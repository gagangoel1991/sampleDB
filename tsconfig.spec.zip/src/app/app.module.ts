import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { routing } from './app.routing';
import { AppConfig } from './app.config';
import { AppComponent } from './app.component';
import { ErrorComponent } from './shared/components/error/error.component';
import { PageNotFoundComponent } from './shared/components/page-not-found/page-not-found.component';
import { ToastrModule } from 'ngx-toastr';
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { HttpSharedIntercepterService } from './core/interceptors/http-shared-intercepter.service';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { LogApi } from 'src/app/core/services/log/log-api';
import { AuthGuardService } from 'src/app/core/guard/auth-guard.service';
import { AuthService } from 'src/app/core/guard/auth.service';
import { SFSDashboardComponent } from 'src/app/shared/home/dashboard/sfsdashboard.component';
import { UnauthorizedComponent } from 'src/app/shared/components/unauthorized/unauthorized.component';
import { ReactiveFormsModule, FormsModule } from '@angular/forms';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { ContextMenuModule } from 'ngx-contextmenu';
import { CommonPopupComponent } from './shared/components/confirm-common-popup/sfp-common-popup.component';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { HashLocationStrategy, LocationStrategy } from '@angular/common';
import { SharedDataService } from './shared/services/shared-data.service';
import { WorkflowAuditTrailPopupComponent } from './shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { CustomControlModule } from './shared/modules/custom-control.module';
import { AuthWorkflowPopupComponent } from './shared/components/auth-workflow/auth-workflow-popup.component';
import { AuthWorkflowService } from './shared/services/auth-workflow-service';
import { InfoPopupComponent } from './shared/components/info-popup/info-popup.component';
import { CommentPopupComponent } from './shared/components/comment-popup/comment-popup.component';
import { OverrideIrComponent } from './cash-waterfall/ipd-run-process/ipd-summary/override-ir/override-ir.component';
import { ListingPageService } from './shared/services/listing-page-service';
import { CorporateGuardService } from './core/guard/corporate-guard.service';
import { RetailGuardService } from './core/guard/retail-guard.service';
import { HomeGuardService } from './core/guard/home-guard.service';
import { NWMGuardService } from './core/guard/nwm-guard.service';

import { OverrideAuditPopupComponent } from './shared/components/override-audit-popup/override-audit-popup.component';
import { FileUploadUtilityComponent } from './shared/components/file-upload-utility/file-upload-utility.component';



// import { AngularSlickgridModule } from 'angular-slickgrid';


@NgModule({
  declarations: [
    AppComponent,
    ErrorComponent,
    PageNotFoundComponent,
    SFSDashboardComponent,
    UnauthorizedComponent,
    CommonPopupComponent,
    InfoPopupComponent,
    CommentPopupComponent,
    WorkflowAuditTrailPopupComponent,
    AuthWorkflowPopupComponent,
    OverrideIrComponent,
    OverrideAuditPopupComponent,    
    
    FileUploadUtilityComponent    
  ],
  entryComponents: [
    CommonPopupComponent,
    OverrideAuditPopupComponent,
    WorkflowAuditTrailPopupComponent,
    AuthWorkflowPopupComponent,
    InfoPopupComponent,
    CommentPopupComponent,
    OverrideIrComponent,
    FileUploadUtilityComponent
  ],
  imports: [
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    ToastrModule.forRoot(),
    routing,
    ReactiveFormsModule,
    FormsModule,
    NgbModule,
    MultiselectDropdownModule,
    CustomControlModule,
    ToastrModule.forRoot(),
    ContextMenuModule.forRoot({
      useBootstrap4: true,
    }),
    routing,
    // AngularSlickgridModule.forRoot()
  ],
  providers: [AppConfig,
    // Registering Global Api and Loging Services
    ConstantService,
    GlobalHttpService,
    LogMaster,
    LogConsole,
    LogApi,
    { provide: HTTP_INTERCEPTORS, useClass: HttpSharedIntercepterService, multi: true },
    { provide: LocationStrategy, useClass: HashLocationStrategy },
    AuthGuardService,
    CorporateGuardService,
    RetailGuardService,
    NWMGuardService,
    HomeGuardService,
    AuthService,
    SharedDataService,
    AuthWorkflowService,
    ListingPageService
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
