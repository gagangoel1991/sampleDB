import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';


@Injectable()
export class AdhocDataLoadService {

  private _globalHttpService: GlobalHttpService;

  constructor(private globalHttpService: GlobalHttpService) {
    this._globalHttpService = globalHttpService;
  }


  public processAdhocDataLoad(loadType: string, loadDate: string): Observable<any> {
    return this.globalHttpService.GetRequest("/adhoc/dataload/monthlyBatch", { 'loadType': loadType, 'asAtDate': loadDate} );
  }

  public loadAdhocDataDates(): Observable<any> {
    return this.globalHttpService.GetRequest("/adhoc/dataload/loaddates");
  }

}



