import { Component, ViewEncapsulation, ViewChild, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { SelectLookupService } from 'src/app/shared/services/select-lookup.service';
import { SelectListEnum, SelectLookupModel } from 'src/app/shared/model/select-lookup.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { AdhocDataLoadService } from './adhoc-dataload.service';



@Component({
  selector: 'sfp-adhoc-dataload',
  templateUrl: './adhoc-dataload.component.html',
  styleUrls: ['./adhoc-dataload.component.scss'],
  providers: [KeyValueLookupService, SelectLookupService, AdhocDataLoadService]
})
export class AdhocDataloadComponent implements OnInit {

  @ViewChild('adhocDataLoadForm') adhocDataloadForm: NgForm;

  public title = 'Adhoc Data Load Utility';
  private readonly _loadDataValidationMessage = 'Please fill required fields marked with asterisk(*) before processing data.';
  private readonly _reportToastTitle = 'Data Load';
  private readonly _dataLoadSuccessMsg = 'Data is loaded successfully.';
  private readonly _dataLoadFailedMsg = 'Data loading process failed.';

  public dealBusinessEndDateList: Array<any> = [];
  public dataLoadTypeList: Array<SelectLookupModel> = [];
  public buttonClicked = false;
  public selectedIpdDate: string = null;
  public selectedLoadType: string = null;
  public selectedLoadTypeForDataLoad: string = null;
  public selectedDealForIpd: string = null;
  public datePipe = new DatePipe('en-UK');
  

  //constructor
  constructor(
    private _selectLookupService: SelectLookupService,
    private _toastservice: GlobalToasterService,
    private _lookupService: KeyValueLookupService,
    private _adhocDataLoadService: AdhocDataLoadService
  ){
        this.showHideLoadingImage(true);
  }

  ngOnInit() {
    this.loadDates();
    this.loadSelectList();
  }


  loadSelectList() {
    let multiListId = [SelectListEnum.LoadDataType]
    this._selectLookupService.getMultiparameterSelectedList(multiListId).subscribe(result => {
      this.dataLoadTypeList = result.filter(x => x.listId == SelectListEnum.LoadDataType);
      this.showHideLoadingImage(false);
    });
  }

  
  loadDates() {
    this._adhocDataLoadService.loadAdhocDataDates().subscribe(result => {
      console.log(result);
      this.dealBusinessEndDateList = result;
      this.showHideLoadingImage(false);
    });
  }


  showHideLoadingImage(isShow) {
    if (isShow)
      document.getElementById('preloader').style['display'] = 'block';
    else
      document.getElementById('preloader').style['display'] = 'none';
  }

  
  onDealClosingEndDate(event: any): boolean {
    this.selectedIpdDate = null;
    if (event) {
        this.selectedIpdDate = event.value;
    }
    return true;
}

onLoadDataType(event: any): boolean {
  this.selectedLoadType = null;
  if (event) {
      this.selectedLoadType = event.text;
  }
  return true;
}

  processDataLoad() {
    if (this.adhocDataloadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this._reportToastTitle, this._loadDataValidationMessage);
      Object.keys(this.adhocDataloadForm.form.controls).forEach((key) => {
        this.adhocDataloadForm.form.get(key).markAsTouched();
      });

      return false;
    }

    this.showHideLoadingImage(true);
    this.buttonClicked = true;
    this._adhocDataLoadService.processAdhocDataLoad(this.selectedLoadType, this.selectedIpdDate).subscribe(data => {

        if(data){
          this._toastservice.openToast(ToasterTypes.success, this._reportToastTitle, this._dataLoadSuccessMsg);
        }else{
          this._toastservice.openToast(ToasterTypes.error, this._reportToastTitle, this._dataLoadFailedMsg);
        } 

        this.buttonClicked = false;
        this.showHideLoadingImage(false);
    }, (error: any) => {
        this.buttonClicked = false;
        this.showHideLoadingImage(false);
    		console.log(error); 
    });
  }

}