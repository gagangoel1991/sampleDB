import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { DealCollectionHistParam } from "src/app/cash-waterfall/model/deal-collection-history.model";

@Injectable()
export class DealCollectionsService {
  private readonly urlApiDailyEstimation = '/dealCollections/getCollectionDate';
  private readonly urlApiDailyEstimationData = '/dealCollections/getCashEstimation';
  private readonly urlApiDailyEstimationDistinct = '/dealCollections/getCashEstDist';
  private readonly urlApiDailyEstimationExcel = '/dealCollections/getCashEstExcel';
  private readonly urlApiPnrSplitData = '/dealCollections/getPNRSplitDetails';
  private readonly urlApiDealDailyCollectionData = '/dealCollections/getDealDailyCollections';
  private readonly urlApiPnrSplitExcel = '/dealCollections/getPNRSplitExcel';

  constructor(private globalHttpService: GlobalHttpService) { }

  public getDailyCashEstimationData(dealName: string, asAtDate: any): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiDailyEstimationData + '/' + dealName.toString() + '/' + asAtDate.toString());
  }

  public getCashEstimationDistinct(dealName: string, asAtDate: any): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiDailyEstimationDistinct + '/' + dealName.toString() + '/' + asAtDate.toString());
  }

  public getCashEstimationExcel(dealName: string, asAtDate: any): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiDailyEstimationExcel + '/' + dealName.toString() + '/' + asAtDate.toString());
  }

  public getCollectionDate(dealName: string, asAtDate: any): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiDailyEstimation + '/' + dealName.toString() + '/' + asAtDate.toString());
  }

  public getCollectionHistory(dealCollHist: DealCollectionHistParam): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getCollectionHistory/`, dealCollHist);
  }

  public getPNRSplitDetails(asAtDate: string, adviceDate: string, dealName: string): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiPnrSplitData + '/' + asAtDate + '/' + adviceDate + '/' + dealName);
  }

  public getDealDailyCollectionsDetails(asAtDate: string): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiDealDailyCollectionData + '/' + asAtDate);
  }

  public getCBOutput(cbOutput: DealCollectionHistParam): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getCBOutput/`, cbOutput);
  }

  public getDealDailyCollectionsExcel(asAtDate: string): Observable<any> {
    return this.globalHttpService.GetRequest(`/dealCollections/getDailyColExl/` + asAtDate.toString());
  }

  public getPNRSplitExcel(asAtDate: string, adviceDate: string, dealName: string): Observable<any> {
    return this.globalHttpService.GetRequest(
      this.urlApiPnrSplitExcel + '/' + asAtDate + '/' + adviceDate + '/' + dealName);
  }

  public getCBOutputExcel(cbOutput: DealCollectionHistParam): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getCBOutputExcel/`, cbOutput);
  }

  public getCollectionHistoryExcel(dealCollHist: DealCollectionHistParam): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/downloadCollectionHistory/`, dealCollHist);
  }

  public getEmailData(emailType: string,asAtDate : string ): Observable<any> {
    return this.globalHttpService.GetRequest(`/dealCollections/getEmailData/` + emailType.toString()  + '/' + asAtDate.toString());
  }
}