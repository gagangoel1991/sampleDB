import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { IAuthWorkflowModel } from 'src/app/shared/model/auth-workflow-model';
import { DailyCollectionDatesExcel, DealSummaryDataModel, DealSummarySaveAdjustmentModel, DealSummarySaveAuditModel } from '../model/dealsum-outputs.model';

@Injectable()
export class DealSummaryOutputService {

  constructor(private globalHttpService: GlobalHttpService) { }

  public getDealSummaryOutputData(dealSummaryDataModel : DealSummaryDataModel): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getDealSummaryOutput/`,dealSummaryDataModel);
  }

  public saveDealSummaryAdjustmentData(dealSummarySaveAdjustmentModel : Array<DealSummarySaveAdjustmentModel>): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/saveDealSummaryAdjustment/`,dealSummarySaveAdjustmentModel);
  }

  public getDealSummaryAuditData(dealSummaryAuditModel : DealSummaryDataModel): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getDealSummaryAudit/`,dealSummaryAuditModel);
  }

  public saveDealSummaryAuditData(dealSummarySaveAuditModel : DealSummarySaveAuditModel): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/saveDealSummaryAudit/`,dealSummarySaveAuditModel);
  }

  public getCollectionDateList(dealName: string, asAtDate: string): Observable<any> {
    return this.globalHttpService.GetRequest( `/dealCollections/getCollectionDateList/${dealName}/${asAtDate}`);
  }

  public manageDealSummaryAuditAuthWorkflowByUser(model: IAuthWorkflowModel): Observable<any> {
    return this.globalHttpService.PostRequest('/dealCollections/manageDealSummaryAuditAuthWorkflowByUser', model);
  }

  public getDailyCollectionDealSummary(adviceDate : string, dealName: string): Observable<any> {
    return this.globalHttpService.GetRequest(`/dealCollections/getDailyCollectionDealSummary/${adviceDate}/${dealName}`);
  }

  public getDealSummaryExcel(dailyCollectionDatesExcel : DailyCollectionDatesExcel): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getDealSummaryExcel/`,dailyCollectionDatesExcel)
  }

  public getLoadDailyEstimationDealSummary(adviceDate : string, dealName: string ,isEstimationData : boolean): Observable<any> {
    return this.globalHttpService.GetRequest(`/dealCollections/getLoadDailyEstimationDealSummary/${adviceDate}/${dealName}/${isEstimationData}`);
  }

  public getDealSummaryLoadDataEstimation(dealSummaryDataModel : DealSummaryDataModel): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealCollections/getDealSummaryLoadDataEstimation/`,dealSummaryDataModel);
  }

  public isActualGMSDataAvaliable(adviceDate : string, dealName: string ,isEstimationData : boolean): Observable<any> {
    return this.globalHttpService.GetRequest(`/dealCollections/isActualGMSDataAvaliable/${adviceDate}/${dealName}/${isEstimationData}`);
  }
  
}
