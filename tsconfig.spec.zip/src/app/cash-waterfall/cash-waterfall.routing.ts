import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { CanDeactivateGuardService } from 'src/app/core/guard/can-deactivate/can-deactivate-guard.service';
import { InvoiceManagementListComponent } from './invoice-management/list/invoice-management-list.component';
import { CashWaterfallModule } from './cash-waterfall.module';
import { ManageInvoiceComponent } from 'src/app/cash-waterfall/invoice-management/manage/manage-invoice.component';
import { IpdProcessMenuResolverService } from '../core/services/resolver/ipd-process-menu.resolver';
import { IpdManagementComponent } from './ipd-management/ipd-management.component';
import { RatingUploadListingComponent } from './rating-upload/rating-upload-listing/rating-upload-listing.component';
import { RatingUploadComponent } from './rating-upload/rating-upload/rating-upload.component';
import { RatingViewComponent } from './rating-upload/rating-view/rating-view.component';
import { DashboardComponent } from './dashboard/dashboard.component'
import { InvoiceIpdDataComponent } from './ipd-run-process/invoices/invoice-ipd-data.component';
import { AdhocDataloadComponent } from './adhoc-dataload/adhoc-dataload.component';
import { DailyCashEstimationComponent } from './deal-collections/daily-cash-estimation/daily-cash-estimation.component';
import { DealCollectionHistoryComponent } from './deal-collections/deal-collection-history/deal-collection-history.component';
import { CbOutputComponent } from './deal-collections/cb-output/cb-output.component';
import { DealsumOutputsComponent } from './deal-collections/deal-Summary/dealsum-outputs/dealsum-outputs.component';
import { RmbsPnrSplitComponent } from './deal-collections/rmbs-pnr-split/rmbs-pnr-split.component';
import { DealDailyCollectionsComponent } from 'src/app/cash-waterfall/deal-collections/deal-daily-collections/deal-daily-collections.component';

export const routes: Routes = [
    { path: 'dashboard', component: DashboardComponent, pathMatch: 'full' },
    { path: 'ipd-management', component: IpdManagementComponent, data: { breadcrumb: 'Invoice Management' } },
    {
        path: 'ipdrunprocess/:dealId/:ipdRunId',
        loadChildren: () => import('src/app/cash-waterfall/ipd-run-process/ipd-process.module').then(m => m.IpdProcessModule),
        resolve: { data: IpdProcessMenuResolverService }
    }
    ,
    { path: 'invoicemgmt', component: InvoiceManagementListComponent, data: { breadcrumb: 'Invoice Management' } }
    ,
    {
        path: 'invoicemgmt/add', component: ManageInvoiceComponent, data: { breadcrumb: 'Invoice Management > Add Invoice' },
        canDeactivate: [CanDeactivateGuardService],
    },

    {
        path: 'invoicemgmt/copy/:invoiceid', component: ManageInvoiceComponent, data: { breadcrumb: 'Invoice Management > Copy Invoice' },
        canDeactivate: [CanDeactivateGuardService],
    },
    {
        path: 'invoicemgmt/view/:invoiceid', component: ManageInvoiceComponent, data: { breadcrumb: 'Invoice Management > View Invoice' },
        canDeactivate: [CanDeactivateGuardService],
    },
    {
        path: 'invoicemgmt/:dealId/:ipdRunId', component: InvoiceManagementListComponent,
        data: { breadcrumb: 'Invoice Management' }
    }
    ,
    {
        path: 'invoicemgmt/add/:dealId/:ipdRunId', component: ManageInvoiceComponent, data: { breadcrumb: 'Invoice Management > Add Invoice' },
        canDeactivate: [CanDeactivateGuardService],
    }
    ,

    {
        path: 'userrating', component: RatingUploadListingComponent, data: { breadcrumb: 'User Rating > view' }

    },
    {
        path: 'userrating/upload', component: RatingUploadComponent, data: { breadcrumb: 'User Rating > upload' }

    },
    {
        path: 'userrating/view/:userRatingFileUploadDetailId', component: RatingViewComponent, data: { breadcrumb: 'User Rating > upload' }

    },
    {
        path: 'adhocDataLoad', component: AdhocDataloadComponent, data: { breadcrumb: 'Adhoc Data Load' }
    },
    {
        path: 'deal-collections/daily-cash-estimation', component: DailyCashEstimationComponent, data: { breadcrumb: 'Daily Cash Estimation' }
    },
    {
        path: 'deal-collections/collection-history-deal', component: DealCollectionHistoryComponent, data: { breadcrumb: 'Collection History - Deal' }
    },
    {
        path: 'deal-collections/cb-deal-output', component: CbOutputComponent, data: { breadcrumb: 'Covered Bond Deal - Output' }
    },
    {
        path: 'deal-collections/rmbs-pnr-split', component: RmbsPnrSplitComponent, data: { breadcrumb: 'RMBS Deal - P&R Split' }
    },    
    {
        path: 'deal-collections/deal-summary', component: DealsumOutputsComponent, data: { breadcrumb: 'DealSum Outputs' }
    },    
    {
        path: 'deal-collections/deal-daily-collections', component: DealDailyCollectionsComponent, data: { breadcrumb: 'Daily Collections' }
    }
];

export const routing: ModuleWithProviders<CashWaterfallModule> = RouterModule.forChild(routes);