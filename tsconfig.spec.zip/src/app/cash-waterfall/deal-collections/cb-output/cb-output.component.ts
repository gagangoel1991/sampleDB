import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { hyperLinkFormatter, downloadLinkFormatter, currencyFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { DealCollectionsService } from 'src/app/cash-waterfall/service/deal-collections.service';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { DealCollectionHistParam } from 'src/app/cash-waterfall/model/deal-collection-history.model';

@Component({
  selector: 'sfp-cb-output',
  templateUrl: './cb-output.component.html',
  styleUrls: ['./cb-output.component.scss'],
  providers: [DealCollectionsService]
})
export class CbOutputComponent implements OnInit {

  @ViewChild('cbOutputForm') cbOutputForm: NgForm;

  private readonly _cbOutputValidationMessage = 'Please fill/select required fields marked with asterisk(*) before showing the data.';
  private readonly _adviceDateValidationMessage = 'Please select advice date.';
  private readonly _startEndDatesMessage = 'Start date should be less than end date.';
  private readonly _excelValidationMessage = 'No data to export.';
  private readonly _dateFormat = 'yyyy-MM-dd';
  private readonly _defaultDate = '1900-01-01';
  private readonly _requiredDateFormat = 'yyyy-MM-dd';

  public title = 'CB IPD Collections';
  public startDate;
  public endDate;
  public cbOutputList: any[];
  public isShowing: boolean = false;
  public currentDate = new Date();
  public datePipe = new DatePipe('en-UK');
  public cbOutputParam: DealCollectionHistParam;
  public isRowVisible: boolean = true;
  public isRecordFound: boolean = false;
  public isDataRequestComplete = false;

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickExportFileName: string;
  //-------Slick Grid Variables End--------------

  @Output() selectedExclusions = new EventEmitter<string>();

  constructor(
    private _cbOutputService: DealCollectionsService,
    private _toastservice: GlobalToasterService,
    private _sharedDataService: SharedDataService
  ) { }

  ngOnInit(): void {
    this.setDefault();
    this.isDataRequestComplete = true;

    //SET EXPORT FILE NAME
    var myDt = new Date();
    var current_timestamp = myDt.getDate() + (myDt.toLocaleString('default', { month: 'short' })) + myDt.getFullYear();
    this.slickExportFileName = 'CB-IPDCollections' + current_timestamp;
  }

  setDefault() {
    this.isRowVisible = false;
    this.isRecordFound = false;
    let stDate: Date = new Date();
    const date = new Date();

    // Get the First day of the Previous Month
    stDate = new Date(date.getFullYear(), date.getMonth() - 1, 1)
    this.bindGridColumns();
    this.startDate = this.datePipe.transform(stDate, 'yyyy-MM-dd');
    this.endDate = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd');
    this.getGridData();
  }

  bindGridColumns() {
    this.slickColumnArray.push
      (
        //Preparing grid custom columns
        new SFP_SlickColumn('adviceDate', 'Advice Date', true, true, 120, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('cashCollectionDate', 'Cash Collection Date', true, true, 120, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('grossPrincipalCollectionsFeesandOtherMovements', 'Gross Principal Collections Fees and Other Movements', true, true, 180, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('lessPrincipalElementofFurtherAdvances', 'Less Principal Element of Further Advances', true, true, 170, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('plusRepurchaseAmounts', 'PlusRepurchase Amounts', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('netPrincipalCollections', 'Net Principal Collections', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('revenueCollections', 'Revenue Collections', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('dailyCashMovement', 'Daily Cash Movement', true, true, 120, FieldType.string, currencyFormatter),
      );
  }

  getGridData() {
    this.cbOutputParam = new DealCollectionHistParam();
    this.cbOutputList = [];

    // Set values for parameter
    this.cbOutputParam.asAtDate = this.startDate
    this.cbOutputParam.asAtToDate = this.endDate

    if ((this.startDate != null && this.startDate != "") || (this.endDate && this.endDate)) {
      this._cbOutputService.getCBOutput(this.cbOutputParam).subscribe(result => {
        this.cbOutputList = JSON.parse(JSON.stringify(result));
        this.slickDataset = this.cbOutputList;
        if (this.slickDataset.length > 0) {
          this.isRecordFound = true;
        }
      }, (error: any) => {
        console.log(error);
      });

    }
  }

  resizeGrid() {
    const objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  cbOutputView() {
    this.isDataRequestComplete = false;
    if (this.cbOutputForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._cbOutputValidationMessage);
      Object.keys(this.cbOutputForm.form.controls).forEach((key) => {
        this.cbOutputForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    } else {

      if (this.startDate > this.endDate) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._startEndDatesMessage);
        return;
      }
      else {
        this.getGridData();
        this.isDataRequestComplete = true;
      }
    }
  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  generateCBCollectionExcel() {
    this.isDataRequestComplete = false;
    if (this.cbOutputForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._cbOutputValidationMessage);
      Object.keys(this.cbOutputForm.form.controls).forEach((key) => {
        this.cbOutputForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    }
    else {
      if (this.startDate > this.endDate) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._startEndDatesMessage);
        return;
      }
      else if (this.cbOutputList == null) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._excelValidationMessage);
      }
      else {
        this.cbOutputParam = new DealCollectionHistParam();
        // Set values for parameter
        this.cbOutputParam.asAtDate = this.startDate
        this.cbOutputParam.asAtToDate = this.endDate

        this._cbOutputService.getCBOutputExcel(this.cbOutputParam).subscribe(data => {
          let FileName = "CB-IPDCollections_" + this.formatDate(this.currentDate) + ".xlsx";
          var blob = new Blob([this.s2ab(atob(data))], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
          });

          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = FileName;

          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          this.isDataRequestComplete = true;
        }, (error: any) => {
          console.log(error);
        });
      }
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
}
