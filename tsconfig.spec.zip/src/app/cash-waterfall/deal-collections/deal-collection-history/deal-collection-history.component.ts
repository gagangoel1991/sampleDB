import { Component, EventEmitter, OnInit, Output, ViewChild } from '@angular/core';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { DealCollectionsService } from 'src/app/cash-waterfall/service/deal-collections.service';
import { SelectLookupModel } from 'src/app/shared/model/select-lookup.model';
import { DatePipe } from '@angular/common';
import { DealCollectionHistParam } from 'src/app/cash-waterfall/model/deal-collection-history.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { hyperLinkFormatter, downloadLinkFormatter, currencyFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { BrandList } from 'src/app/pool-selection-master/pool-management/models/pool-brand.model';
import { NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';

@Component({
  selector: 'sfp-deal-collection-history',
  templateUrl: './deal-collection-history.component.html',
  styleUrls: ['./deal-collection-history.component.scss'],
  providers: [KeyValueLookupService, DealCollectionsService]
})
export class DealCollectionHistoryComponent implements OnInit {

  @ViewChild('dealCollectionHistoryForm') collectionHistoryForm: NgForm;

  private readonly _collectionHistoryValidationMessage = 'Please fill/select required fields marked with asterisk(*) before showing the data.';
  private readonly _adviceDateValidationMessage = 'Please select advice date.';
  private readonly _startEndDatesMessage = 'Starte date should be less than end date.';
  private readonly _excelValidationMessage = 'No data to export.';
  private readonly _dealNameValidationMessage = 'Please select deal name.';
  private readonly _dateFormat = 'yyyy-MM-dd';
  private readonly _defaultDate = '1900-01-01';

  public title = 'Collection History - Deal';
  public dealNameList: Array<KeyValueLookupModel> = [];
  public dealId;
  public dealName;
  public brandId;
  public brandName;
  public brandNameList: Array<KeyValueLookupModel> = [];
  public startDate;
  public endDate;
  public dealCollectionHistList: any[];
  public isShowing: boolean = false;
  public dealCollectionHistParam: DealCollectionHistParam;
  public currentDate = new Date();
  public datePipe = new DatePipe('en-UK');
  public isRowVisible: boolean = true;
  public isRecordFound: boolean = false;
  public isDataRequestComplete = false;

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickExportFileName: string;
  //-------Slick Grid Variables End--------------

  @Output() selectedExclusions = new EventEmitter<string>();

  constructor(
    private _lookupService: KeyValueLookupService,
    private _dealCollectionHistoryService: DealCollectionsService,
    private _toastservice: GlobalToasterService,
    private _sharedDataService: SharedDataService
  ) {
  }

  ngOnInit(): void {
    this.brandNameList = null;
    this.getDealName();
    this.getBrandName();
    this.dealId = 6;
    this.dealName = "Deimos";
    this.brandName = ["NWB"];
    this.isDataRequestComplete = true;
    this.setDefault();

    //SET EXPORT FILE NAME
    var myDt = new Date();
    var current_timestamp = myDt.getDate() + (myDt.toLocaleString('default', { month: 'short' })) + myDt.getFullYear();
    this.slickExportFileName = 'DailyCollectionHistory_' + current_timestamp;
  }

  getDealName() {
    this.dealNameList = null;
    this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealListForESMAReports.toString()).subscribe(result => {
      this.dealNameList = result;
    });
  }

  getBrandName() {
    this.brandNameList = null;
    this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveBrands.toString()).subscribe(result => {
      this.brandNameList = result;
    });
  }

  onDealDropDownChange(event: any) {
    if (event) {
      this.dealId = event.key;
      this.dealName = event.value;

      this.startDate = "";
      this.endDate = "";
      this.brandName = "";
      this.dealCollectionHistList = [];
      this.slickDataset = this.dealCollectionHistList;
      if (this.slickDataset.length > 0) {
        this.isRecordFound = true;
      }
      else
      {
        this.isRecordFound = false;
      }
    }
  }

  onBrandDropDownChange(event: any) {
    this.selectedExclusions.emit(this.brandName.map(x => x).join(","));
  }

  setDefault() {
    this.isRowVisible = false;
    this.isRecordFound = false;
    let stDate: Date = new Date();
    stDate.setDate(stDate.getDate() - 90);
    this.bindGridColumns();
    this.startDate = this.datePipe.transform(stDate, 'yyyy-MM-dd');
    this.endDate = this.datePipe.transform(this.currentDate, 'yyyy-MM-dd');
    this.getGridData();
  }

  bindGridColumns() {
    this.slickColumnArray.push
      (
        //Preparing grid custom columns
        new SFP_SlickColumn('businessDate', 'Business Date', true, true, 90, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('dealName', 'Deal Name', true, true, 90, FieldType.string),
        new SFP_SlickColumn('brandID', 'Brand ID', true, true, 90, FieldType.string),
        new SFP_SlickColumn('openingTrueBalance', 'Opening True Balance', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('openingAccruedInterest', 'Opening Accrued Interest', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('openingCustomerStatementBalanceDerived', 'Opening  Customer Statement Balance  (Derived)', true, true, 200, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('scheduledPrincipalReductions', 'Scheduled Principal Reductions', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('partialPrepayments', 'Partial Prepayments', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('overpayments', 'Overpayments', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('fullRedemptionPayments', 'Full Redemption Payments', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('furtherStageAdvances', 'Further Stage Advances', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('feesChargedCapitalised', 'Fees Charged Capitalised', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('trueCapitalBalance', 'True Capital Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('capitalBalanceInArrears', 'Capital Balance In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('interestReceived', 'Interest Received', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('interestInArrears', 'Interest In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('feesReceived', 'Fees Received', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('feesInArrears', 'Fees In Arrears', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('finesReceived', 'Fines Received', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('finesInArrears', 'Fines In Arrears', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('otherPrincipalMovements', 'Other Principal Movements', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalPrincipalReceipts', 'Total Principal Receipts', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('feesandFinesReceived', 'Fees and Fines Received', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalRevenueReceipts', 'Total Revenue Receipts', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalCashReceived', 'Total Cash Received', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('interestCharged', 'Interest Charged', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('feesandFinesCharged', 'Fees and Fines Charged', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalBalanceMovements', 'Total Balance Movements', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('closingTrueBalance', 'Closing True Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('closingAccruedInterest', 'Closing Accrued Interest', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('closingCustomerStatementBalanceDerived', 'Closing Customer Statement Balance (Derived)', true, true, 200, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('closingTrueBalanceDerived', 'Closing True Balance  (Derived)', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('varianceClosingTrueBalancevsClosingTrueBalanceDerived', 'Variance Closing True Balance vs Closing True Balance (Derived)', true, true, 250, FieldType.string, currencyFormatter),

        new SFP_SlickColumn('prevTrueBalance', 'Prev True Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevTrueCapitalBalance', 'Prev True Capital Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevCapitalInArrears', 'Prev Capital In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevPrepayments', 'Prev Prepayments', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevTotalCapitalBalanceOutstanding', 'Prev Total Capital Balance Outstanding', true, true, 200, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevFeesInArrears', 'Prev Fees In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevFinesInArrears', 'Prev Fines In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevInterestInArrears', 'Prev Interest In Arrearss', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevArrearsInsurance', 'Prev Arrears Insurance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevInterestEarnedNotApplied', 'Prev Interest Earned Not Applied', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevTrueInterestAfterWorkingCalendarDate', 'Prev True Interest After Working Calendar Date', true, true, 180, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('prevControlBreak', 'Prev Control Break', true, true, 150, FieldType.string, currencyFormatter),

        new SFP_SlickColumn('crntTrueBalance', 'Current True Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntTrueCapitalBalance', 'Current True Capital Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntCapitalInArrears', 'Current Capital In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntPrepayments', 'Current Pre-payments', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntTotalCapitalBalanceOutstanding', 'Current Total Capital Balance Outstanding', true, true, 200, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntFeesInArrears', 'Current Fees In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntFinesInArrears', 'Current Fines In Arrears', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntInterestInArrears', 'Current Interest In Arrearss', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntArrearsInsurance', 'Current Arrears Insurance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntInterestEarnedNotApplied', 'Current Interest Earned Not Applied', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntTrueInterestAfterWorkingCalendarDate', 'Current True Interest After Working Calendar Date', true, true, 200, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('crntControlBreak', 'Current Control Break', true, true, 150, FieldType.string, currencyFormatter),

        new SFP_SlickColumn('principalReceiptsDeflagged', 'Principal Receipts Deflagged', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('revenueReceiptsDeflagged', 'Revenue Receipts', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalDeflaggedBalance', 'Total De-flagged Balance', true, true, 150, FieldType.string, currencyFormatter),

        new SFP_SlickColumn('principalReceiptsTopup', 'Principal Receipts', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('revenueReceiptsTopup', 'Revenue Receipts', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalTopupBalance', 'Total Top-up Balance', true, true, 150, FieldType.string, currencyFormatter),

        new SFP_SlickColumn('netPrincipalReceiptsCurrentvspreviousBusinessDay', 'Net Principal Receipts (Current vs previous Business Day)', true, true, 250, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('netRevenueReceipts', 'Net Revenue Receipts (Total Revenue Receipts + Revenue receipts of De-flagged Mortgages)', true, true, 250, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('overallVariance', 'Overall Variance (Net Principal Receipts - Total Principal Receipts) + Revenue Receipts for De-flagged Mortgages', true, true, 300, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('variance', 'Variance (Total De-flagged Balance vs Overall Variance)', true, true, 250, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('overallControlBreak', 'Overall Control Break', true, true, 150, FieldType.string, currencyFormatter),
      );
  }

  getGridData() {
    this.dealCollectionHistParam = new DealCollectionHistParam();
    this.dealCollectionHistList = [];
    // Set values for parameter
    this.dealCollectionHistParam.asAtDate = this.startDate
    this.dealCollectionHistParam.asAtToDate = this.endDate
    this.dealCollectionHistParam.dealName = this.dealName;
    this.dealCollectionHistParam.brandList = this.brandName;

    if ((this.dealName != null && this.dealName != "") || (this.brandName && this.brandName) || (this.startDate && this.startDate) || (this.endDate && this.endDate)) {
      this._dealCollectionHistoryService.getCollectionHistory(this.dealCollectionHistParam).subscribe(result => {
        this.dealCollectionHistList = JSON.parse(JSON.stringify(result));
        this.slickDataset = this.dealCollectionHistList;

        if (this.slickDataset.length > 0) {
          this.isRecordFound = true;
        }
      }, (error: any) => {
        console.log(error);
      });
    }
  }

  collectionHistoryView() {
    if (this.collectionHistoryForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._collectionHistoryValidationMessage);
      Object.keys(this.collectionHistoryForm.form.controls).forEach((key) => {
        this.collectionHistoryForm.form.get(key).markAsTouched();
      });
      return false;
    } else {

      if (this.startDate > this.endDate) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._startEndDatesMessage);
        return;
      }
      this.getGridData();
    }
  }

  resizeGrid() {
    const objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  collectionHistoryExcelExport() {
    this.isDataRequestComplete = false;
    if (this.collectionHistoryForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._collectionHistoryValidationMessage);
      Object.keys(this.collectionHistoryForm.form.controls).forEach((key) => {
        this.collectionHistoryForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    } else {

      if (this.startDate > this.endDate) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._startEndDatesMessage);
        return;
      }
      else if (this.dealCollectionHistList == null) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._excelValidationMessage);
      }
      else {
        this.dealCollectionHistParam = new DealCollectionHistParam();
        this.dealCollectionHistList = [];
        // Set values for parameter
        this.dealCollectionHistParam.asAtDate = this.startDate
        this.dealCollectionHistParam.asAtToDate = this.endDate
        this.dealCollectionHistParam.dealName = this.dealName;
        this.dealCollectionHistParam.brandList = this.brandName;

        this._dealCollectionHistoryService.getCollectionHistoryExcel(this.dealCollectionHistParam).subscribe(data => {
          debugger;
          let downloadFileName = "CollectionHistory_" + this.formatDate(this.currentDate) + ".xlsx";
          var blob = new Blob([this.s2ab(atob(data))], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
          });

          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = downloadFileName;

          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);

          this.isDataRequestComplete = true;
        }, (error: any) => {
          this.isDataRequestComplete = true;
          console.log(error);
        });
      }
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
}