import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'sfp-deal-collections',
  templateUrl: './deal-collections.component.html',
  styleUrls: ['./deal-collections.component.scss']
})
export class DealCollectionsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
