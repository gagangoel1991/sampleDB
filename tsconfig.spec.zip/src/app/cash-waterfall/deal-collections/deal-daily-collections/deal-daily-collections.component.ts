import { Component, OnInit, ViewChild } from '@angular/core';
import { DecimalPipe } from '@angular/common';
import { DealCollectionsService } from 'src/app/cash-waterfall/service/deal-collections.service';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DatePipe } from '@angular/common';
import { StringBuilder } from 'src/app/shared/resources/utility/string-builder-utility';
import { NgForm } from '@angular/forms';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { HeaderCollectionModel } from 'src/app/cash-waterfall/ipd-run-process/model/deal-subloan.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { hyperLinkFormatter, downloadLinkFormatter, currencyFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';

@Component({
  selector: 'sfp-deal-daily-collections',
  templateUrl: './deal-daily-collections.component.html',
  styleUrls: ['./deal-daily-collections.component.scss'],
  providers: [DealCollectionsService, DecimalPipe]
})
export class DealDailyCollectionsComponent implements OnInit {

  @ViewChild('DealDailyCollectionsHeadForm') dealDailyCollectionsHeadForm: NgForm;

  private readonly _dailyCollectionsValidationMessage = 'Please fill/select required fields marked with asterisk(*) before showing the data.';
  private readonly _adviceDateValidationMessage = 'Please select advice date.';
  private readonly _excelValidationMessage = 'No data to export.';
  private readonly _emailDraftValidationMessage = 'No data to draft an email.';
  private readonly _requiredDateFormat = 'yyyy-MM-dd';
  private readonly emailType = '1';

  public title = 'Daily Collection Output';
  public dealDailyCollectionDataList: any[];
  public emailData: any[];
  public currentDate = new Date();
  public isRowVisible: boolean = false;
  public isRecordFound: boolean = false;
  public adviceDT: string;
  public emailStringBuilder: string;
  public isDataRequestComplete = false;
  public isEmalAttachmentFile = false;

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickExportFileName: string;
  //-------Slick Grid Variables End--------------

  datePipe = new DatePipe('en-UK');

  constructor(
    private _dealDailyCollectionsService: DealCollectionsService,
    private _toastservice: GlobalToasterService,
    private _decimalPipe: DecimalPipe,
    private _sharedDataService: SharedDataService
  ) { }

  ngOnInit(): void {
    this.setDefault();
    this.isDataRequestComplete = true;

    //SET EXPORT FILE NAME
    var myDt = new Date();
    var current_timestamp = myDt.getDate() + (myDt.toLocaleString('default', { month: 'short' })) + myDt.getFullYear();
    this.slickExportFileName = 'DailyCollectionOutput' + current_timestamp;
  }

  setDefault() {
    this.isRowVisible = false;
    this.isRecordFound = false;

    this.bindGridColumns();
    this.adviceDT = this.formatDate(this.currentDate);
    this.getGridData();
  }

  bindGridColumns() {
    this.slickColumnArray.push
      (
        //Preparing grid custom columns
        new SFP_SlickColumn('adviceDate', 'Advice Date', true, true, 90, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('collectionDate', 'Collection Date', true, true, 90, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('contextName', 'Context Name', true, true, 200, FieldType.string),
        new SFP_SlickColumn('originator', 'Originator', true, true, 120, FieldType.string),
        new SFP_SlickColumn('principalReceipts', 'Principal Receipts', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('revenueReceipts', 'Revenue Receipts', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('otherCollections', 'Other Collections', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalDailyCash', 'Total Daily Cash', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('dealName', 'Deal Name', true, true, 100, FieldType.string),
        new SFP_SlickColumn('dailyCashMovement', 'Daily Cash Movement', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('compare', 'Compare', true, true, 100, FieldType.string),
        new SFP_SlickColumn('dataSource', 'DataSource', true, true, 100, FieldType.string),
        new SFP_SlickColumn('difference', 'Difference', true, true, 120, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('lossProcessedPreviousDay', 'Loss Processed Previous Day', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('flaggingDeflaggingAdjustment', 'Flagging/Deflagging Adjustment', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('residualDifference', 'Residual Difference', true, true, 120, FieldType.string, currencyFormatter),
      );
  }

  getGridData() {
    this.dealDailyCollectionDataList = [];

    let formattedAdviceDate = this.adviceDT ? this.datePipe.transform(this.adviceDT, this._requiredDateFormat) : '';
    this._dealDailyCollectionsService.getDealDailyCollectionsDetails(formattedAdviceDate).subscribe(result => {
      this.dealDailyCollectionDataList = result;

      this.dealDailyCollectionDataList = JSON.parse(JSON.stringify(result));
      this.slickDataset = this.dealDailyCollectionDataList;
      if (this.slickDataset.length > 0) {
        this.isRecordFound = true;
      }

    }, (error: any) => {
      console.log(error);
    });
  }

  formatAmount(lineItem: string) {
    return this._decimalPipe.transform(lineItem, '1.2-2');
  }

  getMaxNoticeDate() {
    return new Date(this.currentDate);
  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  setVintageDate(dateParam: Date) {
    this.adviceDT = dateParam.toString();
  }

  dealDailyCollectionView() {
    this.isDataRequestComplete = false;

    if (this.dealDailyCollectionsHeadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dailyCollectionsValidationMessage);
      Object.keys(this.dealDailyCollectionsHeadForm.form.controls).forEach((key) => {
        this.dealDailyCollectionsHeadForm.form.get(key).markAsTouched();
      });
      return false;
    }
    else {
      if (this.adviceDT === undefined || this.adviceDT == null || this.adviceDT == '') {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else {
        this.getGridData();
        this.isDataRequestComplete = true;
      }
    }
  }

  generateDealDailyCollectionExcel() {
    this.isDataRequestComplete = false;
    if (this.dealDailyCollectionsHeadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dailyCollectionsValidationMessage);
      Object.keys(this.dealDailyCollectionsHeadForm.form.controls).forEach((key) => {
        this.dealDailyCollectionsHeadForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    }
    else {
      if (this.adviceDT === undefined || this.adviceDT == null || this.adviceDT == '') {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else if (this.dealDailyCollectionDataList == null) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._excelValidationMessage);
      }
      else {
        console.log(this.adviceDT);
        let formattedAdviceDate = this.adviceDT ? this.datePipe.transform(this.adviceDT, this._requiredDateFormat) : '';
        this._dealDailyCollectionsService.getDealDailyCollectionsExcel(formattedAdviceDate).subscribe(data => {
         // let FileName = "DailyCollectionOutput_" + this.formatDate(this.currentDate) + ".xlsx";
         let FileName = "DailyCollectionOutput.xlsx";
          var blob = new Blob([this.s2ab(atob(data))], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
          });

          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = FileName;

          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          this.isDataRequestComplete = true;
        }, (error: any) => {
          console.log(error);
        });
      }
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  sendEmail() {
    this.isDataRequestComplete = false;

    if (this.dealDailyCollectionsHeadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dailyCollectionsValidationMessage);
      Object.keys(this.dealDailyCollectionsHeadForm.form.controls).forEach((key) => {
        this.dealDailyCollectionsHeadForm.form.get(key).markAsTouched();
      });
      return false;
    }
    else {
      if (this.adviceDT === undefined || this.adviceDT == null || this.adviceDT == '') {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else if (this.dealDailyCollectionDataList == null) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._emailDraftValidationMessage);
      }
      else {
        this.emailSetup();
       // this.isEmalAttachmentFile =true
      //  this.generateDealDailyCollectionExcel(this.isEmalAttachmentFile);
        this.isDataRequestComplete = true;
      }
    }
  }

  emailSetup() {
    const sb = new StringBuilder();
    let formattedAdviceDate = this.adviceDT ? this.datePipe.transform(this.adviceDT, this._requiredDateFormat) : '';
    this._dealDailyCollectionsService.getEmailData(this.emailType,formattedAdviceDate).subscribe(result => {
      this.emailData = JSON.parse(JSON.stringify(result));
      let emailFrom = result.map(a => a.emailFrom);
      let IsImportance = result.map(a => a.emailImportance);
      let emailImportanceText = result.map(a => a.emailImportanceText);
      let emailFormat = result.map(a => a.emailFormat);
      let IsAttachment = result.map(a => a.attachment);
      let emailAttachmentText = result.map(a => a.attachmentText);

      let emailTo = result.map(a => a.emailTo);
      let emailSubject = result.map(a => a.emailSubject);
      let emailBody = result.map(a => a.emailBody);
      let emailCC = result.map(a => a.emailCC);
      let emailBCC = result.map(a => a.emailBCC);

      // Validation check if CC or BCC are not given.
      if (true == this.isDataFound(emailTo))
        sb.write("mailto:" + emailTo);

      if (true == this.isDataFound(emailSubject))
        sb.write("?subject=" + emailSubject);

      if (true == this.isDataFound(emailBody))
        sb.write("&body=" + emailBody);

      if (true == this.isDataFound(emailCC))
        sb.write("&cc=" + emailCC);

      if (true == this.isDataFound(emailBCC))
        sb.write("&bcc=" + emailBCC);

      //console.log(sb.toString());
      window.location.href = sb.toString();

    }, (error: any) => {
      console.log(error);
    });
  }

  isDataFound(dataChecking: string) {
    if (dataChecking === undefined || dataChecking == null || dataChecking == '')
      return false;
    else
      return true;
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }
}