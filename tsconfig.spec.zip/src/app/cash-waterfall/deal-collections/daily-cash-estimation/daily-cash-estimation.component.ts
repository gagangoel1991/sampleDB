import { Component, OnInit, ViewChild } from '@angular/core';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { DealCollectionsService } from 'src/app/cash-waterfall/service/deal-collections.service';
import { DailyCashEstimationModel } from 'src/app/cash-waterfall/model/daily-cash-estimation.model';
import { SelectLookupModel } from 'src/app/shared/model/select-lookup.model';
import { DatePipe } from '@angular/common';
import { DecimalPipe } from '@angular/common';
import { DateListService } from 'src/app/shared/services/date-list-service';
import { NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { ConsoleService } from '@ng-select/ng-select/lib/console.service';

@Component({
  selector: 'sfp-daily-cash-estimation',
  templateUrl: './daily-cash-estimation.component.html',
  styleUrls: ['./daily-cash-estimation.component.scss'],
  providers: [KeyValueLookupService, DealCollectionsService, DecimalPipe, DateListService]
})
export class DailyCashEstimationComponent implements OnInit {

  @ViewChild('dealCollectionEstimationForm') collectionEstimationForm: NgForm;

  private readonly _collectionEstimationValidationMessage = 'Please fill/select required fields marked with asterisk(*) before showing the data.';
  private readonly _adviceDateValidationMessage = 'Please select advice date.';
  private readonly _dealNameValidationMessage = 'Please select deal name.';
  private readonly _requiredDateFormat = 'yyyy-MM-dd';

  public title = 'Daily Cash Estimation';
  public dealNameList: Array<KeyValueLookupModel> = [];
  public groupType: string[] = null;
  public brandHeaders: string[] = null;
  public subHeaders: string[] = null;
  public headers: string[] = null;
  public bodyValue: string[] = null;
  public collectionDate: string[] = null;
  public testDatalineItems: Array<DailyCashEstimationModel> = [];
  public testDatalineItemsDaily: Array<DailyCashEstimationModel> = [];
  public testDatalineItemsMonthly: Array<DailyCashEstimationModel> = [];
  public dailyCashMethod: Array<DailyCashEstimationModel> = [];
  public distinctBrands: Array<string> = [];
  public distinctLineItemsDaily: Array<string> = [];
  public distinctLineItemsMonthly: Array<string> = [];
  public dealBusinessEndDateList: Array<SelectLookupModel> = [];
  public selectedDealBusinessEndDateList: Array<SelectLookupModel> = [];
  public dealId;
  public dealName;
  public dealIpdList: Array<SelectLookupModel> = [];
  public selectedDealName: string = null;
  public collectionDateParameter: Date = null;
  public currentDate = new Date();
  public datalineItemsDistinct: Array<DailyCashEstimationModel> = [];
  public isDataRequestComplete = false;
  public resetPreviousWork: boolean = false;

  collectionDT: string = null;
  colDateForExcel: Date = null;
  datePipe = new DatePipe('en-UK');
  private collectionEndDate: string;

  constructor(
    private _lookupService: KeyValueLookupService,
    private _dailyCashEstimationService: DealCollectionsService,
    private _decimalPipe: DecimalPipe,
    private _toastservice: GlobalToasterService
  ) {
    this.subHeaders = ['Principal', 'Revenue', 'Total'];
  }

  ngOnInit(): void {
    this.getDealName();
    this.isDataRequestComplete = true;
  }

  getDealName() {
    this.dealNameList = null;
    this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealListForESMAReports.toString()).subscribe(result => {
      this.dealNameList = result;
    });
  }

  loadDailyCollectionData(dealName: string, asAtDate: string) {
    this.datalineItemsDistinct = null;
    this.testDatalineItems = null;
    this.distinctBrands = null;
    this.testDatalineItemsDaily = [];
    this.testDatalineItemsMonthly = [];

    console.log('Before formatting - ' + asAtDate);
    let formattedFrmDate = asAtDate ? this.datePipe.transform(asAtDate, this._requiredDateFormat) : '';
    console.log('After formatting - ' + formattedFrmDate);

    this._dailyCashEstimationService.getDailyCashEstimationData(dealName, formattedFrmDate).subscribe(data => {
      JSON.stringify(data)
      this.testDatalineItems = data;

      //Get the distinct Brands 
      if (this.testDatalineItems != null)
        this.distinctBrands = this.testDatalineItems.map(item => item.brandName)
          .filter((value, index, self) => self.indexOf(value) === index);

      this.distinctBrands.sort((n1, n2) => {
        if (n1 > n2) {
          return 1;
        }
        if (n1 < n2) {
          return -1;
        }
        return 0;
      });
    }, (error: any) => {
      console.log(error);
    });

    this._dailyCashEstimationService.getCashEstimationDistinct(dealName, formattedFrmDate).subscribe(data => {
      JSON.stringify(data)
      this.datalineItemsDistinct = data;

      if (this.datalineItemsDistinct != null) {
        // Get Daily List 
        this.testDatalineItemsDaily = this.datalineItemsDistinct.filter(x => x.estimationType == 'Daily');
        // Get Monthly List 
        this.testDatalineItemsMonthly = this.datalineItemsDistinct.filter(x => x.estimationType == 'Monthly');
        this.setFormArray();
      }

    }, (error: any) => {
      console.log(error);
    });
  }

  onDealDropDownChange(event: any) {
    if (event) {
      this.dealId = event.key;
      this.dealName = event.value;

      this.resetPreviousWork = true;
      this.collectionEndDate = null;
      this.collectionDT = null;
      this.datalineItemsDistinct = null;
      this.testDatalineItems = null;
      this.distinctBrands = null;
      this.testDatalineItemsDaily = [];
      this.testDatalineItemsMonthly = [];
    }
  }

  returnData(amountType: string, lineItem: string, brand: string) {
    this.dailyCashMethod = null;

    if (brand != null)
      this.dailyCashMethod = this.testDatalineItems.filter(x => x.lineItem == lineItem && x.brandName == brand);

    if (this.dailyCashMethod != null) {
      if (amountType == 'principal') {
        if (this.dailyCashMethod[0].principal != null)
          if (parseInt(this.dailyCashMethod[0].principal) > 0 || parseInt(this.dailyCashMethod[0].principal) < 0)
            return this._decimalPipe.transform(this.dailyCashMethod[0].principal, '1.2-2');
      }
      else if (amountType == 'revenue') {
        if (this.dailyCashMethod[0].revenue != null)
          if (parseInt(this.dailyCashMethod[0].revenue) > 0 || parseInt(this.dailyCashMethod[0].revenue) < 0)
            return this._decimalPipe.transform(this.dailyCashMethod[0].revenue, '1.2-2');
      }
      else if (amountType == 'total') {
        if (this.dailyCashMethod[0].total != null)
          if (parseInt(this.dailyCashMethod[0].total) > 0 || parseInt(this.dailyCashMethod[0].total) < 0)
            return this._decimalPipe.transform(this.dailyCashMethod[0].total, '1.2-2');
      }
      else {
        return '';
      }
    }
    return '';
  }

  setVintageDate(adviceDate: Date) {
    this.collectionEndDate = null;
    this.collectionDT = null;

    if (this.dealName === undefined || this.dealName == null || this.dealName == "") {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNameValidationMessage);
    }
    else {
      const formattedAdviceDate = this.formatDate(adviceDate);
      this._dailyCashEstimationService.getCollectionDate(this.dealName, formattedAdviceDate).subscribe(data => {
        this.collectionEndDate = this.formatDate(data);
        this.collectionDT = this.datePipe.transform(this.collectionEndDate, 'dd/MM/yyyy');
      }, (error: any) => {
        console.log(error);
      });
    }
  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  getMaxNoticeDate() {
    return new Date(this.currentDate);
  }

  generateDailyCashEstimationExcel() {
    this.isDataRequestComplete = false;
    if (this.collectionEstimationForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._collectionEstimationValidationMessage);
      Object.keys(this.collectionEstimationForm.form.controls).forEach((key) => {
        this.collectionEstimationForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    }
    else {
      if (this.dealName === undefined || this.dealName == null || this.dealName == "" || this.collectionEndDate === undefined || this.collectionEndDate === null) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else {
        this._dailyCashEstimationService.getCashEstimationExcel(this.dealName, this.collectionEndDate).subscribe(data => {
          let FileName = "DailyCashEstimation-" + this.dealName + "-" + this.collectionEndDate + ".xlsx";
          var blob = new Blob([this.s2ab(atob(data))], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
          });

          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = FileName;

          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          this.isDataRequestComplete = true;
        }, (error: any) => {
          console.log(error);
        });
      }
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  returnEmptyDate(DateValue: string) {
    if (DateValue == '0001-01-01T00:00:00')
      return ''
    else
      return DateValue;
  }

  expandDailyParentLineItem(isExpandable: boolean, isParent: number) {
    let data = this.testDatalineItemsDaily.filter(x => x.isParent == 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
    });

    data = this.testDatalineItemsDaily.filter(x => x.isParent == 2);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
    });
  }

  expandMonthlyParentLineItem(isExpandable: boolean, isParent: number) {
    let data = this.testDatalineItemsMonthly.filter(x => x.isParent == 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
    });

    data = this.testDatalineItemsMonthly.filter(x => x.isParent == 2);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
    });
  }

  setFormArray() {
    this.testDatalineItemsDaily.forEach(x => {
      x.isRowVisible = !(x.isParent == 0) ? true : false
    });

    this.testDatalineItemsMonthly.forEach(x => {
      x.isRowVisible = !(x.isParent == 0) ? true : false
    });
  }

  cashEstimationShow() {
    if (this.collectionEstimationForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._collectionEstimationValidationMessage);
      Object.keys(this.collectionEstimationForm.form.controls).forEach((key) => {
        this.collectionEstimationForm.form.get(key).markAsTouched();
      });
      return false;
    }
    else {
      if (this.dealName === undefined || this.dealName == null || this.dealName == "" || this.collectionEndDate === undefined || this.collectionEndDate == null) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else {
        this.loadDailyCollectionData(this.dealName, this.collectionEndDate);
      }
    }
  }
}