import { DecimalPipe } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DealSummaryOutputService } from 'src/app/cash-waterfall/service/deal-summary-output.service';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { DealSummaryDataModel, DealSummarySaveAdjustmentModel, DailyCollectionDealSummaryModel, DealsumOutputsModel } from '../../../model/dealsum-outputs.model';

@Component({
  selector: 'sfp-dealsum-adjustments',
  templateUrl: './dealsum-adjustments.component.html',
  styleUrls: ['./dealsum-adjustments.component.scss'],
  providers: [KeyValueLookupService, DealSummaryOutputService, DecimalPipe]
})
export class DealsumAdjustmentsComponent implements OnChanges {
  @ViewChild('dealSummaryAdjustmentSave') dealSummaryAdjustmentSave: any;

  @Input() dealName: string;

  @Input() adviceDate: string

  @Input() adviceDateListDatesData: Array<string> = [];

  @Input() collectionAllStartDataList: DailyCollectionDealSummaryModel;

  @Input() isOtherComponentBind: boolean;

  @Input() isDataRequestComplete: boolean

  public title: string = 'Deal Summary Adjustment'

  public collectionAllNewStartDataList: DailyCollectionDealSummaryModel;

  public savedErrorMessage: string = 'Please enter some value to save Adjustment'

  public adjustmentCommentErrorMessage: string = 'Deal Summary Adjustment comment is required';

  public titleDealSumAdjustmentOutput = 'Deal Summary Output';
  public dealsumAdjustmentList: Array<DealsumOutputsModel> = [];
  public dealsumAdjustmentDates: Array<Date> = [];
  public dealsumAdjustmentLineItem: Array<string> = [];
  public dealSummaryDataModel: DealSummaryDataModel;

  public dealsumCommonItemList: Array<DealsumOutputsModel> = [];


  public dealCategoryName: string;
  public dealSummaryAdjustmentDataModel: DealSummaryDataModel;

  public dealSummarySaveAdjustmentModel: DealSummarySaveAdjustmentModel;

  @Input() dealsummaryAdjustmentItemsList: Array<DealsumOutputsModel>;

  @Output() notifyOutputRefreshData = new EventEmitter<boolean>();



  public isAdjustmentUpdated: boolean = false;

  @Input() permissionList: Array<boolean>;

  public dealsummaryTempAdjustmentItemsList: Array<DealsumOutputsModel> = [];

  public dealsummaryUpdateAdjustmentItemsList: Array<DealsumOutputsModel> = [];

  public dailyCollectionDealSummaryModel: DailyCollectionDealSummaryModel;

  public dealSummarySaveAdjustmentList: Array<DealSummarySaveAdjustmentModel> = [];


  public dealsumAdjustmentListItem: Array<DealsumOutputsModel> = [];
  public canUpdate: boolean = false;
  public allowEditAdjustment : boolean = false;

  constructor(
    private _lookupService: KeyValueLookupService,
    public _dealSummaryOutputService: DealSummaryOutputService,
    private _modalService: NgbModal,
    private _toastservice: GlobalToasterService,
    private _decimalPipe: DecimalPipe
  ) {
  }

  ngOnChanges() {
 
    this.canUpdate = this.permissionList[5];
    this.dealSummaryDataModel = new DealSummaryDataModel();
    this.dealSummarySaveAdjustmentModel = new DealSummarySaveAdjustmentModel();

    this.dailyCollectionDealSummaryModel = new DailyCollectionDealSummaryModel();
    if (this.collectionAllStartDataList != undefined) {
      this.dailyCollectionDealSummaryModel.stepName = this.collectionAllStartDataList.stepName;
      this.dailyCollectionDealSummaryModel.collectionDate = this.collectionAllStartDataList.collectionDate;
    }

    if ((this.dealName != null && this.dealName != "") && this.isOtherComponentBind
      && this.dealsummaryAdjustmentItemsList.length > 0) {

      this.getDealSummaryAdjustmentModelData();
      this.getDealSummaryAdjustmentUpdatedModelData();
    }


  }

  getDealSummaryAdjustmentModelData() {
    this.dealsumAdjustmentListItem = [];
    this.dealsummaryTempAdjustmentItemsList = [];

    //this.isAdjustmentUpdated =false;

    this.dealsummaryAdjustmentItemsList.forEach(obj => this.dealsummaryTempAdjustmentItemsList.push(Object.assign({}, obj)));

    this.dealsumAdjustmentLineItem = this.dealsummaryAdjustmentItemsList.map(s => s.lineItem)
      .filter((value, index, self) => self.indexOf(value) == index);
    


    this.dealsumAdjustmentDates = this.dealsummaryAdjustmentItemsList.map(s => s.collectionDate)
      .filter((value, index, self) => self.indexOf(value) == index);
    

    this.dealsumAdjustmentListItem = this.dealsummaryAdjustmentItemsList.filter(s => s.collectionDate == this.dealsumAdjustmentDates[0])
    

    this.getDailyAdjustmentCollectionDealSummary(this.adviceDateListDatesData[0]);


  }

  getDealSumAdjustmentDataValue(collectionDate: Date, lineItem: string) {

    let Adjustmentvalue = this.dealsummaryAdjustmentItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.adjustmentValue);
    if (Adjustmentvalue != null) {
      let value = Adjustmentvalue[0] != null && Adjustmentvalue[0] != 0.00 ? Adjustmentvalue[0] : 0.00;
      return value; //this._decimalPipe.transform(value, '1.2-2'); 
    }
  }

  getDealSumAdjustmentCommentValue(collectionDate: Date, lineItem: string) {
    let value = this.dealsummaryAdjustmentItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.comments);
    if (value != null) {
      return value[0];
    }
  }

  getDealSumAdjustmentModifiedByValue(collectionDate: Date, lineItem: string) {
    let value = this.dealsummaryAdjustmentItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.modifiedBy);
    if (value != null) {
      return value[0];
    }
  }


  onDealSumAdjustmentSavePopUpModel() {
    this.dealSummarySaveAdjustmentModel.comments = "";
    this.dealsummaryUpdateAdjustmentItemsList = this.dealsummaryTempAdjustmentItemsList.filter(m => m.collectionDate == this.dealsumAdjustmentDates[0])
    let Modifiedresult = this.dealsummaryAdjustmentItemsList.filter(m => m.collectionDate == this.dealsumAdjustmentDates[0])
      .filter(o1 => !this.dealsummaryUpdateAdjustmentItemsList.filter(m1 => m1.dailyCollectionLineItemId == o1.dailyCollectionLineItemId).some(o2 => +o1.adjustmentValue === +o2.adjustmentValue));
    console.log(this.dealsummaryAdjustmentItemsList.filter(m => m.collectionDate == this.dealsumAdjustmentDates[0]))
    console.log(this.dealsummaryUpdateAdjustmentItemsList)
    console.log(Modifiedresult)
    if (Modifiedresult.length > 0) {
      this._modalService.open(this.dealSummaryAdjustmentSave,
        { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
          if (result.toLowerCase() === 'approved') {
          } else if (result.toLowerCase() === 'reject') {
          } else {
            console.log('Collapse');
          }
        });
    }
    else {
      this._toastservice.openToast(ToasterTypes.error, this.title, this.savedErrorMessage);
      return false;

    }
  }


  makeEditableAdjustmentModel(comment: string) {

    this.dealSummarySaveAdjustmentList = [];
    console.log(this.dealsummaryAdjustmentItemsList.filter(m => m.collectionDate == this.dealsumAdjustmentDates[0]))
    console.log(this.dealsummaryUpdateAdjustmentItemsList)
    let result = this.dealsummaryAdjustmentItemsList.filter(m => m.collectionDate == this.dealsumAdjustmentDates[0])
      .filter(o1 => !this.dealsummaryUpdateAdjustmentItemsList.filter(m1 => m1.dailyCollectionLineItemId == o1.dailyCollectionLineItemId).some(o2 => +o1.adjustmentValue === +o2.adjustmentValue));
    if (this.collectionAllStartDataList.stepName != 'Authorise') {
      console.log(this.dealsumAdjustmentListItem);
      this.dealsumAdjustmentListItem.forEach(x => {

        result.forEach(item => {

          if (item.dailyCollectionLineItemId == x.dailyCollectionLineItemId) {
            this.dealSummarySaveAdjustmentList.push(
              {
                'dailyCollectionSummaryId': x.dailyCollectionSummaryId,
                'ModifiedBy': x.modifiedBy,
                'dailyCollectionLineItemId': x.dailyCollectionLineItemId,
                'value': x.adjustmentValue.toString(),
                'comments': comment
              }
            );
          }

        });
      });
    }
  }


  onDealSumAdjustmentSaveData(comment: string, savedMessage: string, irComment1: NgModel, modal: NgbActiveModal) {
    irComment1.control.markAsTouched();
    if (irComment1.control.status == "INVALID") {
      this._toastservice.openToast(ToasterTypes.error, this.title, this.adjustmentCommentErrorMessage);
    }
    else {

      this.makeEditableAdjustmentModel(comment)
      console.log(this.dealSummarySaveAdjustmentList);
      this._dealSummaryOutputService.saveDealSummaryAdjustmentData(this.dealSummarySaveAdjustmentList).subscribe(result => {
        if (result === 1) {
          this._toastservice.openToast(ToasterTypes.success, this.title, savedMessage);
          this.getDealSummaryAdjustmentUpdatedModelData();

        }
        else if (result === 0) {
          this._toastservice.openToast(ToasterTypes.error, this.title, savedMessage);
        }
        else {
          this._toastservice.openToast(ToasterTypes.error, this.title, savedMessage);
        }
      });
      modal.close('cancel');
    }



  }

  getDealSummaryAdjustmentUpdatedModelData() {
    this.dealSummaryAdjustmentDataModel = new DealSummaryDataModel();
    this.dealSummaryAdjustmentDataModel.adviceDate = this.adviceDateListDatesData;
    this.dealSummaryAdjustmentDataModel.dealName = this.dealName;
    this.dealSummaryAdjustmentDataModel.dealCategoryName = 'Deal Summary - Adjustments';
      this.dealSummaryAdjustmentDataModel.viewType ='';

    this.dealsummaryAdjustmentItemsList = [];
    this.dealsummaryTempAdjustmentItemsList = [];

    //this.isAdjustmentUpdated =false;

    this._dealSummaryOutputService.getDealSummaryOutputData(this.dealSummaryAdjustmentDataModel).subscribe(result => {
      this.dealsummaryAdjustmentItemsList = result;

      this.dealsummaryAdjustmentItemsList.forEach(item => {
        item.adjustmentValue = +item.value
      });

      this.dealsumAdjustmentListItem = this.dealsummaryAdjustmentItemsList.filter(s => s.collectionDate == this.dealsumAdjustmentDates[0])
     
      this.dealsummaryAdjustmentItemsList.forEach(obj => this.dealsummaryTempAdjustmentItemsList.push(Object.assign({}, obj)));

      this.dealsummaryTempAdjustmentItemsList.forEach(item => {
        item.adjustmentValue = +item.value
      });
      this.isAdjustmentUpdated = true;
      this.notifyOutputRefreshData.emit(this.isAdjustmentUpdated);
    });
    this.getDailyAdjustmentCollectionDealSummary(this.adviceDateListDatesData[0]);

  }


  getDailyAdjustmentCollectionDealSummary(formattedAdviceDate: string) {
    this._dealSummaryOutputService.getDailyCollectionDealSummary(formattedAdviceDate, this.dealName).subscribe(data => {
      this.collectionAllNewStartDataList = data;
      console.log(this.collectionAllNewStartDataList);
      if (this.collectionAllNewStartDataList != undefined) {
        if (this.collectionAllNewStartDataList.workflowStepId != null && this.collectionAllNewStartDataList.workflowStepId > 0) {
          this.dailyCollectionDealSummaryModel.stepName = this.collectionAllNewStartDataList.stepName;
        }
        
        if(this.dealsumAdjustmentDates[0] == this.collectionAllNewStartDataList.dealSummaryMaxCollectionDate){
          this.allowEditAdjustment = true;
        }
      }

    }, (error: any) => {
      console.log(error);
    });

  }

}
