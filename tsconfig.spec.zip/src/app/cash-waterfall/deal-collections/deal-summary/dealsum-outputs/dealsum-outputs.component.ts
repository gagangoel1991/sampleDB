import { DatePipe, DecimalPipe } from '@angular/common';
import { ConditionalExpr } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { NgbDate, NgbDatepicker, NgbDateStruct, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { objectWithoutKey } from 'angular-slickgrid';
import { Object } from 'core-js';
import { DailyCollectionDatesExcel, DailyCollectionDealSummaryModel, DealSumEstimationHoverModel, DealSummaryDataModel, DealsumOutputsModel } from 'src/app/cash-waterfall/model/dealsum-outputs.model';
import { DealCollectionsService } from 'src/app/cash-waterfall/service/deal-collections.service';
import { DealSummaryOutputService } from 'src/app/cash-waterfall/service/deal-summary-output.service';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { DealsumAdjustmentsComponent } from '../dealsum-adjustments/dealsum-adjustments.component';
import { DealsumControlchecksandbalanceComponent } from '../dealsum-controlchecksandbalance/dealsum-controlchecksandbalance.component';




@Component({
  selector: 'sfp-dealsum-outputs',
  templateUrl: './dealsum-outputs.component.html',
  styleUrls: ['./dealsum-outputs.component.scss'],
  providers: [KeyValueLookupService, DealSummaryOutputService, DealCollectionsService, DecimalPipe]
})
export class DealsumOutputsComponent implements OnInit {
  @ViewChild('dealsumOutputForm') dealsumOutputForm: NgForm;
  @ViewChild('DealSummaryCollectionsHeadForm') DealSummaryCollectionsHeadForm: NgForm;
  @ViewChild(DealsumControlchecksandbalanceComponent) controlcheckChild: DealsumControlchecksandbalanceComponent;
  @ViewChild('loadActualGMSData') loadActualGMSData: any;
  @ViewChild('loadActualEstimationData') loadActualEstimationData: any;
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'Deal Summary';
  public titleDealSumOutput = 'Collection Output';
  public accuralStartDate: string;
  public accuralEndDate: string;
  public currentDate = new Date();
  public dealName: string;
  public dealCategoryName: string;
  public dealSummaryDataModel: DealSummaryDataModel;
  public isDataSubmitDealSummary: boolean = false;
  public formattedAdviceDate: string;

  public isDataRequestComplete: boolean = false;
  public isDataRequestOutputSegComplete: boolean = false;
  public isDataRequestCompleteExcel: boolean = false;
  public excelButtonLoadingText: string;
  collectionDT: string = null;

  public collectionDiffDate: string = null;
  public adviceDate: string;
  public ipdDateHeaders: Array<string> = [];


  public exportExcelUtility = new ExportExcelUtility();
  public dealsumOutputsList: Array<DealsumOutputsModel> = [];
  public dealsumOutputsDates: Array<Date> = [];
  public dealsumOutputsLineItemList: Array<DealsumOutputsModel> = [];
  public dealsumOutputsDistinctLineItem: Array<string> = [];
  public dealsumCommonItemList: Array<DealsumOutputsModel> = [];
  public dealsumCommonLineItem: Array<string> = [];
  public dealsumOutLineItemDates: Array<Date> = [];
  private readonly _formatDate = 'dd/MM/yyyy';
  private readonly _dateFormat = 'yyyy-MM-dd';
  private readonly _invalidDate = 'Invalid date';
  public dealNameList: Array<KeyValueLookupModel> = [];
  public getDealAdviceDateList: Array<string> = []

  public dealsummaryOutputItemsList: Array<DealsumOutputsModel> = [];
  public dealsummaryTempOutputItemsList: Array<DealsumOutputsModel> = [];
  vintageDate: string = null;
  public collectionEndDateList: Array<string> = [];
  public collectionEndFinalDateList: Array<string> = [];
  public adviceDateListData: Array<string> = []

  public dailyEstimationLatestItemsList: Array<number> = [];

  public adviceDateListDates: Array<string> = []
  public adviceDateListDatesData: Array<string> = [];

  public adviceDatesListDatesData: Array<string> = [];

  public collectionDateListDatesData: Array<string> = [];

  public isDailyEstimationDataRefresh: Array<boolean> = [];

  public datesSelected: NgbDateStruct[] = [];
  public collectionAllStartDataList: DailyCollectionDealSummaryModel;

  public dealsummaryAdjustmentItemsList: Array<DealsumOutputsModel> = [];

  public dealsummaryOutputsItemsList: Array<DealsumOutputsModel> = [];

  public dealsummaryDeflagBreakupItemsList: Array<DealsumOutputsModel> = [];

  public dealsummaryControlCheckBalanceItemsList: Array<DealsumOutputsModel> = [];

  public isDailyEstimationData : boolean =false;

  public isLoadDailyEstimationButtonData : boolean =true;

  public isActualGMSDataLoad : boolean =false;

  private _datePicker: NgbDatepicker;

  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  public loggedInUser: string;
  public canUpdate: boolean = false;
  public canView: boolean = false;
  public canDelete: boolean = false;
  public canAuthorized: boolean = false;
  public permissionList: Array<boolean> = [];
  public isMultiDeatPickerChecked: boolean = false;
  public isOtherComponentBind: boolean = false;
  public ngdatesSelected: Array<NgbDate> = [];
  public indexcount: number = 0;

  public dealsummaryOutputItemsListActualData: Array<DealsumOutputsModel> = [];
  public dealSumEstimationHoverData : Array<DealSumEstimationHoverModel> =[]

  public dailyCollectionDatesExcel: DailyCollectionDatesExcel;
  public resetPreviousWork: boolean = false;
  public isControlCheckRefreshRequired :boolean = false;
  public isEstimationData : boolean = false;

  private readonly _adviceDateValidationMessage = 'Please select advice date.';
  private readonly _dealNameValidationMessage = 'Please select deal name.';
  private readonly _dailySummaryValidationMessage = 'Please fill/select required fields marked with asterisk(*) before showing the data.';
  private readonly _numberOfDayValidationMessage = 'Upto 5 date can be select.';
  private readonly _noDateAvialbleValidationMessage = 'No Data is available for this date range';
  private readonly _actualDataValidationErrorMsg = 'Actual GMS Data is not available.Please check after some time.';



  constructor(
    private _lookupService: KeyValueLookupService,
    public _dealSummaryOutputService: DealSummaryOutputService,
    private _userRoleService: UserRoleService,
    private _toastservice: GlobalToasterService,
    private _dailyCashEstimationService: DealCollectionsService,
    private _decimalPipe: DecimalPipe,
    private _modalService: NgbModal
  ) {
  }

  ngOnInit(): void {

    this.getDealName();
    this.dealCategoryName = '';

    this.permissionList = [];
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.View);
    this.permissionList.push(this.isReadOnlyAccess);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.AddEdit);
    this.permissionList.push(this.isAddEditAccess);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.ApproveReject);
    this.permissionList.push(this.isApprovRejectAccess);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.Delete);
    this.permissionList.push(this.isDeleteAccess);
    this.canView = this._userRoleService.getPermissionAccess(PermissionEnum.CW_DealCollection, PermissionAccessTypeEnum.View);
    this.permissionList.push(this.canView);
    this.canUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.CW_DealCollection, PermissionAccessTypeEnum.AddEdit);
    this.permissionList.push(this.canUpdate);
    this.canDelete = this._userRoleService.getPermissionAccess(PermissionEnum.CW_DealCollection, PermissionAccessTypeEnum.Delete);
    this.permissionList.push(this.canDelete);
    this.canAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.CW_DealCollection, PermissionAccessTypeEnum.ApproveReject);
    this.permissionList.push(this.canAuthorized);

    this.collectionAllStartDataList = new DailyCollectionDealSummaryModel();
    this.dealsumOutputsDates = this.dealsumOutputsList.map(s => s.collectionDate)
      .filter((value, index, self) => self.indexOf(value) == index);
    this.dealsumCommonLineItem = ['adviceDate', 'collectionDate'];
    this.dealsumOutLineItemDates = this.dealsummaryOutputItemsList.map(s => s.collectionDate)
      .filter((value, index, self) => self.indexOf(value) == index);
  }

  notifyOutputLoaderDataHandler(setLoader: boolean) {
    this.isDataRequestComplete = setLoader;
   
  }


  notifyOutputRefreshDataHandler(isAdjustmentUpdated: boolean) {    
    if (isAdjustmentUpdated == true) {
      
      this.dealSummaryDataModel = new DealSummaryDataModel();
      this.dealSummaryDataModel.adviceDate = this.adviceDateListDatesData;
      this.dealSummaryDataModel.dealName = this.dealName;
      this.dealSummaryDataModel.dealCategoryName = this.dealCategoryName;
      this.dealSummaryDataModel.viewType ='';
      this.isDataRequestOutputSegComplete = true;
      this._dealSummaryOutputService.getDealSummaryOutputData(this.dealSummaryDataModel).subscribe(result => {

        this.dealsummaryOutputItemsList = result;
        this.dealsummaryOutputsItemsList = this.dealsummaryOutputItemsList.filter(s => s.dailyCollectionCategory == 'Deal Summary - Output')
        this.dealsumOutputsLineItemList = this.dealsummaryOutputsItemsList.filter((value, index, self) => self.indexOf(value) == index)

        this.dealsumOutputsLineItemList = this.dealsumOutputsLineItemList.filter(s => s.lineItem == this.dealsumOutputsDistinctLineItem[0]);
        console.log(this.dealsumOutputsLineItemList);
        console.log(this.dealsummaryOutputsItemsList)
        this.controlcheckChild.notifyControlCheckRefreshDataHandler();
        this.isDataRequestOutputSegComplete = false;

      });
    
    }

  }

  getMultipleDates(value: NgbDate) {
    let i: number = 0;

    let isExist = this.ngdatesSelected.some(o => o.day === value.day && o.month === value.month && o.year === value.year);
    if (!isExist) {
      if (this.ngdatesSelected.length < 5) {
        this.ngdatesSelected.push(value);
        this.getMultipleDateValues(this.ngdatesSelected);
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._numberOfDayValidationMessage);
      }
    }

  }

  removeDate(index): void {
    this.adviceDateListData.splice(index, 1);
    this.adviceDateListDates = [];
    let itemdate;
    this.ngdatesSelected.splice(index, 1);
    this.ngdatesSelected.forEach(item => {
      itemdate = new Date(item.year, item.month - 1, item.day);
      console.log(itemdate);
      this.adviceDateListDates.push(itemdate);

    });
    this.indexcount = this.indexcount + 1;
    
  }

  getMultipleDateValues(value: NgbDateStruct[]) {

    let jsDate;
    this.adviceDateListDatesData = [];
    this.adviceDateListData = [];
    this.adviceDateListDates = [];
    
    value.forEach((item, i: number = 0) => {
      jsDate = new Date(item.year, item.month - 1, item.day);
      this.vintageDate = null;
      this.vintageDate = jsDate ? this.datePipe.transform(jsDate, 'dd/MM/yyyy') : '';
      this.adviceDateListData.push(this.vintageDate);
      this.adviceDateListDates.push(jsDate);
     
      i++;

    });



  }


  setVintageDate(adviceDate: Date) {
    this.collectionEndDateList = [];
    this.adviceDate = "";
    this.isOtherComponentBind = false;
    this.formattedAdviceDate = "";
    if (this.isMultiDeatPickerChecked) {
      this.getMultipleDates(new NgbDate(adviceDate.getFullYear(), adviceDate.getMonth() + 1, adviceDate.getDate()));
    }
    else {
      this.adviceDate = this.formatDate(adviceDate);
      this.collectionDT = null;
      this.formattedAdviceDate = this.formatDate(adviceDate);
   

    }
  }

  getMaxNoticeDate() {
    return new Date(this.currentDate);
  }

  onDealDropDownChange(event: any) {
    if (event) {
      this.dealId = event.key;
      this.dealName = event.value;

      this.resetPreviousWork = true;
      this.isMultiDeatPickerChecked = false;
      this.adviceDateListData = [];
      this.ngdatesSelected = [];
      this.formattedAdviceDate = null;
    }
    this.isOtherComponentBind = false;

  }

  getDealSummaryAllDataView() {

    if (this.dealName === undefined || this.dealName == null || this.dealName == '') {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dailySummaryValidationMessage);
      Object.keys(this.DealSummaryCollectionsHeadForm.form.controls).forEach((key) => {
        this.DealSummaryCollectionsHeadForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = false;
      return false;
    }
    else {

      if (((this.formattedAdviceDate === undefined || this.formattedAdviceDate == null || this.formattedAdviceDate == '')
        && !this.isMultiDeatPickerChecked) || (this.isMultiDeatPickerChecked && this.ngdatesSelected.length < 1)) {
        this.isDataRequestComplete = false;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else {

        this.isActualGMSDataLoad= false;
        this.isDataSubmitDealSummary = true;
        this.isOtherComponentBind = false;
        this.dealsummaryOutputItemsList = [];
        this.adviceDateListDatesData = [];
       
        if (this.isMultiDeatPickerChecked) {

          this.adviceDateListDates.sort((val1, val2) => { return +new Date(val2) - +new Date(val1) });
          this.adviceDateListDates.filter((value, index, self) => self.indexOf(value) == index);
         
          this.adviceDateListDates.forEach(item => {
            let itemDates = item ? this.datePipe.transform(item, 'dd-MMM-yyyy') : '';
            this.adviceDateListDatesData.push(itemDates);

          });
        

          if (this.adviceDateListDatesData.length > 0) {
            this.isDataRequestComplete = true;
          }
          this.dealSummaryDataModel = new DealSummaryDataModel();
          this.dealSummaryDataModel.adviceDate = this.adviceDateListDatesData;
          this.dealSummaryDataModel.dealName = this.dealName;
          this.dealSummaryDataModel.dealCategoryName = this.dealCategoryName;
          this.dealSummaryDataModel.viewType ='';
          this.getDealSummaryOutputMultipleDatesData(this.dealSummaryDataModel);


        }
        else {
          this.getDealSummaryOutputModelData();
          console.log(this.isDataRequestComplete)
        }



      }

    }


  }

  getDealSummaryOutputModelData() {
    this.getAdviceandCollectionListData(this.formattedAdviceDate);
  }

  getDealName() {
    this.dealNameList = null;
    this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealListForESMAReports.toString()).subscribe(result => {
      this.dealNameList = result;
      // this.showHideLoadingImage(false);
    });
  }

  getDealSummaryOutputMultipleDatesData(dealSummaryDataModel: DealSummaryDataModel) {
    this.dealsummaryOutputItemsList = [];
    this.dealsummaryOutputsItemsList = [];
    this._dealSummaryOutputService.getDealSummaryOutputData(dealSummaryDataModel).subscribe(result => {
      this.dealsummaryOutputItemsList = result;
     
      if (this.dealsummaryOutputItemsList.length > 0) {
        this.isDataRequestComplete = true;
        this.dealsummaryOutputsItemsList = this.dealsummaryOutputItemsList.filter(s => s.dailyCollectionCategory == 'Deal Summary - Output')
       
        this.dealsummaryOutputItemsList.forEach(obj => this.dealsummaryTempOutputItemsList.push(Object.assign({}, obj)));

        this.dealsumOutputsDistinctLineItem = this.dealsummaryOutputsItemsList.map(s => s.lineItem)
          .filter((value, index, self) => self.indexOf(value) == index);
        this.dealsumOutputsLineItemList = this.dealsummaryOutputsItemsList
          .filter((value, index, self) => self.indexOf(value) == index)

        this.dealsumOutputsLineItemList = this.dealsumOutputsLineItemList
          .filter(s => s.lineItem == this.dealsumOutputsDistinctLineItem[0]);
        

        this.dealsumOutLineItemDates = this.dealsummaryOutputsItemsList.map(s => s.collectionDate)
          .filter((value, index, self) => self.indexOf(value) == index);
      
        this.dailyEstimationLatestItemsList = this.dealsummaryOutputsItemsList.filter(s => this.dealsumOutLineItemDates[0] && s.dailyCollectionSummaryId==0)
                                              .map( s => s.dailyCollectionSummaryId);
        let i : number =0;
        this.dailyEstimationLatestItemsList.forEach(x => 
          {            
            if(x == 0)
            {
              i++;              
            }
          });
         
          if(i>0)
          {
            debugger;
            //this.isDailyEstimationData =true;
            this.isLoadDailyEstimationButtonData = false;
            
          }
          else{
           // this.isDailyEstimationData =false;
           this.isLoadDailyEstimationButtonData = true;
          }
        


        this.dealsummaryAdjustmentItemsList = this.dealsummaryOutputItemsList.filter(s => s.dailyCollectionCategory == 'Deal Summary - Adjustments');
       
        this.dealsummaryDeflagBreakupItemsList = this.dealsummaryOutputItemsList.filter(s => s.dailyCollectionCategory == 'Deal Summary - DeflagBreakup');
       
        this.dealsummaryControlCheckBalanceItemsList = this.dealsummaryOutputItemsList.filter(s => s.dailyCollectionCategory == "Deal Summary - ControlCheck");
        
        this.isOtherComponentBind = true;
        if (this.isMultiDeatPickerChecked) {
          this.collectionDateListDatesData = [];

          this.dealsumOutLineItemDates.forEach(item => {
            let itemDates = item ? this.datePipe.transform(item, 'dd-MMM-yyyy') : '';
            this.collectionDateListDatesData.push(itemDates);
          });

          this.formattedAdviceDate = this.adviceDateListDatesData[0];
         

        }
        this.getDailyCollectionDealSummaryData();
        this.isLoadDataEstimationRefresh();
        if (this.isMultiDeatPickerChecked) {
          this.formattedAdviceDate = "";
        }
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._noDateAvialbleValidationMessage);
        this.isDataRequestComplete = false;
        this.isOtherComponentBind = false;
      }

    });
  }

  getAdviceandCollectionListData(formattedAdviceDate: string) {
    if (this.dealName === undefined || this.dealName == null || this.dealName == "") {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNameValidationMessage);
    }
    else {
      this._dealSummaryOutputService.getCollectionDateList(this.dealName, formattedAdviceDate).subscribe(data => {
       
        this.collectionEndDateList = [];
        this.collectionDateListDatesData = [];
        this.adviceDateListDatesData = [];
        this.adviceDatesListDatesData = [];
        this.collectionEndDateList = data.adviceDates;
        this.collectionDateListDatesData = data.collectionDates;
       
        this.collectionEndDateList.forEach(item => {
          let itemDates = item ? this.datePipe.transform(item, 'dd-MMM-yyyy') : '';
          this.adviceDatesListDatesData.push(itemDates);
        });
        
        this.adviceDateListDatesData = this.adviceDatesListDatesData;
     

        this.isLoadDataEstimationRefresh();

        this.dealSummaryDataModel = new DealSummaryDataModel();
        this.dealSummaryDataModel.adviceDate = this.adviceDateListDatesData;
        this.dealSummaryDataModel.dealName = this.dealName;
        this.dealSummaryDataModel.dealCategoryName = this.dealCategoryName;
        this.dealSummaryDataModel.viewType ='';
        this.getDealSummaryOutputMultipleDatesData(this.dealSummaryDataModel);
        



      }, (error: any) => {
        console.log(error);


      });

    }
  }

  getDailyCollectionDealSummaryData() {
    console.log('formattedAdviceDate ' + this.formattedAdviceDate);
    this._dealSummaryOutputService.getDailyCollectionDealSummary(this.formattedAdviceDate, this.dealName).subscribe(data => {
      this.collectionAllStartDataList = data;

      console.log(this.collectionAllStartDataList);
      let latestCollectionMaxDate = (this.collectionAllStartDataList != undefined ? this.datePipe.transform(this.collectionAllStartDataList.dealSummaryMaxCollectionDate, 'dd-MMM-yyyy') : '');
      let latestCollectionDate = (this.collectionDateListDatesData[0] !=null ? this.datePipe.transform(this.collectionDateListDatesData[0], 'dd-MMM-yyyy') : '');
            console.log(latestCollectionMaxDate)
            console.log(latestCollectionDate)
            if(latestCollectionMaxDate !="")
            {
              if( latestCollectionDate == latestCollectionMaxDate){
              this.isActualGMSDataLoad= true;
              }
            }
      
    }, (error: any) => {
      console.log(error);
    });

  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealCollection], PermissionAccessTypeEnum.Delete);

  }

  checkAuthorisationStatus(dealId: number) {
    this.setUpUserRolesAndPermissions();
  }


  getDealSumOutputDataValue(collectionDate: Date, lineItem: string, dealId: number) {
    let lineItemValue = this.dealsummaryOutputItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem 
          && obj.dealId == dealId && obj.dailyCollectionCategory== 'Deal Summary - Output')
      .map(obj => obj.value);
    if (lineItemValue != null) {
      let value = lineItemValue[0] != null ? lineItemValue[0] : 0.00;
      return this._decimalPipe.transform(value, '1.2-2');
    }

    else {
      return "";
    }
  }

  getDealSumCommonDataValue(collectionDate: Date, lineItem: string) {
    let lineItemValue = this.dealsummaryOutputItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.value);
    if (lineItemValue != null) {
      return lineItemValue[0];
    }

    else {
      return "";
    }
  }

  generateDealSummaryCollectionExcel() {
    if (this.DealSummaryCollectionsHeadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dailySummaryValidationMessage);
      Object.keys(this.DealSummaryCollectionsHeadForm.form.controls).forEach((key) => {
        this.isDataRequestCompleteExcel = false;
        this.DealSummaryCollectionsHeadForm.form.get(key).markAsTouched();
      });
      return false;
    }
    else {
    
      this.isDataRequestCompleteExcel = true;
      this.excelButtonLoadingText = 'Loading..'
      this.dailyCollectionDatesExcel = new DailyCollectionDatesExcel();
      this.dailyCollectionDatesExcel.dealName = this.dealName;
      this.dailyCollectionDatesExcel.viewType ='';

      if (this.isMultiDeatPickerChecked) {
        this.dailyCollectionDatesExcel.AdviceDates = this.adviceDateListDatesData;
        this.dailyCollectionDatesExcel.CollectionDates = this.collectionDateListDatesData;
        this.dailyCollectionDatesExcel.adviceDate = "";
        this.dailyCollectionDatesExcel.isMultiDateList = true;
      }
      else {
        this.dailyCollectionDatesExcel.adviceDate = this.adviceDate;
        this.dailyCollectionDatesExcel.isMultiDateList = false;
      }

     
      this._dealSummaryOutputService.getDealSummaryExcel(this.dailyCollectionDatesExcel).subscribe(data => {
        let FileName = "DealSummary-" + this.dealName + "-" + this.adviceDate + ".xlsx";
        var blob = new Blob([this.s2ab(atob(data))], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
        });

        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = FileName;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        this.isDataRequestCompleteExcel = false;

      }, (error: any) => {
        console.log(error);
      });
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  onLoadEstimationData(estimationAdviceDate : Date)
  {
    this.isEstimationData =true;
    this.isDataRequestOutputSegComplete = true;
    let latestcollectionDate= this.datePipe.transform(estimationAdviceDate, 'yyyy-MM-dd');
    
    
    this._dealSummaryOutputService.getLoadDailyEstimationDealSummary(latestcollectionDate,this.dealName,this.isEstimationData).subscribe(result => {
      
        this.dealSummaryDataModel = new DealSummaryDataModel();
        this.dealSummaryDataModel.adviceDate = this.adviceDateListDatesData;
        this.dealSummaryDataModel.dealName = this.dealName;
        this.dealSummaryDataModel.dealCategoryName = 'Deal Summary - Output';
        this.dealSummaryDataModel.viewType ='';
        
        this.dealsummaryOutputItemsList=[];
        this._dealSummaryOutputService.getDealSummaryOutputData(this.dealSummaryDataModel).subscribe(data => {
          
          this.dealsummaryOutputItemsList = data;
          this.dealsumOutputsLineItemList = this.dealsummaryOutputsItemsList.filter((value, index, self) => self.indexOf(value) == index)
  
          this.dealsumOutputsLineItemList = this.dealsumOutputsLineItemList.filter(s => s.lineItem == this.dealsumOutputsDistinctLineItem[0]);
         

          this.isDataRequestOutputSegComplete = false;          
          this.isLoadDataEstimationRefresh();
          this.getDailyCollectionDealSummaryData();
        });
        this.controlcheckChild.notifyControlCheckRefreshDataHandler();
      
      });
      
      this.isLoadDailyEstimationButtonData =true;
      console.log(this.isLoadDailyEstimationButtonData);
  }


  isLoadDataEstimationRefresh()
  {
    

    this.isDailyEstimationDataRefresh=[];
    this.dealsummaryOutputItemsListActualData=[];
    this.dealSummaryDataModel = new DealSummaryDataModel();
      this.dealSummaryDataModel.adviceDate = this.collectionDateListDatesData;
      this.dealSummaryDataModel.dealName = this.dealName;
      this._dealSummaryOutputService.getDealSummaryLoadDataEstimation(this.dealSummaryDataModel).subscribe(result => {

        let i:number =0;
        this.isDailyEstimationDataRefresh = result;
        console.log(this.isDailyEstimationDataRefresh);
        this.isDailyEstimationDataRefresh.forEach( m =>
          {
            
            if(m == true)
            {           
              console.log('i' +i)
              this.getDealSumOutputGMSDataValue(i);
            }
            else
            {
              this.isActualGMSDataLoad= false;
            }

            i++;
            
        });        

      });

  }

  getDealSumOutputGMSDataValue(index : number)
  {
    this.dealSummaryDataModel = new DealSummaryDataModel();
    this.dealSummaryDataModel.adviceDate = this.adviceDateListDatesData;
    this.dealSummaryDataModel.dealName = this.dealName;
    this.dealSummaryDataModel.dealCategoryName = 'Deal Summary - Output';
    this.dealSummaryDataModel.viewType='hover';
    
    
    this.dealSumEstimationHoverData =[];
    if(this.isDailyEstimationDataRefresh[index] == true)
    {
      this._dealSummaryOutputService.getDealSummaryOutputData(this.dealSummaryDataModel).subscribe(data => {
        
        this.dealsummaryOutputItemsListActualData = data;
        console.log(this.dealsummaryOutputItemsListActualData)
        this.dealsummaryOutputItemsListActualData = this.dealsummaryOutputItemsListActualData.filter(s => s.collectionDate.toString() == this.collectionDateListDatesData[index]);


        this.dealsummaryOutputItemsListActualData.forEach( m =>
          {
            if(m.value== null)
            {
              m.value= "0";
            }
            
          })

      
          if(this.dealsummaryOutputItemsListActualData.length>0)
          {

           let dealSumEstimationHoverDataValue = new DealSumEstimationHoverModel();

          
           dealSumEstimationHoverDataValue.netPrincipalCollection =(this.dealsummaryOutputItemsListActualData[0].value != null ? this.dealsummaryOutputItemsListActualData[0].value : '0');
           dealSumEstimationHoverDataValue.revenueCollection = (this.dealsummaryOutputItemsListActualData[1].value != null ? this.dealsummaryOutputItemsListActualData[1].value : '0');
           dealSumEstimationHoverDataValue.dailyCashMovement = (this.dealsummaryOutputItemsListActualData[2].value != null ? this.dealsummaryOutputItemsListActualData[2].value : '0');

           this.dealSumEstimationHoverData[index] =dealSumEstimationHoverDataValue;
           

           this.dealSumEstimationHoverData.forEach(m =>
            {

              if(m.netPrincipalCollection== null || m.revenueCollection == null || m.dailyCashMovement == null)
            {
              m.netPrincipalCollection= "0";
              m.revenueCollection= "0";
              m.dailyCashMovement= "0";
            }

            })
          }

        
        console.log('After Estimation Data Load & Load Actual GMS Data')
      });
    }

  }

  isActualGMSDataAvaiable(estimationAdviceDate : Date)
  {
    this.isEstimationData =true;
    let latestcollectionDate= this.datePipe.transform(estimationAdviceDate, 'yyyy-MM-dd');
    
    
    this._dealSummaryOutputService.isActualGMSDataAvaliable(latestcollectionDate,this.dealName,this.isEstimationData).subscribe(result => {
      
        if(result == -1)
        {

          this._toastservice.openToast(ToasterTypes.error, this.title, this._actualDataValidationErrorMsg);

        }
        else
        {
          this.onLoadGMSActualData(estimationAdviceDate);
        }       
      
    });
  }


  onLoadGMSActualData(estimationAdviceDate : Date)
  {
    let latestcollectionDate= this.datePipe.transform(estimationAdviceDate, 'yyyy-MM-dd');
       
    this._dealSummaryOutputService.getLoadDailyEstimationDealSummary(latestcollectionDate,this.dealName,this.isEstimationData).subscribe(result => {
      
        this.dealSummaryDataModel = new DealSummaryDataModel();
        this.dealSummaryDataModel.adviceDate = this.adviceDateListDatesData;
        this.dealSummaryDataModel.dealName = this.dealName;
        this.dealSummaryDataModel.dealCategoryName = 'Deal Summary - Output';
        this.dealSummaryDataModel.viewType ='';
        
        this.dealsummaryOutputItemsList=[];
        this._dealSummaryOutputService.getDealSummaryOutputData(this.dealSummaryDataModel).subscribe(data => {
          
          this.dealsummaryOutputItemsList = data;
          this.dealsumOutputsLineItemList = this.dealsummaryOutputsItemsList.filter((value, index, self) => self.indexOf(value) == index)
  
          this.dealsumOutputsLineItemList = this.dealsumOutputsLineItemList.filter(s => s.lineItem == this.dealsumOutputsDistinctLineItem[0]);
         
          this.controlcheckChild.notifyControlCheckRefreshDataHandler();
          
     //     this.isDataRequestOutputSegComplete = false;
     //     this.isLoadDataEstimationRefresh();
        });
      
    });

    this.isActualGMSDataLoad= false;
    this.isLoadDataEstimationRefresh();

  }

  onLoadGMSActualDataPopUp() {
    this._modalService.open(this.loadActualGMSData,
        { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
            if (result.toLowerCase() === 'approved') {
                //  this.saveDeal(this.actionApproved, 'Approved Successfully')
            } else if (result.toLowerCase() === 'reject') {
                // this.saveDeal(this.actionRejected, 'Rejected Successfully')
            } else {
                console.log('Collapse');
            }
        });
  }

  onLoadEstimationDataPopUp() {
    this._modalService.open(this.loadActualEstimationData,
        { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
            if (result.toLowerCase() === 'approved') {
            } else if (result.toLowerCase() === 'reject') {
            } else {
                console.log('Collapse');
            }
        });
  }
}
