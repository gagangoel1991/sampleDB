import { DecimalPipe } from '@angular/common';
import { ConditionalExpr } from '@angular/compiler';
import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { DealSummaryDataModel, DealsumOutputsModel } from 'src/app/cash-waterfall/model/dealsum-outputs.model';
import { DealSummaryOutputService } from 'src/app/cash-waterfall/service/deal-summary-output.service';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';


@Component({
  selector: 'sfp-dealsum-controlchecksandbalance',
  templateUrl: './dealsum-controlchecksandbalance.component.html',
  styleUrls: ['./dealsum-controlchecksandbalance.component.scss'],
  providers : [DecimalPipe]
})
export class DealsumControlchecksandbalanceComponent implements OnChanges {

  @Input() dealName : string;

  @Input() adviceDate : string;

  @Input() adviceDateListDatesData : Array<string>;

  @Input() isOtherComponentBind : boolean;

  public titleDealSumControlCheckBalance = 'Deal Summary Output';
  public dealsumControlCheckBalanceList: Array<DealsumOutputsModel> = [];
  public dealsumControlCheckBalanceDates : Array<Date> = [];
  public dealsumControlCheckBalanceLineItem : Array<string> = [];

  public dealsumControlCheckBalanceListItem : Array<DealsumOutputsModel> = [];

  public dealsumCommonItemList: Array<DealsumOutputsModel> = [];

  public dealCategoryName : string; 
  public dealSummaryControlCheckBalanceDataModel : DealSummaryDataModel ;

  @Input() dealsummaryControlCheckBalanceItemsList : Array<DealsumOutputsModel> ;

  @Input() isControlCheckRefreshRequired : boolean;

  public dealsummaryTempControlCheckBalanceItemsList : Array<DealsumOutputsModel> = [];

  public dealSummaryDataModelControlCheck: DealSummaryDataModel;

  public isDataRequestControlCheckSegComplete: boolean = false;

  constructor(
    private _lookupService: KeyValueLookupService,
    public _dealSummaryOutputService : DealSummaryOutputService,
    private _decimalPipe: DecimalPipe
            ) { }

  ngOnChanges() {
              console.log(this.isOtherComponentBind );
              console.log(this.dealsummaryControlCheckBalanceItemsList)
      if ((this.dealName != null && this.dealName != "") && 
                  ( this.isOtherComponentBind 
                  && this.dealsummaryControlCheckBalanceItemsList.length>0)) {
              
                this.getDealSummaryControlCheckSumModelData();
      }
      this.dealSummaryDataModelControlCheck = new DealSummaryDataModel();
      
          
  }

  getDealSumBreakupDataValue(collectionDate: Date, lineItem: string) {
    let lineItemValue = this.dealsummaryControlCheckBalanceItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
                                                .map(obj =>obj.value);
    if(lineItemValue.length >0 )
    {
        if(lineItemValue[0] =="PASS" || lineItemValue[0] =="FAIL" || lineItemValue[0] =="YES" || lineItemValue[0] =="NO")
      {
        
        return lineItemValue[0];        
      }
      else
      {
        let value = lineItemValue[0] != null && lineItemValue[0] !="0.00" ? lineItemValue[0] : 0.00;
        return this._decimalPipe.transform(value, '1.2-2');
        
      }
    }
  }

  getDealSummaryControlCheckSumModelData(){
      this.dealsummaryControlCheckBalanceItemsList.forEach(obj => this.dealsummaryTempControlCheckBalanceItemsList.push(Object.assign({}, obj)));

      this.dealsumControlCheckBalanceLineItem =this.dealsummaryControlCheckBalanceItemsList.map( s => s.lineItem)
                .filter((value,index,self) =>  self.indexOf(value) ==index); 
                console.log(this.dealsumControlCheckBalanceLineItem);

      this.dealsumControlCheckBalanceDates =this.dealsummaryControlCheckBalanceItemsList.map( s => s.collectionDate)
                .filter((value,index,self) =>  self.indexOf(value) ==index);
                console.log(this.dealsumControlCheckBalanceDates);

      this.dealsumControlCheckBalanceListItem =this.dealsummaryControlCheckBalanceItemsList.filter(s =>s.collectionDate == this.dealsumControlCheckBalanceDates[0])
                console.log('dealsumControlCheckBalanceListItem' + this.dealsumControlCheckBalanceListItem)

      this.setFormArray(); 
  }

  expandParentLineItem(isExpandable: boolean, parentWaterfallLineItemId: number) {
   
    let data = this.dealsummaryControlCheckBalanceItemsList.filter(x => x.parentDailyCollectionLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 0 && x.collectionDate==this.dealsumControlCheckBalanceDates[0])
                  .sort((a, b) => {
                    return b.collectionDate ? 1 : (a.collectionDate ? -1 : 0)
                });
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
    });

    

    data = this.dealsummaryControlCheckBalanceItemsList.filter(x => x.parentDailyCollectionLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 1  && x.collectionDate==this.dealsumControlCheckBalanceDates[0]);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
    });
  
  }

  setFormArray() {
    this.dealsumControlCheckBalanceListItem.forEach(x => {
      x.isRowVisible = !(x.isSubLineItems == 0 && x.parentDailyCollectionLineItemId > 0   && x.collectionDate==this.dealsumControlCheckBalanceDates[0]) ? true : false
    });
  }

  notifyControlCheckRefreshDataHandler() {
      this.dealSummaryDataModelControlCheck.adviceDate = this.adviceDateListDatesData;
      this.dealSummaryDataModelControlCheck.dealName = this.dealName;
      this.dealSummaryDataModelControlCheck.dealCategoryName = '';
      this.dealSummaryDataModelControlCheck.viewType ='';
      this.isDataRequestControlCheckSegComplete = true;
     
      this._dealSummaryOutputService.getDealSummaryOutputData(this.dealSummaryDataModelControlCheck).subscribe(result => {

        this.dealsummaryControlCheckBalanceItemsList = result;
        this.dealsummaryControlCheckBalanceItemsList = this.dealsummaryControlCheckBalanceItemsList.filter(s => s.dailyCollectionCategory == 'Deal Summary - ControlCheck')
  
       
      this.dealsumControlCheckBalanceDates =this.dealsummaryControlCheckBalanceItemsList.map( s => s.collectionDate)
                .filter((value,index,self) =>  self.indexOf(value) ==index);
                console.log(this.dealsumControlCheckBalanceDates);
                      

       this.dealsumControlCheckBalanceListItem =this.dealsummaryControlCheckBalanceItemsList.filter(s =>s.collectionDate == this.dealsumControlCheckBalanceDates[0])
                 console.log(this.dealsumControlCheckBalanceListItem)
       this.setFormArray();
        
      });
      this.isDataRequestControlCheckSegComplete = false;
  }

}
