import { DatePipe } from '@angular/common';
import { Component, EventEmitter, Input, OnChanges, OnInit, Output, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';
import { Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DailyCollectionDealSummaryModel, DealSummaryDataModel, DealSummarySaveAdjustmentModel, DealSummarySaveAuditModel, DealsumOutputsModel, DealSummaryAuditCollectionModel } from 'src/app/cash-waterfall/model/dealsum-outputs.model';
import { WorkFlowStepEnum } from 'src/app/cash-waterfall/model/workflow-step.enum';
import { DealSummaryOutputService } from 'src/app/cash-waterfall/service/deal-summary-output.service';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuthWorkflowPopupComponent } from 'src/app/shared/components/auth-workflow/auth-workflow-popup.component';
import { AuthModalConfigModel } from 'src/app/shared/model/auth-modal-config.model';
import { AuthWorkflowStep, AuthWorkflowType } from 'src/app/shared/model/auth-workflow-enum';
import { AuthWorkflowStatusModel } from 'src/app/shared/model/auth-workflow-status.model';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { DealsumAdjustmentsComponent } from '../dealsum-adjustments/dealsum-adjustments.component';


@Component({
  selector: 'sfp-dealsum-audit',
  templateUrl: './dealsum-audit.component.html',
  styleUrls: ['./dealsum-audit.component.scss']
})
export class DealsumAuditComponent implements OnInit, OnChanges {

  @ViewChild('dealSummaryAuditCommentSave') dealSummaryAuditCommentSave: any;

  @Input() dealName: string;

  @Input() adviceDate: string;

  @Input() permissionList: Array<boolean>;

  @Input() adviceDateListDatesData: Array<string>;

  @Input() collectionAllStartDataList: DailyCollectionDealSummaryModel;

  @Input() isOtherComponentBind: boolean;

  @Input() isDataRequestComplete: boolean

  @Input() isMultiDeatPickerChecked: boolean

  @Output() notifyOutputLoaderData = new EventEmitter<boolean>();
  public title: string = 'Deal Summary Audit'

  public collectionAllNewStartDataList: DailyCollectionDealSummaryModel

  public isMultiDeatPickerCheckedforAudit: boolean

  public titleDealSumAudit = 'Deal Summary Output';
  public dealsumAuditList: Array<DealsumOutputsModel> = [];
  public dealsumAuditDates: Array<Date> = [];
  public dealAuditDatesUserWorkflow: Array<DealSummaryAuditCollectionModel> = [];
  public dealAuditDatesReviewerWorkflow: Array<DealSummaryAuditCollectionModel> = [];


  public dealsumAuditDailyCollectionIdList: Array<number> = [];
  public dealsumAuditLineItem: Array<string> = [];
  public datePipe = new DatePipe('en-UK');

  public dealsumAduditListItem: Array<DealsumOutputsModel> = [];

  public dealsumCommonItemList: Array<DealsumOutputsModel> = [];

  public dailyCollectionDealSummaryModel: DailyCollectionDealSummaryModel;

  public dealCategoryName: string;

  public dealsumAuditHistoryDailyCollectionModel: DealsumOutputsModel;

  @Input() dealId: number;
  public dealSummaryAuditDataModel: DealSummaryDataModel;

  public dealSummarySaveAuditCommentModel: DealSummarySaveAuditModel;

  public dealsummaryAuditItemsList: Array<DealsumOutputsModel> = [];

  public dealsummaryTempAuditItemsList: Array<DealsumOutputsModel> = [];

  public dealSummarySaveAuditList: Array<DealSummarySaveAuditModel> = [];

  public dealSummaryAuditAuthDataModel: DealsumOutputsModel;

  public auditCommentErrorMessage: string = 'Deal Summary Audit comment is required';

  public canAuthorize: boolean = true;
  public loggedInUser: string;
  public canRecall: boolean = false;
  public automateDataAuthStatusModel: AuthWorkflowStatusModel;
  public cashLaddeLoaded: boolean = true;
  public isDataChangesAllow: boolean = true;

  public isUser: boolean = false;

  public dailyCollectionSummaryIdValue: number;

  public canSendRecallReset: boolean = false;

  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;

  public workflowStepId: number;
  public actionApproved: number;
  public actionDraft: number;
  public actionRejected: number;
  public actionSendForAuthorization: number;
  public actionUserComment: number;
  public actionReviewerComment: number;

  public isAuthorizer: boolean = true;
  public canUpdate: boolean = false;
  public canView: boolean = false;
  public canDelete: boolean = false;
  public canAuthorized: boolean = false;
  public currentWorkflowStepId: number;
  constructor(
    private _lookupService: KeyValueLookupService,
    private _modalService: NgbModal,
    public _dealSummaryOutputService: DealSummaryOutputService,
    private _toastservice: GlobalToasterService,
    private _userRoleService: UserRoleService
  ) { }

  ngOnChanges() {
    console.log(this.isOtherComponentBind);
    console.log(this.adviceDateListDatesData)
    console.log(this.collectionAllStartDataList);
    console.log(this.isDataRequestComplete);
    //this.isMultiDeatPickerCheckedforAudit =this.isMultiDeatPickerChecked;
    console.log(this.isMultiDeatPickerCheckedforAudit)
    if (this.workflowStepId != this.actionUserComment && this.workflowStepId != this.actionReviewerComment) {
      this.getDailyAuditCollectionDealSummary(this.adviceDateListDatesData[0]);
    }
    if (this.isMultiDeatPickerChecked && this.collectionAllNewStartDataList != undefined) {
      this.workflowStepId = this.collectionAllNewStartDataList.workflowStepId;
      this.dailyCollectionSummaryIdValue = this.collectionAllNewStartDataList.dailyCollectionSummaryId;
    }
    else if (this.collectionAllStartDataList != undefined) {
      this.workflowStepId = this.collectionAllStartDataList.workflowStepId;
      this.dailyCollectionSummaryIdValue = this.collectionAllStartDataList.dailyCollectionSummaryId;
    }
    
  }

  ngOnInit(): void {

    this.isMultiDeatPickerCheckedforAudit = this.isMultiDeatPickerChecked;
    if ((this.dealName != null && this.dealName != "") && this.isOtherComponentBind) {
      this.getDealSummaryAuditModelData();

      if (this.isMultiDeatPickerChecked && this.collectionAllNewStartDataList != undefined) {
        this.workflowStepId = this.collectionAllNewStartDataList.workflowStepId;
        this.dailyCollectionSummaryIdValue = this.collectionAllNewStartDataList.dailyCollectionSummaryId;
      }
      else if (this.collectionAllStartDataList != undefined) {
        this.workflowStepId = this.collectionAllStartDataList.workflowStepId;
        this.dailyCollectionSummaryIdValue = this.collectionAllStartDataList.dailyCollectionSummaryId;
      }
      if (this.workflowStepId != null || (this.workflowStepId != this.actionUserComment && this.workflowStepId != this.actionReviewerComment)) {
        this.getDailyAuditCollectionDealSummary(this.adviceDateListDatesData[0]);
      }
      

      this.loggedInUser = this._userRoleService.getCurrentLoginUser();
      
      this.isReadOnlyAccess = this.permissionList[0];
      this.isAddEditAccess = this.permissionList[1];
      this.isApprovRejectAccess = this.permissionList[2];
      this.isDeleteAccess = this.permissionList[3];
      this.canView = this.permissionList[4];
      this.canUpdate = this.permissionList[5];
      this.canDelete = this.permissionList[6];
      this.canAuthorized = this.permissionList[7];

      console.log(this.permissionList);

      this.actionDraft = WorkFlowStepEnum.Draft;
      this.actionSendForAuthorization = WorkFlowStepEnum.SendForReview;
      this.actionApproved = WorkFlowStepEnum.Approved;
      this.actionRejected = WorkFlowStepEnum.Rejected;
      this.actionUserComment = WorkFlowStepEnum.UserComment;
      this.actionReviewerComment = WorkFlowStepEnum.ReviewerComment;

    }

    this.dealsumAuditLineItem = this.dealsummaryAuditItemsList.map(s => s.lineItem)
      .filter((value, index, self) => self.indexOf(value) == index);
    console.log(this.dealsumAuditLineItem);

    this.dealsumAuditDates = this.dealsummaryAuditItemsList.map(s => s.collectionDate)
      .filter((value, index, self) => self.indexOf(value) == index);

    this.fillDealSummaryUserAuditDetails();
    this.fillDealSummaryAuthorizerAuditDetails();

  }
  
  fillDealSummaryUserAuditDetails(){
    this.dealAuditDatesUserWorkflow = [];
    this.dealsummaryAuditItemsList.filter(f => f.lineItem=='User').forEach(s => {
      this.dealAuditDatesUserWorkflow.push({
        'workflowStepId': s.workFlowStepId,
        'collectionDate': s.collectionDate,
        'dailyCollectionSummaryId' : s.dailyCollectionSummaryId,
        'modifiedBy' : s.modifiedBy
      });
    });
  }

  fillDealSummaryAuthorizerAuditDetails(){
    this.dealAuditDatesReviewerWorkflow = [];
    this.dealsummaryAuditItemsList.filter(f => f.lineItem=='Reviewer').forEach(s => {
      this.dealAuditDatesReviewerWorkflow.push({
        'workflowStepId': s.workFlowStepId,
        'collectionDate': s.collectionDate,
        'dailyCollectionSummaryId' : s.dailyCollectionSummaryId,
        'modifiedBy' : this.getCollectionDateSendForAuthUserName(s.collectionDate),
      });
    });
  }


  getCollectionDateSendForAuthUserName(collectionDate: Date) : string
  {
      let data = this.dealAuditDatesUserWorkflow.filter(obj => obj.collectionDate == collectionDate);
      if(data.length>0)
        return data[0].modifiedBy;

  }

  getDealSumAuditDataValue(collectionDate: Date, lineItem: string) {
    let lineItemValue1 = this.dealsummaryAuditItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.modifiedBy);
    let lineItemValue2 = this.dealsummaryAuditItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.modifiedDate)[0];

    let lineitemvalueDates = lineItemValue2 ? this.datePipe.transform(lineItemValue2, 'dd-MMM-yyyy HH:mm') : '';
    let lineItemValue = lineItemValue1.toString() + ' ' + '(' + lineitemvalueDates + ')';

    if (lineItemValue.includes("()")) {
      lineItemValue = lineItemValue.replace(/[\(\)]/g, "");
    }
    else if (lineItemValue != null) {
      return lineItemValue;
    }
  }

  getDealSumAuditCommentValue(collectionDate: Date, lineItem: string) {
    let lineItemValue = this.dealsummaryAuditItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
      .map(obj => obj.comments);
    if (lineItemValue != null) {
      //  let value = noteValue[0][colName] != null ? noteValue[0][colName] : 0.00;
      //  return this._decimalPipe.transform(value, '1.2-2');
      return lineItemValue[0];
    }
  }


  getDealSummaryAuditModelData() {
    if (this.adviceDateListDatesData.length > 0) {

      this.dealSummaryAuditDataModel = new DealSummaryDataModel();
      this.dealCategoryName = 'Deal Summary - ControlCheck';
      this.dealSummaryAuditDataModel.adviceDate = this.adviceDateListDatesData;
      this.dealSummaryAuditDataModel.dealName = this.dealName;
      this.dealSummaryAuditDataModel.dealCategoryName = this.dealCategoryName;
      this.dealSummaryAuditDataModel.viewType ='';


      this.dealsummaryAuditItemsList = [];
      this._dealSummaryOutputService.getDealSummaryAuditData(this.dealSummaryAuditDataModel).subscribe(result => {
        this.dealsummaryAuditItemsList = result;
        console.log('line no 218 audit')
        console.log(result)
        console.log(this.dealsummaryAuditItemsList);


        this.dealsummaryAuditItemsList.forEach(obj => this.dealsummaryTempAuditItemsList.push(Object.assign({}, obj)));

        this.dealsumAuditLineItem = this.dealsummaryAuditItemsList.map(s => s.lineItem)
          .filter((value, index, self) => self.indexOf(value) == index);
       

        this.dealsumAuditDailyCollectionIdList = this.dealsummaryAuditItemsList.map(s => s.dailyCollectionSummaryId)
          .filter((value, index, self) => self.indexOf(value) == index);
        

        this.dealsumAuditDates = this.dealsummaryAuditItemsList.map(s => s.collectionDate)
          .filter((value, index, self) => self.indexOf(value) == index);
       

        this.fillDealSummaryUserAuditDetails();
        this.fillDealSummaryAuthorizerAuditDetails();

        this.dealsumAduditListItem = this.dealsummaryAuditItemsList.filter((value, index, self) => self.indexOf(value) == index);

        if (this.isMultiDeatPickerChecked && this.collectionAllNewStartDataList != undefined) {
          this.dealSummaryAuditAuthDataModel = this.dealsummaryAuditItemsList.filter(obj => obj.collectionDate == this.collectionAllNewStartDataList.collectionDate && obj.lineItem == 'User')[0];
        }
        else if (this.collectionAllStartDataList != undefined) {
          this.dealSummaryAuditAuthDataModel = this.dealsummaryAuditItemsList.filter(obj => obj.collectionDate == this.collectionAllStartDataList.collectionDate && obj.lineItem == 'User')[0];
        }



        this.isDataRequestComplete = false;
        this.notifyOutputLoaderData.emit(this.isDataRequestComplete);
        if (this.dealSummaryAuditAuthDataModel?.modifiedDate != null) {
          this.dealSummaryAuditAuthDataModel.modifiedDate = this.datePipe.transform(this.dealSummaryAuditAuthDataModel.modifiedDate, 'dd-MMM-yyyy HH:mm');

          // if (this.dealSummaryAuditAuthDataModel != undefined) {
          //   if (this.loggedInUser.toLowerCase() === this.dealSummaryAuditAuthDataModel?.modifiedBy.toLowerCase()) {
          //     this.isAuthorizer = false;
          //   }
          // }
        }
       

      });

      if (this.workflowStepId != this.actionUserComment && this.workflowStepId != this.actionReviewerComment) {
        this.getDailyAuditCollectionDealSummary(this.adviceDateListDatesData[0]);
      }
    }
  }

  getDailyAuditCollectionDealSummary(formattedAdviceDate: string) {
    this._dealSummaryOutputService.getDailyCollectionDealSummary(formattedAdviceDate, this.dealName).subscribe(data => {
      this.collectionAllNewStartDataList = data;

      if (this.collectionAllNewStartDataList != undefined) {
        if (this.collectionAllNewStartDataList.workflowStepId != null && this.collectionAllNewStartDataList.workflowStepId > 0) {
          this.workflowStepId = this.collectionAllNewStartDataList.workflowStepId;
        }
      }
     
      // });
    }, (error: any) => {
      console.log(error);
    });

  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }


  onDealSummaryCommntSavePopUpModel(index: number, ReviewerType: string) {
    console.log(this.dealsumAuditDailyCollectionIdList);
    this.dealSummarySaveAuditCommentModel = new DealSummarySaveAuditModel();
    if (this.dealsumAuditDailyCollectionIdList.length > 0) {
      this.dealSummarySaveAuditCommentModel.dailyCollectionSummaryId = this.dealsumAuditDailyCollectionIdList[index];
      if (ReviewerType == 'User') {
        // this.isUser=true;
        this.currentWorkflowStepId = WorkFlowStepEnum.UserComment;
      }
      else {
        this.currentWorkflowStepId = WorkFlowStepEnum.ReviewerComment;

      }

    }
    this._modalService.open(this.dealSummaryAuditCommentSave,
      { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
        if (result.toLowerCase() === 'approved') {
        } else if (result.toLowerCase() === 'reject') {
        } else {
          console.log('Collapse');
        }
      });
  }

  onDealSummaryAuditSaveData(comment: string, savedMessage: string, irComment1: NgModel, modal: NgbActiveModal, workflowstepId: number) {
    if (irComment1.control.status == "INVALID") {
      this._toastservice.openToast(ToasterTypes.error, this.title, this.auditCommentErrorMessage);
      return false;
    }
    else {


      this.dealSummarySaveAuditCommentModel.dailyCollectionSummaryId = this.dealSummarySaveAuditCommentModel.dailyCollectionSummaryId;
      this.dealSummarySaveAuditCommentModel.workflowStepId = workflowstepId;
      this.dealSummarySaveAuditCommentModel.comments = comment;

      this._dealSummaryOutputService.saveDealSummaryAuditData(this.dealSummarySaveAuditCommentModel).subscribe(result => {
        if (result === 1) {
          this._toastservice.openToast(ToasterTypes.success, this.title, savedMessage);
          this.getDealSummaryAuditModelData();

        }
        else if (result === 0) {
          this._toastservice.openToast(ToasterTypes.error, this.title, savedMessage);
        }
        else {
          this._toastservice.openToast(ToasterTypes.error, this.title, savedMessage);
        }
      });
    }
    modal.close('cancel');
  }

  openAuthActionModal(dailyCollectionSummaryIdValue: number) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });
    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.DealDailyCollection, AuthWorkflowStep.Approve_Reject, this.dealId, dailyCollectionSummaryIdValue);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.getDealSummaryAuditModelData();
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
  }


  sendForAuthorisation(dailyCollectionSummaryIdValue: number, workFlowStepId: number, savedMessage: string) {

    let model = new AuthModalConfigModel('Comment', 'Please provide your comment ', 'Comment is required.', AuthWorkflowType.DealDailyCollection, workFlowStepId, this.dealId, dailyCollectionSummaryIdValue);
    this.openModalPopup(model, savedMessage);
  }

  recall(dailyCollectionSummaryIdValue: number, workFlowStepId: number, savedMessage: string) {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comment ', 'Comment is required.', AuthWorkflowType.DealDailyCollection, workFlowStepId, this.dealId, dailyCollectionSummaryIdValue);
    this.openModalPopup(model, savedMessage);
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.getDealSummaryAuditModelData();
    });
  }

  openAuditTrailModal(auditIndex: number, auditName: string) {

    this.dealsumAuditHistoryDailyCollectionModel = this.dealsummaryAuditItemsList.filter(s => s.collectionDate == this.dealsumAuditDates[auditIndex] && s.lineItem == auditName)[0];

    
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.dealsumAuditHistoryDailyCollectionModel.dailyCollectionSummaryId, AuthWorkflowType.DealDailyCollection)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }
}
