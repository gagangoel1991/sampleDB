import { DecimalPipe } from '@angular/common';
import { Component, Input, OnChanges, OnInit } from '@angular/core';
import { DealSummaryDataModel, DealsumOutputsModel } from 'src/app/cash-waterfall/model/dealsum-outputs.model';
import { DealSummaryOutputService } from 'src/app/cash-waterfall/service/deal-summary-output.service';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';


@Component({
  selector: 'sfp-dealsum-breakup',
  templateUrl: './dealsum-breakup.component.html',
  styleUrls: ['./dealsum-breakup.component.scss'],
  providers : [DecimalPipe]
})
export class DealsumBreakupComponent implements OnChanges {

  @Input() dealName : string;

  @Input() adviceDate : string;

  @Input() adviceDateListDatesData : Array<string> =[];

  @Input() isOtherComponentBind : boolean;

  public titleDealSumBreakupOutput = 'Deal Summary Output';
  public dealsumBreakupList: Array<DealsumOutputsModel> = [];
  public dealsumBreakupDates : Array<Date> = [];
  public dealsumBreakupLineItem : Array<string> = [];

  public dealsumCommonItemList: Array<DealsumOutputsModel> = [];

    
  public dealCategoryName : string; 
  public dealSummaryDeflagBreakupDataModel : DealSummaryDataModel ;

  @Input() dealsummaryDeflagBreakupItemsList : Array<DealsumOutputsModel>;

  public dealsummaryTempDeflagBreakupItemsList : Array<DealsumOutputsModel> = [];

  constructor(
    private _lookupService: KeyValueLookupService,
    public _dealSummaryOutputService : DealSummaryOutputService,
    private _decimalPipe: DecimalPipe
            ) { }

  ngOnChanges() {
              console.log(this.isOtherComponentBind );
              this.dealSummaryDeflagBreakupDataModel = new DealSummaryDataModel();
  
      if ((this.dealName != null && this.dealName != "") && 
                  (this.isOtherComponentBind
                  && this.dealsummaryDeflagBreakupItemsList.length>0  )) {
              
                this.getDealSummarybreakupModelData();
        }
            
          
  }

  getDealSumBreakupDataValue(collectionDate: Date, lineItem: string) {
    let lineItemValue = this.dealsummaryDeflagBreakupItemsList.filter(obj => obj.collectionDate == collectionDate && obj.lineItem == lineItem)
                                                .map(obj =>obj.value);
    if (lineItemValue != null) {
      let value = lineItemValue[0] != null && lineItemValue[0] !="0.00" ? lineItemValue[0] : 0.00;
      return this._decimalPipe.transform(value, '1.2-2');
    }
  }

  getDealSummarybreakupModelData(){

    this.dealsummaryDeflagBreakupItemsList.forEach(obj => this.dealsummaryTempDeflagBreakupItemsList.push(Object.assign({}, obj)));

    this.dealsumBreakupLineItem =this.dealsummaryDeflagBreakupItemsList.map( s => s.lineItem)
              .filter((value,index,self) =>  self.indexOf(value) ==index); 
              console.log(this.dealsumBreakupLineItem);


    this.dealsumBreakupDates =this.dealsummaryDeflagBreakupItemsList.map( s => s.collectionDate)
              .filter((value,index,self) =>  self.indexOf(value) ==index);
              console.log(this.dealsumBreakupDates);

  }

  showHideLoadingImage(isShow) {
    if (isShow)
      document.getElementById('preloader').style['display'] = 'block';
    else
      document.getElementById('preloader').style['display'] = 'none';
  }

}
