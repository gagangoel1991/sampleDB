import { Component, OnInit, ViewChild } from '@angular/core';
import { DealCollectionsService } from 'src/app/cash-waterfall/service/deal-collections.service';
import { DatePipe } from '@angular/common';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DecimalPipe } from '@angular/common';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';

@Component({
  selector: 'sfp-rmbs-pnr-split',
  templateUrl: './rmbs-pnr-split.component.html',
  styleUrls: ['./rmbs-pnr-split.component.scss'],
  providers: [KeyValueLookupService, DealCollectionsService, DecimalPipe]
})
export class RmbsPnrSplitComponent implements OnInit {

  @ViewChild('PNRSplitHeadForm') pnrSplitHeadForm: NgForm;
  @ViewChild('PNRSplitBodyForm') pnrSplitBodyForm: NgForm;

  private collectionEndDate: string;
  private readonly _pnrSplitValidationMessage = 'Please fill/select required fields marked with asterisk(*) before showing the data.';
  private readonly _adviceDateValidationMessage = 'Please select advice date.';
  private readonly _excelValidationMessage = 'No data to export.';
  private readonly _dealNameValidationMessage = 'Please select deal name.';
  private readonly _requiredDateFormat = 'yyyy-MM-dd';

  public title = 'RMBS - P&R Split';
  public dealNameList: Array<KeyValueLookupModel> = [];
  public pnrSplitDataList: any[];
  public currentDate = new Date();
  public isRowVisible: boolean = false;
  public isRecordFound: boolean = false;
  public dealId;
  public dealName = "DUNMORE1"
  public isDataRequestComplete = false;

  collectionDate: string = null;
  adviceDate: string = null;
  collectionDT: string = null;
  datePipe = new DatePipe('en-UK');

  constructor(
    private _lookupService: KeyValueLookupService,
    private _rmbsPnrSplitService: DealCollectionsService,
    private _toastservice: GlobalToasterService,
    private _decimalPipe: DecimalPipe
  ) { }

  ngOnInit(): void {
    this.isRowVisible = false;
    this.isRecordFound = false;
    this.getDealName();
    this.dealId = 15;
    this.isDataRequestComplete = true;
  }

  getDealName() {
    this.dealNameList = null;
    this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealListForESMAReports.toString()).subscribe(result => {
      this.dealNameList = result
      if (this.dealNameList != null)
        this.dealNameList = this.dealNameList.filter(x => x.value == 'DUNMORE1');
    });
  }

  onDealDropDownChange(event: any) {
    if (event) {
      this.dealId = event.key;
      this.dealName = event.value;
    }
  }

  getMaxNoticeDate() {
    return new Date(this.currentDate);
  }

  setVintageDate(adviceDate: Date) {
    this.collectionEndDate = null;
    this.collectionDT = null;

    if (this.dealName === undefined || this.dealName == null || this.dealName == "") {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNameValidationMessage);
    }
    else {
      const formattedAdviceDate = this.formatDate(adviceDate);
      // Set advice date in formatted form for DB call
      this.adviceDate = formattedAdviceDate;
      this._rmbsPnrSplitService.getCollectionDate(this.dealName, formattedAdviceDate).subscribe(data => {
        this.collectionEndDate = this.formatDate(data);
        this.collectionDT = this.datePipe.transform(this.collectionEndDate, 'dd/MM/yyyy');
      }, (error: any) => {
        console.log(error);
      });
    }
  }

  PNRSplitView() {
    this.isDataRequestComplete = false;
    if (this.pnrSplitHeadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._pnrSplitValidationMessage);
      Object.keys(this.pnrSplitHeadForm.form.controls).forEach((key) => {
        this.pnrSplitHeadForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    }
    else {
      if (this.dealName === undefined || this.dealName == null || this.dealName == "" || this.collectionEndDate === undefined || this.collectionEndDate == null) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else {
        this.loadPnrSplitData(this.dealName, this.collectionEndDate);
        this.isDataRequestComplete = true;
      }
    }
  }

  loadPnrSplitData(dealName: string, asAtDate: string) {
    let formattedFrmDate = asAtDate ? this.datePipe.transform(asAtDate, this._requiredDateFormat) : '';
    let formattedAdviceDate = this.adviceDate ? this.datePipe.transform(this.adviceDate, this._requiredDateFormat) : '';
    this._rmbsPnrSplitService.getPNRSplitDetails(formattedFrmDate, formattedAdviceDate, dealName).subscribe(result => {
      this.pnrSplitDataList = result;
      console.log(JSON.stringify(result));

      if (result != null) {
        this.isRowVisible = true;
        this.isRecordFound = true;
      }
      else {
        this.isRowVisible = false;
        this.isRecordFound = false;
      }

    }, (error: any) => {
      console.log(error);
    });
  }

  formatDate(date: Date): string {
    return this.datePipe.transform(date, 'yyyy-MM-dd');
  }

  formatAmount(lineItem: string) {
    return this._decimalPipe.transform(lineItem, '1.2-2');
  }

  generatePNRSplitExcel() {
    this.isDataRequestComplete = false;
    if (this.pnrSplitHeadForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._pnrSplitValidationMessage);
      Object.keys(this.pnrSplitHeadForm.form.controls).forEach((key) => {
        this.pnrSplitHeadForm.form.get(key).markAsTouched();
      });
      this.isDataRequestComplete = true;
      return false;
    }
    else {
      if (this.dealName === undefined || this.dealName == null || this.dealName == "" || this.collectionEndDate === undefined || this.collectionEndDate == null) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._adviceDateValidationMessage);
      }
      else if (this.pnrSplitDataList == null) {
        this.isDataRequestComplete = true;
        this._toastservice.openToast(ToasterTypes.error, this.title, this._excelValidationMessage);
      }
      else {
        let formattedFrmDate = this.collectionEndDate ? this.datePipe.transform(this.collectionEndDate, this._requiredDateFormat) : '';
        let formattedAdviceDate = this.adviceDate ? this.datePipe.transform(this.adviceDate, this._requiredDateFormat) : '';
        this._rmbsPnrSplitService.getPNRSplitExcel(formattedFrmDate, formattedAdviceDate, this.dealName).subscribe(data => {
          let FileName = "RMBS-P&R-Split_" + this.formatDate(this.currentDate) + ".xlsx";
          var blob = new Blob([this.s2ab(atob(data))], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
          });

          var link = document.createElement('a');
          link.href = window.URL.createObjectURL(blob);
          link.download = FileName;

          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
          this.isDataRequestComplete = true;
        }, (error: any) => {
          console.log(error);
        });
      }
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }
}