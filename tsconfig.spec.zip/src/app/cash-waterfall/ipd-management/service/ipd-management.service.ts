import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';


@Injectable()
export class IpdManagementService {

  constructor(private _globalHttpService: GlobalHttpService) {
  }

  public GetIpdMgmtDashboardData(): Observable<any> {
    return this._globalHttpService.GetRequest(`/cashwaterfall/ipdmgmt/dashboarddata/`);
  }

  public initiateIpd(dealId: number, ipdDate: Date): Observable<any> {
    return this._globalHttpService.GetRequest(`/IpdProcess/initiateIpd/${dealId}/${ipdDate}`);
  }

  public resetIPD(dealId: number, ipdDate: Date): Observable<any> {
    return this._globalHttpService.GetRequest(`/IpdProcess/resetIPD/${dealId}/${ipdDate}`);
  }

  public getDealNextIpd(dealId: number):Observable<any> {
    return this._globalHttpService.GetRequest('/dealdate/dealnextipd', {dealId: dealId});
  }

}
