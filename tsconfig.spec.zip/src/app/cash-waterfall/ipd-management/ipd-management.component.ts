import { Component, ViewEncapsulation, ViewChild, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { IpdManagementModel, DealDateUIModel } from './model/ipd-management.model';
import { IpdManagementService } from './service/ipd-management.service';
import * as _ from 'lodash';
import { IpdAuthWorkflowService } from '../ipd-run-process/service/ipd-auth-workflow-service';
import { GlobalToasterService, ToasterTypes } from '../../shared/services/globaltoaster.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { ToastrService, GlobalConfig } from 'ngx-toastr';
import { CommonPopupConfigModel } from '../../shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from '../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { PermissionEnum } from '../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../shared/model/user-permission-accesstype.enum';

@Component({
  selector: 'cw-ipd-mgmt',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './ipd-management.component.html',
  styleUrls: ['./ipd-management.component.scss'],
  providers: [KeyValueLookupService, IpdManagementService, DatePipe, IpdAuthWorkflowService]
})

export class IpdManagementComponent implements OnInit {

  public dashboardLineItemList: Array<IpdManagementModel> = [];
  public dashboardLineItemUIList: Array<IpdManagementModel> = [];
  public distinctDeals: Array<string> = [];
  public PreviousIpddateList: Array<Date> = [];
  public PreviousIpddateListData: Array<string> = [];
  public prevIpddateList: DealDateUIModel[]
  public previouslatestdate: string;
  public previousSelectedDealDate: any[] = [];
  public ipdInitiateStarted = {};
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  public dealCollapseTerminateStatus: string[] = ['Collapse', 'Terminate', 'SendForAuthorisationTerminate', 'TerminateReject'];

  constructor(private _ipdManagementService: IpdManagementService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _datePipe: DatePipe,
    private _toastservice: GlobalToasterService,
    private _ipdAuthWorkflowService: IpdAuthWorkflowService,
    private activatedRoute: ActivatedRoute,
    private _userService: UserRoleService,
    private toastr: ToastrService,
    private _modalService: NgbModal) {
    this.activatedRoute.data.subscribe(result => {
      //Set the flag to change the left menu to original view
      this._userService.changeMenuType('home');
    });

  }

  ngOnInit(): void {
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);

    this.GetIpdMangementData();
  }

  public GetIpdMangementData() {
    this._ipdManagementService.GetIpdMgmtDashboardData().subscribe(data => {

      this.dashboardLineItemList = _.cloneDeep(data);
      this.dashboardLineItemUIList = _.cloneDeep(this.dashboardLineItemList);


      //For loader 
      this.ipdInitiateStarted = {};
      for (let x = 0; x < this.dashboardLineItemList.length; x++) {
        if (this.dashboardLineItemList[x].ipdType == 'Next') {
          _.set(this.ipdInitiateStarted, this.dashboardLineItemList[x].dealId + '.' + this.dashboardLineItemList[x].ipdDate, false);
        }
      }


      this.distinctDeals = Array.from(new Set(this.dashboardLineItemList.map(x => x.dealName)));
      this.dashboardLineItemList.filter(x => x.ipdType == "Current" && x.ipdDate != null)
      this.prevIpddateList = this.dashboardLineItemList.filter(x => x.ipdType == "Previous" && x.ipdDate != null)
        .map(elem => (
          new DealDateUIModel(elem.ipdDate, elem.dealId)
        ));

      let prevDistinctDealIds: number[] = Array.from(new Set(this.prevIpddateList.map(x => x.dealId)));

      prevDistinctDealIds.forEach(dealId => {
        let dealDates = this.prevIpddateList.filter(y => y.dealId == dealId).map(z => z.ipdDate);
        let maxPrevDate = _.max(dealDates);
        this.bindPreviousItem(maxPrevDate, dealId);
        this.previousSelectedDealDate[dealId] = this._datePipe.transform(maxPrevDate, 'dd/MM/yyyy');
      });

    }, (error: any) => {
      console.log(error);
    });
  }

  public ipDateItemList(dealId: number) {
    return this.dashboardLineItemList.filter(x => x.ipdType == "Previous" && x.dealId == dealId).map(x => x.ipdDate);
  }

  public bindPreviousItem(previousIpdDate: Date, dealId: number) {
    // previousIpdDate = this._datePipe.transform(previousIpdDate, "yyyy-MM-ddT00:00:00");
    let previousIpdObject = this.dashboardLineItemList.filter(x => x.ipdType == "Previous" && x.runId != 0 && x.ipdDate == previousIpdDate && x.dealId == dealId)[0];
    this.dashboardLineItemUIList = _.cloneDeep(this.dashboardLineItemUIList.filter(x => !(x.ipdType == "Previous" && x.dealId == dealId)));
    this.dashboardLineItemUIList.splice(1, 0, previousIpdObject);
    this.sortTheIpds();
  }


  public onChangePrevIpdDate(objDealDateUIModel: DealDateUIModel) {
    this.previousSelectedDealDate[objDealDateUIModel.dealId] = this._datePipe.transform(objDealDateUIModel.ipdDate, 'dd/MM/yyyy');
    this.bindPreviousItem(objDealDateUIModel.ipdDate, objDealDateUIModel.dealId);
  }

  public getPreviousDealDateList(dealId: number): DealDateUIModel[] {
    return this.prevIpddateList.filter(x => x.dealId == dealId);
  }

  public sortTheIpds() {
    this.dashboardLineItemUIList = _.sortBy(this.dashboardLineItemUIList, [function (ipd) {
      switch (ipd.ipdType) {
        case 'Current':
          return 1;
          break;
        case 'Previous':
          return 2;
          break;
        case 'Next':
          return 3;
          break;
      }
    }]);
  }

  public redirectToDealIpdProcess(dealId: number, runId: number) {
    this._router.navigate(['/cashwaterfall/ipdrunprocess/' + dealId + '/' + runId + '/'], { relativeTo: this._route });
  }

  initiateIPD(dealId: number, ipdDate: Date) {
    this.ipdInitiateStarted[dealId][ipdDate] = true;

    this._ipdManagementService.initiateIpd(dealId, ipdDate).subscribe(res => {

      this.ipdInitiateStarted[dealId][ipdDate] = false;
      this.GetIpdMangementData();

      // this.toastr.success('IPD is Initiated Successfully.', 'Initiate IPD',
      //   {
      //     closeButton: true,
      //     disableTimeOut: true,
      //     tapToDismiss: false
      //   }
      // );
      // this.toastr.error('IPD Initiate Process has been Failed.', 'Initiate IPD',
      //   {
      //     closeButton: true,
      //     disableTimeOut: true,
      //     tapToDismiss: false
      //   }
      // );


      this.GetIpdMangementData();
      if (res == 1) {
        this._toastservice.openToast(ToasterTypes.success, 'Initiate IPD', 'IPD is Initiated Successfully.');
      }
      else if (res == -3) {
        this._toastservice.openToast(ToasterTypes.error, 'Initiate IPD', 'IPD is already initiated, so you cannot re-initiate this IPD');
      }
      else if (res == -4) {
        this._toastservice.openToast(ToasterTypes.error, 'Initiate IPD', 'Collection and Interest Data is not available, so you cannot initiate this IPD');
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, 'Initiate IPD', 'IPD Initiate Process has been Failed.');
      }
    }, () => {
      this.ipdInitiateStarted[dealId][ipdDate] = false;
    });
  }

  confirmBox(dealName: string, dealId: number, ipdDate: Date) {
    console.log(ipdDate);
    let popupCfg = new CommonPopupConfigModel('Initiate IPD', `Are you sure you want to initiate the ${dealName} IPD?`);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.initiateIPD(dealId, ipdDate);
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

  disableNextIpd(dealId: number, ipdStatus: string) {
    let isDisable: boolean = true;
    var obj = this.dashboardLineItemUIList.filter(x => x.ipdType == 'Current' && x.dealId == dealId);
    if (obj.length) {
      let today = new Date();
      today.setUTCHours(0, 0, 0, 0);
      let ipdDate = new Date(obj[0].ipdDate);
      ipdDate.setUTCHours(0, 0, 0, 0);
      if (today > ipdDate && ipdStatus == 'Authorised' && this.isAddEditAccess) {
        isDisable = false;
      }
    }
    return isDisable;
  }

  isNextInitiateDisable(objIpdManagementModel: IpdManagementModel) {
    
    return objIpdManagementModel.ipdType == 'Next' &&
      objIpdManagementModel.earlyRedemptionDate != null &&
      objIpdManagementModel.earlyRedemptionDate < objIpdManagementModel.ipdDate &&
      (this.dealCollapseTerminateStatus.includes(objIpdManagementModel.dealStatus)) &&
      (objIpdManagementModel.earlyRedemptionDate < objIpdManagementModel.ipdDate);
  }
}
