export class IpdManagementModel {
    public dealId: number;
    public dealName: string;
    public dealStatus?: string;
    public dealStatusDisplayName?: string;
    public earlyRedemptionDate?: Date;
    public runId: number;
    public ipdDate: Date;
    public collectionBusinessStart: string;
    public collectionBusinessEnd: string;
    public ipdStatus: string;
    public ipdType: string;
}


export class DealDateUIModel {
    public ipdDate: Date;
    public dealId: number;

    constructor(_ipdDate: Date, _dealId: number) {
        this.ipdDate = _ipdDate;
        this.dealId = _dealId;
    }
}