import { Component, ViewEncapsulation, ViewChild, OnInit } from '@angular/core';
import { NgForm } from '@angular/forms';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { InvoiceManagementService } from 'src/app/cash-waterfall/invoice-management/service/invoice-management.service';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { InvoiceModel, InvoiceSearchParamsModel } from '../model/invoice.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';

import {
    AngularGridInstance,
    CollectionService,
    Column,
    Editors,
    FieldType,
    Filters,
    FlatpickrOption,
    Formatter,
    Formatters,
    GridOption,
    GridStateChange,
    Metrics,
    MultipleSelectOption,
    OperatorType,
} from 'angular-slickgrid';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { hyperLinkFormatter, InvoiceMgmtActionButtonFormatter, downloadLinkFormatter, currencyFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SelectListEnum, SelectLookupModel } from 'src/app/shared/model/select-lookup.model';
import { SelectLookupService } from 'src/app/shared/services/select-lookup.service';
import { InvestorReportSelectIPD } from 'src/app/reports/model/investor-report.model';
import { DealNameModel } from 'src/app/deal-config-master/model/deal-list.model';
import { IpdManagementService } from '../../ipd-management/service/ipd-management.service';
import { IpdManagementModel } from '../../ipd-management/model/ipd-management.model';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';

@Component({
    selector: 'cw-invoice-mgmt',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './invoice-management-list.component.html',
    styleUrls: ['./invoice-management-list.component.scss'],
    providers: [InvoiceManagementService, KeyValueLookupService, SelectLookupService, IpdManagementService]
})

export class InvoiceManagementListComponent implements OnInit {
    //declaration section
    @ViewChild('invoiceSearchForm') invoiceSearchForm: NgForm;



    public title = 'Invoice Management';
    public invoiceSearchGroup: string = 'InvoiceSearchGroup';
    public invoiceDataList: Array<InvoiceModel> = [];
    public invoiceselectedDataList: Array<InvoiceModel> = [];
    public invoiceGridOptions: SfpGridOptionsModel = null;
    public dealNameList: Array<KeyValueLookupModel> = [];
    public invoiceGridCustomCols: Array<SfpGridColumnModel> = [];
    public invoiceGridActionLinks: Array<SfpGridActionModel> = [];
    public invoiceGridExcludedCols: Array<string> = []
    public invoiceSearchParams: InvoiceSearchParamsModel;
    public searchParams: InvoiceSearchParamsModel;
    public datePipe = new DatePipe('en-UK');
    public searchSubmitted = false;
    public dealID: number;
    public dealRunID: number;
    public exportFileName = 'InvoiceManagementData';
    public dealIpdList: Array<SelectLookupModel> = [];
    public dealIpdListManageInvoice: Array<SelectLookupModel> = [];
    public ipdList: Array<InvestorReportSelectIPD> = [];
    public alldealId = 0;
    public ipdManageInvoiceDate;
    public validateIPDdropdown: boolean = true;
    public selectedipdDatesArray: Array<string> = [];
    public selectedformatIpdDate: string;
    public selectedformatedIpdDate: string;
    public dashboardLineItemList: Array<IpdManagementModel> = [];
    public isDeleting: boolean = false;
    

    public isReadOnlyAccess: boolean = false;
    public isAddEditAccess: boolean = false;
    public isApprovRejectAccess: boolean = false;
    public isDeleteAccess: boolean = false;
    private readonly _dateFormat = 'yyyy-MM-dd';
    private readonly _defaultDate = '1900-01-01';
    private readonly _addInvoiceNavPath = '/cashwaterfall/invoicemgmt/add/';
    private readonly _editInvoiceNavPath = '/cashwaterfall/invoicemgmt/edit/';
    private readonly _viewInvoiceNavPath = '/cashwaterfall/invoicemgmt/view/';
    private readonly _copyInvoiceNavPath = '/cashwaterfall/invoicemgmt/copy/';
    private readonly _invoiceLockedStatus = 'Locked';
    private readonly _invoiceAuthorisedStatus = 'Authorised';

    //Messages
    private readonly _invoiceToastTitle = 'Invoice';
    private readonly _invoiceDeletedMsg = 'Invoice is deleted successfully.';
    private readonly _InvoiceLockedNotAllowedDeleteMsg = 'Invoice is locked, you cannot delete this invoice.';
    private readonly _InvoiceLockedNotAllowedEditMsg = 'Invoice is locked, you cannot edit this invoice.';
    private readonly _invoiceReceiptDownloadedMsg = 'Invoice receipt is downloaded successfully.';
    private readonly _invoiceDeleteConfirmMsg = 'Are you sure you want to delete the {0} invoice?';
    private readonly _invoiceFromToDateValidationMsg = 'Paid From-Date cannot be greater than from Paid To-Date.';
    private readonly _InvoiceAuthorisedNotAllowedDeleteMsg = 'Invoice is Authorised, you cannot delete this invoice.';
    private readonly _InvoiceAuthorisedNotAllowedEditMsg = 'Invoice is Authorised, you cannot edit this invoice.';
    //-------Slick Grid Variables Start--------------
    public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
    public slickDataset: any[];
    public slickCallbackFuntions: SFP_SlickAction;
    public slickDefaultActionButtons: boolean = false;
    //-------Slick Grid Variables End--------------



    //constructor
    constructor(private _invoiceMgmtService: InvoiceManagementService,
        public _toastservice: GlobalToasterService,
        private _lookupService: KeyValueLookupService,
        private _route: ActivatedRoute,
        private _router: Router,
        private _userService: UserRoleService,
        private _sharedDataService: SharedDataService,
        private _selectLookupService: SelectLookupService,
        private _ipdManagementService: IpdManagementService) {
        console.log('Invoice data load.');
        //this._userService.changeMenuType('home');
        this.showHideLoadingImage(true);
        //Columns to exclude
        //   this.invoiceGridExcludedCols = ["InvoiceId", "DealId", "InvoiceCategoryTypeId", "InvoiceCategoryId", "UploadedFileName", "CisCode", "DealCounterpartyId", "Description", 'ID', 'UserName', 'IsLocked'];
    }

    ngOnInit() {
        let fromDate: Date = new Date();
        fromDate.setDate(fromDate.getDate() - 180);
        this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.View);
        this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.AddEdit);
        this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.ApproveReject);
        this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.Delete);

        this.invoiceSearchParams = new InvoiceSearchParamsModel(0, 0, 'All', this.datePipe.transform(fromDate, this._dateFormat),
            this.datePipe.transform(Date.now(), this._dateFormat), "");

        this._route.params.subscribe(params => {
            this.dealID = params['dealId'];
            this.dealRunID = params['ipdRunId'];
        });

        this.bindInvoiceColumns();
        this.bindInvoiceActionsCallBack();
        this.getDealName();
        this.getDealIPD();
        this.getInvoiceData();
    }



    getDealIPD() {

        let multiListId = [SelectListEnum.InvoiceStatus]
        this._selectLookupService.getMultiparameterSelectedList(multiListId).subscribe(result => {
            this.dealIpdList = result;
            if (this.dealID != undefined) {
                this.ipdList = this.getIpdDates(this.dealID);
                this._ipdManagementService.GetIpdMgmtDashboardData().subscribe(data => {
                    
                    this.dashboardLineItemList = data;
                    console.log(this.dashboardLineItemList);
                    let dealDates = this.dashboardLineItemList.filter(y => y.dealId == this.dealID && y.runId == this.dealRunID).map(z => z.ipdDate);                   
                    this.selectedformatedIpdDate = this.datePipe.transform(dealDates, 'yyyy-MM-dd');
                    this.invoiceSearchParams.dealId = this.dealID *1;
                    

                });


            }
            if (this.dealRunID == null) {
                this.selectedformatedIpdDate = "";
            }
            this.showHideLoadingImage(false);
        });

    }

    getDealIPDManageInvoice() {

        let multiListId = [SelectListEnum.InvoiceStatus]
        this._selectLookupService.getMultiparameterSelectedList(multiListId).subscribe(result => {
            this.dealIpdListManageInvoice = result;
            console.log(this.dealIpdListManageInvoice);
            this.showHideLoadingImage(false);
        });



    }

    onDealDropDownChange(event: any) {
        this.validateIPDdropdown = true;
        this.slickDataset = [];
        this.showHideLoadingImage(false);

        if (this.ipdList) {
            this.ipdList = [];
            this.ipdManageInvoiceDate = null;
        }
        if (event) {
            if (event.key == 0) {
                let fromDate: Date = new Date();
                fromDate.setDate(fromDate.getDate() - 180);

                this.invoiceSearchParams.paidStartDate = this.datePipe.transform(fromDate, this._dateFormat);
                this.invoiceSearchParams.paidEndDate = this.datePipe.transform(Date.now(), this._dateFormat);
                this.invoiceSearchParams.ipdDate = null;
                this.validateIPDdropdown = true;
            }
            else {
                this.invoiceSearchParams.ipdDate = null;
                this.slickDataset = [];
                this.invoiceSearchParams.paidStartDate = null;
                this.invoiceSearchParams.paidEndDate = null;
                this.dealID = event.key;
                this.ipdList = this.getIpdDates(this.dealID);

                this.validateIPDdropdown = true;
                if (this.dealRunID == null) {
                    this.invoiceSearchParams.ipdDate = null;
                    this.selectedformatedIpdDate = "";
                }

            }
        }
    }

    getIpdDates(dealId: number) {
        var ipdDatesArray: Array<InvestorReportSelectIPD> = [];
        let tempIpdList = this.dealIpdList.filter(x => x.value == dealId);
        let tempIpdListfinal = tempIpdList.sort((a, b) => (this.datePipe.transform(b.text, "yyyy-MM-dd") > this.datePipe.transform(a.text, "yyyy-MM-dd")) ? 1 : -1);
        tempIpdListfinal.forEach(x => {
            this.ipdManageInvoiceDate = new InvestorReportSelectIPD(x.text);
            ipdDatesArray.push(this.ipdManageInvoiceDate);
        });

        for (let i = 0; i < ipdDatesArray.length; i++) {
            ipdDatesArray[i]["formatIpdDate"] = this.datePipe.transform(ipdDatesArray[i]["ipdDate"], "MMM yyyy");
        }
        return ipdDatesArray;
    }

    onDealIPDDropDownChange(event: any) {

        this.invoiceSearchParams.ipdDate = event.formatIpdDate;

        this.validateIPDdropdown = true;

    }

    getDealName() {

        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealList.toString()).subscribe(result => {
            console.log('deal name Fetched:');
            this.dealNameList = JSON.parse(JSON.stringify(result));
            this.dealNameList.splice(0, 0, new KeyValueLookupModel(0, 'All'));
            console.log(this.dealNameList);
            this.showHideLoadingImage(false);
        });
    }

    hideLoadingImage() {
        if (this.dealNameList && this.invoiceDataList) {
            document.getElementById('preloader').style['display'] = 'none';
        }
    }

    onDealSelectDropDownChange(event: any) {
        this.invoiceSearchParams.dealId = event.value.dealId;
        this.invoiceSearchParams.ipdRunId = this.dealRunID;

    }

    bindInvoiceColumns() {
        if (this.isAddEditAccess) {
            //Preparing grid custom columns
            this.slickColumnArray.push(new SFP_SlickColumn('', 'Actions', false, false, 150, FieldType.string, InvoiceMgmtActionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 150))
        }

        this.slickColumnArray.push
            (
                //Preparing grid custom columns
                new SFP_SlickColumn('referenceNumber', 'Invoice Ref No', true, true, 100, FieldType.string, hyperLinkFormatter),
                new SFP_SlickColumn('dealName', 'Deal Name', true, true, 100, FieldType.string),
                new SFP_SlickColumn('invoiceCategoryType', 'Invoice Type', true, true, 100, FieldType.string),
                new SFP_SlickColumn('invoiceCategory', 'Invoice Category', true, true, 150, FieldType.string),
                new SFP_SlickColumn('counterpartyName', 'Counterparty Name', true, true, 150, FieldType.string),
                new SFP_SlickColumn('amount', 'Amount', true, true, 100, FieldType.string, currencyFormatter),
                new SFP_SlickColumn('paidDate', 'Invoice Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
                new SFP_SlickColumn('dealIpdDate', 'Deal IPD Date', true, true, 150, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
                //new SFP_SlickColumn('originalFileName', 'Invoice Receipt', true, true, 100, FieldType.string),
                new SFP_SlickColumn('originalFileName', 'Invoice Receipt', true, true, 175, FieldType.string, downloadLinkFormatter),
                new SFP_SlickColumn('status', 'Status', true, true, 100, FieldType.string),
                new SFP_SlickColumn('createdDate', 'CreatedDate', true, true, 150, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
                new SFP_SlickColumn('createdBy', 'CreatedBy', true, true, 150, FieldType.string, undefined, SFP_SlickFilterType.multiSelect),
                new SFP_SlickColumn('modifiedDate', 'ModifiedDate', true, true, 150, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
                new SFP_SlickColumn('modifiedBy', 'ModifiedBy', true, true, 150, FieldType.string, undefined, SFP_SlickFilterType.multiSelect)
            );

    }

    getInvoiceData() {

        console.log(this.invoiceSearchParams);
        this.validateIPDdropdown = true;
        if (this.invoiceSearchParams.paidStartDate && this.invoiceSearchParams.paidEndDate &&
            this.invoiceSearchParams.paidStartDate > this.invoiceSearchParams.paidEndDate) {
            this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceFromToDateValidationMsg);
            return;
        }


        if (!this.invoiceSearchParams.paidStartDate)
            this.searchParams.paidStartDate = this.datePipe.transform(this._defaultDate);

        if (!this.invoiceSearchParams.paidEndDate)
            this.searchParams.paidEndDate = this.datePipe.transform(this._defaultDate);


        if (this.dealRunID != null) {
            this.invoiceSearchParams.ipdRunId = this.dealRunID;
            //this.invoiceSearchParams.dealId = this.dealID;
            this.invoiceSearchParams.paidStartDate = null;
            this.invoiceSearchParams.paidEndDate = null;

        }

        if (this.invoiceSearchParams.ipdDate != null && this.invoiceSearchParams.ipdDate != "") {

            this.invoiceSearchParams.paidStartDate = null;
            this.invoiceSearchParams.paidEndDate = null;
            this.invoiceSearchParams = new InvoiceSearchParamsModel(this.invoiceSearchParams.dealId, 0, "", "", "", this.invoiceSearchParams.ipdDate);
        }


        this.searchParams = JSON.parse(JSON.stringify(this.invoiceSearchParams));

        if (((this.invoiceSearchParams.ipdDate == null || this.invoiceSearchParams.ipdDate == "")
            && (this.invoiceSearchParams.dealId != 0))
            && (this.dealRunID == null)
            && (this.invoiceSearchParams.paidStartDate == "" || this.invoiceSearchParams.paidStartDate == null)) {

            this.validateIPDdropdown = false;
            this.slickDataset = [];

        }
        if (((this.invoiceSearchParams.ipdDate != null && this.invoiceSearchParams.ipdDate != "")
            || (this.invoiceSearchParams.paidStartDate && this.invoiceSearchParams.paidEndDate))
            || (this.dealRunID != null)) {

            this._invoiceMgmtService.getInvoiceList(this.invoiceSearchParams).subscribe(result => {
                console.log('Invoice List Fetched:');

                this.slickDataset = JSON.parse(JSON.stringify(result));
                this.invoiceselectedDataList = result;

                // if (this.dealRunID != null) {
                //     this.invoiceSearchParams.dealId = this.invoiceselectedDataList[0].dealId;

                // }
                this.showHideLoadingImage(false);

            });

            if (this.dealRunID != null) {
                this._route.params.subscribe(params => {
                    this.dealID = params['dealId'];
                    this.dealRunID = params['ipdRunId'];
                    });
                //this.invoiceSearchParams.dealId = this.dealID;

            }
        }

    }

    bindInvoiceActionsCallBack() {
        this.slickCallbackFuntions = new SFP_SlickAction(
            this.onInvoiceTitleClickCallback,
            this.onInvoiceCopyCallback,
            this.onGridInvoiceEditCallback,

            {
                deleteFunc: this.onGridInvoiceDeleteCallback,
                title: "Delete Invoice Data confirmation",
                message: template`Are you sure you want to delete Deal data for \'${'dealName'}\'.`
            },
            this.onDownLoadAction

        );
    }

    onDownLoadAction(rowData: any, parentThis: any) {
        parentThis.downloadInvoiceReceipt(rowData, parentThis);
    }

    onGridInvoiceEditCallback(record: any, currentThis: any = this) {
        console.log('Edit Invoice id : ' + record.invoiceId.toString());
        let invoiceId = record['invoiceId']
        if (record.status == currentThis._invoiceLockedStatus) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._invoiceToastTitle, currentThis._InvoiceLockedNotAllowedEditMsg);
            return;
        }
        else if (record.status == currentThis._invoiceAuthorisedStatus) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._invoiceToastTitle, currentThis._InvoiceAuthorisedNotAllowedEditMsg);
            return;
        }
        currentThis._router.navigate([currentThis._editInvoiceNavPath, record.invoiceId], { relativeTo: currentThis._route });
    }

    onInvoiceTitleClickCallback(record: any, currentThis: any = this) {
        console.log('View Invoice id : ' + record.invoiceId.toString());
        currentThis._router.navigate([currentThis._viewInvoiceNavPath, record.invoiceId], { relativeTo: currentThis._route });
    }

    onInvoiceCopyCallback(record: any, currentThis: any = this) {
        console.log('Copy Invoice id : ' + record.invoiceId.toString());
        currentThis._router.navigate([currentThis._copyInvoiceNavPath, record.invoiceId], { relativeTo: currentThis._route });
    }

    downloadInvoiceReceipt(record: InvoiceModel, currentThis) {
        currentThis._invoiceMgmtService.downloadInvoiceFile(record.invoiceId).subscribe(blob => {
            console.log('Invoice file blob');
            console.log(blob);
            const a = document.createElement('a');
            const objectUrl = URL.createObjectURL(blob);
            a.href = objectUrl
            a.download = record.originalFileName;
            a.click();
            URL.revokeObjectURL(objectUrl);
            currentThis._toastservice.openToast(ToasterTypes.success, currentThis._invoiceToastTitle, currentThis._invoiceReceiptDownloadedMsg);
        });
    }

    showHideLoadingImage(isShow) {
        if (isShow)
            document.getElementById('preloader').style['display'] = 'block';
        else
            document.getElementById('preloader').style['display'] = 'none';
    }

    onGridInvoiceDeleteCallback(record: any, currentThis: any = this) {
        if (record.status === currentThis._invoiceLockedStatus) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._invoiceToastTitle, currentThis._InvoiceLockedNotAllowedDeleteMsg);
            return;
        }
        else if (record.status === currentThis._invoiceAuthorisedStatus) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._invoiceToastTitle, currentThis._InvoiceAuthorisedNotAllowedDeleteMsg);
            return;
        }
        var invoicelId = record.invoiceId;
        currentThis.showHideLoadingImage(true);
        currentThis.isDeleting = true;
        currentThis._invoiceMgmtService.deleteInvoiceData(invoicelId).subscribe(result => {
            currentThis._toastservice.openToast(ToasterTypes.success, currentThis._invoiceToastTitle, currentThis._invoiceDeletedMsg);
            currentThis.getInvoiceData();
            currentThis.showHideLoadingImage(false);
            currentThis.isDeleting = false;
        });
    }

    onInvoiceSearch() {
        this.getInvoiceData();
    }

    onAddInvoice() {
        this._route.params.subscribe(params => {
            this.dealID = params['dealId'];
            this.dealRunID = params['ipdRunId'];
        });
        // console.log(this.dealRunID);

        if (this.dealRunID != null) {
            this._router.navigate([this._addInvoiceNavPath + this.dealID + '/' + this.dealRunID + '/'], { relativeTo: this._route });
        }
        else {
            this._router.navigate([this._addInvoiceNavPath], { relativeTo: this._route });
        }


    }

    resizeGrid() {
        let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
        objSFP_Slick.resizeGrid();
    }

}