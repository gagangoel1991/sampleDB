import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { InvoiceManagementListComponent } from './invoice-management-list.component';
import { InvoiceManagementService } from './../service/invoice-management.service';
import { InvoiceModel, InvoiceSearchParamsModel } from '../model/invoice.model';
import { SfpGridComponent } from 'src/app/shared/components/grid/sfp-grid.component';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { DealListService } from 'src/app/deal-config/service/deal-list.service';
import { DealNameModel }  from 'src/app/deal-config/model/deal-list.model';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { DummyInvoiceList } from '../model/spec/mock-invoice-list.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';

describe('InvoiceManagementListComponent', () => {
  let childFixture: ComponentFixture<SfpGridComponent>;
  let fixture: ComponentFixture<InvoiceManagementListComponent>;
  let invoiceComponent: InvoiceManagementListComponent;
  let de: DebugElement;
  let compiledElement;
  const dummyInvoiceList: any = DummyInvoiceList;
  const dummyInvoiceRecord: any = dummyInvoiceList[0];
  const dealList: any = [{ dealId: 2, dealName: 'Ardmore1'}, {dealId: 3, dealName: 'Dunmore1'}];
  let datePipe = new DatePipe('en-UK');

  beforeEach(async(() => {
    //spy object to mock
    const mockedDealListService = jasmine.createSpyObj('DealListService',['getDealNames']);
    const mockedInvoiceManagementService = jasmine.createSpyObj('InvoiceManagementService',['getInvoiceList','deleteInvoiceData']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest', 'DownloadFile']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);
    
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [InvoiceManagementListComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: DealListService, useValue: mockedDealListService }
        , { provide: InvoiceManagementService, useValue: mockedInvoiceManagementService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    var dummyElement = document.createElement('div');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);

    fixture = TestBed.createComponent(InvoiceManagementListComponent);

    const dealService = fixture.debugElement.injector.get(DealListService);
    const invoiceManagementService = fixture.debugElement.injector.get(InvoiceManagementService);
    
    spyOn(dealService, 'getDealNames').and.callFake(() => {
      return of(dealList); 
    });

    spyOn(invoiceManagementService, 'getInvoiceList').and.callFake(() => {
      return of(dummyInvoiceList); 
    });

    invoiceComponent = fixture.componentInstance;
    let fromDate : Date = new Date();
    fromDate.setDate(fromDate.getDate() - 60 );
    invoiceComponent.invoiceSearchParams = new InvoiceSearchParamsModel(2,30, 'Ardmore1', datePipe.transform(fromDate, 'yyyy-MM-dd'), 
    datePipe.transform(Date.now(), 'yyyy-MM-dd'), "");

    //Set the invoice record
    invoiceComponent.invoiceDataList = dummyInvoiceList;;
  });

  it('should create Invoice Management list component', () => {
    fixture.debugElement.injector.get(InvoiceManagementService) as jasmine.SpyObj<InvoiceManagementService>;
    fixture.debugElement.injector.get(DealListService) as jasmine.SpyObj<DealListService>;
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;
    
    expect(invoiceComponent).toBeDefined();
  });

  it('Verify the Invoice Management Title->', () => { 
    expect(invoiceComponent.title).toBe('Invoice Management');
  });

  it('should call getDealName function ', function () {
    const dealService = fixture.debugElement.injector.get(DealListService);
    
    //Call the component function
    invoiceComponent.getDealName();

    //Validate/Test the result
    expect(expect(invoiceComponent.getDealName).toHaveBeenCalled).toBeTruthy();
    expect(expect(dealService.getDealNames).toHaveBeenCalled).toBeTruthy();
  });

  it('should load/call invoice list async', async(() => {
    const invoiceManagementService = fixture.debugElement.injector.get(InvoiceManagementService);

    //Call the component function
    invoiceComponent.getInvoiceData();

    //Validate/Test the result
    expect(expect(invoiceManagementService.getInvoiceList).toHaveBeenCalled).toBeTruthy();
    expect(expect(invoiceComponent.getInvoiceData).toHaveBeenCalled).toBeTruthy();
  }));

  it('should have defined grid component', () => {
    childFixture = TestBed.createComponent(SfpGridComponent);
    const childApp = childFixture.componentInstance;
    expect(childApp).toBeDefined();
  });

  it('should be able to call the download invoice receipt', () => {

    const invoiceManagementService = fixture.debugElement.injector.get(InvoiceManagementService);
    spyOn(invoiceManagementService, 'downloadInvoiceFile').and.callFake(() => {
      return of([]); 
    });
    //mock the URL.createObjectURL
    let windowOpenSpy = spyOn(window, 'open');
    let urlCreateObjectSpy = spyOn(URL, 'createObjectURL').and.returnValue('');

    //Call the component function
    invoiceComponent.downloadInvoiceReceipt(dummyInvoiceRecord, invoiceComponent);

    //Validate/Test the result
    expect(expect(invoiceManagementService.downloadInvoiceFile).toHaveBeenCalled).toBeTruthy();
  });

  it('should have delete record option on invoice grid', () => {
    const dummyRecord = dummyInvoiceList[0];
    const invoiceManagementService = fixture.debugElement.injector.get(InvoiceManagementService);
    let result = 'success';
    const spy = spyOn(invoiceManagementService, 'deleteInvoiceData').and.callFake(() => {
      return of(result); 
    });

    //Call the component function
    invoiceComponent.onGridInvoiceDeleteCallback(dummyRecord, invoiceComponent);

    //Validate/Test the result
    expect(expect(invoiceManagementService.deleteInvoiceData).toHaveBeenCalled).toBeTruthy();
    expect(spy).toHaveBeenCalled();
    expect(expect(invoiceComponent.onGridInvoiceDeleteCallback).toHaveBeenCalled).toBeTruthy();

  });

  it('should have invoice title clickable for edit the invoice', () => {
    const dummyRecord = dummyInvoiceList[0];

    //Call the component function
    invoiceComponent.onInvoiceTitleClickCallback(dummyRecord, invoiceComponent);

    //Validate/Test the result
    expect(expect(invoiceComponent.onInvoiceTitleClickCallback).toHaveBeenCalled).toBeTruthy();

  });
});