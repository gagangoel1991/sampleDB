import { Injectable } from '@angular/core';
import { InvoiceModel, InvoiceSearchParamsModel} from '../model/invoice.model';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';

@Injectable()
export class InvoiceManagementService {

    constructor(private globalHttpService: GlobalHttpService) {}
    
    //This will return the Invoice List Data
    public getInvoiceList(searchParams: InvoiceSearchParamsModel):Observable<any> {
        return this.globalHttpService.PostRequest("/invoice/getinvoicelist", searchParams);
    }

    public getInvoice(invoiceId: number):Observable<any> {
        return this.globalHttpService.GetRequest("/invoice/getinvoice", {'invoiceId': invoiceId});
    }

    public downloadInvoiceFile(invoiceId: number):Observable<any> {
        return this.globalHttpService.DownloadFile("/invoice/downloadInvoiceFile", {'invoiceId': invoiceId});
    }

    //this is for updation based upon form data passed
    public saveInvoiceData(invoiceData: FormData):Observable<any> {
        return this.globalHttpService.PostFormDataRequest("/invoice/saveInvoice", invoiceData);
    }

    public deleteInvoiceData(invoiceId: number):Observable<any> {
        return this.globalHttpService.GetRequest("/invoice/deleteInvoice", {'invoiceId': invoiceId});
    }   

    public getInvoiceCategoryType():Observable<any> {
        return this.globalHttpService.GetRequest("/invoice/getInvoiceCatType", null);
    }

    public getInvoiceCategory(invoiceCatTypeId: number):Observable<any> {
        return this.globalHttpService.GetRequest("/invoice/getInvoiceCategory", {invoiceCategoryTypeId: invoiceCatTypeId});
    }

    public getDealCounterparty(dealId: number):Observable<any> {
        return this.globalHttpService.GetRequest("/dealcounterparty/getdealcp", {dealId: dealId});
    }

    public getSpotRate(dealId: number, fromCurrencyId: number, spotRateDate: string): Observable<any> {
        return this.globalHttpService.GetRequest(`/invoice/getSpotRate/${dealId}/${fromCurrencyId}/${spotRateDate}`);
    }
        
}