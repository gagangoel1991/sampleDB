export class InvoiceSearchParamsModel {
    public dealId: number;
    public ipdRunId: number;
    public dealName: string;
    public paidStartDate: string;
    public paidEndDate: string;
    public ipdDate: string


    constructor(dealId: number, ipdRunId: number, dealName: string, paidStartDate: string, paidEndDate: string, ipdDate: string) {
        this.dealId = dealId;
        this.ipdRunId = ipdRunId;
        this.dealName = dealName;
        this.paidStartDate = paidStartDate;
        this.paidEndDate = paidEndDate;
        this.ipdDate = ipdDate;

    }
}

export class InvoiceCategoryTypeModel {
    public invoiceCategoryTypeId: number;
    public name: string;
    public description: string;

    constructor(invoiceCategoryTypeId: number, name: string, description: string) {
        this.invoiceCategoryTypeId = invoiceCategoryTypeId;
        this.name = name;
        this.description = description;
    }
}

export class InvoiceCategoryModel {
    public invoiceCategoryId: number;
    public name: string;
    public description: string;

    constructor(invoiceCategoryId: number, name: string, description: string) {
        this.invoiceCategoryId = invoiceCategoryId;
        this.name = name;
        this.description = description;
    }
}

export class InvoiceModel {
    public invoiceId: number;
    public name: string; //Invoice Title
    public dealId: number;
    public dealName: string;
    public invoiceCategoryTypeId: number;
    public invoiceCategoryType: string;
    public invoiceCategoryId: number;
    public invoiceCategory: string;
    public counterpartyName: string;
    public dealCounterpartyId: number;
    public description: string;
    public amount: number;
    public paidDate: string;
    public dealIpdDate: string;
    public uploadedFileName: string;
    public originalFileName: string;
    public invoiceStatusId: number;
    public status: string;
    public referenceNumber: string;
    public sourceSpotRate: number;
    public spotRate: number;
    public invoicePaidAmount: string;
    public invoiceDate: string;
    public invoiceCurrencyId: number;
    public dealCurrency: string;
    public spotRateDate: string;
    public modifiedBy: string;
    public modifiedDate: Date;

    constructor(invoiceId: number, dealId: number, dealName: string, invoiceCategoryTypeId: number,
        invoiceCategoryType: string, invoiceCategoryId: number, invoiceCategory: string, dealCounterpartyId: number,
        counterpartyName: string, description: string, amount: number, paidDate: string, dealIpdDate: string,
        uploadedFileName: string, originalFileName: string, referenceNumber: string, sourceSpotRate: number, spotRate: number,
        invoicePaidAmount: string, invoiceDate: string, invoiceCurrencyId: number, spotRateDate: string) {
        this.invoiceId = invoiceId;
        this.dealId = dealId;
        this.dealName = dealName;
        this.invoiceCategoryTypeId = invoiceCategoryTypeId;
        this.invoiceCategoryType = invoiceCategoryType;
        this.invoiceCategoryId = invoiceCategoryId;
        this.invoiceCategory = invoiceCategory;
        this.counterpartyName = counterpartyName;
        this.dealCounterpartyId = dealCounterpartyId;
        this.description = description;
        this.amount = amount;
        this.paidDate = paidDate;
        this.dealIpdDate = dealIpdDate;
        this.uploadedFileName = uploadedFileName;
        this.originalFileName = originalFileName;
        this.referenceNumber = referenceNumber;
        this.sourceSpotRate = sourceSpotRate;
        this.spotRate = spotRate;
        this.invoicePaidAmount = invoicePaidAmount;
        this.invoiceDate = invoiceDate;
        this.invoiceCurrencyId = invoiceCurrencyId;
        this.spotRateDate = spotRateDate;
    }
}