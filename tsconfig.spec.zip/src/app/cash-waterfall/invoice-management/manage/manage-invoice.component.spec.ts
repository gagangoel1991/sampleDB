import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { ManageInvoiceComponent } from './manage-invoice.component';
import { InvoiceManagementService } from './../service/invoice-management.service';
import { InvoiceModel, InvoiceCategoryTypeModel, InvoiceCategoryModel } from '../model/invoice.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { DealListService } from 'src/app/deal-config/service/deal-list.service';
import { DealNameModel, DealIpdModel }  from 'src/app/deal-config/model/deal-list.model';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { DummyInvoiceList } from '../model/spec/mock-invoice-list.model';
import { DealCounterpartyModel } from '../../model/deal-counterparty.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';
import { ActivatedRoute, Router, Params } from '@angular/router';

describe('ManageInvoiceComponent', () => {
  let fixture: ComponentFixture<ManageInvoiceComponent>;
  let invoiceComponent: ManageInvoiceComponent;
  let de: DebugElement;
  let compiledElement;
  const dummyInvoiceRecord: InvoiceModel = {
    invoiceId: 1,
    amount: 15000,
    counterpartyName: "THE BANK OF NEW YORK MELLON SA/NV DUBLIN BRANCH",
    dealCounterpartyId: 6,
    dealId: 2,
    dealIpdDate: "2021-02-15T00:00:00",
    dealName: "ARDMORE1",
    description: "Paid to CP as Trustee fee - Copy",
    invoiceCategory: "Trustee Costs and Expenses",
    invoiceCategoryId: 2,
    invoiceCategoryType: "Trustee Fee",
    invoiceCategoryTypeId: 1,
    name: "Paid to CP as Trustee fee - Copy ",
    originalFileName: "cube-8.jpg",
    paidDate: "2020-11-26T00:00:00",
    uploadedFileName: "13fe5702-3d57-47c9-a719-56b8f0b7a1dd.jpg",
    invoiceStatusId : 1,        
    status:'Active',
    referenceNumber : "",
    sourceSpotRate : 1,
    spotRate : 1,
    invoicePaidAmount : "5000",
    invoiceDate: "",
    invoiceCurrencyId: 5,
    dealCurrency: "EUR",
    spotRateDate: "",
    modifiedBy : "",
    modifiedDate : new Date()
  };
  const dealList: any = [{ dealId: 2, dealName: 'Ardmore1'}, {dealId: 3, dealName: 'Dunmore1'}];
  const dealIpdList: Array<DealIpdModel> = [{ dealId: 2, ipdDate: "15-Feb-2021"} ];
  const invoiceCatTypeList: any = [{ invoiceCategoryTypeId: 1, name: "Trustee Fee", description: "Trustee Fee"}, 
    {invoiceCategoryTypeId: 2, name: "Issuer Cost", description: "Issuer Cost"}];
  const dealCPList: Array<DealCounterpartyModel> = [{ dealCounterpartyId: 6, dealId: 2, cisCode: "ZCV9NBE", counterpartyName: "THE BANK OF NEW YORK MELLON SA/NV DUBLIN BRANCH"} ];
  const invoiceCatList: any = [{ invoiceCategoryId: 1, name: "Opening Principal Balance", description: "Opening Principal Balance"}, 
    {invoiceCategoryId: 2, name: "Trustee Costs and Expenses", description: "Trustee Costs and Expenses"}];

  beforeEach(async(() => {
    //spy object to mock
    const mockedDealListService = jasmine.createSpyObj('DealListService',['getDealNames']);
    const mockedInvoiceManagementService = jasmine.createSpyObj('InvoiceManagementService',['getInvoice', 'saveInvoiceData', 'downloadInvoiceFile', 'getInvoiceCategoryType','getInvoiceCategory','getDealCounterparty', 'getDealNextIpd']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [ManageInvoiceComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: DealListService, useValue: mockedDealListService }
        , { provide: InvoiceManagementService, useValue: mockedInvoiceManagementService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
        ,{ provide: ActivatedRoute,
            useValue:{
                params: of({id: 1}),
                url: of('/cashwaterfall/invoicemgmt/edit/1')
            }
          }
      ]
    }).compileComponents();
    
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageInvoiceComponent);
    invoiceComponent = fixture.componentInstance;
    invoiceComponent.actionType = 'edit';
    invoiceComponent.invoiceRecordData = dummyInvoiceRecord;
  });

  it('should create Manage Invoice component', () => {
    const fixture = TestBed.createComponent(ManageInvoiceComponent);
    fixture.debugElement.injector.get(InvoiceManagementService) as jasmine.SpyObj<InvoiceManagementService>;
    fixture.debugElement.injector.get(DealListService) as jasmine.SpyObj<DealListService>;
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;

    // get the service
    const invoiceService = fixture.debugElement.injector.get(InvoiceManagementService);
    const dealService = fixture.debugElement.injector.get(DealListService);

    //Prepare the dummy result
    spyOn(invoiceService, 'getInvoice').and.callFake(() => {
      return of(dummyInvoiceRecord); 
    });

    spyOn(dealService, 'getDealNames').and.callFake(() => {
      return of(dealList); 
    });

    spyOn(invoiceService, 'getInvoiceCategoryType').and.callFake(() => {
      return of(invoiceCatTypeList); // return the invoice category type
    });

    spyOn(invoiceService, 'getDealCounterparty').and.callFake(() => {
      return of(dealCPList); // return the counterparty list 
    });

    // spyOn(invoiceService, 'getDealNextIpd').and.callFake(() => {
    //   return of(dealIpdList); // return the counterparty list 
    // });

    const invoiceMgmtCompopInstance = fixture.componentInstance;    

    expect(invoiceMgmtCompopInstance).toBeDefined();
  });

  it('should be able to call the GetInvoice function', () => {
    // get the service
    const invoiceService = fixture.debugElement.injector.get(InvoiceManagementService); 
    const dealService = fixture.debugElement.injector.get(DealListService);

    //Spy on service functions
    spyOn(invoiceService, 'getInvoice').and.callFake(() => {
      return of(dummyInvoiceRecord); 
    });

    spyOn(dealService, 'getDealNames').and.callFake(() => {
      return of(dealList); 
    });

    spyOn(invoiceService, 'getDealCounterparty').and.callFake(() => {
      return of(dealCPList); // return the counterparty list 
    });

    // spyOn(invoiceService, 'getDealNextIpd').and.callFake(() => {
    //   return of(dealIpdList); // return the counterparty list 
    // });

    spyOn(invoiceService, 'getInvoiceCategoryType').and.callFake(() => {
      return of(invoiceCatTypeList); // return the invoice category type
    });

    spyOn(invoiceService, 'getInvoiceCategory').and.callFake(() => {
      return of(invoiceCatList); // return the invoice category list 
    });

    //Call the component function
    invoiceComponent.editCopyViewInvoiceInitialize(invoiceComponent.invoiceRecordData.invoiceId);

    //Validate/Test the result
    expect(expect(invoiceService.getInvoice).toHaveBeenCalled).toBeTruthy();
    expect(expect(invoiceComponent.editCopyViewInvoiceInitialize).toHaveBeenCalled).toBeTruthy();
  });

  it('should be able to call the download invoice receipt', () => {
    // get the service
    const invoiceManagementService = fixture.debugElement.injector.get(InvoiceManagementService);

    spyOn(invoiceManagementService, 'downloadInvoiceFile').and.callFake(() => {
      return of([]); 
    });
    //mock the URL.createObjectURL
    let windowOpenSpy = spyOn(window, 'open');
    let urlCreateObjectSpy = spyOn(URL, 'createObjectURL').and.returnValue('');

    //Call the component function
    invoiceComponent.downloadInvoiceReceipt();

    //Validate/Test the result
    expect(expect(invoiceManagementService.downloadInvoiceFile).toHaveBeenCalled).toBeTruthy();
  });


  it('should call loadDealList function ', function () {
    // get the service
    const dealService = fixture.debugElement.injector.get(DealListService);
    const invoiceService = fixture.debugElement.injector.get(InvoiceManagementService); 

    //Spy on service functions
    spyOn(dealService, 'getDealNames').and.callFake(() => {
      return of(dealList); 
    });

    spyOn(invoiceService, 'getDealCounterparty').and.callFake(() => {
      return of(dealCPList); // return the counterparty list 
    });

    // spyOn(invoiceService, 'getDealNextIpd').and.callFake(() => {
    //   return of(dealIpdList); // return the counterparty list 
    // });
    
    //Call the component function
    invoiceComponent.loadDealList();

    //Validate/Test the result
    expect(expect(invoiceComponent.loadDealList).toHaveBeenCalled).toBeTruthy();
    expect(expect(dealService.getDealNames).toHaveBeenCalled).toBeTruthy();
  });

  it('should call getInvoiceCategoryType function ', function () {
    // get the service
    const invoiceService = fixture.debugElement.injector.get(InvoiceManagementService); 

    //Spy on service function
    spyOn(invoiceService, 'getInvoiceCategoryType').and.callFake(() => {
      return of(invoiceCatTypeList); // return the invoice category type
    });

    spyOn(invoiceService, 'getInvoiceCategory').and.callFake(() => {
      return of(invoiceCatList); // return the invoice category list 
    });

    //Call the component function
    invoiceComponent.getInvoiceCategoryType();
    
    //test the result
    expect(expect(invoiceService.getInvoiceCategoryType).toHaveBeenCalled).toBeTruthy();
    expect(expect(invoiceService.getInvoiceCategory).toHaveBeenCalled).toBeTruthy();
    expect(expect(invoiceComponent.getInvoiceCategoryType).toHaveBeenCalled).toBeTruthy();
  });

  it('should call getInvoiceCategory function ', function () {
    // get the service
    const service = fixture.debugElement.injector.get(InvoiceManagementService); 

    //Spy on service functions
    spyOn(service, 'getInvoiceCategory').and.callFake(() => {
      return of(invoiceCatList); // return the invoice category list 
    });

    //Call the component function
    invoiceComponent.getInvoiceCategory();

    //test the result
    expect(expect(service.getInvoiceCategory).toHaveBeenCalled).toBeTruthy();
    expect(expect(invoiceComponent.getInvoiceCategory).toHaveBeenCalled).toBeTruthy();
  });


  it('should call getCounterparty function ', function () {
    // get the service
    const invoiceService = fixture.debugElement.injector.get(InvoiceManagementService); 

    //Spy on service functions
    spyOn(invoiceService, 'getDealCounterparty').and.callFake(() => {
      return of(dealCPList); // return the counterparty list 
    });
    
    //Call the component function
    invoiceComponent.getCounterparty();

    //test the result
    expect(expect(invoiceService.getDealCounterparty).toHaveBeenCalled).toBeTruthy();
    expect(expect(invoiceComponent.getCounterparty).toHaveBeenCalled).toBeTruthy();
  });

  // it('should call getDealIpd function ', function () {
  //   // get the service
  //   const invoiceService = fixture.debugElement.injector.get(InvoiceManagementService); 

  //   //Spy on service functions
  //   spyOn(invoiceService, 'getDealNextIpd').and.callFake(() => {
  //     return of(dealIpdList); // return the counterparty list 
  //   });

  //   //Call the component function
  //   invoiceComponent.getDealIpd();

  //   //test the result
  //   expect(expect(invoiceService.getDealNextIpd).toHaveBeenCalled).toBeTruthy();
  //   expect(expect(invoiceComponent.getDealIpd).toHaveBeenCalled).toBeTruthy();
  // });

});