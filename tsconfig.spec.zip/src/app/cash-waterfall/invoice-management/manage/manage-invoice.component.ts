import { Component, Input, OnInit, ViewEncapsulation, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { InvoiceManagementService } from '../../../cash-waterfall/invoice-management/service/invoice-management.service';
import { GlobalToasterService, ToasterTypes } from '../../../shared/services/globaltoaster.service';
import { InvoiceModel, InvoiceCategoryTypeModel, InvoiceCategoryModel } from '../model/invoice.model';
import { DealNameModel, DealIpdModel } from '../../../deal-config-master/model/deal-list.model';
import { DealCounterpartyModel } from '../../../cash-waterfall/model/deal-counterparty.model';
import { DatePipe, DecimalPipe } from '@angular/common';
import { CanDeactivateForm } from '../../../core/guard/can-deactivate/can-deactivate-form.component';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { KeyValueLookupModel } from '../../../shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from '../../../shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupService } from '../../../shared/services/key-value-lookup.service';
import { IpdManagementService } from '../../ipd-management/service/ipd-management.service';
import { UserRoleService } from '../../..//shared/services/user-role-service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';

@Component({
    selector: 'cw-manage-invoice',
    templateUrl: './manage-invoice.component.html',
    styleUrls: ['./manage-invoice.component.scss'],
    providers: [InvoiceManagementService, KeyValueLookupService, IpdManagementService]
})

export class ManageInvoiceComponent extends CanDeactivateForm implements OnInit {
    @ViewChild('manageInvoiceForm') manageInvoiceForm: NgForm;
    @ViewChild('manageInvoiceForm') confirmUnsavedForm: NgForm;
    @Output() notifyOnInvoiceSave = new EventEmitter<string>();

    public invoiceRecordData: InvoiceModel = null;
    public dealNameList: Array<KeyValueLookupModel>;
    public invoiceCatTypeList: Array<InvoiceCategoryTypeModel> = [];
    public invoiceCategoryList: Array<InvoiceCategoryModel> = [];
    public counterpartyList: Array<DealCounterpartyModel> = [];
    public dealIpdList: Array<DealIpdModel> = [];
    public title: string = '';
    public invoiceForm: FormGroup;
    public invoiceFileToUpload: File = null;
    public actionType: string = '';
    public invoiceFileUploadRequiredValidation: boolean = false;
    public invoiceFileUploadSizeValidation: boolean = false;
    public isRecordLocked: boolean = false;
    public notAllowMinerAmendment: boolean = true;
    public minerAmendmentClicked: boolean = false;
    public isSaving: boolean = false;
    private invoiceId: number = 0;
    private datePipe = new DatePipe('en-UK');
    public dealID: number;
    public isReadOnlyAccess: boolean = false;
    public isAddEditAccess: boolean = false;
    public isApprovRejectAccess: boolean = false;
    public isDeleteAccess: boolean = false;
    public dealRunID: number;
    public invoiceViewURL: string = '';
    public routerURL: string = '';
    private readonly _dateFormat = 'yyyy-MM-dd';
    private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);
    private readonly _allowedFiles = ['txt', 'png', 'gif', 'jpg', 'jpeg', 'pdf', 'doc', 'docx', 'xls', 'xlsx', 'csv', 'msg'];
    public currentDate: string = new Date().toISOString().split("T")[0];
    public invoiceunsavedRecordData: InvoiceModel = null;

    private readonly _invoiceSaveValidationMessage = 'Please fill required fields marked with asterisk(*) before saving invoice.';
    private readonly _spotRateDateValidationMessage = 'This combination (Deal Currency, Invoice Currency, and Spot Date) spot rate is not exists, please select correct combination to get the spot rate.';
    private readonly _invoiceActionAdd = 'add';
    private readonly _invoiceActionEdit = 'edit';
    private readonly _invoiceActionCopy = 'copy';
    private readonly _invoiceActionView = 'view';
    private readonly _invalidAction = 'invalid';
    private readonly _addInvoiceTitle = 'Add Invoice';
    private readonly _editInvoiceTitle = 'Edit Invoice';
    private readonly _lockedInvoiceTitle = 'This invoice is locked, you cannot edit this invoice';
    private readonly _authorisedInvoiceTitle = 'This invoice is Authorised, you cannot edit this invoice';
    private readonly _copyInvoiceTitle = 'Copy Invoice';
    private readonly _viewInvoiceTitle = 'View Invoice';
    private readonly _InvalidActionTitle = 'Resource is not available';
    private readonly _viewInvoiceListNavPath = '/cashwaterfall/invoicemgmt/';
    private readonly _viewInvoiceListInvoiceNavPath = '/cashwaterfall/ipdrunprocess/';
    private readonly _lockedStatus = 'Locked'
    private readonly _authorisedStatus = 'Authorised'
    //Messages
    private readonly _invoiceNotExist = 'Invoice record is not exist.';
    private readonly _invoiceToastTitle = 'Invoice';
    private readonly _invoiceReferenceDuplicateMsg = 'Please enter the unique Invoice Reference Number.';
    private readonly _invoiceSavedMsg = 'Invoice is saved successfully.';
    private readonly _invoiceUpdedMsg = 'Invoice is updated successfully.';
    private readonly _invoiceReceiptSizeExceedMsg = 'Invoice receipt file size cannot exceed 20MB.';
    private readonly _invoiceReceiptSizeBlankMsg = 'Invoice receipt file size cannot be of 0KB.';
    private readonly _invoiceReceiptInvalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file types are txt, png, gif, jpg, jpeg, pdf, doc, docx, xls, xlsx, msg and csv.';
    private readonly _invoiceReceiptDownloadedMsg = 'Invoice receipt is successfully downloaded.';
    private readonly _valueChangeMessage = "You have not changed any value.";

    public canUpdate: boolean = false;
    public canView: boolean = false;
    public canDelete: boolean = false;
    public canAuthorized: boolean = false;
    public loggedInUser: string;
    public selectedDealName: string;
    public currencyList: any;
    public dealCurrency: any;
    public isRateChange: boolean = false;
    public isSpotRateChangeDisable: boolean = false;


    constructor(
        private _lookupService: KeyValueLookupService,
        private _invoiceService: InvoiceManagementService,
        private _toastservice: GlobalToasterService,
        private _route: ActivatedRoute,
        private _router: Router,
        private _ipdManagementService: IpdManagementService,
        private _userService: UserRoleService) {
        super();


        this._route.params.subscribe((params: Params) => {
            this.invoiceId = (params['invoiceid'] && params['invoiceid'] != null) ? params['invoiceid'] : null;
            this.invoiceViewURL = this._router.url.split('/')[6];

            if (this.invoiceViewURL == this._invoiceActionView) {
                this.routerURL = this.invoiceViewURL;
            }
            else {
                this.routerURL = this._router.url.split('/')[3];
            }

            switch (this.routerURL) {

                case this._invoiceActionAdd:
                    this.title = this._addInvoiceTitle;
                    this.actionType = this._invoiceActionAdd;
                    this.addInvoiceInitialize();
                    break;
                case this._invoiceActionEdit:
                    this.title = this._editInvoiceTitle;
                    this.actionType = this._invoiceActionEdit;
                    this.editCopyViewInvoiceInitialize(this.invoiceId);
                    break;
                case this._invoiceActionCopy:
                    this.title = this._copyInvoiceTitle;
                    this.actionType = this._invoiceActionCopy;
                    this.editCopyViewInvoiceInitialize(this.invoiceId);
                    break;
                case this._invoiceActionView:
                    this.title = this._viewInvoiceTitle;
                    this.actionType = this._invoiceActionView;
                    this.editCopyViewInvoiceInitialize(this.invoiceId);
                    break;
                default:
                    this.title = this._InvalidActionTitle;
                    this.actionType = this._invalidAction;
            }
        });
    }

    ngOnInit() {
        this.invoiceRecordData = new InvoiceModel(0, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null, null);
        this.loadCurrency();
        this.setUpUserRolesAndPermissions();
        this._route.params.subscribe(params => {
            this.dealID = params['dealId'];
            this.dealRunID = params['ipdRunId'];
        });
        this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.View);
        this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.AddEdit);
        this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.ApproveReject);
        this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.Delete);
    }

    editCopyViewInvoiceInitialize(invoiceId: number) {


        this._invoiceService.getInvoice(invoiceId).subscribe(result => {
            console.log('Invoice record is fetched:');
            if (result) {
                this.invoiceRecordData = result;

                this.dealCurrency = this.invoiceRecordData.dealCurrency;
                if (this.invoiceRecordData.sourceSpotRate != this.invoiceRecordData.spotRate) {
                    this.isRateChange = true;
                }
                //this.selectedDealName = this.invoiceRecordData.dealName.toLowerCase();
                if (this.actionType === 'copy') {
                    this.invoiceRecordData.referenceNumber = "";
                    this.invoiceFileToUpload == null;
                    this.invoiceRecordData.originalFileName = '';
                }

                if (this.invoiceRecordData.status === this._lockedStatus ||
                    this.invoiceRecordData.status === this._authorisedStatus) {
                    if (this.actionType === this._invoiceActionEdit)
                        this.title = this.invoiceRecordData.status == this._lockedStatus ? this._lockedInvoiceTitle : this._authorisedInvoiceTitle;
                    this.isRecordLocked = true;
                }
                if (this.invoiceRecordData.status === this._lockedStatus || this.invoiceRecordData.status === this._authorisedStatus) {
                    this.notAllowMinerAmendment = false;
                }

                if (this.canUpdate == true && this.actionType == 'view' && this.isRecordLocked == false) {
                    this.actionType = 'edit';
                    this.title = this._editInvoiceTitle;
                }

                this.invoiceRecordData.paidDate = this.datePipe.transform(this.invoiceRecordData.paidDate, this._dateFormat);
                this.invoiceRecordData.dealIpdDate = this.datePipe.transform(this.invoiceRecordData.dealIpdDate, this._dateFormat);
                this.invoiceRecordData.invoiceDate = this.datePipe.transform(this.invoiceRecordData.invoiceDate, this._dateFormat);
                this.invoiceRecordData.spotRateDate = this.datePipe.transform(this.invoiceRecordData.spotRateDate, this._dateFormat);
                this.loadDealList();
                this.getInvoiceCategoryType();
                this.invoiceunsavedRecordData = JSON.parse(JSON.stringify(this.invoiceRecordData));
            }
            else {
                this.title = this._invoiceNotExist;
                this.actionType = this._invalidAction;
            }


            this.isDealInVoiceCurrencyCompare();
        });
    }

    isDealInVoiceCurrencyCompare() {
        if (this.dealCurrency != null && this.invoiceRecordData.invoiceCurrencyId != null && this.currencyList != undefined) {

            let invoicecurrncy = this.currencyList?.filter(x => x.key == this.invoiceRecordData.invoiceCurrencyId)[0].value;
            if (invoicecurrncy == this.dealCurrency) {
                this.isSpotRateChangeDisable = true;
                this.invoiceRecordData.spotRate = 1;
                this.invoiceRecordData.sourceSpotRate = 1;
            }


        }

    }

    addInvoiceInitialize() {
        this.loadDealList();
        this.getInvoiceCategoryType();
    }

    onInvoiceCurrencyChange(event: any) {
        if (event && this.invoiceRecordData.spotRateDate && this.invoiceRecordData.dealId) {
            if (this.dealCurrency == event.value) {
                this.isDealInVoiceCurrencyCompare();
                return false;
            }
            else {
                this.isSpotRateChangeDisable = false;
                this.getSpotRate(this.invoiceRecordData.dealId, event.key, this.invoiceRecordData.spotRateDate);
            }
        }
    }

    spotRateChange() {
        this.isRateChange = false;
        if (this.invoiceRecordData.sourceSpotRate != this.invoiceRecordData.spotRate) {
            this.isRateChange = true;
        }
    }

    onInvoiceDateChange(event: any) {
        if (event) {
            this.invoiceRecordData.spotRateDate = this.invoiceRecordData.invoiceDate;
        }
    }

    onSpotRateDateChange(event: any) {
        if (event && this.invoiceRecordData.invoiceCurrencyId && this.invoiceRecordData.dealId) {
            this.getSpotRate(this.invoiceRecordData.dealId, this.invoiceRecordData.invoiceCurrencyId, this.invoiceRecordData.spotRateDate);
        }
    }

    getSpotRate(dealId: number, invoiceCurrencyId: number, spotRateDate: string) {

        this._invoiceService.getSpotRate(dealId, invoiceCurrencyId, spotRateDate).subscribe(spotRate => {
            console.log(spotRate);
            if (spotRate == null) {
                this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._spotRateDateValidationMessage);
                this.invoiceRecordData.spotRate = spotRate;
                this.invoiceRecordData.sourceSpotRate = spotRate;
                return false;
            }
            else {
                this.invoiceRecordData.spotRate = spotRate;
                this.invoiceRecordData.sourceSpotRate = spotRate;
            }
        });
    }

    isEditInvoice() {
        return (this.actionType === this._invoiceActionEdit || this.actionType === this._invoiceActionCopy
            || this.actionType === this._invoiceActionView);
    }

    validateFormState() {
        if (this.manageInvoiceForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceSaveValidationMessage);
            return false;
        }
        return true;
    }

    downloadInvoiceReceipt() {
        if (this.invoiceFileToUpload != null || this.invoiceRecordData.originalFileName != '') {
            this._invoiceService.downloadInvoiceFile(this.invoiceId).subscribe(blob => {
                console.log('Invoice file blob');
                console.log(blob);
                const a = document.createElement('a');
                const objectUrl = URL.createObjectURL(blob);
                a.href = objectUrl
                a.download = this.invoiceRecordData.originalFileName;
                a.click();
                URL.revokeObjectURL(objectUrl);
                this._toastservice.openToast(ToasterTypes.success, this._invoiceToastTitle, this._invoiceReceiptDownloadedMsg);
            });
        }
    }

    //Saving the invoice data
    onSaveInvoice() {
        if (this.isSaving)
            return false;

        if (this.manageInvoiceForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceSaveValidationMessage);
            Object.keys(this.manageInvoiceForm.form.controls).forEach((key) => {
                this.manageInvoiceForm.form.get(key).markAsTouched();
            });

            this.invoiceFileUploadRequiredValidation = this.invoiceFileToUpload == null ?? true;

            return false;
        }
        //Saving the invoice after all validations
        const formData: FormData = new FormData();
        if (this.invoiceFileToUpload) {
            formData.append('invoiceFileAsByte', this.invoiceFileToUpload, this.invoiceFileToUpload.name);
        }
        else {
            formData.append('invoiceFileAsByte', null);
            formData.append('originalFileName', this.invoiceRecordData.originalFileName);
            formData.append('uploadedFileName', this.invoiceRecordData.uploadedFileName);
        }

        //Add other details as well in the form data
        //Set the InvoiceID as Zero in case of Copy action
        if (this.actionType === this._invoiceActionCopy)
            this.invoiceRecordData.invoiceId = 0;
        formData.append('invoiceId', this.invoiceRecordData.invoiceId.toString());
        formData.append('name', this.invoiceRecordData.name);
        formData.append('dealId', this.invoiceRecordData.dealId.toString());
        formData.append('invoiceCategoryTypeId', this.invoiceRecordData.invoiceCategoryTypeId.toString());
        formData.append('invoiceCategoryId', this.invoiceRecordData.invoiceCategoryId.toString());
        formData.append('dealCounterpartyId', this.invoiceRecordData.dealCounterpartyId.toString());
        formData.append('amount', this.invoiceRecordData.amount.toString());
        formData.append('description', (this.invoiceRecordData.description) ? this.invoiceRecordData.description : '');
        formData.append('paidDate', this.invoiceRecordData.paidDate.toString());
        formData.append('dealIpdDate', this.invoiceRecordData.dealIpdDate.toString());
        formData.append('referenceNumber', this.invoiceRecordData.referenceNumber);
        formData.append('invoiceDate', this.invoiceRecordData.invoiceDate.toString());
        formData.append('invoiceCurrencyId', this.invoiceRecordData.invoiceCurrencyId.toString());
        if (this.invoiceRecordData.spotRate != null) {
            formData.append('invoicePaidAmount', ((this.invoiceRecordData.amount * this.invoiceRecordData.spotRate).toString()));
        }
        if (this.invoiceRecordData.sourceSpotRate != null) {
            formData.append('sourceSpotRate', this.invoiceRecordData.sourceSpotRate.toString());
        }
        if (this.invoiceRecordData.spotRate != null) {
            formData.append('spotRate', this.invoiceRecordData.spotRate.toString());
        }
        formData.append('spotRateDate', this.invoiceRecordData.spotRateDate.toString());

        if (this.invoiceRecordData.originalFileName == null || this.invoiceRecordData.originalFileName == "") {
            //  this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceSaveValidationMessage);
            this.invoiceFileUploadRequiredValidation = true;
        }
        else {

            if (this.actionType == 'edit') {
                if (!this.CheckDataChange(this.invoiceunsavedRecordData)) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
                    return;
                }
            }
            this.isSaving = true;

            this._invoiceService.saveInvoiceData(formData).subscribe(result => {

                this.isSaving = false;

                if (result === -2) {//Duplicate Invoice Reference Number
                    this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceReferenceDuplicateMsg);
                }
                else {
                    console.log('Invoice Data is saved');

                    if (this.invoiceRecordData.invoiceId == 0) {
                        this.invoiceRecordData.invoiceId = result;
                    }

                    //Below these two line will clear the changed state of the form so that user can 
                    //be redirected back to list page without alert.
                    this.manageInvoiceForm.form.markAsPristine();
                    this.manageInvoiceForm.form.markAsUntouched();
                    if (this.actionType == this._invoiceActionAdd || this.actionType == this._invoiceActionCopy) {
                        this._toastservice.openToast(ToasterTypes.success, this._invoiceToastTitle, this._invoiceSavedMsg);
                    }
                    else {
                        this._toastservice.openToast(ToasterTypes.success, this._invoiceToastTitle, this._invoiceUpdedMsg);
                    }
                    this.viewInvoiceList();
                }
            }, err => {
                this.isSaving = false;
            });
        }
    }

    private CheckDataChange(row: InvoiceModel) {
        console.log(row);
        console.log(JSON.parse(JSON.stringify(this.invoiceRecordData)))
        if (row.referenceNumber == this.invoiceRecordData.referenceNumber && row.invoiceDate == this.invoiceRecordData.invoiceDate &&
            row.dealName == this.invoiceRecordData.dealName && row.paidDate == this.invoiceRecordData.paidDate &&
            row.dealIpdDate == this.invoiceRecordData.dealIpdDate && row.amount == this.invoiceRecordData.amount &&
            row.dealCurrency == this.invoiceRecordData.dealCurrency && row.invoiceCurrencyId == this.invoiceRecordData.invoiceCurrencyId &&
            row.dealCounterpartyId == this.invoiceRecordData.dealCounterpartyId && row.spotRateDate == this.invoiceRecordData.spotRateDate &&
            row.invoiceCategoryId == this.invoiceRecordData.invoiceCategoryId && row.invoiceCategoryTypeId == this.invoiceRecordData.invoiceCategoryTypeId &&
            row.spotRate == this.invoiceRecordData.spotRate && row.uploadedFileName == this.invoiceRecordData.uploadedFileName &&
            row.description == this.invoiceRecordData.description) {
            return false;
        }
        else
            return true;
    }

    viewInvoiceList() {
        this._route.parent.params.subscribe((params: Params) => {
            this.dealID = (params['dealId'] && params['dealId'] != null) ? params['dealId'] : null;
            this.dealRunID = (params['ipdRunId'] && params['ipdRunId'] != null) ? params['ipdRunId'] : null;

        });
        if (this.invoiceViewURL == 'view') {
            this._router.navigate([this._viewInvoiceListInvoiceNavPath + this.dealID + '/' + this.dealRunID + '/invoices/'], { relativeTo: this._route });
        }
        else {
            this._router.navigate([this._viewInvoiceListNavPath], { relativeTo: this._route });
        }
    }

    //Fetch category type, category and counterpary
    loadDealList() {
        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealList.toString()).subscribe(result => {
            console.log('deal name Fetched:');
            this.dealNameList = result;
            console.log(this.dealNameList);

            //Now load the counterparty
            if (this.isEditInvoice()) {
                this.getCounterparty();
                this.getDealIpd();
            }
        });
    }

    getInvoiceCategoryType() {
        this._invoiceService.getInvoiceCategoryType().subscribe(result => {
            console.log('Invoice category fetched:');
            this.invoiceCatTypeList = result;
            console.log('Invoice Category Type');
            console.log(this.invoiceCatTypeList);

            //Now load the invoice category
            if (this.isEditInvoice()) {
                this.getInvoiceCategory();
            }
        });
    }

    getInvoiceCategory() {
        this._invoiceService.getInvoiceCategory(this.invoiceRecordData.invoiceCategoryTypeId).subscribe(result => {
            console.log('Invoice category fetched:');
            this.invoiceCategoryList = result;
            console.log(this.invoiceCategoryList);
        });
    }

    getCounterparty() {
        this._invoiceService.getDealCounterparty(this.invoiceRecordData.dealId).subscribe(result => {
            console.log('Counterparty is fetched:');
            this.counterpartyList = result;
            console.log(this.counterpartyList);
        });
    }

    onInvoiceCategoryTypeChange(event: any) {
        console.log('Invoice category type change');
        this.invoiceRecordData.invoiceCategoryId = null;
        if (event) {
            this.invoiceRecordData.invoiceCategoryTypeId = event.invoiceCategoryTypeId;
            this.getInvoiceCategory();
        }
    }

    onDealDropDownChange(event: any) {
        this.invoiceRecordData.dealCounterpartyId = null;
        this.invoiceRecordData.dealIpdDate = null;
        //this.selectedDealName = event.value.toLowerCase()
        if (this.counterpartyList) {
            this.counterpartyList = [];
        }
        if (event) {
            this.invoiceRecordData.dealId = event.key;
            this.getCounterparty();
            this.getDealIpd();
            this.getDealCurrency(event.key);

        }
    }

    getDealCurrency(dealId: number) {
        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.DealCurrency.toString()).subscribe(result => {
            let currency = result?.filter(x => x.key == dealId);
            if (currency) {
                this.dealCurrency = currency[0].value;
            }
            this.isDealInVoiceCurrencyCompare();
        });
    }

    getDealIpd() {
        this._ipdManagementService.getDealNextIpd(this.invoiceRecordData.dealId).subscribe(result => {
            console.log('Deal IPD is fetched:');
            this.dealIpdList = result;
            this.dealIpdList.sort((val1, val2) => { return +new Date(val2.ipdDate) - +new Date(val1.ipdDate) });
        });
    }

    validateUploadedFileExtension(fileName: string) {
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
        if (this._allowedFiles.some(x => x === ext.toLowerCase()))
            return true;
        else
            return false;
    }

    setInvoiceFileUploadControlInvalid() {
        this.manageInvoiceForm.form.controls["uploadInvoiceReceipt"].markAsDirty();
        this.manageInvoiceForm.form.controls["uploadInvoiceReceipt"].markAsTouched();
        this.manageInvoiceForm.form.controls["uploadInvoiceReceipt"].setErrors({ 'incorrect': true });
        this.invoiceFileUploadRequiredValidation = true;
        this.invoiceRecordData.originalFileName = '';
    }

    handleInvoiceFileInput(event: any, files: FileList) {
        if (event && event.target.files) {
            let file = event.target.files.item(0);
            if (!this.validateUploadedFileExtension(file.name)) {
                this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceReceiptInvalidFileFormatMsg);
                event.srcElement.value = '';
                this.setInvoiceFileUploadControlInvalid();
                return false;
            }
            if (file.size > this._maxAllowedFileSiz) {
                this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceReceiptSizeExceedMsg);
                event.srcElement.value = '';
                this.setInvoiceFileUploadControlInvalid();
                return false;
            }
            if (file.size == 0) {
                this._toastservice.openToast(ToasterTypes.error, this._invoiceToastTitle, this._invoiceReceiptSizeBlankMsg);
                event.srcElement.value = '';
                this.invoiceFileUploadRequiredValidation = true;
                this.invoiceRecordData.originalFileName = '';
                return false;
            }

            //When all validation passed, set the file name
            this.invoiceFileToUpload = file;
            this.invoiceRecordData.originalFileName = this.invoiceFileToUpload.name;
            this.invoiceFileUploadRequiredValidation = false;
        }
    }


    setUpUserRolesAndPermissions() {
        this.loggedInUser = this._userService.getCurrentLoginUser();

        this.canView = this._userService.getPermissionAccess(PermissionEnum.CW_InvoiceMgmt, PermissionAccessTypeEnum.View);
        this.canUpdate = this._userService.getPermissionAccess(PermissionEnum.CW_InvoiceMgmt, PermissionAccessTypeEnum.AddEdit);
        this.canDelete = this._userService.getPermissionAccess(PermissionEnum.CW_InvoiceMgmt, PermissionAccessTypeEnum.Delete);
        this.canAuthorized = this._userService.getPermissionAccess(PermissionEnum.CW_InvoiceMgmt, PermissionAccessTypeEnum.ApproveReject);
    }

    onMinerAmendment() {
        this.minerAmendmentClicked = true;
    }

    onCancel() {
        this.minerAmendmentClicked = false;
    }

    loadCurrency() {


        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.CurrencyList.toString()).subscribe(result => {
            this.currencyList = result;
            this.isDealInVoiceCurrencyCompare();
        });


    }
}
