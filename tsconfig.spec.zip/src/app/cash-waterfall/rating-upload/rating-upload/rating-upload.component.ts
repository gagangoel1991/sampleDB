import { Component, ElementRef, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { SelectListEnum, SelectLookupModel } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { subString } from 'src/app/shared/pipes/sub-string.pipe';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { FormsModule, NgForm } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Deal, DealIpdDates, IpdDate, ParsedResult } from '../../ipd-run-process/model/rating-upload.model';
import { RatingUploadDataService } from '../../ipd-run-process/service/rating-upload.service';
import { NgbActiveModal } from '@ng-bootstrap/ng-bootstrap';
import { IpdManagementService } from '../../ipd-management/service/ipd-management.service';
import { UserRoleService } from '../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';

@Component({
  selector: 'sfp-user-rating-upload',
  templateUrl: './rating-upload.component.html',
  styleUrls: ['./rating-upload.component.scss'],
  providers: [RatingUploadDataService, subString, NgbActiveModal, IpdManagementService],
  encapsulation: ViewEncapsulation.None,
})
export class RatingUploadComponent implements OnInit {

  @ViewChild('manageRatingForm') manageRatingForm: NgForm;
  @ViewChild('inputFile') ratingInputFileVariable: ElementRef;

  public dealNameList: Array<SelectLookupModel> = [];

  public loadStartedCallsCount = 0;
  public loadCompletedCallsCount = 0;
  public selectedDeal = '';
  public selectedIpdDate;
  public comment = '';

  public dealIpdDatesArray: Array<DealIpdDates> = [];
  public ratingFileToUpload: File = null;
  public dealList: Array<Deal> = [];
  public ipdDateList: Array<IpdDate> = [];


  private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);
  public disableIpdDate: boolean = true;
  private readonly _allowedFiles = ['csv', 'xls', 'xlsx'];
  private readonly _ratingToastTitle = 'Rating';
  private readonly _ratingInvalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file types are csv, xls and xlsx.';
  private readonly _ratingFileSizeExceedMsg = 'Rating file size cannot exceed 20MB.';
  private readonly _ratingFileSaveMsg = 'Rating data saved successfully.';
  private readonly _ratingFileSaveErrorMsg = 'Rating data not saved successfully.';
  private readonly _ratingFileNoRowsMsg = 'No rating rows are available to save.';
  private readonly _ratingDealParseErrorMsg = 'Deal is required before parsing.';
  private readonly _ratingFileRequiredErrorMsg = 'Please provide input to all required fields.';
  public ratingFileUploadRequiredValidation: boolean = false;
  private readonly _viewUploadedRatingList = '/cashwaterfall/userrating/';
  private readonly _templateFileDownloadedMsg = 'Sample Rating Upload file is successfully downloaded.';


  public parsedResult: ParsedResult;
  public parsedColumnArray = [];
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  public parsingRequestLoader = false;


  constructor(private _ratingUploadDataService: RatingUploadDataService,
    private _subString: subString,
    private _router: Router,
    public _toastservice: GlobalToasterService,
    private _route: ActivatedRoute,
    public modal: NgbActiveModal,
    private _ipdManagementService: IpdManagementService,
    private _userService: UserRoleService) { }

  ngOnInit(): void {
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.Delete);

    // this.ratingModelData = new RatingModel();
    this.parsedResult = new ParsedResult();
    this.loadDealList();
  }

  loadDealList() {
    this._ratingUploadDataService.getDealIpdDates().subscribe(
      result => {
        this.dealIpdDatesArray = JSON.parse(JSON.stringify(result));//deep copy
        this.createDealList();
        this.createIpdDateList(-1);
      },
      undefined,
      () => {
        this.loadCompletedCallsCount = this.loadCompletedCallsCount + 1;
      });
  }

  createDealList() {
    this.dealIpdDatesArray.forEach(x => {
      var y = JSON.parse(JSON.stringify(x));
      delete y['ipdDate'];
      this.dealList.push(y);
    });
    this.dealList = Array.from(new Set(this.dealList.map(x => JSON.stringify(x)))).map(y => JSON.parse(y));
  }

  createIpdDateList(dealId: number) {
    this.ipdDateList = [];
    this.selectedIpdDate = null;
    this.dealIpdDatesArray.forEach(x => {
      var y = JSON.parse(JSON.stringify(x));
      if (dealId == y.dealId) {
        delete y['dealId'];
        delete y['dealName'];
        this.ipdDateList.push(y);
      }
    });
    this.ipdDateList = Array.from(new Set(this.ipdDateList.map(x => JSON.stringify(x)))).map(y => JSON.parse(y));
    this.ipdDateList.sort((val1, val2) => { return +new Date(val2.ipdDate) - +new Date(val1.ipdDate) });
  }

  public onDealChange(selectedDeal: Deal) {
    if (selectedDeal == undefined) {
      this.selectedIpdDate = null;
    }

    let dealId = selectedDeal == undefined ? undefined : selectedDeal.dealId;
    this.ratingInputFileVariable.nativeElement.value = '';
    this.ratingFileToUpload = null;
    this.parsedResult = new ParsedResult();
    this.createIpdDateList(dealId);
  }

  public handleRatingFileInput(event: any) {
    if (this.selectedDeal == '' || this.selectedDeal == null) {
      this.ratingInputFileVariable.nativeElement.value = '';
      this._toastservice.openToast(ToasterTypes.info, this._ratingToastTitle, this._ratingDealParseErrorMsg);
      return;
    }
    else if (event && event.target.files) {
      let file = event.target.files.item(0);
      if (!this.validateUploadedFileExtension(file.name)) {
        this._toastservice.openToast(ToasterTypes.error, this._ratingToastTitle, this._ratingInvalidFileFormatMsg);
        event.srcElement.value = '';
        this.setInvoiceFileUploadControlInvalid();
        return false;
      }
      if (file.size > this._maxAllowedFileSiz) {
        this._toastservice.openToast(ToasterTypes.error, this._ratingToastTitle, this._ratingFileSizeExceedMsg);
        event.srcElement.value = '';
        this.setInvoiceFileUploadControlInvalid();
        return false;
      }

      //When all validation passed, set the file name
      this.ratingFileToUpload = file;
      this.ratingFileUploadRequiredValidation = false;


      this.processRating();


    }
  }
  processRating() {
    if (this.selectedDeal == '' || this.selectedDeal == null) {
      this._toastservice.openToast(ToasterTypes.info, this._ratingToastTitle, this._ratingDealParseErrorMsg);
      return;
    }
    else {
      const formData: FormData = new FormData();
      formData.append('dealId', this.selectedDeal);
      formData.append('ratingFileAsByte', this.ratingFileToUpload, this.ratingFileToUpload.name);
      this.parsingRequestLoader = true;
      this._ratingUploadDataService.processRating(formData).subscribe(
        result => {
          console.log(result);
          this.parsedResult = JSON.parse(JSON.stringify(result));
          if (this.parsedResult.parsedTable.length > 0)
            this.parsedColumnArray = Object.keys(this.parsedResult.parsedTable[0]);
        },
        undefined,
        () => {
          this.parsingRequestLoader = false;
          this.loadCompletedCallsCount = this.loadCompletedCallsCount + 1;
        });
    }
  }


  setInvoiceFileUploadControlInvalid() {
    this.manageRatingForm.form.controls["uploadRatingFile"].markAsDirty();
    this.manageRatingForm.form.controls["uploadRatingFile"].markAsTouched();
    this.manageRatingForm.form.controls["uploadRatingFile"].setErrors({ 'incorrect': true });
    this.ratingFileUploadRequiredValidation = true;
  }


  public onSaveRatingClick() {

    if (this.manageRatingForm.valid == false || this.ratingFileToUpload == null) {
      this.ratingFileUploadRequiredValidation = this.ratingFileToUpload == null ?? true;

      if (this.comment.replace(/\s/g, "").toLowerCase().length <= 0) {
        this.manageRatingForm.form.controls['desc'].setErrors({ 'required': true });
      }
      for (var i in this.manageRatingForm.controls) {
        this.manageRatingForm.controls[i].markAsTouched();
      }
      this._toastservice.openToast(ToasterTypes.error, this._ratingToastTitle, this._ratingFileRequiredErrorMsg);
    }

    else {

      if (this.parsedResult.discardedRowsCount < this.parsedResult.totalRowsCount) {
        this.CheckUploadRatingDataRecordExist();
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, this._ratingToastTitle, this._ratingFileNoRowsMsg);
      }
    }
  }


  CheckUploadRatingDataRecordExist() {

    const formData: FormData = new FormData();
    formData.append('dealId', this.selectedDeal);
    formData.append('collectionDate', this.selectedIpdDate);

    this._ratingUploadDataService.uploadRatingDataRecordExist(formData).subscribe(
      result => {
        if (result) {
          if (confirm(' Rating File already exit for the selected "Deal" and "Collection Date".\nDo you want to Discard previously uploaded file and override with new file?')) {
            this.SaveRatingData();
          }
        }
        else {
          this.SaveRatingData();
        }
      },
      undefined,
      undefined);

  }

  SaveRatingData() {

    const formData: FormData = new FormData();
    formData.append('ratingFileAsByte', this.ratingFileToUpload, this.ratingFileToUpload.name);
    formData.append('dealId', this.selectedDeal);
    formData.append('collectionDate', this.selectedIpdDate);
    formData.append('comment', this.comment);

    if (this.comment.replace(/\s/g, "").toLowerCase().length <= 0) {
      //  this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._saveValidationMessage);
      this.manageRatingForm.form.controls['desc'].setErrors({ 'required': true });
    }
    else {
      this._ratingUploadDataService.saveRating(formData).subscribe(
        result => {
          if (result > 0) {
            this._toastservice.openToast(ToasterTypes.info, this._ratingToastTitle, this._ratingFileSaveMsg);
            this.viewUploadedRatingList();
          }
          else {
            this._toastservice.openToast(ToasterTypes.error, this._ratingToastTitle, this._ratingFileSaveErrorMsg);
          }
        },
        undefined,
        undefined
      );
    }
  }

  public viewUploadedRatingList() {
    this._router.navigate([this._viewUploadedRatingList], { relativeTo: this._route });
  }


  validateUploadedFileExtension(fileName: string) {
    var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
    if (this._allowedFiles.some(x => x === ext.toLowerCase()))
      return true;
    else
      return false;
  }

  downloadTemplateFile() {
    this._ratingUploadDataService.downloadRatingSampleFile().subscribe(blob => {
      if (blob == null) {
        this._toastservice.openToast(ToasterTypes.error, "File not found", "Sample file is missing.");
        return;
      }
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl
      a.download = "RatingUpload_yyyymmdd.csv";
      a.click();
      URL.revokeObjectURL(objectUrl);
      this._toastservice.openToast(ToasterTypes.success, this._ratingToastTitle, this._templateFileDownloadedMsg);
    });
  }
}