import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { GlobalToasterService } from 'src/app/shared/services/globaltoaster.service';
import { RatingSavedDataModel } from '../../ipd-run-process/model/rating-upload.model';
import { RatingUploadDataService } from '../../ipd-run-process/service/rating-upload.service';



@Component({
  selector: 'sfp-rating-view',
  templateUrl: './rating-view.component.html',
  styleUrls: ['./rating-view.component.scss'],
  providers: [RatingUploadDataService]
})
export class RatingViewComponent implements OnInit {

  public ratingSavedData: RatingSavedDataModel;

  public loadCompleted = false;
  private userRatingFileUploadDetailId = 0;
  public columnArray = [];
  private readonly _viewUploadedRatingList = '/cashwaterfall/userrating/';

  constructor(private _ratingUploadDataService: RatingUploadDataService, private _router: Router,
    public _toastService: GlobalToasterService, private _route: ActivatedRoute) { }


  ngOnInit(): void {

    this.ratingSavedData = new RatingSavedDataModel();

    this._route.params.subscribe((params: Params) => {

      if (params['userRatingFileUploadDetailId'] == "" || params['userRatingFileUploadDetailId'] == null || isNaN(params['userRatingFileUploadDetailId'])) {
        alert("Wrong userRatingFileUploadDetailId ");
        this.viewUploadedRatingList();
      } else {
        this.userRatingFileUploadDetailId = params['userRatingFileUploadDetailId'];
        this.getUserRatingSavedData();
      }

    });

  }

  getUserRatingSavedData() {
    this._ratingUploadDataService.getUserRatingSavedData(this.userRatingFileUploadDetailId).subscribe(
      result => {
        console.log(result);
        this.ratingSavedData = JSON.parse(JSON.stringify(result));
        if (this.ratingSavedData.ratingData.length > 0)
          this.columnArray = Object.keys(this.ratingSavedData.ratingData[0]);
      },
      undefined,
      () => {
        this.loadCompleted = true;
      });

  }


  public downloadRatingFile() {   
    this._ratingUploadDataService.downloadRatingFile(this.ratingSavedData.originalFileName, this.ratingSavedData.uploadedFileName).subscribe(
      data => {       
        var blob = new Blob([this.s2ab(atob(data))], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
        });      

        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = this.ratingSavedData.originalFileName;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

      
      },
      undefined,
      () => {
        this.loadCompleted = true;
      });

  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  public viewUploadedRatingList() {
    this._router.navigate([this._viewUploadedRatingList], { relativeTo: this._route });
  }

}
