
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Column, FieldType, Formatters } from 'angular-slickgrid';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { downloadLinkFormatter, hyperLinkFormatter, ratingActionButtonFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { RatingUploadDataService } from '../../ipd-run-process/service/rating-upload.service';
import { UserRoleService } from '../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';


@Component({
  selector: 'sfp-user-rating-upload-listing',
  templateUrl: './rating-upload-listing.component.html',
  styleUrls: ['./rating-upload-listing.component.scss'],
  providers: [RatingUploadDataService],
  encapsulation: ViewEncapsulation.None,
})//-- Action Buttons Formatter--

export class RatingUploadListingComponent implements OnInit {

  public exportFileName = 'UserUploadedRatingList';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  // private readonly _editBuildDealNavPath = '/dealconfig/deal/edit/';
  // private readonly _copyBuildDealNavPath = '/dealconfig/deal/copy/';
  private readonly _viewRatingNavPath = '/cashwaterfall/userrating/view/';
  private readonly _uploadRatingNavPath = '/cashwaterfall/userrating/upload/';


  private readonly _ratingListToastTitle = "User Uploaded Rating List";
  private readonly _ratingListToastDelete = "Record Deleted Successfully";
  private readonly _ratingListToastDeleteError = "Record Not Deleted Successfully";
  private readonly _ratingListToastDeleteNotAllowed = 'You can not delete.';

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  //-------Slick Grid Variables End--------------

  constructor(private _sharedDataService: SharedDataService,
    private _ratingUploadDataService: RatingUploadDataService,
    private _router: Router,
    public _toastService: GlobalToasterService,
    private _route: ActivatedRoute,
    private _userService: UserRoleService) { }

  ngOnInit(): void {
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_RatingUpload], PermissionAccessTypeEnum.Delete);
    this.bindDealColumns();
    this.bindDealActionsCallBack();
    this.bindDealList();
    this.slickDefaultActionButtons = false;
  }

  bindDealColumns() {
    if (this.isAddEditAccess) {
      this.slickColumnArray.push
        (
          new SFP_SlickColumn('', 'Actions', false, false, 100, FieldType.string, ratingActionButtonFormatter)
        )
    }
    this.slickColumnArray.push
      (
        new SFP_SlickColumn('dealName', 'Deal Name', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.singleSelect),
        new SFP_SlickColumn('collectionDate', 'Collection Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('uploadedBy', 'Uploaded By', true, true, 125, FieldType.string, undefined, SFP_SlickFilterType.singleSelect),
        new SFP_SlickColumn('uploadedDate', 'Uploaded Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('originalFileName', 'File Name', true, true, 175, FieldType.string, downloadLinkFormatter),
      );
  }

  bindDealList() {
    this._ratingUploadDataService.getRatingListingData().subscribe(result => {
      this.slickDataset = JSON.parse(JSON.stringify(result)); //deep copy  
    });
  }

  bindDealActionsCallBack() {
    var objSFP_SlickAction = new SFP_SlickAction(
      this.onviewAction,
      null,
      null,
      {
        deleteFunc: this.onDeleteAction,
        title: "Delete Rating Data confirmation.",
        message: template`Are you sure you want to delete rating data for Deal \'${'dealName'}\' and Collection Date \'${'collectionDate'}\'.`
      },
      this.onDownLoadAction
    );

    this.slickCallbackFuntions = objSFP_SlickAction;
  }

  //** Action Callback functions Start  */
  onviewAction(rowData: any, parentThis: any) {
    let userRatingFileUploadDetailId = rowData['ratingUploadDetailId'];
    parentThis._router.navigate([parentThis._viewRatingNavPath, userRatingFileUploadDetailId], { relativeTo: parentThis._route });
  }

  onDownLoadAction(rowData: any, parentThis: any) {
    let originalFileName = rowData['originalFileName'];
    let uploadedFileName = rowData['uploadedFileName'];
    parentThis.downloadRatingFile(originalFileName, uploadedFileName);
  }

  onDeleteAction(rowData: any, parentThis: any) {
    let userRatingFileUploadDetailId = rowData['ratingUploadDetailId'];
    parentThis._ratingUploadDataService.deleteRatingData(userRatingFileUploadDetailId).subscribe(result => {
      if (result > 0) {
        parentThis._toastService.openToast(ToasterTypes.info, parentThis._ratingListToastTitle, parentThis._ratingListToastDelete);
      }
      else {
        parentThis._toastService.openToast(ToasterTypes.error, parentThis._ratingListToastTitle, parentThis._ratingListToastDeleteError);
      }
      parentThis.bindDealList();
    });
  }

  //** Action Callback functions End  */

  navigateToUploadratingFile(): void {
    this._router.navigate([this._uploadRatingNavPath], { relativeTo: this._route })
  }



  public downloadRatingFile(originalFileName: string, uploadedFileName: string) {
    this._ratingUploadDataService.downloadRatingFile(originalFileName, uploadedFileName).subscribe(
      data => {

        var blob = new Blob([this.s2ab(atob(data))], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
        });

        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = originalFileName;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

      },
      undefined,
      () => {

      });

  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }


}

