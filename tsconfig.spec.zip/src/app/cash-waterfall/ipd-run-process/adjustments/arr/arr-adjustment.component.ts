import { Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, NgForm } from '@angular/forms';
import { ActivatedRoute, NavigationStart, Params, Router } from '@angular/router';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { CashwaterfallLineItemModel, IpdAdjustmentParams } from '../../../ipd-run-process/model/cash-waterfall-line-item-model';
import { AdjustmentWaterfallService } from '../../service/adjustment-waterfall.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from 'src/app/shared/components/confirm-common-popup/sfp-common-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { DealNameEnum } from 'src/app/shared/enum/deal-name-enum';
import _ from 'lodash';
import { Subscription } from 'rxjs';

@Component({
  selector: 'sfp-cw-adjustment',
  templateUrl: './arr-adjustment.component.html',
  styleUrls: ['./arr-adjustment.component.scss'],
  providers: [AdjustmentWaterfallService]
})
export class ARRAdjustmentComponent extends CanDeactivateForm implements OnInit, OnDestroy {
  //Adjustment Messages
  private readonly _arrToastTitle = 'Adjustment';
  public readonly _arrSavedMsg = 'Available Revenue adjustments are updated successfully.';
  public readonly _arrNoDataErrorMsg = 'No data is available for save.';
  private readonly _arrSaveErrorMsg = 'Issue occurs while saving the data.';
  public readonly _arrNoSavedMsg = 'No change has been made. Please make change in order to save.';
  private readonly _ipdNotAllowedChangesMsg = 'Adjustment cannot be saved, IPD status is either authorised or pending-authorisation.';
  private readonly _negativeValueErrorMsg = 'Total Values cannot be negative.';
  private readonly _negativeSignErrorMsg = 'Please enter numeric value in Adjustment.';
  private readonly _sumRequireLineItemGroup = 'required';
  private readonly _sumAdjusmentLineItemGroup = 'adjustment';
  private readonly _sumTotalLineItemGroup = 'total';

  public arrLineItemList: Array<CashwaterfallLineItemModel> = [];
  public exportArrLineItemList: Array<CashwaterfallLineItemModel> = [];
  public isDataChangesAllow: boolean = true;
  public isAdjustmentHasValue: boolean = false;
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;

  public startedRequests: number = 0;
  public completedRequests: number = 0;

  @ViewChild('arrAdjustmentForm') arrAdjustmentForm: NgForm;
  @ViewChild('arrAdjustmentForm') confirmUnsavedForm: NgForm;

  ipdParams: IpdAdjustmentParams;
  public sumRequired: number = 0;
  public sumAdjustment: number = 0;
  public sumTotalRequired: number = 0;
  private readonly maxRangeValue = 10000000000000000;
  private readonly minRangeValue = -10000000000000000;
  public headers: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();

  private _routerEvent = Subscription.EMPTY;

  constructor(private router: Router, private _adjustmentWaterfallService: AdjustmentWaterfallService,
    private _ipdProcessService: IpdProcessParentService,
    public _toastservice: GlobalToasterService,
    private _fb: FormBuilder, private ref: ChangeDetectorRef,
    private _modalService: NgbModal,
    private _route: ActivatedRoute,
    private _userService: UserRoleService) {

    super();
    //Updating that Adjustements tab has been clicked to notify to parent component
    // this._ipdProcessService.changeIpdLevel1MenuName('adjustments');
    // this._buildForm();

    this.ipdParams = new IpdAdjustmentParams(0, 0, null);
    this.startedRequests += 1;
    this._route.params.subscribe((params: Params) => {
      this._ipdProcessService.changeIpdLevel1MenuName('adjustments');
      console.log('ARR adjustment constructor called.');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this.router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
      this.completedRequests += 1;
    });

    this.ipdParams.waterfallCategoryName = (this.ipdParams.dealId == DealNameEnum.DEIMOS ? "PreAvailableRevenueReceipts" : "PostAvailableRevenueReceipts");

  }

  expandParentLineItem(isExpandable: boolean, parentWaterfallLineItemId: number) {
    let data = this.arrLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
    });

    console.log(data);

    data = this.arrLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 1);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
    });
    console.log(data);
  }

  setFormArray() {
    this.arrLineItemList.forEach(x => {
      x.isRowVisible = !(x.isSubLineItems == 0 && x.parentWaterfallLineItemId > 0) ? true : false
    });
  }
  ngOnInit(): void {
    this.loadARRWaterfallData();
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
    this._routerEvent = this.router.events.subscribe(
      (event) => {
        if (event instanceof NavigationStart) {
          // Handle Navigation Start
          if (!this.isDataChanged(this.arrLineItemList)) {
            this.arrAdjustmentForm.form.markAsPristine();
            this.arrAdjustmentForm.form.markAsUntouched();
          }
        }
      });
  }

  ngOnDestroy(): void {
    this._routerEvent.unsubscribe()
  }

  onAdjustmentValueChange($event, waterfallLineItemAmountId: number): void {
    console.log($event);

    let data = this.arrLineItemList.filter(x => x.waterfallLineItemAmountId == waterfallLineItemAmountId);
    console.log(data);
    console.log(waterfallLineItemAmountId);
    data.forEach(x => {
      x.totalRequiredAmount = Number(x.adjustedAmount) + Number(x.requiredAmount);
      x.isAdjustmentEdited = true;
      this.updateParentLineItemAmountAdjustmentEdited(x.parentWaterfallLineItemId);
    });
    console.log(data);

    this.sumLineItemValue();
  }

  updateParentLineItemAmountAdjustmentEdited(parentWaterfallLineItemId: number) {
    let data = this.arrLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 1);
    data.forEach(x => {
      x.isAdjustmentEdited = true;
    });
  }

  sumLineItemValue(): void {
    let data = this.arrLineItemList.filter(z => z.lineItem != 'Total');
    if (data.length > 0) {
      this.sumRequired = data.map(a => a.requiredAmount).reduce(function (a, b) { return a + b; });
      this.sumAdjustment = data.filter(a => a.adjustedAmount.toString() != '-')
        .map(a => Number(a.adjustedAmount)).reduce(function (a, b) { return Number(a) + Number(b); });
      this.sumTotalRequired = this.sumRequired + Number(this.sumAdjustment);
    }
  }

  sumLineItemGroupValue(parentWaterfallLineItemId: number, sumOf: string): number {

    let data = this.arrLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId);
    let sumGroupRequired: number = 0;
    let sumGroupAdjustment: number = 0;
    let sumGroupTotalRequired: number = 0;

    if (data.length > 0) {
      sumGroupRequired = data.map(a => a.requiredAmount).reduce(function (a, b) { return a + b; });
      sumGroupAdjustment = data.map(a => Number(a.adjustedAmount)).reduce(function (a, b) { return Number(a) + Number(b); });
      sumGroupTotalRequired = sumGroupRequired + sumGroupAdjustment;
    }


    if (sumOf === this._sumRequireLineItemGroup)
      return sumGroupRequired;
    if (sumOf === this._sumAdjusmentLineItemGroup)
      return sumGroupAdjustment;
    if (sumOf === this._sumTotalLineItemGroup)
      return sumGroupTotalRequired;
  }

  loadARRWaterfallData() {
    if (this.confirmUnsavedForm) {
      this.confirmUnsavedForm.reset();
    }
    this.arrLineItemList = [];
    this.startedRequests += 1;
    this._adjustmentWaterfallService.getPrincipalWaterfallData(this.ipdParams).subscribe(data => {
      this.arrLineItemList = data;
      this.exportArrLineItemList = JSON.parse(JSON.stringify(this.arrLineItemList)); //Deep Copy
      this.setFormArray();
      this.sumLineItemValue();
      this.verifyAdjustmentHasValue();
      this.completedRequests += 1;
    }, (error: any) => {
      console.log(error);
    });
  }

  verifyAdjustmentHasValue() {
    this.isAdjustmentHasValue = this.arrLineItemList.filter(z => (z.adjustedAmount != 0)).length > 0 ? true : false;
  }

  saveARRWaterfall() {
    if (!this.arrAdjustmentForm.dirty) {
      this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._arrNoSavedMsg);
    }
    else {
      let data = this.arrLineItemList;

      let arrdata = this.arrLineItemList.filter(z => z.lineItem == 'Total');
      let arrdataindex = this.arrLineItemList.findIndex(z => z.lineItem == 'Total');
      if (arrdata.length > 0) {
        data[arrdataindex].requiredAmount = this.sumRequired;
        data[arrdataindex].adjustedAmount = this.sumAdjustment;
        data[arrdataindex].totalRequiredAmount = this.sumTotalRequired;

      }

      if (data.length <= 0) {
        this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._arrNoDataErrorMsg);
      } else if (!this.isDataChanged(data)) {
        this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._arrNoSavedMsg);
      } else if (this.isRangeViolate()) {
        this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, 'Amount limit has been exceeded, Please enter valid adjustment value.');
      } else if (this.isNegativeValue()) {
        this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._negativeValueErrorMsg);
      } else if (this.isNegativeSign()) {
        this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._negativeSignErrorMsg);
      }
      else {

        this.startedRequests += 1;
        this._adjustmentWaterfallService.savePrincipalWaterfall(data).subscribe(result => {
          if (result === 0) { // adjustment is not saved
            this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._arrSaveErrorMsg);
          }
          if (result === 2) { // When adjustment is not allowed to save due to the IPD status either authorised or Pending-Authorisation
            this._toastservice.openToast(ToasterTypes.error, this._arrToastTitle, this._ipdNotAllowedChangesMsg);
            this.arrAdjustmentForm.form.markAsPristine();
            this.arrAdjustmentForm.form.markAsUntouched();
            this.isDataChangesAllow = false;
            this.loadARRWaterfallData();
          }
          else {
            this.arrAdjustmentForm.form.markAsPristine();
            this.arrAdjustmentForm.form.markAsUntouched();
            this.verifyAdjustmentHasValue();
            this._toastservice.openToast(ToasterTypes.success, this._arrToastTitle, this._arrSavedMsg);
            this.loadARRWaterfallData();
          }
          this.completedRequests += 1;
        }, (error: any) => {
          console.log(error);
        });
      }

    }

  }

  isRangeViolate(): boolean {
    let attribute = this.arrLineItemList.filter(x => x.adjustedAmount > this.maxRangeValue
      || x.adjustedAmount < this.minRangeValue);

    if (attribute.length > 0) {
      return true;
    }

    return false;
  }

  isNegativeValue(): boolean {
    let attribute = this.arrLineItemList.filter(x => x.totalRequiredAmount < 0);

    if (attribute.length > 0) {
      return true;
    }

    return false;
  }

  isNegativeSign(): boolean {
    let attribute = this.arrLineItemList.filter(x => x.adjustedAmount.toString() == '-');

    if (attribute.length > 0) {
      return true;
    }

    return false;
  }

  isDataChanged(data: Array<CashwaterfallLineItemModel>): boolean {
    for (let i = 0; i < data.length; i++) {
      let waterfallLineItemAmountId = data[i].waterfallLineItemAmountId;
      //It Return always single value
      let orignalValues = this.exportArrLineItemList.filter(function (ele) {
        return ele.waterfallLineItemAmountId == waterfallLineItemAmountId;
      });
      //If any condition pass then value has been modified
      if (orignalValues[0].adjustedAmount != data[i].adjustedAmount) {
        return true;
      }
    }
    return false;
  }

  exportToExcel() {

    this.headers.push(new HeaderCollectionModel('lineItem', 'Waterfall Line Item'));
    this.headers.push(new HeaderCollectionModel('requiredAmount', 'Calculated', 'currency'));
    this.headers.push(new HeaderCollectionModel('adjustedAmount', 'Adjustment', 'currency'));
    this.headers.push(new HeaderCollectionModel('totalRequiredAmount', 'Total', 'currency'));
    this.headers.push(new HeaderCollectionModel('modifiedBy', 'Modified By'));
    this.headers.push(new HeaderCollectionModel('modifiedDate', 'Modified Date', 'date'));

    let sourceData = JSON.parse(JSON.stringify(this.exportArrLineItemList)); //Deep Copy
    Object.keys(sourceData).map(
      function (object) {
        if (sourceData[object]["isSubLineItems"] > 0) {
          let parentid = sourceData[object]["parentWaterfallLineItemId"];
          let data1 = sourceData.filter(x => x.isSubLineItems == 0 && x.parentWaterfallLineItemId == parentid);
          data1.forEach(element => {
            sourceData[object]["requiredAmount"] = sourceData[object]["requiredAmount"] + element.requiredAmount
            sourceData[object]["adjustedAmount"] = sourceData[object]["adjustedAmount"] + element.adjustedAmount
            sourceData[object]["totalRequiredAmount"] = sourceData[object]["totalRequiredAmount"] + element.totalRequiredAmount
          });
        }
      });
    this.exportExcelUtility.exportDataToExcel(this.headers, sourceData, "Adjustments-AvailableRevenueReceiptsData.xlsx");

  }

  confirmBox() {

    let popupCfg = new CommonPopupConfigModel(`Reset ${this._arrToastTitle}`, `Do you want to reset the adjustments? If you will click on 'OK' it will reset the adjustments amount to zero and save the data.`);

    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

  reset() {
    let data = this.arrLineItemList;
    data.forEach(x => {
      x.adjustedAmount = 0;
      x.totalRequiredAmount = Number(x.requiredAmount);
      x.isAdjustmentReset = true;
    });
    this.sumLineItemValue();
    this.arrAdjustmentForm.form.markAsTouched();
    this.arrAdjustmentForm.form.markAsDirty();
    this.saveARRWaterfall();
  }

  allRequestCompleted(): boolean {
    return this.startedRequests == this.completedRequests && this.completedRequests > 0;
  }

}
