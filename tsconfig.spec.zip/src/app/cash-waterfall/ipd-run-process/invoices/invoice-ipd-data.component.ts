import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { InvoiceIpdDataService } from '../service/invoice-ipd-data.service';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { InvoiceIpdDataModel } from '../model/invoice-ipd-data-model';
import { ContextMenuComponent, ContextMenuService } from 'ngx-contextmenu';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { SfpGridContextMenuComponent } from '../../../shared/components/grid/contextMenu/grid-context-menu.component';
import { DatePipe } from '@angular/common';
import { SfpEditableGridColumnModel } from '../model/sfp-inline-edit-gridoption.model';
import { InvoiceManagementListComponent } from 'src/app/cash-waterfall/invoice-management/list/invoice-management-list.component';
import { IpdProcessParentService } from '../service/ipd-process-parent.service';
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { currencyFormatter, downloadLinkFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { UserRoleService } from '../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';


@Component({
  selector: 'cw-feed-invoice-data',
  templateUrl: './invoice-ipd-data.component.html',
  styleUrls: ['./invoice-ipd-data.component.scss'],
  providers: [OrderByPipe, InvoiceIpdDataService],
  encapsulation: ViewEncapsulation.None
})
export class InvoiceIpdDataComponent implements OnInit {
  public item: any;
  public columnMode = ColumnMode;
  public invoiceDataList: Array<InvoiceIpdDataModel> = [];
  public tempInvoiceDataList: Array<InvoiceIpdDataModel> = [];
  public invoiceDataGridCustomCols: Array<SfpEditableGridColumnModel> = [];
  public selectedSortCol = '';
  public colSortType = 'asc';
  public editing = {};
  public dealId: number;
  public ipdRunId: number
  public datePipe = new DatePipe('en-UK');
  public searchSubmitted = false;
  public title = 'Invoice Data';
  public isDataChangesAllow: boolean = true;
  public dealID: number;
  public dealRunID: number;
  public exportFileName = 'InvoiceData';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private readonly _formatDate = 'dd-MM-yyyy';
  private readonly _mangeInvoiceList = '/cashwaterfall/invoicemgmt/';
  private readonly _viewInvoiceNavPath = '/cashwaterfall/ipdrunprocess/';

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  public slickDefaultAuditButtons: boolean = true;
  //-------Slick Grid Variables End--------------

  //Messages
  private readonly _invoiceToastTitle = 'Invoice';
  private readonly _invoiceReceiptDownloadedMsg = 'Invoice receipt is downloaded successfully.';



  @ViewChild(SfpGridContextMenuComponent) rightClick: SfpGridContextMenuComponent;
  constructor(private _ipdProcessService: IpdProcessParentService,
    public _toastservice: GlobalToasterService,
    private _invoiceIpdDataService: InvoiceIpdDataService,
    private _contextMenuService: ContextMenuService
    , private ngxOrderPipe: OrderByPipe,
    private changeDetectorRef: ChangeDetectorRef,
    private _route: ActivatedRoute,
    private _router: Router,
    private _sharedDataService: SharedDataService,
    private _userService: UserRoleService) {
    //Updating that invoices tab has been clicked to notify to parent component
    this._ipdProcessService.changeIpdLevel1MenuName('invoices');
    this._route.params.subscribe((params: Params) => {
      console.log('IPD Invoice constructor called.');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
      console.log(this.dealId);
    });
  }
  ngAfterContentChecked() {
    this.changeDetectorRef.detectChanges();
  }
  ngOnInit(): void {
    this.bindInvoiceDataList();
    this.bindInvoiceActionsCallBack();
    this._route.params.subscribe(params => {
      this.dealID = params['dealId'];
      this.dealRunID = params['ipdRunId'];
    });
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_InvoiceMgmt], PermissionAccessTypeEnum.Delete);

  }

  private bindInvoiceDataList() {
    this.configureInvoiceDataGrid();
    this._invoiceIpdDataService.getInvoiceIpdData(this.dealId, this.ipdRunId).subscribe((result) => {
      this.invoiceDataList = result;
      this.slickDataset = JSON.parse(JSON.stringify(result)); //deep copy  
      console.log(result);
      this.invoiceDataList.forEach(val => this.tempInvoiceDataList.push(Object.assign({}, val)));
      this.applyDatePipe();
    });
    document.getElementById('preloader').style['display'] = 'none';
  }



  configureInvoiceDataGrid() {

    this.slickColumnArray.push
      (
        new SFP_SlickColumn('referenceNumber', 'Invoice Ref No', true, true, 180, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('invoiceCategoryType', 'Invoice Type', true, true, 100, FieldType.string),
        new SFP_SlickColumn('invoiceCategory', 'Invoice Category', true, true, 180, FieldType.string),
        new SFP_SlickColumn('description', 'Description', true, true, 180, FieldType.string),
        new SFP_SlickColumn('counterpartyName', 'Counterparty Name', true, true, 220, FieldType.string),
        new SFP_SlickColumn('amount', 'Amount', true, true, 100, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('originalFileName', 'Invoice Receipt', true, true, 175, FieldType.string, downloadLinkFormatter),
        new SFP_SlickColumn('paidDate', 'Invoice Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true)
      );

  }

  public getVisibleColumn() {
    const visibleColumns = this.invoiceDataGridCustomCols.filter(function (col) {
      return col.isChecked;;
    });
    return visibleColumns;
  }

  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  applyDatePipe() {
    this.invoiceDataGridCustomCols.forEach(customColumn => {
      if (customColumn.pipeFormatter === 'date') {
        this.invoiceDataList.forEach(gridDataRecord => {
          let valueToDateFormat = gridDataRecord[customColumn.columnName];
          gridDataRecord[customColumn.columnName] =
            (valueToDateFormat !== null) ? this.datePipe.transform(gridDataRecord[customColumn.columnName], this._formatDate)
              : '';
        });
      }
    });
  }

  public sfpGridColumnFilter(event, colName, colIdx) {
    if (this.invoiceDataList) {
      const visibleColumns = this.invoiceDataGridCustomCols.filter(function (col) {
        return col.isChecked;
      });

      const searchValue = event.target.value.toLowerCase();
      visibleColumns[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let filteredData = this.tempInvoiceDataList;
      visibleColumns.forEach(function (col) {
        if (col.filterText !== '' && filteredData.length > 0) {
          filteredData = filteredData.filter(function (row) {
            return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.invoiceDataList = filteredData;
    }
  }

  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }
    this.invoiceDataList = this.ngxOrderPipe.transform(this.invoiceDataList, filter);
  }

  bindInvoiceActionsCallBack() {
    this.slickCallbackFuntions = new SFP_SlickAction(
      this.onInvoiceTitleClickCallback,
      null,
      null,

      null,
      this.onDownLoadAction

    );
  }

  onInvoiceTitleClickCallback(record: any, currentThis: any = this) {

    console.log(this.dealRunID);
    console.log('View Invoice id : ' + record.invoiceId.toString());
    currentThis._router.navigate([currentThis._viewInvoiceNavPath + currentThis.dealId + '/' + currentThis.ipdRunId + '/invoices/view/', record.invoiceId], { relativeTo: currentThis._route });
  }

  onDownLoadAction(rowData: any, parentThis: any) {
    parentThis.downloadInvoiceReceipt(rowData, parentThis);
  }

  downloadInvoiceReceipt(record: InvoiceIpdDataModel, currentThis) {
    currentThis._invoiceIpdDataService.downloadInvoiceFile(record.invoiceId).subscribe(blob => {
      console.log('Invoice file blob');
      console.log(blob);
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl
      a.download = record.originalFileName;
      a.click();
      URL.revokeObjectURL(objectUrl);
      currentThis._toastservice.openToast(ToasterTypes.success, currentThis._invoiceToastTitle, currentThis._invoiceReceiptDownloadedMsg);
    });
  }

  reDirectToManageInvoice() {
    this._router.navigate([this._mangeInvoiceList + this.dealId + '/' + this.ipdRunId + '/'], { relativeTo: this._route });
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }
}
