import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { InvoiceIpdDataComponent } from './invoice-ipd-data.component';
import { InvoiceIpdDataService } from '../service/invoice-ipd-data.service';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { HttpClient } from '@angular/common/http';
import { DummyInvoiceList } from 'src/app/cash-waterfall/invoice-management/model/spec/mock-invoice-list.model';
import { of } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';

describe('InvoiceIpdDataComponent', () => {
    let fixture: ComponentFixture<InvoiceIpdDataComponent>;
    const dummyInvoiceData: any = DummyInvoiceList;
    let invoiceComponent: InvoiceIpdDataComponent;
    beforeEach(async(() => {
        const mockedInvoiceDataService = jasmine.createSpyObj('InvoiceDataService', ['getInvoiceData']);
        const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest']);
        TestBed.configureTestingModule({
            declarations: [
                InvoiceIpdDataComponent
            ],
            providers: [LogMaster, LogConsole, ConstantService, HttpClient
                , { provide: InvoiceIpdDataService, useValue: mockedInvoiceDataService }
                , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }

            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(InvoiceIpdDataComponent);
        const invoiceDataService = fixture.debugElement.injector.get(InvoiceIpdDataService);
        invoiceComponent.invoiceDataList = dummyInvoiceData;;
    });
    


    // spyOn(invoiceDataService, 'getInvoiceData').and.callFake(() => {
    //     return of(dummyInvoiceData);
    // });

    //Set the invoice record
    

    it('should create the app', async(() => {
        const fixture = TestBed.createComponent(InvoiceIpdDataComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app).toBeTruthy();
    }));
    it(`should have as title 'Invoice Data'`, async(() => {
        const fixture = TestBed.createComponent(InvoiceIpdDataComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app.title).toEqual('Invoice Data');
    }));

    it('should load/call invoice data async', async(() => {
        const invoiceDataService = fixture.debugElement.injector.get(InvoiceIpdDataService);

        //Call the component function
        // invoiceDataService.getInvoiceData(12, 1)
        // //Validate/Test the result
        // expect(expect(invoiceDataService.getInvoiceData(12, 1)).toHaveBeenCalled).toBeTruthy();
    }));
});