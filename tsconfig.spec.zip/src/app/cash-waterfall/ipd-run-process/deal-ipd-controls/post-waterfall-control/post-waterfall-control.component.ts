import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';
import { DealIpdBasicInfoModel } from '../../model/deal-ipd-basicinfo.model';
import { PostWaterfallControlEntity } from '../../model/post-waterfall-control.model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { PostWaterfallService } from '../../service/post-waterfall.service';

@Component({
  selector: 'sfp-post-waterfall-control',
  templateUrl: './post-waterfall-control.component.html',
  styleUrls: ['./post-waterfall-control.component.scss'],
  providers: [PostWaterfallService, DecimalPipe, DatePipe]
})
export class PostWaterfallControlComponent implements OnInit {

  private ipdParams: IpdAdjustmentParams;
  public dealIpdBasicInfoModel: DealIpdBasicInfoModel;
  public objPostWaterfallControlEntity: Array<PostWaterfallControlEntity>  = [];
  public postWaterfallReportReconcil: Array<PostWaterfallControlEntity>  = [];
  public postAP: number;
  public postPC: number;
  public postAR: number;
  public postRC: number;
   public postAPP:string;
   public postPCP:string;
   public postARR:string;
   public postRCR:string;
   public postPRecon:number;
   public postRRecon:number;
   public isDataRequestComplete = false;
  public isBasicInfoRequestComplete = false;
  public isFileDownloadStarted = false;
  public isExpanded = false;
  

  constructor(private _ipdProcessService: IpdProcessParentService,
    private _postWaterfallService: PostWaterfallService, private _route: ActivatedRoute,
    private _router: Router, private _decimalPipe: DecimalPipe, private _datePipe: DatePipe) {
    this._ipdProcessService.changeIpdLevel1MenuName('controls');
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });

    this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
      this.dealIpdBasicInfoModel = data;
    });

  }
  ngOnInit(): void {

    document.getElementById('preloader').style['display'] = 'none';

    this.getDealIpdBasicInfo();
    this.bindPostWaterfallTableData();
    

  }

  getDealIpdBasicInfo() {
    this.dealIpdBasicInfoModel = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData();
    if (this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {      
      this.isBasicInfoRequestComplete = true;
    }
    else {
      this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
        this.dealIpdBasicInfoModel = data;
        this.isBasicInfoRequestComplete = true;
        this.bindPostWaterfallTableData();
      });
    }
    
  }

  bindPostWaterfallTableData() {

       this._postWaterfallService.getPostwaterfallControlData(this.dealIpdBasicInfoModel.dealName, 
        this.dealIpdBasicInfoModel.ipdCollectionEndDate.toString()).subscribe((result) => {
        this.objPostWaterfallControlEntity = JSON.parse(JSON.stringify(result));
        console.log(this.objPostWaterfallControlEntity);
        this.postAP =this.objPostWaterfallControlEntity.filter( a =>a.attributeName=='Available Principal' && a.attributeType== 'Waterfall Reconciliation Attribute')[0]["attributeValue"];
        //this.postAP = Number(this.postAPP);
        this.postPC =this.objPostWaterfallControlEntity.filter( a =>a.attributeName=='Principal Collection' && a.attributeType== 'Waterfall Reconciliation Attribute')[0]["attributeValue"];
        //this.postPC = Number(this.postPCP);
        this.postAR =this.objPostWaterfallControlEntity.filter( a =>a.attributeName=='Available Revenue Receipts' && a.attributeType== 'Waterfall Reconciliation Attribute')[0]["attributeValue"];
        //this.postAR = Number(this.postARR);
        this.postRC =this.objPostWaterfallControlEntity.filter( a =>a.attributeName=='Revenue Collection' && a.attributeType== 'Waterfall Reconciliation Attribute')[0]["attributeValue"];
        //this.postRC = Number(this.postRCR);
        this.postPRecon =  this.postPC- this.postAP;
        this.postRRecon = Number((Math.round(this.postRC*100)/100).toFixed(2)) - Number((Math.round(this.postAR*100)/100).toFixed(2));
        console.log(this.postRRecon);
        this.postWaterfallReportReconcil = this.objPostWaterfallControlEntity.filter(a => a.attributeType== 'Asset Strats Reconciliation Attribute' && a.varianceCount.toString()!="");
        console.log(this.postWaterfallReportReconcil);
        
      });
  }

  onDownloadClick() {
    if (this.isFileDownloadStarted == false) {
      this.isFileDownloadStarted = true;
      this._postWaterfallService.getPostwaterfallExcelFile(this.dealIpdBasicInfoModel.dealName, 
        this.dealIpdBasicInfoModel.ipdCollectionEndDate.toString()).subscribe((data) => {

        this.isFileDownloadStarted = false;

        let FileName = "PostWaterfallControl-" + this.dealIpdBasicInfoModel.dealName + "-"
          + this._datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, "LLL-yyyy") + "-IPD.xlsx";
        console.log(FileName);
        

        const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(data);
      a.href = objectUrl
      a.download = FileName;
      a.click();

      URL.revokeObjectURL(objectUrl);
      
      });
    }
  }  

  FormatData(val: number) {
    return val == 0 ? "-" : this._decimalPipe.transform(val, "1.2-2");
  }

  FormatDataToNumber(val: string) {
    return Number(val);
  }

  FormatDataToCountNumber(val: string) {
    return val == "0" ? "-" :Number(val);
  }
}

