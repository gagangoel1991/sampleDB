import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { StormVsSfpEntity } from '../../model/stormVsSfp.model';
import { DealIpdcontrols } from '../../service/DealIpdcontrols.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import localeDe from '@angular/common/locales/en';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { DealIpdBasicInfoModel } from '../../model/deal-ipd-basicinfo.model';
import { DealDetailService } from '../../service/deal-detail.service';
import { IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';

@Component({
  selector: 'sfp-storm-vs-sfp',
  templateUrl: './storm-vs-sfp.component.html',
  styleUrls: ['./storm-vs-sfp.component.scss'],
  providers: [DealIpdcontrols, DecimalPipe, DatePipe, DealDetailService]
})
export class StormVsSfpComponent implements OnInit {

  private ipdParams: IpdAdjustmentParams;
  public dealIpdBasicInfoModel: DealIpdBasicInfoModel;
  public objStormVsSfpEntity: StormVsSfpEntity;
  public isDataRequestComplete = false;
  public isBasicInfoRequestComplete = false;
  public isFileDownloadStarted = false;
  public isExpanded = false;


  constructor(private _ipdProcessService: IpdProcessParentService,
    private _dealIpdcontrols: DealIpdcontrols, private _route: ActivatedRoute,
    private _router: Router, private _decimalPipe: DecimalPipe, private _datePipe: DatePipe) {
    this._ipdProcessService.changeIpdLevel1MenuName('controls');
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);
    this._route.params.subscribe((params: Params) => {
      this.objStormVsSfpEntity = new StormVsSfpEntity();
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });

  }

  ngOnInit(): void {

    document.getElementById('preloader').style['display'] = 'none';

    this.getDealIpdBasicInfo();
    this.bindTableData();

  }

  getDealIpdBasicInfo() {
    this.dealIpdBasicInfoModel = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData();
    if (this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {      
      this.isBasicInfoRequestComplete = true;
    }
    else {
      this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
        this.dealIpdBasicInfoModel = data;
        this.isBasicInfoRequestComplete = true;
      });
    }
  }

  bindTableData() {
    this._dealIpdcontrols.getStormVsSfpData(this.ipdParams.dealId, this.ipdParams.ipdRunId).subscribe((result) => {
      this.objStormVsSfpEntity = JSON.parse(JSON.stringify(result));
      this.computeOtherFields();
    },
      undefined,
      () => {
        this.isDataRequestComplete = true;
      });
  }

  computeOtherFields() {

    this.objStormVsSfpEntity.varianceRevCashCollPeriod = Math.abs(this.objStormVsSfpEntity.stormRevCashCollPeriod) - Math.abs(this.objStormVsSfpEntity.sfpRevCashCollPeriod);
    this.objStormVsSfpEntity.variancePrinCashCollPeriod = Math.abs(this.objStormVsSfpEntity.stormPrinCashCollPeriod) - Math.abs(this.objStormVsSfpEntity.sfpPrinCashCollPeriod);
    this.objStormVsSfpEntity.stormTotalCashCollPeriod = this.objStormVsSfpEntity.stormRevCashCollPeriod + this.objStormVsSfpEntity.stormPrinCashCollPeriod;
    this.objStormVsSfpEntity.sfpTotalCashCollPeriod = this.objStormVsSfpEntity.sfpRevCashCollPeriod + this.objStormVsSfpEntity.sfpPrinCashCollPeriod;
    this.objStormVsSfpEntity.varianceTotalCashCollPeriod = Math.abs(this.objStormVsSfpEntity.stormTotalCashCollPeriod) - Math.abs(this.objStormVsSfpEntity.sfpTotalCashCollPeriod);

    this.objStormVsSfpEntity.sfpTotalAdjustment = this.objStormVsSfpEntity.sfpRevAdjustment + this.objStormVsSfpEntity.sfpPrinAdjustment;

    this.objStormVsSfpEntity.varianceRevCashPostIpdPeriod = Math.abs(this.objStormVsSfpEntity.stormRevCashCollPostIpdPeriod) - Math.abs(this.objStormVsSfpEntity.sfpRevCashCollPostIpdPeriod);
    this.objStormVsSfpEntity.variancePrinCashPostIpdPeriod = Math.abs(this.objStormVsSfpEntity.stormPrinCashCollPostIpdPeriod) - Math.abs(this.objStormVsSfpEntity.sfpPrinCashCollPostIpdPeriod);
    this.objStormVsSfpEntity.stormTotalCashPostIpdPeriod = this.objStormVsSfpEntity.stormRevCashCollPostIpdPeriod + this.objStormVsSfpEntity.stormPrinCashCollPostIpdPeriod;
    this.objStormVsSfpEntity.sfpTotalCashPostIpdPeriod = this.objStormVsSfpEntity.sfpRevCashCollPostIpdPeriod + this.objStormVsSfpEntity.sfpPrinCashCollPostIpdPeriod;
    this.objStormVsSfpEntity.varianceTotalCashPostIpdPeriod = Math.abs(this.objStormVsSfpEntity.stormTotalCashPostIpdPeriod) - Math.abs(this.objStormVsSfpEntity.sfpTotalCashPostIpdPeriod);

    this.objStormVsSfpEntity.stormRevCashSummary = this.objStormVsSfpEntity.stormRevCashCollPeriod;
    this.objStormVsSfpEntity.sfpRevCashSummary = this.objStormVsSfpEntity.sfpRevCashCollPeriod + this.objStormVsSfpEntity.sfpRevDeflaggedReceipts + this.objStormVsSfpEntity.sfpRevAdjustment;
    this.objStormVsSfpEntity.varianceRevCashSummary = this.objStormVsSfpEntity.stormRevCashSummary + this.objStormVsSfpEntity.sfpRevCashSummary;
    this.objStormVsSfpEntity.stormPrinCashSummary = this.objStormVsSfpEntity.stormPrinCashCollPeriod;
    this.objStormVsSfpEntity.sfpPrinCashSummary = this.objStormVsSfpEntity.sfpPrinCashCollPeriod + this.objStormVsSfpEntity.sfpPrinDeflaggedReceipts + this.objStormVsSfpEntity.sfpPrinFurtherAdvances + this.objStormVsSfpEntity.sfpPrinAdjustment;
    this.objStormVsSfpEntity.variancePrinCashSummary = this.objStormVsSfpEntity.stormPrinCashSummary + this.objStormVsSfpEntity.sfpPrinCashSummary;
    this.objStormVsSfpEntity.stormTotalCashSummary = this.objStormVsSfpEntity.stormRevCashSummary + this.objStormVsSfpEntity.stormPrinCashSummary;

    this.objStormVsSfpEntity.sfpTotalDeflaggedReceipts = this.objStormVsSfpEntity.sfpRevDeflaggedReceipts + this.objStormVsSfpEntity.sfpPrinDeflaggedReceipts;
    this.objStormVsSfpEntity.sfpTotalCashSummary = this.objStormVsSfpEntity.sfpTotalCashCollPeriod + this.objStormVsSfpEntity.sfpTotalDeflaggedReceipts + this.objStormVsSfpEntity.sfpPrinFurtherAdvances + this.objStormVsSfpEntity.sfpTotalAdjustment;
    this.objStormVsSfpEntity.varianceTotalCashSummary = this.objStormVsSfpEntity.stormTotalCashSummary + this.objStormVsSfpEntity.sfpTotalCashSummary;
  }

  onDownloadClick() {
    if (this.isFileDownloadStarted == false) {
      this.isFileDownloadStarted = true;
      this._dealIpdcontrols.getStormVsSfpExcelFile(this.ipdParams.dealId, this.ipdParams.ipdRunId).subscribe((data) => {

        this.isFileDownloadStarted = false;

        let FileName = "StormVsSfp-" + this.dealIpdBasicInfoModel.dealName + "-"
          + this._datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, "LLL-yyyy") + "-IPD.xlsx";

        var blob = new Blob([this.s2ab(atob(data))], {
          type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
        });

        var link = document.createElement('a');
        link.href = window.URL.createObjectURL(blob);
        link.download = FileName;

        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);

      });
    }
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  FormatData(val: number) {
    return val == 0 ? "-" : this._decimalPipe.transform(val, "1.2-2");
  }

}
