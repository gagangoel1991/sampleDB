import { Component, ViewEncapsulation, OnInit } from "@angular/core";
import { IpdProcessParentService } from "../../service/ipd-process-parent.service";
import { RatingTriggerService } from "../../service/rating-trigger.service";
import { ActivatedRoute, Router, Params } from "@angular/router";
import { RatingTriggerModel } from "../../model/rating-trigger.model";
import { HeaderCollectionModel } from "../../model/deal-subloan.model";
import { ExportExcelUtility } from "src/app/shared/utility/export-excel-utility";
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from "angular-slickgrid";
import {
  SFP_SlickGridUtility,
  SFP_SlickAction,
  SFP_SlickColumn,
} from "src/app/shared/components/slick-grid/slick-grid.model";
import { SharedDataService } from "src/app/shared/services/shared-data.service";
import { SFP_SlickFilterType } from "src/app/shared/components/slick-grid/slick-grid.filter";
import {
  currencyFormatter,
  downloadLinkFormatter,
  hyperLinkFormatter,
} from "src/app/shared/components/slick-grid/slick-grid.formatter";
import {
  GlobalToasterService,
  ToasterTypes,
} from "src/app/shared/services/globaltoaster.service";
import { SfpEditableGridColumnModel } from "../../model/sfp-inline-edit-gridoption.model";
import { ContextMenuService } from "ngx-contextmenu";
import { DatePipe } from "@angular/common";
import { OrderByPipe } from "ngx-pipes";

@Component({
  selector: "cw-rating-trigger",
  templateUrl: "./rating-trigger.component.html",
  styleUrls: ["./rating-trigger.component.scss"],
  providers: [RatingTriggerService, OrderByPipe],
})
export class RatingComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public ratingTriggerList: Array<RatingTriggerModel> = [];
  public exportRatingTriggerList: Array<RatingTriggerModel> = [];
  public tempratingTriggerDataList: Array<RatingTriggerModel> = [];
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public RatingTriggerDataGridCustomCols: Array<SfpEditableGridColumnModel> =
    [];
  public datePipe = new DatePipe("en-UK");
  public selectedSortCol = "";
  public colSortType = "asc";
  private readonly _formatDate = "dd-MM-yyyy";
  public exportFileName = "DealRatingTriggerData";

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  public slickDefaultAuditButtons: boolean = false;
  //-------Slick Grid Variables End--------------

  constructor(
    private _ipdProcessService: IpdProcessParentService,
    private _ratingTriggerService: RatingTriggerService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _contextMenuService: ContextMenuService,
    private ngxOrderPipe: OrderByPipe,
    private _sharedDataService: SharedDataService
  ) {
    this._ipdProcessService.changeIpdLevel1MenuName("triggers");
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(
        this._router.url
      );
      this.dealId = values ? values[0] : null;
      this.ipdRunId = values ? values[1] : null;
    });
  }
  ngOnInit() {
    this._ratingTriggerService
      .getRatingTriggerData(this.dealId, this.ipdRunId)
      .subscribe((data) => {
        this.ratingTriggerList = data;
        this.exportRatingTriggerList =  JSON.parse(JSON.stringify(data)); //Deep Copy
        this.ratingTriggerList.forEach(function (element) {
          if (!element.isBreached)
            element.rowClass = "cw-row-valid";
          else
            element.rowClass = "cw-row-invalid";
        });
        let sourceData = JSON.parse(JSON.stringify(this.ratingTriggerList)); //Deep Copy
        sourceData.forEach((x) => {
          x.isBreached = x.isBreached ? "Yes" : "No";
        });
        this.slickDataset = sourceData;
        //  this.slickDataset = JSON.parse(JSON.stringify(data)); //deep copy
        console.log(data);
        this.ratingTriggerList.forEach((val) =>
          this.tempratingTriggerDataList.push(Object.assign({}, val))
        );
        //  this.applyDatePipe();
      });
    this.configureRatingTriggerDataGrid();
    document.getElementById("preloader").style["display"] = "none";
  }

  configureRatingTriggerDataGrid() {
    this.slickColumnArray.push(
      new SFP_SlickColumn(
        "eventName",
        "EventName",
        true,
        true,
        100,
        FieldType.string
      ),
      new SFP_SlickColumn(
        "cisCode",
        "Cis Code",
        true,
        true,
        100,
        FieldType.string
      ),
      new SFP_SlickColumn(
        "triggerSummary",
        "Summary of Event",
        true,
        true,
        100,
        FieldType.string
      ),
      new SFP_SlickColumn(
        "reference",
        "Reference",
        true,
        true,
        100,
        FieldType.string
      ),
      new SFP_SlickColumn(
        "thresholdRating",
        "Trigger Rating (S&P, DBRS; Short-term, Long-term)",
        true,
        true,
        150,
        FieldType.string
      ),
      new SFP_SlickColumn(
        "currentRating",
        "Current Rating",
        true,
        true,
        100,
        FieldType.string
      ),
      new SFP_SlickColumn(
        "isBreached",
        "Trigger Breached (Yes/No)",
        true,
        true,
        100,
        FieldType.string,
        undefined,
        SFP_SlickFilterType.singleSelect
      ),
      new SFP_SlickColumn(
        "consequenceOfEvent",
        "Consequence Of Event",
        true,
        true,
        100,
        FieldType.string
      )
    );
  }

  exportToExcel() {
    this.exportHeaders.push(new HeaderCollectionModel("eventName", "Event"));
    this.exportHeaders.push(new HeaderCollectionModel("cisCode", "Cis Code"));
    this.exportHeaders.push(new HeaderCollectionModel("triggerSummary", "Summary of Event"));
    this.exportHeaders.push(new HeaderCollectionModel("reference", "Reference"));
    this.exportHeaders.push(new HeaderCollectionModel("thresholdRating","Trigger Rating (S&P, DBRS; Short-term, Long-term)"));
    this.exportHeaders.push(new HeaderCollectionModel("currentRating", "Current Rating"));
    this.exportHeaders.push(new HeaderCollectionModel("isBreached", "Trigger Breached (Yes/No)"));
    this.exportHeaders.push(new HeaderCollectionModel("consequenceOfEvent", "Consequence Of Event"));

    let sourceData = JSON.parse(JSON.stringify(this.exportRatingTriggerList)); //Deep Copy
    sourceData.forEach((x) => {
      x.isBreached = x.isBreached ? "Yes" : "No";
    });

    this.exportExcelUtility.exportDataToExcel(
      this.exportHeaders,
      sourceData,
      "DealRatingTriggerData.xlsx"
    );
  }

  public getVisibleColumn() {
    const visibleColumns = this.RatingTriggerDataGridCustomCols.filter(
      function (col) {
        return col.isChecked;
      }
    );
    return visibleColumns;
  }

  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      event: $event,
      item: item,
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  applyDatePipe() {
    this.RatingTriggerDataGridCustomCols.forEach((customColumn) => {
      if (customColumn.pipeFormatter === "date") {
        this.ratingTriggerList.forEach((gridDataRecord) => {
          let valueToDateFormat = gridDataRecord[customColumn.columnName];
          gridDataRecord[customColumn.columnName] =
            valueToDateFormat !== null
              ? this.datePipe.transform(
                gridDataRecord[customColumn.columnName],
                this._formatDate
              )
              : "";
        });
      }
    });
  }

  public sfpGridColumnFilter(event, colName, colIdx) {
    if (this.ratingTriggerList) {
      const visibleColumns = this.RatingTriggerDataGridCustomCols.filter(
        function (col) {
          return col.isChecked;
        }
      );

      const searchValue = event.target.value.toLowerCase();
      visibleColumns[colIdx].filterText =
        searchValue === "blank" || searchValue === "undefined"
          ? "null"
          : searchValue.trim();

      let filteredData = this.tempratingTriggerDataList;
      visibleColumns.forEach(function (col) {
        if (col.filterText !== "" && filteredData.length > 0) {
          filteredData = filteredData.filter(function (row) {
            return (
              String(row[col.columnName])
                .toLowerCase()
                .indexOf(col.filterText) !== -1 || !col.filterText
            );
          });
        }
      });
      this.ratingTriggerList = filteredData;
    }
  }

  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = "asc";
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === "asc") {
      this.colSortType = "desc";
      filter = "-" + filter;
    } else if (
      colName === this.selectedSortCol &&
      this.colSortType === "desc"
    ) {
      this.colSortType = "asc";
    }
    this.ratingTriggerList = this.ngxOrderPipe.transform(
      this.ratingTriggerList,
      filter
    );
  }

  bindRatingTriggerActionsCallBack() {
    this.slickCallbackFuntions = new SFP_SlickAction(
      null,
      null,
      null,

      null,
      null
    );
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(
      this._sharedDataService
    );
    objSFP_Slick.resizeGrid();
  }
}
