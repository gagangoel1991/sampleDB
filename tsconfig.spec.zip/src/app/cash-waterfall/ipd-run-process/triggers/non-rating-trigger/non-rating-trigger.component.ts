import { Component, ViewEncapsulation, OnInit } from "@angular/core"
import { IpdProcessParentService } from "../../service/ipd-process-parent.service";
import { NonRatingTriggerService } from "../../service/non-rating-trigger.service";
import { ActivatedRoute, Router, Params } from "@angular/router";
import { NonRatingTriggerModel } from "../../model/non-rating-trigger.model";
import { FormGroup, FormBuilder } from "@angular/forms";
import { GlobalToasterService, ToasterTypes } from "../../../../shared/services/globaltoaster.service";
import { HeaderCollectionModel } from "../../model/deal-subloan.model";
import { ExportExcelUtility } from "src/app/shared/utility/export-excel-utility";
import { UserRoleService } from "../../../../shared/services/user-role-service";
import { PermissionEnum } from "../../../../shared/model/user-permission.enum";
import { PermissionAccessTypeEnum } from "../../../../shared/model/user-permission-accesstype.enum";
import { NgbModal } from "@ng-bootstrap/ng-bootstrap";
import { CommonPopupConfigModel } from "src/app/shared/components/grid/sfp-gridOptions.model";
import { CommonPopupComponent } from "src/app/shared/components/confirm-common-popup/sfp-common-popup.component";
import { DealNameEnum } from "src/app/shared/enum/deal-name-enum";


@Component({
    selector: 'cw-non-rating-trigger',
    templateUrl: './non-rating-trigger.component.html',
    styleUrls: ['./non-rating-trigger.component.scss'],
    providers: [NonRatingTriggerService],
})

export class NonRatingComponent implements OnInit {
    public dealId: number;
    public ipdRunId: number;
    public nonRatingTriggerList: Array<NonRatingTriggerModel> = [];
    public exportNonRatingTriggerList: Array<NonRatingTriggerModel> = [];
    public tempNonRatingTriggerList: Array<NonRatingTriggerModel> = [];
    public editing = {};
    public isDataChangesAllow: boolean = true;
    public exportHeaders: Array<HeaderCollectionModel> = [];
    public exportExcelUtility = new ExportExcelUtility();
    public isReadOnlyAccess: boolean = false;
    public isAddEditAccess: boolean = false;
    public isApprovRejectAccess: boolean = false;
    public isDeleteAccess: boolean = false;
    private readonly _nonRatingTriggerHeader = 'Non Rating Trigger';
    private readonly _nonRatingTriggerMessage = "Trigger updated successfully.";
    public isNonRatingTriggerHasValue: boolean = false;
    public nonRatingConditiondealId:number =DealNameEnum.DEIMOS;
    private readonly _valueChangeMessage = "You have not changed any value.";

    public startedRequests: number = 0;
    public completedRequests: number = 0;

    constructor(private _ipdProcessService: IpdProcessParentService
        , private _nonRatingTriggerService: NonRatingTriggerService
        , private _toastservice: GlobalToasterService
        , private _route: ActivatedRoute,
        private _router: Router,
        private _userService: UserRoleService,
        private _modalService: NgbModal) {
        this._ipdProcessService.changeIpdLevel1MenuName('triggers');
        this._route.params.subscribe((params: Params) => {
            var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
            this.dealId = (values) ? values[0] : null;
            this.ipdRunId = (values) ? values[1] : null;
        });

    }
    ngOnInit() {
        this.load()
        document.getElementById('preloader').style['display'] = 'none';
        this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
            this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
        });
        this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
        this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
        this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
        this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
    }

    load() {
        this.tempNonRatingTriggerList = []
        this.nonRatingTriggerList = [];
        this.startedRequests += 1;
        this._nonRatingTriggerService.getNontRatingTriggerData(this.dealId, this.ipdRunId).subscribe((data) => {
            this.nonRatingTriggerList = data;
            this.exportNonRatingTriggerList = JSON.parse(JSON.stringify(data));
            this.nonRatingTriggerList.forEach(obj => this.tempNonRatingTriggerList.push(Object.assign({}, obj)));
            this.verifyNonRatingTriggerHasValue();
            this.completedRequests += 1;
        })


    }
    // Save row
    save(rowIndex, isBreached: boolean) {

        if (!this.CheckDataChange(rowIndex,isBreached)) {
            this._toastservice.openToast(ToasterTypes.error, this._nonRatingTriggerHeader, this._valueChangeMessage);
            return;
          }
        let model = new NonRatingTriggerModel(rowIndex, "", "", isBreached, "", "", false, true);
        this.startedRequests += 1;
        this._nonRatingTriggerService.saveNontRatingTriggerData(model).subscribe((data) => {
            this._toastservice.openToast(ToasterTypes.success, this._nonRatingTriggerHeader, this._nonRatingTriggerMessage);
            this.load();
            this.editing[rowIndex] = false;
            this.verifyNonRatingTriggerHasValue();
            this.completedRequests += 1;
        });
    }

    private CheckDataChange(row: any,isBreached: boolean) {        
        var originalRow = this.tempNonRatingTriggerList.filter(x => x?.id == row);
        if (originalRow.length) {
            if(originalRow[0].isBreached != isBreached)
                return true;            
          }
        else
          return false;
      }

    // cancel row
    cancel(rowIndex: any) {
        this.editing[rowIndex] = false;
        this.nonRatingTriggerList = JSON.parse(JSON.stringify(this.tempNonRatingTriggerList));
    }

    exportToExcel(internalName: any) {

        this.exportHeaders.push(new HeaderCollectionModel('eventName', 'Event'));
        this.exportHeaders.push(new HeaderCollectionModel('isBreached', 'Trigger Breached (Yes/No)'));
        this.exportHeaders.push(new HeaderCollectionModel('triggerSummary', 'Summary of Event'));
        this.exportHeaders.push(new HeaderCollectionModel('consequenceOfEvent', 'Consequence Of Event'));
        this.exportHeaders.push(new HeaderCollectionModel('modifiedBy', 'Modified By'));
        this.exportHeaders.push(new HeaderCollectionModel('modifiedDate', 'Modified Date', 'date'));

        if (internalName == 'NonRatingTrigger') {
            let sourceData = JSON.parse(JSON.stringify(this.exportNonRatingTriggerList.filter(y => y.internalName == internalName))); //Deep Copy
            sourceData.forEach(x => {
                x.isBreached = x.isBreached ? 'Yes' : 'No';
            });

            this.exportExcelUtility.exportDataToExcel(this.exportHeaders, sourceData, "NonRatingTriggerData.xlsx");
        }
        else {
            let sourceData = JSON.parse(JSON.stringify(this.exportNonRatingTriggerList.filter(y => y.internalName == internalName))); //Deep Copy
            sourceData.forEach(x => {
                x.isBreached = x.isBreached ? 'Yes' : 'No';
            });

            this.exportExcelUtility.exportDataToExcel(this.exportHeaders, sourceData, "ConditionTriggerData.xlsx");
        }

    }


    reset() {
        this.startedRequests += 1;
        this._nonRatingTriggerService.resetNontRatingTriggerData(this.dealId, this.ipdRunId).subscribe((result) => {
            this._toastservice.openToast(ToasterTypes.success, this._nonRatingTriggerHeader, 'Reset successfully');
            this.load();
            this.completedRequests += 1;
        });
    }


    confirmBox() {
        let popupCfg = new CommonPopupConfigModel(
            `Reset ${'Non Rating Trigger'}`,
            `Are you sure you want to reset the rating changes? \n This action will reset the rating changes made on this screen.`
        );
        const modalRefDel = this._modalService.open(CommonPopupComponent, {
            backdrop: 'static',
            keyboard: false
        });

        modalRefDel.componentInstance.popupConfig = popupCfg;

        modalRefDel.result.then(result => {
            console.log(result);
            if (result === 'confirmed') {
                this.reset();
            }
            else if (result === 'cancel click') {
                console.log('Cancel popup clicked.')
            }
        });
    };

    verifyNonRatingTriggerHasValue() {

        let isNonRatingTriggerResetVal = this.nonRatingTriggerList.filter(z => (z.isBreached == true));
        if (isNonRatingTriggerResetVal.length > 0) {
            this.isNonRatingTriggerHasValue = true;
        }
        else {

            this.isNonRatingTriggerHasValue = false;
        }
        console.log(this.isNonRatingTriggerHasValue);

    }

    allRequestCompleted(): boolean {
        return this.startedRequests == this.completedRequests && this.completedRequests > 0;
    }
}



