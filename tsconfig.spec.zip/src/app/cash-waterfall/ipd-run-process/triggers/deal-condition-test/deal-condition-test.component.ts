import { DatePipe, DecimalPipe } from '@angular/common';
import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommonPopupComponent } from 'src/app/shared/components/confirm-common-popup/sfp-common-popup.component';
import { CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { DealConditionTestModel } from '../../model/deal-condition-test.model';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { DealConditionTestService } from '../../service/deal-condition-test.service';
import { IpdProcessParentService } from "../../service/ipd-process-parent.service";
import { UserRoleService } from "../../../../shared/services/user-role-service";
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { DealIpdBasicInfoModel } from '../../model/deal-ipd-basicinfo.model';
import { DealDetailService } from '../../service/deal-detail.service';
import { IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';

@Component({
  selector: 'cw-deal-condition-test',
  templateUrl: './deal-condition-test.component.html',
  styleUrls: ['./deal-condition-test.component.scss'],
  providers: [DealConditionTestService,IpdProcessParentService]
})
export class DealConditionTestComponent implements OnInit {

  public dealId: number;
  public ipdRunId: number;
  public dealConditionTestList: Array<DealConditionTestModel> = [];
  public exportDealConditionTestList: Array<DealConditionTestModel> = [];
  public tempdealConditionTestList: Array<DealConditionTestModel> = [];
  public dealconditionunsavedModel: DealConditionTestModel;
  public editing = {};
  public isDataChangesAllow: boolean = true;
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private readonly _dealCondtionTestHeader = 'Deal Condition Test';
  private readonly _dealCondtionTestMessage = "Deal Condition Record updated successfully.";
  private readonly _valueChangeMessage = "You have not changed any value.";
  public isDealConditionHasValue: boolean = false;
  public dealDetail: DealIpdBasicInfoModel;
  public ipdDate : string;
  private datePipe = new DatePipe('en-UK');
  public ipdParams: IpdAdjustmentParams;

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _dealConditionTestService: DealConditionTestService
    , private _toastservice: GlobalToasterService
    ,private _dealDetailService: DealDetailService
    , private _route: ActivatedRoute,
    private _router: Router,
    private _userService: UserRoleService,
    private _modalService: NgbModal) {
    this._ipdProcessService.changeIpdLevel1MenuName('triggers');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });

  }
  ngOnInit() {
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);


    this.ipdParams = new IpdAdjustmentParams(0, 0, null);
      this.ipdParams.dealId = this.dealId
      this.ipdParams.ipdRunId = this.ipdRunId
     

    this._dealDetailService.getDealDetailData(this.ipdParams).subscribe(data => {
      console.log(data);
      this.dealDetail = data;
      this.ipdDate = this.datePipe.transform(this.dealDetail.ipdDate, 'yyyy-MM-dd');new Date(this.dealDetail.ipdDate);
    });
    this.getloadConditionTest();
  }

  getloadConditionTest() {
    this.tempdealConditionTestList = []
    this.dealConditionTestList = [];
    this._dealConditionTestService.getDealConditionTestData(this.dealId, this.ipdRunId).subscribe((data) => {
      console.log(data);
      this.dealConditionTestList = data;
      this.exportDealConditionTestList = JSON.parse(JSON.stringify(data));
      this.dealconditionunsavedModel = JSON.parse(JSON.stringify(data));
      this.dealConditionTestList.forEach(obj => this.tempdealConditionTestList.push(Object.assign({}, obj)));
      this.verifyDealConditionHasValue();
      console.log(this.dealConditionTestList);
    })
    document.getElementById('preloader').style['display'] = 'none';

  }

  // Save row
  save(rowIndex, loanAmount: number, repurchaseAmount: number, comment: string, number: number, previousRepurchaseDate: string) {
    if (comment == null) {
      comment = "";
    }
    if (previousRepurchaseDate == null) {
      previousRepurchaseDate = "";
    }

    
    let model = new DealConditionTestModel(rowIndex, "", "", comment, number, loanAmount, "", repurchaseAmount, "", previousRepurchaseDate);
    if (!this.CheckDataChange(rowIndex ,model)) {
      this._toastservice.openToast(ToasterTypes.error, this._dealCondtionTestHeader, this._valueChangeMessage);
      return;
    }
    this._dealConditionTestService.saveDealConditionTestData(model).subscribe((data) => {
      this._toastservice.openToast(ToasterTypes.success, this._dealCondtionTestHeader, this._dealCondtionTestMessage);
      this.getloadConditionTest();
      this.editing[rowIndex] = false;
    });
  }

  private CheckDataChange(rowIndex : any,row: DealConditionTestModel) { 
    
    if (this.dealconditionunsavedModel.comment == null) {
      this.dealconditionunsavedModel.comment = "";
    }
    if (this.dealconditionunsavedModel.previousRepurchaseDate == null) {
      this.dealconditionunsavedModel.previousRepurchaseDate = "";
    }
    console.log(JSON.parse(JSON.stringify(this.dealconditionunsavedModel)))
    if (row.amount == this.dealconditionunsavedModel.amount && row.repurchaseAmount == this.dealconditionunsavedModel.repurchaseAmount &&
        row.number == this.dealconditionunsavedModel.number && row.comment == this.dealconditionunsavedModel.comment &&
        row.previousRepurchaseDate == this.dealconditionunsavedModel.previousRepurchaseDate ) {
        return false;
    }
    else
        return true;
  }

  // cancel row
  cancel(rowIndex: any) {
    this.editing[rowIndex] = false;
    this.dealConditionTestList = JSON.parse(JSON.stringify(this.tempdealConditionTestList));
  }

  exportToExcel() {

    this.exportHeaders.push(new HeaderCollectionModel('condition', 'Condition'));
    this.exportHeaders.push(new HeaderCollectionModel('status', 'Status'));
    this.exportHeaders.push(new HeaderCollectionModel('amount', 'Amount(EUR)', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('repurchaseAmount', 'Repurchases(Current Balance)', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('comment', 'Comment'));
    this.exportHeaders.push(new HeaderCollectionModel('number', 'Number'));    
    this.exportHeaders.push(new HeaderCollectionModel('consequences', 'Consequences'));    
    this.exportHeaders.push(new HeaderCollectionModel('previousRepurchaseDate', 'Date of Previous Repurchase', 'date'));
    this.exportHeaders.push(new HeaderCollectionModel('modifiedBy', 'Modified By'));
    this.exportHeaders.push(new HeaderCollectionModel('modifiedDate', 'Modified Date', 'date'));
    
    this.exportExcelUtility.exportDataToExcel(this.exportHeaders, this.exportDealConditionTestList, "ConditionsTestsData.xlsx");

  }

  reset() {
    this._dealConditionTestService.resetDealConditionTestData(this.ipdRunId).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this._dealCondtionTestHeader, 'Reset successfully');
      this.getloadConditionTest();
    });
  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel(
      `Reset ${'Conditions/Tests'}`,
      `Are you sure you want to reset the Conditions/Tests changes? \n This action will reset the Conditions/Tests changes made on this screen.`
    );
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

  verifyDealConditionHasValue() {
    this.isDealConditionHasValue = this.dealConditionTestList.filter(z => (z.amount != 0 || z.repurchaseAmount != 0 || z.number != 0 || z.comment != null || z.previousRepurchaseDate != null)).length > 0 ? true : false;
  }



}
