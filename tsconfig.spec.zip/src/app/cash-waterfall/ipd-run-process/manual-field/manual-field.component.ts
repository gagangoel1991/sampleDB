import { Component, OnInit, ViewChild } from '@angular/core';
import { ManualFieldKeyValue, FieldData, ManualDataObj, Field } from '../model/manual-field.model';
import { ManualFieldService } from '../service/manual-field.service';
import * as _ from 'lodash';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { IpdProcessParentService } from '../service/ipd-process-parent.service';
import { Router } from '@angular/router';
import { DealIpdBasicInfoModel } from '../model/deal-ipd-basicinfo.model';
import { NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DatePipe } from '@angular/common';
import { ObjectArrayFilterByKeyValue } from 'src/app/shared/pipes/object-array-filter.pipe';
import { CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from 'src/app/shared/components/confirm-common-popup/sfp-common-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';


@Component({
  selector: 'sfp-manual-field',
  templateUrl: './manual-field.component.html',
  styleUrls: ['./manual-field.component.scss'],
  providers: [ManualFieldService, ObjectArrayFilterByKeyValue]
})
export class ManualFieldComponent extends CanDeactivateForm implements OnInit {

  public manualFieldModelArray: ManualDataObj = <ManualDataObj>{};
  public manualFieldModelOrignalArray: ManualDataObj = <ManualDataObj>{};

  public datePipe = new DatePipe('en-UK');


  public groupDisplayNamesList: Array<string> = [];

  public isDataChangesAllow: boolean = true;
  public isAddEditAccess: boolean = false;

  public dealIpdBasicInfoModel: DealIpdBasicInfoModel;
  public dealId: number;
  public ipdRunId: number;


  public startedRequests: number = 0;
  public completedRequests: number = 0;


  //Toaster Messages
  private readonly _manualFields = 'Manual Fields';
  private readonly _manualFieldErrorMessage = 'Please correct the error before saving.';
  private readonly _noDataChangeErrorMessage = 'No data changes to save.';
  private readonly _successMessage = 'Data has been saved successfully.';
  private readonly _nothingSavedErrorMessage = 'Nothing saved.';

  private readonly _resetUnsavedSuccessMessage = 'Manual Fields unsaved data has been reset successfully.';
  private readonly _resetSavedSuccessMessage = 'Manual Fields data has been reset successfully using last IPD Values.';
  private readonly _resetUnsavedErrorMessage = 'Nothing changed locally.';
  private readonly _resetSavedErrorMessage = 'Nothing changed in saved Data as compared to last IPD.';
  private readonly _nothingResetErrorMessage = 'Nothing reset.';
  private readonly _resetConfirmMessage = `Do you want to reset 'Manual Fields' data? If you will click on 'OK' it will override all current IPD 'Manual Fields' data by last IPD 'Manual Fields' data.`




  @ViewChild('manualForm') manualForm: NgForm;
  @ViewChild('manualForm') confirmUnsavedForm: NgForm;


  constructor(private _ipdProcessService: IpdProcessParentService, private _manualFieldService: ManualFieldService,
    private _userService: UserRoleService, private _router: Router, private _toastservice: GlobalToasterService,
    private _modalService: NgbModal

  ) {
    super();
    this._ipdProcessService.changeIpdLevel1MenuName('manualfield');
    var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
    this.dealId = (values) ? values[0] : null;
    this.ipdRunId = (values) ? values[1] : null;
  }

  ngOnInit(): void {
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
    this.getDealIpdBasicInfo();
    this.getManualFieldsData();
  }

  getDealIpdBasicInfo() {
    this.startedRequests += 1;
    this.dealIpdBasicInfoModel = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData();
    if (this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {      
      this.completedRequests += 1;
    }
    else {
      this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
        this.dealIpdBasicInfoModel = data;
        this.completedRequests += 1;
      });
    }
  }

  getManualFieldsData() {

    this.startedRequests += 1;
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);

    this._manualFieldService.getManualFieldData(this.ipdRunId).subscribe((data) => {

      this.manualFieldModelArray = _.cloneDeep(data);
      this.manualFieldModelOrignalArray = _.cloneDeep(data);

      console.log(JSON.stringify(data));

      this.completedRequests += 1;

    });
  }

  public saveManualFieldData() {
    Object.keys(this.manualForm.controls).forEach(key => {
      this.manualForm.controls[key].markAsDirty();
    });

    if (this.manualForm.valid) {
      let changedKeyValuePairs = this.getLocallyChangedData();
      if (changedKeyValuePairs.length > 0) {
        this.startedRequests += 1;
        this._manualFieldService.updateManualFieldData(changedKeyValuePairs).subscribe((changeCount) => {
          if (changeCount > 0) {
            this._toastservice.openToast(ToasterTypes.success, this._manualFields, this._successMessage);
          } else {
            this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._nothingSavedErrorMessage);
          }
          this.completedRequests += 1;
          this.confirmUnsavedForm.form.markAsPristine();
          this.confirmUnsavedForm.form.markAsUntouched();
          this.getManualFieldsData();
        });
      }
      else {
        this.confirmUnsavedForm.form.markAsPristine();
        this.confirmUnsavedForm.form.markAsUntouched();
        this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._noDataChangeErrorMessage);
      }
    }
    else {
      this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._manualFieldErrorMessage);
    }
  }

  public getLocallyChangedData(): Array<ManualFieldKeyValue> {

    let objChangedKeyValuePairs: Array<ManualFieldKeyValue> = [];
    let mutatedFieldsArray: Array<FieldData> = [];
    let orignalFieldsArray: Array<FieldData> = [];
    let changedData: Array<FieldData> = [];


    this.manualFieldModelArray.manualFieldData.forEach((group) => {
      group.val.forEach((subGroup) => {
        subGroup.val.forEach((fieldHeader) => {
          fieldHeader.val.forEach((field) => {
            if (this.datePipe.transform(field.ipdDate, 'yyyy-MM-dd') == this.datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, 'yyyy-MM-dd')) {
              mutatedFieldsArray.push(field);
            }
          }, this)
        }, this)
      }, this)
    }, this);



    this.manualFieldModelOrignalArray.manualFieldData.forEach((group) => {
      group.val.forEach((subGroup) => {
        subGroup.val.forEach((fieldHeader) => {
          fieldHeader.val.forEach((field) => {
            if (this.datePipe.transform(field.ipdDate, 'yyyy-MM-dd') == this.datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, 'yyyy-MM-dd')) {
              orignalFieldsArray.push(field);
            }
          }, this)
        }, this)
      }, this)
    }, this);


    changedData = _.differenceWith(mutatedFieldsArray, orignalFieldsArray, _.isEqual);

    changedData.forEach(function (val) {
      objChangedKeyValuePairs.push(new ManualFieldKeyValue(val.manualFieldValueId, val.fieldValue))
    })

    return objChangedKeyValuePairs;

  }

  allRequestCompleted(): boolean {
    return this.startedRequests == this.completedRequests && this.completedRequests > 0;
  }

  public resetSavedData() {

    this.startedRequests += 1;
    this._manualFieldService.resetManualFieldData(this.ipdRunId).subscribe((changeCount) => {
      if (changeCount > 0) {
        this._toastservice.openToast(ToasterTypes.success, this._manualFields, this._resetSavedSuccessMessage);
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._nothingResetErrorMessage);
      }
      this.getManualFieldsData();
      this.completedRequests += 1;
    });

  }

  public resetUnsavedData() {

    let changedKeyValuePairs = this.getLocallyChangedData();
    if (changedKeyValuePairs.length > 0) {
      this.manualFieldModelArray = _.cloneDeep(this.manualFieldModelOrignalArray);
      this._toastservice.openToast(ToasterTypes.success, this._manualFields, this._resetUnsavedSuccessMessage);
    }
    else {
      this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._resetUnsavedErrorMessage);
    }
    this.confirmUnsavedForm.form.markAsPristine();
    this.confirmUnsavedForm.form.markAsUntouched();
  }


  public resetManualFieldDealSwapData() {

    this.startedRequests += 1;
    this._manualFieldService.resetManualFieldDealSwapData(this.ipdRunId).subscribe((changeCount) => {
      if (changeCount > 0) {
        this._toastservice.openToast(ToasterTypes.success, this._manualFields, this._resetSavedSuccessMessage);
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._nothingResetErrorMessage);
      }
      this.getManualFieldsData();
      this.completedRequests += 1;
    });

  }

  public isAnyChangeFromLastIPd(): boolean {

    let currentIpdFieldsArray: Array<Field> = [];
    let lastIpdFieldsArray: Array<Field> = [];
    let changedData: Array<FieldData> = [];
    let lastIpdDate: Date = this.manualFieldModelArray.ipdDates[1];

    this.manualFieldModelOrignalArray.manualFieldData.forEach((group) => {
      group.val.forEach((subGroup) => {
        subGroup.val.forEach((fieldHeader) => {
          fieldHeader.val.forEach((fieldData) => {
            if (this.datePipe.transform(fieldData.ipdDate, 'yyyy-MM-dd') == this.datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, 'yyyy-MM-dd')) {

              let fieldObj: Field = <Field>{};
              fieldObj.fieldValue = fieldData.fieldValue;
              fieldObj.manualFieldId = fieldData.manualFieldId;
              currentIpdFieldsArray.push(fieldObj);
            }
          }, this)
        }, this)
      }, this)
    }, this);



    this.manualFieldModelOrignalArray.manualFieldData.forEach((group) => {
      group.val.forEach((subGroup) => {
        subGroup.val.forEach((fieldHeader) => {
          fieldHeader.val.forEach((fieldData) => {
            if (this.datePipe.transform(fieldData.ipdDate, 'yyyy-MM-dd') == this.datePipe.transform(lastIpdDate, 'yyyy-MM-dd')) {
              let fieldObj: Field = <Field>{};
              fieldObj.fieldValue = fieldData.fieldValue;
              fieldObj.manualFieldId = fieldData.manualFieldId;
              lastIpdFieldsArray.push(fieldObj);
            }
          }, this)
        }, this)
      }, this)
    }, this);


    changedData = _.differenceWith(currentIpdFieldsArray, lastIpdFieldsArray, _.isEqual);
    return changedData.length > 0;
  }


  public downloadExcel() {
    this._manualFieldService.getManualExcelData(this.ipdRunId).subscribe((data) => {

      // this.isFileDownloadStarted = false;

      let FileName = "Manual-Field-" + this.dealIpdBasicInfoModel.dealName + "-"
        + this.datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, "LLL-yyyy") + "-IPD.xlsx";

      var blob = new Blob([this.s2ab(atob(data))], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
      });

      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = FileName;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

    });
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  resetConfirmBox() {
    let isChangedFromLastIpd: boolean = this.isAnyChangeFromLastIPd();
    if (isChangedFromLastIpd) {
      let popupCfg = new CommonPopupConfigModel(`Reset ${this._manualFields}`, this._resetConfirmMessage);

      const modalRefDel = this._modalService.open(CommonPopupComponent, {
        backdrop: 'static',
        keyboard: false
      });

      modalRefDel.componentInstance.popupConfig = popupCfg;

      modalRefDel.result.then(result => {
        console.log(result);
        if (result === 'confirmed') {
          this.resetSavedData();
        }
        else if (result === 'cancel click') {
          console.log('Cancel popup clicked.')
        }
      });
    }
    else {
      this._toastservice.openToast(ToasterTypes.error, this._manualFields, this._resetSavedErrorMessage);
    }
  }

}
