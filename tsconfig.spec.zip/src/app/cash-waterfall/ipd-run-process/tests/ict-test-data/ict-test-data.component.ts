import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SFP_SlickGridUtility } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { GlobalToasterService } from 'src/app/shared/services/globaltoaster.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';
import { TestDataModel } from '../../model/test-summary-line-item-model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { TestSummaryService } from '../../service/test-summary.service';

@Component({
  selector: 'ict-test-component',
  templateUrl: './ict-test-data.component.html',
  styleUrls: ['./ict-test-data.component.scss']
})
export class IctTestDataComponent {
  @Input() item: any;
  @Input() index: number = 0;
  @Input() ipdDates: Date[] = [];
  @Output() testExcelEvent = new EventEmitter<string>();

  public ipdParams: IpdAdjustmentParams;
  public testIctDatalineItems: Array<TestDataModel> = [];
  public testIctMonthDatalineItems: Array<TestDataModel> = [];
  public iCTTestType: string = 'ICTMonthly'
  public iCTTest12MonthType: string = 'ICT12MonthsForwardTest'

  constructor(private router: Router, private _testSummaryService: TestSummaryService,
    private _ipdProcessService: IpdProcessParentService,
    public _toastservice: GlobalToasterService,
    private _modalService: NgbModal,
    private _route: ActivatedRoute,
    private _userService: UserRoleService,
    private _sharedDataService: SharedDataService) {


    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this.router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.loadIctSampleData();
  }

  loadIctSampleData() {
    this.loadIctTestData(this.iCTTestType);
    this.loadIctMonthTestData(this.iCTTest12MonthType);

  }

  public ictitems: any[];
  public ictmonthitems: any[];

  expandedIct(itemict: any) {
    itemict.expanded = !itemict.expanded;
    this.ictitems = this.getItemsict(this.testIctDatalineItems, null, 0);
  }

  expandedIctMonth(itemictMonth: any) {
    itemictMonth.expanded = !itemictMonth.expanded;
    this.ictitems = this.getItemsictMonth(this.testIctMonthDatalineItems, null, 0);
  }

  getItemsict(data, itemsict, index) {
    data.forEach(x => {
      if (!itemsict) itemsict = [];
      itemsict.push(x);
      itemsict[itemsict.length - 1].index = index;
      if (x.childLineItems && x.expanded) this.getItemsict(x.subtasks, itemsict, index + 1);
    });
    return itemsict;
  }


  getItemsictMonth(data, itemsictMonth, index) {
    data.forEach(x => {
      if (!itemsictMonth) itemsictMonth = [];
      itemsictMonth.push(x);
      itemsictMonth[itemsictMonth.length - 1].index = index;
      if (x.childLineItems && x.expanded) this.getItemsictMonth(x.subtasks, itemsictMonth, index + 1);
    });
    return itemsictMonth;
  }

  loadIctTestData(testTypeName: string): boolean {
    this.testIctDatalineItems = [];
    this._testSummaryService.getTestTypeData(this.ipdParams.dealId, this.ipdParams.ipdRunId, testTypeName).subscribe(data => {
      this.testIctDatalineItems = data;
      this.ictitems = data;
      console.log(this.ictitems);

    }, (error: any) => {
      console.log(error);
    });
    return true;
  }

  loadIctMonthTestData(testTypeName: string): boolean {
    this.testIctMonthDatalineItems = [];
    this._testSummaryService.getTestTypeData(this.ipdParams.dealId, this.ipdParams.ipdRunId, testTypeName).subscribe(data => {
      this.testIctMonthDatalineItems = data;
      this.ictmonthitems = data;
      console.log(this.ictmonthitems);

    }, (error: any) => {
      console.log(error);
    });
    return true;
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  getTestExcelParent2(testTypeName: string): void {
    this.testExcelEvent.emit(testTypeName);
  }
}
