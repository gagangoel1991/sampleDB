import { Component, Input, OnInit, SimpleChanges, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SFP_SlickGridUtility } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { GlobalToasterService } from 'src/app/shared/services/globaltoaster.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';
import { TestDataModel } from '../../model/test-summary-line-item-model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { TestSummaryService } from '../../service/test-summary.service';

@Component({
  selector: 'oct-test-component',
  templateUrl: './oct-test-data.component.html',
  styleUrls: ['./oct-test-data.component.scss']
})
export class OctTestDataComponent {

  @Input() item: any;
  @Input() index: number = 0;
  @Input() ipdDates: Date[] = [];
  @Output() testExcelEvent = new EventEmitter<string>();

  public ipdParams: IpdAdjustmentParams;
  public testOctDatalineItems: Array<TestDataModel> = [];
  public testOctMonthDatalineItems: Array<TestDataModel> = [];
  public oCTTestType: string = 'OCTMonthly'
  public oCTTest12MonthType: string = '12MonthsForwardOCTTest'

  constructor(private router: Router, private _testSummaryService: TestSummaryService,
    private _ipdProcessService: IpdProcessParentService,
    public _toastservice: GlobalToasterService,
    private _modalService: NgbModal,
    private _route: ActivatedRoute,
    private _userService: UserRoleService,
    private _sharedDataService: SharedDataService) {



    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this.router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.loadOctSampleData();
  }

  loadOctSampleData() {
    this.loadOctTestData(this.oCTTestType);
    this.loadOctMonthTestData(this.oCTTest12MonthType);

  }

  public octitems: any[];
  public octmonthitems: any[];

  expandedOct(itemoct: any) {
    itemoct.expanded = !itemoct.expanded;
    this.octitems = this.getItemsoct(this.testOctDatalineItems, null, 0);
  }

  expandedOctMonth(itemoctMonth: any) {
    itemoctMonth.expanded = !itemoctMonth.expanded;
    this.octitems = this.getItemsoctMonth(this.testOctMonthDatalineItems, null, 0);
  }

  getItemsoct(data, itemsoct, index) {
    data.forEach(x => {
      if (!itemsoct) itemsoct = [];
      itemsoct.push(x);
      itemsoct[itemsoct.length - 1].index = index;
      if (x.childLineItems && x.expanded) this.getItemsoct(x.subtasks, itemsoct, index + 1);
    });
    return itemsoct;
  }


  getItemsoctMonth(data, itemsoctMonth, index) {
    data.forEach(x => {
      if (!itemsoctMonth) itemsoctMonth = [];
      itemsoctMonth.push(x);
      itemsoctMonth[itemsoctMonth.length - 1].index = index;
      if (x.childLineItems && x.expanded) this.getItemsoctMonth(x.subtasks, itemsoctMonth, index + 1);
    });
    return itemsoctMonth;
  }

  loadOctTestData(testTypeName: string): boolean {
    this.testOctDatalineItems = [];
    this._testSummaryService.getTestTypeData(this.ipdParams.dealId, this.ipdParams.ipdRunId, testTypeName).subscribe(data => {
      this.testOctDatalineItems = data;
      this.octitems = data;
      console.log(this.octitems);

    }, (error: any) => {
      console.log(error);
    });
    return true;
  }

  loadOctMonthTestData(testTypeName: string): boolean {
    this.testOctMonthDatalineItems = [];
    this._testSummaryService.getTestTypeData(this.ipdParams.dealId, this.ipdParams.ipdRunId, testTypeName).subscribe(data => {
      this.testOctMonthDatalineItems = data;
      this.octmonthitems = data;
      console.log(this.octmonthitems);

    }, (error: any) => {
      console.log(error);
    });
    return true;
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  getTestExcelParent2(testTypeName: string): void {
    this.testExcelEvent.emit(testTypeName);
  }
}
