import { DecimalPipe } from '@angular/common';
import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'testResult'
})
export class TestsResultPipe implements PipeTransform {

  transform(value: string): unknown {

    if (value != undefined) {
      let pipe = new DecimalPipe('en-US');
      // if last character is '%'
      if (value.slice(-1) == '%') {
        let remainPart = value.replace('%', '');
        //Last Chracter is % but remaining is not a number so can't be formatted
        if (isNaN(remainPart as any)) {
          return value;
        }
        else {
          return pipe.transform(remainPart, '1.4-4') + '%';
        }

      }
      if (isNaN(value as any)) {
        return value;
      }
      else {
        return pipe.transform(value, '1.2-2') ;
      }

    }

    return value;
  }

}
