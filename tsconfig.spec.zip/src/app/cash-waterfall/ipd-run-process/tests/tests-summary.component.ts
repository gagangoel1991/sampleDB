import { DatePipe } from '@angular/common';
import { Component, Input, OnInit, ViewChild } from '@angular/core';
import { IpdAdjustmentParams } from '../model/cash-waterfall-line-item-model';
import { IpdTabs, TestDataModel, TestSummaryModel } from '../model/test-summary-line-item-model';
import { IpdProcessParentService } from '../service/ipd-process-parent.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { UserRoleService } from '../../../shared/services/user-role-service';
import { TestSummaryService } from '../service/test-summary.service';
import { DealIpdBasicInfoModel } from '../model/deal-ipd-basicinfo.model';

@Component({
  selector: 'sfp-test-summary',
  templateUrl: './tests-summary.component.html',
  styleUrls: ['./tests-summary.component.scss'],
  providers: [TestSummaryService]
})
export class TestsSummaryComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public title = 'Test Summary';
  public testDatalineItems: Array<TestDataModel> = [];
  public ipdParams: IpdAdjustmentParams;
  public defaultActiveTab: string = 'active';
  public testSummaryModel: TestSummaryModel;
  public tabsChunks: IpdTabs[][];
  public chunkSize: number = 4;
  public internalTestLineItem: string;
  public dealIpdBasicInfoModel: DealIpdBasicInfoModel;

  //@Input() testSubType: string;

  constructor(private router: Router, private _testSummaryService: TestSummaryService,
    private _ipdProcessService: IpdProcessParentService,
    public _toastservice: GlobalToasterService,
    private _modalService: NgbModal,
    private _route: ActivatedRoute,
    private _userService: UserRoleService) {

    this._ipdProcessService.changeIpdLevel1MenuName('conditions/tests');
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this.router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.loadTestSummaryData();
    this.getDealIpdBasicInfo();
  }

  getDealIpdBasicInfo() {
    this.dealIpdBasicInfoModel = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData();
    if (this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {
    }
    else {
      this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
        this.dealIpdBasicInfoModel = data;
      });
    }
  }

  loadTestSummaryData() {
    this._testSummaryService.getTestSummary(this.ipdParams.dealId, this.ipdParams.ipdRunId).subscribe(data => {
      console.log(data);
      this.testSummaryModel = data;
      this.createTabChunks();
      console.log(JSON.stringify(this.testSummaryModel));
    }, (error: any) => {
      console.log(error);
    });
  }

  redirectToSelectedTestTab(testTypeName: string) {
    this.defaultActiveTab = '';

    this.testSummaryModel.ipdTabs.forEach(x => {
      x.isActiveTab = '';
    });

    let data = this.testSummaryModel.ipdTabs.filter(x => x.internalTestLineItem == testTypeName);
    data.forEach(x => {
      x.isActiveTab = 'active'
    });
    this.createTabChunks();
  }

  public items: any[];

  expanded(item: any) {
    item.expanded = !item.expanded;
    this.items = this.getItems(this.testDatalineItems, null, 0);
  }

  getItems(data, items, index) {
    data.forEach(x => {
      if (!items) items = [];
      items.push(x);
      items[items.length - 1].index = index;
      if (x.childLineItems && x.expanded) this.getItems(x.subtasks, items, index + 1);
    });
    return items;
  }

  loadTestData(testTypeName: string) {
    this.testDatalineItems = [];
    this._testSummaryService.getTestTypeData(this.ipdParams.dealId, this.ipdParams.ipdRunId, testTypeName).subscribe(data => {
      this.testDatalineItems = data;
      this.items = data;

      console.log(this.items);

    }, (error: any) => {
      console.log(error);
    });
  }

  onTabChange(tabName: string) {
    if (tabName === "Test Summary") {
      this.defaultActiveTab = 'active';

      this.testSummaryModel.ipdTabs.forEach(x => {
        x.isActiveTab = '';
      });

    } else {
      this.loadTestData(tabName);
      this.redirectToSelectedTestTab(tabName);

    }

    this.createTabChunks();
  }

  createTabChunks() {
    this.tabsChunks = this.chunkArrayInGroups(this.testSummaryModel.ipdTabs, this.chunkSize);
  }
  chunkArrayInGroups(arr, size) {
    var myArray = [];
    for (var i = 0; i < arr.length; i += size) {
      myArray.push(arr.slice(i, i + size));
    }
    return myArray;
  }

  getTestExcel(testTypeName: string) {
    var displayName = '';
    if (testTypeName == 'TestSummary') {
      displayName = 'Test-Summary';
    } else if (testTypeName == 'ICTMonthly') {
      displayName = 'Interest-Coverage-Test-Monthly';
    } else if (testTypeName == 'ICT12MonthsForwardTest') {
      displayName = 'Interest-Coverage-Test-12Months';
    } else if (testTypeName == 'OCTMonthly') {
      displayName = 'Overcollateralisation-Test-Monthly';
    } else if (testTypeName == '12MonthsForwardOCTTest') {
      displayName = 'Overcollateralisation-Test-12Months';
    } else {
      var tempArray = this.testSummaryModel.ipdTabs.filter(x => x.internalTestLineItem == testTypeName);
      var tempVar = tempArray[0].uiTabName;
      displayName = tempVar.split(' ').join('-');
    }

    this._testSummaryService.getTestExcel(this.ipdParams.dealId, this.ipdParams.ipdRunId, testTypeName).subscribe(data => {

      let FileName = displayName + "-" + this.dealIpdBasicInfoModel.dealName + "-"
        + this.datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, "LLL-yyyy") + "-IPD.xlsx";
      var blob = new Blob([this.s2ab(atob(data))], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
      });

      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = FileName;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);

    }, (error: any) => {
      console.log(error);
    });

  }
  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

}