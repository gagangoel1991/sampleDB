import { Component, EventEmitter, Input, Output } from "@angular/core";

@Component({
  selector: 'sfp-conditions-tests-date-header',
  templateUrl: './conditions-tests-date-header.component.html',
  styleUrls: ['./conditions-tests-date-header.component.scss']
})

export class ConditionsTestsDateHeaderComponent {
  @Input() ipdDates: Date[] = [];
  @Input() testType: string;
  @Output() testExcelEvent = new EventEmitter<string>();
  
  callParentTestExcel(testType: string): void {
    this.testExcelEvent.emit(testType);
  }
}