import { Component, EventEmitter, HostBinding, Input, Output } from "@angular/core";

@Component({
  styleUrls: ['./ipd-recursive-table.component.scss'],
  selector: "recursive-component",
  templateUrl: "./ipd-recursive-table.component.html",
})

export class RecursiveComponent {
  @Input() item: any;
  @Input() index: number = 0;
  @Input() withHyperLink: boolean = false;
  @Output() someEvent = new EventEmitter<string>();
  callParentOnTabChange(internalTestLineItem: string): void {
    this.someEvent.emit(internalTestLineItem);
  }
}
