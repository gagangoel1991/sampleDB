import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { CanDeactivateGuardService } from 'src/app/core/guard/can-deactivate/can-deactivate-guard.service';
import { IpdProcessModule } from './ipd-process.module';
import { IpdProcessParentComponent } from 'src/app/cash-waterfall/ipd-run-process/ipd-process-parent.component';
import { DailyCollectionComponent } from 'src/app/cash-waterfall/ipd-run-process/automated-data/daily-collection/daily-collection.component';
import { CashladderComponent } from './automated-data/cash-ladder/cash-ladder.component';
import { CollectionLedgerComponent } from './automated-data/collection-ledger/collection-ledger.component';
import { BondRatingComponent } from './automated-data/bond-rating/bond-rating.component';
import { ARRAdjustmentComponent } from './adjustments/arr/arr-adjustment.component';
import { APRAdjustmentComponent } from './adjustments/apr/apr-adjustment.component';
import { RevenueAdjustmentComponent } from './adjustments/revenue/revenue-adjustment.component';
import { PrincipalAdjustmentComponent } from './adjustments/principal/principal-adjustment.component';
import { CounterpartyRatingComponent } from './automated-data/counter-party-rating/counter-party-rating.component';
import { IntereseRateComponent } from './automated-data/interest-rate/interest-rate.component';
import { InvoiceIpdDataComponent } from './invoices/invoice-ipd-data.component';
import { SubLoanComponent } from './deal-detail/sub-loan/sub-loan.component';
import { ReserveComponent } from './deal-detail/reserve/reserve.component';
import { PDLBreakDownComponent } from './deal-detail/pdl-breakdown/pdl-breakdown.component';
import { PdlSummaryComponent } from './deal-detail/pdl-summary/pdl-summary.component';
import { NoteSummaryComponent } from './deal-detail/note-summary/note-summary.component';
import { APRWaterfallOutputComponent } from './waterfall-output/apr-output/apr-output.component';
import { PPPWaterfallOutputComponent } from './waterfall-output/ppp-output/ppp-output.component';
import { RPPWaterfallOutputComponent } from './waterfall-output/rpp-output/rpp-output.component';
import { ARRWaterfallOutputComponent } from './waterfall-output/arr-output/arr-output.component';
import { RatingComponent } from './triggers/rating-trigger/rating-trigger.component';
import { NonRatingComponent } from './triggers/non-rating-trigger/non-rating-trigger.component';
import { DealConditionTestComponent } from './triggers/deal-condition-test/deal-condition-test.component';
import { StormVsSfpComponent } from './deal-ipd-controls/storm-vs-sfp/storm-vs-sfp.component';
import { IpdSummaryComponent } from './ipd-summary/ipd-summary.component';
import { ManageInvoiceComponent } from '../invoice-management/manage/manage-invoice.component';
import { ManualFieldComponent } from './manual-field/manual-field.component';
import { PostWaterfallControlComponent } from './deal-ipd-controls/post-waterfall-control/post-waterfall-control.component';
import { SwapRatingTriggerComponent } from './triggers/swap-rating-trigger/swap-rating-trigger.component';
import { DealSwapComponent } from './deal-detail/deal-swap/deal-swap.component';
import { CollectionsAndReservesComponent } from './deal-detail/collections-and-reserves/collections-and-reserves.component';
import { FundsParentComponent } from './deal-detail/funds/funds-parent.component';
import { BondSwapComponent } from './deal-detail/bond-swap/bond-swap.component';
import { CBNoteSummaryComponent } from './deal-detail/cb-note-summary/cb-note-summary.component';
import { SoniaCompoundingComponent } from './deal-detail/sonia-compounding/sonia-compounding.component';
import { TestsSummaryComponent } from './tests/tests-summary.component';


export const routes: Routes = [
    {
        path: '',
        component: IpdProcessParentComponent,
        children: [
            { path: '', redirectTo: 'ipd_summary', pathMatch: 'full' },
            {
                path: 'ipd_summary',
                component: IpdSummaryComponent,
                // data: { breadcrumb: 'IPD Run Process -> Automated Data -> Daily Collection' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'automated_data/daily_collection',
                component: DailyCollectionComponent,
                data: { breadcrumb: 'IPD Run Process -> Automated Data -> Daily Collection' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'automated_data/collection_ledger',
                component: CollectionLedgerComponent,
                data: { breadcrumb: 'IPD Run Process -> Automated Data -> Collection Ledger' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'automated_data/cash_ladder',
                component: CashladderComponent,
                data: { breadcrumb: 'IPD Run Process -> Automated Data -> Cash Ladder' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'ratings/bond_rating',
                component: BondRatingComponent,
                data: { breadcrumb: 'IPD Run Process -> Automated Data -> Bond Rating' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'ratings/cp_rating',
                component: CounterpartyRatingComponent,
                data: { breadcrumb: 'IPD Run Process -> Automated Data -> Counterparty Rating' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'automated_data/interest_rates',
                component: IntereseRateComponent,
                data: { breadcrumb: 'IPD Run Process -> Automated Data -> Interest Rates' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'invoices',
                component: InvoiceIpdDataComponent,
                data: { breadcrumb: 'IPD Run Process -> Invoices' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            { path: 'adjustments', redirectTo: 'adjustments/arr', pathMatch: 'full' },
            {
                path: 'adjustments/arr',
                component: ARRAdjustmentComponent,
                data: { breadcrumb: 'IPD Run Process -> Adjustment -> ARR' },
                canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'adjustments/apr',
                component: APRAdjustmentComponent,
                data: { breadcrumb: 'IPD Run Process -> Adjustment -> APR' },
                canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'adjustments/revenue',
                component: RevenueAdjustmentComponent,
                data: { breadcrumb: 'IPD Run Process -> Adjustment -> Revenue' },
                canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'adjustments/principal',
                component: PrincipalAdjustmentComponent,
                data: { breadcrumb: 'IPD Run Process -> Adjustment -> principal' },
                canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'subloan',
                component: SubLoanComponent,
                data: { breadcrumb: 'IPD Run Process -> SubLoan -> SubLoan' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'reserve',
                component: ReserveComponent,
                data: { breadcrumb: 'IPD Run Process -> Reserve -> Reserve' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'pdl_breakdown',
                component: PDLBreakDownComponent,
                data: { breadcrumb: 'IPD Run Process -> pdl_breakdown -> pdl_breakdown' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'pdl',
                component: PdlSummaryComponent,
                data: { breadcrumb: 'IPD Run Process -> pdl_breakdown -> pdl_breakdown' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'note_summary',
                component: NoteSummaryComponent,
                data: { breadcrumb: 'IPD Run Process -> note_summary -> note_summary' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'cbnote_summary',
                component: CBNoteSummaryComponent,
                data: { breadcrumb: 'IPD Run Process -> cbnote_summary -> cbnote_summary' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'deal_swap',
                component: DealSwapComponent,
                data: { breadcrumb: 'IPD Run Process -> deal_swap -> deal_swap' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'bond_swap',
                component: BondSwapComponent,
                data: { breadcrumb: 'IPD Run Process -> bond_swap -> bond_swap' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'ledgers',
                component: FundsParentComponent,
                data: { breadcrumb: 'IPD Run Process -> funds -> funds' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'sonia_compounding',
                component: SoniaCompoundingComponent,
                data: { breadcrumb: 'IPD Run Process -> sonia_compounding -> sonia_compounding' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'cashwaterfall_output',
                component: ARRWaterfallOutputComponent,
                data: { breadcrumb: 'IPD Run Process -> cashwaterfall_output -> cashwaterfall_output' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'cashwaterfall_output/apr',
                component: APRWaterfallOutputComponent,
                data: { breadcrumb: 'IPD Run Process -> cashwaterfall_output -> cashwaterfall_output' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'cashwaterfall_output/arr',
                component: ARRWaterfallOutputComponent,
                data: { breadcrumb: 'IPD Run Process -> cashwaterfall_output -> cashwaterfall_output' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'cashwaterfall_output/rpp',
                component: RPPWaterfallOutputComponent,
                data: { breadcrumb: 'IPD Run Process -> cashwaterfall_output -> cashwaterfall_output' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'cashwaterfall_output/ppp',
                component: PPPWaterfallOutputComponent,
                data: { breadcrumb: 'IPD Run Process -> cashwaterfall_output -> cashwaterfall_output' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'triggers',
                component: RatingComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> rating' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'triggers/rating',
                component: RatingComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> rating' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'triggers/rating/swap_rating',
                component: SwapRatingTriggerComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> swap_rating' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'tests',
                component: TestsSummaryComponent,
                data: { breadcrumb: 'IPD Run Process -> test -> summary' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'triggers/non_rating',
                component: NonRatingComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> non_rating' },
                //canDeactivate: [CanDeactivateGuardService],
            }
            ,
            {
                path: 'conditions',
                component: DealConditionTestComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> conditions' },
                //canDeactivate: [CanDeactivateGuardService],
            }
            ,
            {
                path: 'controls/storm-vs-sfp',
                component: StormVsSfpComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> conditions' },
                //canDeactivate: [CanDeactivateGuardService],
            }
            ,
            {
                path: 'invoices/view/:invoiceid',
                component: ManageInvoiceComponent,
                data: { breadcrumb: 'IPD Management > View Invoice' },
                //  canDeactivate: [CanDeactivateGuardService],
                // resolve: { data: IpdProcessMenuResolverService } 
            }
            ,
            {
                path: 'controls/Postwaterfall',
                component: PostWaterfallControlComponent,
                data: { breadcrumb: 'IPD Run Process -> triggers -> conditions' },
                //canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'manualfield',
                component: ManualFieldComponent,
                data: { breadcrumb: 'IPD Run Process -> manual Field' },
                canDeactivate: [CanDeactivateGuardService],
            },
            {
                path: 'collection-reserve-interest',
                component: CollectionsAndReservesComponent,
                data: { breadcrumb: 'IPD Run Process -> collection reserve' },
                //canDeactivate: [CanDeactivateGuardService],
            },

        ]
    },

];

export const routing: ModuleWithProviders<IpdProcessModule> = RouterModule.forChild(routes);