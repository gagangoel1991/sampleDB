import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = { suppressScrollX: true };
import { DirectivesModule } from 'src/app/core/theme/directives/directives.module';
import { PipesModule } from 'src/app/core/theme/pipes/pipes.module';
import { routing } from './ipd-process.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

import { IpdProcessParentComponent } from 'src/app/cash-waterfall/ipd-run-process/ipd-process-parent.component';
import { DailyCollectionComponent } from 'src/app/cash-waterfall/ipd-run-process/automated-data/daily-collection/daily-collection.component';
import { CashladderComponent } from './automated-data/cash-ladder/cash-ladder.component';
import { CollectionLedgerComponent } from './automated-data/collection-ledger/collection-ledger.component';
import { BondRatingComponent } from './automated-data/bond-rating/bond-rating.component';
import { DealDetailComponent } from './deal-detail/deal-detail.component';
import { ARRAdjustmentComponent } from './adjustments/arr/arr-adjustment.component';
import { APRAdjustmentComponent } from './adjustments/apr/apr-adjustment.component';
import { RevenueAdjustmentComponent } from './adjustments/revenue/revenue-adjustment.component';
import { PrincipalAdjustmentComponent } from './adjustments/principal/principal-adjustment.component';
import { CommentPopUpComponent } from './automated-data/comment-popup/comment-popup.component';
import { DebounceClickDirective } from 'src/app/shared/directive/debounce-click-directive';
import { CounterpartyRatingComponent } from './automated-data/counter-party-rating/counter-party-rating.component';
import { IpdProcessParentService } from './service/ipd-process-parent.service';
import { IntereseRateComponent } from './automated-data/interest-rate/interest-rate.component';
import { InvoiceIpdDataComponent } from './invoices/invoice-ipd-data.component';
import { SubLoanComponent } from './deal-detail/sub-loan/sub-loan.component';
import { ReserveComponent } from './deal-detail/reserve/reserve.component';
import { FourDigitDecimalNumberComponent } from './ipd-decimal-limit.component';
import { PDLBreakDownComponent } from './deal-detail/pdl-breakdown/pdl-breakdown.component';
import { PdlSummaryComponent } from './deal-detail/pdl-summary/pdl-summary.component';
import { NoteSummaryComponent } from './deal-detail/note-summary/note-summary.component';
import { APRWaterfallOutputComponent } from './waterfall-output/apr-output/apr-output.component';
import { ARRWaterfallOutputComponent } from './waterfall-output/arr-output/arr-output.component';
import { PPPWaterfallOutputComponent } from './waterfall-output/ppp-output/ppp-output.component';
import { RPPWaterfallOutputComponent } from './waterfall-output/rpp-output/rpp-output.component';
import { RatingComponent } from './triggers/rating-trigger/rating-trigger.component';
import { NonRatingComponent } from './triggers/non-rating-trigger/non-rating-trigger.component';
import { DealConditionTestComponent } from './triggers/deal-condition-test/deal-condition-test.component';
import { StormVsSfpComponent } from './deal-ipd-controls/storm-vs-sfp/storm-vs-sfp.component';
import { IpdSummaryComponent } from './ipd-summary/ipd-summary.component';
import { ManualFieldComponent } from './manual-field/manual-field.component';
import { PostWaterfallControlComponent } from './deal-ipd-controls/post-waterfall-control/post-waterfall-control.component';
import { DealSwapComponent } from './deal-detail/deal-swap/deal-swap.component';
import { FundsParentComponent } from './deal-detail/funds/funds-parent.component';
import { SwapRatingTriggerComponent } from './triggers/swap-rating-trigger/swap-rating-trigger.component';
import { CollectionsAndReservesComponent } from './deal-detail/collections-and-reserves/collections-and-reserves.component';
import { GenericLineItemBasedComponent } from 'src/app/shared/components/line-item-based-component/generic-line-item-based-component';
import { BondSwapComponent } from './deal-detail/bond-swap/bond-swap.component';
import { CBNoteSummaryComponent } from './deal-detail/cb-note-summary/cb-note-summary.component';
import { SoniaCompoundingComponent } from './deal-detail/sonia-compounding/sonia-compounding.component';
import { TestsSummaryComponent } from './tests/tests-summary.component';
import { RecursiveComponent } from './tests/ipd-recursive-table/ipd-recursive-table.component';
import { OctTestDataComponent } from './tests/oct-test-data/oct-test-data.component';
import { IctTestDataComponent } from './tests/ict-test-data/ict-test-data.component';
import { TestsResultPipe } from './tests/tests-result.pipe';
import { ConditionsTestsDateHeaderComponent } from './tests/conditions-tests-date-header/conditions-tests-date-header.component';


@NgModule({
  imports: [
    CommonModule,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    MultiselectDropdownModule,
    routing,
    NgxDatatableModule,
    CustomControlModule,
    NgSelectModule,
    NgbModule,
  ],

  declarations: [
    IpdProcessParentComponent,
    DailyCollectionComponent,
    CashladderComponent,
    CollectionLedgerComponent,
    BondRatingComponent,
    DealDetailComponent,
    ARRAdjustmentComponent,
    APRAdjustmentComponent,
    RevenueAdjustmentComponent,
    PrincipalAdjustmentComponent,
    CommentPopUpComponent,
    DebounceClickDirective,
    CounterpartyRatingComponent,
    IntereseRateComponent,
    InvoiceIpdDataComponent,
    SubLoanComponent,
    ReserveComponent,
    PDLBreakDownComponent,
    FourDigitDecimalNumberComponent,
    PdlSummaryComponent,
    NoteSummaryComponent,
    APRWaterfallOutputComponent,
    ARRWaterfallOutputComponent,
    PPPWaterfallOutputComponent,
    RPPWaterfallOutputComponent,
    RatingComponent,
    NonRatingComponent,
    DealConditionTestComponent,
    StormVsSfpComponent,
    IpdSummaryComponent,
    PostWaterfallControlComponent,
    ManualFieldComponent,
    DealSwapComponent,
    SwapRatingTriggerComponent,
    CollectionsAndReservesComponent,
    FundsParentComponent,
    GenericLineItemBasedComponent,
    BondSwapComponent,
    CBNoteSummaryComponent,
    SoniaCompoundingComponent,
    TestsSummaryComponent,
    RecursiveComponent,
    OctTestDataComponent,
    IctTestDataComponent,
    TestsResultPipe,
    ConditionsTestsDateHeaderComponent,
  ],
  entryComponents: [
    CommentPopUpComponent
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    IpdProcessParentService
  ],
  exports: [
    FourDigitDecimalNumberComponent
  ]
})
export class IpdProcessModule { }