import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class ReserveService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getReserveData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserve/getReserveData/${dealId}/${ipdRunId}`);
    }
}