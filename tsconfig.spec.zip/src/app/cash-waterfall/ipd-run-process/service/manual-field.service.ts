import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class ManualFieldService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getManualFieldData(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/ManualField/getManualFieldData/${ipdRunId}`);
    }

    public updateManualFieldData(row: any): Observable<number> {
        return this.globalHttpService.PostRequest("/ManualField/updateManualFieldData", row);
    }

    public resetManualFieldData(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/ManualField/resetManualFieldData/${ipdRunId}`);
    }

    public getManualExcelData(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/ManualField/getManualExcelData/${ipdRunId}`);
    }

    public resetManualFieldDealSwapData(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/ManualField/resetManualFieldDealSwapData/${ipdRunId}`);
    }
}