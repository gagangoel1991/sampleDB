import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable({
  providedIn: 'root'
})
export class IpdSummaryService {

  constructor(private globalHttpService: GlobalHttpService) { }

    public getIpdSummaryData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/ipdSummary/GetIpdSummaryData/${dealId}/${ipdRunId}`);
    }
}