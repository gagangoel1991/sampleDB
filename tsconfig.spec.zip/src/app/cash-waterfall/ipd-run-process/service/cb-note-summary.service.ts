import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class CBNoteSummaryService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getNoteSummary(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/cbNoteSummary/getNoteSummary/${dealId}/${ipdRunId}`);
    }
}