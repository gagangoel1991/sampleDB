import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'
import { BondRatingModel, BondRatingParam } from '../model/bond-rating.model'

@Injectable()
export class InterestRateService {
    constructor(private globalHttpService: GlobalHttpService) { }

    public getinterestRateList(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/interestRate/getInterestRateData/ ${dealId}/${ipdRunId}`);
    }

    public saveInterestRate(row: any): Observable<any> {
        return this.globalHttpService.PostRequest("/interestRate/saveInterestRate", row);
    }
}