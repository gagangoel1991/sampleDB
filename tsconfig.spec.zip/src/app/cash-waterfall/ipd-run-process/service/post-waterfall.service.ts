import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';

@Injectable({
  providedIn: 'root'
})
export class PostWaterfallService {

  constructor(private _globalHttpService: GlobalHttpService) { }
  
  public getPostwaterfallExcelFile(dealName: string, asAtDate: string): Observable<any> {
    return this._globalHttpService.DownloadFile('/ipdrunprocess/controls/CreatePostWFControlExcelFile/' + dealName + "/" + asAtDate);
  }

  public getPostwaterfallControlData(dealName: string, asAtDate: string): Observable<any> {
    return this._globalHttpService.GetRequest('/ipdrunprocess/controls/GetPostWFControlDataFromFile/' + dealName + "/" + asAtDate);
  }
}
