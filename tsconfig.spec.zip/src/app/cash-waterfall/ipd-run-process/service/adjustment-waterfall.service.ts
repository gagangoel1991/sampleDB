import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'
import { IpdAdjustmentParams, CashwaterfallLineItemModel } from '../model/cash-waterfall-line-item-model'

@Injectable()
export class AdjustmentWaterfallService {


    constructor(private globalHttpService: GlobalHttpService) { }


    public getPrincipalWaterfallData(ipdAdjustmentParams: IpdAdjustmentParams): Observable<any> {
        return this.globalHttpService.GetRequest(`/adjustment/waterfall/${ipdAdjustmentParams.dealId}/${ipdAdjustmentParams.ipdRunId}/${ipdAdjustmentParams.waterfallCategoryName}`);
    }

    public savePrincipalWaterfall(principalWaterfallLineItemModel: CashwaterfallLineItemModel[]): Observable<any> {
        return this.globalHttpService.PostRequest("/adjustment/savePrincipalWaterfall", principalWaterfallLineItemModel);
    }

    public getPrincipalWaterfallOutputData(dealId:number,ipdRunId:number): Observable<any> {
        return this.globalHttpService.GetRequest(`/adjustment/getPrincipalWaterfallOutput/${dealId}/${ipdRunId}`);
    }

    public getRevenueWaterfallOutputData(dealId:number,ipdRunId:number): Observable<any> {
        return this.globalHttpService.GetRequest(`/adjustment/getRvenueWaterfallOutput/${dealId}/${ipdRunId}`);
    }
}