import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'


@Injectable()
export class InvoiceIpdDataService {
    constructor(private globalHttpService: GlobalHttpService) { }
    public getInvoiceIpdData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/invoice/getInvoiceIpdData/${dealId}/${ipdRunId}`);
    }

    public getInvoice(invoiceId: number):Observable<any> {
        return this.globalHttpService.GetRequest("/invoice/getinvoice", {'invoiceId': invoiceId});
    }

    public downloadInvoiceFile(invoiceId: number):Observable<any> {
        return this.globalHttpService.DownloadFile("/invoice/downloadInvoiceFile", {'invoiceId': invoiceId});
    }
}