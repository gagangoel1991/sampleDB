import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'
import { CashLadderParams, CashLadderModel } from '../model/cash-ladder.model'

@Injectable()
export class CashLadderService {


    constructor(private globalHttpService: GlobalHttpService) { }


    public getCashLadderList(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest('/cashladder/getCashLadderData/' + dealId + "/" + ipdRunId);
    }

    public saveCashLadderData(x: any): Observable<any> {
        return this.globalHttpService.PostRequest("/cashladder/saveCashLadderData", JSON.stringify(x));
    }
}