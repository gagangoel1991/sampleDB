import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'
import { BondRatingModel, BondRatingParam } from '../model/bond-rating.model'

@Injectable()
export class BondRatingService {


    constructor(private globalHttpService: GlobalHttpService) { }


    public getBondRatingList(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/bondRating/getBondRatingData/ ${dealId}/${ipdRunId}`);
    }

    public saveBondRatingData(row: any): Observable<any> {
        return this.globalHttpService.PostRequest("/bondRating/saveBondRatingData", row);
    }

    public getCreditRatings(): Observable<any> {
        return this.globalHttpService.GetRequest("/bondRating/getCreditRatings");
    }

    public resetBondRating(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/bondRating/resetBondRating/${ipdRunId}`);
    }

    public isBondRatingEdited(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/bondRating/isBondRatingEdited/${ipdRunId}`);
    }
}