import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'
import { DailyCollectionModel } from '../model/daily-collection.model'

@Injectable()
export class DailyCollectionService {


    constructor(private globalHttpService: GlobalHttpService) { }


    public getDailyCollectionList(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest("/dailyCollection/getDailyCollectionData/" + dealId + "/" + ipdRunId);
    }

    public saveDailyCollectionData(dailyCollectionModel: DailyCollectionModel): Observable<any> {
        return this.globalHttpService.PostRequest("/dailyCollection/saveDailyCollectionData", dailyCollectionModel);
    }
}