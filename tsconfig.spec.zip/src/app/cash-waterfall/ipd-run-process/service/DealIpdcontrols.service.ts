import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';

@Injectable()
export class DealIpdcontrols {
  constructor(private _globalHttpService: GlobalHttpService) { }

  public getStormVsSfpData(dealId: number, ipdRunId: number): Observable<any> {
    return this._globalHttpService.GetRequest('/ipdrunprocess/controls/stormvssfp/' + dealId + "/" + ipdRunId);
  }
  public getStormVsSfpExcelFile(dealId: number, ipdRunId: number): Observable<any> {
    return this._globalHttpService.GetRequest('/ipdrunprocess/controls/getStormVsSfpExcelFile/' + dealId + "/" + ipdRunId);
  }
}