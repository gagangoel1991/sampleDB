import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'


@Injectable()
export class RatingUploadDataService {
    constructor(private globalHttpService: GlobalHttpService) { }
    public getDealIpdDates(): Observable<any> {
        return this.globalHttpService.GetRequest("/RatingUpload/GetDealIpdDates");
    }

    public processRating(ratingData: FormData): Observable<any> {
        return this.globalHttpService.PostFormDataRequest("/RatingUpload/parseRatingFile", ratingData);
    }

    public saveRating(ratingData: FormData): Observable<any> {
        return this.globalHttpService.PostFormDataRequest("/RatingUpload/saveRating", ratingData);
    }
    public getRatingListingData(): Observable<any> {
        return this.globalHttpService.GetRequest("/RatingUpload/GetRatingListingData");
    }
    public getUserRatingSavedData(userRatingFileUploadDetailId: number): Observable<any> {
        return this.globalHttpService.GetRequest("/RatingUpload/GetUserRatingSavedData/" + userRatingFileUploadDetailId);
    }
    public downloadRatingFile(OriginalFileName: string, UploadedFileName: string): Observable<any> {
        return this.globalHttpService.GetRequest("/RatingUpload/DownloadRatingFile/" + OriginalFileName + "/" + UploadedFileName);
    }
    public uploadRatingDataRecordExist(ratingData: FormData): Observable<any> {
        return this.globalHttpService.PostFormDataRequest("/RatingUpload/UploadRatingDataRecordExist", ratingData);
    }
    public deleteRatingData(userRatingFileUploadDetailId: number): Observable<any> {
        return this.globalHttpService.DeleteRequest("/RatingUpload/delete", userRatingFileUploadDetailId);
    }
    public downloadRatingSampleFile():Observable<any> {
        return this.globalHttpService.DownloadFile("/RatingUpload/DownloadRatingSampleFile");
    }
}