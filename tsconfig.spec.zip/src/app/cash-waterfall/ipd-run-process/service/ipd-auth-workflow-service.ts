import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { IAuthWorkflowModel } from '../../../shared/model/auth-workflow-model';
import { AuthWorkflowStep } from '../../../shared/model/auth-workflow-enum';



@Injectable()
export class IpdAuthWorkflowService {
  constructor(private _globalHttpService: GlobalHttpService) { }


  public manageIpdAuthWorkflow(model: IAuthWorkflowModel): Observable<any> {
    return this._globalHttpService.PostRequest('/ipdAuthWorkflow/manageIpdAuthWorkflow/', JSON.stringify(model));
  }

  public manageIpdAuthWorkflowByUser(model: IAuthWorkflowModel): Observable<any> {
    return this._globalHttpService.PostRequest('/ipdAuthWorkflow/manageIpdAuthWorkflowByUser/', JSON.stringify(model));
  }

  public async getIpdAuthWorkflowStatus(dealId: number, ipdRunId: number): Promise<any> {
    let model: any = {};
    model.dealId = dealId;
    model.ipdRunId = ipdRunId;
    return await this._globalHttpService.PostRequest('/ipdAuthWorkflow/getIpdAuthWorkflowStatus/', JSON.stringify(model)).toPromise();
  }

  public downloadInvestorReport(fileName: string): Observable<any> {
    return this._globalHttpService.DownloadFile(`/report/DownloadInvestorReport/${fileName}`);
  }

  public async validateIPD(dealIpdRunId: number, workFlowStep: AuthWorkflowStep): Promise<any> {
    return this._globalHttpService.GetRequest(`/ipdAuthWorkflow/validateIPD/${dealIpdRunId}/${workFlowStep}`).toPromise();
  }
}
