import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'


@Injectable()
export class CounterpartyRatingService {
    constructor(private globalHttpService: GlobalHttpService) { }

    public getCounterPartyRatingList(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/counterPartyRating/getCounterpartyRatingData/ ${dealId}/${ipdRunId}`);
    }

    public saveCounterPartyRatingData(row: any): Observable<any> {
        return this.globalHttpService.PostRequest("/counterPartyRating/saveCounterpartyRatingData", row);
    }

    public getCreditRatings(): Observable<any> {
        return this.globalHttpService.GetRequest("/bondRating/getCreditRatings");
    }

    public resetCPRating(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/counterPartyRating/resetCPRating/${ipdRunId}`);
    }

    public isCPRatingEdited(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/counterPartyRating/isCPRatingEdited/${ipdRunId}`);
    }
}