import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class FundsService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getSwapCollateral(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/getSwapCollateral/${dealId}/${ipdRunId}`);
    }

    public getPreMaturityLiquidityFund(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/getPreMaturityLiquidityFund/${dealId}/${ipdRunId}`);
    }

    public getReserveFund(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/getReserveFund/${dealId}/${ipdRunId}`);
    }

    public getCouponPaymentFund(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/getCouponPaymentFund/${dealId}/${ipdRunId}`);
    }

    public getReserveFundExcel(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/getReserveFundExcel/${dealId}/${ipdRunId}`);
    }

    public getReserveFundIpdDateHeader(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/getReserveFundIpdDateHeader/${dealId}/${ipdRunId}`);
    }

    
    public getRevenueLedger(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/GetRevenueLedger/${dealId}/${ipdRunId}`);
    }

    
    public getPrincipalLedger(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/GetPrincipalLedger/${dealId}/${ipdRunId}`);
    }

    
    public getPaymentLedger(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/GetPaymentLedger/${dealId}/${ipdRunId}`);
    }

    
    public getMaturingLoansLedger(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/GetMaturingLoansLedger/${dealId}/${ipdRunId}`);
    }

    
    public getCapitalAccountLedger(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/reserveFund/GetCapitalAccountLedger/${dealId}/${ipdRunId}`);
    }
}