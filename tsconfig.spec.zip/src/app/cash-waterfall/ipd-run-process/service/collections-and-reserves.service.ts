import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class CollectionsAndReserves {


    constructor(private globalHttpService: GlobalHttpService) { }


    public getCollandIntData(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/CollAndInt/getCollandIntData/${ipdRunId}`);
    }
    
    public getCollandIntExcelData(ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/CollAndInt/getCollandIntExcelData/${ipdRunId}`);
    }  
  
}