import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { DealConditionTestModel } from '../model/deal-condition-test.model';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';

@Injectable({
  providedIn: 'root'
})
export class DealConditionTestService {

  constructor(private globalHttpService: GlobalHttpService) { }

  public getDealConditionTestData(dealId: number, ipdRunId: number): Observable<any> {
    return this.globalHttpService.GetRequest(`/triggers/getTriggersConditions/${dealId}/${ipdRunId}`);
  }

  public saveDealConditionTestData(model: DealConditionTestModel): Observable<any> {
    return this.globalHttpService.PostRequest(`/triggers/saveTriggersConditions/`, model);
  }

  public resetDealConditionTestData(ipdRunId: number): Observable<any> {
    return this.globalHttpService.GetRequest(`/triggers/resetTriggersConditions/${ipdRunId}`);
  }
}
