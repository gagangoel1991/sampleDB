import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class DealSwapService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getDealSwapData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/dealSwap/getDealSwapData/${dealId}/${ipdRunId}`);
    }

    public getDealSwapExcel(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/dealSwap/getDealSwapExcel/${dealId}/${ipdRunId}`);
    }
}