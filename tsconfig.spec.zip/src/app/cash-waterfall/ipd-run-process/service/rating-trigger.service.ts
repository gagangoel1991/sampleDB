import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class RatingTriggerService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getRatingTriggerData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/triggers/getRatingTriggers/${dealId}/${ipdRunId}`);
    }

    public getSwapRatingTriggerData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/triggers/getSwapRatingTriggers/${dealId}/${ipdRunId}`);
    }
}