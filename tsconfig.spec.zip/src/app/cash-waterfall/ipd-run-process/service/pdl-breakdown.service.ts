import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class PDLBreakdownService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getPDLBreakdownData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/pdlBreakdown/getPdlBreakdownData/${dealId}/${ipdRunId}`);
    }
}