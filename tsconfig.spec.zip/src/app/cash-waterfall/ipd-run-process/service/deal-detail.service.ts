import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service'
import { Observable } from 'rxjs'
import { IpdAdjustmentParams } from '../model/cash-waterfall-line-item-model';

@Injectable({
  providedIn: 'root'
})
export class DealDetailService {

  constructor(private globalHttpService: GlobalHttpService) { }

  public getDealDetailData(ipdAdjustmentParams: IpdAdjustmentParams): Observable<any> {
    return this.globalHttpService.GetRequest(`/IpdProcess/dealdetail/ ${ipdAdjustmentParams.dealId}/${ipdAdjustmentParams.ipdRunId}`);
  }

}
