import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { IAuthWorkflowModel } from '../../../shared/model/auth-workflow-model';

@Injectable()
export class UpstreamDataAuthService {
  constructor(private _globalHttpService: GlobalHttpService) { }

  public manageUpstreamDataAuthWorkflow(model: IAuthWorkflowModel): Observable<any> {
    return this._globalHttpService.PostRequest('/upstreamDataAuthWorkflow/manageUpstreamDataAuthWorkflow/', JSON.stringify(model));
  }

  public manageUpstreamDataAuthWorkflowByUser(model: IAuthWorkflowModel): Observable<any> {
    return this._globalHttpService.PostRequest('/upstreamDataAuthWorkflow/manageUpstreamDataAuthWorkflowByUser/', JSON.stringify(model));
  }

  public getUpstreamDataAuthWorkflowStatus(dealId: number, ipdRunId: number, workflowType: number): Observable<any> {
    let model: any = {};
    model.dealId = dealId;
    model.ipdRunId = ipdRunId;
    model.workflowType = workflowType;
    return this._globalHttpService.PostRequest('/upstreamDataAuthWorkflow/getUpstreamDataAuthWorkflowStatus/', JSON.stringify(model));
  }
}
