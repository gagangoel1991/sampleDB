import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class BondSwapService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getDealSwapData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/bondSwap/getBondSwapData/${dealId}/${ipdRunId}`);
    }

    public getBondSwapExcel(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/bondSwap/geBondSwapExcel/${dealId}/${ipdRunId}`);
    }
}