import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';

@Injectable()
export class CollectionLedgerService {
  constructor(private _globalHttpService: GlobalHttpService) { }

  public getCollectionLedger(dealId: number, ipdRunId: number): Observable<any> {
    return this._globalHttpService.GetRequest('/ipdrunprocess/automateddata/colledger/get/' + dealId + "/" + ipdRunId);
  }

  public updateCollectionLedger(x: any): Observable<any> {
    return this._globalHttpService.PostRequest('/ipdrunprocess/automateddata/colledger/update', JSON.stringify(x));
  }
}
