import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'
import { NonRatingTriggerModel } from '../model/non-rating-trigger.model';

@Injectable()
export class NonRatingTriggerService {

    constructor(private globalHttpService: GlobalHttpService) { }
    public getNontRatingTriggerData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/triggers/getNonRatingTriggers/${dealId}/${ipdRunId}`);
    }

    public saveNontRatingTriggerData(model: NonRatingTriggerModel): Observable<any> {
        return this.globalHttpService.PostRequest(`/triggers/saveNonRatingTrigger/`, model);
    }


    public resetNontRatingTriggerData(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/triggers/resetNontRatingTrigger/${dealId}/${ipdRunId}`);
    }
}