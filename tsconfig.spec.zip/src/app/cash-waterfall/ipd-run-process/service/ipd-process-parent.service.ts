import { EventEmitter, Injectable, Output } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable, BehaviorSubject } from 'rxjs';
import { DealIpdBasicInfoModel } from '../model/deal-ipd-basicinfo.model';
import { IAuthWorkflowModel } from '../../../shared/model/auth-workflow-model';
import { Router } from '@angular/router';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';

@Injectable()
export class IpdProcessParentService {

  private _globalHttpService: GlobalHttpService;

  private ipdLevel1MenuName = new BehaviorSubject<string>('automated_data');
  private ipdWorkflowStatus = new BehaviorSubject<string>('draft');
  currentipdLevel1MenuName = this.ipdLevel1MenuName.asObservable();
  currentIpdWorkflowStatus = this.ipdWorkflowStatus.asObservable();
  private DealIpdBasicInfoGlobalModelData: DealIpdBasicInfoModel;

  private _obsoleteUrlHeader = "Deal IPD Management";
  private _obsoleteUrlMessage = "Redirecting to 'Deal IPD  Management' due to Obsolete URL Fragments.";

  changeIpdLevel1MenuName(menuName: string) {
    this.ipdLevel1MenuName.next(menuName);
  }

  changeIpdWorkflowStatus(workflowStatus: string) {
    console.log('workflowStatus->' + workflowStatus);
    this.ipdWorkflowStatus.next(workflowStatus);
  }

  getDealIpdWorkflowStatus() {
    return this.ipdWorkflowStatus.getValue();
  }

  constructor(private globalHttpService: GlobalHttpService, private _router: Router
    , private _toastservice: GlobalToasterService) {
    this._globalHttpService = globalHttpService;
  }

  ///This will return false if the IPD workflow status in ('Authorise', 'SendForAuthorisation')
  isIpdAllowDataChanges() {
    if (this.ipdWorkflowStatus.getValue() === 'Authorise' || this.ipdWorkflowStatus.getValue() === 'SendForAuthorisation') {
      return false;
    }
    else {
      return true;
    }
  }

  getDealIdAndIpdRunId(url) {
    var values: number[] = new Array(2);
    values[0] = url.split('/')[3]; //Set the deal Id
    values[1] = url.split('/')[4]; //Set the IPD Run Id

    return values;
  }

  @Output() public DealIpdBasicInfoModelChanged: EventEmitter<any> = new EventEmitter();
  setDealIpdBasicInfoGlobalModelData(val: DealIpdBasicInfoModel) {
    if (val == null || val.ipdDate == null) {
      this._router.navigate(['/cashwaterfall/ipd-management']);
      this._toastservice.openToast(ToasterTypes.warning, this._obsoleteUrlHeader, this._obsoleteUrlMessage);
    }
    this.DealIpdBasicInfoGlobalModelData = val;
  }
  getDealIpdBasicInfoGlobalModelData(): DealIpdBasicInfoModel {
    return this.DealIpdBasicInfoGlobalModelData
  }


  runIpd(dealId: number, ipdRunId: number, extraHeaders: Object): Observable<any> {
    return this.globalHttpService.GetRequestWithRequestHeaders(`/IpdProcess/runIpd/${dealId}/${ipdRunId}`, null, null, extraHeaders);
  }

  public CreateIrFile(dealIrConfigId: number, asAtDate: string, templateId: number, ipdRunId: number, dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest("/report/CreateIr", { 'dealIrConfigId': dealIrConfigId, 'asAtDate': asAtDate, 'templateId': templateId, 'ipdRunId': ipdRunId, 'dealId': dealId });
  }

  public withdrawIpd(authWorkflowModel: IAuthWorkflowModel): Observable<any> {
    return this._globalHttpService.PostRequest("/IpdProcess/withdrawIpd", authWorkflowModel);
  }

  public saveOverridedIRFile(templateData: FormData): Observable<any> {
    return this.globalHttpService.PostFormDataRequest('/IpdProcess/saveOverridedIRFile', templateData);
  }

  public downloadIrReconciliationFile(irFileName: string): Observable<any> {
    return this.globalHttpService.DownloadFile(`/IpdProcess/DownloadIrReconciliationFile/${irFileName}`);
  }
  public deleteIrReconciliationFile(fileName: string): Observable<any> {
    return this.globalHttpService.GetRequest(`/IpdProcess/DeleteIrReconciliationFile/${fileName}`);
  }

}