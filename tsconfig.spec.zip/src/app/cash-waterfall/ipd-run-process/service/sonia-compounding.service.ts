import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';

@Injectable()
export class SoniaCompoundingService {

  constructor(private globalHttpService: GlobalHttpService) { }

  public getSoniaCompoundingSummary(dealId: number, ipdRunId: number): Observable<any> {
    return this.globalHttpService.GetRequest(`/soniaCompounding/getSoniaCompoundingSummary/${dealId}/${ipdRunId}`);
  }
  public getSoniaCompoundingData(accrualStartDate: string, accrualEndDate: string): Observable<any> {
    return this.globalHttpService.GetRequest(`/soniaCompounding/getSoniaCompoundingData/${accrualStartDate}/${accrualEndDate}`);
  }
}
