import { Injectable } from '@angular/core';
import { GlobalHttpService } from '../../../core/services/api/global.http.service';
import { Observable } from 'rxjs'

@Injectable()
export class TestSummaryService {

    constructor(private globalHttpService: GlobalHttpService) { }

    public getTestSummary(dealId: number, ipdRunId: number): Observable<any> {
        return this.globalHttpService.GetRequest(`/test/summary/${dealId}/${ipdRunId}`);
    }

    public getTestTypeData(dealId: number, ipdRunId: number, testTypeName: string): Observable<any> {
        return this.globalHttpService.GetRequest(`/test/testData/${dealId}/${ipdRunId}/${testTypeName}`);
    }

    public getTestExcel(dealId: number, ipdRunId: number, testTypeName: string): Observable<any> {
        return this.globalHttpService.GetRequest(`/test/testExcel/${dealId}/${ipdRunId}/${testTypeName}`);
    }
}