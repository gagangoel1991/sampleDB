
export interface ISwapModel {
    swapId: number;
    swapName: string;
    ipdDate: string;
    payCouponPeriodStart: number;
    payCouponPeriodEnd: number;
    payNotional: number;
    payMarginDifferential: number;
    payRate: number;
    payAmount: number;
    receiveCouponPeriodStart: number;
    receiveCouponPeriodEnd: number;
    receiveNotional: number;
    receiveMarginDifferential: number;
    receiveRate: number;
    receiveAmount: number;
    payNetAmount: number;
    receiveNetAmount: number;
    payMargin: number;
    receiveMargin: number;
    payTotalAmount: number;
    receiveTotalAmount: number;
    payAccrualDays : number;
    receiveAccrualDays : number;
    payBaseRate : number;
    receiveBaseRate : number;
}


