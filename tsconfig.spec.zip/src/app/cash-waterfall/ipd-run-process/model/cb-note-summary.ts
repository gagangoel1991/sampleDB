export class CBNoteModel {
    public ipdDate: string
    public dealNoteId: number
    public couponPaymentStartPeriod: string
    public couponPaymentEndPeriod: string
    public daysInInterestPeriod: number
    public dayCountBasis: number
    public baseRate: number
    public couponRate: number
    public principalOutstanding_Ccy: number
    public principalOutstanding_GBP: number
    public interestAmountDue_Ccy: number
    public interestAmountDue_GBP: number
    public requiredRedemptionForHardBullet: number
    public redemptionAmountForExtendedBond_GT1yr: number
    public redemptionAmountForExtendedBond_LTEq1yr: number
    public rateForEstimation: number
    public estimatedThreeMonthInterest_GBP: number
    public estimatedOneMonthInterest_GBP: number
}

export class CBNoteStaticAttributeModel {
    public ipdDate: number
    public dealNoteId: number
    public dealNote: number
    public isin: number
    public currency: number
    public hardBulletSeries: number
    public extendedMaturitySeries: number
    public issuanceAmount: number
    public issuanceAmount_GBP: number
    public maturityDate: Date
    public margin: number
    public rateType: number
    public isSwapLinked: number
    public remainingTerm: string
}

export interface RangeObject {
    days: number,
    firstDateWasLater: boolean,
    hours: number,
    minutes: number,
    months: number,
    seconds: number,
    years: number
}