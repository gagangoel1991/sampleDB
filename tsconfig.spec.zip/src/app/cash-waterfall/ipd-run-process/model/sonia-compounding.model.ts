
export class SoniaCompoundingModel {
    public swapName: string;
    public ipdDate: Date;
    public collectionEndDate: string;
    public collectionStartDate: string
    public couponPeriodStart: Date;
    public couponPeriodEnd: Date;
    public coupon: number;
    public groupType: string;
   
}
