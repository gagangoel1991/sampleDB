export class DealIpdBasicInfoModel {
    public dealName: string
    public ipdInitiatedBy: string
    public ipdDate: Date
    public ipdRunDate: Date
    public collectionStartDate: Date
    public collectionEndDate: Date
    public previousIPDDate: Date
    public ipdStatus: string
    public authorisedBy: string
    public authorisedDate: Date
    public buildIrTemplateId: number
    public dealIrConfigId: number
    public comment?: string;
    public isCurrentIPD : boolean
    public ipdCollectionEndDate: Date

    constructor(dealName: string,
        ipdInitiatedBy: string,
        ipdDate: Date,
        ipdRunDate: Date,
        collectionStartDate: Date,
        collectionEndDate: Date,
        previousIPDDate: Date,
        ipdStatus: string,
        authorisedBy: string,
        authorisedDate: Date,
        buildIrTemplateId: number,
        dealIrConfigId: number,
        comment: string,
        isCurrentIPD : boolean,
        ipdCollectionEndDate: Date) {
        this.dealName = dealName;
        this.ipdDate = ipdDate;
        this.collectionStartDate = collectionStartDate;
        this.collectionEndDate = collectionEndDate;
        this.previousIPDDate = previousIPDDate;
        this.ipdInitiatedBy = ipdInitiatedBy;
        this.ipdRunDate = ipdRunDate;
        this.ipdStatus = ipdStatus;
        this.authorisedBy = authorisedBy;
        this.authorisedDate = authorisedDate;
        this.buildIrTemplateId = buildIrTemplateId;
        this.dealIrConfigId = dealIrConfigId;
        this.comment = comment;
        this.isCurrentIPD = isCurrentIPD;
        this.ipdCollectionEndDate=ipdCollectionEndDate;
    }
}

