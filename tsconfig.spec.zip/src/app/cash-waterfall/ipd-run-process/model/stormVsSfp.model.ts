export class StormVsSfpEntity {
    public stormRevCashCollPeriod: number;
    public stormRevCashCollPostIpdPeriod: number;
    public sfpRevCashCollPeriod: number;
    public sfpRevCashCollPostIpdPeriod: number;
    public stormPrinCashCollPeriod: number;
    public stormPrinCashCollPostIpdPeriod: number;
    public sfpPrinCashCollPeriod: number;
    public sfpPrinCashCollPostIpdPeriod: number;
    public sfpRevAdjustment: number;
    public sfpPrinAdjustment: number;
    public sfpRevDeflaggedReceipts: number;
    public sfpPrinDeflaggedReceipts: number;
    public sfpPrinFurtherAdvances: number;

    public stormRevCashSummary: number;
    public sfpRevCashSummary: number;
    public varianceRevCashSummary: number;
    public stormPrinCashSummary: number;
    public sfpPrinCashSummary: number;
    public variancePrinCashSummary: number;
    public stormTotalCashSummary: number;
    public sfpTotalCashSummary: number;
    public varianceTotalCashSummary: number;

    public varianceRevCashCollPeriod: number;
    public variancePrinCashCollPeriod: number;
    public stormTotalCashCollPeriod: number;
    public sfpTotalCashCollPeriod: number;
    public varianceTotalCashCollPeriod: number;

    public sfpTotalDeflagCash: number;

    public sfpTotalAdjustment: number;

    public varianceRevCashPostIpdPeriod: number;
    public variancePrinCashPostIpdPeriod: number;
    public varianceTotalCashPostIpdPeriod: number;
    public sfpTotalCashPostIpdPeriod: number;
    public stormTotalCashPostIpdPeriod: number;


    public sfpTotalDeflaggedReceipts: number;
}

