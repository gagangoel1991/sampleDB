export class RatingTriggerModel {
    public cisCode: string
    public thresholdRating: string
    public currentRating: string
    public eventName: string
    public isBreached: boolean
    public actionTaken: string
    public consequenceOfEvent: string
    public reference: string
    public triggerSummary: string
    public rowClass: string;

    constructor(cisCode: string
        , thresholdRating: string
        , currentRating: string
        , eventName: string
        , isBreached: boolean
        , consequenceOfEvent: string
        , actionTaken: string
        , reference: string
        , triggerSummary: string
        , rowClass: string
    ) {
        this.cisCode = cisCode;
        this.thresholdRating = thresholdRating;
        this.currentRating = currentRating;
        this.eventName = eventName;
        this.isBreached = isBreached;
        this.consequenceOfEvent = consequenceOfEvent;
        this.actionTaken = actionTaken;
        this.reference = reference;
        this.triggerSummary = triggerSummary;
        this.rowClass = rowClass;
    }
}