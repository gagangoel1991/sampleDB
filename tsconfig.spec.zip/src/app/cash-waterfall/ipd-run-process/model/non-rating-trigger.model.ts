export class NonRatingTriggerModel {
    public id: number
    public triggerSummary: string
    public eventName: string
    public isBreached: boolean
    public consequenceOfEvent: string
    public internalName: string
    public modifiedBy: string
    public modifiedDate: Date
    public isAdjustmentReset: boolean;
    public isAdjustmentEdited: boolean;
    
    constructor(id: number
        , triggerSummary: string
        , eventName: string
        , isBreached: boolean
        , consequenceOfEvent: string
        , internalName: string
        ,isAdjustmentReset: boolean
        , isAdjustmentEdited: boolean
        , modifiedBy?: string
        , modifiedDate?: Date        

    ) {
        this.id = id;
        this.triggerSummary = triggerSummary;
        this.eventName = eventName;
        this.isBreached = isBreached;
        this.consequenceOfEvent = consequenceOfEvent;
        this.internalName = internalName;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;        
        this.isAdjustmentReset = isAdjustmentReset;
        this.isAdjustmentEdited = isAdjustmentEdited;
    }
}