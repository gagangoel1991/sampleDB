
export class OverrideIRModalConfigModel {
    public dealId: number;
    public ipdDate: string;
    public ipdRunId: number;
    public comment?: string;
    public originalFileName? :string;
    constructor(dealId: number,ipdDate: string, ipdRunId: number) {
        this.dealId = dealId;
        this.ipdDate = ipdDate;
        this.ipdRunId = ipdRunId;
             
    }
}