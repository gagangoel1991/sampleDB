export enum IpdRunLevel1TabType {
    Automated = 1,
    DailyCollection = 2,
    BondRating = 3,
    CpRating = 4,
}