export class PostWaterfallControlEntity {
    public attributeName: string;
    public attributeType: string;
    public attributeCount : string
    public attributeValue : number;
    public dailyCollectionCount : string
    public dailyCollectionValue :number;
    public varianceCount : string
    public varianceValue: number;
    
}

