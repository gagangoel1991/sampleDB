export class SfpEditableGridColumnModel {
    public columnName: string;
    public displayName: string;
    public isEditable: boolean;
    public inputType: string;
    public pipeFormatter: string;
    public isHideAllowed = true;
    public filterText: string;
    public functionName: string;
    public isChecked = true;
    public errorMessage = '';


    constructor(columnName: string, displayName: string, isEditable: boolean, inputType: string, pipeFormatter: string,
        functionName: string, isChecked: boolean, isHideAllowed?: boolean, errorMessage?: string) {
        this.columnName = columnName;
        this.displayName = displayName;
        this.isEditable = isEditable;
        this.pipeFormatter = pipeFormatter;
        this.isHideAllowed = (isHideAllowed === null) ? this.isHideAllowed : isHideAllowed;
        this.errorMessage = (errorMessage === null || errorMessage === undefined) ? this.errorMessage : errorMessage;
        this.inputType = inputType;
        this.functionName = functionName;
        this.filterText = '';
        this.isChecked = (isChecked === false) ? false : this.isChecked;
    }
}

export class CashLadderModel {
    public cashLadderId: number
    public dealId: number
    public collectionDate?: Date;
    public correspondentAccountNumber: string
    public dealReference: string
    public product: string
    public subProduct: string
    public counterParty: string
    public contextName: string
    public rate: number
    public maturityDate: string
    public currency: string
    public inflowAmount: number
    public outflowAmount: number
    public flowSubTotal: number    
    public modifiedBy: string;
    public modifiedDate?: Date;
    public reason: string;
    public dealIpdRunId?: number;

    constructor(cashLadderId: number,collectionDate: Date,
         rate: number,inflowAmount: number, outflowAmount: number, flowSubTotal: number, modifiedBy: string, modifiedDate: Date,
        reason: string, dealIpdRunId?: number) {
        this.cashLadderId = cashLadderId;
        this.collectionDate = collectionDate;
        this.rate = rate;
        this.inflowAmount = inflowAmount;
        this.outflowAmount = outflowAmount;
        this.flowSubTotal = flowSubTotal;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
        this.reason = reason;
        this.dealIpdRunId = dealIpdRunId;
    }
}

export class CashLadderParams {
    public dealId: number;
    public ipdRunId: number;

    constructor(dealId: number, ipdRunId: number) {
        this.dealId = dealId;
        this.ipdRunId = ipdRunId;
    }
}