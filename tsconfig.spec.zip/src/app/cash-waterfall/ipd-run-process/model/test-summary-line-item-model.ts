export interface TestSummaryModel {
    ipdTestSummaryItems: TestDataModel[];
    ipdDates: Date[];
    ipdTabs: IpdTabs[];
}

export interface IpdTabs {
    internalTestLineItem: string;
    displayName: string;
    uiTabName: string;
    isActiveTab: string;
}

// *******************************************

export class TestDataModel {

    // public testLineItemId: number;
    public displayName: string;
    public internalTestLineItem: string;
    public internalName: string;
    public lineItemValue: string;
    public parentTestLineItemId: number;
    public uiTabName: string;
    public childLineItems: TestDataModel[];


    constructor(parentTestLineItemId: number, testLineItemId: number,
        lineItemValue: string, displayName: string, internalName: string, childLineItems: TestDataModel[]) {
        this.parentTestLineItemId = parentTestLineItemId;
        // this.testLineItemId = testLineItemId;
        this.lineItemValue = lineItemValue;
        this.displayName = displayName;
        this.internalName = internalName;
        this.childLineItems = childLineItems;
    }
}