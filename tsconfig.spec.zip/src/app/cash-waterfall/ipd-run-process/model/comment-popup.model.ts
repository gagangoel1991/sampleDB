export class CommentPopUpModel {
    public title: string
    public type: number;
    public row: any;
    public comment: string
    public rowIndex: number;
    public dealId?: number;
    public dealIpdRunId?: number;
    constructor(type: number, row: any, rowIndex: number, dealId?: number, dealIpdRunId?: number) {
        this.type = type;
        this.row = row;
        this.rowIndex = rowIndex;
        this.dealId = dealId;
        this.dealIpdRunId = dealIpdRunId;
    }
}