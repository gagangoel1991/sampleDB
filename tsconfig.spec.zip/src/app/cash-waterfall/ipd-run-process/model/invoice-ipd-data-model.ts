export class InvoiceIpdDataModel {
    public invoiceId: number
    public invoiceCategoryType: string
    public description: string
    public counterpartyName: string
    public amount: string
    public originalFileName: string;
    public paidDate: string
    public modifiedBy: string
    public modifiedDate: number
    public referenceNumber : string;

    constructor(invoiceId: number
        , invoiceCategoryType: string
        , description: string
        , counterpartyName: string
        , amount: string
        , originalFileName: string
        , paidDate: string
        , modifiedBy: string
        , modifiedDate: number
        ,referenceNumber : string) {
        this.invoiceId = invoiceId;
        this.invoiceCategoryType = invoiceCategoryType;
        this.description = description;
        this.counterpartyName = counterpartyName;
        this.amount = amount;
        this.originalFileName = originalFileName ;
        this.paidDate = paidDate
        this.modifiedBy = modifiedBy
        this.modifiedDate = modifiedDate
        this.referenceNumber =referenceNumber
    }
}