export class PDLBreakdownModel {
    public ipdDate: string;
    public series: string;
    public principal_bf: number;
    public pdlAllocated: number;
    public pdlToBeCredited: number;
    public actualPdlCredit: number;
    public netPdl: number;
    public openingBalance: number;
    public closingBalance: number;

    constructor(ipdDate: string, series: string, principal_bf: number, pdlAllocated: number
        , pdlToBeCredited: number
        , actualPdlCredit: number
        , netPdl: number
        , openingBalance: number
        , closingBalance: number
    ) {
        this.ipdDate = ipdDate;
        this.series = series;
        this.principal_bf = principal_bf;
        this.pdlAllocated = pdlAllocated;
        this.pdlToBeCredited = pdlToBeCredited;
        this.actualPdlCredit = actualPdlCredit;
        this.netPdl = netPdl;
        this.openingBalance = openingBalance;
        this.closingBalance = closingBalance;
    }
}

export enum Note {
    ZNote = 'Z',
    CNote = 'C',
    BNote = 'B',
    ANote = 'A',
}