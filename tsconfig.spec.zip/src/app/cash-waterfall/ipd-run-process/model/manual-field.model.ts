export class ManualFieldKeyValue {
    public manualFieldValueId: number;
    public fieldValue: string;

    constructor(manualFieldValueId: number, fieldValue: string) {
        this.manualFieldValueId = manualFieldValueId;
        this.fieldValue = fieldValue;
    }
}


export interface Field {
    fieldValue: string;
    manualFieldId: number;
}



export interface FieldData {
    manualFieldValueId: number;
    fieldDisplayName: number;
    fieldValue: string;
    manualFieldId: number;
    fieldDataType: string;
    ipdDate: Date;
    precission: number;
    modifiedBy: string;
    modifiedDate: Date;
}

export interface FieldGroup {
    header: string;
    tooltipText: string;
    val: FieldData[];
}

export interface SubGroup {
    isCollapsed: boolean;
    header: string;
    val: FieldGroup[];
}

export interface Group {
    header: string;
    val: SubGroup[];
}

export interface ManualDataObj {
    ipdDates: Date[];
    manualFieldData: Group[];
}


