export class CashwaterfallLineItemModel {
    public waterfallLineItemAmountId: number
    public lineItem: string;
    public requiredAmount: number;
    public adjustedAmount: number;
    public totalRequiredAmount: number;
    public parentWaterfallLineItemId?: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public waterfallLineItemOperatorInTotal: string;
    public modifiedBy: string;
    public modoifiedDate: Date;
    public isAdjustmentReset: boolean;
    public isAdjustmentEdited: boolean;

    constructor(waterfallLineItemAmountId: number, lineItem: string, requiredAmount: number, adjustedAmount: number,
        isAdjustmentReset: boolean, isAdjustmentEdited: boolean, isSubLineItems?: number, parentWaterfallLineItemId?: number, isExpanded?: boolean, isEditable?: boolean,
        waterfallLineItemOperatorInTotal?: string, modifiedBy?: string, modoifiedDate?: Date) {
        this.waterfallLineItemAmountId = waterfallLineItemAmountId;
        this.lineItem = lineItem;
        this.requiredAmount = requiredAmount;
        this.adjustedAmount = adjustedAmount;
        this.totalRequiredAmount = this.requiredAmount + this.adjustedAmount;
        this.parentWaterfallLineItemId = parentWaterfallLineItemId;
        this.isSubLineItems = isSubLineItems;
        this.isExpanded = isExpanded;
        this.isEditable = isEditable;
        this.waterfallLineItemOperatorInTotal = waterfallLineItemOperatorInTotal;
        this.modifiedBy = modifiedBy;
        this.modoifiedDate = modoifiedDate;
        this.isAdjustmentReset = isAdjustmentReset;
        this.isAdjustmentEdited = isAdjustmentEdited;
    }
}

export class IpdAdjustmentParams {
    public dealId: number;
    public ipdRunId: number;
    public waterfallCategoryName: string;

    constructor(dealId: number, ipdRunId: number, waterfallCategoryName: string) {
        this.dealId = dealId;
        this.ipdRunId = ipdRunId;
        this.waterfallCategoryName = waterfallCategoryName;
    }
}