export class BondRatingModel {
    public sourceBondRatingId: number
    public isin: string
    public series: string
    public cRatingAgency: string
    public ratingType: string
    public rating: string
    public ratingDate: string
    public ratingTypeId: number
    public craId: number

    constructor(sourceBondRatingId: number, isin: string, series: string
        , cRatingAgency: string
        , ratingType: string
        , rating: string
        , ratingDate: string
        , ratingTypeId: number
        , craId: number) {
        this.sourceBondRatingId = sourceBondRatingId;
        this.isin = isin;
        this.series = series;
        this.cRatingAgency = cRatingAgency;
        this.ratingType = ratingType;
        this.rating = rating
        this.ratingDate = ratingDate
        this.ratingTypeId = ratingTypeId
        this.craId = craId
    }
}

export class BondRatingParam {
    public dealId: number;
    public ipdRunId: number;

    constructor(dealId: number, ipdRunId: number) {
        this.dealId = dealId;
        this.ipdRunId = ipdRunId;
    }
}