export class DealIpdDates {
    public dealId: number
    public dealName: string
    public ipdDate: Date
}

export class Deal {
    public dealId: number
    public dealName: string
}

export class IpdDate {
    public dealId: number
    public ipdDate: Date
}

export class ParsedResult {
    originalFileName: string
    customFileName: string
    errorMessage: string
    parsedTable: any[]
    totalRowsCount: number
    discardedRowsCount: number
}


export class RatingSavedDataModel {
    dealName: string
    collectionDate: Date
    originalFileName: string
    uploadedFileName: string
    comment: string
    uploadedBy: string
    uploadedDate: Date
    ratingData: any[]
}