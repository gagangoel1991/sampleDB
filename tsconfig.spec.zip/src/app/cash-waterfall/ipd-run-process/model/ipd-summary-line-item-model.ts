export class IpdSummaryLineItemModel {
    public dealId: number
    public dealIpdId: number;
    public ipdDate: string;
    public dealIpdRunId: number;
    public dealIpdSummaryLineItemId: number;
    public dealIpdSummaryLineItemStatusId: number;
    public status: string;
    public codeName: string;
    public displayName: string;
    public defaultStatus: string;
    public seqOrder: number;
    public parentId: number;
    public isExpanded?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayAuthorizerButton?: boolean = false;
    public isAuthRequited: boolean;
    public stepDescription: string;
    public actionBy: string;
    public irFileName : string;
    public routerLink : string;
    public summaryInfo : string;

    constructor(dealId: number, dealIpdId: number,ipdDate: string, dealIpdRunId: number, dealIpdSummaryLineItemId: number,
        dealIpdSummaryLineItemStatusId: number, status: string, codeName: string,
        displayName: string, defaultStatus: string, seqOrder: number, parentId: number,
        isExpanded: boolean, isRowVisible: boolean, displayAuthorizerButton: boolean, isAuthRequited: boolean,
        stepDescription: string, actionBy: string, irFileName: string, routerLink : string, summaryInfo : string) {
        this.dealId = dealId;
        this.dealIpdId = dealIpdId;
        this.ipdDate = ipdDate;
        this.dealIpdRunId = dealIpdRunId;
        this.dealIpdSummaryLineItemId = dealIpdSummaryLineItemId;
        this.dealIpdSummaryLineItemStatusId = dealIpdSummaryLineItemStatusId;
        this.status = status;
        this.codeName = codeName;
        this.displayName = displayName;
        this.defaultStatus = defaultStatus;
        this.seqOrder = seqOrder;
        this.parentId = parentId;
        this.isExpanded = isExpanded;
        this.isRowVisible = isRowVisible;
        this.displayAuthorizerButton = displayAuthorizerButton;
        this.isAuthRequited = isAuthRequited;
        this.stepDescription = stepDescription;
        this.actionBy = actionBy;
        this.irFileName = irFileName;
        this.routerLink = routerLink;
        this.summaryInfo=summaryInfo;
    }
}
