export class SfpEditableGridColumnModel {
    public columnName: string;
    public displayName: string;
    public isEditable: boolean;
    public inputType: string;
    public pipeFormatter: string;
    public isHideAllowed = true;
    public filterText: string;
    public functionName: string;
    public isChecked = true;
    public columnHintText = '';


    constructor(columnName: string, displayName: string, isEditable: boolean, inputType: string, pipeFormatter: string,
        functionName: string, isChecked: boolean, isHideAllowed?: boolean, columnHintText?: string) {
        this.columnName = columnName;
        this.displayName = displayName;
        this.isEditable = isEditable;
        this.pipeFormatter = pipeFormatter;
        this.isHideAllowed = (isHideAllowed === null) ? this.isHideAllowed : isHideAllowed;
        this.columnHintText = (columnHintText === null || columnHintText === undefined) ? this.columnHintText : columnHintText;
        this.inputType = inputType;
        this.functionName = functionName;
        this.filterText = '';
        this.isChecked = (isChecked === false) ? false : this.isChecked;
    }
}

export class DailyCollectionModel {
    public collectionDate: string
    public dealId: number
    public brand: string
    public accruedInterestCF: string
    public accruedInterestEarnedNotApplied: string
    public closingTrueBalance: string
    public closingTrueBalanceDerived: string
    public controlBreakVariance: string
    public currentArrearsInsuranceAMT: string
    public currentCapitalInArrearsAMT: string
    public currentControlBreak: string
    public currentFeeArrearsAMT: string
    public currentFinesArrearsAMT: string
    public currentInterestEarnedNotAppliedAMT: string
    public currentInterestInArrearsAMT: string
    public currentPrepaymentAMT: string
    public currentSumTotalCapital: string
    public currentTrueBalanceAMT: string
    public currentTrueCapitalBalanceAMT: string
    public currentTrueInterestAfterCalcDateAMT: string
    public custStatementBalance: string
    public custStatementBalanceDerived: string
    public deflaggedPrincipalReceipts: string
    public deflaggedRevenueReceipts: string
    public deflaggedVOverallVariance: string
    public feesCharged: string
    public feesChargedCapitalised: string
    public feesReceived: string
    public furtherStageAdvances: string
    public interestCharged: string
    public interestReceived: string
    public netRevenueReceipts: string
    public otherPrincipalMovements: string
    public overallVariance: string
    public overPayments: string
    public partialPrepayments: string
    public principalReceipts: string
    public principalReceiptsCheck: string
    public principalReceiptsDerived: string
    public principalReceiptsVariance: string
    public redemptions: string
    public scheduledPrincipalReductions: string
    public totalBalanceMovements: string
    public totalCashReceived: string
    public totalDeflaggedAmount: string
    public totalRevenueReceipts: string
    public variance1: string;
    public prevSumTotalCapital: string;
    public topupBalance: string;
    public changeReason: string;
    public modifiedBy: string;
    public modifiedDate: string;
    public dealIpdRunId?: number;

    constructor(
        collectionDate: string
        , dealId: number
        , brand: string
        , accruedInterestCF: string
        , accruedInterestEarnedNotApplied: string
        , closingTrueBalance: string
        , closingTrueBalanceDerived: string
        , controlBreakVariance: string
        , currentArrearsInsuranceAMT: string
        , currentCapitalInArrearsAMT: string
        , currentControlBreak: string
        , currentFeeArrearsAMT: string
        , currentFinesArrearsAMT: string
        , currentInterestEarnedNotAppliedAMT: string
        , currentInterestInArrearsAMT: string
        , currentPrepaymentAMT: string
        , currentSumTotalCapital: string
        , currentTrueBalanceAMT: string
        , currentTrueCapitalBalanceAMT: string
        , currentTrueInterestAfterCalcDateAMT: string
        , custStatementBalance: string
        , custStatementBalanceDerived: string
        , deflaggedPrincipalReceipts: string
        , deflaggedRevenueReceipts: string
        , deflaggedVOverallVariance: string
        , feesCharged: string
        , feesChargedCapitalised: string
        , feesReceived: string
        , furtherStageAdvances: string
        , interestCharged: string
        , interestReceived: string
        , netRevenueReceipts: string
        , otherPrincipalMovements: string
        , overallVariance: string
        , overPayments: string
        , partialPrepayments: string
        , principalReceipts: string
        , principalReceiptsCheck: string
        , principalReceiptsDerived: string
        , principalReceiptsVariance: string
        , redemptions: string
        , scheduledPrincipalReductions: string
        , totalBalanceMovements: string
        , totalCashReceived: string
        , totalDeflaggedAmount: string
        , totalRevenueReceipts: string
        , variance1: string
        , prevSumTotalCapital: string
        , topupBalance: string
        , changeReason: string
        , modifiedBy: string
        , modifiedDate: string
        , dealIpdRunId?: number
    ) {
        this.collectionDate = collectionDate
        this.dealId = dealId
        this.brand = brand
        this.accruedInterestCF = accruedInterestCF
        this.accruedInterestEarnedNotApplied = accruedInterestEarnedNotApplied
        this.closingTrueBalance = closingTrueBalance
        this.closingTrueBalanceDerived = closingTrueBalanceDerived
        this.controlBreakVariance = controlBreakVariance
        this.currentArrearsInsuranceAMT = currentArrearsInsuranceAMT
        this.currentCapitalInArrearsAMT = currentCapitalInArrearsAMT
        this.currentControlBreak = currentControlBreak
        this.currentFeeArrearsAMT = currentFeeArrearsAMT
        this.currentFinesArrearsAMT = currentFinesArrearsAMT
        this.currentInterestEarnedNotAppliedAMT = currentInterestEarnedNotAppliedAMT
        this.currentInterestInArrearsAMT = currentInterestInArrearsAMT
        this.currentPrepaymentAMT = currentPrepaymentAMT
        this.currentSumTotalCapital = currentSumTotalCapital
        this.currentTrueBalanceAMT = currentTrueBalanceAMT
        this.currentTrueCapitalBalanceAMT = currentTrueCapitalBalanceAMT
        this.currentTrueInterestAfterCalcDateAMT = currentTrueInterestAfterCalcDateAMT
        this.custStatementBalance = custStatementBalance
        this.custStatementBalanceDerived = custStatementBalanceDerived
        this.deflaggedPrincipalReceipts = deflaggedPrincipalReceipts
        this.deflaggedRevenueReceipts = deflaggedRevenueReceipts
        this.deflaggedVOverallVariance = deflaggedVOverallVariance
        this.feesCharged = feesCharged
        this.feesChargedCapitalised = feesChargedCapitalised
        this.feesReceived = feesReceived
        this.furtherStageAdvances = furtherStageAdvances
        this.interestCharged = interestCharged
        this.interestReceived = interestReceived
        this.netRevenueReceipts = netRevenueReceipts
        this.otherPrincipalMovements = otherPrincipalMovements
        this.overallVariance = overallVariance
        this.overPayments = overPayments
        this.partialPrepayments = partialPrepayments
        this.principalReceipts = principalReceipts
        this.principalReceiptsCheck = principalReceiptsCheck
        this.principalReceiptsDerived = principalReceiptsDerived
        this.principalReceiptsVariance = principalReceiptsVariance
        this.redemptions = redemptions
        this.scheduledPrincipalReductions = scheduledPrincipalReductions
        this.totalBalanceMovements = totalBalanceMovements
        this.totalCashReceived = totalCashReceived
        this.totalDeflaggedAmount = totalDeflaggedAmount
        this.totalRevenueReceipts = totalRevenueReceipts
        this.variance1 = variance1
        this.prevSumTotalCapital = prevSumTotalCapital;
        this.topupBalance = topupBalance;
        this.changeReason = changeReason;
        this.modifiedBy = modifiedBy
        this.modifiedDate = modifiedDate;
        this.dealIpdRunId = dealIpdRunId;
    }
}