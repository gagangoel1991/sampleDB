export enum AuthorisationSteps {
    Draft = 1,
    SentForAuthorisation = 2,
    Authorized = 3,
    Reject = 4,
    Recall = 5,
    Withdraw=6
}