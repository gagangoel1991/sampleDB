export class DealSwapTotalAmountModel {
    public ipdDate: string;
    public payTotalAmount: number;
    public receiveTotalAmount: number;
    

    constructor(
          ipdDate: string
        , payTotalAmount: number
        , receiveTotalAmount: number        
    ) {
        this.ipdDate = ipdDate;
        this.payTotalAmount = payTotalAmount;
        this.receiveTotalAmount = receiveTotalAmount;       
    }
}
