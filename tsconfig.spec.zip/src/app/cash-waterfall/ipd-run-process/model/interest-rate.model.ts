export class InterestRateModel {
    public interestRateId: number
    public interestRate: number
    public interestRateType: string
    public ricCode: string
    public ipdDate: string
    public modifiedBy: string
    public modifiedDate: Date
    public reason: string;
    public dealIpdRunId?: number;
    constructor(interestRateId: number
        , interestRate: number
        , interestRateType: string
        , ricCode: string
        , ipdDate: string
        , modifiedBy: string
        , modifiedDate: Date
        , reason?: string
        , dealIpdRunId?: number) {
        this.interestRateId = interestRateId;
        this.interestRate = interestRate;
        this.interestRateType = interestRateType;
        this.ricCode = ricCode;
        this.ipdDate = ipdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
        this.reason = reason;
        this.dealIpdRunId = dealIpdRunId;
    }
}