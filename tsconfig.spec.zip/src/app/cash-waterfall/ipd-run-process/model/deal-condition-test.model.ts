export class DealConditionTestModel {
    public id: number
    public condition: string
    public status: string
    public comment: string
    public number: number
    public amount: number
    public consequences: string
    public repurchaseAmount: number
    public dealStatus: string
    public previousRepurchaseDate: string
    public modifiedBy?: string
    public modifiedDate?: Date
    constructor(id: number,
        condition: string,
        status: string,
        comment: string,
        number: number,
        amount: number,
        consequences: string,
        repurchaseAmount: number,
        dealStatus: string,
        previousRepurchaseDate: string,
        modifiedBy?: string,
        modifiedDate?: Date
    ) {
        this.id = id;
        this.condition = condition;
        this.status = status;
        this.comment = comment;
        this.number = number;
        this.amount = amount;
        this.consequences = consequences;
        this.repurchaseAmount = repurchaseAmount;
        this.dealStatus = dealStatus;
        this.previousRepurchaseDate = previousRepurchaseDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
    }
}