export class SfpEditableGridColumnModel {
    public columnName: string;
    public displayName: string;
    public isEditable: boolean;
    public inputType: string;
    public pipeFormatter: string;
    public isHideAllowed = true;
    public filterText: string;
    public functionName: string;
    public isChecked = true;
    public errorMessage = '';


    constructor(columnName: string, displayName: string, isEditable: boolean, inputType: string, pipeFormatter: string,
        functionName: string, isChecked: boolean, isHideAllowed?: boolean, errorMessage?: string) {
        this.columnName = columnName;
        this.displayName = displayName;
        this.isEditable = isEditable;
        this.pipeFormatter = pipeFormatter;
        this.isHideAllowed = (isHideAllowed === null) ? this.isHideAllowed : isHideAllowed;
        this.errorMessage = (errorMessage === null || errorMessage === undefined) ? this.errorMessage : errorMessage;
        this.inputType = inputType;
        this.functionName = functionName;
        this.filterText = '';
        this.isChecked = (isChecked === false) ? false : this.isChecked;
    }
}