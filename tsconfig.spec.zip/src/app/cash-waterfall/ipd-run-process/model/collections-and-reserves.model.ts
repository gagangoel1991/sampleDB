export interface ResultCollectionData {
    ipdDate: Date;
    principalReceipts: number;
    revenueReceipts: number;
    interestOnCollections: number;
}

export interface ResultReserveData {
    ipdDate: Date;
    requiredAmount: number;
    interestOnReserves: number;
}

export interface ResultCollRes {
    ipdDates: Date[];
    totalInterest: number[];
    resultCollectionData: ResultCollectionData[];
    resultReserveData: ResultReserveData[];
}