export class DealNoteModel {
    public dealNoteId: number;
    public ipdDate: string;
    public openingPoolFactor: number;
    public baseRate: number;
    public isNote : boolean;
    public totalRate: number;
    public daysInInterestPeriod: number;
    public principal_bf: number;
    public interestDue: number;
    public unpaidInterest_bf: number;
    public interestOnUnpaidInterest_bf: number;
    public interestPaid: number;
    public unpaidInterest_cf: number;
    public principalPaid: number;
    public principal_cf: number;
    public closingPoolFactor: number;

    constructor(dealNoteId: number, ipdDate: string,
        openingPoolFactor: number,
        baseRate: number,
        totalRate: number,
        daysInInterestPeriod: number,
        principal_bf: number,
        interestDue: number,
        unpaidInterest_bf: number,
        interestOnUnpaidInterest_bf: number,
        interestPaid: number,
        unpaidInterest_cf: number,
        principalPaid: number,
        principal_cf: number,
        closingPoolFactor: number) {
        this.dealNoteId = dealNoteId;
        this.ipdDate = ipdDate;
        this.openingPoolFactor = openingPoolFactor;
        this.baseRate = baseRate;
        this.totalRate = totalRate;
        this.daysInInterestPeriod = daysInInterestPeriod;
        this.principal_bf = principal_bf;
        this.interestDue = interestDue;
        this.unpaidInterest_bf = unpaidInterest_bf;
        this.interestOnUnpaidInterest_bf = interestOnUnpaidInterest_bf;
        this.interestPaid = interestPaid;
        this.unpaidInterest_cf = unpaidInterest_cf;
        this.principalPaid = principalPaid;
        this.principal_cf = principal_cf;
        this.closingPoolFactor = closingPoolFactor;
    }
}

export class DealNoteStaticAttributeModel {
    public dealNote: string;
    public isin: string;
    public issuanceAmount: number
    public maturityDate: Date
    public margin: string
    public rateType: string
    public couponFloor : number

    constructor(
        dealNote: string
        , isin: string
        , issuanceAmount: number
        , maturityDate: Date
        , margin: string
        , rateType: string
        , couponFloor : number) {
        this.dealNote = dealNote;
        this.isin = isin;
        this.issuanceAmount = issuanceAmount;
        this.maturityDate = maturityDate;
        this.margin = margin;
        this.rateType = rateType;
        this.couponFloor =couponFloor;
    }
}