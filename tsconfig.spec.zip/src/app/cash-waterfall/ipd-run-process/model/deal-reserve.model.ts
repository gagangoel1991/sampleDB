
export class DealReserveModel {
    public ipdDate: string;
    public reserveFundTypeId: number;
    public displayName: string;
    public principal_bf: number;
    public reserveFund_bf: number;
    public requiredReserveFund: number;
    public reserveFundDue: number;
    public reserveResidualAmount: number;
    public drawingsInPeriod: number;
    public creditReceived: number;
    public reserveFund_cf: number;
    constructor(ipdDate: string, reserveFundTypeId: number, displayName: string, principal_bf: number, reserveFund_bf: number
        , requiredReserveFund: number
        , reserveFundDue: number
        , reserveResidualAmount: number
        , drawingsInPeriod: number
        , creditReceived: number
        , reserveFund_cf: number
    ) {
        this.ipdDate = ipdDate;
        this.reserveFundTypeId = reserveFundTypeId;
        this.displayName = displayName;
        this.principal_bf = principal_bf;
        this.reserveFund_bf = reserveFund_bf;
        this.requiredReserveFund = requiredReserveFund;
        this.reserveFundDue = reserveFundDue;
        this.reserveResidualAmount = reserveResidualAmount;
        this.drawingsInPeriod = drawingsInPeriod;
        this.creditReceived = creditReceived;
        this.reserveFund_cf = reserveFund_cf;
    }
}



export enum ReserveType {
    GeneralReserve = 1,
    LiquidityReserve = 2
}