export class DealSubloanModel {
    public subloanTypeId: number;
    public ipdDate: string;
    public baseRate: number;
    public totalRate: number;
    public interestPeriod: number;
    public principal_bf: number;
    public interestDue: number;
    public unpaidInterestRate_bf: number;
    public interestOnUnpaidInterest: number;
    public interestPaid: number;
    public unpaidInterest_cf: number;
    public principalPaid: number;
    public principal_cf: number;

    constructor(
        subloanTypeId: number
        , ipdDate: string
        , baseRate: number
        , totalRate: number
        , interestPeriod: number
        , principal_bf: number
        , interestDue: number
        , unpaidInterestRate_bf: number
        , interestOnUnpaidInterest: number
        , interestPaid: number
        , unpaidInterest_cf: number
        , principalPaid: number
        , principal_cf: number
    ) {
        this.subloanTypeId = subloanTypeId;
        this.ipdDate = ipdDate;
        this.baseRate = baseRate;
        this.totalRate = totalRate;
        this.interestPeriod = interestPeriod;
        this.principal_bf = principal_bf;
        this.interestDue = interestDue;
        this.unpaidInterestRate_bf = unpaidInterestRate_bf;
        this.interestOnUnpaidInterest = interestOnUnpaidInterest;
        this.interestPaid = interestPaid;
        this.unpaidInterest_cf = unpaidInterest_cf;
        this.principalPaid = principalPaid;
        this.principal_cf = principal_cf;
    }
}


export class DealSubLoanStaticAttributeModel {
    public subloanTypeId: number;
    public applicableSubLoan: string;
    public initialAmount: number
    public limitAmount: number
    public margin: string
    public rateType: string

    constructor(
        subloanTypeId: number
        , applicableSubLoan: string
        , initialAmount: number
        , limitAmount: number
        , margin: string
        , rateType: string) {
        this.subloanTypeId = subloanTypeId;
        this.applicableSubLoan = applicableSubLoan;
        this.initialAmount = initialAmount;
        this.limitAmount = limitAmount;
        this.margin = margin;
        this.rateType = rateType;
    }
}

export class HeaderCollectionModel {
    public name: string;
    public displayName: string;
    public exportFormat?: string;
    constructor(
        name: string
        , displayName: string
        , exportFormat?: string
    ) {
        this.name = name;
        this.displayName = displayName;
        this.exportFormat = exportFormat;
    }
}

export enum SubLoanType {
    SubLoan = 1,
    ServicerAdvanced = 2
}