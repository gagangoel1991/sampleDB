export class SwapCollateralModel {
    public ipdDate: string
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public swapCollateralFundbF: number
    public swapCollateralAmountReceived: number
    public swapCollateralExcludedAmount: number
    public releaseToARR: number
    public swapCollateralcf: number
}

export class PrematurityFundModel {
    public ipdDate: string
    public testResult: string;
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public preMaturityLiquidity_bf: number;
    public requiredAmount1: number;
    public finalRequiredAmount: number;
    public dueAmount: number;
    public residualAmount: number;
    public capitalContribution: number;
    public creditReceivedRPP: number;
    public shortfallAfterRPP: number;
    public creditReceivedPPP: number;
    public preMaturityLiquidity_cf: number;
}

export class CouponPaymentModel {
    public ipdDate: string
    public testResult: string;
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public couponPayment_bf: number
    public finalRequiredAmount: number
    public requiredAmount1: number
    public dueAmount: number
    public residualAmount: number
    public capitalContribution: number
    public creditReceived: number
    public couponPayment_cf: number
}

export class ReserveFundModel {
    public ipdDate: string
    public testResult: string;
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public reserveFundb_f: number;
    public finalRequiredAmount: number;
    public requiredAmount1: number;
    public requiredAmount2: number;
    public dueAmount: number;
    public residualAmount: number;
    public releaseToARR: number;
    public creditReceived: number;
    public reserveFund_cf: number;
    
    public displayName: string;
    public internalTestLineItem: string;
    public internalName: string;
    public lineItemValue: string;
    public testLineItemId: number;
    public parentTestLineItemId: number;
    public uiTabName: string;
    public lineItemTooltip: string;
    public childLineItems: ReserveFundModel[];

    constructor(ipdDate: string, parentTestLineItemId: number, testLineItemId: number,
        lineItemValue: string, lineItemTooltip: string, displayName: string, childLineItems: ReserveFundModel[]) {
        this.ipdDate = ipdDate;
        this.testLineItemId = testLineItemId;
        this.parentTestLineItemId = parentTestLineItemId;
        this.displayName = displayName;
        this.lineItemValue = lineItemValue;
        this.lineItemTooltip = lineItemTooltip;
        this.childLineItems = childLineItems;
    }
}


export class RevenueLedgerModel {
    public ipdDate: string
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public revenueLedgerFund_bF: number
    public revenueLedgerReceiptsReceived: number
    public revenueLedgerOthersReceived: number
    public cashCapitalContrubution: number
    public releaseToARR: number
    public preAccelerationCredit: number
    public revenueLedgerFund_cf: number
    
}

export class PrincipalLedgerModel {
    public ipdDate: string
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public principalLedgerFund_bF: number
    public principalLedgerReceiptsReceived: number
    public principalLedgerOthersReceived: number
    public releaseToAPR: number
    public retainedPrincipalAmount: number
    public preAccelerationCredit: number
    public principalLedgerFund_cf: number
}


export class PaymentLedgerModel {
    public ipdDate: string
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public paymentLedgerFund_bF: number
    public creditofARR: number
    public creditofAPR: number
    public releaseToAPR: number
    public creditofMoniesDepositAccount: number
    public paymentDuePreAccelerationRPP: number
    public paymentDuePreAccelerationPPP: number
    public paymentDueGuranteePPP: number
    public paymentDueMoniesDistributionRepaid: number
    public paymentLedgerFund_cf: number
}


export class MaturingProceedsLedgerModel {
    public ipdDate: string
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public MaturingProceedsLoanFund_bF: number
    public Rate: number
    public Interest: number
    public releaseToAPR: number
    public CapitalContributionRedemption: number
    public PrincipalCollectionReduction: number
    public RetainedPrincipal: number
    public IssuanceFunds: number
    public CapitalContributionTopUps: number
    public MaturingProceedsLoanFund_cf: number
}


export class CapitalAccountLedgerModel {
    public ipdDate: string
    public parentId: number;
    public isSubLineItems?: number;
    public isExpanded?: boolean = false;
    public isEditable?: boolean = false;
    public isRowVisible?: boolean = false;
    public displayTextUI: number;
    public fieldName: number;
    public capitalAccountLedger_bF: number;
    public capitalDistribution: number;
    public capitalDistributionLLPtoNW: number;
    public lossesSoldToLLP: number;
    public capitalisedInterest: number;
    public borrowerLoanAdvance: number;
    public loanSecuritySaleToLLP: number;
    public subsitutionAssetSale: number;
    public paymentTermination: number;
    public paymentCouponAmount: number;
    public paymentCouponAmountShortfall: number;
    public paymentRedemtionAmount: number;
    public cashCapitalRedemtionContribution: number;
    public capitalAccountLedger_cf: number;
}


export class LedgerList {
    displayName : string;
    internalLedgerName : string;
    isActiveTab : string;
    // dataSet : Array<{}>;
    title : string;
    export : string;

}
















