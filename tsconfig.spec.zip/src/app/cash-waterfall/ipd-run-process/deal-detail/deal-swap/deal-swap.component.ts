import { Component, OnInit } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { DealSwapService } from '../../service/deal-swap.service';
import { ISwapModel } from '../../model/deal-swap.model';
import { DecimalPipe } from '@angular/common';
import { DealSwapTotalAmountModel } from '../../model/deal-swap-totalamount.model';

@Component({
    selector: 'cw-deal-swap-data',
    templateUrl: './deal-swap.component.html',
    styleUrls: ['./deal-swap.component.scss'],
    providers: [OrderByPipe, DealSwapService, DecimalPipe]
})
export class DealSwapComponent implements OnInit {
    public dealId: number;
    public ipdRunId: number;
    public datePipe = new DatePipe('en-UK');
    public customCurrencyPipe = new CustomCurrencyPipe();
    public title = 'Deal Swap';
    public dealSwapList: Array<ISwapModel> = [];
    public headers: Array<HeaderCollectionModel> = [];
    public headers1: Array<HeaderCollectionModel> = [];
    public headersFixed: Array<HeaderCollectionModel> = [];
    public ipdDateHeaders: Array<string> = [];
    public dealSwaps: Array<any> = []
    public dealSwapHeaders: Array<HeaderCollectionModel> = [];
    public skipNoteHeaders = [];
    public exportHeaders: Array<HeaderCollectionModel> = [];
    public exportExcelUtility = new ExportExcelUtility();
    public dealSwapTotalAmountList: Array<DealSwapTotalAmountModel> = [];


    constructor(private _ipdProcessService: IpdProcessParentService
        , private _dealSwapService: DealSwapService
        , private ngxOrderPipe: OrderByPipe,
        private _route: ActivatedRoute,
        private _router: Router,
        private _decimalPipe: DecimalPipe) {
        this._ipdProcessService.changeIpdLevel1MenuName('Note_summary');
        this._route.params.subscribe((params: Params) => {
            var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
            this.dealId = (values) ? values[0] : null;
            this.ipdRunId = (values) ? values[1] : null;
        });
    }

    ngOnInit(): void {
        this.headers.push(new HeaderCollectionModel('CouponPeriodStart', 'Coupon Start Date'));
        this.headers.push(new HeaderCollectionModel('CouponPeriodEnd', 'Coupon End Date'));
        this.headers.push(new HeaderCollectionModel('AccrualDays', 'Accrual Days'));
        this.headers.push(new HeaderCollectionModel('Notional', 'Notional', 'percent'));
        this.headers.push(new HeaderCollectionModel('MarginDifferential', 'Margin', 'number'));
        this.headers.push(new HeaderCollectionModel('BaseRate', 'Base Rate'));
        this.headers.push(new HeaderCollectionModel('Rate', 'All-in-Rate'));
        this.headers.push(new HeaderCollectionModel('Amount', 'Amount', 'currency'));

        this.headers1.push(new HeaderCollectionModel('CouponPeriodStart', 'Coupon Start Date'));
        this.headers1.push(new HeaderCollectionModel('CouponPeriodEnd', 'Coupon End Date'));
        this.headers1.push(new HeaderCollectionModel('AccrualDays', 'Accrual Days'));
        this.headers1.push(new HeaderCollectionModel('Notional', 'Notional', 'percent'));
        this.headers1.push(new HeaderCollectionModel('MarginDifferential', 'Margin', 'number'));
        this.headers1.push(new HeaderCollectionModel('BaseRate', 'SVR Rate'));
        this.headers1.push(new HeaderCollectionModel('Rate', 'All-in-Rate'));
        this.headers1.push(new HeaderCollectionModel('Amount', 'Amount', 'currency'));

        this.headersFixed.push(new HeaderCollectionModel('CouponPeriodStart', 'Coupon Start Date'));
        this.headersFixed.push(new HeaderCollectionModel('CouponPeriodEnd', 'Coupon End Date'));
        this.headersFixed.push(new HeaderCollectionModel('AccrualDays', 'Accrual Days'));
        this.headersFixed.push(new HeaderCollectionModel('Notional', 'Notional', 'percent'));
        this.headersFixed.push(new HeaderCollectionModel('MarginDifferential', 'Margin', 'number'));
        this.headersFixed.push(new HeaderCollectionModel('BaseRate', 'Rate'));
        this.headersFixed.push(new HeaderCollectionModel('Rate', 'All-in-Rate'));
        this.headersFixed.push(new HeaderCollectionModel('Amount', 'Amount', 'currency'));
        

        this._dealSwapService.getDealSwapData(this.dealId, this.ipdRunId).subscribe((data) => {
            let ipdDates: Array<string> = [];
            let swapNameList: Array<any> = [];
            this.dealSwapList = data;
            console.log(this.dealSwapList);
            swapNameList = this.dealSwapList.map(({ swapName, swapId }) => ({ swapName, swapId }));
            ipdDates = data.map(e => e.ipdDate);
            this.dealSwaps = Array.from(new Set(swapNameList.map(x => x.swapId))).map(id => {
                return {
                    swapId: id,
                    swapName: swapNameList.find(s => s.swapId == id).swapName
                };
            });
            let index =this.dealSwaps.findIndex(z => z.swapName == 'Amount');
            this.dealSwaps[index]= { swapId :index, swapName:'Total'};
            console.log(this.dealSwaps);
            this.ipdDateHeaders = ipdDates.filter(this.getUniqueIPDDates);
        })

        document.getElementById('preloader').style['display'] = 'none';
    }

    getUniqueIPDDates(value, index, self) {
        return self.indexOf(value) === index;
    }

    getDealSwapValue(dealSwapId: number, colName: string, ipdDate: string, colPrefix: string) {
        let dealSwap = this.dealSwapList.filter(obj => obj.ipdDate == ipdDate && obj.swapId == dealSwapId);
        
        if (dealSwap && dealSwap.length > 0) {
            let name = colPrefix + colName;
            if (name === "payCouponPeriodStart" || name === "payCouponPeriodEnd" || name === "receiveCouponPeriodStart" || name === "receiveCouponPeriodEnd" || name === "ipdDate"
                    || name === "payAccrualDays" || name === "receiveAccrualDays"   ) {
                return dealSwap[0][name];
            }
            else if (name === "payRate" || name === "receiveRate" || name === 'payMarginDifferential' || name === 'receiveMarginDifferential'  || name === "payBaseRate"  ||name === "receiveBaseRate") {
                return this.customCurrencyPipe.transform(dealSwap[0][name], 4) + ' %';
            }
            else {
                let value = dealSwap[0][name] != null ? dealSwap[0][name] : 0.00;
                return this._decimalPipe.transform(value, '1.2-2');
            }
        }
        else
            return "NA";
    }

    getDealSwapTotalAmountValue(ipdDate: string, colPrefix: string) {
        this.dealSwapTotalAmountList = this.dealSwapList.map(({ ipdDate, payTotalAmount,receiveTotalAmount }) => ({ ipdDate, payTotalAmount,receiveTotalAmount }));
        let dealSwap = this.dealSwapTotalAmountList.filter(obj => obj.ipdDate == ipdDate);
        if (dealSwap && dealSwap.length > 0) {
            let name = colPrefix + 'TotalAmount' ;
                return this._decimalPipe.transform(dealSwap[0][name],  '1.2-2');
           
        }
        else
            return "NA";
    }

    getDateHeadrs(value, index, self) {
        return self.indexOf(value) === index;
    }

    exportToExcel() {
        this._dealSwapService.getDealSwapExcel(this.dealId, this.ipdRunId).subscribe((data) => {
            // this.isFileDownloadStarted = false;

            let FileName = "Deal-Swap-Data" + ".xlsx";

            var blob = new Blob([this.s2ab(atob(data))], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
            });

            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = FileName;

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

        });
    }

    s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }
}
