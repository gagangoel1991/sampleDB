import { Component, OnInit } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { ISwapModel } from '../../model/deal-swap.model';
import { DecimalPipe } from '@angular/common';
import { BondSwapService } from '../../service/bond-swap.service';

@Component({
    selector: 'cw-bond-swap',
    templateUrl: './bond-swap.component.html',
    styleUrls: ['./bond-swap.component.scss'],
    providers: [OrderByPipe, BondSwapService, DecimalPipe]
})
export class BondSwapComponent implements OnInit {
    public dealId: number;
    public ipdRunId: number;
    public datePipe = new DatePipe('en-UK');
    public customCurrencyPipe = new CustomCurrencyPipe();
    public title = 'Bond Swap';
    public bondSwapList: Array<ISwapModel> = [];
    public headers: Array<HeaderCollectionModel> = [];
    public ipdDateHeaders: Array<string> = [];
    public bondSwaps: Array<any> = []
    public dealSwapHeaders: Array<HeaderCollectionModel> = [];
    public skipNoteHeaders = [];
    public exportHeaders: Array<HeaderCollectionModel> = [];
    public exportExcelUtility = new ExportExcelUtility();


    constructor(private _ipdProcessService: IpdProcessParentService
        , private _bondSwapService: BondSwapService,
        private _route: ActivatedRoute,
        private _router: Router,
        private _decimalPipe: DecimalPipe) {
        this._ipdProcessService.changeIpdLevel1MenuName('Note_summary');
        this._route.params.subscribe((params: Params) => {
            var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
            this.dealId = (values) ? values[0] : null;
            this.ipdRunId = (values) ? values[1] : null;
        });
    }

    ngOnInit(): void {
        this.headers.push(new HeaderCollectionModel('CouponPeriodStart', 'Coupon Period Start'));
        this.headers.push(new HeaderCollectionModel('CouponPeriodEnd', 'Coupon Period End'));
        this.headers.push(new HeaderCollectionModel('AccrualDays', 'Accrual Days'));
        this.headers.push(new HeaderCollectionModel('Notional', 'Notional', 'percent'));
        this.headers.push(new HeaderCollectionModel('Margin', 'Margin', 'number'));
        this.headers.push(new HeaderCollectionModel('BaseRate', 'Base Rate'));
        this.headers.push(new HeaderCollectionModel('Rate', 'Coupon Rate'));
        this.headers.push(new HeaderCollectionModel('Amount', 'Amount', 'currency'));

        this._bondSwapService.getDealSwapData(this.dealId, this.ipdRunId).subscribe((data) => {
            let ipdDates: Array<string> = [];
            let swapNameList: Array<any> = [];
            this.bondSwapList = data;
            console.log(this.bondSwapList);
            swapNameList = this.bondSwapList.map(({ swapName, swapId }) => ({ swapName, swapId }));
            ipdDates = data.map(e => e.ipdDate);
            this.bondSwaps = Array.from(new Set(swapNameList.map(x => x.swapId))).map(id => {
                return {
                    swapId: id,
                    swapName: swapNameList.find(s => s.swapId == id).swapName
                };
            });            
            this.ipdDateHeaders = ipdDates.filter(this.getUniqueIPDDates);
        })

        document.getElementById('preloader').style['display'] = 'none';
    }

    getUniqueIPDDates(value, index, self) {
        return self.indexOf(value) === index;
    }

    getBondSwapValue(bondSwapId: number, colName: string, ipdDate: string, colPrefix: string) {
        let bondSwap = this.bondSwapList.filter(obj => obj.ipdDate == ipdDate && obj.swapId == bondSwapId);
        if (bondSwap && bondSwap.length > 0) {
            let name = colPrefix + colName;
            console.log(name);
            if (name === "payCouponPeriodStart" || name === "payCouponPeriodEnd" || name === "receiveCouponPeriodStart" || name === "receiveCouponPeriodEnd" || name === "ipdDate"
                        || name === "payAccrualDays" || name === "receiveAccrualDays" ) {
                return bondSwap[0][name];
            }
            else if (name === "payRate" || name === "receiveRate" || name === "payMargin"  ||name === "receiveMargin" || name === "payBaseRate"  ||name === "receiveBaseRate") {
                return this.customCurrencyPipe.transform(bondSwap[0][name], 4) + ' %';
            }
            else {
                let value = bondSwap[0][name] != null ? bondSwap[0][name] : 0.00;
                return this._decimalPipe.transform(value, '1.2-2');
            }
        }
        else
            return "NA";
    }

    getDateHeadrs(value, index, self) {
        return self.indexOf(value) === index;
    }

    exportToExcel() {
        this._bondSwapService.getBondSwapExcel(this.dealId, this.ipdRunId).subscribe((data) => {
            // this.isFileDownloadStarted = false;

            let FileName = "Bond-Swap-Data" + ".xlsx";

            var blob = new Blob([this.s2ab(atob(data))], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
            });

            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = FileName;

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

        });
    }

    s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }
}
