import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { PDLBreakdownService } from '../../service/pdl-breakdown.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { PDLBreakdownModel, Note } from '../../model/pdl-breakdown.model';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';



@Component({
  selector: 'cw-pdl-breakdown-data',
  templateUrl: './pdl-breakdown.component.html',
  styleUrls: ['./pdl-breakdown.component.scss'],
  providers: [OrderByPipe, PDLBreakdownService]
})
export class PDLBreakDownComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'PDL Breakdown';
  public pdlBreakdownDetailsList: Array<PDLBreakdownModel> = [];
  public headers: Array<HeaderCollectionModel> = [];
  public ipdDateHeaders: Array<string> = [];
  public noteSeries: Array<string> = [];
  public noteHeaders: Array<HeaderCollectionModel> = [];
  public skipNoteHeaders = [];
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _pdlBreakdownService: PDLBreakdownService
    , private ngxOrderPipe: OrderByPipe,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('Deal_Detail');
    this._route.params.subscribe((params: Params) => {

      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.headers.push(new HeaderCollectionModel('principal_bf', 'Principal B/F', 'currency'));
    this.headers.push(new HeaderCollectionModel('pdlAllocated', 'PDL Allocated', 'currency'));
    this.headers.push(new HeaderCollectionModel('pdlToBeCredited', 'PDL To Be Credited', 'currency'));
    this.headers.push(new HeaderCollectionModel('actualPdlCredit', 'Actual PDL Credit', 'currency'));
    this.headers.push(new HeaderCollectionModel('netPdl', 'Net PDL', 'currency'));
    this.headers.push(new HeaderCollectionModel('openingBalance', 'Opening Balance', 'currency'));
    this.headers.push(new HeaderCollectionModel('closingBalance', 'Closing Balance', 'currency'));

    this._pdlBreakdownService.getPDLBreakdownData(this.dealId, this.ipdRunId).subscribe((data) => {
      let ipdDates: Array<string> = [];
      this.pdlBreakdownDetailsList = data;
      //Get the distinct note series
      this.noteSeries = this.pdlBreakdownDetailsList.map(item => item.series)
        .filter((value, index, self) => self.indexOf(value) === index);

      ipdDates = data.map(e => e.ipdDate);
      this.ipdDateHeaders = ipdDates.filter(this.getDateHeadrs);
    })
    document.getElementById('preloader').style['display'] = 'none';
  }

  getDateHeadrs(value, index, self) {
    return self.indexOf(value) === index;
  }

  getPdlBreakdownValue(series: string, colName: string, ipdDate: string) {
    let pdlBreakdownValue = this.pdlBreakdownDetailsList.filter(obj => obj.ipdDate == ipdDate && obj.series == series);
    if (pdlBreakdownValue && pdlBreakdownValue.length > 0)
      return this.customCurrencyPipe.transform(pdlBreakdownValue[0][colName]);
    else
      return "";
  }

  exportToExcel() {

    this.exportHeaders = this.exportHeaders.concat(new HeaderCollectionModel('ipdDate', 'IPD Date'), this.headers);

    let ws = this.exportExcelUtility.createWorkbook();

    this.noteSeries.forEach(obj => {
      let pdlBreakdownHeaderRow = Object.entries(obj);
      let tempSeries = pdlBreakdownHeaderRow[0][1];

      let exportPdlBreakdownList = this.pdlBreakdownDetailsList.filter(x => x.series == tempSeries);
      this.exportExcelUtility.addDataToWorkBook(ws, [{ note: 'Note ' + tempSeries },], { header: ["note"], skipHeader: true, origin: -1 });
      let exportPdlBreakdown = this.exportExcelUtility.renameJsonKey(this.exportHeaders, JSON.parse(JSON.stringify(exportPdlBreakdownList)));
      let option = { skipHeader: true, origin: -1 };

      this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(exportPdlBreakdown), option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''], option);

    });

    this.exportExcelUtility.writeWorkbook(ws, "PDLBreakdownData.xlsx")

  }

}