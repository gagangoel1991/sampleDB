import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { PDLSummaryService } from '../../service/pdl-summary.service';


@Component({
  selector: 'sfp-pdl',
  templateUrl: './pdl-summary.component.html',
  styleUrls: ['./pdl-summary.component.scss'],
  providers: [PDLSummaryService]
})
export class PdlSummaryComponent implements OnInit {

  public dealId: number;
  public ipdRunId: number;

  public pdlSummaryModel;
  public tempPdlSummaryModel;
  private datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public dataValuesObj = [];   
  public exportExcelUtility = new ExportExcelUtility();

  constructor(
    private _ipdProcessService: IpdProcessParentService,
    private _pdlBreakdownService: PDLSummaryService,
    private _route: ActivatedRoute,
    private _router: Router
  ) {

    this._ipdProcessService.changeIpdLevel1MenuName('Deal_Detail');

    this._route.params.subscribe((params: Params) => {

      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });

  }

  ngOnInit(): void {

    this._pdlBreakdownService.getPDLBreakdownData(this.dealId, this.ipdRunId).subscribe((data) => {
     
      if (data.length > 0) {

        this.pdlSummaryModel = JSON.parse(JSON.stringify(data));
        this.tempPdlSummaryModel = JSON.parse(JSON.stringify(data));

        let dataValues = [];
        this.pdlSummaryModel.forEach(eachPdlSummary => {
          dataValues = [];
          for (let key in eachPdlSummary) {
            //Format the Dates 
            if (key.toUpperCase() == 'IPDDATE') {
              eachPdlSummary[key] = this.datePipe.transform(eachPdlSummary[key], 'dd/MM/yyyy');
            }
            else {
              eachPdlSummary[key] = this.customCurrencyPipe.transform(eachPdlSummary[key]);
            }
            dataValues.push(eachPdlSummary[key]);
          }
          this.dataValuesObj.push(dataValues);
        });

        //Prepare Left Columns 
        let leftCol = Object.keys(this.pdlSummaryModel[0]);
        for (var i = 0; i < leftCol.length; i++) {
          leftCol[i] = this.unCamelCase(leftCol[i]).replace(/pdl/ig, "PDL").replace(/ipd/ig, "IPD");
        };
        this.dataValuesObj.unshift(leftCol);

      }
    });
  }

  unCamelCase(val) {
    return val
      // insert a space before all caps
      .replace(/([A-Z])/g, ' $1')
      // uppercase the first character
      .replace(/^./, function (str) { return str.toUpperCase(); })
  }

  
  exportToExcel() {

    let ws = this.exportExcelUtility.createWorkbook();
    let headers: Array<HeaderCollectionModel> = [];

    let leftCol = Object.keys(this.tempPdlSummaryModel[0]);
    for (var i = 0; i < leftCol.length; i++) {
      let columnIdentifier = leftCol[i];
      leftCol[i] = this.unCamelCase(leftCol[i]).replace(/pdl/ig, "PDL").replace(/ipd/ig, "IPD");
      if (leftCol[i].toUpperCase() == 'IPDDATE') {
        headers.push(new HeaderCollectionModel(columnIdentifier, leftCol[i]));
      }
      else
        headers.push(new HeaderCollectionModel(columnIdentifier, leftCol[i], 'currency'));
    };
    this.tempPdlSummaryModel.forEach(eachPdlSummary => {
      for (let key in eachPdlSummary) {
        //Format the Dates 
        if (key.toUpperCase() == 'IPDDATE') {
          eachPdlSummary[key] = this.datePipe.transform(eachPdlSummary[key], 'dd/MM/yyyy');
        }
      }
    });

    let pdlList = this.exportExcelUtility.renameJsonKey(headers, JSON.parse(JSON.stringify(this.tempPdlSummaryModel))); //Deep Copy
    let option = { skipHeader: true, origin: -1 };
    this.exportExcelUtility.addDataToWorkBook(ws, [{ note: "Principal Deficiency Ledger" },], { header: ["note"], skipHeader: true, origin: -1 });
    this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(pdlList), option);


    this.exportExcelUtility.writeWorkbook(ws, "PrincipalDeficiencyLedgerData.xlsx")
  }


}
