import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe, DecimalPipe } from '@angular/common';
import { CBNoteSummaryService } from '../../service/cb-note-summary.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { CBNoteStaticAttributeModel, CBNoteModel, RangeObject } from '../../model/cb-note-summary';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import moment from 'moment';
import 'moment-precise-range-plugin';
import { DealIpdBasicInfoModel } from '../../model/deal-ipd-basicinfo.model';
declare module 'moment' {
  function preciseDiff(start: string | Date | moment.Moment, end: string | Date | moment.Moment, convertToObject?: boolean): RangeObject;
}
@Component({
  selector: 'cb-note-summary',
  templateUrl: './cb-note-summary.component.html',
  styleUrls: ['./cb-note-summary.component.scss'],
  providers: [DecimalPipe, CBNoteSummaryService]
})
export class CBNoteSummaryComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'Note Summary';
  public noteStaticAttributeList: Array<CBNoteStaticAttributeModel> = [];
  public tempNoteStaticAttribute: Array<CBNoteStaticAttributeModel> = [];
  public noteSummaryDetailsList: Array<CBNoteModel> = [];
  public headers: Array<HeaderCollectionModel> = [];
  public noteHeaders: Array<HeaderCollectionModel> = [];
  public ipdDateHeaders: Array<string> = [];
  public skipNoteHeaders = [];
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public dealIpdBasicInfoModel: DealIpdBasicInfoModel;

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _cbNoteSummaryService: CBNoteSummaryService
    , private _decimalPipe: DecimalPipe,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('Note_summary');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.headers.push(new HeaderCollectionModel('couponPaymentStartPeriod', 'Coupon Payment Start Period', null));
    this.headers.push(new HeaderCollectionModel('couponPaymentEndPeriod', 'Coupon Payment End Period', null));
    this.headers.push(new HeaderCollectionModel('daysInInterestPeriod', 'Days In Interest Period', 'number'));
    this.headers.push(new HeaderCollectionModel('dayCountBasis', 'Day Count Basis', 'number'));
    this.headers.push(new HeaderCollectionModel('baseRate', 'Base Rate', 'percent'));
    this.headers.push(new HeaderCollectionModel('couponRate', 'Coupon Rate', 'percent'));
    this.headers.push(new HeaderCollectionModel('principalOutstanding_Ccy', 'Principal Outstanding(CCY)', 'currency'));
    this.headers.push(new HeaderCollectionModel('principalOutstanding_GBP', 'Principal Outstanding(GBP)', 'currency'));
    this.headers.push(new HeaderCollectionModel('interestAmountDue_Ccy', 'Interest Amount Due(CCY)', 'currency'));
    this.headers.push(new HeaderCollectionModel('interestAmountDue_GBP', 'Interest Amount Due(GBP)', 'currency'));
    this.headers.push(new HeaderCollectionModel('requiredRedemptionForHardBullet', 'Required Redemption For Hard Bullet', 'currency'));
    this.headers.push(new HeaderCollectionModel('redemptionAmountForExtendedBond_GT1yr', 'Redemption Value for Extended Maturity greater than 1 year', 'currency'));
    this.headers.push(new HeaderCollectionModel('redemptionAmountForExtendedBond_LTEq1yr', 'Redemption Value for Extended Maturity less than equal to 1 year', 'currency'));
    this.headers.push(new HeaderCollectionModel('rateForEstimation', 'Rate For Estimation (for Reserve calc)', 'percent'));
    this.headers.push(new HeaderCollectionModel('estimatedThreeMonthInterest_GBP', 'Estimated 3 months Interest (for Reserve calc)', 'currency'));
    this.headers.push(new HeaderCollectionModel('estimatedOneMonthInterest_GBP', 'Estimated 1 months Interest (for Reserve calc)', 'currency'));

    this.getDealIpdBasicInfo();
    document.getElementById('preloader').style['display'] = 'none';
  }

  getNoteSummaryData() {
    this._cbNoteSummaryService.getNoteSummary(this.dealId, this.ipdRunId).subscribe((data) => {
      let ipdDates: Array<string> = [];      
      this.noteStaticAttributeList = data.cbNoteStaticAttributeList;
      this.noteStaticAttributeList.forEach(obj => {
        obj.remainingTerm = this.getRemainingTerm(obj.maturityDate);
      });
      this.noteStaticAttributeList.forEach(obj => this.tempNoteStaticAttribute.push(Object.assign({}, obj)));
      this.noteSummaryDetailsList = data.cbNoteList;
      ipdDates = data.cbNoteList.map(e => e.ipdDate);
      this.ipdDateHeaders = ipdDates.filter(this.getDateHeadrs);
    })
  }

  getDealIpdBasicInfo() {
    this.dealIpdBasicInfoModel = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData();
    if (this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {      
      this.getNoteSummaryData();
    }
    else {
      this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
        this.dealIpdBasicInfoModel = data;
        this.getNoteSummaryData();
      });
    }
  }

  getRemainingTerm(maturityDate: Date) {
    let remainingTerm = "";
    if (maturityDate != null && maturityDate != undefined && this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {
      var m1 = moment(this.dealIpdBasicInfoModel.ipdDate);
      var m2 = moment(maturityDate);
      var diff = moment.preciseDiff(m1, m2, true);
      if (diff.years > 0) {
        remainingTerm += ' ' + diff.years + " Year";
        if (diff.years > 1)
          remainingTerm += 's';
      }
      if (diff.months > 0) {
        remainingTerm += ' ' + diff.months + " Month";
        if (diff.months > 1)
          remainingTerm += 's';
      }
      if (diff.days > 0) {
        remainingTerm += ' ' + diff.days + " Day";
        if (diff.days > 1)
          remainingTerm += 's';
      }
      if (diff.firstDateWasLater && remainingTerm != '') {
        remainingTerm = '-' + remainingTerm;
      }
    }
    return remainingTerm;
  }

  getDateHeadrs(value, index, self) {
    return self.indexOf(value) === index;
  }

  getNoteSummaryValue(dealNoteId: number, colName: string, ipdDate: string) {
    let noteValue = this.noteSummaryDetailsList.filter(obj => obj.ipdDate == ipdDate && obj.dealNoteId == dealNoteId);
    let formatObj = this.headers.filter(x => x.name == colName);
    if (noteValue.length && formatObj.length && formatObj[0].exportFormat == 'currency') {
      let value = noteValue[0][colName] != null ? noteValue[0][colName] : 0.00;
      return this._decimalPipe.transform(value, '1.2-2');
    }
    else if (noteValue.length && formatObj.length && formatObj[0].exportFormat == 'percent') {
      return this.customCurrencyPipe.transform(noteValue[0][colName] * 100, 4) + ' %';
    } else if (noteValue.length && formatObj.length && formatObj[0].exportFormat == 'number') {
      return this.customCurrencyPipe.transform(noteValue[0][colName] , 0);
    } else if (noteValue.length && formatObj.length && formatObj[0].exportFormat == null) {
      return noteValue[0][colName];
    }
    else {
      return "";
    }
  }

  exportToExcel() {
    this.noteHeaders.push(new HeaderCollectionModel('dealNoteId', 'Deal Note ID'));
    this.noteHeaders.push(new HeaderCollectionModel('dealNote', 'Deal Note'));
    this.noteHeaders.push(new HeaderCollectionModel('isin', 'ISIN'));
    this.noteHeaders.push(new HeaderCollectionModel('currency', 'Currency'));
    this.noteHeaders.push(new HeaderCollectionModel('issuanceAmount', 'Limit Amount', 'currency'));
    this.noteHeaders.push(new HeaderCollectionModel('margin', 'Margin (bps)', 'percent'));
    this.noteHeaders.push(new HeaderCollectionModel('rateType', 'Rate Type', 'percent'));
    this.noteHeaders.push(new HeaderCollectionModel('maturityDate', 'Maturity Date', 'date'));
    this.noteHeaders.push(new HeaderCollectionModel('remainingTerm', 'Remaining Term'));
    this.noteHeaders.push(new HeaderCollectionModel('hardBulletSeries', 'Bullet'));
    this.noteHeaders.push(new HeaderCollectionModel('extendedMaturitySeries', 'Extended Maturity Series'));
    this.noteHeaders.push(new HeaderCollectionModel('isSwapLinked', 'Is Swap Linked'));

    //Summary data header collection
    this.exportHeaders = this.exportHeaders.concat(new HeaderCollectionModel('ipdDate', 'IPD Date'), this.headers);

    //Skip columns from export
    this.skipNoteHeaders.push(['dealNoteId', 'Deal Note ID']);

    let ws = this.exportExcelUtility.createWorkbook();

    let sourceNoteStaticAttribute = JSON.parse(JSON.stringify(this.tempNoteStaticAttribute)); //Deep Copy

    let staticAttributeList = this.exportExcelUtility.renameJsonKey(this.noteHeaders, sourceNoteStaticAttribute);

    staticAttributeList.forEach(obj => {
      let noteHeaderRow = Object.entries(obj);
      let tempDealNoteId = noteHeaderRow[0][1];
      let exportData = this.exportExcelUtility.skipColumnFromExport(noteHeaderRow, this.skipNoteHeaders);

      let transposeNoteHeader = [];
      this.exportExcelUtility.transpose(exportData).forEach(x => {
        x.shift();
        transposeNoteHeader.push(x);
      });

      let option = { skipHeader: true, origin: -1 };
      this.exportExcelUtility.addDataToWorkBook(ws, transposeNoteHeader, option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''], option);

      let noteSummaryList = this.noteSummaryDetailsList.filter(x => x.dealNoteId == tempDealNoteId);

      let exportNoteSummary = this.exportExcelUtility.renameJsonKey(this.exportHeaders, JSON.parse(JSON.stringify(noteSummaryList)));

      this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(exportNoteSummary), option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''], option);

    });

    this.exportExcelUtility.writeWorkbook(ws, "CBNoteSummaryData.xlsx")

  }

}
