import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { SoniaCompoundingModel } from '../../model/sonia-compounding.model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { SoniaCompoundingService } from '../../service/sonia-compounding.service';
import * as xlsx from 'xlsx';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';

@Component({
  selector: 'sfp-sonia-compounding',
  templateUrl: './sonia-compounding.component.html',
  styleUrls: ['./sonia-compounding.component.scss'],
  providers: [SoniaCompoundingService]
})
export class SoniaCompoundingComponent implements OnInit {
  @ViewChild('soniaCompoundingRateForm') soniaCompoundingRateForm: NgForm;
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'Sonia Compounding';
  public accuralStartDate: string;
  public accuralEndDate: string;

  public headers: Array<HeaderCollectionModel> = [];
  public ipdDateHeaders: Array<string> = [];
  public groupType: Array<string> = [];
  public dealSwapType: Array<string> = [];
  public bondSwapType: Array<string> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public soniaCompoundingList: Array<SoniaCompoundingModel> = [];
  private readonly _formatDate = 'dd/MM/yyyy';
  private readonly _dateFormat = 'yyyy-MM-dd';
  private readonly _invalidDate = 'Invalid date';
  private readonly _startDtGrThEndDt = 'Accural Start Date cannot be greater then Accural End Date';

  constructor(private _ipdProcessService: IpdProcessParentService,
    private _soniaCompoundingService: SoniaCompoundingService,
    private _toastservice: GlobalToasterService,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('sonia_compounding');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {


    this.headers.push(new HeaderCollectionModel('couponPeriodStart', 'Coupon Start Date', 'date'));
    this.headers.push(new HeaderCollectionModel('couponPeriodEnd', 'Coupon End Date', 'date'));
    this.headers.push(new HeaderCollectionModel('coupon', 'Compounded Rate', 'percent'));

    this._soniaCompoundingService.getSoniaCompoundingSummary(this.dealId, this.ipdRunId).subscribe((data) => {
      let ipdDates: Array<string> = [];
      this.soniaCompoundingList = data;
      console.log(this.soniaCompoundingList);

      ipdDates = data.map(e => this.datePipe.transform(e.ipdDate, this._formatDate));
      this.ipdDateHeaders = ipdDates.filter(this.getUniqueItem);
      let toDate = this.datePipe.transform(this.soniaCompoundingList[0].collectionEndDate, this._dateFormat);
      console.log(toDate);
      let fromDate: Date = new Date(this.soniaCompoundingList[0].collectionStartDate);
      console.log(fromDate);
     // fromDate.setDate(fromDate.getDate() - 90);
      this.accuralEndDate = this.datePipe.transform(toDate, this._dateFormat);
      this.accuralStartDate = this.datePipe.transform(fromDate, this._dateFormat);
      this.groupType = data.map(e => e.groupType).filter(this.getUniqueItem);
      this.dealSwapType = data.filter(e => e.groupType == 'Deal Swap').map(a => a.swapName).filter(this.getUniqueItem)
      this.bondSwapType = data.filter(e => e.groupType == 'Bond Swap').map(a => a.swapName).filter(this.getUniqueItem)
    })
  }

  getUniqueItem(value, index, self) {
    return self.indexOf(value) === index;
  }

  getDealSwapValue(groupType: string, colName: string, ipdDate: string, swapName: string) {
    let dealSwap = this.soniaCompoundingList.filter(obj => this.datePipe.transform(obj.ipdDate, this._formatDate) == ipdDate && obj.swapName == swapName && obj.groupType == groupType);
    if (dealSwap && dealSwap.length > 0) {
      if (colName === "couponPeriodStart" || colName === "couponPeriodEnd") {
        return this.datePipe.transform(dealSwap[0][colName], this._formatDate);
      }
      else if (colName === "coupon") {
        return this.customCurrencyPipe.transform(dealSwap[0][colName], 4) + ' %';
      }
      return dealSwap[0][colName];
    }
    else
      return "NA";
  }

  validateDate() {
    if (this.accuralStartDate == null || this.accuralStartDate == '' || this.accuralEndDate == null || this.accuralEndDate == '') {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._invalidDate);
      return false;
    } else if (this.accuralStartDate > this.accuralEndDate) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._startDtGrThEndDt);
      return false;
    }
    return true
  }

  soniaCompoundingRateDownload() {
    if (this.validateDate()) {
      this._soniaCompoundingService.getSoniaCompoundingData(this.accuralStartDate, this.accuralEndDate).subscribe((data) => {
        let ws = xlsx.utils.book_new();
        xlsx.utils.sheet_add_json(ws, data);
        const wb: xlsx.WorkBook = xlsx.utils.book_new();
        xlsx.utils.book_append_sheet(wb, ws, 'Data');
        xlsx.writeFile(wb, "SoniaCompoundingRateData.xlsx");

      });
    }
  }

  exportToExcel() {    
    let exportHeaders: Array<HeaderCollectionModel> = [];

    let ws = this.exportExcelUtility.createWorkbook();

    this.groupType.forEach(obj => {

      let exportSoniaCompoundingList = this.soniaCompoundingList.filter(x => x.groupType == obj);
      this.exportExcelUtility.addDataToWorkBook(ws, [{ note: obj },], { header: ["note"], skipHeader: true, origin: -1 });
      exportHeaders=[];
      if(obj == 'Deal Swap' || obj == 'Bond Swap' ){
       
        exportHeaders = exportHeaders.concat(
          new HeaderCollectionModel('ipdDate', 'IPD Date', 'date'),
          new HeaderCollectionModel('swapName', 'Type'),this.headers);
      
      }
      else{
        exportHeaders = exportHeaders.concat(
          new HeaderCollectionModel('ipdDate', 'IPD Date', 'date'),this.headers);
      }
     
      let exportSoniaCompounding = this.exportExcelUtility.renameJsonKey(exportHeaders, JSON.parse(JSON.stringify(exportSoniaCompoundingList)));
      let option = { skipHeader: true, origin: -1 };

      this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(exportSoniaCompounding), option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''], option);


    });

    this.exportExcelUtility.writeWorkbook(ws, "SoniaCompoundingSummaryData.xlsx")

  }

}
