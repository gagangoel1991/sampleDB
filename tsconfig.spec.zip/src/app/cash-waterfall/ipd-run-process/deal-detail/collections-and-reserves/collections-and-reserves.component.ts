import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { ResultCollRes } from '../../model/collections-and-reserves.model';
import { DealIpdBasicInfoModel } from '../../model/deal-ipd-basicinfo.model';
import { CollectionsAndReserves } from '../../service/collections-and-reserves.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';


@Component({
  selector: 'sfp-collections-and-reserves',
  templateUrl: './collections-and-reserves.component.html',
  styleUrls: ['./collections-and-reserves.component.scss'],
  providers: [CollectionsAndReserves]
})
export class CollectionsAndReservesComponent implements OnInit {

  public dealIpdBasicInfoModel: DealIpdBasicInfoModel;
  public datePipe = new DatePipe('en-UK');
  public startedRequests: number = 0;
  public completedRequests: number = 0;
  public dealId: number;
  public ipdRunId: number;
  public resultCollRes: ResultCollRes = <ResultCollRes>{};

  constructor(private _collectionsAndReserves: CollectionsAndReserves, private _ipdProcessService: IpdProcessParentService
    , private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('Deal_Detail');
    var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
    this.dealId = (values) ? values[0] : null;
    this.ipdRunId = (values) ? values[1] : null;
  }

  ngOnInit(): void {
    this.getCollandIntData();
    this.getDealIpdBasicInfo();
  }

  getDealIpdBasicInfo() {
    this.startedRequests += 1;
    this.dealIpdBasicInfoModel = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData();
    if (this.dealIpdBasicInfoModel != null && this.dealIpdBasicInfoModel != undefined) {      
      this.completedRequests += 1;
    }
    else {
      this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
        this.dealIpdBasicInfoModel = data;
        this.completedRequests += 1;
      });
    }
  }


  getCollandIntData() {
    this.startedRequests += 1;
    this._collectionsAndReserves.getCollandIntData(this.ipdRunId).subscribe((data) => {
      this.resultCollRes = JSON.parse(JSON.stringify(data));
      this.completedRequests += 1;
    });
  }

  downloadExcel() {
    this._collectionsAndReserves.getCollandIntExcelData(this.ipdRunId).subscribe((data) => {

      let FileName = "Collection-and-Reserve-" + this.dealIpdBasicInfoModel.dealName + "-"
        + this.datePipe.transform(this.dealIpdBasicInfoModel.ipdDate, "LLL-yyyy") + "-IPD.xlsx";

      var blob = new Blob([this.s2ab(atob(data))], {
        type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
      });

      var link = document.createElement('a');
      link.href = window.URL.createObjectURL(blob);
      link.download = FileName;

      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);


    });
  }

  s2ab(s) {
    var buf = new ArrayBuffer(s.length);
    var view = new Uint8Array(buf);
    for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
    return buf;
  }

  allRequestCompleted(): boolean {
    return this.startedRequests == this.completedRequests && this.completedRequests > 0;
  }
}
