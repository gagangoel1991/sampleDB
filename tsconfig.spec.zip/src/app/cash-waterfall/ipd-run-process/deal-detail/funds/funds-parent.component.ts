import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { FundsService } from '../../service/funds.service';
import { ReserveFundModel, PrematurityFundModel, CouponPaymentModel, SwapCollateralModel, RevenueLedgerModel, MaturingProceedsLedgerModel, PaymentLedgerModel, PrincipalLedgerModel, CapitalAccountLedgerModel, LedgerList } from '../../model/funds.model';

@Component({
    selector: 'cb-funds-parent-data',
    templateUrl: './funds-parent.component.html',
    styleUrls: ['./funds-parent.component.scss'],
    providers: [FundsService]
})
export class FundsParentComponent implements OnInit {
    public dealId: number;
    public ipdRunId: number;
    public reserveTitle = 'Reserve Ledger';
    public preMaturityTitle = 'Pre-Maturity Liquidity Ledger';
    public couponPaymentTitle = 'Coupon Payment Ledger';
    public swapCollateraTitle = 'Swap Collateral Ledger';
    public revenueLedgerTitle = 'Revenue Ledger';
    public paymentLedgerTitle = 'Payment Ledger';
    public principalLedgerTitle = 'Principal Ledger';
    public maturingLoansLedgerTitle = 'Maturing Proceeds Loan';
    public CapitalAccountLedgerTitle = 'Natwest Capital Account Ledger';

    public exportPreMaturity = 'PreMaturity';
    public exportCouponPayment = 'CouponPayment';
    public exportSwapCollateral = 'SwapCollateral';
    public exportRevenueLedger = 'RevenueLedger';
    public exportPaymentLedger = 'PaymentLedger';
    public exportPrinciaplLedger = 'PrincipalLedger';
    public exportMaturingLoansLedger = 'MaturingLoansLedger';
    public exportCapitalAccountLedger = 'CapitalAccountLedger';


    public reserveData: Array<ReserveFundModel> = [];
    public prematurityFundData: Array<PrematurityFundModel> = [];
    public couponPaymentData: Array<CouponPaymentModel> = [];
    public swapCollateralData: Array<SwapCollateralModel> = [];
    public revenueLedgerData: Array<RevenueLedgerModel> = [];
    public principalLedgerData: Array<PrincipalLedgerModel> = [];
    public paymentLedgerData: Array<PaymentLedgerModel> = [];
    public maturingLoansLedgerData: Array<MaturingProceedsLedgerModel> = [];
    public capitalAccountLedgerData: Array<CapitalAccountLedgerModel> = [];
    public ledgerDataSet: Array<any> = [];
    

    public testDatalineItems: Array<ReserveFundModel> = [];
    public tmpHeaders: Array<Date> = [];
    public ipdDateHeaders: Array<Date> = [];

    public ledgerList : Array<LedgerList> = [];
    public defaultActiveTab: string = 'active';
    public tabsChunks: LedgerList[][];
    public chunkSize: number = 4;

    constructor(private _ipdProcessService: IpdProcessParentService,
        private _fundsService: FundsService,
        private _route: ActivatedRoute,
        private _router: Router) {
        this._ipdProcessService.changeIpdLevel1MenuName('Deal_Detail');
        this._route.params.subscribe((params: Params) => {

            var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
            this.dealId = (values) ? values[0] : null;
            this.ipdRunId = (values) ? values[1] : null;

            
            this.ledgerList.push({ "displayName": "Reserve Ledger", "internalLedgerName" : "reserveLedger", "isActiveTab" : "active",  "title" : "preMaturityTitle", "export" : "exportPreMaturity"  });
            this.ledgerList.push({ "displayName": "Pre-Maturity Liquidity Ledger", "internalLedgerName" : "preMaturityLedger", "isActiveTab" : "",  "title" : "preMaturityTitle", "export" : "exportPreMaturity"  });
            this.ledgerList.push({ "displayName": "Coupon Payment Ledger", "internalLedgerName" : "couponPaymentLedger", "isActiveTab" : "" , "title" : "couponPaymentTitle", "export" : "exportCouponPayment"  });
            this.ledgerList.push({ "displayName": "Swap Collateral Ledger", "internalLedgerName" : "swapCollateralLedger", "isActiveTab" : "" ,  "title" : "swapCollateraTitle", "export" : "exportSwapCollateral"  });
            this.ledgerList.push({ "displayName": "Revenue Ledger", "internalLedgerName" : "revenueLedger", "isActiveTab" : "" , "title" : "revenueLedgerTitle", "export" : "exportRevenueLedger"  });
            this.ledgerList.push({ "displayName": "Payment Ledger", "internalLedgerName" : "paymentLedger" , "isActiveTab" : "" , "title" : "principalLedgerTitle", "export" : "exportPrinciaplLedger"  });
            this.ledgerList.push({ "displayName": "Principal Ledger", "internalLedgerName" : "principalLedger", "isActiveTab" : "" , "title" : "maturingLoansLedgerTitle", "export" : "exportMaturingLoansLedger"  });
            this.ledgerList.push({ "displayName": "Maturing Proceeds Loan", "internalLedgerName" : "postMaturityLoanLedger", "isActiveTab" : "" , "title" : "CapitalAccountLedgerTitle", "export" : "exportCapitalAccountLedger"  });
            this.ledgerList.push({ "displayName": "Natwest Capital Account Ledger", "internalLedgerName" : "capitalLedger", "isActiveTab" : "" , "title" : "paymentLedgerTitle", "export" : "exportPaymentLedger"  });
            this.createTabChunks();

        });
    }

    ngOnInit(): void {

      
            this.loadIpdDateHeaders();
            this.loadTestData();



            this._fundsService.getPreMaturityLiquidityFund(this.dealId, this.ipdRunId).subscribe((data) => {
                this.prematurityFundData = JSON.parse(JSON.stringify(data));
           

                this._fundsService.getCouponPaymentFund(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.couponPaymentData = JSON.parse(JSON.stringify(data));
                });

                this._fundsService.getSwapCollateral(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.swapCollateralData = JSON.parse(JSON.stringify(data));
                });

                this._fundsService.getRevenueLedger(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.revenueLedgerData = JSON.parse(JSON.stringify(data));
                });

                this._fundsService.getPrincipalLedger(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.principalLedgerData = JSON.parse(JSON.stringify(data));
                });

                this._fundsService.getPaymentLedger(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.paymentLedgerData = JSON.parse(JSON.stringify(data));
                });

                this._fundsService.getMaturingLoansLedger(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.maturingLoansLedgerData = JSON.parse(JSON.stringify(data));
                });

                this._fundsService.getCapitalAccountLedger(this.dealId, this.ipdRunId).subscribe((data) => {
                    this.capitalAccountLedgerData = JSON.parse(JSON.stringify(data));
                });
        });
    }

    loadIpdDateHeaders() {
        this.ipdDateHeaders = [];
        this._fundsService.getReserveFundIpdDateHeader(this.dealId, this.ipdRunId).subscribe(data => {
            this.ipdDateHeaders = data.map(e => e.ipdDate);


        });
    }

    loadTestData() {
        this.testDatalineItems = [];
        this._fundsService.getReserveFund(this.dealId, this.ipdRunId).subscribe(data => {
            this.testDatalineItems = data;
        }, (error: any) => {
            console.log(error);
        });
    }

    exportReserve() {
        this._fundsService.getReserveFundExcel(this.dealId, this.ipdRunId).subscribe((data) => {
            let FileName = "ReserveFund.xlsx";
            var blob = new Blob([this.s2ab(atob(data))], {
                type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet;'
            });

            var link = document.createElement('a');
            link.href = window.URL.createObjectURL(blob);
            link.download = FileName;

            document.body.appendChild(link);
            link.click();
            document.body.removeChild(link);

        }, (error: any) => {
            console.log(error);
        });
    }

    s2ab(s) {
        var buf = new ArrayBuffer(s.length);
        var view = new Uint8Array(buf);
        for (var i = 0; i != s.length; ++i) view[i] = s.charCodeAt(i) & 0xFF;
        return buf;
    }


    
  redirectToSelectedTab(ledgerInternalName: string) {
    this.defaultActiveTab = '';

    this.ledgerList.forEach(x => {
        x.isActiveTab = ''
      });

    let data = this.ledgerList.filter(x => x.internalLedgerName == ledgerInternalName);
    data.forEach(x => {
      x.isActiveTab = 'active'
    });
  }

  
  createTabChunks() {
    this.tabsChunks = this.chunkArrayInGroups(this.ledgerList, this.chunkSize);
    console.log( this.tabsChunks);
  }

  
  chunkArrayInGroups(arr, size) {
    var myArray = [];
    for (var i = 0; i < arr.length; i += size) {
      myArray.push(arr.slice(i, i + size));
    }
    return myArray;
  }

}