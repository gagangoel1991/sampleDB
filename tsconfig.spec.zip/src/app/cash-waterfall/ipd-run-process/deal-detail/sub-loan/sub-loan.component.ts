import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { SubloanService } from '../../service/sub-loan.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { DealSubLoanStaticAttributeModel, DealSubloanModel, HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';

@Component({
  selector: 'cw-sub-loan-data',
  templateUrl: './sub-loan.component.html',
  styleUrls: ['./sub-loan.component.scss'],
  providers: [OrderByPipe, SubloanService]  
})
export class SubLoanComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'SubLoan';
  public subloanStaticAttributeList: Array<DealSubLoanStaticAttributeModel> = [];
  public subloanDetailsList: Array<DealSubloanModel> = [];
  public headers: Array<HeaderCollectionModel> = [];
  public ipdDateHeaders: Array<string> = [];
  public subloanHeaders: Array<HeaderCollectionModel> = [];
  public skipSubloanHeaders  = [];
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _subLoanService: SubloanService
    , private ngxOrderPipe: OrderByPipe,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('Deal_Detail');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.headers.push(new HeaderCollectionModel('baseRate', 'Base Rate','percent'));
    this.headers.push(new HeaderCollectionModel('totalRate', 'Total Rate','percent'));
    this.headers.push(new HeaderCollectionModel('interestPeriod', 'Days in Interest Period','number'));
    this.headers.push(new HeaderCollectionModel('principal_bf', 'Principal B/F','currency'));
    this.headers.push(new HeaderCollectionModel('interestDue', 'Interest Due','currency'));
    this.headers.push(new HeaderCollectionModel('unpaidInterestRate_bf', 'Unpaid InterestRate B/F','currency'));
    this.headers.push(new HeaderCollectionModel('interestOnUnpaidInterest', 'Interest On Unpaid Interest','currency'));
    this.headers.push(new HeaderCollectionModel('interestPaid', 'Interest Paid*','currency'));
    this.headers.push(new HeaderCollectionModel('unpaidInterest_cf', 'Unpaid Interest C/F*','currency'));
    this.headers.push(new HeaderCollectionModel('principalPaid', 'Principal Paid*','currency'));
    this.headers.push(new HeaderCollectionModel('principal_cf', 'Principal C/F*','currency'));
    this._subLoanService.getSubLoanData(this.dealId, this.ipdRunId).subscribe((data) => {
      let ipdDates: Array<string> = [];
      this.subloanDetailsList = data.subLoanList;
      this.subloanStaticAttributeList = data.subLoanStaticAttributeList;
      ipdDates = data.subLoanList.map(e => e.ipdDate);
      this.ipdDateHeaders = ipdDates.filter(this.getDateHeadrs);
    })
    document.getElementById('preloader').style['display'] = 'none';
  }

  getDateHeadrs(value, index, self) {
    return self.indexOf(value) === index;
  }

  getSubloanValue(subloanTypeId: number, colName: string, ipdDate: string) {
    let subLoanValue = this.subloanDetailsList.filter(obj => obj.ipdDate == ipdDate && obj.subloanTypeId == subloanTypeId);
    if (subLoanValue && subLoanValue.length > 0){
      if (subLoanValue[0][colName]==="N/A"){
        return subLoanValue[0][colName];
      }
      else if(colName==="interestPeriod") {        
        return subLoanValue[0][colName];
      }
      else if(colName==="baseRate" || colName==="totalRate") {        
        
        return this.customCurrencyPipe.transform(subLoanValue[0][colName],4) + ' %';
      }  
      return this.customCurrencyPipe.transform(subLoanValue[0][colName]);
    }
    else
      return "";
  }
  exportToExcel() {

    this.subloanHeaders.push(new HeaderCollectionModel('subloanTypeId', 'Subloan Type Id'));
    this.subloanHeaders.push(new HeaderCollectionModel('applicableSubLoan', 'Applicable SubLoan'));
    this.subloanHeaders.push(new HeaderCollectionModel('initialAmount', 'Initial Amount','currency'));
    this.subloanHeaders.push(new HeaderCollectionModel('limitAmount', 'Limit Amount','currency'));
    this.subloanHeaders.push(new HeaderCollectionModel('margin', 'Margin (bps)','number'));
    this.subloanHeaders.push(new HeaderCollectionModel('rateType', 'Rate Type'));

    this.exportHeaders = this.exportHeaders.concat(new HeaderCollectionModel('ipdDate', 'IPD Date'), this.headers);

    //Skip columns from export
    this.skipSubloanHeaders.push(['subloanTypeId', 'Subloan Type Id']);

    let ws =  this.exportExcelUtility.createWorkbook();

    let sourcesubloanStaticAttribute = JSON.parse(JSON.stringify(this.subloanStaticAttributeList)); //Deep Copy

    let staticAttributeList = this.exportExcelUtility.renameJsonKey(this.subloanHeaders, sourcesubloanStaticAttribute);

    staticAttributeList.forEach(obj => {
      let headerRow = Object.entries(obj);
      let tempSubloanTypeId = headerRow[0][1];
      let exportData = this.exportExcelUtility.skipColumnFromExport(headerRow,this.skipSubloanHeaders);

      let transposeNoteHeader = [];
      this.exportExcelUtility.transpose(exportData).forEach(x => {
        x.shift();
        transposeNoteHeader.push(x);
      });

      let option ={ skipHeader: true, origin: -1 };
      this.exportExcelUtility.addDataToWorkBook(ws, transposeNoteHeader,option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''],option);

      let subloanList = this.subloanDetailsList.filter(x => x.subloanTypeId == tempSubloanTypeId);

      let subloanData = this.exportExcelUtility.renameJsonKey(this.exportHeaders, JSON.parse(JSON.stringify(subloanList)) );

      this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(subloanData),option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''],option);

    });

    this.exportExcelUtility.writeWorkbook(ws,"SubordinatedLoanData.xlsx")

  }

  
}