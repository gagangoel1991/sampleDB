import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { NoteSummaryService } from '../../service/note-summary.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { DealNoteStaticAttributeModel, DealNoteModel } from '../../model/deal-note.model';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';


@Component({
  selector: 'cw-note-summary-data',
  templateUrl: './note-summary.component.html',
  styleUrls: ['./note-summary.component.scss'],
  providers: [OrderByPipe, NoteSummaryService]
})
export class NoteSummaryComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'Note Summary';
  public noteStaticAttributeList: Array<DealNoteStaticAttributeModel> = [];
  public noteSummaryDetailsList: Array<DealNoteModel> = [];
  public headers: Array<HeaderCollectionModel> = [];
  public ipdDateHeaders: Array<string> = [];
  public noteHeaders: Array<HeaderCollectionModel> = [];
  public skipNoteHeaders  = [];
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _noteSummaryService: NoteSummaryService
    , private ngxOrderPipe: OrderByPipe,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('Note_summary');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this.headers.push(new HeaderCollectionModel('openingPoolFactor', 'Opening Pool Factor','currency'));
    this.headers.push(new HeaderCollectionModel('baseRate', 'BaseRate','percent'));
    this.headers.push(new HeaderCollectionModel('totalRate', 'Total Rate','percent'));
    this.headers.push(new HeaderCollectionModel('daysInInterestPeriod', 'Days In Interest Period','number'));
    this.headers.push(new HeaderCollectionModel('principal_bf', 'Principal B/F','currency'));
    this.headers.push(new HeaderCollectionModel('interestDue', 'Interest Due','currency'));
    this.headers.push(new HeaderCollectionModel('unpaidInterest_bf', 'Unpaid Interest B/F','currency'));
    this.headers.push(new HeaderCollectionModel('interestOnUnpaidInterest_bf', 'Interest On Unpaid Interest B/F','currency'));
    this.headers.push(new HeaderCollectionModel('interestPaid', 'Interest Paid*','currency'));
    this.headers.push(new HeaderCollectionModel('unpaidInterest_cf', 'Unpaid Interest C/F*','currency'));
    this.headers.push(new HeaderCollectionModel('principalPaid', 'Principal Paid*','currency'));
    this.headers.push(new HeaderCollectionModel('principal_cf', 'Principal C/F*','currency'));
    this.headers.push(new HeaderCollectionModel('closingPoolFactor', 'Closing Pool Factor*','currency'));

    this._noteSummaryService.getDealNoteSummary(this.dealId, this.ipdRunId).subscribe((data) => {
      let ipdDates: Array<string> = [];
      this.noteStaticAttributeList = data.dealNoteStaticAttributeList;
      this.noteSummaryDetailsList = data.dealNoteList;
      ipdDates = data.dealNoteList.map(e => e.ipdDate);
      this.ipdDateHeaders = ipdDates.filter(this.getDateHeadrs);
    })

    document.getElementById('preloader').style['display'] = 'none';
  }

  getDateHeadrs(value, index, self) {
    return self.indexOf(value) === index;
  }

  getNoteSummaryValue(dealNoteId: number, colName: string, ipdDate: string) {   
    let noteValue = this.noteSummaryDetailsList.filter(obj => obj.ipdDate == ipdDate && obj.dealNoteId == dealNoteId);
    if (noteValue && noteValue.length > 0){ 
      if (noteValue[0][colName]==="N/A"){
        return noteValue[0][colName];
      }
      else if(colName==="daysInInterestPeriod") {        
        return noteValue[0][colName];
      }
      else if(colName==="baseRate") {        
        return this.customCurrencyPipe.transform(noteValue[0][colName],4) + ' %';
      }
      else if(colName==="totalRate")
      {
        if(noteValue[0]["isNote"])
        {
          return this.customCurrencyPipe.transform(noteValue[0][colName],4) + ' %';
        }
        else
        {
          return "N/A";
        }
      }
      else if (colName==="closingPoolFactor" || colName==="openingPoolFactor") {
        return this.customCurrencyPipe.transform(noteValue[0][colName],4);
      }
      return this.customCurrencyPipe.transform(noteValue[0][colName]);
    }
      
    else
      return "";
  }

  exportToExcel() {

    //Note data header collection
    this.noteHeaders.push(new HeaderCollectionModel('dealNoteId', 'Deal Note ID'));
    this.noteHeaders.push(new HeaderCollectionModel('dealNote', 'Deal Note'));
    this.noteHeaders.push(new HeaderCollectionModel('isin', 'ISIN'));
    this.noteHeaders.push(new HeaderCollectionModel('issuanceAmount', 'Limit Amount', 'currency'));
    this.noteHeaders.push(new HeaderCollectionModel('margin', 'Margin (bps)', 'number'));
    this.noteHeaders.push(new HeaderCollectionModel('maturityDate', 'Maturity Date'));
    this.noteHeaders.push(new HeaderCollectionModel('couponFloor', 'Coupon Floor', 'percent'));

    //Summary data header collection
    this.exportHeaders = this.exportHeaders.concat(new HeaderCollectionModel('ipdDate', 'IPD Date'), this.headers);
  
    //Skip columns from export
    this.skipNoteHeaders.push(['dealNoteId', 'Deal Note ID']);
  
    let ws =  this.exportExcelUtility.createWorkbook();

    let sourceNoteStaticAttribute = JSON.parse(JSON.stringify(this.noteStaticAttributeList)); //Deep Copy

    let staticAttributeList = this.exportExcelUtility.renameJsonKey(this.noteHeaders, sourceNoteStaticAttribute);

    staticAttributeList.forEach(obj => {
      let noteHeaderRow = Object.entries(obj);
      let tempDealNoteId = noteHeaderRow[0][1];
      let exportData = this.exportExcelUtility.skipColumnFromExport(noteHeaderRow,this.skipNoteHeaders);

      let transposeNoteHeader = [];
      this.exportExcelUtility.transpose(exportData).forEach(x => {
        x.shift();
        transposeNoteHeader.push(x);
      });

      let option ={ skipHeader: true, origin: -1 };
      this.exportExcelUtility.addDataToWorkBook(ws, transposeNoteHeader,option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''],option);

      let noteSummaryList = this.noteSummaryDetailsList.filter(x => x.dealNoteId == tempDealNoteId);

      let exportNoteSummary = this.exportExcelUtility.renameJsonKey(this.exportHeaders, JSON.parse(JSON.stringify(noteSummaryList)));

      this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(exportNoteSummary),option);

      this.exportExcelUtility.addDataToWorkBook(ws, [''],option);

    });

    this.exportExcelUtility.writeWorkbook(ws,"NoteSummaryData.xlsx")

  }

}
