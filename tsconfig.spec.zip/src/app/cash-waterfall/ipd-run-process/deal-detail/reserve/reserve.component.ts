import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DatePipe } from '@angular/common';
import { ReserveService } from '../../service/reserve.service';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { DealReserveModel, ReserveType } from '../../model/deal-reserve.model';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';



@Component({
  selector: 'cw-reserve-data',
  templateUrl: './reserve.component.html',
  styleUrls: ['./reserve.component.scss'],
  providers: [OrderByPipe, ReserveService]
})
export class ReserveComponent implements OnInit {
  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public customCurrencyPipe = new CustomCurrencyPipe();
  public title = 'Reserve';

  public reserveDetailsList: Array<DealReserveModel> = [];
  public reserveDetailsList1: Array<DealReserveModel> = [];
  public reserveDetailsList2: Array<DealReserveModel> = [];
  public headers: Array<HeaderCollectionModel> = [];
  public ipdDateHeaders: Array<string> = [];
  public distinctReserve: Array<string> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public exportHeaders: Array<HeaderCollectionModel> = [];

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _reserveService: ReserveService
    , private ngxOrderPipe: OrderByPipe,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('Deal_Detail');
    this._route.params.subscribe((params: Params) => {

      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    //this.headers.push(new HeaderCollectionModel('principal_bf', 'Principal B/F'));
    this.headers.push(new HeaderCollectionModel('reserveFund_bf', 'Reserve Fund B/F','currency'));
    this.headers.push(new HeaderCollectionModel('requiredReserveFund', 'Reserve  Required Fund','currency'));
    this.headers.push(new HeaderCollectionModel('reserveFundDue', 'Reserve Fund Due','currency'));
    this.headers.push(new HeaderCollectionModel('reserveResidualAmount', 'Reserve Residual Amount','currency'));
    this.headers.push(new HeaderCollectionModel('drawingsInPeriod', 'Drawings In Period*','currency'));
    this.headers.push(new HeaderCollectionModel('creditReceived', 'Credit Received*','currency'));
    this.headers.push(new HeaderCollectionModel('reserveFund_cf', 'Reserve Fund C/F*','currency'));

    this._reserveService.getReserveData(this.dealId, this.ipdRunId).subscribe((data) => {
      let ipdDates: Array<string> = [];
      this.reserveDetailsList = data;
      //Get the distinct reserve 
      this.distinctReserve = this.reserveDetailsList.map(item => item.displayName)
        .filter((value, index, self) => self.indexOf(value) === index);

      this.reserveDetailsList1 = data.filter(e => e.reserveFundTypeId == ReserveType.GeneralReserve);
      this.reserveDetailsList2 = data.filter(e => e.reserveFundTypeId == ReserveType.LiquidityReserve);
      ipdDates = data.map(e => e.ipdDate);
      this.ipdDateHeaders = ipdDates.filter(this.getDateHeadrs);
    })
    document.getElementById('preloader').style['display'] = 'none';
  }

  getDateHeadrs(value, index, self) {
    return self.indexOf(value) === index;
  }

  getReserveValue(reserveName:string, colName:string, ipdDate:string){
    let reserveValue = this.reserveDetailsList.filter(obj => obj.ipdDate == ipdDate && obj.displayName == reserveName);
    if(reserveValue && reserveValue.length>0){
      return this.customCurrencyPipe.transform(reserveValue[0][colName]);
    }
    else
      return "";
  }

  exportToExcel() {

    let ws =  this.exportExcelUtility.createWorkbook();
    this.exportHeaders = this.exportHeaders.concat(new HeaderCollectionModel('ipdDate', 'IPD Date'), this.headers);
  
    this.distinctReserve.forEach(obj =>{

      let reserveDetailsList = this.reserveDetailsList.filter(e => e.displayName == obj);

      let reserveList = this.exportExcelUtility.renameJsonKey(this.exportHeaders,reserveDetailsList); 

      let option ={ skipHeader: true, origin: -1 };
      this.exportExcelUtility.addDataToWorkBook(ws, [{note: obj},], { header: ["note"], skipHeader:true,origin: -1 });
      this.exportExcelUtility.addDataToWorkBook(ws, this.exportExcelUtility.transpose(reserveList),option);
      this.exportExcelUtility.addDataToWorkBook(ws, [''],option);
    });  
    
    this.exportExcelUtility.writeWorkbook(ws,"ReserveData.xlsx")
  }


}