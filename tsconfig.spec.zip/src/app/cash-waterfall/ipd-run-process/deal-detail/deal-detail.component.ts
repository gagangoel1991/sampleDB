import { ChangeDetectorRef, Component, Input, OnInit } from '@angular/core';
import { DealDetailService } from '../service/deal-detail.service';
import { DealIpdBasicInfoModel } from '../model/deal-ipd-basicinfo.model';
import { IpdProcessParentService } from '../service/ipd-process-parent.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { IpdAdjustmentParams } from '../model/cash-waterfall-line-item-model';
import { FormBuilder } from '@angular/forms';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { WorkflowAuditTrailPopupComponent } from '../../../shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from '../../../shared/model/workflow-audit-trail.model';
import { AuthWorkflowType } from '../../../shared/model/auth-workflow-enum';


@Component({
  selector: 'sfp-deal-detail',
  templateUrl: './deal-detail.component.html',
  styleUrls: ['./deal-detail.component.scss'],
  providers: [DealDetailService]
})
export class DealDetailComponent implements OnInit {
  @Input() tabName: string;
  public formatDateTime = 'dd/MM/yyyy hh:mm a';
  public dealDetail: DealIpdBasicInfoModel;
  public tabLevel1Name: string;
  ipdParams: IpdAdjustmentParams;


  constructor(private router: Router,
    private _dealDetailService: DealDetailService,
    private _ipdProcessService: IpdProcessParentService,
    private _fb: FormBuilder, private ref: ChangeDetectorRef,
    private _route: ActivatedRoute,
    private _modalService: NgbModal,) {



    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._route.params.subscribe((params: Params) => {
      //this._ipdProcessService.changeIpdLevel1MenuName('adjustments');
      console.log('IPD Deal Detail  constructor called.');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this.router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
      this.tabLevel1Name = this.router.url.split('/')[5]; //Fetching the parent tab name 

    });
  }

  ngOnInit(): void {
    this._dealDetailService.getDealDetailData(this.ipdParams).subscribe(data => {
      console.log(data);
      this._ipdProcessService.setDealIpdBasicInfoGlobalModelData(data);
      this._ipdProcessService.DealIpdBasicInfoModelChanged.emit(data);
    }, (error: any) => {
      console.log(error);
    });

    this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
      this.dealDetail = data;
    });
  }

  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.ipdParams.ipdRunId, AuthWorkflowType.Deal_IPD)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }


  backIpdSummary() {
    this.router.navigate(['/cashwaterfall/ipdrunprocess/' + this.ipdParams.dealId + '/' + this.ipdParams.ipdRunId + '/']);
  }
}
