import { Component, ViewEncapsulation, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { OrderByPipe } from 'ngx-pipes';
import { DailyCollectionService } from '../../../ipd-run-process/service/daily-collection.service';
import { DailyCollectionModel, SfpEditableGridColumnModel } from '../../../ipd-run-process/model/daily-collection.model';
import { DatePipe } from '@angular/common';
import { SfpGridContextMenuComponent } from '../../../../shared/components/grid/contextMenu/grid-context-menu.component';
import { ContextMenuService } from 'ngx-contextmenu';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { Router, ActivatedRoute, Params } from '@angular/router';
import { CommentPopUpModel } from '../../model/comment-popup.model';
import { CommentPopUpComponent } from '../comment-popup/comment-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { UpstreamDataAuthService } from '../../service/upstream-data-auth-service';
import { AuthWorkflowPopupComponent } from '../../../../shared/components/auth-workflow/auth-workflow-popup.component';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { SharedDataService } from '../../../../shared/services/shared-data.service';
import { CommonPopupConfigModel } from '../../../../shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from '../../../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { WorkflowAuditTrailPopupComponent } from '../../../../shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from '../../../../shared/model/workflow-audit-trail.model';
import { ToasterTypes, GlobalToasterService } from '../../../../shared/services/globaltoaster.service';
import { AuthWorkflowType, AuthWorkflowStep } from '../../../../shared/model/auth-workflow-enum';
import { AuthWorkflowStatusModel } from '../../../../shared/model/auth-workflow-status.model';
import { AuthModalConfigModel } from '../../../../shared/model/auth-modal-config.model';
import { DealNameEnum } from '../../../../shared/enum/deal-name-enum';

@Component({
  selector: 'cw-feed-daily-col',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './daily-collection.component.html',
  styleUrls: ['./daily-collection.component.scss'],
  providers: [OrderByPipe, DailyCollectionService, UpstreamDataAuthService]
})

export class DailyCollectionComponent implements OnInit {
  public dailyCollectionModel: DailyCollectionModel;
  public dailyCollectionList: Array<DailyCollectionModel> = [];
  public exportDailyCollectionList: Array<DailyCollectionModel> = [];
  public tempDailyCollectionList = [];
  public dailyCollectionGridCustomCols: Array<SfpEditableGridColumnModel> = [];

  public selectedSortCol = '';
  public colSortType = 'asc';
  public title = 'Daily Collection';
  public datePipe = new DatePipe('en-UK');
  public searchSubmitted = false;
  private readonly _formatDate = 'dd-MM-yyyy';
  private readonly _valueChangeMessage = "You have not changed any value.";
  private readonly _requiredInputMessage = "Please correct required field errors.";
  private readonly _numberRegex = "^-?[0-9]{0,16}(\.[0-9]{1,4})?$";
  private readonly _numberErrorMessage = 'Number required maximum upto 4 decimal places';
  private readonly _sendForAuthorisationMsg = "Sent for authorisation.";
  private readonly _recallMsg = "Recalled Successfully.";
  private readonly _resetlMsg = "Data reset Successfully.";
  //public isAuthoriser: boolean = false;
  public canAuthorize: boolean = true;
  //public isUser: boolean = false;
  public canRecall: boolean = false;
  public loggedInUser: string;
  public automateDataAuthStatusModel: AuthWorkflowStatusModel;
  public editing = {};
  public filteredData = [];
  public ColumnMode = ColumnMode;
  public currencyTypeList: any[] = [];
  public dailyCollectionForm: Array<FormGroup> = [];;
  public submitted = false;
  public item: any;
  public dealId: number;
  public ipdRunId: number;
  public sourceDailyCollectionList: Array<DailyCollectionModel> = [];
  public dailyCollectionLoaded: boolean = true;
  public isDataChangesAllow: boolean = true;
  public exportFileName = 'SFPCollectionData.xlsx';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;

  @ViewChild(SfpGridContextMenuComponent) rightClick: SfpGridContextMenuComponent;

  constructor(private _ipdProcessService: IpdProcessParentService,
    private ngxOrderPipe: OrderByPipe,
    private fb: FormBuilder,
    private _userRoleService: UserRoleService,
    private _contextMenuService: ContextMenuService,
    private _dailyCollectionService: DailyCollectionService,
    private _upstreamDataAuthService: UpstreamDataAuthService,
    private _toastservice: GlobalToasterService, private _route: ActivatedRoute,
    private _router: Router,
    private _modalService: NgbModal, private _sharedDataService: SharedDataService) {

    this._ipdProcessService.changeIpdLevel1MenuName('automated_data');
    var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
    this.dealId = (values) ? values[0] : null;
    this.ipdRunId = (values) ? values[1] : null;
    this.automateDataAuthStatusModel = new AuthWorkflowStatusModel("", "", 0, "", "", "", "")
  }

  private createMultipleFormGroups() {
    for (let index = 0; index < this.dailyCollectionList.length; index++) {
      this.dailyCollectionForm.push(
        this.fb.group({
          accruedInterestCF: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , accruedInterestEarnedNotApplied: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , closingTrueBalance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , closingTrueBalanceDerived: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , controlBreakVariance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentArrearsInsuranceAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentCapitalInArrearsAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentControlBreak: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentFeeArrearsAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentFinesArrearsAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentInterestEarnedNotAppliedAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentInterestInArrearsAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentPrepaymentAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentSumTotalCapital: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentTrueBalanceAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentTrueCapitalBalanceAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , currentTrueInterestAfterCalcDateAMT: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , custStatementBalance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , custStatementBalanceDerived: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , deflaggedPrincipalReceipts: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , deflaggedRevenueReceipts: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , deflaggedVOverallVariance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , feesCharged: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , feesChargedCapitalised: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , feesReceived: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , furtherStageAdvances: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , interestCharged: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , interestReceived: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , netRevenueReceipts: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , otherPrincipalMovements: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , overallVariance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , overPayments: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , partialPrepayments: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , principalReceipts: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , principalReceiptsCheck: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , principalReceiptsDerived: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , principalReceiptsVariance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , redemptions: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , scheduledPrincipalReductions: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , totalBalanceMovements: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , totalCashReceived: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , totalDeflaggedAmount: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , totalRevenueReceipts: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , variance1: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , prevSumTotalCapital: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
          , topupBalance: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        }))
    }
  }

  ngOnInit(): void {
    this.loadDailyCollectionList();
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
  }

  loadDailyCollectionList() {
    this.dailyCollectionLoaded = false;
    this.editing = {};
    this.showHideLoadingImage(true)
    this.dailyCollectionGridCustomCols = [];
    this.tempDailyCollectionList = [];
    this.sourceDailyCollectionList = [];
    this.dailyCollectionList = [];
    this._dailyCollectionService.getDailyCollectionList(this.dealId, this.ipdRunId).subscribe(data => {
      data.dailyCollectionList.forEach(element => {
        if (element.status == 0) {
          element.modifiedBy = '';
          element.modifiedDate = null;
        }
      });
      data.sourceDailyCollectionList.forEach(element => {
        if (element.status == 0) {
          element.modifiedBy = '';
          element.modifiedDate = null;
        }
      });
      data.dailyCollectionList.forEach(obj => this.tempDailyCollectionList.push(Object.assign({}, obj)));
      data.sourceDailyCollectionList.forEach(val => this.sourceDailyCollectionList.push(Object.assign({}, val)));
      this.bindDailyCollectionListData(data.dailyCollectionList);
      this.configureDailyCollectionGrid(data.columns);
      this.createMultipleFormGroups();
      this.removeCollectionField();
      this.checkAuthorisationStatus();
      this.dailyCollectionLoaded = true;
    },
      error => console.log(error));
    this.showHideLoadingImage(false);
  }

  removeCollectionField() {
    let dealName = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData().dealName?.toUpperCase();
    if (dealName != DealNameEnum[DealNameEnum.DEIMOS]) {
      for (let index = 0; index < this.dailyCollectionForm.length; index++) {
        this.dailyCollectionForm[index].removeControl('topupBalance');
      }
    }
  }

  getFilteredColumn() {
    const filteredCol = this.dailyCollectionGridCustomCols.filter(function (col) {
      return col.isChecked;
    });
    return filteredCol;
  }

  bindDailyCollectionListData(data: DailyCollectionModel[]) {
    this.dailyCollectionList = data;
    this.filteredData = data;
    this.exportDailyCollectionList = JSON.parse(JSON.stringify(data)); //Deep Copy
  }

  applyDatePipe() {
    this.dailyCollectionGridCustomCols.forEach(customColumn => {
      if (customColumn.pipeFormatter === 'date') {
        this.dailyCollectionList.forEach(gridDataRecord => {
          let valueToDateFormat = gridDataRecord[customColumn.columnName];
          gridDataRecord[customColumn.columnName] =
            (valueToDateFormat !== null) ? this.datePipe.transform(gridDataRecord[customColumn.columnName], this._formatDate)
              : '';
        });
      }
    });
  }

  configureDailyCollectionGrid(columns: any) {
    this.dailyCollectionGridCustomCols.push(new SfpEditableGridColumnModel('collectionDate', 'Collection Date', false, 'date', 'date', '', true, true, ''));
    this.dailyCollectionGridCustomCols.push(new SfpEditableGridColumnModel('brand', 'Brand', false, '', '', '', true, true, ''));
    columns.forEach(element => {
      this.dailyCollectionGridCustomCols.push(new SfpEditableGridColumnModel(element.key, element.displayKey, element.isEditable, 'input', '', '', true, true, ''));
    });
    this.dailyCollectionGridCustomCols.push(new SfpEditableGridColumnModel('changeReason', 'Modify Reason', false, '', '', '', true, true, ''));
    this.dailyCollectionGridCustomCols.push(new SfpEditableGridColumnModel('modifiedBy', 'Modified By', false, '', '', '', true, true, ''));
    this.dailyCollectionGridCustomCols.push(new SfpEditableGridColumnModel('modifiedDate', 'Modified Date', false, 'date', 'date', '', true, true, ''));
  }


  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      // contextMenu: this,
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  // Custom Sort
  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }

    this.dailyCollectionList = this.ngxOrderPipe.transform(this.dailyCollectionList, filter);
    console.log('Sorting Colum: ' + colName);
  }

  sfpGridColumnFilter(event, colName, colIdx) {
    if (this.dailyCollectionList) {
      const filteredCol = this.dailyCollectionGridCustomCols.filter(function (col) {
        return col.isChecked;
      });
      const searchValue = event.target.value.toLowerCase();
      filteredCol[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let tempGridData = this.filteredData;
      filteredCol.forEach(function (col) {
        if (col.filterText !== '' && tempGridData.length > 0) {
          tempGridData = tempGridData.filter(function (row) {
            return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.dailyCollectionList = tempGridData;
    }
  }

  // Save row
  save(row, rowIndex) {
    this.submitted = true;
    if (this.dailyCollectionForm[rowIndex].valid) {
      if (!this.CheckDataChange(row)) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
        return;
      }
      const modalRefPopUp = this._modalService.open(CommentPopUpComponent, {
        backdrop: 'static',
        keyboard: false
      });
      var commentModel = new CommentPopUpModel(AuthWorkflowType.Automated_Data_Daily_Collection, row, rowIndex, this.dealId, this.ipdRunId);
      modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
      modalRefPopUp.componentInstance.popupEmitService.subscribe((emmitedValue) => {
        this.editing[emmitedValue] = false;
        this.loadDailyCollectionList();
      });
    }
    else
      this._toastservice.openToast(ToasterTypes.error, this.title, this._requiredInputMessage);
  }

  // cancel row
  cancel(row, rowIndex) {
    this.editing[rowIndex] = false;
    this.dailyCollectionList = JSON.parse(JSON.stringify(this.tempDailyCollectionList));
  }

  IsValidControl(name: any, isSubmitted: boolean, rowIndex: number) {
    var fieldName = this.dailyCollectionForm[rowIndex].controls[name]
    var isValid: Boolean = true
    if ((fieldName.touched || isSubmitted) && (fieldName.errors?.required || fieldName.errors?.pattern)) {
      isValid = false;
    }
    return isValid;
  }

  IsCellValueChanged(row: any, name: string) {
    var modifiedRow = this.sourceDailyCollectionList.filter(x => x?.collectionDate == row?.collectionDate && x?.brand == row?.brand);
    if (modifiedRow.length) {
      if (row[name] == modifiedRow[0][name]) {
        return false
      }
      else {
        return true
      }
    }
    else
      return false;
  }

  getRowClass = (row) => {
    var sourceRow = this.sourceDailyCollectionList.filter(x => x.collectionDate == row?.collectionDate && x?.brand == row?.brand);
    if (sourceRow.length) {
      if (sourceRow[0]['status'] == AuthWorkflowStep.Authorise) {
        return { 'cw-ngx-row-bg-authorised': true };
      }
      for (let key of Object.keys(row)) {
        if (sourceRow[0][key] != row[key]) {
          return { 'cw-ngx-row-bg-color': true };
        }
      }
    }
  }


  getToolTipMessage(name: any, isSubmitted: boolean, rowIndex: number) {
    let isValid = this.IsValidControl(name, isSubmitted, rowIndex);
    let errorMessage: string = "";
    if (!isValid) {
      this.dailyCollectionGridCustomCols.forEach(x => {
        if (x.columnName == name) {
          errorMessage = this._numberErrorMessage;
        }
      })
    }
    return errorMessage;
  }

  private CheckDataChange(row: any) {
    var originalRow = this.tempDailyCollectionList.filter(x => x.collectionDate == row?.collectionDate && x?.brand == row?.brand);
    if (originalRow.length) {
      for (let key of Object.keys(row)) {
        if (row[key] != originalRow[0][key]) {
          return true
        }
      }
    }
    else
      return false;
  }

  showHideLoadingImage(isShow) {
    if (isShow)
      document.getElementById('preloader').style['display'] = 'block';
    else
      document.getElementById('preloader').style['display'] = 'none';
  }

  sendForAuthorisation() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Daily_Collection, AuthWorkflowStep.SendForAuthorisation, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._sendForAuthorisationMsg);
  }

  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Daily_Collection, AuthWorkflowStep.Recall, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._recallMsg);
  }

  reset() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Daily_Collection, AuthWorkflowStep.Reset, this.dealId, this.ipdRunId);
    this._upstreamDataAuthService.manageUpstreamDataAuthWorkflowByUser(model).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.loadDailyCollectionList();
    });
  }

  openAuthActionModal() {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });
    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Daily_Collection, AuthWorkflowStep.Approve_Reject, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.loadDailyCollectionList();
    });
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.loadDailyCollectionList();
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    // this.isAuthoriser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.ApproveReject);
    // this.isUser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.AddEdit);
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
  }

  checkAuthorisationStatus() {
    this.setUpUserRolesAndPermissions();
    this._upstreamDataAuthService.getUpstreamDataAuthWorkflowStatus(this.dealId, this.ipdRunId, AuthWorkflowType.Automated_Data_Daily_Collection).subscribe((result) => {
      this.automateDataAuthStatusModel = result;
      this.automateDataAuthStatusModel.stepDescription = this.automateDataAuthStatusModel?.stepDescription ? this.automateDataAuthStatusModel.stepDescription : "Not Edited";
      this.automateDataAuthStatusModel.actionBy = this.automateDataAuthStatusModel?.actionBy ? this.automateDataAuthStatusModel.actionBy : "NA";
      this.automateDataAuthStatusModel.actionDate = this.automateDataAuthStatusModel?.actionDate ? this.datePipe.transform(this.automateDataAuthStatusModel.actionDate, "dd/MM/yyyy") : "NA";
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() && this.isApprovRejectAccess) {
        this.canAuthorize = false;
      }
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() || (!this.isApprovRejectAccess)) {
        this.canRecall = true;
      }
    });
  }

  resizeGrid() {
    if (document.getElementsByTagName('ngx-datatable').length > 0) {
      this._sharedDataService.triggerWindowResize(200);
    }
  }

  getHeight() {
    let containerElem = document.getElementById("dcTable");
    let remainHeight = document.documentElement.clientHeight - (containerElem.getBoundingClientRect().top + window.scrollY);
    this._sharedDataService.triggerWindowResize(1000);
    return {
      'height': remainHeight + "px"
    };
  }


  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.ipdRunId, AuthWorkflowType.Automated_Data_Daily_Collection)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;

  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel(`Reset ${this.title}`, `Do you want to revert your changes?`);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

}