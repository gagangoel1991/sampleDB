import { GlobalToasterService, ToasterTypes } from '../../../../shared/services/globaltoaster.service';
import { Component, ViewEncapsulation, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';
import { OrderByPipe } from 'ngx-pipes';
import { BondRatingService } from '../../../ipd-run-process/service/bond-rating.service';
import { BondRatingModel, BondRatingParam } from '../../../ipd-run-process/model/bond-rating.model';
import { SfpEditableRatingGridColumnModel } from '../../../ipd-run-process/model/sfp-inline-edit-gridoption-ratings.model';
import { DatePipe } from '@angular/common';
import { SfpGridContextMenuComponent } from '../../../../shared/components/grid/contextMenu/grid-context-menu.component';
import { ContextMenuService } from 'ngx-contextmenu';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CommentPopUpComponent } from '../comment-popup/comment-popup.component';
import { CommentPopUpModel } from '../../model/comment-popup.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { SharedDataService } from '../../../../shared/services/shared-data.service';
import { CommonPopupConfigModel } from '../../../../shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from '../../../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { Rating } from '../../../../shared/model/auth-workflow-enum';
import { subString } from 'src/app/shared/pipes/sub-string.pipe';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';


@Component({
  selector: 'cw-feed-bondRating',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './bond-rating.component.html',
  styleUrls: ['./bond-rating.component.scss'],
  providers: [OrderByPipe, BondRatingService, subString]
})

export class BondRatingComponent implements OnInit {
  @ViewChild('mydatatable') table: any;
  public bondRatingParams: BondRatingParam;
  public bondRatingModel: BondRatingModel;
  public bondRatingList: Array<any> = [];
  public exportBondRatingList: Array<any> = [];
  public tempBondRatingList = [];
  public bondRatingGridCustomCols: Array<SfpEditableRatingGridColumnModel> = [];

  // ISIN + seprator + NoteName
  public seprator = ' | ';

  public selectedSortCol = '';
  public colSortType = 'asc';
  public title = 'Bond Rating';
  public datePipe = new DatePipe('en-UK');
  public searchSubmitted = false;
  public formatDate = 'dd/MM/yyyy';
  public exportFileName = 'BondRatingData.xlsx';
  public bondRatingLoaded: boolean = true;


  public editing = {};
  public filteredData = [];
  public ColumnMode = ColumnMode;
  public ratingList: any[] = [];
  public bondRatingForm: Array<FormGroup> = [];
  public submitted = false;
  public item: any;
  public dealId: number;
  public ipdRunId: number;
  public sourceBondRatingData: Array<any> = [];
  public ratingDate: any;
  public isPostCollectionEndDate: boolean;
  public isDataChangesAllow: boolean = true;
  public isDealAuthorised: boolean = true;
  public isSendForAuthorisation: boolean = true;
  public isdataChange: boolean = false;
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private readonly _valueChangeMessage = "You have not changed any value.";
  public readonly ratingBeforeBusinessEndDateMessage = "* The ratings will be refreshed post business collection end date";

  @ViewChild(SfpGridContextMenuComponent) rightClick: SfpGridContextMenuComponent;
  constructor(private _ipdProcessService: IpdProcessParentService,
    private ngxOrderPipe: OrderByPipe, private fb: FormBuilder,
    private _contextMenuService: ContextMenuService,
    private _bondRatingService: BondRatingService,
    private _toastservice: GlobalToasterService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _modalService: NgbModal,
    private _sharedDataService: SharedDataService,
    private subStr: subString,
    private _userService: UserRoleService) {
    this._route.params.subscribe((params: Params) => {
      this._ipdProcessService.changeIpdLevel1MenuName('ratings');
      console.log('Bond Rating constructor called.');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
      console.log(this.dealId);
    });
  }

  ngOnInit(): void {
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
      let ipdWorkflowStatus = this._ipdProcessService.getDealIpdWorkflowStatus();
      this.isDealAuthorised = (ipdWorkflowStatus == 'Authorise');
      this.isSendForAuthorisation = (ipdWorkflowStatus == 'SendForAuthorisation');
    });
    this.loadBondRatingList();
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
  }

  loadBondRatingList() {
    this.bondRatingLoaded = false;
    this.bondRatingGridCustomCols = [];
    this.tempBondRatingList = [];
    this.sourceBondRatingData = [];
    this.bondRatingList = [];
    this._bondRatingService.getBondRatingList(this.dealId, this.ipdRunId).subscribe(data => {
      this.bindBondRatingtData(data.bondRatingData);
      data.sourceBondRatingData.forEach(val => this.sourceBondRatingData.push(Object.assign({}, val)));
      this.configureBondRatingGrid(data.isiNs);
      this.bondRatingList.forEach(obj => this.tempBondRatingList.push(Object.assign({}, obj)));
      this._bondRatingService.getCreditRatings().subscribe(data => {
        this.ratingList = data;
      })
      this.createMultipleFormGroups();
      if (data.bondRatingData.length) {
        this.ratingDate = data.bondRatingData[0].RatingDate
        this.isPostCollectionEndDate = data.bondRatingData[0].IsPostCollectionEndDate
      }
      this.bondRatingLoaded = true;
    });
    this.isRatingEdited();
    document.getElementById('preloader').style['display'] = 'none';
  }

  isRatingEdited() {
    this._bondRatingService.isBondRatingEdited(this.ipdRunId).subscribe(data => {
      if (data) {
        this.isdataChange = true;
      } else {
        this.isdataChange = false;
      }
    })
  }

  private createMultipleFormGroups() {
    var formControl = {};
    for (let index = 0; index < this.bondRatingList.length; index++) {
      var model = this.bondRatingList[index];
      Object.keys(model).forEach(element => {
        formControl[element] = [''];
      });
      this.bondRatingForm.push(this.fb.group(formControl))
    }
  }

  getFilteredColumn() {
    const filteredCol = this.bondRatingGridCustomCols.filter(function (col) {
      return col.isChecked;
    });
    return filteredCol;
  }

  bindBondRatingtData(data: BondRatingModel[]) {
    this.bondRatingList = data;
    this.filteredData = data;
    this.exportBondRatingList = JSON.parse(JSON.stringify(data)); //Deep Copy

  }


  configureBondRatingGrid(columns: Array<string>) {
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('sourceBondRatingId', 'SourceBondRatingId', 'SourceBondRatingId', '', false, '', '', '', false, false, ''));
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('CRAId', 'CRA', 'CRA', '', false, '', '', '', false, false, ''));
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('RatingDate', 'RatingDate', 'RatingDate', '', false, '', '', '', false, false, ''));
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('RatingTypeId', 'RatingTypeId', 'RatingTypeId', '', false, '', '', '', false, false, ''));
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('RatingAgency', 'Rating Agency', 'Rating Agency', '', false, '', '', '', true, true, ''));
    // this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('RatingType', 'Rating Type', false, '', '', '', true, true, ''));
    columns.forEach(element => {
      let splittedISIN = element.split(this.seprator);
      let formattedISIN = splittedISIN[0];
      let isinName = splittedISIN[1];
      this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel(element, element, formattedISIN, isinName, true, 'select', '', '', true, true, ''));
    });
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('Reason', 'Modify Reason', 'Modify Reason', '', false, '', '', '', true, true, ''));
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('ModifiedBy', 'Last Modified By', 'Last Modified By', '', false, '', '', '', true, true, ''));
    this.bondRatingGridCustomCols.push(new SfpEditableRatingGridColumnModel('ModifiedDate', 'Last Modified Date', 'Last Modified Date', '', false, 'date', '', '', true, true, ''));
  }


  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  // Custom Sort
  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }

    this.bondRatingList = this.ngxOrderPipe.transform(this.bondRatingList, filter);
    console.log('Sorting Colum: ' + colName);
  }

  sfpGridColumnFilter(event, colName, colIdx) {
    if (this.bondRatingList) {
      const filteredCol = this.bondRatingGridCustomCols.filter(function (col) {
        return col.isChecked;
      });
      const searchValue = event.target.value.toLowerCase();
      filteredCol[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let tempGridData = this.filteredData;
      filteredCol.forEach(function (col) {
        if (col.filterText !== '' && tempGridData.length > 0) {
          tempGridData = tempGridData.filter(function (row) {
            return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.bondRatingList = tempGridData;
    }
  }

  // Save row
  save(row, rowIndex) {
    this.submitted = true;
    if (!this.CheckDataChange(row)) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
      return;
    }
    const modalRefPopUp = this._modalService.open(CommentPopUpComponent, {
      backdrop: 'static',
      keyboard: false
    });

    // Removing extra information from the ISIN     
    let modifiedRowObj = {};
    for (const property in row) {
      if (property.indexOf(this.seprator) != -1) {
        let splittedISINCode = property.split(this.seprator);
        let formattedCisCode = splittedISINCode[0];
        modifiedRowObj[formattedCisCode] = row[property];
      }
      else {
        modifiedRowObj[property] = row[property];
      }
    }

    var commentModel = new CommentPopUpModel(Rating.Automated_Data_Bond_Rating, modifiedRowObj, rowIndex, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((emmitedValue) => {
      this.editing[emmitedValue] = false;
      this.loadBondRatingList();
    });
  }

  // cancel row
  cancel(rowIndex: any) {
    this.editing[rowIndex] = false;
    this.bondRatingList = JSON.parse(JSON.stringify(this.tempBondRatingList));
  }

  IsValidControl(name: any, isSubmitted: boolean, index: number) {
    var fieldName = this.bondRatingForm[index].controls[name]
    var isValid: Boolean = true
    if ((fieldName.touched || isSubmitted) && (fieldName.errors?.required || fieldName.errors?.pattern)) {
      isValid = false;
    }
    return isValid;
  }

  getRatingList(row: any) {
    let ratingsArray = [];
    this.ratingList.filter(function (val) {
      if (row.CRAId == val.craId && row.RatingTypeId == val.ratingTypeId) {
        ratingsArray.push(val.rating)
      }
    })
    return ratingsArray;
  }
  private CheckDataChange(row: any) {
    var originalRow = this.tempBondRatingList.filter(x => x.RatingDate == row?.RatingDate && x?.CRAId == row?.CRAId && x?.RatingType == row?.RatingType);
    if (originalRow.length) {
      for (let key of Object.keys(row)) {
        if (row[key] != originalRow[0][key]) {
          return true
        }
      }
    }
    else
      return false;
  }

  IsCellValueChanged(row: any, name: string) {
    if (row.IsPrevIpdRating != 1) {
      var sourceRow = this.sourceBondRatingData.filter(x => x?.RatingDate == row?.RatingDate && x?.CRAId == row?.CRAId && x?.RatingType == row?.RatingType);
      if (sourceRow.length) {
        if (this.getRefinedValue(row[name]) == this.getRefinedValue(sourceRow[0][this.subStr.transform(name, this.seprator)])) {
          return false
        }
        else {
          return true
        }
      }
      else if (row.ModifiedBy && this.getRefinedValue(row[name]) != '')
        return true;

      else
        return false;
    }
  }

  getRowClass = (row) => {
    if (row.IsPrevIpdRating != 1) {
      let rowColor = 'cw-ngx-row-bg-color';
      if (this.isDealAuthorised)
        rowColor = 'cw-ngx-row-bg-authorised';

      var sourceRow = this.sourceBondRatingData.filter(x => x.RatingDate == row?.RatingDate && x?.CRAId == row?.CRAId && x?.RatingType == row?.RatingType);
      if (sourceRow.length) {
        for (let key of Object.keys(row)) {
          if (this.getRefinedValue(sourceRow[0][this.subStr.transform(key, this.seprator)]) != this.getRefinedValue(row[key])) {
            return { [rowColor]: true };
          }
        }
      } else {
        if (row.ModifiedBy)
          return { [rowColor]: true };
      }
    }
  }

  getRefinedValue(val: any) {
    if (val == undefined || val == null)
      return "";
    else
      return val;
  }

  resizeGrid() {
    if (document.getElementsByTagName('ngx-datatable').length > 0) {
      this._sharedDataService.triggerWindowResize(200);
    }
  }

  reset() {
    this._bondRatingService.resetBondRating(this.ipdRunId).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, 'Reset successfully');
      this.loadBondRatingList();
    });
  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel(
      `Reset ${this.title}`,
      `Are you sure you want to reset the rating changes? \n This action will reset the rating changes made on this screen.`
    );
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };
}
