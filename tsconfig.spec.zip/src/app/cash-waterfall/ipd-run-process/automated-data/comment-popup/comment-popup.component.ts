import { Component, Input, OnInit, ViewChild, Output, EventEmitter } from '@angular/core';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { CommentPopUpModel } from '../../model/comment-popup.model';
import { FormGroup, NgForm } from '@angular/forms';
import { CollectionLedgerService } from '../../service/collection-ledger.service';
import { DailyCollectionService } from '../../service/daily-collection.service';
import { GlobalToasterService, ToasterTypes } from '../../../../shared/services/globaltoaster.service';
import { CollectionLedgerModel } from '../../../model/collection-ledger.model';
import { DailyCollectionModel } from '../../model/daily-collection.model';
import { BondRatingService } from '../../service/bond-rating.service';
import { CounterpartyRatingService } from '../../service/counter-party-rating.service';
import { InterestRateService } from '../../service/interest-rate.service';
import { InterestRateModel } from '../../model/interest-rate.model';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { AuthWorkflowType, Rating } from '../../../../shared/model/auth-workflow-enum';
import { CashLadderModel } from '../../model/cash-ladder.model';
import { CashLadderService } from '../../service/cash-ladder.service';

@Component({
  selector: 'comment-popup',
  templateUrl: './comment-popup.component.html',
  styleUrls: ['./comment-popup.component.scss'],
  providers: [CollectionLedgerService, DailyCollectionService, BondRatingService, CounterpartyRatingService, InterestRateService,CashLadderService],
})

export class CommentPopUpComponent implements OnInit {
  @ViewChild('myForm') myForm: NgForm;
  @Input() commentPopUpConfig: CommentPopUpModel;
  @Output() popupEmitService = new EventEmitter();
  calls = new Subject();

  public dailyCollectionModel: DailyCollectionModel;
  public title = "Comment";
  public myFormGroup: FormGroup;
  public saveButtonClicked: boolean = false;
  private readonly _clHeader = 'Collection Ledger';
  private readonly _dcHeader = 'Daily Collection';
  private readonly _sbrHeader = 'Bond Rating';
  private readonly _cprHeader = 'Counter Party Rating';
  private readonly _claHeader = 'Cash Ladder';
  private readonly _interestRateHeader = 'Interest Rate';
  private readonly _changeReasonHeader = 'Change Reason';
  private readonly _reasonErrorMessage = "Change reason is required.";
  private readonly _collectionLedgerMessage = "Collection Ledger data updated successfully.";
  private readonly _dailyCollectionMessage = "Daily Collection data updated successfully.";
  private readonly _bondRatingMessage = "Bond Rating data updated successfully.";
  private readonly _cpRatingMessage = "Counter Party Rating data updated successfully.";
  private readonly _interestRateMessage = "Interest Rate data updated successfully.";
  private readonly _cashLadderMessage = "Cash Ladder data updated successfully.";
  private readonly _errorMessage = "Error Occured.";

  constructor(public modal: NgbActiveModal,
    private _collectionLedgerService: CollectionLedgerService,
    private _dailyCollectionService: DailyCollectionService,
    private _bondRatingService: BondRatingService,
    private _cpRatingService: CounterpartyRatingService,
    private _interestRateService: InterestRateService,
    private _toastservice: GlobalToasterService,
    private _modalService: NgbModal,
    private _cashLadderService: CashLadderService) { }

  ngOnInit(): void {

  }

  save() {
    // this.saveButtonClicked = true;
    this.calls.next(true);
    if (this.myForm.valid) {
      if (this.commentPopUpConfig.comment.replace(/\s/g, "").toLowerCase().length <= 0) {
        this.myForm.controls['comment'].setErrors({ 'required': true });
      }
      else {
        switch (this.commentPopUpConfig.type) {
          case AuthWorkflowType.Automated_Data_Collection_Ledger:
            var collectionLedgerModel = new CollectionLedgerModel(this.commentPopUpConfig.row.collectionLedgerId, null, null,
              this.commentPopUpConfig.row.netPrincipalCollections, this.commentPopUpConfig.row.financeCollections,
              this.commentPopUpConfig.row.otherCollections
              , this.commentPopUpConfig.row.totalDailyCashAmount, '', null
              , this.commentPopUpConfig.comment, this.commentPopUpConfig.dealIpdRunId);

            this.saveButtonClicked = true;

            this._collectionLedgerService.updateCollectionLedger(collectionLedgerModel).pipe(takeUntil(this.calls)).subscribe(result => {
              this._toastservice.openToast(ToasterTypes.success, this._clHeader, this._collectionLedgerMessage)
              this.popupEmitService.emit(this.commentPopUpConfig.rowIndex);
              this._modalService.dismissAll();
              this.saveButtonClicked = false;
            },
              err => {
                this._toastservice.openToast(ToasterTypes.error, this._clHeader, this._errorMessage)
                this.saveButtonClicked = false;
                console.log(err);
              });
            break;

          case AuthWorkflowType.Automated_Data_Daily_Collection:
            this.dailyCollectionModel = this.commentPopUpConfig.row;
            this.dailyCollectionModel.changeReason = this.commentPopUpConfig.comment;
            this.dailyCollectionModel.dealId = this.commentPopUpConfig.dealId;
            this.dailyCollectionModel.dealIpdRunId = this.commentPopUpConfig.dealIpdRunId;

            this.saveButtonClicked = true;

            this._dailyCollectionService.saveDailyCollectionData(this.dailyCollectionModel).pipe(takeUntil(this.calls)).subscribe(result => {
              this._toastservice.openToast(ToasterTypes.success, this._dcHeader, this._dailyCollectionMessage);
              this.popupEmitService.emit(this.commentPopUpConfig.rowIndex);
              this._modalService.dismissAll();
              this.saveButtonClicked = false;
            },
              err => {
                this.saveButtonClicked = false; this._toastservice.openToast(ToasterTypes.error, this._clHeader, this._errorMessage)
                this.saveButtonClicked = false;
                console.log(err);
              });
            break;
          case Rating.Automated_Data_Bond_Rating:
            this.commentPopUpConfig.row['ChangeReason'] = this.commentPopUpConfig.comment;
            this.commentPopUpConfig.row['DealId'] = this.commentPopUpConfig.dealId;
            this.commentPopUpConfig.row['DealIpdRunId'] = this.commentPopUpConfig.dealIpdRunId;

            this.saveButtonClicked = true;

            this._bondRatingService.saveBondRatingData(this.commentPopUpConfig.row).subscribe(result => {
              this._toastservice.openToast(ToasterTypes.success, this._sbrHeader, this._bondRatingMessage);
              this.popupEmitService.emit(this.commentPopUpConfig.rowIndex);
              this._modalService.dismissAll();
              this.saveButtonClicked = false;
            },
              err => {
                this._toastservice.openToast(ToasterTypes.error, this._clHeader, this._errorMessage)
                this.saveButtonClicked = false;
                console.log(err);
              },
            );
            break;
          case Rating.Automated_Data_CPRating:
            this.commentPopUpConfig.row['ChangeReason'] = this.commentPopUpConfig.comment;
            this.commentPopUpConfig.row['DealId'] = this.commentPopUpConfig.dealId;
            this.commentPopUpConfig.row['DealIpdRunId'] = this.commentPopUpConfig.dealIpdRunId;

            this.saveButtonClicked = true;

            this._cpRatingService.saveCounterPartyRatingData(this.commentPopUpConfig.row).subscribe(result => {
              this._toastservice.openToast(ToasterTypes.success, this._cprHeader, this._cpRatingMessage);
              this.popupEmitService.emit(this.commentPopUpConfig.rowIndex);
              this._modalService.dismissAll();
              this.saveButtonClicked = false;
            },
              err => {
                this._toastservice.openToast(ToasterTypes.error, this._clHeader, this._errorMessage)
                this.saveButtonClicked = false;
                console.log(err);
              }
            );
            break;
          case AuthWorkflowType.Automated_Data_Interest_Rates:
            var interestRateModel = new InterestRateModel(this.commentPopUpConfig.row.interestRateId,
              this.commentPopUpConfig.row.interestRate, '', '', '', '', new Date()
              , this.commentPopUpConfig.comment, this.commentPopUpConfig.dealIpdRunId)

            this.saveButtonClicked = true;

            this._interestRateService.saveInterestRate(interestRateModel).pipe(takeUntil(this.calls)).subscribe(result => {
              this._toastservice.openToast(ToasterTypes.success, this._interestRateHeader, this._interestRateMessage);
              this.popupEmitService.emit(this.commentPopUpConfig.rowIndex);
              this._modalService.dismissAll();
              this.saveButtonClicked = false;
            },
              err => {
                this._toastservice.openToast(ToasterTypes.error, this._clHeader, this._errorMessage)
                this.saveButtonClicked = false;
                console.log(err);
              });
            break;

          case AuthWorkflowType.Automated_Data_Cash_Ladder:
            var cashLadderModel = new CashLadderModel(this.commentPopUpConfig.row.cashLadderId, null, 
              this.commentPopUpConfig.row.rate, this.commentPopUpConfig.row.inflowAmount,
              this.commentPopUpConfig.row.outflowAmount
              , this.commentPopUpConfig.row.flowSubTotal, '', null
              , this.commentPopUpConfig.comment, this.commentPopUpConfig.dealIpdRunId);

            this.saveButtonClicked = true;
            this._cashLadderService.saveCashLadderData(cashLadderModel).pipe(takeUntil(this.calls)).subscribe(result => {
              this._toastservice.openToast(ToasterTypes.success, this._claHeader, this._cashLadderMessage)
              this.popupEmitService.emit(this.commentPopUpConfig.rowIndex);
              this._modalService.dismissAll();
              this.saveButtonClicked = false;
            },
              err => {
                this._toastservice.openToast(ToasterTypes.error, this._claHeader, this._errorMessage)
                this.saveButtonClicked = false;
                console.log(err);
              });
            break;
        }
      }
    }
    else {
      this._toastservice.openToast(ToasterTypes.error, this._changeReasonHeader, this._reasonErrorMessage);
    }
  }
}
