import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { CollectionLedgerService } from '../../service/collection-ledger.service';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { CollectionLedgerModel } from '../../../../cash-waterfall/model/collection-ledger.model';
import { ContextMenuComponent, ContextMenuService } from 'ngx-contextmenu';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrderByPipe } from 'ngx-pipes';
import { GlobalToasterService, ToasterTypes } from '../../../../shared/services/globaltoaster.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CommentPopUpComponent } from '../comment-popup/comment-popup.component';
import { CommentPopUpModel } from '../../model/comment-popup.model';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { SfpGridContextMenuComponent } from '../../../../shared/components/grid/contextMenu/grid-context-menu.component';
import { DatePipe } from '@angular/common';
import { SfpEditableGridColumnModel } from '../../model/sfp-inline-edit-gridoption.model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { UpstreamDataAuthService } from '../../service/upstream-data-auth-service';
import { AuthWorkflowPopupComponent } from '../../../../shared/components/auth-workflow/auth-workflow-popup.component';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { SharedDataService } from '../../../../shared/services/shared-data.service';
import { WorkflowAuditTrailPopupComponent } from '../../../../shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from '../../../../shared/model/workflow-audit-trail.model';
import { CommonPopupConfigModel } from '../../../../shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from '../../../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { AuthWorkflowType, AuthWorkflowStep } from '../../../../shared/model/auth-workflow-enum';
import { AuthWorkflowStatusModel } from '../../../../shared/model/auth-workflow-status.model';
import { AuthModalConfigModel } from '../../../../shared/model/auth-modal-config.model';

@Component({
  selector: 'cw-collection-ledger',
  templateUrl: './collection-ledger.component.html',
  styleUrls: ['./collection-ledger.component.scss'],
  providers: [OrderByPipe, CollectionLedgerService, UpstreamDataAuthService],
  encapsulation: ViewEncapsulation.None
})
export class CollectionLedgerComponent implements OnInit {
  public item: any;
  public ColumnMode = ColumnMode;
  public CollectionLedgerList: Array<CollectionLedgerModel> = [];
  public exportCollectionLedgerList: Array<CollectionLedgerModel> = [];
  public tempCollectionLedgerList: Array<CollectionLedgerModel> = [];
  public wipCollectionLedgerList: Array<CollectionLedgerModel> = [];
  public registerForm: Array<FormGroup> = [];
  public collectionLedgerGridCustomCols: Array<SfpEditableGridColumnModel> = [];
  public selectedSortCol = '';
  public colSortType = 'asc';
  public editing = {};
  public dealId: number;
  public ipdRunId: number
  public datePipe = new DatePipe('en-UK');
  public searchSubmitted = false;
  public title = 'Collection Ledger';
  // public isAuthoriser: boolean = false;
  // public isUser: boolean = false;
  public canAuthorize: boolean = true;
  public loggedInUser: string;
  public canRecall: boolean = false;
  public automateDataAuthStatusModel: AuthWorkflowStatusModel;
  public collectionLedgerLoaded: boolean = true;
  public isDataChangesAllow: boolean = true;
  public exportFileName = 'StormCollectionData.xlsx';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;

  private readonly _formatDate = 'dd-MM-yyyy';
  private readonly _valueChangeMessage = "You have not changed any value.";
  private readonly _requiredInputMessage = "Please correct required field errors.";
  private readonly _numberErrorMessage = 'Number required maximum upto 4 decimal places';
  private readonly _sendForAuthorisationMsg = "Sent for authorisation.";
  private readonly _recallMsg = "Recalled Successfully.";
  private readonly _resetlMsg = "Data reset Successfully.";
  private readonly _numberRegex = "^-?[0-9]{0,16}(\.[0-9]{1,4})?$";



  @ViewChild(SfpGridContextMenuComponent) rightClick: SfpGridContextMenuComponent;
  constructor(
    private _ipdProcessService: IpdProcessParentService,
    private _collectionLedgerService: CollectionLedgerService,
    private _upstreamDataAuthService: UpstreamDataAuthService,
    private _sharedDataService: SharedDataService,
    private _userRoleService: UserRoleService,
    private _contextMenuService: ContextMenuService,
    private fb: FormBuilder,
    private ngxOrderPipe: OrderByPipe,
    private _toastservice: GlobalToasterService,
    private _modalService: NgbModal,
    private changeDetectorRef: ChangeDetectorRef,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._ipdProcessService.changeIpdLevel1MenuName('automated_data');
    this._route.params.subscribe((params: Params) => {
      console.log('Collection ledger constructor called.');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
      this.automateDataAuthStatusModel = new AuthWorkflowStatusModel("", "", 0, "", "", "", "")
    });
  }
  ngAfterContentChecked() {
    this.changeDetectorRef.detectChanges();
  }
  ngOnInit(): void {
    this.bindCollectionLedgerList();
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
  }

  private bindCollectionLedgerList() {
    this.collectionLedgerLoaded = false;
    this.editing = {};
    this.collectionLedgerGridCustomCols = [];
    this.wipCollectionLedgerList = [];
    this.tempCollectionLedgerList = [];
    this.CollectionLedgerList = [];
    this.configureCollectionLedgerGrid();
    this._collectionLedgerService.getCollectionLedger(this.dealId, this.ipdRunId).subscribe((result) => {
      result.collectionLedgerList.forEach(element => {
        if (element.status == 0) {
          element.modifiedBy = '';
          element.modifiedDate = null;
        }
      });
      this.CollectionLedgerList = result.collectionLedgerList;
      this.exportCollectionLedgerList = JSON.parse(JSON.stringify(result.collectionLedgerList)); //Deep Copy
      this.CollectionLedgerList.forEach(val => this.tempCollectionLedgerList.push(Object.assign({}, val)));
      result.wipCollectionLedgerList.forEach(val => this.wipCollectionLedgerList.push(Object.assign({}, val)));
      this.createMultipleFormGroups();
      this.checkAuthorisationStatus();
      this.collectionLedgerLoaded = true;
    });
    document.getElementById('preloader').style['display'] = 'none';
  }

  private createMultipleFormGroups() {
    for (let index = 0; index < this.CollectionLedgerList.length; index++) {
      this.registerForm.push(
        this.fb.group({
          netPrincipalCollections: ['', [Validators.required, Validators.pattern(this._numberRegex)]],
          financeCollections: ['', [Validators.required, Validators.pattern(this._numberRegex)]],
          otherCollections: ['', [Validators.required, Validators.pattern(this._numberRegex)]],
          totalDailyCashAmount: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        }))
    }
  }

  configureCollectionLedgerGrid() {

    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('collectionLedgerId', 'CollectionLedgerId', false, 'input', '', '', false, false, ''));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('adviceDate', 'Advice Date', false, 'date', 'date', '', true, true, ''));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('collectionDate', 'Collection Date', false, 'date', 'date', '', true, true, ''));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('netPrincipalCollections', 'Net Principal Collections', true, 'input', '', '', true, true, this._numberErrorMessage));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('financeCollections', 'Finance Collections', true, 'input', '', '', true, true, this._numberErrorMessage));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('otherCollections', 'OtherCollections', true, 'input', '', '', true, true, this._numberErrorMessage));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('totalDailyCashAmount', 'TotalDailyCashAmount', true, 'input', '', '', true, true, this._numberErrorMessage));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('reason', 'Modify Reason', false, '', '', '', true, true, ''));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('modifiedBy', 'Modified By', false, '', '', '', true, true, ''));
    this.collectionLedgerGridCustomCols.push(new SfpEditableGridColumnModel('modifiedDate', 'Modified Date', false, 'date', 'date', '', true, true, ''));
  }

  public getVisibleColumn() {
    const visibleColumns = this.collectionLedgerGridCustomCols.filter(function (col) {
      return col.isChecked;;
    });
    return visibleColumns;
  }

  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  applyDatePipe() {
    this.collectionLedgerGridCustomCols.forEach(customColumn => {
      if (customColumn.pipeFormatter === 'date') {
        this.CollectionLedgerList.forEach(gridDataRecord => {
          let valueToDateFormat = gridDataRecord[customColumn.columnName];
          gridDataRecord[customColumn.columnName] =
            (valueToDateFormat !== null) ? this.datePipe.transform(gridDataRecord[customColumn.columnName], this._formatDate)
              : '';
        });
      }
    });
  }

  public sfpGridColumnFilter(event, colName, colIdx) {
    if (this.CollectionLedgerList) {
      const visibleColumns = this.collectionLedgerGridCustomCols.filter(function (col) {
        return col.isChecked;
      });

      const searchValue = event.target.value.toLowerCase();
      visibleColumns[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let filteredData = this.tempCollectionLedgerList;
      visibleColumns.forEach(function (col) {
        if (col.filterText !== '' && filteredData.length > 0) {
          filteredData = filteredData.filter(function (row) {
            return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.CollectionLedgerList = filteredData;
    }
  }

  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }
    this.CollectionLedgerList = this.ngxOrderPipe.transform(this.CollectionLedgerList, filter);
  }

  IsValidControl(rowIndex: number, name: any) {
    var fieldName = this.registerForm[rowIndex].controls[name]
    var isValid: Boolean = true
    if ((fieldName.touched) && (fieldName.errors?.required || fieldName.errors?.pattern)) {
      isValid = false;
    }
    return isValid;
  }

  getRowClass = (row) => {
    var modifiedRow = this.wipCollectionLedgerList.filter(x => x.collectionLedgerId == row?.collectionLedgerId);
    if (modifiedRow.length) {
      if (modifiedRow[0]['status'] == AuthWorkflowStep.Authorise) {
        return { 'cw-ngx-row-bg-authorised': true };
      }
      for (let key of Object.keys(row)) {
        if (modifiedRow[0][key] != row[key]) {
          return { 'cw-ngx-row-bg-color': true };
        }
      }
    }
  }

  IsCellValueChanged(row: any, name: string) {
    var modifiedRow = this.wipCollectionLedgerList.filter(x => x?.collectionLedgerId == row?.collectionLedgerId);
    if (modifiedRow.length) {
      if (row[name] == modifiedRow[0][name]) {
        return false
      }
      else {
        return true
      }
    }
    else
      return false;
  }

  getToolTipMessage(rowIndex: number, name: any) {
    let isValid = this.IsValidControl(rowIndex, name);
    let errorMessage: string = "";
    if (!isValid) {
      this.collectionLedgerGridCustomCols.forEach(x => {
        if (x.columnName == name) {
          errorMessage = x.errorMessage
        }
      })
    }
    return errorMessage;
  }

  save(row, rowIndex) {
    if (this.registerForm[rowIndex].valid) {
      if (!this.CheckDataChange(row)) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
        return;
      }
      const modalRefPopUp = this._modalService.open(CommentPopUpComponent, {
        backdrop: 'static',
        keyboard: false
      });

      var commentModel = new CommentPopUpModel(AuthWorkflowType.Automated_Data_Collection_Ledger, row, rowIndex, this.dealId, this.ipdRunId);
      modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
      modalRefPopUp.componentInstance.popupEmitService.subscribe((emmitedValue) => {
        this.editing[emmitedValue] = !this.editing[emmitedValue];
        this.editing[emmitedValue] = false;
        this.bindCollectionLedgerList()
      });

      modalRefPopUp.result.then(result => {
        console.log(result);
        if (result === 'confirmed') {
        }
        else if (result === 'cancel click') {
          console.log('Cancel popup clicked.')
        }
      });
    }
    else
      this._toastservice.openToast(ToasterTypes.error, this.title, this._requiredInputMessage);
  }

  private CheckDataChange(row: any) {
    var originalRow = this.tempCollectionLedgerList.filter(x => x?.collectionLedgerId == row?.collectionLedgerId);
    if (originalRow.length) {
      for (let key of Object.keys(row)) {
        if (row[key] != originalRow[0][key]) {
          return true
        }
      }
    }
    else
      return false;
  }

  // cancel row
  cancel(row, rowIndex) {
    this.editing[rowIndex] = !this.editing[rowIndex];
    this.CollectionLedgerList[rowIndex] = JSON.parse(JSON.stringify(this.tempCollectionLedgerList[rowIndex])); //deepcopy 
    this.CollectionLedgerList = [...this.CollectionLedgerList]; //table reload
  }

  resizeGrid() {
    if (document.getElementsByTagName('ngx-datatable').length > 0) {
      this._sharedDataService.triggerWindowResize(200);
    }
  }

  sendForAuthorisation() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Collection_Ledger, AuthWorkflowStep.SendForAuthorisation, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._sendForAuthorisationMsg);
  }

  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Collection_Ledger, AuthWorkflowStep.Recall, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._recallMsg);
  }

  reset() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Collection_Ledger, AuthWorkflowStep.Reset, this.dealId, this.ipdRunId);
    this._upstreamDataAuthService.manageUpstreamDataAuthWorkflowByUser(model).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.bindCollectionLedgerList();
    });
  }


  openAuthActionModal() {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });
    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Collection_Ledger, AuthWorkflowStep.Approve_Reject, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.bindCollectionLedgerList();
    });
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.bindCollectionLedgerList();
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    // this.isAuthoriser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.ApproveReject);
    // this.isUser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.AddEdit);
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);

  }

  checkAuthorisationStatus() {
    this.setUpUserRolesAndPermissions();
    this._upstreamDataAuthService.getUpstreamDataAuthWorkflowStatus(this.dealId, this.ipdRunId, AuthWorkflowType.Automated_Data_Collection_Ledger).subscribe((result) => {
      this.automateDataAuthStatusModel = result;
      this.automateDataAuthStatusModel.stepDescription = this.automateDataAuthStatusModel?.stepDescription ? this.automateDataAuthStatusModel.stepDescription : "Not Edited";
      this.automateDataAuthStatusModel.actionBy = this.automateDataAuthStatusModel?.actionBy ? this.automateDataAuthStatusModel.actionBy : "NA";
      this.automateDataAuthStatusModel.actionDate = this.automateDataAuthStatusModel?.actionDate ? this.datePipe.transform(this.automateDataAuthStatusModel.actionDate, "dd/MM/yyyy") : "NA";
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() && this.isApprovRejectAccess) {
        this.canAuthorize = false;
      }
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() || (!this.isApprovRejectAccess)) {
        this.canRecall = true;
      }
    });
  }

  getHeight() {
    let containerElem = document.getElementById("dcTable");
    let remainHeight = document.documentElement.clientHeight - (containerElem.getBoundingClientRect().top + window.scrollY);
    this._sharedDataService.triggerWindowResize(1000);
    return {
      'height': remainHeight + "px"
    };
  }

  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.ipdRunId, AuthWorkflowType.Automated_Data_Collection_Ledger)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel(`Reset ${this.title}`, `Do you want to revert your changes?`);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };
}
