import { TestBed, async, ComponentFixture } from '@angular/core/testing';
import { IntereseRateComponent } from './interest-rate.component';
import { InterestRateService } from '../../service/interest-rate.service';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';

describe('IntereseRateComponent', () => {
    let fixture: ComponentFixture<IntereseRateComponent>;
    const dummyInterestRateData: any = [];
    let interestRateComponent: IntereseRateComponent;
    
    beforeEach(async(() => {
        const mockedInterestRateDataService = jasmine.createSpyObj('InterestRateService', ['getinterestRateList']);
        const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest']);
        TestBed.configureTestingModule({
            declarations: [
                IntereseRateComponent
            ],
            providers: [HttpClient
                , { provide: InterestRateService, useValue: mockedInterestRateDataService }
                , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }

            ]
        }).compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(IntereseRateComponent);
        
    });
    
    

    //Set the interest rate record
    

    it('should create the app', async(() => {
        const fixture = TestBed.createComponent(IntereseRateComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app).toBeTruthy();
    }));
    it(`should have as title 'Interest Rate'`, async(() => {
        const fixture = TestBed.createComponent(IntereseRateComponent);
        const app = fixture.debugElement.componentInstance;
        expect(app.title).toEqual('Interest Rate');
    }));

    it('should load/call interest rate async', async(() => {
        interestRateComponent.interestRateList = dummyInterestRateData;
        const interestRateService = fixture.debugElement.injector.get(InterestRateService);

        //Call the component function
        interestRateService.getinterestRateList(15, 1)
        //Validate/Test the result
        expect(expect(interestRateService.getinterestRateList(12, 1)).toHaveBeenCalled).toBeTruthy();
    }));
});