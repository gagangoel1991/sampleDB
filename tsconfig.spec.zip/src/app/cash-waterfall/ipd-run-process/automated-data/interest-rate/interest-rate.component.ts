import { ChangeDetectorRef, Component, OnInit, ViewEncapsulation, ViewChild } from '@angular/core';
import { InterestRateService } from '../../service/interest-rate.service';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { InterestRateModel } from '../../model/interest-rate.model';
import { ContextMenuComponent, ContextMenuService } from 'ngx-contextmenu';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { OrderByPipe } from 'ngx-pipes';
import { GlobalToasterService, ToasterTypes } from '../../../../shared/services/globaltoaster.service';
import { NgbModal, ModalDismissReasons } from '@ng-bootstrap/ng-bootstrap';
import { CommentPopUpComponent } from '../comment-popup/comment-popup.component';
import { CommentPopUpModel } from '../../model/comment-popup.model';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { SfpGridContextMenuComponent } from '../../../../shared/components/grid/contextMenu/grid-context-menu.component';
import { DatePipe } from '@angular/common';
import { SfpEditableGridColumnModel } from '../../model/sfp-inline-edit-gridoption.model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { UpstreamDataAuthService } from '../../service/upstream-data-auth-service';
import { AuthWorkflowPopupComponent } from '../../../../shared/components/auth-workflow/auth-workflow-popup.component';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { SharedDataService } from '../../../../shared/services/shared-data.service';
import { CommonPopupConfigModel } from '../../../../shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from '../../../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { AuthWorkflowStep, AuthWorkflowType } from '../../../../shared/model/auth-workflow-enum';
import { WorkflowAuditTrailPopupComponent } from '../../../../shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from '../../../../shared/model/workflow-audit-trail.model';
import { AuthWorkflowStatusModel } from '../../../../shared/model/auth-workflow-status.model';
import { AuthModalConfigModel } from '../../../../shared/model/auth-modal-config.model';

@Component({
  selector: 'cw-interest-rate',
  templateUrl: './interest-rate.component.html',
  styleUrls: ['./interest-rate.component.scss'],
  providers: [OrderByPipe, InterestRateService, UpstreamDataAuthService],
  encapsulation: ViewEncapsulation.None
})
export class IntereseRateComponent implements OnInit {
  public item: any;
  public columnMode = ColumnMode;
  public interestRateList: Array<InterestRateModel> = [];
  public exportInterestRateList: Array<InterestRateModel> = [];
  public tempInterestRateList: Array<InterestRateModel> = [];
  public wipInterestRateList: Array<InterestRateModel> = [];
  public interestRateForm: Array<FormGroup> = [];
  public interestRateGridCustomCols: Array<SfpEditableGridColumnModel> = [];
  public selectedSortCol = '';
  public colSortType = 'asc';
  public editing = {};
  public dealId: number;
  public ipdRunId: number
  public datePipe = new DatePipe('en-UK');
  public searchSubmitted = false;
  public title = 'Interest Rate';
  public actionBy: string;
  public actionDate: string;
  private readonly _formatDate = 'dd-MM-yyyy';
  // public isAuthoriser: boolean = false;
  // public isUser: boolean = false;
  public canAuthorize: boolean = true;
  public canRecall: boolean = false;
  public loggedInUser: string;
  public automateDataAuthStatusModel: AuthWorkflowStatusModel;
  public interestRateLoaded: boolean = true;
  public isDataChangesAllow: boolean = true;
  public exportFileName = 'InterestRateData.xlsx';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;

  private readonly _valueChangeMessage = "You have not changed any value.";
  private readonly _requiredInputMessage = "Please correct required field errors.";
  private readonly _numberErrorMessage = 'Number required maximum upto 4 decimal places';
  private readonly _numberRegex = "^-?[0-9]{0,16}(\.[0-9]{1,4})?$";
  private readonly _sendForAuthorisationMsg = "Sent for authorisation."
  private readonly _recallMsg = "Recalled Successfully.";
  private readonly _resetlMsg = "Data reset Successfully.";


  @ViewChild(SfpGridContextMenuComponent) rightClick: SfpGridContextMenuComponent;
  constructor(
    private _ipdProcessService: IpdProcessParentService,
    private _interestRateService: InterestRateService,
    private _upstreamDataAuthService: UpstreamDataAuthService,
    private _sharedDataService: SharedDataService,
    private _userRoleService: UserRoleService,
    private _contextMenuService: ContextMenuService,
    private fb: FormBuilder,
    private ngxOrderPipe: OrderByPipe,
    private _toastservice: GlobalToasterService,
    private _modalService: NgbModal,
    private changeDetectorRef: ChangeDetectorRef,
    private _route: ActivatedRoute,
    private _router: Router) {
    this._route.params.subscribe((params: Params) => {
      this._ipdProcessService.changeIpdLevel1MenuName('automated_data');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
      this.automateDataAuthStatusModel = new AuthWorkflowStatusModel("", "", 0, "", "", "", "")
    });
  }
  ngAfterContentChecked() {
    this.changeDetectorRef.detectChanges();
  }
  ngOnInit(): void {
    this.bindInterestRateList();
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
  }

  private bindInterestRateList() {
    this.interestRateLoaded = false;
    this.editing = {};
    this.interestRateGridCustomCols = [];
    this.wipInterestRateList = [];
    this.tempInterestRateList = [];
    this.interestRateList = [];
    this.configureInterestRateGrid();
    this._interestRateService.getinterestRateList(this.dealId, this.ipdRunId).subscribe((result) => {
      result.interestRateList.forEach(element => {
        if (element.status == 0) {
          element.modifiedBy = '';
          element.modifiedDate = null;
        }
      });
      this.interestRateList = result.interestRateList;
      this.exportInterestRateList = JSON.parse(JSON.stringify(result.interestRateList)); //Deep Copy
      this.interestRateList.forEach(val => this.tempInterestRateList.push(Object.assign({}, val)));
      result.sourceInterestRateList.forEach(val => this.wipInterestRateList.push(Object.assign({}, val)));
      this.createMultipleFormGroups();
      this.checkAuthorisationStatus();
      this.interestRateLoaded = true;
    });

    document.getElementById('preloader').style['display'] = 'none';
  }

  private createMultipleFormGroups() {
    for (let index = 0; index < this.interestRateList.length; index++) {
      this.interestRateForm.push(
        this.fb.group({
          interestRate: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        }))
    }
  }

  configureInterestRateGrid() {
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('interestRateId', 'Interest Rate Id', false, '', '', '', false, false, ''));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('interestRateType', 'Interest Rate Type', false, '', '', '', true, true, ''));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('ricCode', 'RIC Code', false, '', '', '', true, true, ''));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('interestRate', 'Interest Rate', true, 'input', '', '', true, true, this._numberErrorMessage));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('ipdDate', 'Rate Reset Date', false, 'date', 'date', '', true, true, ''));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('reason', 'Modify Reason', false, '', '', '', true, true, ''));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('modifiedBy', 'Modified By', false, '', '', '', true, true, ''));
    this.interestRateGridCustomCols.push(new SfpEditableGridColumnModel('modifiedDate', 'Modified Date', false, 'date', 'date', '', true, true, ''));
  }

  public getVisibleColumn() {
    const visibleColumns = this.interestRateGridCustomCols.filter(function (col) {
      return col.isChecked;;
    });
    return visibleColumns;
  }

  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  applyDatePipe() {
    this.interestRateGridCustomCols.forEach(customColumn => {
      if (customColumn.pipeFormatter === 'date') {
        this.interestRateList.forEach(gridDataRecord => {
          let valueToDateFormat = gridDataRecord[customColumn.columnName];
          gridDataRecord[customColumn.columnName] =
            (valueToDateFormat !== null) ? this.datePipe.transform(gridDataRecord[customColumn.columnName], this._formatDate)
              : '';
        });
      }
    });
  }

  public sfpGridColumnFilter(event, colName, colIdx) {
    if (this.interestRateList) {
      const visibleColumns = this.interestRateGridCustomCols.filter(function (col) {
        return col.isChecked;
      });

      const searchValue = event.target.value.toLowerCase();
      visibleColumns[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let filteredData = this.tempInterestRateList;
      visibleColumns.forEach(function (col) {
        if (col.filterText !== '' && filteredData.length > 0) {
          filteredData = filteredData.filter(function (row) {
            return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.interestRateList = filteredData;
    }
  }

  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }
    this.interestRateList = this.ngxOrderPipe.transform(this.interestRateList, filter);
  }

  IsValidControl(rowIndex: number, name: any) {
    var fieldName = this.interestRateForm[rowIndex].controls[name]
    var isValid: Boolean = true
    if ((fieldName.touched) && (fieldName.errors?.required || fieldName.errors?.pattern)) {
      isValid = false;
    }
    return isValid;
  }

  getRowClass = (row) => {
    var modifiedRow = this.wipInterestRateList.filter(x => x.interestRateId == row?.interestRateId);
    if (modifiedRow.length) {
      if (modifiedRow[0]['status'] == AuthWorkflowStep.Authorise) {
        return { 'cw-ngx-row-bg-authorised': true };
      }
      for (let key of Object.keys(row)) {
        if (modifiedRow[0][key] != row[key]) {
          return { 'cw-ngx-row-bg-color': true };
        }
      }
    }
  }

  IsCellValueChanged(row: any, name: string) {
    var modifiedRow = this.wipInterestRateList.filter(x => x?.interestRateId == row?.interestRateId);
    if (modifiedRow.length) {
      if (row[name] == modifiedRow[0][name]) {
        return false
      }
      else {
        return true
      }
    }
    else
      return false;
  }

  getToolTipMessage(rowIndex: number, name: any) {
    let isValid = this.IsValidControl(rowIndex, name);
    let errorMessage: string = "";
    if (!isValid) {
      this.interestRateGridCustomCols.forEach(x => {
        if (x.columnName == name) {
          errorMessage = x.errorMessage
        }
      })
    }
    return errorMessage;
  }

  save(row, rowIndex) {
    if (this.interestRateForm[rowIndex].valid) {
      if (!this.CheckDataChange(row)) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
        return;
      }
      const modalRefPopUp = this._modalService.open(CommentPopUpComponent, {
        backdrop: 'static',
        keyboard: false
      });

      var commentModel = new CommentPopUpModel(AuthWorkflowType.Automated_Data_Interest_Rates, row, rowIndex, this.dealId, this.ipdRunId);
      modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
      modalRefPopUp.componentInstance.popupEmitService.subscribe((emmitedValue) => {
        this.editing[emmitedValue] = !this.editing[emmitedValue];
        this.editing[emmitedValue] = false;
        this.bindInterestRateList()
      });

      modalRefPopUp.result.then(result => {
        console.log(result);
        if (result === 'confirmed') {
        }
        else if (result === 'cancel click') {
          console.log('Cancel popup clicked.')
        }
      });
    }
    else
      this._toastservice.openToast(ToasterTypes.error, this.title, this._requiredInputMessage);
  }

  private CheckDataChange(row: any) {
    var originalRow = this.tempInterestRateList.filter(x => x?.interestRateId == row?.interestRateId);
    if (originalRow.length) {
      for (let key of Object.keys(row)) {
        if (row[key] != originalRow[0][key]) {
          return true
        }
      }
    }
    else
      return false;
  }

  // cancel row
  cancel(row, rowIndex) {
    this.editing[rowIndex] = !this.editing[rowIndex];
    this.interestRateList[rowIndex] = JSON.parse(JSON.stringify(this.tempInterestRateList[rowIndex])); //deepcopy 
    this.interestRateList = [...this.interestRateList]; //table reload
  }

  sendForAuthorisation() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Interest_Rates, AuthWorkflowStep.SendForAuthorisation, this.dealId, this.ipdRunId)
    this.openModalPopup(model, this._sendForAuthorisationMsg);
  }

  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Interest_Rates, AuthWorkflowStep.Recall, this.dealId, this.ipdRunId)
    this.openModalPopup(model, this._recallMsg);
  }

  reset() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Interest_Rates, AuthWorkflowStep.Reset, this.dealId, this.ipdRunId)
    this._upstreamDataAuthService.manageUpstreamDataAuthWorkflowByUser(model).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.bindInterestRateList();
    });
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.bindInterestRateList();
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    // this.isAuthoriser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.ApproveReject);
    // this.isUser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.AddEdit);
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
  }

  checkAuthorisationStatus() {
    this.setUpUserRolesAndPermissions();
    this._upstreamDataAuthService.getUpstreamDataAuthWorkflowStatus(this.dealId, this.ipdRunId, AuthWorkflowType.Automated_Data_Interest_Rates).subscribe((result) => {
      this.automateDataAuthStatusModel = result;
      this.automateDataAuthStatusModel.stepDescription = this.automateDataAuthStatusModel?.stepDescription ? this.automateDataAuthStatusModel.stepDescription : "Not Edited";
      this.automateDataAuthStatusModel.actionBy = this.automateDataAuthStatusModel?.actionBy ? this.automateDataAuthStatusModel.actionBy : "NA";
      this.automateDataAuthStatusModel.actionDate = this.automateDataAuthStatusModel?.actionDate ? this.datePipe.transform(this.automateDataAuthStatusModel.actionDate, "dd/MM/yyyy") : "NA";
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() && this.isApprovRejectAccess) {
        this.canAuthorize = false;
      }

      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() || (!this.isApprovRejectAccess)) {
        this.canRecall = true;
      }
    });
  }

  openAuthActionModal() {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Interest_Rates, AuthWorkflowStep.Approve_Reject, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.bindInterestRateList();
    });
  }

  resizeGrid() {
    if (document.getElementsByTagName('ngx-datatable').length > 0) {
      this._sharedDataService.triggerWindowResize(200);
    }
  }

  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.ipdRunId, AuthWorkflowType.Automated_Data_Interest_Rates)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel(`Reset ${this.title}`, `Do you want to revert your changes?`);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };
}
