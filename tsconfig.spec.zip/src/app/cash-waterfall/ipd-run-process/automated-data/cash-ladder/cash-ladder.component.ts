import {
  Component, ViewEncapsulation, OnInit, Input, ViewChild, SimpleChanges, OnChanges,
  AfterContentChecked, ChangeDetectorRef
} from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { CashLadderModel, CashLadderParams, SfpEditableGridColumnModel } from '../../../ipd-run-process/model/cash-ladder.model';
import { DatePipe } from '@angular/common';
import { SfpGridContextMenuComponent } from '../../../../shared/components/grid/contextMenu/grid-context-menu.component';
import { Observable } from 'rxjs';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { OrderByPipe } from 'ngx-pipes';
import { ContextMenuComponent, ContextMenuService } from 'ngx-contextmenu';
import { CashLadderService } from '../../../ipd-run-process/service/cash-ladder.service';
import { GlobalToasterService, ToasterTypes } from '../../../../shared/services/globaltoaster.service';
import { KeyValueLookupService } from '../../../../shared/services/key-value-lookup.service';
import { KeyValueLookupTypeEnum } from '../../../../shared/enum/key-value-lookup-type.enum';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { CommentPopUpComponent } from '../comment-popup/comment-popup.component';
import { AuthWorkflowStep, AuthWorkflowType } from 'src/app/shared/model/auth-workflow-enum';
import { CommentPopUpModel } from '../../model/comment-popup.model';
import { AuthWorkflowStatusModel } from 'src/app/shared/model/auth-workflow-status.model';
import { AuthModalConfigModel } from 'src/app/shared/model/auth-modal-config.model';
import { UpstreamDataAuthService } from '../../service/upstream-data-auth-service';
import { AuthWorkflowPopupComponent } from 'src/app/shared/components/auth-workflow/auth-workflow-popup.component';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';
import { CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from 'src/app/shared/components/confirm-common-popup/sfp-common-popup.component';

@Component({
  selector: 'cw-cash-ladder',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './cash-ladder.component.html',
  styleUrls: ['./cash-ladder.component.scss'],
  providers: [OrderByPipe, CashLadderService, KeyValueLookupService, UpstreamDataAuthService]
})
export class CashladderComponent implements OnInit, AfterContentChecked {
  ColumnMode = ColumnMode;
  cashLadderParams: CashLadderParams;
  cashLadderModel: CashLadderModel;
  cashLadderList: Array<CashLadderModel> = [];
  exportCashLadderList: Array<CashLadderModel> = [];
  cashLadderGridCustomCols: Array<SfpEditableGridColumnModel> = [];
  tempCashLadderList : Array<CashLadderModel> = [];
  wipCashLadderList : Array<CashLadderModel> = [];
  public selectedSortCol = '';
  public colSortType = 'asc';
  title = 'Cash Ladder';
  public datePipe = new DatePipe('en-UK');
  searchSubmitted = false;
  public formatDate = 'dd/MM/yyyy';
  public exportFileName = 'CashLadderData.xlsx';
  public dealId: number;
  public ipdRunId: number;
  private readonly _valueChangeMessage = "You have not changed any value.";
  private readonly _requiredInputMessage = "Please correct required field errors.";
  private readonly _numberRegex = "^-?[0-9]{0,16}(\.[0-9]{1,4})?$";
  private readonly _numberErrorMessage = 'Number required maximum upto 4 decimal places';
  private readonly _sendForAuthorisationMsg = "Sent for authorisation.";
  private readonly _recallMsg = "Recalled Successfully.";
  private readonly _resetlMsg = "Data reset Successfully.";


  public editing = {};
  filteredData = [];
  
  currencyTypeList: any[] = [];
  public registerForm: Array<FormGroup> = [];
  submitted = false;
  item: any;


  public canAuthorize: boolean = true;
  public loggedInUser: string;
  public canRecall: boolean = false;
  public automateDataAuthStatusModel: AuthWorkflowStatusModel;
  public cashLaddeLoaded: boolean = true;
  public isDataChangesAllow: boolean = true;
  //public exportFileName = 'StormCollectionData.xlsx';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;

  @ViewChild(SfpGridContextMenuComponent) rightClick: SfpGridContextMenuComponent;
  constructor(private ngxOrderPipe: OrderByPipe, private fb: FormBuilder,
    private _contextMenuService: ContextMenuService,
    private _cashLadderService: CashLadderService,
    private _keyValueLookupService: KeyValueLookupService,
    private _toastservice: GlobalToasterService,
    private changeDetectorRef: ChangeDetectorRef,
    private _route: ActivatedRoute,
    private _ipdProcessService: IpdProcessParentService,
    private _sharedDataService: SharedDataService,
    private _modalService: NgbModal,    
    private _router: Router,
    private _upstreamDataAuthService: UpstreamDataAuthService,
    private _userRoleService: UserRoleService) {

   // this.cashLadderParams = new CashLadderParams(2, 1);

    this._route.params.subscribe((params: Params) => {
      console.log('Collection ledger constructor called.');
      this._ipdProcessService.changeIpdLevel1MenuName('automated_data');
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.dealId = (values) ? values[0] : null;
      this.ipdRunId = (values) ? values[1] : null;
      this.automateDataAuthStatusModel = new AuthWorkflowStatusModel("", "", 0, "", "", "", "")
    });
  }
  ngAfterContentChecked() {
    this.changeDetectorRef.detectChanges();
  }

  ngOnInit(): void {
    this.loadCashLadderList();
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
  }

  IsValidControl(rowIndex: number, name: any) {
    var fieldName = this.registerForm[rowIndex].controls[name]
    var isValid: Boolean = true
    if ((fieldName.touched) && (fieldName.errors?.required || fieldName.errors?.pattern)) {
      isValid = false;
    }
    return isValid;
  }

  private createMultipleFormGroups() {
    for (let index = 0; index < this.cashLadderList.length; index++) {
      this.registerForm.push(
        this.fb.group({

          rate: ['', [Validators.required, Validators.pattern(this._numberRegex)]],
          inflowAmount: ['', [Validators.required, Validators.pattern(this._numberRegex)]],
          outflowAmount: ['', [Validators.required, Validators.pattern(this._numberRegex)]],
          flowSubTotal: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        }))
    }
  }

  getToolTipMessage(name: any, isSubmitted: boolean) {
    let isValid = this.IsValidControl(name, isSubmitted);
    let errorMessage: string = "";
    if (!isValid) {
      this.cashLadderGridCustomCols.forEach(x => {
        if (x.columnName == name) {
          errorMessage = x.errorMessage;
        }
      })
    }
    return errorMessage;
  }
  
  loadCashLadderList() {
    this.cashLaddeLoaded =false;
    this.tempCashLadderList = [];
    this.cashLadderList = [];
    this.wipCashLadderList = [];
    this.cashLadderGridCustomCols =[];
    this.editing = {};
    this.configureCashLadderGrid();
    this.applyDatePipe();
    this._cashLadderService.getCashLadderList(this.dealId, this.ipdRunId).subscribe(data => {
      data.cashLadderList.forEach(element => {
        if (element.status == 0) {
          element.modifiedBy = '';
          element.modifiedDate = null;
        }
      });  
      this.cashLadderList=data.cashLadderList;
      this.exportCashLadderList = JSON.parse(JSON.stringify(data.cashLadderList)); //Deep Copy
      this.cashLadderList.forEach(val => this.tempCashLadderList.push(Object.assign({}, val)));
      data.wipCashLadderList.forEach(val => this.wipCashLadderList.push(Object.assign({}, val)));      
      this.createMultipleFormGroups();
      this.checkAuthorisationStatus();
      this.cashLaddeLoaded =true;
  });

    this._keyValueLookupService.getKeyLookupList(KeyValueLookupTypeEnum.CurrencyList.toString()).subscribe(data => {
      this.currencyTypeList = data;
    })
  }

  getCurrencyList() {
    return this.currencyTypeList;
  }

  getFilteredColumn() {
    const filteredCol = this.cashLadderGridCustomCols.filter(function (col) {
      return col.isChecked;
    });
    return filteredCol;
  }

  bindCashLadderListData(data: CashLadderModel[]) {
    this.cashLadderList = data;
    this.filteredData = data;
  }

  applyDatePipe() {
    this.cashLadderGridCustomCols.forEach(customColumn => {
      if (customColumn.pipeFormatter === 'date') {
        this.cashLadderList.forEach(gridDataRecord => {
          const valueToDateFormat = gridDataRecord[customColumn.columnName];
          gridDataRecord[customColumn.columnName] =
            (valueToDateFormat !== null) ? this.datePipe.transform(gridDataRecord[customColumn.columnName], this.formatDate)
              : '';
        });
      }
    });
  }


  configureCashLadderGrid() {
    // Preparing grid custom columns
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('cashLadderId', 'Cash Ladder Id', false, '', '', '', false, false, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('collectionDate', 'Collection Date', false, 'date', 'date', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('correspondentAccountNumber', 'Correspondent Account Number', false, 'input', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('dealReference', 'Deal Reference', false, 'input', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('product', 'Product', false, 'input', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('subProduct', 'Sub Product', false, 'input', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('counterParty', 'Counter Party', false, 'input', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('contextName', 'Context Name', false, 'input', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('rate', 'Rate', true, 'input', 'number', '', true, true, 'Number required maximum upto 2 decimal places.'));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('maturityDate', 'Maturity Date', false, 'date', 'date', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('currency', 'Currency', false, 'select', '', 'getCurrencyTypeList()', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('inflowAmount', 'Inflow Amount', true, 'input', 'number', '', true, true, 'Number required maximum upto 2 decimal places.'));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('outflowAmount', 'Outflow Amount', true, 'input', 'number', '', true, true, 'Number required maximum upto 2 decimal places.'));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('flowSubTotal', 'Flow SubTotal', true, 'input', 'number', '', true, true, 'Number required maximum upto 2 decimal places.'));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('reason', 'Modify Reason', false, '', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('modifiedBy', 'Modified By', false, '', '', '', true, true, ''));
    this.cashLadderGridCustomCols.push(new SfpEditableGridColumnModel('modifiedDate', 'Modified Date', false, 'date', 'date', '', true, true, ''));
  }


  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      // contextMenu: this,
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  // Custom Sort
  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }

    this.cashLadderList = this.ngxOrderPipe.transform(this.cashLadderList, filter);
    console.log('Sorting Colum: ' + colName);
  }

  getSentenceCase(camcelCase: string) {
    const str1 = camcelCase.replace(/([A-Z]+)/g, ' $1').replace(/([A-Z][a-z])/g, ' $1');
    return str1.charAt(0).toUpperCase() + str1.slice(1);
  }

  isCellValueChanged(row: any, name: string) {
    var modifiedRow = this.wipCashLadderList.filter(x => x?.cashLadderId == row?.cashLadderId);
    if (modifiedRow.length) {
      if (row[name] == modifiedRow[0][name]) {
        return false
      }
      else {
        return true
      }
    }
    else
      return false;
  }

  sfpGridColumnFilter(event, colName, colIdx) {
    if (this.cashLadderList) {
      const filteredCol = this.cashLadderGridCustomCols.filter(function (col) {
        return col.isChecked;
      });
      const searchValue = event.target.value.toLowerCase();
      filteredCol[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let tempGridData = this.filteredData;
      filteredCol.forEach(function (col) {
        if (col.filterText !== '' && tempGridData.length > 0) {
          tempGridData = tempGridData.filter(function (row) {
            return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.cashLadderList = tempGridData;
    }
  }

  // Save row
  save(row, rowIndex)  {
   // this.submitted = true;
    // if (this.registerForm[rowIndex].valid) {
    //   this.cashLadderModel = row;
    //   this.cashLadderModel["maturityDate"] = this.datePipe.transform(this.cashLadderModel["maturityDate"], this.formatDate)
    //   this._cashLadderService.saveCashLadderData(this.cashLadderModel).subscribe(result => {
    //     this.editing[rowIndex] = !this.editing[rowIndex]
    //     this._toastservice.openToast(ToasterTypes.success, 'Cash Ladder', "Cash ladder data updated successfully.");
    //   });
    //   //console.table(this.registerForm.value);
    // }
    // else
    //   this._toastservice.openToast(ToasterTypes.error, 'Cash Ladder', "Required fields are empty.");

    if (this.registerForm[rowIndex].valid) {
      if (!this.CheckDataChange(row)) {
        this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
        return;
      }
      const modalRefPopUp = this._modalService.open(CommentPopUpComponent, {
        backdrop: 'static',
        keyboard: false
      });

      var commentModel = new CommentPopUpModel(AuthWorkflowType.Automated_Data_Cash_Ladder, row, rowIndex, this.dealId, this.ipdRunId);
      modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
      modalRefPopUp.componentInstance.popupEmitService.subscribe((emmitedValue) => {
        this.editing[emmitedValue] = !this.editing[emmitedValue];
        this.editing[emmitedValue] = false;
        this.loadCashLadderList();
      });

      modalRefPopUp.result.then(result => {
        console.log(result);
        if (result === 'confirmed') {
        }
        else if (result === 'cancel click') {
          console.log('Cancel popup clicked.')
        }
      });
    }
    else
      this._toastservice.openToast(ToasterTypes.error, this.title, this._requiredInputMessage);
  }

  // cancel row
  cancel(row, rowIndex) {
    this.editing[rowIndex] = false;
    this.cashLadderList = JSON.parse(JSON.stringify(this.tempCashLadderList));
  }

  resizeGrid() {
    if (document.getElementsByTagName('ngx-datatable').length > 0) {
      this._sharedDataService.triggerWindowResize(200);
    }
  }

  getRowClass = (row) => {
    var modifiedRow = this.wipCashLadderList.filter(x => x.cashLadderId == row?.cashLadderId);
    if (modifiedRow.length) {
      console.log(modifiedRow[0]['status']);
      if (modifiedRow[0]['status'] == AuthWorkflowStep.Authorise) {
        return { 'cw-ngx-row-bg-authorised': true };
      }
      for (let key of Object.keys(row)) {
        if (modifiedRow[0][key] != row[key]) {
          return { 'cw-ngx-row-bg-color': true };
        }
      }
    }
  }

  private CheckDataChange(row: any) {
    var originalRow = this.tempCashLadderList.filter(x => x?.cashLadderId == row?.cashLadderId);
    if (originalRow.length) {
      for (let key of Object.keys(row)) {
        if (row[key] != originalRow[0][key]) {
          return true
        }
      }
    }
    else
      return false;
  }

  sendForAuthorisation() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Cash_Ladder, AuthWorkflowStep.SendForAuthorisation, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._sendForAuthorisationMsg);
  }

  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Cash_Ladder, AuthWorkflowStep.Recall, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._recallMsg);
  }

  reset() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Cash_Ladder, AuthWorkflowStep.Reset, this.dealId, this.ipdRunId);
    this._upstreamDataAuthService.manageUpstreamDataAuthWorkflowByUser(model).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.loadCashLadderList();
    });
  }


  openAuthActionModal() {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });
    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.Automated_Data_Cash_Ladder, AuthWorkflowStep.Approve_Reject, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.loadCashLadderList();
    });
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.loadCashLadderList();
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    // this.isAuthoriser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.ApproveReject);
    // this.isUser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.AddEdit);
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);

  }

  checkAuthorisationStatus() {
    this.setUpUserRolesAndPermissions();
    this._upstreamDataAuthService.getUpstreamDataAuthWorkflowStatus(this.dealId, this.ipdRunId, AuthWorkflowType.Automated_Data_Cash_Ladder).subscribe((result) => {
      this.automateDataAuthStatusModel = result;
      console.log(result);
      this.automateDataAuthStatusModel.stepDescription = this.automateDataAuthStatusModel?.stepDescription ? this.automateDataAuthStatusModel.stepDescription : "Not Edited";
      this.automateDataAuthStatusModel.actionBy = this.automateDataAuthStatusModel?.actionBy ? this.automateDataAuthStatusModel.actionBy : "NA";
      this.automateDataAuthStatusModel.actionDate = this.automateDataAuthStatusModel?.actionDate ? this.datePipe.transform(this.automateDataAuthStatusModel.actionDate, "dd/MM/yyyy") : "NA";
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() && this.isApprovRejectAccess) {
        this.canAuthorize = false;
      }
      if (this.loggedInUser.toLowerCase() === this.automateDataAuthStatusModel?.actionBy.toLowerCase() || (!this.isApprovRejectAccess)) {
        this.canRecall = true;
      }
    });
  }

  getHeight() {
    let containerElem = document.getElementById("dcTable");
    let remainHeight = document.documentElement.clientHeight - (containerElem.getBoundingClientRect().top + window.scrollY);
    this._sharedDataService.triggerWindowResize(1000);
    return {
      'height': remainHeight + "px"
    };
  }

  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.ipdRunId, AuthWorkflowType.Automated_Data_Cash_Ladder)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel(`Reset ${this.title}`, `Do you want to revert your changes?`);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.reset();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

}
