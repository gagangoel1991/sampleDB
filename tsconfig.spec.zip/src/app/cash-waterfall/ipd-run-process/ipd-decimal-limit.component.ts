import { Directive, ElementRef, HostListener, Input, SimpleChanges } from '@angular/core';
@Directive({
  selector: '[appNDigitDecimalNumber]'
})

export class FourDigitDecimalNumberComponent {  
  @Input() appNDigitDecimalNumber = '4';
  public regexPattern: string;
  private regex: RegExp;
  private specialKeys: Array<string> = ['Backspace', 'Tab', 'End', 'Home', 'ArrowLeft', 'ArrowRight', 'Del', 'Delete'];

  constructor(private el: ElementRef) {
    this.buildRegexExpression();
  }

  ngOnChanges(changes: SimpleChanges) {
    this.buildRegexExpression();
  }

  buildRegexExpression() {
    this.regexPattern = '^\\-?\\d*\\.?\\d{0,' + this.appNDigitDecimalNumber + '}$'
    //console.log(this.regexPattern);
    this.regex = new RegExp(this.regexPattern, 'g');
  }


  @HostListener('paste', ['$event'])
  blockPaste(e: ClipboardEvent) {
    let clipboardData = e.clipboardData;
    let pastedText = clipboardData.getData('text');
    if (!String(pastedText).match(this.regex)) {
      e.preventDefault();
    }
  }

  @HostListener('keydown', ['$event'])

  onKeyDown(event: KeyboardEvent) {
    if (this.specialKeys.indexOf(event.key) !== -1) {
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toUpperCase() === "C") {
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toUpperCase() === "V") {
      return;
    }
    if ((event.ctrlKey || event.metaKey) && event.key.toUpperCase() === "X") {
      return;
    }




    let current: string = this.el.nativeElement.value;

    const position = this.el.nativeElement.selectionStart;

    const next: string = [current.slice(0, position), event.key == 'Decimal' ? '.' : event.key, current.slice(position)].join('');

    if (next && !String(next).match(this.regex)) {
      console.log('preventing');
      event.preventDefault();
    }
  }

}