import { Component, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IrTemplateService } from 'src/app/deal-config-master/investor-report/service/ir-template.service';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { OverrideIRModalConfigModel } from '../../model/override-ir-modal-config.model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { IpdSummaryService } from '../../service/ipd-summary.service';

@Component({
  selector: 'sfp-override-ir',
  templateUrl: './override-ir.component.html',
  styleUrls: ['./override-ir.component.scss'],
  providers: [IrTemplateService, IpdSummaryService]
})
export class OverrideIrComponent implements OnInit {
  @ViewChild('overrideIRForm') overrideIRForm: NgForm;
  @Input() overrideIRModalConfig: OverrideIRModalConfigModel;

  @Output() popupEmitService = new EventEmitter();


  public overrideIrFileUploadRequiredValidation: boolean = false;
  public overrideIRFileToUpload: File = null;

  private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);

  private readonly _allowedFiles = ['xlsx'];
  private readonly _overrideIrToastTitle = 'Overridden IR';
  private readonly _overrideIrSaveValidationMessage = 'Please fill required fields marked with asterisk(*) before saving Overridden IR file.';
  private readonly _overrideIrSavedMsg = 'Overridden IR uploaded successfully.';
  private readonly _overrideIrtSizeBlankMsg = 'Overridden IR file size cannot be of 0KB.';
  private readonly _overrideIrInvalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file types is xlsx.';
  private readonly _overrideIrSizeExceedMsg = 'Overridden IR file size cannot exceed 20MB.';
  private readonly _overrideIrUploadErrorMsg = 'Error while saving override IR file.';
  private readonly _fileUploadErrorMsg = '"Investor Report" sheet is missing or not a first sheet of uploaded file.';

  constructor(public modal: NgbActiveModal,
    private _ipdProcessParentService: IpdProcessParentService,
    private _templateService: IrTemplateService,
    private _ipdSummaryService: IpdSummaryService,
    private _toastservice: GlobalToasterService,
    private _modalService: NgbModal) { }

  ngOnInit(): void {
  }


  validateUploadedFileExtension(fileName: string) {
    var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
    if (this._allowedFiles.some(x => x === ext.toLowerCase()))
      return true;
    else
      return false;
  }

  setOverrideIrFileUploadControlInvalid() {
    this.overrideIRForm.form.controls["uploadOverrideIrFile"].markAsDirty();
    this.overrideIRForm.form.controls["uploadOverrideIrFile"].markAsTouched();
    this.overrideIRForm.form.controls["uploadOverrideIrFile"].setErrors({ 'incorrect': true });
    this.overrideIrFileUploadRequiredValidation = true;

  }

  handleOverrideIrFileInput(event: any) {
    if (event && event.target.files) {
      let file = event.target.files.item(0);
      if (!this.validateUploadedFileExtension(file.name)) {
        this._toastservice.openToast(ToasterTypes.error, this._overrideIrToastTitle, this._overrideIrInvalidFileFormatMsg);
        event.srcElement.value = '';
        this.setOverrideIrFileUploadControlInvalid();
        return false;
      }
      if (file.size > this._maxAllowedFileSiz) {
        this._toastservice.openToast(ToasterTypes.error, this._overrideIrToastTitle, this._overrideIrSizeExceedMsg);
        event.srcElement.value = '';
        this.setOverrideIrFileUploadControlInvalid();
        return false;
      }
      if (file.size == 0) {
        this._toastservice.openToast(ToasterTypes.error, this._overrideIrToastTitle, this._overrideIrtSizeBlankMsg);
        event.srcElement.value = '';
        this.overrideIrFileUploadRequiredValidation = true;

        return false;
      }

      //When all validation passed, set the file name
      this.overrideIRFileToUpload = file;
      this.overrideIrFileUploadRequiredValidation = false;
      this.overrideIRModalConfig.originalFileName = this.overrideIRFileToUpload.name;
    }
  }

  save() {
    if (this.overrideIRForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this._overrideIrToastTitle, this._overrideIrSaveValidationMessage);
      Object.keys(this.overrideIRForm.form.controls).forEach((key) => {
        this.overrideIRForm.form.get(key).markAsTouched();
      });

      if (this.overrideIRForm.form.controls["uploadOverrideIrFile"].invalid)
        this.overrideIrFileUploadRequiredValidation = true;
      else
        this.overrideIrFileUploadRequiredValidation = false;

      return false;
    }



    if (this.overrideIRModalConfig.comment.replace(/\s/g, "").toLowerCase().length <= 0) {
      this.overrideIRForm.controls['comment'].setErrors({ 'required': true });
    }
    else if (this.overrideIRModalConfig.originalFileName == null) {
      this.overrideIrFileUploadRequiredValidation = true;
    }
    else {
      //Saving the overrided IR file after all validations
      const formData: any = new FormData();

      formData.append('overridedIrFileAsByte', this.overrideIRFileToUpload, this.overrideIRFileToUpload.name);
      formData.append('originalFileName', this.overrideIRModalConfig.originalFileName);
      formData.append('comment', this.overrideIRModalConfig.comment);
      formData.append('dealId', this.overrideIRModalConfig.dealId.toString());
      formData.append('ipdRunId', this.overrideIRModalConfig.ipdRunId.toString());
      formData.append('ipdDate', this.overrideIRModalConfig.ipdDate.toString());
      formData.append('fileType', "Excel");


      this._ipdProcessParentService.saveOverridedIRFile(formData).subscribe(result => {
        if (result === -1) {//Error in saving file details in db
          this._toastservice.openToast(ToasterTypes.error, this._overrideIrToastTitle, this._overrideIrUploadErrorMsg);
        }
        else if (result === -2) {//IR sheet is missing from the uploaded file
          this._toastservice.openToast(ToasterTypes.error, this._overrideIrToastTitle, this._fileUploadErrorMsg);
        }
        else {
          this._modalService.dismissAll();
          this.overrideIRForm.form.markAsPristine();
          this.overrideIRForm.form.markAsUntouched();
          this._toastservice.openToast(ToasterTypes.success, this._overrideIrToastTitle, this._overrideIrSavedMsg);
          this.popupEmitService.emit(this.overrideIRModalConfig.ipdRunId);
        }
      });
    }

  }
}