import { DatePipe } from '@angular/common';
import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { IpdSummaryLineItemModel } from '../model/ipd-summary-line-item-model';
import { IpdProcessParentService } from '../service/ipd-process-parent.service';
import { IpdSummaryService } from '../service/ipd-summary.service';
import { IpdAdjustmentParams } from '../model/cash-waterfall-line-item-model';
import { DealIpdBasicInfoModel } from '../model/deal-ipd-basicinfo.model';
import { UpstreamDataAuthService } from '../service/upstream-data-auth-service';
import { UserRoleService } from '../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';
import { DealModel } from '../../../deal-config-master/model/deal.model';
import { GlobalToasterService, ToasterTypes } from '../../../shared/services/globaltoaster.service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IpdAuthWorkflowService } from '../service/ipd-auth-workflow-service';
import { CommonPopupConfigModel } from '../../../shared/components/grid/sfp-gridOptions.model';
import { CommonPopupComponent } from '../../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { AuthWorkflowStep, AuthWorkflowType } from '../../../shared/model/auth-workflow-enum';
import { AuthWorkflowStatusModel } from '../../../shared/model/auth-workflow-status.model';
import { AuthModalConfigModel } from '../../../shared/model/auth-modal-config.model';
import { AuthWorkflowPopupComponent } from '../../../shared/components/auth-workflow/auth-workflow-popup.component';
import { AdjustmentWaterfallService } from '../service/adjustment-waterfall.service';
import { NonRatingTriggerService } from '../service/non-rating-trigger.service';
import { DealConditionTestService } from '../service/deal-condition-test.service';
import { OverrideIrComponent } from './override-ir/override-ir.component';
import { OverrideIRModalConfigModel } from '../model/override-ir-modal-config.model';
import { InvestorReportService } from 'src/app/reports/service/investor-report.service';
import { InvestorReportFileNameParams } from 'src/app/reports/model/investor-report.model';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';

@Component({
  selector: 'sfp-ipd-summary',
  templateUrl: './ipd-summary.component.html',
  styleUrls: ['./ipd-summary.component.scss'],
  providers: [IpdSummaryService,UpstreamDataAuthService, IpdAuthWorkflowService, AdjustmentWaterfallService, NonRatingTriggerService,InvestorReportService]
})
export class IpdSummaryComponent implements OnInit {

  public dealId: number;
  public ipdRunId: number;
  public datePipe = new DatePipe('en-UK');
  public title = 'IPD Summary';
  public ipdSummarylineItems: Array<IpdSummaryLineItemModel> = [];
  public dealModel: DealModel;
  //public isAuthoriser: boolean = false;
  //public isUser: boolean = false;
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  public loggedInUser: string;
  public automateDataAuthStatusModel: AuthWorkflowStatusModel;
  public ipdParams: IpdAdjustmentParams;
  public dealDetail: DealIpdBasicInfoModel;
  public ipdStepDescription: string;
  public isDataChangesAllow: boolean = true;
  public codeName: string = "AutomatedData";
  public showAdjustmentResetButton: boolean = false;
  public investorReportFileNameParams: InvestorReportFileNameParams;
  public ipdDate;
  public isExcelFileDownloadStarted = false;
  public customCurrencyPipe = new CustomCurrencyPipe();
  private readonly _sendForAuthorisationMsg = "Sent For Authorisation.";
  private readonly _recallMsg = "Recalled Successfully.";
  private readonly _resetlMsg = "Data Reset Successfully.";


  constructor(
    private _ipdProcessService: IpdProcessParentService,
    private _ipdSummaryService: IpdSummaryService,
    private _userRoleService: UserRoleService,
    private _upstreamDataAuthService: UpstreamDataAuthService,
    private _toastservice: GlobalToasterService,
    private _ipdAuthWorkflowService: IpdAuthWorkflowService,
    private _adjustmentWaterfallService: AdjustmentWaterfallService,
    private _modalService: NgbModal,
    private _route: ActivatedRoute,
    private _router: Router,
    private _nonRatingTriggerService: NonRatingTriggerService,
    private _dealConditionTestService: DealConditionTestService,
    private _investoreReportService: InvestorReportService) {
    var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
    this.dealId = (values) ? values[0] : null;
    this.ipdRunId = (values) ? values[1] : null;
    this._ipdProcessService.changeIpdLevel1MenuName('ipd_summary');
  }

  ngOnInit(): void {
    this._ipdSummaryService.getIpdSummaryData(this.dealId, this.ipdRunId).subscribe((data) => {
      this.ipdSummarylineItems = data;
      console.log(this.ipdSummarylineItems);
      this.ipdSummarylineItems.forEach(x => {
        x.isRowVisible = true;
        x.isExpanded = true;
        x.displayAuthorizerButton = (x.parentId == 0 && x.codeName == this.codeName) ? true : false;
        x.routerLink = x.routerLink?.replace('{0}', this.dealId.toString()).replace('{1}', this.ipdRunId.toString());
      });
    })
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
    this.setUpUserRolesAndPermissions();
    this.checkIPDAuthorisationStatus();
    document.getElementById('preloader').style['display'] = 'none';
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    //this.isAuthoriser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.ApproveReject);
    //this.isUser = this._userRoleService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.AddEdit);
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);

  }


  getChildLineItems(dealIpdSummaryLineItemId: number) {
    return this.ipdSummarylineItems.filter(x => x.parentId == dealIpdSummaryLineItemId);
  }

  getSummaryValue(summaryInfo: string) {
    if (summaryInfo.length > 0) {
      let itemArray = summaryInfo.split('|');
      let itemValue = itemArray[2];
      if (itemArray[1] == 'currency') {
        itemValue = this.customCurrencyPipe.transform(Number(itemValue), 2);
      }
      else if (itemArray[1] == 'percent') {
        itemValue = this.customCurrencyPipe.transform(Number(itemValue) * 100, 4) + ' %';
      }

      return itemArray[0] + (itemArray[0].length>0 ? " : " : "") + itemValue;
    }
  }


  expandParentLineItem(dealIpdSummaryLineItemId: number, parentId) {
    let data = this.ipdSummarylineItems.filter(x => x.parentId == dealIpdSummaryLineItemId && x.parentId > 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
      x.displayAuthorizerButton = this.ipdSummarylineItems.filter(y => y.dealIpdSummaryLineItemId == dealIpdSummaryLineItemId && y.codeName == this.codeName).length > 0 ? true : false

    });
    data = this.ipdSummarylineItems.filter(x => x.dealIpdSummaryLineItemId == dealIpdSummaryLineItemId && x.parentId == 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
    });
  }

  sendForAuthorisation(type: string) {
    let workflowType = this.getWorkflowType(type);
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', workflowType, AuthWorkflowStep.SendForAuthorisation, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._sendForAuthorisationMsg);
  }

  recall(type: string) {
    let workflowType = this.getWorkflowType(type);
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', workflowType, AuthWorkflowStep.Recall, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._recallMsg);
  }

  reset(type: string) {
    let workflowType = this.getWorkflowType(type);
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', workflowType, AuthWorkflowStep.Reset, this.dealId, this.ipdRunId)
    this._upstreamDataAuthService.manageUpstreamDataAuthWorkflowByUser(model).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.reloadCurrentRoute();
    });
  }

  resetAdjustment(type: string) {

    this.ipdParams = new IpdAdjustmentParams(0, 0, null);
    this.ipdParams.dealId = this.dealId;
    this.ipdParams.ipdRunId = this.ipdRunId;

    this.ipdParams.waterfallCategoryName = type;

    this._adjustmentWaterfallService.getPrincipalWaterfallData(this.ipdParams).subscribe(data => {
      data.forEach(x => {
        x.adjustedAmount = 0;
        x.isAdjustmentReset = true;
        x.totalRequiredAmount = Number(x.requiredAmount);
      });

      this._adjustmentWaterfallService.savePrincipalWaterfall(data).subscribe(result => {
        this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
        this.reloadCurrentRoute();
      });
    });

  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.reloadCurrentRoute();
    });
  }

  openAuthActionModal(type: string) {
    let workflowType = this.getWorkflowType(type);
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });
    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', workflowType, AuthWorkflowStep.Approve_Reject, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.reloadCurrentRoute();
    });
  }

  canAuthorize(actionBy: string) {
    if (this.loggedInUser.toLowerCase() === actionBy?.toLowerCase() && this.isApprovRejectAccess) {
      return false;
    }
    else {
      return true;
    }
  }

  canRecall(actionBy: string) {
    if (this.loggedInUser.toLowerCase() === actionBy?.toLowerCase() || (!this.isApprovRejectAccess)) {
      return true;
    }
    else {
      return false;
    }
  }

  reloadCurrentRoute() {
    let currentUrl = this._router.url;
    this._router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this._router.navigate([currentUrl]);
    });
  }

  checkIPDAuthorisationStatus() {
    this._ipdAuthWorkflowService.getIpdAuthWorkflowStatus(this.dealId, this.ipdRunId).then((result) => {
      this.ipdStepDescription = result?.stepName;
    });
  }

  onChecked(codeName: string) {

  }

  getWorkflowType(type: string) {
    let workflowType: number;
    switch (type) {
      case 'Automated_Data_Daily_Collection':
        workflowType = AuthWorkflowType.Automated_Data_Daily_Collection;
        break;
      case 'Automated_Data_Collection_Ledger':
        workflowType = AuthWorkflowType.Automated_Data_Collection_Ledger;
        break;
      case 'Automated_Data_Interest_Rates':
        workflowType = AuthWorkflowType.Automated_Data_Interest_Rates;
        break;
        case 'Automated_Data_Cash_Ladder':
        workflowType = AuthWorkflowType.Automated_Data_Cash_Ladder;
        break;
    }
    return workflowType;
  }

  confirmBox(type: string) {

    let popupCfg = new CommonPopupConfigModel(`Reset`, `Do you want to revert your changes?`);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        if (type.includes('Adjustments_')) {
          this.resetAdjustment(type);
        }
        else if (type.includes('TriggersConditions_NonRating')) {
          this.resetNonRatingTrigger(type);
        }
        else if (type.includes('TriggersConditions_Conditions')) {
          this.resetConditionTestTrigger(type);
        }
        else
          this.reset(type);
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

  resetNonRatingTrigger(type: string) {


    this._nonRatingTriggerService.resetNontRatingTriggerData(this.dealId, this.ipdRunId).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.reloadCurrentRoute();
    });
  }

  resetConditionTestTrigger(type: string) {
    this._dealConditionTestService.resetDealConditionTestData(this.ipdRunId).subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, this._resetlMsg);
      this.reloadCurrentRoute();
    });
  }

  canOverrideIR(displayName : string) {
    if(displayName == 'Investor Report'){
      return true;
    }
    else{
      return false;
    }
  }

  openOverrideIRModal(type: string) {
    const modalRefPopUp = this._modalService.open(OverrideIrComponent, {
      backdrop: 'static',
      keyboard: false,
    });
    var overrideIRModel = new OverrideIRModalConfigModel(this.dealId, this.ipdSummarylineItems[0].ipdDate, this.ipdRunId);
    modalRefPopUp.componentInstance.overrideIRModalConfig = overrideIRModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.reloadCurrentRoute();
    });
  }

  downloadReconciliationFile(){
    this.isExcelFileDownloadStarted = true;

    this.ipdDate = this.datePipe.transform(this.ipdSummarylineItems[0].ipdDate, "yyyy-MM-dd")
    this.investorReportFileNameParams = new InvestorReportFileNameParams(this.dealId, this.ipdDate, "EXCEL");
    this._investoreReportService.getInvestorReportFileName(this.investorReportFileNameParams).subscribe(data => {
      let irFileName = JSON.parse(JSON.stringify(data))["fileName"];
      this._ipdProcessService.downloadIrReconciliationFile(irFileName).subscribe(blob => {
        if(blob == null){
          this._toastservice.openToast(ToasterTypes.error, "File not Found", "Reconciliation File is missing.");
          this.isExcelFileDownloadStarted = false; 
        return;
        }       
        let reconcileFileName = "Reconcile_"+ irFileName.toString().replace("Overrided_","");
        const a = document.createElement('a');
        const objectUrl = URL.createObjectURL(blob);
        a.href = objectUrl
        a.download = reconcileFileName;
        a.click();
        URL.revokeObjectURL(objectUrl);
        this._toastservice.openToast(ToasterTypes.success, this.title, "Reconciliation File Downloaded Successfully");
        
        this.isExcelFileDownloadStarted = false;
        this._ipdProcessService.deleteIrReconciliationFile(reconcileFileName).subscribe(blob => {

        });
      }, (error: any) => {
        console.log(error); 
        this.isExcelFileDownloadStarted = false;
       
      });

    });
    
  }

  
}