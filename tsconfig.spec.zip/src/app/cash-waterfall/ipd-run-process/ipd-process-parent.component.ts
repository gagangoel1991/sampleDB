import { Component, ViewEncapsulation, OnInit, ChangeDetectionStrategy } from '@angular/core';
import { SfpGridOptionsModel, SfpGridActionModel, CommonPopupConfigModel } from '../../shared/components/grid/sfp-gridOptions.model';
import { IpdProcessParentService } from './service/ipd-process-parent.service';
import { Router, ActivatedRoute, Params, NavigationEnd } from '@angular/router';
import { UserRoleService } from '../../../app/shared/services/user-role-service';
import { ToasterTypes, GlobalToasterService } from '../../shared/services/globaltoaster.service';
import { IpdAuthWorkflowService } from './service/ipd-auth-workflow-service'
import { SharedDataService } from '../../shared/services/shared-data.service';
import { PermissionEnum } from '../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../shared/model/user-permission-accesstype.enum';
import { AuthWorkflowStatusModel } from '../../shared/model/auth-workflow-status.model';
import { AuthWorkflowPopupComponent } from '../../shared/components/auth-workflow/auth-workflow-popup.component';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthModalConfigModel } from '../../shared/model/auth-modal-config.model';
import { DealDetailService } from './service/deal-detail.service';
import { IpdAdjustmentParams } from './model/cash-waterfall-line-item-model';
import { DealIpdBasicInfoModel } from './model/deal-ipd-basicinfo.model';
import { IpdManagementService } from '../ipd-management/service/ipd-management.service';
import { CommonPopupComponent } from '../../shared/components/confirm-common-popup/sfp-common-popup.component';
import { AuthWorkflowStep, AuthWorkflowType } from '../../shared/model/auth-workflow-enum';
import { TokenService } from 'src/app/shared/services/token.service';


@Component({
  selector: 'cw-ipd-flow',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './ipd-process-parent.component.html',
  styleUrls: ['./ipd-process-parent.component.scss'],
  providers: [IpdAuthWorkflowService, IpdManagementService, TokenService]
})

export class IpdProcessParentComponent implements OnInit {

  public tabIndex = -1;
  public cwtabIndex = -1;
  public tabLevel1Name: string;
  public tabLevel2Name: string;
  public title = 'Deal IPD Process';
  public dailyCollection: Array<any>;
  public isCompLoad: boolean;
  public dailyCollectionGridOptions: SfpGridOptionsModel;
  public dealGridActionLinks: Array<SfpGridActionModel> = [];
  public dealId: number;
  public ipdRunId: number;
  public menuItems: Array<any>;
  // public isAuthoriser: boolean = false;
  // public isUser: boolean = false;
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  public canAuthorize: boolean = true;
  public loggedInUser: string;
  public canRecall: boolean = false;
  public dealIpdAuthStatusModel: AuthWorkflowStatusModel;
  public ipdParams: IpdAdjustmentParams;
  public dealDetail: DealIpdBasicInfoModel;
  public buttonClicked: boolean = false;
  public runIpdButtonClicked: boolean = false;
  public irFileName: string = 'Not Generated';
  public runIpdBtnText: string = 'Run IPD';
  public dealName: string;

  private readonly _sendForAuthorisationMsg = "Ipd sent for authorisation";
  private readonly _recallMsg = "Ipd Recalled Successfully.";
  private readonly _ipdTostHeader = "Run IPD";
  private readonly _sendForAuthTostHeader = "Send for authorisation";
  private readonly _withdrawMsg = "Ipd Withdraw Successfully.";

  private readonly _resetIPDAlertMessage = `Are you sure you want to re-initiate/reset the IPD ? 
  This action will reset all manual inputs except Invoices and Ratings Upload.`;
  public resetIpdClicked: boolean;

  private Token: string;

  constructor(private _ipdProcessService: IpdProcessParentService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _toastservice: GlobalToasterService,
    private _userService: UserRoleService,
    private activatedRoute: ActivatedRoute,
    private _ipdAuthWorkflowService: IpdAuthWorkflowService,
    private _sharedDataService: SharedDataService,
    private _modalService: NgbModal,
    private _dealDetailService: DealDetailService,
    private router: Router,
    private _ipdManagementService: IpdManagementService,
    private _tokenService: TokenService
  ) {
    this.dealIpdAuthStatusModel = new AuthWorkflowStatusModel("", "", 0, "", "", "", "")
    this._router.events.subscribe(
      (event) => {
        if (event instanceof NavigationEnd) {
          var urlParams = this._router.url.split('/');
          if (urlParams.length > 6) {
            this.tabLevel2Name = urlParams[6]; //Fetching the sub-tab name
            console.log('Selected sub-tab-' + this.tabLevel2Name);
          }
        }
      });

    this._route.params.subscribe((params: Params) => {
      this.dealId = (params['dealId'] != null) ? params['dealId'] : null;
      this.ipdRunId = (params['ipdRunId'] != null) ? params['ipdRunId'] : null;
      this.tabLevel1Name = this._router.url.split('/')[5]; //Fetching the parent tab name 
      this.tabLevel2Name = this._router.url.split('/')[6]; //Fetching the sub-tab name
      console.log(this.tabLevel1Name);
      console.log(this.tabLevel2Name);

      //Calling the resolver service
      this.activatedRoute.data.subscribe(result => {
        console.log('Getting data from resolver service - ipd flow components');
        this.menuItems = result.data;
        var self = this;
        this.menuItems.forEach(function (menuItem) {
          if (menuItem.childMenu) {
            menuItem.childMenu.forEach(function (subMenuItem) {
              self.replaceRouterLinkParams(subMenuItem, self);
            });
          }
          if (menuItem.routerLink) {
            self.replaceRouterLinkParams(menuItem, self);
          }
        });

        //Setting the data for further use in the application
        this._userService.dealIpdMenuItems = this.menuItems;
        this._userService.changeMenuType('ipd');
        console.log(this._userService.dealIpdMenuItems);

        this._ipdProcessService.currentipdLevel1MenuName.subscribe(level1MenuName => this.tabLevel1Name = level1MenuName);
      });
    });
  }


  ngOnInit(): void {
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this.router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
      this.getTokens();
    });

    this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
      this.dealDetail = data;
      this.dealName = this.dealDetail.dealName;
    });



    this.checkAuthorisationStatus();
  }


  getTokens() {
    let Key = this._tokenService.createKey("btnRunIpd", [this.ipdParams.dealId, this.ipdParams.ipdRunId].map(String));
    this._tokenService.getToken(Key).subscribe(result => { this.Token = result; });
  }

  replaceRouterLinkParams(menuItem: any, selfThis: any) {
    var routerLink = menuItem.routerLink;
    routerLink = routerLink.replace('{0}', selfThis.dealId).replace('{1}', selfThis.ipdRunId);
    menuItem.routerLink = routerLink;
  }

  resetIPD() {
    this.resetIpdClicked = true;
    this._ipdManagementService.resetIPD(this.dealId, this.dealDetail.ipdDate).subscribe(res => {
      if (res == 1) {
        this.resetIpdClicked = false;
        this._toastservice.openToast(ToasterTypes.success, 'Reset IPD', 'IPD Reset Successfully.');
        this.reloadCurrentRoute();
      }
      else if (res == 112) {
        this.runIpdButtonClicked = false;
        this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Another IPD related process is running, please wait for sometime and try again.');
      }
      else {
        this.resetIpdClicked = false;
        this._toastservice.openToast(ToasterTypes.error, 'Reset IPD', 'IPD reset Failed.');
      }
    }, err => {
      this.resetIpdClicked = false;
    }, () => {
      this.resetIpdClicked = false;
    });
  }

  confirmBox() {
    let popupCfg = new CommonPopupConfigModel('Reset IPD', this._resetIPDAlertMessage);
    const modalRefDel = this._modalService.open(CommonPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefDel.componentInstance.popupConfig = popupCfg;

    modalRefDel.result.then(result => {
      console.log(result);
      if (result === 'confirmed') {
        this.resetIPD();
      }
      else if (result === 'cancel click') {
        console.log('Cancel popup clicked.')
      }
    });
  };

  runIpd() {
    this.runIpdButtonClicked = true;
    this.runIpdBtnText = 'Running IPD...'

    var Token = { [this._tokenService.TokenInfoKeyName]: this.Token };

    this._ipdProcessService.runIpd(this.dealId, this.ipdRunId, Token).subscribe((data) => {
      switch (data) {
        case 1:
          this._toastservice.openToast(ToasterTypes.success, this._ipdTostHeader, 'IPD run process is successfully completed, now generating the Investor Report');
          this.runIpdBtnText = 'Generating IR...'
          this._ipdProcessService.CreateIrFile(this.dealDetail.dealIrConfigId, this.dealDetail.ipdCollectionEndDate.toString(), this.dealDetail.buildIrTemplateId, this.ipdRunId, this.dealId).subscribe((isFile) => {
            if (isFile) {
              this.runIpdButtonClicked = false;
              this.reloadCurrentRoute();
              this._toastservice.openToast(ToasterTypes.success, this._ipdTostHeader, ' Investor Report is generated successfully');
            }
            else {
              this.runIpdButtonClicked = false;
              this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Error in file generation');
            }
          },
            err => {
              this.runIpdButtonClicked = false;
            }
          );
          break
        case 101:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Daily collection data has been edited, please reset the change or get it authorised.');
          break
        case 102:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Collection ledger data has been edited, please reset the change or get it authorised.');
          break
        case 103:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Interest rate data has been edited, please reset the change or get it authorised.');
          break
        case 104:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'IPD is already sent for authorisation, you cannot re-run the IPD.');
          break
        case 105:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'IPD is already authorised, you cannot re-run the IPD.');
          break
        case 106:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Invoice data has been modified, please re-run the IPD before sending for the authorisation.');
          break
        case 107:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Adjustment data has been modified, please re-run the IPD before sending for the authorisation.');
          break
        case 108:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Rating/Non rating trigger data has been modified, please re-run the IPD before sending for the authorisation.');
          break
        case 109:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Bond rating has been modified, please re-run the IPD before sending for the authorisation.');
          break
        case 110:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Counterparty rating has been modified, please re-run the IPD before sending for the authorisation.');
          break
        case 111:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Another IPD related process is running, please wait for sometime and try again.');
          break
        default:
          this.runIpdButtonClicked = false;
          this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'IPD run process failed.');
          break
      }

      this.getTokens();
    },
      err => {
        this.runIpdButtonClicked = false;
      }
    );
  }

  sendForAuthorisation() {
    var ipdCollectionEndDate = this._ipdProcessService.getDealIpdBasicInfoGlobalModelData().collectionEndDate;
    let today = new Date();
    today.setUTCHours(0, 0, 0, 0);
    let collectionEndDate = new Date(ipdCollectionEndDate);
    collectionEndDate.setUTCHours(0, 0, 0, 0);
    if (today > collectionEndDate) {
      this._ipdAuthWorkflowService.validateIPD(this.ipdRunId, AuthWorkflowStep.SendForAuthorisation).then((result) => {
        switch (result) {
          case 100:
            let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Deal_IPD, AuthWorkflowStep.SendForAuthorisation, this.dealId, this.ipdRunId);
            this.openModalPopup(model, this._sendForAuthorisationMsg);
            break;
          case 101:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'Daily collection data has been edited, please reset the change or get it authorised.');
            break
          case 1011:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'Daily collection data has been changed, please rerun the IPD.');
            break
          case 102:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'Collection ledger data has been edited, please reset the change or get it authorised.');
            break
          case 1021:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'Collection ledger data has been changed, please rerun the IPD.');
            break
          case 103:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'Interest rate data has been edited, please reset the change or get it authorised.');
            break
          case 1031:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'Interest rate data has been changed, please rerun the IPD.');
            break
          case 104:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'IPD is already sent for authorisation, you cannot re-run the IPD.');
            break
          case 105:
            this._toastservice.openToast(ToasterTypes.error, this._sendForAuthTostHeader, 'IPD is already authorised, you cannot re-run the IPD.');
            break
          case 106:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Invoice data has been modified, please re-run the IPD before sending for the authorisation.');
            break
          case 107:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Adjustment data has been modified, please re-run the IPD before sending for the authorisation.');
            break
          case 108:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Rating/Non rating trigger data has been modified, please re-run the IPD before sending for the authorisation.');
            break
          case 109:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Bond rating has been modified, please re-run the IPD before sending for the authorisation.');
            break
          case 110:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Counterparty rating has been modified, please re-run the IPD before sending for the authorisation.');
            break
          case 111:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Conditions/Tests has been modified, please re-run the IPD before sending for the authorisation.');
            break
          case 112:
            this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'Manual Fields has been modified, please re-run the IPD before sending for the authorisation.');
            break
        }
      });
    }
    else {
      this._toastservice.openToast(ToasterTypes.error, this._ipdTostHeader, 'You can not send Ipd for authorisation untill today date surpass the business collection end date.');
    }
  }

  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.Deal_IPD, AuthWorkflowStep.Recall, this.dealId, this.ipdRunId);
    this.openModalPopup(model, this._recallMsg);
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((result) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this.checkAuthorisationStatus();
      this.updateIpdStatus();
      this.reloadCurrentRoute();
    });
  }

  openAuthActionModal() {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });
    var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.Deal_IPD, AuthWorkflowStep.Approve_Reject, this.dealId, this.ipdRunId);
    modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this.checkAuthorisationStatus();
      this.updateIpdStatus();
      this.reloadCurrentRoute();
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userService.getCurrentLoginUser();
    // this.isAuthoriser = this._userService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.ApproveReject);
    // this.isUser = this._userService.getPermissionAccess(PermissionEnum.CW_AutomatedData, PermissionAccessTypeEnum.AddEdit);

    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
  }

  checkAuthorisationStatus() {
    this.setUpUserRolesAndPermissions();
    this._ipdAuthWorkflowService.getIpdAuthWorkflowStatus(this.dealId, this.ipdRunId).then((result) => {
      console.log('Deal Ipd Auth Status:');
      console.log(result);
      this._ipdProcessService.changeIpdWorkflowStatus(result.stepName);
      this.dealIpdAuthStatusModel = result;
      this.irFileName = result.irFileName;
      this.dealIpdAuthStatusModel.stepDescription = this.dealIpdAuthStatusModel?.stepDescription ? this.dealIpdAuthStatusModel.stepDescription : "Not Applicable";
      this.dealIpdAuthStatusModel.actionBy = this.dealIpdAuthStatusModel?.actionBy ? this.dealIpdAuthStatusModel.actionBy : "Not Applicable";
      this.dealIpdAuthStatusModel.actionDate = this.dealIpdAuthStatusModel?.actionDate ? this.dealIpdAuthStatusModel.actionDate : "Not Applicable";
      if (this.loggedInUser.toLowerCase() === this.dealIpdAuthStatusModel?.actionBy.toLowerCase() && this.isApprovRejectAccess) {
        this.canAuthorize = false;
      }
      if (this.loggedInUser.toLowerCase() === this.dealIpdAuthStatusModel?.actionBy.toLowerCase() || (!this.isApprovRejectAccess)) {
        this.canRecall = true;
      }
    });
  }


  updateIpdStatus() {
    this._dealDetailService.getDealDetailData(this.ipdParams).subscribe(data => {
      data.ipdStatus = this.dealIpdAuthStatusModel.stepDescription;
      data.authorisedBy = this.dealIpdAuthStatusModel.actionBy;
      data.authorisedDate = new Date(this.dealIpdAuthStatusModel.actionDate);
      data.comment = this.dealIpdAuthStatusModel.comment;
      this.dealDetail = data;
      this._ipdProcessService.setDealIpdBasicInfoGlobalModelData(this.dealDetail);
      this._ipdProcessService.DealIpdBasicInfoModelChanged.emit(this.dealDetail);
    }, (error: any) => {
      console.log(error);
    });
  }

  onIrDownload() {
    let reportPrefix: string = "";
    this.buttonClicked = true;



    if (this.dealIpdAuthStatusModel.stepDescription.toUpperCase() !== "Authorised".toUpperCase()) {
      reportPrefix = "Draft_";
    }

    let downloadFileName: string = this.irFileName;

    this._ipdAuthWorkflowService.downloadInvestorReport(downloadFileName).subscribe(blob => {

      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl
      a.download = reportPrefix + downloadFileName.toString().replace("Overrided_", "");
      a.click();

      URL.revokeObjectURL(objectUrl);
      this._toastservice.openToast(ToasterTypes.success, this.title, "Successfully Downloaded");
      this.buttonClicked = false;

    }, (error: any) => {
      this._toastservice.openToast(ToasterTypes.error, this.title, "Issue with download");
      this.buttonClicked = false;
    });

  }

  reloadCurrentRoute() {
    let currentUrl = this._router.url;
    this._router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
      this._router.navigate([currentUrl]);
    });
  }

  openWithdrawModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((result) => {
      if (result > 0) {
        //Success       
        this._toastservice.openToast(ToasterTypes.success, this.title, message);
        this._router.navigateByUrl('/', { skipLocationChange: true }).then(() => {
          this._router.navigate(['/cashwaterfall/ipdrunprocess/' + this.dealId + '/' + result + '/']);
        });
      }
      else if (result == -2) {
        this._toastservice.openToast(ToasterTypes.error, this.title, 'Speciified IPD is not authorised so you cannot withdraw this ipd.');
      }
      else if (result == -3) {
        this._toastservice.openToast(ToasterTypes.error, this.title, 'Deal is terminated.You can not withdraw ipd.');
      }
      else {
        this._toastservice.openToast(ToasterTypes.error, this.title, 'Ipd Withdraw failed.');
      }
    });
  }


  withdraw() {
    let model = new AuthModalConfigModel('Withdraw Confirmation!!', 'Withdraw with your comments', 'Comment is required.', AuthWorkflowType.Deal_IPD, AuthWorkflowStep.Withdraw, this.dealId, this.ipdRunId);
    this.openWithdrawModalPopup(model, this._withdrawMsg);

  }

  backIpdSummary() {
    this.router.navigate(['/cashwaterfall/ipdrunprocess/' + this.dealId + '/' + this.ipdRunId + '/']);
  }
}