import { Component, OnInit, ViewChild } from '@angular/core';
import { CashwaterfallLineItemModel, IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { AdjustmentWaterfallService } from '../../service/adjustment-waterfall.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';


@Component({
  selector: 'cw-ppp-output',
  templateUrl: './ppp-output.component.html',
  styleUrls: ['./ppp-output.component.scss'],
  providers: [AdjustmentWaterfallService]
})
export class PPPWaterfallOutputComponent implements OnInit {

  public dealId: number;
  public ipdRunId: number;
  public ipdParams: IpdAdjustmentParams;
  public title = 'Principal Priority of Payments Output';
  public pppLineItemList: Array<any> = [];

  public totalDueAmount: number = 0;
  public amountPaidFromSource_AvailablePrincipalReceipt: number = 0;
  public remainingDueAmountAfter_AvailablePrincipalReceipt: number = 0;
  public totalPaidAmount: number = 0;
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();




  constructor(private _ipdProcessService: IpdProcessParentService
    , private _adjustmentWaterfallService: AdjustmentWaterfallService
    , private _route: ActivatedRoute,
    private _router: Router) {
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._ipdProcessService.changeIpdLevel1MenuName('cashwaterfall_output');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this._adjustmentWaterfallService.getPrincipalWaterfallOutputData(this.ipdParams.dealId, this.ipdParams.ipdRunId).subscribe(data => {
      this.pppLineItemList = data;
      this.sumLineItemValue();
      document.getElementById('preloader').style['display'] = 'none';
    });
  }

  sumLineItemValue(): void {
    if (this.pppLineItemList.length > 0) {
      this.totalDueAmount = this.pppLineItemList.map(a => a.totalDueAmount).reduce(function (a, b) { return a + b; });
      this.amountPaidFromSource_AvailablePrincipalReceipt = this.pppLineItemList.map(a => Number(a.amountPaidFromSource_AvailablePrincipalReceipt)).reduce(function (a, b) { return Number(a) + Number(b); });
      this.remainingDueAmountAfter_AvailablePrincipalReceipt = this.pppLineItemList.map(a => a.remainingDueAmountAfter_AvailablePrincipalReceipt).reduce(function (a, b) { return a + b; });
      this.totalPaidAmount = this.pppLineItemList.map(a => a.totalPaidAmount).reduce(function (a, b) { return a + b; });
    }
  }
  exportToExcel() {

    this.exportHeaders.push(new HeaderCollectionModel('lineItem', 'Waterfall Line Item'));
    this.exportHeaders.push(new HeaderCollectionModel('totalDueAmount', 'Total-Required', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('isEligible_AvailablePrincipalReceipt', 'APR-Eligible'));
    this.exportHeaders.push(new HeaderCollectionModel('amountPaidFromSource_AvailablePrincipalReceipt', 'APR-Paid', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('remainingDueAmountAfter_AvailablePrincipalReceipt', 'ShortfallAfter-APR', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('totalPaidAmount', 'TOTAL PAID', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('remainingDueAmountAfter_AvailablePrincipalReceipt', 'Shortfall', 'currency'));
    
    let sourceData = JSON.parse(JSON.stringify(this.pppLineItemList)); //Deep Copy
    sourceData.map(x=>{
      x.isEligible_AvailablePrincipalReceipt = x.isEligible_AvailablePrincipalReceipt ? 'Yes' : 'No';            
    });

    var footerRow = {
      lineItem: "Total",
      totalDueAmount: this.totalDueAmount, 
      isEligible_AvailablePrincipalReceipt: "-",
      amountPaidFromSource_AvailablePrincipalReceipt: this.amountPaidFromSource_AvailablePrincipalReceipt,
      remainingDueAmountAfter_AvailablePrincipalReceipt: this.remainingDueAmountAfter_AvailablePrincipalReceipt,
      totalPaidAmount: this.totalPaidAmount
    }; 
    
    sourceData.push(footerRow);


    this.exportExcelUtility.exportDataToExcel(this.exportHeaders, sourceData, "Cashwaterfall-PrincipalPriorityOfPaymentsData.xlsx");
  
  }
}
