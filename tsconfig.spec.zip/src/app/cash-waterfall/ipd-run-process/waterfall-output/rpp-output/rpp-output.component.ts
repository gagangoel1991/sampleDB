import { Component, ElementRef, OnInit, QueryList, ViewChild, ViewChildren } from '@angular/core';
import { CashwaterfallLineItemModel, IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { AdjustmentWaterfallService } from '../../service/adjustment-waterfall.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgForm } from '@angular/forms';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { DealNameEnum } from 'src/app/shared/enum/deal-name-enum';


@Component({
  selector: 'cw-rpp-output',
  templateUrl: './rpp-output.component.html',
  styleUrls: ['./rpp-output.component.scss'],
  providers: [AdjustmentWaterfallService]
})
export class RPPWaterfallOutputComponent implements OnInit {

  public dealId: number;
  public ipdRunId: number;
  public ipdParams: IpdAdjustmentParams;
  public title = 'RPP Waterfall Output';
  public rppLineItemList: Array<any> = [];

  public totalDueAmount: number = 0;
  public amountPaidFromSource_AvailableRevenueReceipt: number = 0;
  public totalShortfallAfterAvailableRevenueReceipt: number = 0;
  public amountPaidFromSource_LiquidityReservedFund: number = 0;
  public totalShortfallAfterLiquidityReservedFund: number = 0;
  public amountPaidFromSource_GeneralReservedFund: number = 0;
  public totalShortfallAfterGeneralReservedFund: number = 0;
  public totalShortfallAfterAvailablePrincipalReceipt: number = 0;
  public amountPaidFromSource_AvailablePrincipalReceipt: number = 0;
  public totalPaidAmount: number = 0;
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public waterfalldealId: number = DealNameEnum.DEIMOS;

  @ViewChild('revenueoutputAdjustmentForm') revenueAdjustmentForm: NgForm;

  @ViewChildren('refTdEl') set ft(elements: QueryList<ElementRef>) {
    elements.forEach(refTdEl => {
      refTdEl.nativeElement.parentElement.style.height = refTdEl.nativeElement.getBoundingClientRect().height + 'px';
    });
  };

  constructor(private _ipdProcessService: IpdProcessParentService
    , private _adjustmentWaterfallService: AdjustmentWaterfallService
    , private _route: ActivatedRoute,
    private _router: Router) {
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._ipdProcessService.changeIpdLevel1MenuName('cashwaterfall_output');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
    });
  }

  ngOnInit(): void {
    this._adjustmentWaterfallService.getRevenueWaterfallOutputData(this.ipdParams.dealId, this.ipdParams.ipdRunId).subscribe(data => {
      this.rppLineItemList = data;
      console.log(this.rppLineItemList);
      this.setFormArray();
      this.sumLineItemValue();
      document.getElementById('preloader').style['display'] = 'none';
    });
  }
  sumLineItemValue(): void {
    if (this.rppLineItemList.length > 0) {
      console.log(this.rppLineItemList.filter(item => !item.isParent));
      this.totalDueAmount = this.rppLineItemList.filter(item => !item.isParent).map(a => a.totalDueAmount).reduce(function (a, b) { return a + b; });
      this.amountPaidFromSource_AvailableRevenueReceipt = this.rppLineItemList.filter(item => !item.isParent).map(a => Number(a.amountPaidFromSource_AvailableRevenueReceipt)).reduce(function (a, b) { return Number(a) + Number(b); });
      this.totalShortfallAfterAvailableRevenueReceipt = this.rppLineItemList.filter(item => !item.isParent).map(a => a.shortfallAfter_AvailableRevenueReceipt).reduce(function (a, b) { return a + b; });
      this.amountPaidFromSource_LiquidityReservedFund = this.rppLineItemList.filter(item => !item.isParent).map(a => a.amountPaidFromSource_LiquidityReservedFund).reduce(function (a, b) { return a + b; });
      this.totalShortfallAfterLiquidityReservedFund = this.rppLineItemList.filter(item => !item.isParent).map(a => a.shortfallAfter_LiquidityReservedFund).reduce(function (a, b) { return a + b; });
      this.amountPaidFromSource_GeneralReservedFund = this.rppLineItemList.filter(item => !item.isParent).map(a => a.amountPaidFromSource_GeneralReservedFund).reduce(function (a, b) { return a + b; });
      this.totalShortfallAfterGeneralReservedFund = this.rppLineItemList.filter(item => !item.isParent).map(a => a.shortfallAfter_GeneralReservedFund).reduce(function (a, b) { return a + b; });
      this.totalShortfallAfterAvailablePrincipalReceipt = this.rppLineItemList.filter(item => !item.isParent).map(a => a.shortfallAfter_AvailablePrincipalReceipt).reduce(function (a, b) { return a + b; });
      this.amountPaidFromSource_AvailablePrincipalReceipt = this.rppLineItemList.filter(item => !item.isParent).map(a => a.amountPaidFromSource_AvailablePrincipalReceipt).reduce(function (a, b) { return a + b; });
      this.totalPaidAmount = this.rppLineItemList.filter(item => !item.isParent).map(a => a.totalPaidAmount).reduce(function (a, b) { return a + b; });
    }
  }

  setFormArray() {
    this.rppLineItemList.forEach(x => {
      x.isRowVisible = !(x.isParent == 0 && x.parentWaterfallLineItemId > 0) ? true : false
    });
  }

  expandParentLineItem(isExpandable: boolean, parentWaterfallLineItemId: number) {
    let data = this.rppLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isParent == 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
    });

    data = this.rppLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isParent == 1);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
    });
  }

  exportToExcel() {

    this.exportHeaders.push(new HeaderCollectionModel('lineItem', 'Waterfall Line Item'));
    this.exportHeaders.push(new HeaderCollectionModel('totalDueAmount', 'Total-Required', 'currency'));

    this.exportHeaders.push(new HeaderCollectionModel('isEligible_AvailableRevenueReceipt', 'ARR-Eligible'));
    this.exportHeaders.push(new HeaderCollectionModel('amountPaidFromSource_AvailableRevenueReceipt', 'ARR-Paid', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('shortfallAfter_AvailableRevenueReceipt', 'ShortfallAfter-ARR', 'currency'));

    if (this.ipdParams.dealId == 14) {
      this.exportHeaders.push(new HeaderCollectionModel('isEligible_LiquidityReservedFund', 'LR-Eligible'));
      this.exportHeaders.push(new HeaderCollectionModel('amountPaidFromSource_LiquidityReservedFund', 'LR-Paid', 'currency'));
      this.exportHeaders.push(new HeaderCollectionModel('shortfallAfter_LiquidityReservedFund', 'ShortfallAfter-LR', 'currency'));
    }

    if (this.ipdParams.dealId != this.waterfalldealId) {
      this.exportHeaders.push(new HeaderCollectionModel('isEligible_GeneralReservedFund', 'GR-Eligible'));
      this.exportHeaders.push(new HeaderCollectionModel('amountPaidFromSource_GeneralReservedFund', 'GR-Paid', 'currency'));
      this.exportHeaders.push(new HeaderCollectionModel('shortfallAfter_GeneralReservedFund', 'ShortfallAfter-GR', 'currency'));

      this.exportHeaders.push(new HeaderCollectionModel('isEligible_AvailablePrincipalReceipt', 'APR-Eligible'));
      this.exportHeaders.push(new HeaderCollectionModel('amountPaidFromSource_AvailablePrincipalReceipt', 'APR-Paid', 'currency'));
      this.exportHeaders.push(new HeaderCollectionModel('shortfallAfter_AvailablePrincipalReceipt', 'ShortfallAfter-APR', 'currency'));
    }

    this.exportHeaders.push(new HeaderCollectionModel('totalPaidAmount', 'TOTAL PAID', 'currency'));
    this.exportHeaders.push(new HeaderCollectionModel('shortfall', 'Shortfall', 'currency'));

    let sourceData = JSON.parse(JSON.stringify(this.rppLineItemList)); //Deep Copy
    Object.keys(sourceData).map(
      function (object) {
        sourceData[object]["shortfall"] = sourceData[object]["totalDueAmount"] - sourceData[object]["totalPaidAmount"];

        sourceData[object]["isEligible_AvailableRevenueReceipt"] = sourceData[object]["isEligible_AvailableRevenueReceipt"] == 1 ? 'Yes' : 'No';
        sourceData[object]["isEligible_LiquidityReservedFund"] = sourceData[object]["isEligible_LiquidityReservedFund"] == 1 ? 'Yes' : 'No';
        sourceData[object]["isEligible_GeneralReservedFund"] = sourceData[object]["isEligible_GeneralReservedFund"] == 1 ? 'Yes' : 'No';
        sourceData[object]["isEligible_AvailablePrincipalReceipt"] = sourceData[object]["isEligible_AvailablePrincipalReceipt"] == 1 ? 'Yes' : 'No';
      });
    var footerRow = {
      lineItem: "Total",
      totalDueAmount: this.totalDueAmount,

      isEligible_AvailableRevenueReceipt: "-",
      amountPaidFromSource_AvailableRevenueReceipt: this.amountPaidFromSource_AvailableRevenueReceipt,
      shortfallAfter_AvailableRevenueReceipt: this.totalShortfallAfterAvailableRevenueReceipt,

      isEligible_LiquidityReservedFund: "-",
      amountPaidFromSource_LiquidityReservedFund: this.amountPaidFromSource_LiquidityReservedFund,
      shortfallAfter_LiquidityReservedFund: this.totalShortfallAfterLiquidityReservedFund,

      isEligible_GeneralReservedFund: "-",
      amountPaidFromSource_GeneralReservedFund: this.amountPaidFromSource_GeneralReservedFund,
      shortfallAfter_GeneralReservedFund: this.totalShortfallAfterGeneralReservedFund,

      isEligible_AvailablePrincipalReceipt: "-",
      amountPaidFromSource_AvailablePrincipalReceipt: this.amountPaidFromSource_AvailablePrincipalReceipt,
      shortfallAfter_AvailablePrincipalReceipt: this.totalShortfallAfterAvailablePrincipalReceipt,

      totalPaidAmount: this.totalPaidAmount,
      shortfall: this.totalDueAmount - this.totalPaidAmount,
    };
    sourceData.push(footerRow);

    this.exportExcelUtility.exportDataToExcel(this.exportHeaders, sourceData, "Cashwaterfall-RevenuePriorityOfPaymentsData.xlsx");

  }

  }
