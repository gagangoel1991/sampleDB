import { Component, OnInit, ViewChild } from '@angular/core';
import { CashwaterfallLineItemModel, IpdAdjustmentParams } from '../../model/cash-waterfall-line-item-model';
import { ChangeDetectorRef } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormArray, NgForm } from '@angular/forms';
import { IpdProcessParentService } from '../../service/ipd-process-parent.service';
import { AdjustmentWaterfallService } from '../../service/adjustment-waterfall.service';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NoteSummaryService } from '../../service/note-summary.service';
import { HeaderCollectionModel } from '../../model/deal-subloan.model';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';

@Component({
  selector: 'cw-apr-output',
  templateUrl: './apr-output.component.html',
  styleUrls: ['./apr-output.component.scss'],
  providers: [AdjustmentWaterfallService]
})
export class APRWaterfallOutputComponent implements OnInit {

  public dealId: number;
  public ipdRunId: number;
  public ipdParams: IpdAdjustmentParams;
  public title = 'APR Waterfall Output';
  public aprLineItemList: Array<CashwaterfallLineItemModel> = [];
  public sumRequired: number = 0;
  public sumAdjustment: number = 0;
  public sumTotalRequired: number = 0;
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();
  private readonly _sumRequireLineItemGroup = 'required';
  private readonly _sumAdjusmentLineItemGroup = 'adjustment';
  private readonly _sumTotalLineItemGroup = 'total';


  constructor(private _ipdProcessService: IpdProcessParentService
    , private _adjustmentWaterfallService: AdjustmentWaterfallService
    , private _route: ActivatedRoute,
    private _router: Router) {
    this.ipdParams = new IpdAdjustmentParams(0, 0, null);

    this._ipdProcessService.changeIpdLevel1MenuName('cashwaterfall_output');
    this._route.params.subscribe((params: Params) => {
      var values = this._ipdProcessService.getDealIdAndIpdRunId(this._router.url);
      this.ipdParams.dealId = (values) ? values[0] : null;
      this.ipdParams.ipdRunId = (values) ? values[1] : null;
      this.ipdParams.waterfallCategoryName = "PreAvailablePrincipalReceipts";
    });
  }

  ngOnInit(): void {
    this._adjustmentWaterfallService.getPrincipalWaterfallData(this.ipdParams).subscribe(data => {
      this.aprLineItemList = data;
      this.sumLineItemValue();
      this.setFormArray();
      document.getElementById('preloader').style['display'] = 'none';
    });
  }

  sumLineItemValue(): void {
    let data = this.aprLineItemList.filter(z => z.lineItem === 'Total');
    if (data.length > 0) {
      this.sumTotalRequired = data[0]["totalRequiredAmount"];
    }
  }

  
  sumLineItemGroupValue(parentWaterfallLineItemId: number, sumOf: string): number {

    let data = this.aprLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId);
    let sumGroupTotalRequired: number = 0;

    if (data.length > 0) {
      sumGroupTotalRequired = data.map(a => a.totalRequiredAmount).reduce(function (a, b) { return a + b; });
    }

    if (sumOf === this._sumTotalLineItemGroup)
      return sumGroupTotalRequired;
  }

  exportToExcel() {

    this.exportHeaders.push(new HeaderCollectionModel('lineItem', 'Waterfall Line Item'));
    this.exportHeaders.push(new HeaderCollectionModel('totalRequiredAmount', 'Current Period (EUR)', 'currency'));

    let sourceData = JSON.parse(JSON.stringify(this.aprLineItemList)); //Deep Copy

    Object.keys(sourceData).map(
      function (object) {
        if (sourceData[object]["isSubLineItems"] > 0) {
          let parentid = sourceData[object]["parentWaterfallLineItemId"];
          let data1 = sourceData.filter(x => x.isSubLineItems == 0 && x.parentWaterfallLineItemId == parentid);
          data1.forEach(element => {
            sourceData[object]["totalRequiredAmount"] = sourceData[object]["totalRequiredAmount"] + element.totalRequiredAmount
          });
        }
      });
    this.exportExcelUtility.exportDataToExcel(this.exportHeaders, sourceData, "Cashwaterfall-AvailablePrincipalReceiptsData.xlsx");
  }

  expandParentLineItem(isExpandable: boolean, parentWaterfallLineItemId: number) {
    let data = this.aprLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 0);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded
      x.isRowVisible = x.isExpanded ? true : false
    });

    data = this.aprLineItemList.filter(x => x.parentWaterfallLineItemId == parentWaterfallLineItemId && x.isSubLineItems == 1);
    data.forEach(x => {
      x.isExpanded = !x.isExpanded

    });
  }

  setFormArray() {
    this.aprLineItemList.forEach(x => {
      x.isRowVisible = !(x.isSubLineItems == 0 && x.parentWaterfallLineItemId > 0) ? true : false
    });
  }

}
