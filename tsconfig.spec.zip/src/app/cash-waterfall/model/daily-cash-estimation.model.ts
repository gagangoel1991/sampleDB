export class DailyCashEstimationModel {
    public isParent: number;
    public estimationType: string;
    public lineItem: string;
    public collectionDate: string;
    public brandName: string;
    public principal: string;
    public revenue: string;
    public total: string;
    public isExpanded?: boolean = false;
    public isRowVisible?: boolean = false;
}