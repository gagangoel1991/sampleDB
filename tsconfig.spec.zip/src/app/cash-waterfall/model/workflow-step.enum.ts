export enum WorkFlowStepEnum {
    Draft = 80,
    SendForReview = 81,
    Approved = 82,
    Rejected = 83,
    UserComment = 84,
    ReviewerComment =85

}