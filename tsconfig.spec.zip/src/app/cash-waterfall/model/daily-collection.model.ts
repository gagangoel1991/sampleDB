export class DailyCollectionModel{
    public collectionDate: string;
    public brand:string;
    public openingTrueBalance: string;
    public CustStatementBalance: string;
    public scheduledPrincipalReduction: string;
    public partialPrepayment: string;
    public overPayment: string;
    public redemptions: string;

    constructor(collectionDate:string, brand:string, openingTrueBalance: string, CustStatementBalance: string, 
        scheduledPrincipalReduction: string, partialPrepayment: string, 
        overPayment: string, redemptions: string){
        this.collectionDate = collectionDate;
        this.brand = brand;
        this.openingTrueBalance = openingTrueBalance;
        this.CustStatementBalance = CustStatementBalance;
        this.scheduledPrincipalReduction = scheduledPrincipalReduction;
        this.partialPrepayment = partialPrepayment;
        this.overPayment = overPayment;
        this.redemptions = redemptions;
    }
}