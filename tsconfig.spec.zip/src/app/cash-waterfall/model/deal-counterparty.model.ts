export class DealCounterpartyModel{
    public dealCounterpartyId: number;
    public dealId:number;
    public cisCode: string;
    public counterpartyName: string;

    constructor(dealCounterpartyId:number, dealId:number, cisCode: string, counterpartyName: string){
        this.dealCounterpartyId = dealCounterpartyId;
        this.dealId = dealId;
        this.cisCode = cisCode;
        this.counterpartyName = counterpartyName;
    }
}