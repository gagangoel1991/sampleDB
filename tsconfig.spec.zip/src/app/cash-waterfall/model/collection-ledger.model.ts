export class CollectionLedgerEditableGridColumnModel {
    public columnName: string;
    public displayName: string;
    public isEditable: boolean;
    public inputType: string;
    public filterText: string;
    public pipeFormatter: string;
    public isHiddenColumn = true;
    public isChecked = true;
    public errorMessage: string;


    constructor(columnName: string, displayName: string, isEditable: boolean, inputType: string, pipeFormatter: string,
        isHiddenColumn: boolean, isChecked: boolean, errorMessage: string) {
        this.columnName = columnName;
        this.displayName = displayName;
        this.isEditable = isEditable;
        this.inputType = inputType;
        this.pipeFormatter = pipeFormatter;
        this.isHiddenColumn = isHiddenColumn
        this.isChecked = (isChecked === false) ? false : this.isChecked;
        this.filterText = '';
        this.errorMessage = errorMessage;
    }
}

export class CollectionLedgerModel {
    public collectionLedgerId: number;
    public adviceDate?: Date;
    public collectionDate?: Date;
    public netPrincipalCollections: number;
    public financeCollections: number;
    public otherCollections: number;
    public totalDailyCashAmount: number;
    public modifiedBy: string;
    public modifiedDate?: Date;
    public reason: string;
    public dealIpdRunId?: number;


    constructor(collectionLedgerId: number, adviceDate: Date, collectionDate: Date, netPrincipalCollections: number,
        financeCollections: number, otherCollections: number, totalDailyCashAmount: number, modifiedBy: string, modifiedDate: Date,
        reason: string, dealIpdRunId?: number
    ) {
        this.collectionLedgerId = collectionLedgerId;
        this.adviceDate = adviceDate;
        this.collectionDate = collectionDate;
        this.netPrincipalCollections = netPrincipalCollections;
        this.financeCollections = financeCollections;
        this.otherCollections = otherCollections;
        this.totalDailyCashAmount = totalDailyCashAmount;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
        this.reason = reason;
        this.dealIpdRunId = dealIpdRunId;
    }
}