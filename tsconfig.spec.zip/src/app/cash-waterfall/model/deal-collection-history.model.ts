export class DealCollectionHistParam {
    asAtDate: Date;
    asAtToDate: Date;
    dealName: string;
    brandList: string[];    
}