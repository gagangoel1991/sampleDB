export class DealsumOutputsModel {
    public dealId : number;
    public collectionDate: Date;
    public lineItem: string;
    public value: string;
    public comments : string;
    public dailyCollectionSummaryId : number;
    public parentDailyCollectionLineItemId : number;
    public dailyCollectionLineItemId : number
    public parentWaterfallLineItemId?: number;
    public isSubLineItems: number;
    public isExpanded?: boolean = false;
    public isRowVisible?: boolean = false;
    public modifiedBy?: string;
    public modifiedDate?: string;
    public dailyCollectionCategory : string
    public adjustmentValue: number;
    public workFlowStepId: number;
    
    constructor(dealId : number,
        collectionDate: Date,
        lineItem: string,
        value: string,        
        comments :string,
        dailyCollectionSummaryId : number,
        parentDailyCollectionLineItemId : number,
        dailyCollectionLineItemId : number,
        parentWaterfallLineItemId : number,
        isSubLineItems : number,
        dailyCollectionCategory : string,
        isExpanded : boolean,
        isRowVisible : boolean,
        modifiedBy?: string,
        modifiedDate?: string,
        adjustmentValue? : number,
        workFlowStepId?: number
        ) {
        this.dealId = dealId;
        this.collectionDate = collectionDate;
        this.lineItem = lineItem;
        this.value = value;  
        this.comments =comments;  
        this.dailyCollectionSummaryId =dailyCollectionSummaryId;
        this.parentDailyCollectionLineItemId =parentDailyCollectionLineItemId;
        this.dailyCollectionLineItemId =dailyCollectionLineItemId;
        this.parentWaterfallLineItemId =parentWaterfallLineItemId;
        this.isSubLineItems =isSubLineItems;
        this.isExpanded =isExpanded;
        this.isRowVisible =isRowVisible;
        this.modifiedBy =modifiedBy;
        this.modifiedDate = modifiedDate;
        this.dailyCollectionCategory =dailyCollectionCategory
        this.adjustmentValue = adjustmentValue;
        this.workFlowStepId = workFlowStepId;
    }
}

export class DealSummaryDataModel
{
    public adviceDate : Array<string>;
    public dealName : string;
    public dealCategoryName : string;
    public viewType : string
}

export class DealSummarySaveAdjustmentModel
{
    public dailyCollectionSummaryId : number;
    public dailyCollectionLineItemId : number
    public value: string;
    public comments : string;
    public ModifiedBy : string
}


export class DealSummarySaveAuditModel
{
    public dailyCollectionSummaryId : number;
    public workflowStepId : number
    public comments : string;
    
}


export class DailyCollectionDealSummaryModel
{
    public dailyCollectionSummaryId : number;
    public collectionDate: Date;
    public workflowStepId : number
    public stepName : string;
    public modifiedBy: string;
    public nextIpd? : string;
    public previousIpd? : string;
    public collectionAdvicestartDate? : string;
    public collectionAdviceEndDate? : string;
    public rateReset? : string;
    public currentEuribor? : string;
    public dealSummaryMaxCollectionDate : Date;
    
}

export class DailyCollectionDatesExcel
{
    public dealName : string
    public adviceDate : string
    public AdviceDates : string[];
    public CollectionDates : string[];
    public isMultiDateList : boolean
    public viewType : string

}


export class DealSummaryAuditCollectionModel
{
    public collectionDate: Date;
    public workflowStepId : number;
    public dailyCollectionSummaryId : number;
    public modifiedBy: string;
    
}

export class DealSumEstimationHoverModel
{
    public netPrincipalCollection : string
    public revenueCollection : string
    public dailyCashMovement : string
}

