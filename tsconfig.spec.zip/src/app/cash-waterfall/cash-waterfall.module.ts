import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = { suppressScrollX: true };
import { DirectivesModule } from '../core/theme/directives/directives.module';
import { PipesModule } from '../core/theme/pipes/pipes.module';
import { routing } from './cash-waterfall.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { InvoiceManagementService } from 'src/app/cash-waterfall/invoice-management/service/invoice-management.service';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { CustomControlModule } from '../shared/modules/custom-control.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { InvoiceManagementListComponent } from './invoice-management/list/invoice-management-list.component';
import { ManageInvoiceComponent } from 'src/app/cash-waterfall/invoice-management/manage/manage-invoice.component';
import { IpdManagementComponent } from './ipd-management/ipd-management.component';
import { RatingUploadComponent } from './rating-upload/rating-upload/rating-upload.component';
import { RatingUploadListingComponent } from './rating-upload/rating-upload-listing/rating-upload-listing.component';
import { RatingViewComponent } from './rating-upload/rating-view/rating-view.component';
import { DashboardComponent } from './dashboard/dashboard.component';
import { AdhocDataloadComponent } from './adhoc-dataload/adhoc-dataload.component';
import { DailyCashEstimationComponent } from './deal-collections/daily-cash-estimation/daily-cash-estimation.component';
import { DealCollectionsComponent } from './deal-collections/deal-collections.component';
import { DealCollectionHistoryComponent } from './deal-collections/deal-collection-history/deal-collection-history.component';
import { CbOutputComponent } from './deal-collections/cb-output/cb-output.component';
import { DealsumOutputsComponent } from './deal-collections/deal-Summary/dealsum-outputs/dealsum-outputs.component';
import { DealsumAdjustmentsComponent } from './deal-collections/deal-Summary/dealsum-adjustments/dealsum-adjustments.component';
import { DealsumBreakupComponent } from './deal-collections/deal-Summary/dealsum-breakup/dealsum-breakup.component';
import { DealsumControlchecksandbalanceComponent } from './deal-collections/deal-Summary/dealsum-controlchecksandbalance/dealsum-controlchecksandbalance.component';
import { DealsumAuditComponent } from './deal-collections/deal-Summary/dealsum-audit/dealsum-audit.component';
import { RmbsPnrSplitComponent } from './deal-collections/rmbs-pnr-split/rmbs-pnr-split.component';
import { DealDailyCollectionsComponent } from './deal-collections/deal-daily-collections/deal-daily-collections.component';
import { MultiDatePickerComponent } from './deal-collections/deal-Summary/multi-date-picker/multi-date-picker.component';
import { IpdProcessModule } from './ipd-run-process/ipd-process.module';

@NgModule({
  imports: [
    CommonModule,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    MultiselectDropdownModule,
    routing,
    NgxDatatableModule,
    CustomControlModule,
    NgSelectModule,
    NgbModule,
    IpdProcessModule
  ],
  declarations: [
    InvoiceManagementListComponent,
    ManageInvoiceComponent,
    IpdManagementComponent,
    RatingUploadComponent,
    RatingUploadListingComponent,
    RatingViewComponent,
    DashboardComponent,
    AdhocDataloadComponent,
    DailyCashEstimationComponent,
    DealCollectionsComponent,
    DealCollectionHistoryComponent,
    CbOutputComponent,
    RmbsPnrSplitComponent,
    DealsumOutputsComponent,
    DealsumAdjustmentsComponent,
    DealsumBreakupComponent,
    DealsumControlchecksandbalanceComponent,
    DealsumAuditComponent,
	  MultiDatePickerComponent,	
    DealDailyCollectionsComponent
    
   ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    },
    InvoiceManagementService
  ]
})
export class CashWaterfallModule { }
