import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';
import { DealModel } from '../model/deal.model';
import { IAuthWorkflowModel } from '../../shared/model/auth-workflow-model';

@Injectable()
export class DealService {
  private readonly  currentAsset = window.localStorage.getItem('selectedAssetId');
  private _globalHttpService: GlobalHttpService;

  constructor(private globalHttpService: GlobalHttpService) {
    this._globalHttpService = globalHttpService;
  }

  public saveDeal(dealModel: DealModel): Observable<any> {
    return this.globalHttpService.PostRequest('/deal/saveDeal/' + this.currentAsset.toString(), dealModel);
  }

  public getDeal(dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest('/deal/getDeal/' + dealId);
  }


  public deleteDeal(dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest('/deal/delete/' + dealId);
  }

  public getSelectedList(listId: string): Observable<any> {
    return this.globalHttpService.GetRequest('/selectLookup/selectList/' + listId);
  }

  public getMultipleSelectedList(listTypes: Array<number>): Observable<any> {
    return this.globalHttpService.PostRequest('/selectLookup', listTypes);
  }

  public manageDealAuthWorkflow(model: IAuthWorkflowModel): Observable<any> {
    return this.globalHttpService.PostRequest('deal/ManageDealAuthWorkflow', model);
  }

  public manageDealAuthWorkflowByUser(model: IAuthWorkflowModel): Observable<any> {
    return this.globalHttpService.PostRequest('/deal/manageDealAuthWorkflowByUser', model);
  }

  public  postDealCollapseSentforAuthorization(dealModel: DealModel): Observable<any> {
    return this.globalHttpService.PostRequest('/deal/dealCollapseSentforAuthorization', dealModel);
  }

  public  getValidateDealForCollapse(dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest('/deal/getValidateDealForCollapse/' + dealId);
  }

  public  getDealLatestAuthorisedIpdDate(dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest('/deal/getDealLatestAuthorisedIpdDate/' + dealId);
  }



  

     
}
