import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { EmailConfigModel } from '../model/email-config.model';

@Injectable()
export class EmailConfigService {
  private _globalHttpService: GlobalHttpService;

  constructor(private globalHttpService: GlobalHttpService) {
    this._globalHttpService = globalHttpService; 
  }

  public getEmailConfigList(): Observable<any> {
    return this.globalHttpService.GetRequest('/email/getEmailConfigList', null);
  }

  public getEmailConfig(emailConfigId: number): Observable<any> {
    return this.globalHttpService.GetRequest(`/email/getEmailConfig/${emailConfigId}`);
  }
  public saveEmailConfig(emailConfigModel: EmailConfigModel): Observable<any> {
    return this.globalHttpService.PostRequest('/email/saveEmailConfig', emailConfigModel);
  }
  public deleteEmailConfig(emailConfigId: number): Observable<any> {
    return this.globalHttpService.GetRequest('/email/deleteEmailConfig/' + emailConfigId);
  }
   
}
