import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { IAuthWorkflowModel } from 'src/app/shared/model/auth-workflow-model';
import { DealNoteInformationModel } from '../model/deal-note-information.model';


@Injectable({
  providedIn: 'root'
})
export class DealNoteInformationService {

  constructor(private globalHttpService: GlobalHttpService) { }

  public getDealNoteInformationData(dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest(`/dealNote/getDealNoteList/${dealId}`);
  }

  public saveDealNoteInformationData(model: DealNoteInformationModel): Observable<any> {
    return this.globalHttpService.PostRequest(`/dealNote/saveDealNoteInformationData/`, model);
  }

  public  onDealNoteSentforAuthorization(model: DealNoteInformationModel): Observable<any> {
    return this.globalHttpService.PostRequest('/dealNote/dealNoteSentforAuthorization', model);
  }

  
}
