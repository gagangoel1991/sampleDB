import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';

@Injectable()
export class DealListService {
  private readonly  currentAsset = window.localStorage.getItem('selectedAssetId');
  private _globalHttpService: GlobalHttpService;

  constructor(private globalHttpService: GlobalHttpService) {
    this._globalHttpService = globalHttpService;
  }

  public getDealNames(): Observable<any> {
    return this.globalHttpService.GetRequest('/deal/getdeallist/' + this.currentAsset.toString(), null);
  }

  public deleteDeal(dealId: number): Observable<any> {
    return this.globalHttpService.GetRequest('/deal/delete/' + dealId);
  }


}
