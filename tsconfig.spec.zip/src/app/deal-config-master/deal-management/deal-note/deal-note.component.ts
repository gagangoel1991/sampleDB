import { DatePipe } from '@angular/common';
import { ConditionalExpr, ElementSchemaRegistry } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NgModel } from '@angular/forms';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DealIpdBasicInfoModel } from 'src/app/cash-waterfall/ipd-run-process/model/deal-ipd-basicinfo.model';
import { HeaderCollectionModel } from 'src/app/cash-waterfall/ipd-run-process/model/deal-subloan.model';
import { IpdProcessParentService } from 'src/app/cash-waterfall/ipd-run-process/service/ipd-process-parent.service';
import { AuthWorkflowPopupComponent } from 'src/app/shared/components/auth-workflow/auth-workflow-popup.component';
import { DealNameEnum } from 'src/app/shared/enum/deal-name-enum';
import { AuthModalConfigModel } from 'src/app/shared/model/auth-modal-config.model';
import { AuthWorkflowType } from 'src/app/shared/model/auth-workflow-enum';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import { DealNoteInformationModel } from '../../model/deal-note-information.model';
import { WorkFlowStepEnum } from '../../model/workflow-step.enum';
import { DealNoteInformationService } from '../../service/deal-note-information.service';

@Component({
  selector: 'sfp-deal-note',
  templateUrl: './deal-note.component.html',
  styleUrls: ['./deal-note.component.scss'],
  providers: [DealNoteInformationService, IpdProcessParentService]
})
export class DealNoteComponent implements OnInit {
  @ViewChild('dealNoteSendforAuthorization') dealNoteSendforAuthorization: any;
  @ViewChild('dealNoteApproveReject') dealNoteApproveReject: any;
  @ViewChild('dealNoteRecallSendforAuthorization') dealNoteRecallSendforAuthorization : any;
  public title: string = "Deal Note";
  public dealId: number;
  public ipdRunId: number;
  public dealNoteInformationModel: DealNoteInformationModel;
  public dealNoteWIPStatusModel: DealNoteInformationModel;
  public wipdealNoteInformationList: Array<DealNoteInformationModel> = [];
  public dealNoteList: Array<DealNoteInformationModel> = [];
  public exportDealNoteList: Array<DealNoteInformationModel> = [];
  public tempDealNoteList: Array<DealNoteInformationModel> = [];
  public editing = {};
  public isDataChangesAllow: boolean = true;
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private readonly _dealCondtionTestHeader = 'Deal Note';
  private readonly _dealCondtionTestMessage = "Deal Note Record updated successfully.";
  public isDealConditionHasValue: boolean = false;
  public dealDetail: DealIpdBasicInfoModel;
  public ipdDate;
  private datePipe = new DatePipe('en-UK');
  public workflowStepId: number;
  public actionSendForAuthorisationUpdateDeal: number;
  public actionRejectUpdateDeal: number;
  public actionAuthorisedUpdateDeal: number;
  public actionDraftUpdateDeal: number;
  public actionRecallUpdateDeal : number;
  public isAuthorizer: boolean = true;
  public canUpdate: boolean = false;
  public canView: boolean = false;
  public canDelete: boolean = false;
  public canAuthorized: boolean = false;
  public loggedInUser: string;
  public canSendRecallReset: boolean = false;
  private readonly _dealListNavPath = 'rt/dealconfig/deal';
  private readonly _dealNoteNameErrorMsg = 'Deal name should be unique.';
  private readonly _dealNoteErrorMsg = 'Something went wrong.';
  private readonly _dealNoteEarlyRedemptionErrorMsg = 'Please select Redemption Date.';
  private readonly _dealNoteAuthorisedEarlyRedemptionErrorMsg = 'The selected date is already authorised.Please select any other date.';
  public isRecallSet: boolean = false;
  public isActionBy : string;
  public isSendforAuth : boolean =false;


  constructor(private _ipdProcessService: IpdProcessParentService
    , private _userRoleService: UserRoleService
    , private _dealNoteInformationService: DealNoteInformationService
    , private _toastservice: GlobalToasterService
    , private _route: ActivatedRoute,
    private _router: Router,
    private _userService: UserRoleService,
    private _modalService: NgbModal) {
    this._ipdProcessService.changeIpdLevel1MenuName('triggers');

    this.dealNoteWIPStatusModel = new DealNoteInformationModel(0, 6, "", "", "","", "", "","", "", 0,false,"");

    this._route.params.subscribe((params: Params) => {
      this.dealId = (params['dealId'] != null) ? params['dealId'] : null;
    });

  }

  ngOnInit() {

    this.actionSendForAuthorisationUpdateDeal = WorkFlowStepEnum.SendForAuthorisationUpdateDeal;
    this.actionRejectUpdateDeal = WorkFlowStepEnum.RejectUpdateDeal;
    this.actionAuthorisedUpdateDeal = WorkFlowStepEnum.AuthorisedUpdateDeal;
    this.actionDraftUpdateDeal = WorkFlowStepEnum.Draft;
    this.actionRecallUpdateDeal = WorkFlowStepEnum.Recall;

    this.getloadDealNoteTest();
    this._ipdProcessService.currentIpdWorkflowStatus.subscribe(ipdStatus => {
      this.isDataChangesAllow = this._ipdProcessService.isIpdAllowDataChanges();
    });
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_DealIpdProcess], PermissionAccessTypeEnum.Delete);
        

    console.log('isDataChangesAllow ' + this.isDataChangesAllow);
    console.log('isReadOnlyAccess ' + this.isReadOnlyAccess);
    console.log('isAddEditAccess ' + this.isAddEditAccess);
    console.log('isApprovRejectAccess' + this.isApprovRejectAccess);
    console.log('isDeleteAccess ' + this.isDeleteAccess);
    
    this._ipdProcessService.DealIpdBasicInfoModelChanged.subscribe((data: DealIpdBasicInfoModel) => {
      this.dealDetail = data;
      this.ipdDate = this.datePipe.transform(this.dealDetail.ipdDate, 'yyyy-MM-dd');
      console.log(this.ipdDate);
    });

    if (this.dealId != null) {
      this.checkAuthorisationStatus(this.dealId);
    }


  }

  getloadDealNoteTest() {
    this.tempDealNoteList = []
    this.dealNoteList = [];

    this.wipdealNoteInformationList = [];
    this.workflowStepId = this.actionDraftUpdateDeal;
    this._dealNoteInformationService.getDealNoteInformationData(this.dealId).subscribe((data) => {
      console.log(data);
      this.dealNoteList = data;
      this.exportDealNoteList = JSON.parse(JSON.stringify(data));
      this.dealNoteList.forEach(obj => this.tempDealNoteList.push(Object.assign({}, obj)));
      this.dealNoteList.forEach(obj => this.wipdealNoteInformationList.push(Object.assign({}, obj)));

      console.log(this.dealNoteList);

      this.dealNoteList.filter(s => s.isActive).forEach(item => {
        if (item.dealStatusId > 0) {
            this.workflowStepId = item.dealStatusId;
        }        
        console.log('WorkflowstepID' + this.workflowStepId);       

      });

      let isValidSendforAuth = this.dealNoteList.filter( s =>s.dealStatusId !=0 && s.dealStatusId ==this.actionDraftUpdateDeal);

        if(isValidSendforAuth.length ==0 )
        {

          this.isSendforAuth =true;
        }
        else
        {
          this.isSendforAuth =false;
        }

        console.log(isValidSendforAuth)
        
      let isdealNoteList = this.dealNoteList.filter( p => p.modifiedDate != null)
      .sort((a, b)  =>
      (this.datePipe.transform(b.modifiedDate, "yyyy-MM-dd") 
      >this.datePipe.transform(a.modifiedDate, "yyyy-MM-dd")) ? 1 :-1 )[0];
      
          this.isActionBy =isdealNoteList.modifiedBy;         
       
      
    })

    document.getElementById('preloader').style['display'] = 'none';

  }


  // Save row
  save(rowIndex, name: string, isin: string, validFrom: string, validTo: string,maturityDate : string, earlyRedemptionDate: string,dealStatusId : number) {
    debugger;
    if (earlyRedemptionDate == null || earlyRedemptionDate == "") {
      earlyRedemptionDate = "";
      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNoteEarlyRedemptionErrorMsg);
    }
    else{    
      let model = new DealNoteInformationModel(rowIndex, 6, name, isin, validFrom, validTo, maturityDate,earlyRedemptionDate,"", "", dealStatusId,true,"");
      this.dealNoteWIPStatusModel = model;
      this.wipdealNoteInformationList.push(model);
      this._dealNoteInformationService.saveDealNoteInformationData(model).subscribe((data) => {
        if(data === -1)
        {
          this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNoteAuthorisedEarlyRedemptionErrorMsg);
          
        }
        else{        
        this._toastservice.openToast(ToasterTypes.success, this._dealCondtionTestHeader, this._dealCondtionTestMessage);
        this.getloadDealNoteTest();
        console.log(this.wipdealNoteInformationList);
        console.log(dealStatusId);
        }


        this.editing[rowIndex] = false;
      });
    }
  }

  // cancel row
  cancel(rowIndex: any) {
    this.editing[rowIndex] = false;
    this.dealNoteList = JSON.parse(JSON.stringify(this.tempDealNoteList));
  }


  // #region send for sendforauth/Recall
  sendForAuthorisation(workFlowStepId: number, savedMessage: string) {
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastservice.openToast(ToasterTypes.success, this.title, message);
      this._router.navigate([this._dealListNavPath]);
    });
  }

  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();
    console.log(this.loggedInUser);
    this.canView = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.View);
    this.canUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.AddEdit);
    this.canDelete = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.Delete);
    this.canAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.ApproveReject);
    console.log('canAuthorized' +this.canAuthorized);
    console.log('isAuthorizer' + this.isAuthorizer);
    console.log('canUpdate ' + this.canUpdate);
    console.log(this.workflowStepId);
  }

  checkAuthorisationStatus(dealId: number) {
    this.setUpUserRolesAndPermissions();
    this._dealNoteInformationService.getDealNoteInformationData(dealId).subscribe(result => {
      this.dealNoteInformationModel = result;
      this.dealNoteInformationModel.modifiedDate = this.datePipe.transform(this.dealNoteInformationModel.modifiedDate, 'yyyy-MM-dd');
      this.wipdealNoteInformationList.filter( s => s.isActive ).forEach( wipitem => {

         if(this.loggedInUser.toLowerCase() === wipitem.modifiedBy.toLowerCase()  && this.canAuthorized)
         {
          this.isAuthorizer = false;
         }    
         
         if (this.loggedInUser.toLowerCase() === wipitem.modifiedBy.toLowerCase() || (this.canUpdate && !this.canAuthorized)) {

          this.canSendRecallReset = true;
          }

      });
      console.log(this.canSendRecallReset );
      // }
    });
  }

  //Open Deal Note Pop up

  onDealNotePopUpModel() {
    this._modalService.open(this.dealNoteSendforAuthorization,
      { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
        if (result.toLowerCase() === 'approved') {
        } else if (result.toLowerCase() === 'reject') {
        } else {
          console.log('Collapse');
        }
      });
  }

  onDealNotePopUpRecallModel() {
    this._modalService.open(this.dealNoteRecallSendforAuthorization,
      { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
        if (result.toLowerCase() === 'approved') {

          //  this.saveDeal(this.actionApproved, 'Approved Successfully')
        } else if (result.toLowerCase() === 'reject') {
          // this.saveDeal(this.actionRejected, 'Rejected Successfully')
        } else {
          console.log('Collapse');
        }
      });
  }

  onDealNoteSentforAuthorization(workFlowStepId: number, savedMessage: string, irComment1: NgModel, modal: NgbActiveModal) {
    irComment1.control.markAsTouched();
    if (irComment1.control.status == "INVALID") {
      //     this._toastservice.openToast(ToasterTypes.error, this._CollapseErrorTitle, this._dealValidationMessage);
    }
    else {
      this.dealNoteWIPStatusModel.dealStatusId = workFlowStepId;
      this.workflowStepId = workFlowStepId;
      this.wipdealNoteInformationList.forEach(wipitem => {

        this.dealNoteList.forEach(item => {
          if (wipitem.dealNoteId = item.dealNoteId) {
            wipitem.dealStatusId = workFlowStepId;
            item.dealStatusId = workFlowStepId;
          }

        });
      });
      console.log(this.wipdealNoteInformationList);

      this._dealNoteInformationService.onDealNoteSentforAuthorization(this.dealNoteWIPStatusModel).subscribe(result => {
        if (result === 1) {

          this.workflowStepId = WorkFlowStepEnum.SendForAuthorisationUpdateDeal;
          this._toastservice.openToast(ToasterTypes.success, this.title, savedMessage);

          this._router.navigate([this._dealListNavPath]);
        }
        else if (result === 0) {
          this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNoteNameErrorMsg);
        }
        else {
          this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNoteErrorMsg);
        }
      });
      modal.close('cancel');
    }

  }

  onDealNoteApproveReject() {
    this._modalService.open(this.dealNoteApproveReject,
      { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
        if (result.toLowerCase() === 'approved') {
          //       this.saveDeal(workFlowStepId, savedMessage, false)
        } else if (result.toLowerCase() === 'reject') {
          //       this.saveDeal(this.actionRejected, 'Deal is rejected Successfully', false)
        } else {
          console.log('cancelled');
          //       this.dealModel.authorizerComment = "";
        }
      });
  }

  getRowClass = (row) => {
    var modifiedRow = this.dealNoteList.filter(x => x.dealNoteId == row?.dealNoteId);
    if (modifiedRow.length) {
      console.log(modifiedRow[0]['dealStatusId']);
      if (modifiedRow[0]['status'] == WorkFlowStepEnum.AuthorisedUpdateDeal) {
        return { 'cw-ngx-row-bg-authorised': true };
      }
      for (let key of Object.keys(row)) {
        if (modifiedRow[0][key] != row[key]) {
          return { 'cw-ngx-row-bg-color': true };
        }
      }
    }
  }



}
