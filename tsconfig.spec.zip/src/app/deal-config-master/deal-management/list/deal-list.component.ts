import { Component, ContentChild, OnInit } from '@angular/core';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { actionButtonFormatter, actionPermissionButtonFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter'
import { UserRoleService } from '../../../shared/services/user-role-service';
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { DealListService } from 'src/app/deal-config-master/service/deal-list.service';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';
import { DealListBtnCreateNewDirective, DealListGridDirective, DealListTitleDirective } from './deal-list.directive';

@Component({
  selector: 'cw-deal-list',
  providers: [DealListService],
  templateUrl: './deal-list.component.html',
  styleUrls: ['./deal-list.component.scss']
})
export class DealListComponent implements OnInit {

  @ContentChild(DealListTitleDirective) dealListTitleTemplate: DealListTitleDirective;
  @ContentChild(DealListBtnCreateNewDirective) dealListBtnCreateNewTemplate: DealListBtnCreateNewDirective;
  @ContentChild(DealListGridDirective) dealListGridTemplate: DealListGridDirective;

  public exportFileName = 'DealListData';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private readonly _editBuildDealNavPath = '../../dealconfig/deal/edit/';
  private readonly _copyBuildDealNavPath = '../../dealconfig/deal/copy/';
  private readonly _viewBuildDealNavPath = '../../dealconfig/deal/view/';

  private readonly _lockedRecordNotAllowedDeleteMsg = 'Deal Status is Active, you cannot delete this deal.';
  private readonly _lockedRecordNotAllowedDeleteMsgPendingAuth = 'Deal Status is Pending Authorisation, you cannot delete this deal.';
  private readonly _lockedRecordNotAllowedEditMsg = 'Deal Status is Active, you cannot edit this deal.';
  private readonly _toastTitle = 'Deal Management';
  private readonly _deletedMsg = 'Deal is deleted successfully.';

  //-------Slick Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  public slickDefaultAuditButtons: boolean = true;
  //-------Slick Variables End--------------

  constructor(private _dealListService: DealListService, private _router: Router, private _sharedDataService: SharedDataService,
    public _toastService: GlobalToasterService, private _route: ActivatedRoute, private _userRoleService: UserRoleService) { }

  ngOnInit(): void {
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.Delete);

    this.bindDealColumns();
    this.bindDealActionsCallBack();
    this.bindDealList();
  }

  bindDealColumns() {
    if (this.isAddEditAccess) {
      this.slickColumnArray.push(new SFP_SlickColumn('', 'Action', false, false, 110, FieldType.string,
        actionPermissionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 110))
    }
    this.slickColumnArray.push
      (
        new SFP_SlickColumn('dealName', 'Deal Name', true, true, 100, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('dealPublicName', 'Deal Public Name', true, true, 100, FieldType.string),
        new SFP_SlickColumn('description', 'Description', true, true, 100, FieldType.string),
        new SFP_SlickColumn('ownerName', 'Owner Name', true, true, 100, FieldType.string),
        new SFP_SlickColumn('businessArea', 'Business Area', true, true, 150, FieldType.string, undefined, SFP_SlickFilterType.multiSelect),
        new SFP_SlickColumn('dealType', 'Deal Type', true, true, 150, FieldType.string, undefined, SFP_SlickFilterType.multiSelect),
        new SFP_SlickColumn('dealStatus', 'Deal Status', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.singleSelect),
        new SFP_SlickColumn('closingDate', 'Closing Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('dealMaturityDate', 'Maturity Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('dealCurrency', 'Currency', true, true, 100, FieldType.string),
        new SFP_SlickColumn('jurisdictionMarker', 'Jurisdiction Marker', true, true, 100, FieldType.string),
        new SFP_SlickColumn('dealAccountingType', 'Accounting Type', true, true, 100, FieldType.string)
      );

      //SET EXPORT FILE NAME
      var myDt = new Date();
      var current_timestamp = myDt.getDate() +' '+ (myDt.toLocaleString('default', { month: 'short' })) +' '+  myDt.getFullYear();
      this.exportFileName = current_timestamp + '_Deal List';
  }

  bindDealList() {
    this._dealListService.getDealNames().subscribe(result => {
      this.slickDataset = JSON.parse(JSON.stringify(result)); //deep copy 
    });
  }

  bindDealActionsCallBack() {
    var objSFP_SlickAction = new SFP_SlickAction(
      this.onviewAction,
      this.onCopyAction,
      this.onEditAction,
      {
        deleteFunc: this.onDeleteAction,
        title: "Delete Deal Data confirmation",
        message: template`Are you sure you want to delete Deal data for \'${'dealName'}\'.`
      }
    );
    this.slickCallbackFuntions = objSFP_SlickAction;
  }



  //** Action Callback functions Start  */
  onviewAction(rowData: any, parentThis: any) {
    let dealId = rowData['dealId']
    parentThis._router.navigate([parentThis._viewBuildDealNavPath, dealId], { relativeTo: parentThis._route });
  }

  onCopyAction(rowData: any, parentThis: any) {
    let dealId = rowData['dealId']
    parentThis._router.navigate([parentThis._copyBuildDealNavPath, dealId], { relativeTo: parentThis._route });
  }
  onEditAction(rowData: any, parentThis: any) {
    let dealId = rowData['dealId']
    if (rowData.dealStatus == 'Active') {
      parentThis._toastService.openToast(ToasterTypes.error, parentThis._toastTitle, parentThis._lockedRecordNotAllowedEditMsg);
      return;
    }
    parentThis._router.navigate([parentThis._editBuildDealNavPath, dealId], { relativeTo: parentThis._route });
  }

  onDeleteAction(rowData: any, parentThis: any) {
    let dealId = rowData['dealId']

    if (rowData.dealStatus == 'Draft' || rowData.dealStatus == 'Rejected' ) {

      parentThis._dealListService.deleteDeal(dealId).subscribe(result => {
        if (result === -1) {//Locked record
          parentThis._toastService.openToast(ToasterTypes.error, parentThis._toastTitle, parentThis._lockedRecordNotAllowedDeleteMsg);
        }
        else {
          parentThis._toastService.openToast(ToasterTypes.success, parentThis._toastTitle, parentThis._deletedMsg);
          parentThis.bindDealList();
        }
      });
    }
    
    else{
      parentThis._toastService.openToast(ToasterTypes.error, parentThis._toastTitle, 'Deal Status is ' + rowData.dealStatus + ', you cannot delete this deal.');
      return;
    }

  }
  //** Action Callback functions End  */

  navigateToCreateDeal(): void {
    this._router.navigate(['../../dealconfig/deal/create'],{ relativeTo: this._route })
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  getDealListTitleTemplate() {
    return this.dealListTitleTemplate?.template;
  }
  getDealListBtnCreateTemplate() {
    return this.dealListBtnCreateNewTemplate?.template;
  }
  getDealListGridTemplate() {
    return this.dealListGridTemplate?.template;
  }

}
