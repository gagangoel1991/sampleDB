import { Directive, TemplateRef } from '@angular/core';


@Directive({selector :'[dealListTitle]'})
export class DealListTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[dealListBtnCreateNewDirective]'})
export class DealListBtnCreateNewDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[dealListGridDirective]'})
export class DealListGridDirective{
    constructor(public template:TemplateRef<any>){}
}

