import { Directive, TemplateRef } from '@angular/core';

@Directive({selector : '[manageDealFields]'})
export class ManageDealFieldsDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealTitle]'})
export class ManageDealTitleDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealStatus]'})
export class ManageDealStatusDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealActionBy]'})
export class ManageDealActionByDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealActionDate]'})
export class ManageDealActionDateDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealName]'})
export class ManageDealNameDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealPublicName]'})
export class ManageDealPublicNameDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealDescription]'})
export class ManageDealDescriptionDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealOwner]'})
export class ManageDealOwnerDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealAssetType]'})
export class ManageDealAssetTypeDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealType]'})
export class ManageDealTypeDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealCurrency]'})
export class ManageDealCurrencyDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealJurisMarker]'})
export class ManageDealJurisMarkerDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealAdvancesAutoFlag]'})
export class ManageDealAdvancesAutoFlagDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealTransferAutoFlag]'})
export class ManageDealTransferAutoFlagDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealMortgageAutoFlag]'})
export class ManageDealMortgageAutoFlagDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealAccountingFlag]'})
export class ManageDealAccountingFlagDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealIpdFrequency]'})
export class ManageDealIpdFrequencyDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealClosingDt]'})
export class ManageDealClosingDtDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealMaturityDt]'})
export class ManageDealMaturityDtDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealIpdDt]'})
export class ManageDealIpdDtDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealCollectionDt]'})
export class ManageDealCollectionDtDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealRedactedIds]'})
export class ManageDealRedactedIdsDirective {
    constructor(public template: TemplateRef<any>) {}
}


@Directive({selector : '[manageDealCashReporting]'})
export class ManageDealCashReportingDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealDealInitialSize]'})
export class ManageDealInitialSizeDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealTopupEndDate]'})
export class ManageDealTopupEndDateDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealTopupFlag]'})
export class ManageDealTopupFlagDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealRiskRetentionPercent]'})
export class ManageDealRiskRetentionPercentDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealRiskRetentionMethod]'})
export class ManageDealRiskRetentionMethodDirective {
    constructor(public template: TemplateRef<any>) {}
}
@Directive({selector : '[manageDealRiskRetentionHolder]'})
export class ManageDealRiskRetentionHolderDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealRonaCalculatedBasedOn]'})
export class ManageDealRonaCalculatedBasedOnDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealFxRateDate]'})
export class ManageDealFxRateDateDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealFacilitySharingAllowed]'})
export class ManageDealFacilitySharingAllowedDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealEnableHistoricFlagging]'})
export class ManageDealEnableHistoricFlaggingDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealFacilityPercentChangeAllowed]'})
export class ManageDealFacilityPercentChangeAllowedDirective {
    constructor(public template: TemplateRef<any>) {}
}

@Directive({selector : '[manageDealLegalRetentionPercent]'})
export class ManageDealLegalRetentionPercentDirective {
    constructor(public template: TemplateRef<any>) {}
}