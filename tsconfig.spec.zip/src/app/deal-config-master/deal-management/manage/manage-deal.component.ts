import { Component, OnInit, ViewEncapsulation, ViewChild, ContentChild, EventEmitter, Output } from '@angular/core';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { NgForm, NgModel } from '@angular/forms';
import { DealService } from "../../service/manage-deal.service";
import { DealModel } from '../../model/deal.model';
import { GlobalToasterService, ToasterTypes } from '../../../shared/services/globaltoaster.service';
import { SelectLookupModel, SelectListEnum } from 'src/app/cash-waterfall//model/select-lookup.model';
import { WorkFlowStepEnum } from '../../model/workflow-step.enum';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { UserPermissionModel } from 'src/app/shared/model/user-permission.model';
import { UserModel } from 'src/app/shared/home/user.model';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';
import { NgbActiveModal, NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { DatePipe, JsonPipe } from '@angular/common';
import { SFP_SlickGridUtility } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';
import { AuthWorkflowType, AuthWorkflowStep } from 'src/app/shared/model/auth-workflow-enum';
import { AuthWorkflowPopupComponent } from '../../../shared/components/auth-workflow/auth-workflow-popup.component';
import { AuthModalConfigModel } from '../../../shared/model/auth-modal-config.model';
import { IpdManagementService } from 'src/app/cash-waterfall/ipd-management/service/ipd-management.service';
import { DealIpdModel } from '../../model/deal-list.model';
import { ManageDealAccountingFlagDirective, ManageDealActionByDirective, ManageDealActionDateDirective, ManageDealAdvancesAutoFlagDirective, ManageDealAssetTypeDirective, ManageDealCashReportingDirective, ManageDealClosingDtDirective, ManageDealCollectionDtDirective, ManageDealCurrencyDirective, ManageDealDescriptionDirective, ManageDealEnableHistoricFlaggingDirective, ManageDealFacilityPercentChangeAllowedDirective, ManageDealFacilitySharingAllowedDirective, ManageDealFieldsDirective, ManageDealFxRateDateDirective, ManageDealInitialSizeDirective, ManageDealIpdDtDirective, ManageDealIpdFrequencyDirective, ManageDealJurisMarkerDirective, ManageDealLegalRetentionPercentDirective, ManageDealMaturityDtDirective, ManageDealMortgageAutoFlagDirective, ManageDealNameDirective, ManageDealOwnerDirective, ManageDealPublicNameDirective, ManageDealRedactedIdsDirective, ManageDealRiskRetentionHolderDirective, ManageDealRiskRetentionMethodDirective, ManageDealRiskRetentionPercentDirective, ManageDealRonaCalculatedBasedOnDirective, ManageDealStatusDirective, ManageDealTitleDirective, ManageDealTopupEndDateDirective, ManageDealTopupFlagDirective, ManageDealTransferAutoFlagDirective, ManageDealTypeDirective } from './manage-deal.directive';


@Component({
    selector: 'sfp-deal-create',
    encapsulation: ViewEncapsulation.Emulated,
    templateUrl: 'manage-deal.component.html',
    styleUrls: ['./manage-deal.component.scss'],
    providers: [DealService, IpdManagementService]
})

export class ManageDealComponent implements OnInit {

    @Output() onLoadDealModelParentEvent = new EventEmitter<any>();

    @ContentChild(ManageDealFieldsDirective) dealFieldsTemplate: ManageDealFieldsDirective;
    @ContentChild(ManageDealTitleDirective) dealTitleTemplate: ManageDealTitleDirective;
    @ContentChild(ManageDealStatusDirective) dealStatusemplate: ManageDealStatusDirective;
    @ContentChild(ManageDealActionByDirective) dealActionByTemplate: ManageDealActionByDirective;
    @ContentChild(ManageDealActionDateDirective) dealActionDateTemplate: ManageDealActionDateDirective;
    @ContentChild(ManageDealNameDirective) dealNameTemplate: ManageDealNameDirective;
    @ContentChild(ManageDealPublicNameDirective) dealPublicNameTemplate: ManageDealPublicNameDirective;
    @ContentChild(ManageDealDescriptionDirective) dealDescriptionTemplate: ManageDealDescriptionDirective;
    @ContentChild(ManageDealOwnerDirective) dealOwnerTemplate: ManageDealOwnerDirective;
    @ContentChild(ManageDealAssetTypeDirective) dealAssetTypeTemplate: ManageDealAssetTypeDirective;
    @ContentChild(ManageDealTypeDirective) dealTypeTemplate: ManageDealTypeDirective;
    @ContentChild(ManageDealCurrencyDirective) dealCurrencyTemplate: ManageDealCurrencyDirective;
    @ContentChild(ManageDealJurisMarkerDirective) dealJurisMarkerTemplate: ManageDealJurisMarkerDirective;
    @ContentChild(ManageDealAdvancesAutoFlagDirective) dealAdvancesAutoFlagTemplate: ManageDealAdvancesAutoFlagDirective;
    @ContentChild(ManageDealTransferAutoFlagDirective) dealTransferAutoFlagTemplate: ManageDealTransferAutoFlagDirective;
    @ContentChild(ManageDealMortgageAutoFlagDirective) dealMortgageAutoFlagTemplate: ManageDealMortgageAutoFlagDirective;
    @ContentChild(ManageDealAccountingFlagDirective) dealAccountingFlagTemplate: ManageDealAccountingFlagDirective;
    @ContentChild(ManageDealIpdFrequencyDirective) dealIpdFrequencyTemplate: ManageDealIpdFrequencyDirective;
    @ContentChild(ManageDealClosingDtDirective) dealClosingDtTemplate: ManageDealClosingDtDirective;
    @ContentChild(ManageDealMaturityDtDirective) dealMaturityDtTemplate: ManageDealMaturityDtDirective;
    @ContentChild(ManageDealIpdDtDirective) dealIpdDtTemplate: ManageDealIpdDtDirective;
    @ContentChild(ManageDealCollectionDtDirective) dealCollectionDtTemplate: ManageDealCollectionDtDirective;
    @ContentChild(ManageDealRedactedIdsDirective) dealRedactedIdsTemplate: ManageDealRedactedIdsDirective;
    @ContentChild(ManageDealCashReportingDirective) dealCashReportingTemplate: ManageDealCashReportingDirective;
    @ContentChild(ManageDealInitialSizeDirective) dealInitialSizeTemplate: ManageDealInitialSizeDirective;
    @ContentChild(ManageDealTopupEndDateDirective) dealTopupEndDateTemplate: ManageDealTopupEndDateDirective;
    @ContentChild(ManageDealTopupFlagDirective) dealTopupFlagTemplate: ManageDealTopupFlagDirective;
    @ContentChild(ManageDealRiskRetentionPercentDirective) dealRiskRetentionPercentTemplate: ManageDealRiskRetentionPercentDirective;
    @ContentChild(ManageDealRiskRetentionMethodDirective) dealRiskRetentionMethodTemplate: ManageDealRiskRetentionMethodDirective;
    @ContentChild(ManageDealRiskRetentionHolderDirective) dealRiskRetentionHolderTemplate: ManageDealRiskRetentionHolderDirective;
    @ContentChild(ManageDealRonaCalculatedBasedOnDirective) dealRonaCalculatedBasedOnTemplate: ManageDealRonaCalculatedBasedOnDirective;
    @ContentChild(ManageDealFxRateDateDirective) dealFxRateDateTemplate: ManageDealFxRateDateDirective;
    @ContentChild(ManageDealFacilitySharingAllowedDirective) dealFacilitySharingAllowedTemplate: ManageDealFacilitySharingAllowedDirective;
    @ContentChild(ManageDealEnableHistoricFlaggingDirective) dealEnableHistoricFlaggingTemplate: ManageDealEnableHistoricFlaggingDirective;
    @ContentChild(ManageDealFacilityPercentChangeAllowedDirective) dealFacilityPercentChangeAllowedTemplate: ManageDealFacilityPercentChangeAllowedDirective;
    @ContentChild(ManageDealLegalRetentionPercentDirective) dealLegalRetentionPercentTemplate: ManageDealLegalRetentionPercentDirective;


    @ViewChild('dealForm') confirmUnsavedForm: NgForm;
    @ViewChild('collapseDeal') collapseDeal: any;
    @ViewChild('collapseDealClose') collapseDealClose: any;
    @ViewChild('collapseDealConfirmation') collapseDealConfirmation: any;
    @ViewChild('collapseDealConfirmationCollapse') collapseDealConfirmationCollapse: any;
    @ViewChild('terminateDeal') terminateDeal: any;
    @ViewChild('terminateDealConfirmation') terminateDealConfirmation: any;
    @ViewChild('terminateDealConfirmationCollapse') terminateDealConfirmationCollapse: any;

    public title: string;
    public dealModel: DealModel;
    public dealunsavedModel: DealModel;
    public dealsaved: DealModel;
    public dealId: number;
    public dealAction: string;
    public actionType: string = '';

    public workflowStepId: number;
    public actionApproved: number;
    public actionDraft: number;
    public actionRejected: number;
    public actionSendForAuthorization: number;
    public actionRecall: number;
    public actionCollapse: number;
    public actionTerminate: number;
    public actionSendForAuthorizationCollapse: number;
    public actionSendForAuthorizationTerminate: number;
    public actionCollapseReject: number;
    public actionTerminateReject: number;
    public loggedInUser: string;
    public canSendRecallReset: boolean = false;
    public userPermissionsOnIrConfig: UserPermissionModel[];
    public userDetail: UserModel;
    public comment: string;
    public isAuthorizer: boolean = true;
    public canUpdate: boolean = false;
    public canView: boolean = false;
    public canDelete: boolean = false;
    public canAuthorized: boolean = false;
    private datePipe = new DatePipe('en-UK');
    public redemptionDate: string;
    public riskRetentionPercentage: number = null;
    public legalRetentionPercentage: number = null;
    public dealIpdList: Array<DealIpdModel> = [];

    private readonly _addDealTitle = 'New Deal';
    private readonly _editDealTitle = 'Edit Deal';
    private readonly _copyDealTitle = 'Copy Deal';
    private readonly _viewDealTitle = 'View Deal';
    private readonly _dealActionAdd = 'create';
    private readonly _dealActionEdit = 'edit';
    private readonly _dealActionCopy = 'copy';
    private readonly _dealActionView = 'view';
    private readonly _invalidAction = 'invalid';
    private readonly _InvalidActionTitle = 'Resource is not available';
    private readonly _dealValidationMessage = 'Please fill all required values.';
    private readonly _dealRedactedValidationnMessage = 'Please fill Redacted Facility Ids.';
    private readonly _dealNotExist = 'Deal record is not exist.';
    public _dealListNavPath = '/rt/dealconfig/deal';
    private readonly _dealtitleName = 'Deal Management';
    //   private readonly _dealSuccessMsg = 'Deal saved successfully.';
    private readonly _savedMsg = 'Deal is saved successfully.';
    private readonly _editMsg = 'Deal is updated successfully.';
    private readonly _savedAmendMsg = 'Minor Amendment success.';

    private readonly _dealErrorMsg = 'Something went wrong.';
    private readonly _dealNameErrorMsg = 'Deal name should be unique.';
    private readonly _noDealErrorMsg = 'No deal found.';
    private readonly _dealAuthorisedLoanErrorMsg = 'All loans need to be repurchased before collapse of deal.';
    private readonly _commentErrorMsg = 'Comment is required.';
    private readonly _dealTerminateErrorMsg = 'Deal cannot be terminated until last IPD is authorised.';
    private readonly _CollapseErrorTitle = "Collapse Deal"
    private readonly _CollapseErrorNoDeal = "This deal cannot be Collapsed.";
    private readonly _valueChangeMessage = "You have not changed any value.";
    @ViewChild('dealForm') dealForm: NgForm;
    public assetTypeList: Array<SelectLookupModel> = [];
    public isReadOnlyAccess: boolean = false;
    public isAddEditAccess: boolean = false;
    public isApprovRejectAccess: boolean = false;
    public isDeleteAccess: boolean = false;
    public minerAmendmentClicked: boolean = false;
    public notAllowMinerAmendment: boolean = true;
    dealTypeList: Array<SelectLookupModel> = [];
    ipdFrequencyList: Array<SelectLookupModel> = [];
    jurisdictionList: Array<SelectLookupModel> = [];
    furtherAdvancesAutoTopUpFlagList: Array<SelectLookupModel> = [];
    balanceTransferAutoTopUpFlagList: Array<SelectLookupModel> = [];
    mortgageAutoTopUpFlagList: Array<SelectLookupModel> = [];
    dealAccountingTypeList: Array<SelectLookupModel> = [];
    dealCurrencyList: Array<SelectLookupModel> = [];
    cashReportingList: Array<SelectLookupModel> = [];
    replenishableList: Array<SelectLookupModel> = [];
    riskRetentionMethodList: Array<SelectLookupModel> = [];
    riskRetentionHolderList: Array<SelectLookupModel> = [];
    businessAreaAssetClassMapList: Array<SelectLookupModel> = [];
    ronaBasedOnList: Array<SelectLookupModel> = [];
    facilitySharingAllowedList: Array<SelectLookupModel> = [];
    historicalFlaggingAllowedList: Array<SelectLookupModel> = [];
    facilityPercentChangeAllowedList: Array<SelectLookupModel> = [];

    private readonly _lockedStatus = 'Locked'
    private readonly _authorisedStatus = 'Active'
    private isRecordLocked: boolean = false;
    private defaultBusinessAreaId: boolean = false;


    constructor(private _dealService: DealService, private _toastservice: GlobalToasterService,
        private _userRoleService: UserRoleService,
        private _modalService: NgbModal,
        private _route: ActivatedRoute,
        private _router: Router,
        private _sharedDataService: SharedDataService,
        private _ipdManagementService: IpdManagementService) {
        this.showHideLoadingImage(false);

        this._route.params.subscribe((params: Params) => {
            this.dealId = (params['dealId'] != null) ? params['dealId'] : null;
            this.dealAction = this._router.url.split('/')[4];

            switch (this.dealAction) {
                case this._dealActionAdd:
                    this.title = this._addDealTitle;
                    this.actionType = this._dealActionAdd;
                    this.addDealInitialize();
                    break;
                case this._dealActionEdit:
                    this.title = this._editDealTitle;
                    this.actionType = this._dealActionEdit;
                    this.editCopyViewDealInitialize(this.dealId);
                    break;
                case this._dealActionCopy:
                    this.title = this._copyDealTitle;
                    this.actionType = this._dealActionCopy;
                    this.editCopyViewDealInitialize(this.dealId);
                    break;
                case this._dealActionView:
                    this.title = this._viewDealTitle;
                    this.actionType = this._dealActionView;
                    this.editCopyViewDealInitialize(this.dealId);
                    break;
                default:
                    this.title = this._InvalidActionTitle;
                    this.actionType = this._invalidAction;
            }
        });
    }

    ngOnInit() {

        this.actionDraft = WorkFlowStepEnum.Draft;
        this.actionSendForAuthorization = WorkFlowStepEnum.SendForAuthorization;
        this.actionApproved = WorkFlowStepEnum.Approved;
        this.actionRejected = WorkFlowStepEnum.Rejected;
        this.actionRecall = WorkFlowStepEnum.Recall;
        this.actionCollapse = WorkFlowStepEnum.Collapse;
        this.actionTerminate = WorkFlowStepEnum.Terminate;
        this.actionSendForAuthorizationCollapse = WorkFlowStepEnum.SendForAuthorisationCollapse;
        this.actionSendForAuthorizationTerminate = WorkFlowStepEnum.SendForAuthorisationTerminate;
        this.actionCollapseReject = WorkFlowStepEnum.CollapseReject;
        this.actionTerminateReject = WorkFlowStepEnum.TerminateReject;
        this.workflowStepId = 0;

        this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.View);
        this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.AddEdit);
        this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.ApproveReject);
        this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.Delete);

        if (this.dealId != null) {
            this.checkAuthorisationStatus(this.dealId);
        }
    }

    editCopyViewDealInitialize(dealId: number) {
        this.dealModel = new DealModel();
        this._dealService.getDeal(dealId).subscribe(result => {
            if (result) {
                this.dealModel = result;
                if (this.dealModel.riskRetentionPercent != null) {
                    this.riskRetentionPercentage = this.dealModel.riskRetentionPercent * 100;
                }
                if (this.dealModel.legalRetentionPercent != null) {
                    this.legalRetentionPercentage = this.dealModel.legalRetentionPercent * 100;
                }
                if (this.dealModel.dealStatus === this._lockedStatus ||
                    this.dealModel.dealStatus === this._authorisedStatus) {
                    this.isRecordLocked = true;
                    this.notAllowMinerAmendment = false;
                }

                if (this.canUpdate == true && this.actionType == 'view' && this.isRecordLocked == false) {
                    this.actionType = 'edit';
                    this.title = this._editDealTitle;
                }


                this.comment = this.dealModel.authorizerComment;
                this.workflowStepId = this.dealModel.dealStatusId;
                this.dealModel.authorizerComment = null;
                if (this.actionType === 'copy') {
                    this.dealModel.dealId = 0;
                    this.dealModel.dealName = ("Copy of : " + result.dealName).substring(0, 100);
                    this.workflowStepId = 0;
                }
                this.loadSelectList();
                this.dealunsavedModel = JSON.parse(JSON.stringify(this.dealModel));
            }
            else {
                this.title = this._dealNotExist;
                this.actionType = this._invalidAction;
            }
            this.onLoadDealModelParentEvent.emit();
        });

    }

    addDealInitialize() {
        this.title = this._addDealTitle;
        this.dealModel = new DealModel();
        this.dealModel.businessAreaId = 22;
        this.dealModel.furtherAdvancesAutoTopUpFlagId = 18;
        this.dealModel.balanceTransferAutoTopUpFlagId = 18;
        this.dealModel.mortgageAutoTopUpFlagId = 18;
        this.dealModel.dealAccountingTypeId = 21;
        this.workflowStepId = 0;
        this.canUpdate = true;

        this.loadSelectList();
    }
    saveDeal(workFlowStepId: number, savedMessage: string, isSaveAction: boolean): boolean {
        if (this.title == this._editDealTitle || this.title == this._copyDealTitle) {
            this.title = this._dealtitleName;
        }

        if (this.dealModel.dealName == null) {
            //      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealValidationMessage);
            this.dealForm.form.controls['dealName'].setErrors({ 'required': true });
        }

        if (this.dealModel.dealPublicName == null) {
            //      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealValidationMessage);
            this.dealForm.form.controls['dealPublicName'].setErrors({ 'required': true });
        }

        if (this.dealModel.dealName != null && this.dealModel.dealName.replace(/\s/g, "").toLowerCase().length <= 0) {
            //      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealValidationMessage);
            this.dealForm.form.controls['dealName'].setErrors({ 'required': true });
        }
        if (this.dealModel.dealPublicName != null && this.dealModel.dealPublicName.replace(/\s/g, "").toLowerCase().length <= 0) {
            //      this._toastservice.openToast(ToasterTypes.error, this.title, this._dealValidationMessage);
            this.dealForm.form.controls['dealPublicName'].setErrors({ 'required': true });
        }

        if (this.riskRetentionPercentage != null
            && (this.riskRetentionPercentage > 100 || this.riskRetentionPercentage < 0)) {
            this.dealForm.form.controls['riskRetentionPercent'].setErrors({ 'incorrect': true });
        }

        if (this.legalRetentionPercentage != null
            && (this.legalRetentionPercentage > 100 || this.legalRetentionPercentage < 0)) {
            this.dealForm.form.controls['legalRetentionPercent'].setErrors({ 'incorrect': true });
        }
        if (this.dealForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this.title, this._dealValidationMessage);
            Object.keys(this.dealForm.form.controls).forEach((key) => {
                this.dealForm.form.get(key).markAsTouched();
            });
            return false;
        }
        if (this.dealForm.valid) {
            if (this.dealAction == this._dealActionView) {
                if (!this.CheckDataChange(this.dealunsavedModel)) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
                    return;
                }
            }
            this.dealModel.internalDealName = this.dealModel.dealName.replace(/[^A-Z0-9]+/ig, "")
            //this.dealModel.dealStatusId = workFlowStepId;

            // if (!isSaveAction && (workFlowStepId == this.actionApproved || workFlowStepId == this.actionRejected || workFlowStepId == this.actionSendForAuthorization || workFlowStepId == this.actionDraft)) {
            //     if ((this.dealModel.authorizerComment === null || this.dealModel.authorizerComment === undefined || this.dealModel.authorizerComment.length <= 0)) {
            //         this._toastservice.openToast(ToasterTypes.error, this.title, this._commentErrorMsg);
            //         return false;
            //     }
            // }

            if (this.riskRetentionPercentage != null) {
                this.dealModel.riskRetentionPercent = this.riskRetentionPercentage / 100;
            } else {
                this.dealModel.riskRetentionPercent  = this.riskRetentionPercentage;
            }
            if (this.legalRetentionPercentage != null) {
                this.dealModel.legalRetentionPercent = this.legalRetentionPercentage / 100;
            } else {
                this.dealModel.legalRetentionPercent = this.legalRetentionPercentage;
            }
            if (this.dealModel.dealName != null &&
                this.dealModel.dealName.replace(/\s/g, "").toLowerCase().length > 0
                && this.dealModel.dealPublicName != null &&
                this.dealModel.dealPublicName.replace(/\s/g, "").toLowerCase().length > 0
            ) {
                // if (this.dealForm.form.dirty == true && workFlowStepId == this.actionSendForAuthorization) {
                //     savedMessage = 'Deal is saved and sent for authorization successfully';
                // }
                this.dealModel.dealStatusId = workFlowStepId;
                this.dealModel.dealName = this.dealModel.dealName.trim();

                this._dealService.saveDeal(this.dealModel).subscribe(result => {
                    if (result === 1) {
                        this._toastservice.openToast(ToasterTypes.success, this.title, savedMessage);
                        this.dealForm.form.markAsPristine();
                        this.dealForm.form.markAsUntouched();
                        this._router.navigate([this._dealListNavPath]);
                    }
                    else if (result === 0) {
                        this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNameErrorMsg);
                    }
                    else {
                        this._toastservice.openToast(ToasterTypes.error, this.title, this._dealErrorMsg);
                    }
                });
            }
        }
    }


    private CheckDataChange(row: DealModel) {
        console.log(row);
        console.log(JSON.parse(JSON.stringify(this.dealModel)))
        if (row.dealName == this.dealModel.dealName && row.dealPublicName == this.dealModel.dealPublicName &&
            row.internalDealName == this.dealModel.internalDealName && row.description == this.dealModel.description &&
            row.ownerName == this.dealModel.ownerName && row.businessAreaId == this.dealModel.businessAreaId &&
            row.dealTypeId == this.dealModel.dealTypeId && row.dealCurrencyId == this.dealModel.dealCurrencyId &&
            row.jurisdictionMarkerId == this.dealModel.jurisdictionMarkerId && row.furtherAdvancesAutoTopUpFlagId == this.dealModel.furtherAdvancesAutoTopUpFlagId &&
            row.balanceTransferAutoTopUpFlagId == this.dealModel.balanceTransferAutoTopUpFlagId && row.mortgageAutoTopUpFlagId == this.dealModel.mortgageAutoTopUpFlagId &&
            row.dealAccountingTypeId == this.dealModel.dealAccountingTypeId && row.ipdFrequencyId == this.dealModel.ipdFrequencyId &&
            row.closingDate == this.dealModel.closingDate && row.dealMaturityDate == this.dealModel.dealMaturityDate &&
            row.firstIpdDate == this.dealModel.firstIpdDate && row.cashCollectionStartDate == this.dealModel.cashCollectionStartDate &&
            row.redactedFacilityIds == this.dealModel.redactedFacilityIds &&

            row.cashReportingFlagId == this.dealModel.cashReportingFlagId &&
            row.dealInitialSize == this.dealModel.dealInitialSize &&
            row.topupEndDate == this.dealModel.topupEndDate &&
            row.topupFlagId == this.dealModel.topupFlagId &&
            row.riskRetentionPercent == this.riskRetentionPercentage / 100 &&
            row.riskRetentionMethodId == this.dealModel.riskRetentionMethodId &&
            row.riskRetentionHolderId == this.dealModel.riskRetentionHolderId &&
            row.ronaCalculatedBasedOnId == this.dealModel.ronaCalculatedBasedOnId &&
            row.fxRateDate == this.dealModel.fxRateDate &&
            row.facilitySharingAllowedId == this.dealModel.facilitySharingAllowedId &&
            row.enableHistoricFlaggingId == this.dealModel.enableHistoricFlaggingId &&
            row.facilityPercentChangeAllowedId == this.dealModel.facilityPercentChangeAllowedId &&
            row.legalRetentionPercent == this.legalRetentionPercentage / 100
        ) {
            return false;
        }
        else
            return true;
    }

    // #region Authorise-Reject
    // onAuthoriseRejectDeal() {
    //     this._modalService.open(this.authoriseRejectConfirmation,
    //         { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
    //             if (result.toLowerCase() === 'approved') {
    //                 this.saveDeal(this.actionApproved, 'Deal is approved Successfully', false)
    //             } else if (result.toLowerCase() === 'reject') {
    //                 this.saveDeal(this.actionRejected, 'Deal is rejected Successfully', false)
    //             } else {
    //                 console.log('cancelled');
    //                 this.dealModel.authorizerComment = "";
    //             }
    //         });
    // }

    // #region send for sendforauth/Recall
    sendForAuthorisation(workFlowStepId: number, savedMessage: string) {
        // this._modalService.open(this.modalOnWorkflowAction,
        //     { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
        //         if (result.toLowerCase() === 'save') {
        //             this.saveDeal(workFlowStepId, savedMessage, false)
        //         } else {
        //             this._modalService.dismissAll();
        //         }
        //     });

        if (this.dealForm.form.dirty) {
            this._toastservice.openToast(ToasterTypes.error, this.title, "Please save your unsaved changes.");
            return false;
        }

        let model = new AuthModalConfigModel('Comment', 'Please provide your comment ', 'Comment is required.', AuthWorkflowType.CW_New_Deal_Onboarding, workFlowStepId, this.dealId);
        this.openModalPopup(model, savedMessage);
    }

    recall(workFlowStepId: number, savedMessage: string) {
        let model = new AuthModalConfigModel('Comment', 'Please provide your comment ', 'Comment is required.', AuthWorkflowType.CW_New_Deal_Onboarding, workFlowStepId, this.dealId);
        this.openModalPopup(model, savedMessage);
    }

    openModalPopup(model: AuthModalConfigModel, message: string) {
        const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
            backdrop: 'static',
            keyboard: false
        });

        modalRefPopUp.componentInstance.commentPopUpConfig = model;
        modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
            this._toastservice.openToast(ToasterTypes.success, this.title, message);
            this._router.navigate([this._dealListNavPath]);
        });
    }

    openAuthActionModal() {
        const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
            backdrop: 'static',
            keyboard: false
        });

        var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.CW_New_Deal_Onboarding, AuthWorkflowStep.Approve_Reject, this.dealId);
        modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
        modalRefPopUp.componentInstance.popupEmitService.subscribe((message) => {
            this._toastservice.openToast(ToasterTypes.success, this.title, message);
            this._router.navigate([this._dealListNavPath]);
        });
    }

    setUpUserRolesAndPermissions() {
        this.loggedInUser = this._userRoleService.getCurrentLoginUser();
        console.log(this.loggedInUser);
        this.canView = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.View);
        this.canUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.AddEdit);
        this.canDelete = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.Delete);
        this.canAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.ApproveReject);
    }

    checkAuthorisationStatus(dealId: number) {
        this.setUpUserRolesAndPermissions();
        this._dealService.getDeal(dealId).subscribe(result => {
            this.dealModel.modifiedDate = this.datePipe.transform(this.dealModel.modifiedDate, 'yyyy-MM-dd');
            if (this.loggedInUser.toLowerCase() === this.dealModel.modifiedBy.toLowerCase() && this.canAuthorized) {
                this.isAuthorizer = false;
            }

            if (this.loggedInUser.toLowerCase() === this.dealModel.modifiedBy.toLowerCase() || (this.canUpdate && !this.canAuthorized)) {

                this.canSendRecallReset = true;
            }

            if (this.dealModel.isCwDeal) {
                this.getDealIpd();
            }
        });
    }


    loadSelectList() {
        let listTypes: Array<number> = [SelectListEnum.AssetType, SelectListEnum.DealType, SelectListEnum.IpdFrequency,
        SelectListEnum.JurisdicationMarker, SelectListEnum.FurtherAdvancesAutoTopUpFlag, SelectListEnum.BalanceTransferAutoTopUpFlag, 
        SelectListEnum.MortgageAutoTopUpFlag, SelectListEnum.DealAccountingType, SelectListEnum.Currency,
        SelectListEnum.CashReportingOptions, SelectListEnum.ReplenishableOptions,
        SelectListEnum.RiskRetentionMethodOptions, SelectListEnum.RiskRetentionHolderOptions, SelectListEnum.BusinessAreaAssetClassMap,
        SelectListEnum.RonaCalculatedBasedOnOptions, SelectListEnum.FacilitySharingAllowedOptions, SelectListEnum.HistoricalFlaggingAllowedOptions,
        SelectListEnum.FacilityPercentChangeAllowedOptions];
        this._dealService.getMultipleSelectedList(listTypes).subscribe(result => {
            this.assetTypeList = result.filter(x => x.listId == SelectListEnum.AssetType);
            this.dealTypeList = result.filter(x => x.listId == SelectListEnum.DealType);
            this.ipdFrequencyList = result.filter(x => x.listId == SelectListEnum.IpdFrequency);
            this.jurisdictionList = result.filter(x => x.listId == SelectListEnum.JurisdicationMarker);
            this.furtherAdvancesAutoTopUpFlagList = result.filter(x => x.listId == SelectListEnum.FurtherAdvancesAutoTopUpFlag);
            this.balanceTransferAutoTopUpFlagList = result.filter(x => x.listId == SelectListEnum.BalanceTransferAutoTopUpFlag);
            this.mortgageAutoTopUpFlagList = result.filter(x => x.listId == SelectListEnum.MortgageAutoTopUpFlag);
            this.dealAccountingTypeList = result.filter(x => x.listId == SelectListEnum.DealAccountingType);
            this.dealCurrencyList = result.filter(x => x.listId == SelectListEnum.Currency);
            this.cashReportingList = result.filter(x => x.listId == SelectListEnum.CashReportingOptions);
            this.replenishableList = result.filter(x => x.listId == SelectListEnum.ReplenishableOptions);
            this.riskRetentionMethodList = result.filter(x => x.listId == SelectListEnum.RiskRetentionMethodOptions);
            this.riskRetentionHolderList = result.filter(x => x.listId == SelectListEnum.RiskRetentionHolderOptions);
            this.businessAreaAssetClassMapList = result.filter(x => x.listId == SelectListEnum.BusinessAreaAssetClassMap);
            this.ronaBasedOnList = result.filter(x => x.listId == SelectListEnum.RonaCalculatedBasedOnOptions);
            this.facilitySharingAllowedList = result.filter(x => x.listId == SelectListEnum.FacilitySharingAllowedOptions);
            this.historicalFlaggingAllowedList = result.filter(x => x.listId == SelectListEnum.HistoricalFlaggingAllowedOptions);
            this.facilityPercentChangeAllowedList = result.filter(x => x.listId == SelectListEnum.FacilityPercentChangeAllowedOptions);
            //Assign businessAreaId based on profile's asset class
            this.defaultBusinessAreaId = false;
            if (this.businessAreaAssetClassMapList && this.businessAreaAssetClassMapList.length > 0) {
                let AssetClassId = window.localStorage.getItem('selectedAssetId');
                let AssetBusinessArea = this.businessAreaAssetClassMapList.filter(x => x.text == AssetClassId);
                if (AssetClassId && AssetBusinessArea.length > 0) {
                    let lstBusinessAreas = this.assetTypeList.filter(x => x.value == AssetBusinessArea[0].value);
                    if (lstBusinessAreas.length > 0) {
                        this.dealModel.businessAreaId = lstBusinessAreas[0].value;
                        this.defaultBusinessAreaId = true;
                    }
                    if (this.dealModel.businessAreaId == 24) {
                        this.dealModel.dealCurrencyId = (this.dealModel.dealCurrencyId == null) ? 56 : this.dealModel.dealCurrencyId;
                        this.dealModel.jurisdictionMarkerId = (this.dealModel.jurisdictionMarkerId == null) ? 16 : this.dealModel.jurisdictionMarkerId;
                    }
                }
            }

        });
    }

    showHideTopUpEndDate() {
        if (this.dealModel.topupFlagId == 18) {
            return true;
        } else {
            return false;
        }
    }

    showHideCashCollectionDate() {
        if (this.dealModel.cashReportingFlagId == 18) {
            return true;
        } else {
            return false;
        }
    }

    showHideLoadingImage(isShow) {
        if (isShow)
            document.getElementById('preloader').style['display'] = 'block';
        else
            document.getElementById('preloader').style['display'] = 'none';
    }

    backToList() {
        this._router.navigate([this._dealListNavPath])
    }

    resizeGrid() {
        let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
        objSFP_Slick.resizeGrid();
    }

    openAuditTrailModal() {
        const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
            size: 'lg',
            backdrop: 'static',
            keyboard: false
        });
        var auditTrailModel = new AuditTrailPopupModel(this.dealId, AuthWorkflowType.New_Deal_Onboarding)
        modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
    }

    // #region Collapse Deal
    onDealCollapse() {
        if ((this.dealModel.dealName).toUpperCase() == ('No Deal').toUpperCase()) {
            this._toastservice.openToast(ToasterTypes.error, this.title, this._CollapseErrorNoDeal);
            return;
        }
        this._modalService.open(this.collapseDeal,
            { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
                if (result.toLowerCase() === 'approved') {
                    //  this.saveDeal(this.actionApproved, 'Approved Successfully')
                } else if (result.toLowerCase() === 'reject') {
                    // this.saveDeal(this.actionRejected, 'Rejected Successfully')
                } else {
                    console.log('Collapse');
                }
            });
    }

    // #region Collapse Deal Confirmation
    onDealCollapseConfirmation() {


        this._dealService.getDealLatestAuthorisedIpdDate(this.dealModel.dealId).subscribe(result => {
            console.log(result);
            this.redemptionDate = this.datePipe.transform(result, 'yyyy-MM-dd');
            console.log(this.redemptionDate);

        });

        this._dealService.getValidateDealForCollapse(this.dealModel.dealId).subscribe(result => {
            console.log(result);
            if (result === 1) {
                this._modalService.open(this.collapseDealConfirmation,
                    { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
                        if (result.toLowerCase() === 'approved') {
                            //  this.saveDeal(this.actionApproved, 'Approved Successfully')
                        } else if (result.toLowerCase() === 'reject') {
                            // this.saveDeal(this.actionRejected, 'Rejected Successfully')
                        } else {
                            console.log('Collapse');
                        }
                    });
            } else {

                this._toastservice.openToast(ToasterTypes.error, this.title, this._dealAuthorisedLoanErrorMsg);

            }
        });

    }

    // #region Collapse Deal Confirmation
    onDealCollapseSentforAuthorization(workFlowStepId: number, savedMessage: string, irComment1: NgModel, earlyRedemptionDate: NgModel, modal: NgbActiveModal) {
        irComment1.control.markAsTouched();
        earlyRedemptionDate?.control.markAsTouched();
        console.log(workFlowStepId);
        if (irComment1.control.status == "INVALID" || earlyRedemptionDate?.control.status == "INVALID") {
            this._toastservice.openToast(ToasterTypes.error, this._CollapseErrorTitle, this._dealValidationMessage);
        }
        else {
            this.dealModel.dealStatusId = workFlowStepId;
            this.dealModel.dealName = this.dealModel.dealName.trim();
            this._dealService.postDealCollapseSentforAuthorization(this.dealModel).subscribe(result => {
                if (result === 1) {
                    this._toastservice.openToast(ToasterTypes.success, this.title, savedMessage);
                    this.dealForm.form.markAsPristine();
                    this.dealForm.form.markAsUntouched();
                    this._router.navigate([this._dealListNavPath]);
                }
                else if (result === 0) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNameErrorMsg);
                }
                else {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealErrorMsg);
                }
            });
            modal.close('cancel');
        }
    }


    // #region Authorise-Reject
    onDealConfirmCollapse(workFlowStepId: number, savedMessage: string) {
        this._modalService.open(this.collapseDealConfirmationCollapse,
            { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
                if (result.toLowerCase() === 'approved') {
                    this.saveDeal(workFlowStepId, savedMessage, false)
                } else if (result.toLowerCase() === 'reject') {
                    this.saveDeal(this.actionRejected, 'Deal is rejected Successfully', false)
                } else {
                    console.log('cancelled');
                    this.dealModel.authorizerComment = "";
                }
            });
    }

    // #region Collapse Deal
    onDealTerminate() {
        this._modalService.open(this.terminateDeal,
            { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
                if (result.toLowerCase() === 'approved') {
                    //  this.saveDeal(this.actionApproved, 'Approved Successfully')
                } else if (result.toLowerCase() === 'reject') {
                    // this.saveDeal(this.actionRejected, 'Rejected Successfully')
                } else {
                    console.log('Collapse');
                }
            });
    }

    onDealTerminateConfirmation() {
        this._modalService.open(this.terminateDealConfirmation,
            { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
                if (result.toLowerCase() === 'approved') {
                    //  this.saveDeal(this.actionApproved, 'Approved Successfully')
                } else if (result.toLowerCase() === 'reject') {
                    // this.saveDeal(this.actionRejected, 'Rejected Successfully')
                } else {
                    console.log('Collapse');
                }
            });
    }

    onDealTerminateSentforAuthorization(workFlowStepId: number, savedMessage: string, irComment1: NgModel, modal: NgbActiveModal) {
        irComment1.control.markAsTouched();
        console.log(workFlowStepId);
        if (irComment1.control.status == "INVALID") {
            this._toastservice.openToast(ToasterTypes.error, this._CollapseErrorTitle, this._dealValidationMessage);
        }
        else {
            this.dealModel.dealStatusId = workFlowStepId;
            this.dealModel.dealName = this.dealModel.dealName.trim();
            this._dealService.postDealCollapseSentforAuthorization(this.dealModel).subscribe(result => {
                if (result === 1) {
                    this._toastservice.openToast(ToasterTypes.success, this.title, savedMessage);
                    this.dealForm.form.markAsPristine();
                    this.dealForm.form.markAsUntouched();
                    this._router.navigate([this._dealListNavPath]);
                }
                else if (result === 100) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealTerminateErrorMsg);
                }
                else if (result === 0) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealNameErrorMsg);
                }
                else {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealErrorMsg);
                }
            });
            modal.close('cancel');
        }
    }

    onDealConfirmTerminate(workFlowStepId: number, savedMessage: string) {
        this._modalService.open(this.terminateDealConfirmationCollapse,
            { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
                if (result.toLowerCase() === 'approved') {
                    this.saveDeal(workFlowStepId, savedMessage, false)
                } else if (result.toLowerCase() === 'reject') {
                    this.saveDeal(this.actionRejected, 'Deal is rejected Successfully', false)
                } else {
                    console.log('cancelled');
                    this.dealModel.authorizerComment = "";
                }
            });
    }

    onMinerAmendment() {
        this.minerAmendmentClicked = true;
        this.dealsaved = JSON.parse(JSON.stringify(this.dealModel));
    }
    
    onCancel() {
        this.minerAmendmentClicked = false;
        if(this.dealsaved){
            this.dealModel = JSON.parse(JSON.stringify(this.dealsaved));
            }
            this.onLoadDealModelParentEvent.emit();
    }
    onSaveDealAmendment() {
        if (this.title === this._editDealTitle || this.title === this._copyDealTitle) {
            this.title = this._dealtitleName;
        }
        if (this.dealModel.dealPublicName == null) {
            this._toastservice.openToast(ToasterTypes.error, this.title, this._dealValidationMessage);
            this.dealForm.form.controls['dealPublicName'].setErrors({ 'required': true });
        }

        //if (!this.dealModel.redactedFacilityIds)
        //{
        //    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealRedactedValidationnMessage);
        //    return;
        //}

        this.inactiveValidatorsForDisabledCrtls();

        //if (!this.dealModel.redactedFacilityIds)
        //{
        //    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealRedactedValidationnMessage);
        //    return;
        //}

        this.inactiveValidatorsForDisabledCrtls();

        if (this.dealForm.valid) {
            this.dealModel.isMinorAmendment = true;
            this._dealService.saveDeal(this.dealModel).subscribe(result => {
                if (result === 1) {
                    this._toastservice.openToast(ToasterTypes.success, this.title, this._savedAmendMsg);
                    this.dealForm.form.markAsPristine();
                    this.dealForm.form.markAsUntouched();
                    this._router.navigate([this._dealListNavPath]);
                } else if (result === 0) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._noDealErrorMsg);
                } else {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._dealErrorMsg);
                }
            });
        }
    }

    isPercentInvalid(percent: number) {
        if (percent < 0 || percent > 100) {
            return true;
        } else {
            return false;
        }
    }

    inactiveValidatorsForDisabledCrtls() {
        if (this.dealForm.form.controls['jurisdictionMarkerId'])
            this.dealForm.form.controls['jurisdictionMarkerId'].setErrors(null);

        if (this.dealForm.form.controls['dealAccountingTypeId'])
            this.dealForm.form.controls['dealAccountingTypeId'].setErrors(null);

        if (this.dealForm.form.controls['cashReportingFlagId'])
            this.dealForm.form.controls['cashReportingFlagId'].setErrors(null);

        if (this.dealForm.form.controls['dealInitialSize'])
            this.dealForm.form.controls['dealInitialSize'].setErrors(null);

        if (this.dealForm.form.controls['topupEndDate'])
            this.dealForm.form.controls['topupEndDate'].setErrors(null);

        if (this.dealForm.form.controls['topupFlagId'])
            this.dealForm.form.controls['topupFlagId'].setErrors(null);

        if (this.dealForm.form.controls['riskRetentionPercent'])
            this.dealForm.form.controls['riskRetentionPercent'].setErrors(null);

        if (this.dealForm.form.controls['riskRetentionMethodId'])
            this.dealForm.form.controls['riskRetentionMethodId'].setErrors(null);

        if (this.dealForm.form.controls['riskRetentionHolderId'])
            this.dealForm.form.controls['riskRetentionHolderId'].setErrors(null);
    }

    getDealIpd() {
        this._ipdManagementService.getDealNextIpd(this.dealId).subscribe(result => {
            this.dealIpdList = result;
        });
    }

    getMinFxRateDate(date) {
        return date;
    }

    getDealFieldsTemplate() {
        return this.dealFieldsTemplate?.template;
    }
    getDealTitleTemplate() {
        return this.dealTitleTemplate?.template;
    }
    getDealStatusTemplate() {
        return this.dealStatusemplate?.template;
    }
    getDealActionByTemplate() {
        return this.dealActionByTemplate?.template;
    }
    getDealActionDateTemplate() {
        return this.dealActionDateTemplate?.template;
    }
    getDealNameTemplate() {
        return this.dealNameTemplate?.template;
    }
    getDealPublicNameTemplate() {
        return this.dealPublicNameTemplate?.template;
    }
    getDealDescriptionTemplate() {
        return this.dealDescriptionTemplate?.template;
    }
    getDealOwnerTemplate() {
        return this.dealOwnerTemplate?.template;
    }
    getDealAssetTypeTemplate() {
        return this.dealAssetTypeTemplate?.template;
    }
    getDealTypeTemplate() {
        return this.dealTypeTemplate?.template;
    }
    getDealCurrencyTemplate() {
        return this.dealCurrencyTemplate?.template;
    }
    getDealJurisMarkerTemplate() {
        return this.dealJurisMarkerTemplate?.template;
    }
    getDealAdvancesAutoFlagTemplate() {
        return this.dealAdvancesAutoFlagTemplate?.template;
    }
    getDealTransferAutoFlagTemplate() {
        return this.dealTransferAutoFlagTemplate?.template;
    }
    getDealMortgageAutoFlagTemplate() {
        return this.dealMortgageAutoFlagTemplate?.template;
    }
    getDealAccountingFlagTemplate() {
        return this.dealAccountingFlagTemplate?.template;
    }
    getDealIpdFrequencyTemplate() {
        return this.dealIpdFrequencyTemplate?.template;
    }
    getDealClosingDtTemplate() {
        return this.dealClosingDtTemplate?.template;
    }
    getDealMaturityDtTemplate() {
        return this.dealMaturityDtTemplate?.template;
    }
    getDealIpdDtTemplate() {
        return this.dealIpdDtTemplate?.template;
    }
    getDealCollectionDtTemplate() {
        return this.dealCollectionDtTemplate?.template;
    }
    getDealRedactedIdsTemplate() {
        return this.dealRedactedIdsTemplate?.template;
    }
    getDealCashReportingTemplate() {
        return this.dealCashReportingTemplate?.template;
    }
    getDealInitialSizeTemplate() {
        return this.dealInitialSizeTemplate?.template;
    }
    getDealTopupEndDateTemplate() {
        return this.dealTopupEndDateTemplate?.template;
    }
    getDealTopupFlagTemplate() {
        return this.dealTopupFlagTemplate?.template;
    }
    getDealRiskRetentionPercentTemplate() {
        return this.dealRiskRetentionPercentTemplate?.template;
    }
    getDealRiskRetentionMethodTemplate() {
        return this.dealRiskRetentionMethodTemplate?.template;
    }
    getDealRiskRetentionHolderTemplate() {
        return this.dealRiskRetentionHolderTemplate?.template;
    }

    getRonaCalculatedBasedOnTemplate() {
        return this.dealRonaCalculatedBasedOnTemplate?.template;
    }

    getFxRateDateTemplate() {
        return this.dealFxRateDateTemplate?.template;
    }

    getFacilitySharingAllowedTemplate() {
        return this.dealFacilitySharingAllowedTemplate?.template;
    }
    getEnableHistoricFlaggingTemplate() {
        return this.dealEnableHistoricFlaggingTemplate?.template;
    }
    getFacilityPercentChangeAllowedTemplate() {
        return this.dealFacilityPercentChangeAllowedTemplate?.template;
    }
    getDealLegalRetentionPercentTemplate() {
        return this.dealLegalRetentionPercentTemplate?.template;
    }
}
