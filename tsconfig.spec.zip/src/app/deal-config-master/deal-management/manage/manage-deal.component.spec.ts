import { async, ComponentFixture, TestBed } from '@angular/core/testing';
import { ManageDealComponent } from '../../deal-management/manage/manage-deal.component';
import { DealModel } from '../../model/deal.model';
import { FormsModule } from '@angular/forms';
import { NgSelectModule } from '@ng-select/ng-select';
import { RouterTestingModule } from "@angular/router/testing";
import { DealService } from '../../service/manage-deal.service';
import { SelectListEnum, SelectLookupModel } from '../../model/select-lookup.model';
import { GlobalToasterService, ToasterTypes } from '../../../shared/services/globaltoaster.service';
import { GlobalHttpService } from '../../../../app/core/services/api/global.http.service';
import { HttpClient } from '@angular/common/http';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { of } from 'rxjs';

describe('ManageDealComponent', () => {
    let manageDealComponent: ManageDealComponent;
    let fixture: ComponentFixture<ManageDealComponent>;
    const dummyDealRecord: DealModel = {

        dealId: 1,
        dealName: 'DUNMORE1',
        dealPublicName: 'Dunmore-deal',
        internalDealName: 'DUNMORE1',
        description: 'DUNMORE1',
        ownerName: '',
        businessAreaId: 22,
        dealTypeId: 1,
        dealStatus: "Draft",
        closingDate: null,
        dealMaturityDate: null,
        firstIpdDate: null,
        cashCollectionStartDate: null,
        dealCurrencyId: 1,
        jurisdictionMarkerId: 1,
        furtherAdvancesAutoTopUpFlagId: 18,
        balanceTransferAutoTopUpFlagId: 18,
        mortgageAutoTopUpFlagId: 18,
        dealAccountingTypeId: 21,
        dealStatusId : 42,
        authorizerComment : 'test',
        modifiedBy : "",
        modifiedDate : "",
        createdBy : "",
        workflowActionedBy : "",
        workflowActionedDate : "",
        earlyRedemptionDate : new Date(),
        isMinorAmendment : false,
        isCwDeal : false

    };
    const selectList: Array<SelectLookupModel> = [new SelectLookupModel(SelectListEnum.AssetType, 22, 'Mortgage'),
    new SelectLookupModel(SelectListEnum.FurtherAdvancesAutoTopUpFlag, 18, 'Yes'),
    new SelectLookupModel(SelectListEnum.BalanceTransferAutoTopUpFlag, 18, 'Yes'),
    new SelectLookupModel(SelectListEnum.MortgageAutoTopUpFlag, 18, 'Yes'),
    new SelectLookupModel(SelectListEnum.DealAccountingType, 21, 'FAILD SALE')];
    beforeEach(async(() => {
        //spy object to mock
        const mockedDealService = jasmine.createSpyObj('DealIrConfigService', ['getMultipleSelectedList', 'saveDeal', 'getDeal', 'deleteDeal']);
        const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService', ['GetRequest', 'PostRequest', 'DeleteRequest']);
        const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);
        TestBed.configureTestingModule({
            imports: [RouterTestingModule, NgSelectModule, FormsModule],
            declarations: [ManageDealComponent],
            providers: [HttpClient
                , { provide: DealService, useValue: mockedDealService }
                , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
                , { provide: GlobalToasterService, useValue: mockedToasterService }
                , {
                    provide: ActivatedRoute,
                    useValue: {
                        params: of({ id: 3 }),
                        url: of('/cashwaterfall/deal/edit/1')
                    }
                }
            ]
        })
            .compileComponents();
    }));

    beforeEach(() => {
        fixture = TestBed.createComponent(ManageDealComponent);
        manageDealComponent = fixture.componentInstance;
        manageDealComponent.actionType = 'edit';
        manageDealComponent.dealModel = dummyDealRecord;
    });

    it('should create Manage Deal Component', () => {
        const fixture = TestBed.createComponent(ManageDealComponent);
        manageDealComponent = fixture.componentInstance;
        fixture.debugElement.injector.get(DealService) as jasmine.SpyObj<DealService>;
        fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;

        // get the service
        const dealService = fixture.debugElement.injector.get(DealService);


        //Prepare the dummy result
        spyOn(dealService, 'getDeal').and.callFake(() => {
            return of(dummyDealRecord);
        });

        spyOn(dealService, 'getMultipleSelectedList').and.callFake(() => {
            return of(selectList);
        });


        const dealCompopInstance = fixture.componentInstance;
        //Call the manageDealComponent function
        manageDealComponent.editCopyViewDealInitialize(manageDealComponent.dealModel.dealId);
        //Validate/Test the result
        expect(expect(dealService.getDeal).toHaveBeenCalled).toBeTruthy();
        expect(expect(manageDealComponent.editCopyViewDealInitialize).toHaveBeenCalled).toBeTruthy();
        expect(dealCompopInstance).toBeDefined();
    });

    it('should call loadSelectedList function ', function () {
        // get the service

        const dealService = fixture.debugElement.injector.get(DealService);

        //Spy on service functions
        spyOn(dealService, 'getMultipleSelectedList').and.callFake(() => {
            return of(selectList);
        });

        //Call the manageDealComponent function
        manageDealComponent.loadSelectList();

        //Validate/Test the result
        expect(expect(manageDealComponent.loadSelectList).toHaveBeenCalled).toBeTruthy();
        expect(expect(dealService.getSelectedList).toHaveBeenCalled).toBeTruthy();
    });
});