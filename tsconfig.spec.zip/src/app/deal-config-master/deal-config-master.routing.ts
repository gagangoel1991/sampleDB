import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core'; 
import { DealConfigurationMasterModule } from './deal-config-master.module';



export const routes: Routes = [
];

export const routing: ModuleWithProviders<DealConfigurationMasterModule> = RouterModule.forChild([]); 