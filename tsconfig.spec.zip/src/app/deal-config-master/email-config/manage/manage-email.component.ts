import { Component, Input, OnInit, ViewEncapsulation, EventEmitter, Output, ViewChild, ElementRef } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DatePipe } from '@angular/common';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';
import { SelectLookupModel, SelectListEnum } from 'src/app/deal-config-master/investor-report/model/strat-asset.model'
import { StratAssetService } from 'src/app/deal-config-master/investor-report/service/strat-asset.service';
import { EmailConfigModel } from '../../model/email-config.model';
import { EmailConfigService } from '../../service/email-config.service';

@Component({
  selector: 'sfp-manage-email',
  templateUrl: './manage-email.component.html',
  styleUrls: ['./manage-email.component.scss'],
  providers: [EmailConfigService, StratAssetService]
})
export class ManageEmailComponent extends CanDeactivateForm implements OnInit {
  @ViewChild('manageEmailConfigForm') manageEmailConfigForm: NgForm;
  @ViewChild('manageEmailConfigForm') confirmUnsavedForm: NgForm;
  @Output() notifyOnTemplateSave = new EventEmitter<string>();

  public emailConfigDetails: EmailConfigModel = null;
  public title: string = '';
  public emailConfigForm: FormGroup;
  public actionType: string = '';
  private emailConfigId: number = 0;
  public emailConfigAction: string = '';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private datePipe = new DatePipe('en-UK');
  private readonly _dateFormat = 'yyyy-MM-dd';
  private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);
  public emailConfigUnsavedDetails: EmailConfigModel = null;
  public emailFormatList: any;
  
  private readonly _emailConfigSaveValidationMessage = 'Please fill required fields marked with asterisk(*) before saving Email Configuration.';
  private readonly _emailConfigActionAdd = 'create';
  private readonly _emailConfigActionEdit = 'edit';
  private readonly _emailConfigActionCopy = 'copy';
  private readonly _emailConfigActionView = 'view';
  private readonly _invalidAction = 'invalid';
  private readonly _addEmailConfigTitle = 'Add Email Configuration';
  private readonly _editEmailConfigTitle = 'Edit Email Configuration';
  private readonly _copyEmailConfigTitle = 'Copy Email Configuration';
  private readonly _viewEmailConfigTitle = 'View Email Configuration';
  private readonly _invalidActionTitle = 'Resource is not available';
  private readonly _viewEmailConfigListNavPath = 'rt/dealconfig/email/';
  private readonly _valueChangeMessage = "You have not changed any value.";


  //Messages
  private readonly _emailConfigNotExist = 'Email Configuration record is not exist.';
  private readonly _emailConfigToastTitle = 'Email Configuration';
  private readonly _emailConfigTitleDuplicateMsg = 'Email Configuration Type is already exist. We can have only one record for each Email Configuration Type';
  private readonly _emailConfigSavedMsg = 'Email Configuration is saved successfully.';
  private readonly _emailConfigEditdMsg = 'Email Configuration updated successfully.';
  private readonly _emailConfigErrorMsg = 'Something went wrong.';
  

  public canUpdate: boolean = false;
  public canView: boolean = false;
  public canDelete: boolean = false;
  public canAuthorized: boolean = false;
  public loggedInUser: string;
  public emailTypeList: Array<SelectLookupModel> = [];

  constructor(
    private _emailConfigService: EmailConfigService,
    private _stratService: StratAssetService,
    private _toastservice: GlobalToasterService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _userService: UserRoleService) {
    super();
    this._route.params.subscribe((params: Params) => {
  
      this.emailConfigId = (params['emailConfigId'] != null) ? params['emailConfigId'] : null;
 
      this.emailConfigAction = this._router.url.split('/')[4];
      switch (this.emailConfigAction) {
        case this._emailConfigActionAdd:
          this.title = this._addEmailConfigTitle;
          this.actionType = this._emailConfigActionAdd;
          this.addEmailConfigInitialize();
          break;
        case this._emailConfigActionEdit:
          this.title = this._editEmailConfigTitle;
          this.actionType = this._emailConfigActionEdit;
          this.editCopyViewEmailConfigInitialize(this.emailConfigId);
          break;
        case this._emailConfigActionCopy:
          this.title = this._copyEmailConfigTitle;
          this.actionType = this._emailConfigActionCopy;
          this.editCopyViewEmailConfigInitialize(this.emailConfigId);
          break;
        case this._emailConfigActionView:
          this.title = this._viewEmailConfigTitle;
          this.actionType = this._emailConfigActionView;
          this.editCopyViewEmailConfigInitialize(this.emailConfigId);
          break;
        default:
          this.title = this._invalidActionTitle;
          this.actionType = this._invalidAction;
      }
    });
  }

  ngOnInit() {

    this.setUpUserRolesAndPermissions();
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.AddEdit);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.Delete);

  }
  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userService.getCurrentLoginUser();

    this.canView = this._userService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.View);
    this.canUpdate = this._userService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.AddEdit);
    this.canDelete = this._userService.getPermissionAccess(PermissionEnum.DealMgmt, PermissionAccessTypeEnum.Delete);
  }

  editCopyViewEmailConfigInitialize(emailConfigId: number) {
    this.emailConfigDetails = new EmailConfigModel();
    this._emailConfigService.getEmailConfig(emailConfigId).subscribe(result => {
      if (result) {
        this.emailConfigDetails = result;

        if (this.canUpdate == true && this.actionType == 'view') {
          this.actionType = 'edit';
          this.title = this._editEmailConfigTitle;
        }

        this.loadSelectList();

        if (this.actionType === this._emailConfigActionCopy) {
          this.emailConfigDetails.displayName = 'Copy of ' + this.emailConfigDetails.displayName;
          this.emailConfigDetails.emailConfigId=0;
        }
        this.emailConfigUnsavedDetails = JSON.parse(JSON.stringify(this.emailConfigDetails));
      }
      else {
        this.title = this._emailConfigNotExist;
        this.actionType = this._invalidAction;
      }
    });

  }

  addEmailConfigInitialize() {
    this.title = this._addEmailConfigTitle;
    this.emailConfigDetails = new EmailConfigModel();
    this.loadSelectList();
    this.emailConfigDetails.emailConfigId = 0;
    this.emailConfigDetails.emailImportance = false;
    this.emailConfigDetails.attachment = false;
    this.emailConfigDetails.emailFormat = 'Text';
    this.emailConfigDetails.isActive = true;
  }


  loadSelectList() {
    let multiListId = [SelectListEnum.EmailTypeList]
    this._stratService.getMultiparameterSelectedList(multiListId).subscribe(result => {
      this.emailTypeList = result.filter(x => x.listId == SelectListEnum.EmailTypeList);
    }, (error: any) => {
      console.log(error);
    });

  }

  //Saving the IR Template data
  saveEmailConfig(): boolean {
    if (this.title == this._editEmailConfigTitle || this.title == this._copyEmailConfigTitle) {
      this.title = this._emailConfigToastTitle
    }
    if (this.manageEmailConfigForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this.title, this._emailConfigSaveValidationMessage);
      Object.keys(this.manageEmailConfigForm.form.controls).forEach((key) => {
        this.manageEmailConfigForm.form.get(key).markAsTouched();
      });
      return false;
    }
    else {
      if (this.emailConfigAction == this._emailConfigActionView) {
        if (!this.CheckDataChange(this.emailConfigUnsavedDetails)) {
          this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
          return;
        }
      }

      if (this.emailConfigDetails.displayName != null &&
        this.emailConfigDetails.displayName.replace(/\s/g, "").toLowerCase().length > 0
      ) {
        
        this._emailConfigService.saveEmailConfig(this.emailConfigDetails).subscribe(result => {
          debugger;
          if (result === 1) {
           if(this.actionType === 'edit'){
              this._toastservice.openToast(ToasterTypes.success, this.title, this._emailConfigEditdMsg);
            }else
            this._toastservice.openToast(ToasterTypes.success, this.title, this._emailConfigSavedMsg);

            this.manageEmailConfigForm.form.markAsPristine();
            this.manageEmailConfigForm.form.markAsUntouched();
            this._router.navigate([this._viewEmailConfigListNavPath]);
          }
          else if (result === 0) {
            this._toastservice.openToast(ToasterTypes.error, this.title, this._emailConfigTitleDuplicateMsg);
          }
          else {
            this._toastservice.openToast(ToasterTypes.error, this.title, this._emailConfigErrorMsg);
          }
        }, (error: any) => {
          console.log(error);
        });
      }
    }
  }

  private CheckDataChange(row: EmailConfigModel) {
    if (row.displayName == this.emailConfigDetails.displayName && row.emailTo == this.emailConfigDetails.emailTo &&
        row.emailFrom == this.emailConfigDetails.emailFrom && row.emailCC == this.emailConfigDetails.emailCC &&
        row.emailBCC == this.emailConfigDetails.emailBCC && row.emailSubject == this.emailConfigDetails.emailSubject &&
        row.emailBody == this.emailConfigDetails.emailBody && row.emailImportance == this.emailConfigDetails.emailImportance &&
        row.emailFormat == this.emailConfigDetails.emailFormat && row.attachment == this.emailConfigDetails.attachment &&
        row.isActive == this.emailConfigDetails.isActive && row.emailTypeId == this.emailConfigDetails.emailTypeId ) {
        return false;
    }
    else
    return true;
  }
  viewEmailConfigList() {
    this._router.navigate([this._viewEmailConfigListNavPath]);
  }


}
