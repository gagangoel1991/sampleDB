import { Component, OnInit } from '@angular/core';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { actionButtonFormatter, actionPermissionButtonFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter'
import { UserRoleService } from '../../../shared/services/user-role-service';
import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { PermissionEnum } from '../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../shared/model/user-permission-accesstype.enum';
import { EmailConfigService } from '../../service/email-config.service';

@Component({
  selector: 'sfp-email-list',
  providers: [EmailConfigService],
  templateUrl: './email-list.component.html',
  styleUrls: ['./email-list.component.scss']
})
export class EmailListComponent implements OnInit {

  public exportFileName = 'EmailConfigListData';
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  private readonly _editBuildDealNavPath = 'rt/dealconfig/email/edit/';
  private readonly _copyBuildDealNavPath = 'rt/dealconfig/email/copy/';
  private readonly _viewBuildDealNavPath = 'rt/dealconfig/email/view/';

  private readonly _lockedRecordNotAllowedDeleteMsg = 'Deal Status is Active, you cannot delete this deal.';
  private readonly _lockedRecordNotAllowedDeleteMsgPendingAuth = 'Deal Status is Pending Authorisation, you cannot delete this deal.';
  private readonly _lockedRecordNotAllowedEditMsg = 'Deal Status is Active, you cannot edit this deal.';
  private readonly _toastTitle = 'Email Configuration';
  private readonly _deletedMsg = 'Email Configuration is deleted successfully.';

  //-------Slick Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  public slickDefaultAuditButtons: boolean = true;
  //-------Slick Variables End--------------

  constructor(private _emailConfigListService: EmailConfigService, private _router: Router, private _sharedDataService: SharedDataService,
    public _toastService: GlobalToasterService, private _route: ActivatedRoute, private _userRoleService: UserRoleService) { }

  ngOnInit(): void {
    this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.AddEdit);
    this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.DealMgmt], PermissionAccessTypeEnum.Delete);

    this.bindEmailConfigColumns();
    this.bindDealActionsCallBack();
    this.bindEmailConfigList();
  }

  bindEmailConfigColumns() {
    if (this.isAddEditAccess) {
      this.slickColumnArray.push(new SFP_SlickColumn('', 'Action', false, false, 110, FieldType.string,
        actionPermissionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 110))
    }
    this.slickColumnArray.push
      (
        new SFP_SlickColumn('displayName', 'Email Configuration', true, true, 120, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('emailType', 'Email Type', true, true, 100, FieldType.string),
        new SFP_SlickColumn('emailFrom', 'From', true, true, 150, FieldType.string),
        new SFP_SlickColumn('emailTo', 'To', true, true, 200, FieldType.string),
        new SFP_SlickColumn('emailCC', 'CC', true, true, 100, FieldType.string),
        new SFP_SlickColumn('emailBCC', 'BCC', true, true, 100, FieldType.string),
        new SFP_SlickColumn('emailSubject', 'Subject', true, true, 100, FieldType.string),
        new SFP_SlickColumn('emailBody', 'Body', true, true, 200, FieldType.string),
        new SFP_SlickColumn('emailImportanceText', 'Importance', true, true, 50, FieldType.string),
        new SFP_SlickColumn('emailFormat', 'Email Format', true, true, 50, FieldType.string),
        new SFP_SlickColumn('attachmentText', 'Attachment', true, true, 30, FieldType.string),
        new SFP_SlickColumn('activeStatus', 'Status', true, true, 50, FieldType.string)
      );

      //SET EXPORT FILE NAME
      var myDt = new Date();
      var current_timestamp = myDt.getDate() +' '+ (myDt.toLocaleString('default', { month: 'short' })) +' '+  myDt.getFullYear();
      this.exportFileName = current_timestamp + '_EmailConfigList';
  }

  bindEmailConfigList() {
    this._emailConfigListService.getEmailConfigList().subscribe(result => {
      console.log(result);
      this.slickDataset = JSON.parse(JSON.stringify(result)); //deep copy      
    });
  }

  bindDealActionsCallBack() {
    var objSFP_SlickAction = new SFP_SlickAction(
      this.onviewAction,
      this.onCopyAction,
      this.onEditAction,
      {
        deleteFunc: this.onDeleteAction,
        title: "Delete Email Configuration confirmation",
        message: template`Are you sure you want to delete Email Configuration for \'${'displayName'}\'.`
      }
    );
    this.slickCallbackFuntions = objSFP_SlickAction;
  }



  //** Action Callback functions Start  */
  onviewAction(rowData: any, parentThis: any) {
    let emailConfigId = rowData['emailConfigId']
    parentThis._router.navigate([parentThis._viewBuildDealNavPath, emailConfigId]);
  }

  onCopyAction(rowData: any, parentThis: any) {
    let emailConfigId = rowData['emailConfigId']
    parentThis._router.navigate([parentThis._copyBuildDealNavPath, emailConfigId]);
  }
  onEditAction(rowData: any, parentThis: any) {
    let emailConfigId = rowData['emailConfigId']
    if (rowData.dealStatus == 'Active') {
      parentThis._toastService.openToast(ToasterTypes.error, parentThis._toastTitle, parentThis._lockedRecordNotAllowedEditMsg);
      return;
    }
    parentThis._router.navigate([parentThis._editBuildDealNavPath, emailConfigId]);
  }

  onDeleteAction(rowData: any, parentThis:any) {
    let emailConfigId = rowData['emailConfigId']
 
    parentThis._emailConfigListService.deleteEmailConfig(emailConfigId).subscribe(result => {
          parentThis._toastService.openToast(ToasterTypes.success, parentThis._toastTitle, parentThis._deletedMsg);
          parentThis.bindEmailConfigList();
      });
  }

  //** Action Callback functions End  */

  navigateToConfigNewEamil(): void {
    this._router.navigate(['rt/dealconfig/email/create'])
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

}
