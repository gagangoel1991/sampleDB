import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = { suppressScrollX: true };
import { DirectivesModule } from '../core/theme/directives/directives.module';
import { PipesModule } from '../core/theme/pipes/pipes.module';
import { routing } from './deal-config-master.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { CustomControlModule } from '../shared/modules/custom-control.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularSlickgridModule } from 'angular-slickgrid';

import { ManageDealComponent } from './deal-management/manage/manage-deal.component';
import { DealListComponent } from './deal-management/list/deal-list.component';
import { StratAssetListComponent } from 'src/app/deal-config-master/investor-report/strat-asset/list/strat-asset-list.component';
import { ManageStratAssetComponent } from 'src/app/deal-config-master/investor-report/strat-asset/manage/manage-strat-asset.component';
import { IrTemplateListComponent } from 'src/app/deal-config-master/investor-report/ir-template/list/ir-template-list.component';
import { ManageIrTemplateComponent } from 'src/app/deal-config-master/investor-report/ir-template/manage/manage-ir-template.component';
import { BuildIrListComponent } from 'src/app/deal-config-master/investor-report/build-ir/list/build-ir-list.component';
import { ManageBuildIrComponent } from 'src/app/deal-config-master/investor-report/build-ir/manage/manage-build-ir.component';
import { ViewNonConfigStratComponent } from './investor-report/strat-asset/view-non-config-strat/view-non-config-strat.component';
import { IrTemplateListBtnCreateNewDirective, IrTemplateListGridDirective, IrTemplateListTitleDirective } from './investor-report/ir-template/list/ir-template-list.directive';
import { RtIrTemplateListComponent } from '../deal-config-retail/investor-report/ir-template/rt-list/rt-ir-template-list.component';
import { IrManageTemplateDealTypeDirective, IrManageTemplateDescriptionDirective, IrManageTemplateNameDirective, IrManageTemplateTitleDirective, IrManageTemplateUploadFileDirective } from './investor-report/ir-template/manage/manage-ir-template.directive';
import { RtManageIrTemplateComponent } from '../deal-config-retail/investor-report/ir-template/rt-manage/rt-manage-ir-template.component';
import { StratListConfigTabNameDirective, StratListCreateNewBtnDirective, StratListGridDirective, StratListNonConfigTabNameDirective, StratListTitleDirective } from './investor-report/strat-asset/list/strat-asset-list.directive';
import { ManageStratCollectionEndDateDirective, ManageStratConfigDetailsDirective, ManageStratDealTypeDirective, ManageStratDescriptionDirective, ManageStratDetailsTabDirective, ManageStratFieldNameDirective, ManageStratGridDirective, ManageStratNameDirective, ManageStratPreviewTabDirective, ManageStratSelectDealDirective, ManageStratTitleDirective } from './investor-report/strat-asset/manage/manage-strat-asset.directive';
import { ViewNonConfigStratCreatedByDirective, ViewNonConfigStratCreatedDateDirective, ViewNonConfigStratDescriptionDirective, ViewNonConfigStratEndDateDirective, ViewNonConfigStratFieldDirective, ViewNonConfigStratPreviewDirective, ViewNonConfigStratResultTblDirective, ViewNonConfigStratSelectDealDirective, ViewNonConfigStratStatusDirective, ViewNonConfigStratTypeDirective } from './investor-report/strat-asset/view-non-config-strat/view-non-config-strat.directive';
import { BuildIrListAddBtnDirective, BuildIrListGridDirective, BuildIrListTitleDirective } from './investor-report/build-ir/list/build-ir-list.directive';
import { BuildIrActionByDirective, BuildIrActionDateDirective, BuildIrAssetStratTitleDirective, BuildIrCollectionDateDirective, BuildIrDealNameDirective, BuildIrDescriptionDirective, BuildIrDetailsTabDirective, BuildIrDownloadIrTabDirective, BuildIrLiabilityStratTitleDirective, BuildIrMiscellaneousTitleDirective, BuildIrNameDirective, BuildIrStatusDirective, BuildIrTemplateNameDirective, BuildIrTitleDirective, BuildIrUploadIrTabDirective, BuildIrUploadTemplateDirective, BuildIrUploadTemplateLblDirective } from './investor-report/build-ir/manage/manage-build-ir.directive';
import { DealNoteComponent } from './deal-management/deal-note/deal-note.component';
import { ManageDealFieldsDirective, ManageDealTitleDirective,
        ManageDealStatusDirective,ManageDealActionByDirective,ManageDealActionDateDirective,
        ManageDealNameDirective,ManageDealPublicNameDirective,ManageDealDescriptionDirective,
        ManageDealOwnerDirective,ManageDealAssetTypeDirective,ManageDealTypeDirective,
        ManageDealCurrencyDirective,ManageDealJurisMarkerDirective,ManageDealAdvancesAutoFlagDirective,
        ManageDealTransferAutoFlagDirective,ManageDealMortgageAutoFlagDirective,ManageDealAccountingFlagDirective,
        ManageDealIpdFrequencyDirective,ManageDealClosingDtDirective,ManageDealMaturityDtDirective,
        ManageDealIpdDtDirective,ManageDealCollectionDtDirective,ManageDealRedactedIdsDirective, ManageDealCashReportingDirective, 
        ManageDealInitialSizeDirective, ManageDealTopupEndDateDirective, ManageDealTopupFlagDirective, 
        ManageDealRiskRetentionPercentDirective, ManageDealRiskRetentionMethodDirective, ManageDealRiskRetentionHolderDirective, 
        ManageDealEnableHistoricFlaggingDirective, ManageDealFacilityPercentChangeAllowedDirective, ManageDealFacilitySharingAllowedDirective, 
        ManageDealFxRateDateDirective, ManageDealLegalRetentionPercentDirective, ManageDealRonaCalculatedBasedOnDirective } 
        from './deal-management/manage/manage-deal.directive';

import { DealListBtnCreateNewDirective, DealListGridDirective, DealListTitleDirective }
 from './deal-management/list/deal-list.directive';
import { EmailListComponent } from './email-config/list/email-list.component';
import { ManageEmailComponent } from './email-config/manage/manage-email.component';

@NgModule({
  imports: [ 
    CommonModule,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    MultiselectDropdownModule,
    routing,
    NgxDatatableModule,
    CustomControlModule,
    NgSelectModule,
    NgbModule,
    AngularSlickgridModule.forRoot()
  ],
  declarations: [

    //1
    IrTemplateListComponent,
    //RtIrTemplateListComponent,
    IrTemplateListTitleDirective,
    IrTemplateListBtnCreateNewDirective,
    IrTemplateListGridDirective,

    //2
    ManageIrTemplateComponent,
    //RtManageIrTemplateComponent,
    IrManageTemplateTitleDirective,
    IrManageTemplateDealTypeDirective,
    IrManageTemplateNameDirective,
    IrManageTemplateUploadFileDirective,
    IrManageTemplateDescriptionDirective,

    //3
    StratAssetListComponent,
    StratListTitleDirective,
    StratListConfigTabNameDirective,
    StratListNonConfigTabNameDirective,
    StratListCreateNewBtnDirective,
    StratListGridDirective,

    //4
    ManageStratAssetComponent,
    ManageStratDetailsTabDirective,
    ManageStratPreviewTabDirective,
    ManageStratTitleDirective,
    ManageStratDealTypeDirective,
    ManageStratFieldNameDirective,
    ManageStratNameDirective,
    ManageStratDescriptionDirective,
    ManageStratConfigDetailsDirective,
    ManageStratSelectDealDirective,
    ManageStratCollectionEndDateDirective,
    ManageStratGridDirective,

    //5
    ViewNonConfigStratComponent,
    ViewNonConfigStratPreviewDirective,
    ViewNonConfigStratFieldDirective,
    ViewNonConfigStratDescriptionDirective,
    ViewNonConfigStratStatusDirective,
    ViewNonConfigStratTypeDirective,
    ViewNonConfigStratCreatedByDirective,
    ViewNonConfigStratCreatedDateDirective,
    ViewNonConfigStratSelectDealDirective,
    ViewNonConfigStratEndDateDirective,
    ViewNonConfigStratResultTblDirective,

    //6
    BuildIrListComponent,
    BuildIrListTitleDirective,
    BuildIrListAddBtnDirective,
    BuildIrListGridDirective,

    //7
    ManageBuildIrComponent,
    BuildIrTitleDirective,
    BuildIrStatusDirective,
    BuildIrActionByDirective,
    BuildIrActionDateDirective,
    BuildIrDetailsTabDirective,
    BuildIrDownloadIrTabDirective,
    BuildIrUploadIrTabDirective,
    BuildIrNameDirective,
    BuildIrDescriptionDirective,
    BuildIrDealNameDirective,
    BuildIrTemplateNameDirective,
    BuildIrAssetStratTitleDirective,
    BuildIrLiabilityStratTitleDirective,
    BuildIrMiscellaneousTitleDirective,
    BuildIrCollectionDateDirective,
    BuildIrUploadTemplateLblDirective,
    BuildIrUploadTemplateDirective,

    DealListComponent,
    //ManageIrTemplateComponent,
    //IrTemplateListComponent,
    //StratAssetListComponent,
    //ManageStratAssetComponent,
    //BuildIrListComponent,
    //ManageBuildIrComponent,
    //ViewNonConfigStratComponent,    
    ViewNonConfigStratComponent, 
    DealNoteComponent,

    ManageDealComponent,
    ManageDealFieldsDirective,
    ManageDealTitleDirective,
    ManageDealStatusDirective,
    ManageDealActionByDirective,
    ManageDealActionDateDirective,
    ManageDealNameDirective,
    ManageDealPublicNameDirective,
    ManageDealDescriptionDirective,
    ManageDealOwnerDirective,
    ManageDealAssetTypeDirective,
    ManageDealTypeDirective,
    ManageDealCurrencyDirective,
    ManageDealJurisMarkerDirective,
    ManageDealAdvancesAutoFlagDirective,
    ManageDealTransferAutoFlagDirective,
    ManageDealMortgageAutoFlagDirective,
    ManageDealAccountingFlagDirective,
    ManageDealIpdFrequencyDirective,
    ManageDealClosingDtDirective,
    ManageDealMaturityDtDirective,
    ManageDealIpdDtDirective,
    ManageDealCollectionDtDirective,
    ManageDealRedactedIdsDirective,
    ManageDealCashReportingDirective,
    ManageDealInitialSizeDirective,
    ManageDealTopupEndDateDirective,
    ManageDealTopupFlagDirective,
    ManageDealRiskRetentionPercentDirective,
    ManageDealRiskRetentionMethodDirective,
    ManageDealRiskRetentionHolderDirective,
    ManageDealRonaCalculatedBasedOnDirective,
    ManageDealFxRateDateDirective,
    ManageDealFacilitySharingAllowedDirective,
    ManageDealEnableHistoricFlaggingDirective,
    ManageDealFacilityPercentChangeAllowedDirective,
    ManageDealLegalRetentionPercentDirective,
    DealListTitleDirective,
    DealListBtnCreateNewDirective,
    DealListGridDirective, 
    //Email Config
    EmailListComponent, 
    ManageEmailComponent

  ],
  exports :[
     //1
     IrTemplateListComponent,
     //RtIrTemplateListComponent,
     IrTemplateListTitleDirective,
     IrTemplateListBtnCreateNewDirective,
     IrTemplateListGridDirective,
 
     //2
     ManageIrTemplateComponent,
     //RtManageIrTemplateComponent,
     IrManageTemplateTitleDirective,
     IrManageTemplateDealTypeDirective,
     IrManageTemplateNameDirective,
     IrManageTemplateUploadFileDirective,
     IrManageTemplateDescriptionDirective,
 
     //3
     StratAssetListComponent,
     StratListTitleDirective,
     StratListConfigTabNameDirective,
     StratListNonConfigTabNameDirective,
     StratListCreateNewBtnDirective,
     StratListGridDirective,
 
     //4
     ManageStratAssetComponent,
     ManageStratDetailsTabDirective,
     ManageStratPreviewTabDirective,
     ManageStratTitleDirective,
     ManageStratDealTypeDirective,
     ManageStratFieldNameDirective,
     ManageStratNameDirective,
     ManageStratDescriptionDirective,
     ManageStratConfigDetailsDirective,
     ManageStratSelectDealDirective,
     ManageStratCollectionEndDateDirective,
     ManageStratGridDirective,
 
     //5
     ViewNonConfigStratComponent,
     ViewNonConfigStratPreviewDirective,
     ViewNonConfigStratFieldDirective,
     ViewNonConfigStratDescriptionDirective,
     ViewNonConfigStratStatusDirective,
     ViewNonConfigStratTypeDirective,
     ViewNonConfigStratCreatedByDirective,
     ViewNonConfigStratCreatedDateDirective,
     ViewNonConfigStratSelectDealDirective,
     ViewNonConfigStratEndDateDirective,
     ViewNonConfigStratResultTblDirective,
 
     //6
     BuildIrListComponent,
     BuildIrListTitleDirective,
     BuildIrListAddBtnDirective,
     BuildIrListGridDirective,
 
     //7
     ManageBuildIrComponent,
     BuildIrTitleDirective,
     BuildIrStatusDirective,
     BuildIrActionByDirective,
     BuildIrActionDateDirective,
     BuildIrDetailsTabDirective,
     BuildIrDownloadIrTabDirective,
     BuildIrUploadIrTabDirective,
     BuildIrNameDirective,
     BuildIrDescriptionDirective,
     BuildIrDealNameDirective,
     BuildIrTemplateNameDirective,
     BuildIrAssetStratTitleDirective,
     BuildIrLiabilityStratTitleDirective,
     BuildIrMiscellaneousTitleDirective,
     BuildIrCollectionDateDirective,
     BuildIrUploadTemplateLblDirective,
     BuildIrUploadTemplateDirective,
 
     DealListComponent,
     ManageDealFieldsDirective,
     DealListTitleDirective,
     DealListBtnCreateNewDirective,
     DealListGridDirective,

     //ManageIrTemplateComponent,
     //IrTemplateListComponent,
     //StratAssetListComponent,
     //ManageStratAssetComponent,
     //BuildIrListComponent,
     //ManageBuildIrComponent,
     //ViewNonConfigStratComponent,    
     ManageDealComponent, 
     ManageDealTitleDirective,
    ManageDealStatusDirective,
    ManageDealActionByDirective,
    ManageDealActionDateDirective,
    ManageDealNameDirective,
    ManageDealPublicNameDirective,
    ManageDealDescriptionDirective,
    ManageDealOwnerDirective,
    ManageDealAssetTypeDirective,
    ManageDealTypeDirective,
    ManageDealCurrencyDirective,
    ManageDealJurisMarkerDirective,
    ManageDealAdvancesAutoFlagDirective,
    ManageDealTransferAutoFlagDirective,
    ManageDealMortgageAutoFlagDirective,
    ManageDealAccountingFlagDirective,
    ManageDealIpdFrequencyDirective,
    ManageDealClosingDtDirective,
    ManageDealMaturityDtDirective,
    ManageDealIpdDtDirective,
    ManageDealCollectionDtDirective,
    ManageDealRedactedIdsDirective,
    ManageDealCashReportingDirective,
    ManageDealInitialSizeDirective,
    ManageDealTopupEndDateDirective,
    ManageDealTopupFlagDirective,
    ManageDealRiskRetentionPercentDirective,
    ManageDealRiskRetentionMethodDirective,
    ManageDealRiskRetentionHolderDirective,
    ManageDealRonaCalculatedBasedOnDirective,
    ManageDealFxRateDateDirective,
    ManageDealFacilitySharingAllowedDirective,
    ManageDealEnableHistoricFlaggingDirective,
    ManageDealFacilityPercentChangeAllowedDirective,
    ManageDealLegalRetentionPercentDirective,
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class DealConfigurationMasterModule { }