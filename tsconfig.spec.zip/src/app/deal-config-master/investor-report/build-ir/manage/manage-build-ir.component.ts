import { Component, OnInit, ViewEncapsulation, EventEmitter, Output, ViewChild, ElementRef, ContentChild } from '@angular/core';
import { FormGroup, NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DealIrConfigAddEditEntity, DealIrConfigModel, DealIrStratMapList } from 'src/app/deal-config-master/investor-report/model/deal-ir-config.model';
import { DealIrConfigService } from '../../../..//deal-config-master/investor-report/service/deal-ir-config.service';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { DatePipe } from '@angular/common';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { StratTemplateModel } from '../../model/strat-template-model';
import { StratTypeEnum } from '../../enum/strat-type.enum';
import { WorkFlowStepEnum } from '../../enum/workflow-step.enum';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { UserPermissionModel } from 'src/app/shared/model/user-permission.model';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { UserModel } from 'src/app/shared/home/user.model';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { SelectListEnum, SelectLookupModel } from '../../model/strat-asset.model';
import { StratAssetService } from '../../service/strat-asset.service';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';
import { AuthWorkflowType, AuthWorkflowStep } from 'src/app/shared/model/auth-workflow-enum';
import { AuthModalConfigModel } from '../../../../shared/model/auth-modal-config.model';
import { AuthWorkflowPopupComponent } from '../../../../shared/components/auth-workflow/auth-workflow-popup.component';
import { BuildIrActionByDirective, BuildIrActionDateDirective, BuildIrAssetStratTitleDirective, BuildIrCollectionDateDirective, BuildIrDealNameDirective, BuildIrDescriptionDirective, BuildIrDetailsTabDirective, BuildIrDownloadIrTabDirective, BuildIrLiabilityStratTitleDirective, BuildIrMiscellaneousTitleDirective, BuildIrNameDirective, BuildIrStatusDirective, BuildIrTemplateNameDirective, BuildIrTitleDirective, BuildIrUploadIrTabDirective, BuildIrUploadTemplateDirective, BuildIrUploadTemplateLblDirective } from './manage-build-ir.directive';



@Component({
    selector: 'cw-manage-build-ir',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './manage-build-ir.component.html',
    styleUrls: ['./manage-build-ir.component.scss'],
    providers: [DealIrConfigService, KeyValueLookupService, StratAssetService]
})

export class ManageBuildIrComponent //extends CanDeactivateForm 
implements OnInit {

    @ContentChild(BuildIrTitleDirective) buildIrTitleTemplate: BuildIrTitleDirective;
    @ContentChild(BuildIrStatusDirective) buildIrStatusTemplate: BuildIrStatusDirective;
    @ContentChild(BuildIrActionByDirective) buildIrActionByTemplate: BuildIrActionByDirective;
    @ContentChild(BuildIrActionDateDirective) buildIrActionDateTemplate: BuildIrActionDateDirective; 
    @ContentChild(BuildIrDetailsTabDirective) buildIrDetailsTabTemplate: BuildIrDetailsTabDirective;
    @ContentChild(BuildIrDownloadIrTabDirective) buildIrDownloadIrTabTemplate: BuildIrDownloadIrTabDirective;
    @ContentChild(BuildIrUploadIrTabDirective) buildIrUploadIrTabTemplate: BuildIrUploadIrTabDirective;
    @ContentChild(BuildIrNameDirective) buildIrNameTemplate: BuildIrNameDirective; 
    @ContentChild(BuildIrDescriptionDirective) buildIrDescriptionTemplate: BuildIrDescriptionDirective;
    @ContentChild(BuildIrDealNameDirective) buildIrDealNameTemplate: BuildIrDealNameDirective;
    @ContentChild(BuildIrTemplateNameDirective) buildIrTemplateNameTemplate: BuildIrTemplateNameDirective;
    @ContentChild(BuildIrAssetStratTitleDirective) buildIrAssetStratTitleTemplate: BuildIrAssetStratTitleDirective;
 
    @ContentChild(BuildIrLiabilityStratTitleDirective) buildIrLiabilityStratTitleTemplate: BuildIrLiabilityStratTitleDirective; 
    @ContentChild(BuildIrMiscellaneousTitleDirective) buildIrMiscellaneousTitleTemplate: BuildIrMiscellaneousTitleDirective;
    @ContentChild(BuildIrCollectionDateDirective) BuildIrCollectionDateTemplate: BuildIrCollectionDateDirective;
    @ContentChild(BuildIrUploadTemplateLblDirective) BuildIrUploadTemplateLblTemplate: BuildIrUploadTemplateLblDirective;
    @ContentChild(BuildIrUploadTemplateDirective) BuildIrUploadTemplateTemplate: BuildIrUploadTemplateDirective;  

    @ViewChild('manageBuildIrForm') manageBuildIrForm: NgForm;
    @ViewChild('manageStratTemplateForm') manageStratTemplateForm: NgForm;

    @ViewChild('manageBuildIrForm') confirmUnsavedForm: NgForm;
    @ViewChild('manageUploadIrForm') manageUploadIrForm: NgForm;
    // @ViewChild('authoriseRejectConfirmation') authoriseRejectConfirmation: any;
    // @ViewChild('modalOnWorkflowAction') modalOnWorkflowAction: any;


    @Output() notifyOnInvoiceSave = new EventEmitter<string>();
    @Output() buildIrParentEvent = new EventEmitter<NgForm>();

    public dealIrConfigRecord: DealIrConfigModel;
    public dealIrConfigAddEditEntity: DealIrConfigAddEditEntity;
    public dealNameList: Array<KeyValueLookupModel>;
    public stratTemplateList: Array<KeyValueLookupModel> = [];
    public reportLayoutList: Array<KeyValueLookupModel> = [];
    public title: string = '';
    public dealIrForm: FormGroup;
    public irFileToUpload: File = null;
    public actionType: string = '';
    public templateFileToUpload: File = null;
    public irFileUploadRequiredValidation: boolean = false;
    public irFileUploadSizeValidation: boolean = false;
    public isRecordLocked: boolean = false;
    private dealIrConfigId: number = 0;
    private datePipe = new DatePipe('en-UK');
    private readonly _dateFormat = 'yyyy-MM-dd';
    private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);
    private readonly _allowedFiles = ['xlsx'];
    public selectedIpdDate: string = null;
    public templateFileUploadRequiredValidation: boolean = false;
    public dealIrunsavedConfigRecord: DealIrConfigModel;
    private readonly _templateNotExist = 'Build IR template record is not exist.';
    private readonly _templateToastTitle = 'Build IR Template';
    private readonly _templateTitleDuplicateMsg = 'Build IR template name is already exist, should be unique';
    private readonly _templateSavedMsg = 'Build IR template is saved successfully.';
    private readonly _templateFileSizeExceedMsg = 'Build IR file size cannot exceed 20MB.';
    private readonly _templateFileInvalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file types is xlsx.';
    private readonly _templateFileDownloadedMsg = 'Build IR template file is successfully downloaded.';
    private readonly _templateFileUploadErrorMsg = 'Please select Build IR template file for sucessfull upload.';
    private readonly _valueChangeMessage = "You have not changed any value.";

    private readonly _actionAdd = 'add';
    private readonly _actionEdit = 'edit';
    private readonly _actionCopy = 'copy';
    private readonly _actionView = 'view';
    private readonly _invalidAction = 'invalid';
    private readonly _addRecordTitle = 'Add Build IR for : ';

    private readonly _editRecordTitle = 'Edit Build IR for : ';
    private readonly _lockedRecordTitle = 'This Build IR is locked, you cannot edit this.';
    private readonly _copyRecordTitle = 'Copy Build IR for : ';

    private readonly _viewRecordTitle = 'View Build IR for : ';

    private readonly _invalidActionTitle = 'Resource is not available';
    public _viewIrListNavPath = '/dealconfig/ir/buildir/';

    //Messages
    private readonly _recordNotExistMsg = 'Record is not exist.';
    private readonly _nameDuplicateMsg = 'Build IR name should be unique, please enter another name';
    private readonly _anchorCellDuplicateMsg = 'Anchor cell should be unique, please enter another cell name.';
    private readonly _toastTitle = 'Build IR';
    private readonly _savedMsg = 'Build IR is saved successfully.';
    private readonly _updatedMsg = 'Build IR is updated successfully.';
    private readonly _savedErrorMsg = 'Build IR not saved successfully.';
    private readonly _saveValidationStratMsg = 'Please select atleast one Asset Strat.';
    private readonly _saveValidationMessage = 'Please fill the required fields marked with asterisk(*) before saving/updating.';
    private readonly _fileSizeExceedMsg = 'Build IR file size cannot exceed 20MB.';
    private readonly _invalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file types is xlsx.';
    private readonly _fileDownloadedMsg = 'Build IR file is downloaded successfully.';
    private readonly _fileDownloadDateSelectionMsg = 'Please select valid IPD Collection end date.';
    private readonly _fileUploadTabMsg = 'Build IR needs to be saved before upload';
    private readonly _fileDownloadTabMsg = 'Build IR needs to be saved before download.';
    public _fileUploadErrorMsg : string = '"Investor Report" sheet is missing from uploaded file.';
    public _fileDownloadedErrorMsg : string = '"Investor Report" sheet is missing from download file.';
    private readonly _commentErrorMsg = 'Comment is required.';
    private readonly _sendForAuthErrorMsg = 'Please Upload Investor Report template to proceed with Authorisation';

    public tabUploadActive: string = '';
    public tabDownloadActive: string = '';
    public tabIRBuildActive: string = 'active';
    public templateRecordData: StratTemplateModel = null;

    public assetStratSearch: string = '';
    public liabilityStratSearch: string = '';
    public miscStratSearch: string = '';

    public _isDisabled: string;
    public _saveButtonText: string = " Save";
    public _saveButtonView: boolean = true;
    public selectedDealName: string = null;
    public todayDate: Date = new Date;
    public buttonClicked = false;

    public isCellDirty: Boolean;
    public workflowStepId: number;
    public actionApproved: number;
    public actionDraft: number;
    public actionRejected: number;
    public actionSendForAuthorization: number;
    public actionClosed: number;
    public loggedInUser: string;
    public userPermissionsOnIrConfig: UserPermissionModel[];
    public userDetail: UserModel;
    public comment: string;
    public isAuthorizer: boolean = true;
    public canUpdate: boolean = false;
    public canView: boolean = false;
    public canDelete: boolean = false;
    public canAuthorized: boolean = false;
    public selectedDealForIpd: number = null;
    public dealBusinessEndDateList: Array<SelectLookupModel> = [];
    public selectedDealBusinessEndDateList: Array<SelectLookupModel> = [];
    public isTemplateUploaded: boolean = false;
    public isReadOnlyAccess: boolean = false;
    public isAddEditAccess: boolean = false;
    public isApprovRejectAccess: boolean = false;
    public isDeleteAccess: boolean = false;
    public assetId = window.localStorage.getItem('selectedAssetId');

    ngOnInit() {
        this.actionDraft = WorkFlowStepEnum.Draft;
        this.actionSendForAuthorization = WorkFlowStepEnum.SendForAuthorization;
        this.actionApproved = WorkFlowStepEnum.Approved;
        this.actionRejected = WorkFlowStepEnum.Rejected;
        this.actionClosed = WorkFlowStepEnum.Closed;
        this.isReadOnlyAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.View);
        this.isAddEditAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.AddEdit);
        this.isApprovRejectAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.ApproveReject);
        this.isDeleteAccess = this._userRoleService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.Delete);
        this.setUpUserRolesAndPermissions();
    }

    constructor(
        private _dealIrConfigService: DealIrConfigService,
        private _userRoleService: UserRoleService,
        private _modalService: NgbModal,
        private _stratService: StratAssetService,
        private _lookupService: KeyValueLookupService,
        private _toastservice: GlobalToasterService,
        private _route: ActivatedRoute,
        private _router: Router) {
        //super();

        this.showHideLoadingImage(false);

        this._route.params.subscribe((params: Params) => {
            this.dealIrConfigId = (params['id'] && params['id'] != null) ? params['id'] : null; 
            switch (this._router.url.split('/')[5]) {
                case this._actionAdd:
                    this.title = this._addRecordTitle;
                    this.actionType = this._actionAdd;

                    this.IrConfViewLoadDetails(0);
                    break;
                case this._actionEdit:
                    this.title = this._editRecordTitle;
                    this.actionType = this._actionEdit;

                    this.IrConfViewLoadDetails(this.dealIrConfigId);
                    break;
                case this._actionCopy:
                    this.title = this._copyRecordTitle;
                    this.actionType = this._actionCopy;
                    this.IrConfViewLoadDetails(this.dealIrConfigId);
                    break;
                case this._actionView:
                    this.title = this._viewRecordTitle;
                    this.actionType = this._actionView;
                    this.IrConfViewLoadDetails(this.dealIrConfigId);
                    break;
                default:
                    this.title = this._invalidActionTitle;
                    this.actionType = this._invalidAction;
            }


        });
    }

    IrConfViewLoadDetails(dealIrConfigId: number) {
        this._dealIrConfigService.getDealIrConfig(dealIrConfigId).subscribe(result => {
            this.dealIrConfigRecord = result;
            this.comment = this.dealIrConfigRecord.iR_Config.authorizerComment;
            this.dealIrConfigRecord.iR_Config.authorizerComment = null;
            this.dealIrConfigRecord.iR_Config.lastModifiedDate = this.datePipe.transform(this.dealIrConfigRecord.iR_Config.lastModifiedDate, 'yyyy-MM-dd');

            if (this.canUpdate == true && this.actionType == 'view' && this.isRecordLocked == false) {
                this.actionType = 'edit';
                if (this.dealIrConfigRecord.iR_Config.workFlowStepId == this.actionRejected || this.dealIrConfigRecord.iR_Config.workFlowStepId == this.actionDraft)
                    this.title = this._editRecordTitle;
            }


            this.loadSelectList();

            if (this.dealIrConfigRecord.iR_Config.templateId !== null
                || this.dealIrConfigRecord.iR_Config.uploadedFileName !== null) {
                this.isTemplateUploaded = true;
            }

            if (this.actionType == 'copy') {
                this.dealIrConfigRecord.iR_Config.name = ("Copy of : " + this.dealIrConfigRecord.iR_Config.name).substring(0, 100);
                this.dealIrConfigRecord.iR_Config.workFlowStepId = 0;
                this.dealIrConfigId = null;
            }

            if (this.dealIrConfigRecord.iR_ConfigStartList.length > 0) {
                this.dealIrConfigRecord.iR_ConfigStartList.forEach(val => {
                    val.isExcluded = false;
                })
            }

            if (result.iR_ConfigDetailList.length > 0 && this.actionType !== 'add') {
                this.selectedDealName = result.iR_ConfigDetailList.filter(x => x.dealId == this.dealIrConfigRecord.iR_Config.dealId)[0].dealName;
            }

            if (this.actionType == 'add') {

                this.dealIrConfigRecord.iR_Config.dealId = null;
                this.dealIrConfigRecord.iR_Config.templateId = null;
                this.dealIrConfigRecord.iR_Config.name = null;
                this.dealIrConfigRecord.iR_Config.description = null;
                this.dealIrConfigRecord.iR_Config.originalFileName = null;
                this.dealIrConfigRecord.iR_Config.uploadedFileName = null;
                this.dealIrConfigRecord.iR_Config.workFlowStepId = 0;
                this.dealIrConfigRecord.iR_Config.authorizerComment = null;
                this.dealIrConfigRecord.iR_Config.authRequestorUserName = null;
                this.dealIrConfigRecord.iR_Config.draftRequestCreatedBy = null;
            }

            this.workflowStepId = this.dealIrConfigRecord.iR_Config.workFlowStepId;





            this._isDisabled = (this.actionType === 'view' || this.isRecordLocked
                || this.workflowStepId == this.actionApproved || this.workflowStepId == this.actionClosed || this.workflowStepId == this.actionSendForAuthorization
                || this.canUpdate == false) ? 'disabled' : null;

            if (this.dealIrConfigRecord.iR_Config.authRequestorUserName !== null) {
                if (this.loggedInUser.toLowerCase() === this.dealIrConfigRecord.iR_Config.authRequestorUserName.toLowerCase()) {
                    this.isAuthorizer = false;
                }
            }

            this.dealIrunsavedConfigRecord = JSON.parse(JSON.stringify(this.dealIrConfigRecord));
            //  this.dealIrunsavedConfigRecord.IR_ConfigDealList = JSON.parse( JSON.stringify( this.dealIrConfigRecord.IR_ConfigDealList));
            this.dealIrunsavedConfigRecord.iR_Config = JSON.parse(JSON.stringify(this.dealIrConfigRecord.iR_Config));
            this.dealIrunsavedConfigRecord.iR_ConfigLayoutList = JSON.parse(JSON.stringify(this.dealIrConfigRecord.iR_ConfigLayoutList));
            this.dealIrunsavedConfigRecord.iR_ConfigStartList = JSON.parse(JSON.stringify(this.dealIrConfigRecord.iR_ConfigStartList));
            setTimeout(()=>{ this.buildIrParentEvent.next(this.confirmUnsavedForm); }, 500);
        });
    }

    //Fetch Deal List, Report-Layout List and Strat-Template List
    loadDealList() {
        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ActiveDealList.toString()).subscribe(result => {
            console.log('deal name Fetched:');
            this.dealNameList = result;
            console.log(this.dealNameList);
        });
    }

    getReportLayoutList() {
        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.IrReportLayoutList.toString()).subscribe(result => {
            console.log('Report layout list is fetched:');
            this.reportLayoutList = result;
            console.log(this.reportLayoutList);
        });
    }

    getStratTemplateList() {
        this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.IrStratTemplateList.toString()).subscribe(result => {
            console.log('Strat template list is fetched:');
            this.stratTemplateList = result;
            console.log(this.stratTemplateList);
        });
    }

    setUpUserRolesAndPermissions() {
        this.loggedInUser = this._userRoleService.getCurrentLoginUser();

        this.canView = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.View);
        this.canUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.AddEdit);
        this.canDelete = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.Delete);
        this.canAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.ApproveReject);
    }

    addInvoiceInitialize() {
        // this.dealIrConfigRecord = new DealIrConfigModel(0, '', '', null, '', null, '', null, '', '', '', null, null, null, null, null, null, null);
        this.loadDealList();
        this.loadSelectList();

        this.getStratTemplateList();
        this.getReportLayoutList();
    }

    isEditInvoice() {
        return (this.actionType === this._actionEdit || this.actionType === this._actionCopy
            || this.actionType === this._actionView);
    }

    validateFormState() {
        if (this.manageBuildIrForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._saveValidationMessage);
            return false;
        }
        return true;
    }


    showHideLoadingImage(isShow) {
        if (isShow)
            document.getElementById('preloader').style['display'] = 'block';
        else
            document.getElementById('preloader').style['display'] = 'none';
    }

    onStratDataDownload() {
        if (!this.selectedIpdDate) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._fileDownloadDateSelectionMsg);
        } else {

            this.showHideLoadingImage(true);
            this.buttonClicked = true;


            let templateId = this.dealIrConfigRecord.iR_Config.templateId === null ? 0 : this.dealIrConfigRecord.iR_Config.templateId;
            let downloadFileName = this.dealIrConfigRecord.iR_Config.defaultFileName;

            if (templateId === 0 && this.dealIrConfigRecord.iR_Config.originalFileName !== null)
                downloadFileName = this.dealIrConfigRecord.iR_Config.originalFileName;
            else if (templateId > 0 && this.dealIrConfigRecord.iR_Config.originalFileName !== null) {
                downloadFileName = this.dealIrConfigRecord.iR_Config.originalFileName;
                templateId = 0;
            }
            else if (templateId > 0)
                downloadFileName = this.dealIrConfigRecord.iR_Config.templateFileName;

            this._dealIrConfigService.downloadIrTemplateFile(this.dealIrConfigId, this.selectedIpdDate, templateId, this.assetId).subscribe(blob => {
                this.showHideLoadingImage(false);

                const a = document.createElement('a');
                const objectUrl = URL.createObjectURL(blob);
                a.href = objectUrl
                a.download = downloadFileName;
                a.click();

                URL.revokeObjectURL(objectUrl);
                this._toastservice.openToast(ToasterTypes.success, this._toastTitle, this._fileDownloadedMsg);
                this.buttonClicked = false;

            }, (error: any) => {
                //this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._fileDownloadedErrorMsg);
                this.showHideLoadingImage(false);
                this.buttonClicked = false;
            });
        }
    }

    //For Uploading the IR 
    onUploadDealIr() {
        if (this.manageUploadIrForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileUploadErrorMsg);
            Object.keys(this.manageUploadIrForm.form.controls).forEach((key) => {
                this.manageUploadIrForm.form.get(key).markAsTouched();
            });

            //this.dealIrConfigId
            if (this.manageUploadIrForm.form.controls["uploadTemplateFile"].invalid)
                this.templateFileUploadRequiredValidation = true;
            else
                this.templateFileUploadRequiredValidation = false;

            return false;
        }

        if (this.dealIrConfigRecord.iR_Config.originalFileName === null) {
            this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileUploadErrorMsg);
        } else {

            //Saving the IR Template after all validations
            const formData: FormData = new FormData();
            if (this.templateFileToUpload) {
                formData.append('templateFileAsByte', this.templateFileToUpload, this.templateFileToUpload.name);
            }
            else {
                formData.append('templateFileAsByte', null);
                formData.append('originalFileName', this.dealIrConfigRecord.iR_Config.originalFileName);
                formData.append('uploadedFileName', this.dealIrConfigRecord.iR_Config.uploadedFileName);
            }

            formData.append('dealIrConfigId', this.dealIrConfigId.toString());
            formData.append('action', 'Upload');


            this._dealIrConfigService.uploadDealIR(formData).subscribe(result => {

                if (result === "duplicate") {//Duplicate IR Template title
                    this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateTitleDuplicateMsg);
                    //Mark the name control as invalid
                    this.manageUploadIrForm.form.controls['templateName'].setErrors({ 'incorrect': true });
                }
                else if (result.includes("missing")) {//IR sheet is missing from the file the  Template
                    this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._fileUploadErrorMsg);
                    //Mark the name control as invalid
                    this.manageUploadIrForm.form.controls['templateName'].setErrors({ 'incorrect': true });
                }
                else {
                    //Below these two line will clear the changed state of the form so that user can 
                    //be redirected back to list page without alert.
                    this.dealIrConfigRecord.iR_Config.uploadedFileName = result;
                    this.manageUploadIrForm.form.markAsPristine();
                    this.manageUploadIrForm.form.markAsUntouched();
                    this._toastservice.openToast(ToasterTypes.success, this._templateToastTitle, this._templateSavedMsg);
                }
            });
        }

    }

    countValueInArray(array, value): number {
        let object = array.filter(item => item.anchorCell == value);
        return object.length;
    }


    isAnchorCellDuplicate(stratMapList: any): number {
        let count = 0;
        stratMapList.forEach(x => {
            if (this.countValueInArray(stratMapList, x.anchorCell) > 1 && x.anchorCell.length > 1) {
                ++count;
                return false;
            }
        });

        return count;
    }

    //Saving the IR Config data
    onSaveIrConfig(workFlowStepId: number, savedMessage: string, isSaveAction: boolean): boolean {

        if (this.dealIrConfigRecord.iR_Config.name == null) {
            //       this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._saveValidationMessage);
            this.manageBuildIrForm.form.controls['irName'].setErrors({ 'required': true });
        }

        if (this.dealIrConfigRecord.iR_Config.name != null && this.dealIrConfigRecord.iR_Config.name.replace(/\s/g, "").toLowerCase().length <= 0) {
            //       this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._saveValidationMessage);
            this.manageBuildIrForm.form.controls['irName'].setErrors({ 'required': true });
        }
        let isAnyAssetStartSelected = false;
        var objSelectedStartMapList: DealIrStratMapList[] = [];
        this.dealIrConfigRecord.iR_ConfigStartList.forEach(function (val) {
            if (val.isSelected) {
                isAnyAssetStartSelected = (val.stratTypeId == 1 || isAnyAssetStartSelected) ? true : false;
                objSelectedStartMapList.push(new DealIrStratMapList(val.dealIrStratMapId, val.stratID, val.anchorCell ?? ""));
            }
        });

        if (this.isAnchorCellDuplicate(objSelectedStartMapList) > 0) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._anchorCellDuplicateMsg);
            return false;
        }
        // else if (!isSaveAction && (workFlowStepId == this.actionApproved || workFlowStepId == this.actionRejected || workFlowStepId == this.actionSendForAuthorization || workFlowStepId == this.actionDraft)) {
        //     if ((this.dealIrConfigRecord.iR_Config.authorizerComment === null || this.dealIrConfigRecord.iR_Config.authorizerComment === undefined || this.dealIrConfigRecord.iR_Config.authorizerComment.length <= 0)) {
        //         this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._commentErrorMsg);
        //         return false;
        //     }
        // }

        if (this.manageBuildIrForm.form.valid && isAnyAssetStartSelected) {

            let Action = this.actionType == 'edit' ? "Update" : "Add"

            let obj = new DealIrConfigAddEditEntity(this.dealIrConfigId ?? 0, this.dealIrConfigRecord.iR_Config.name, this.dealIrConfigRecord.iR_Config.description,
                this.dealIrConfigRecord.iR_Config.dealId, this.dealIrConfigRecord.iR_Config.templateId,
                this.dealIrConfigRecord.iR_Config.originalFileName,
                this.dealIrConfigRecord.iR_Config.uploadedFileName,
                workFlowStepId,
                objSelectedStartMapList,
                Action,
                this.dealIrConfigRecord.iR_Config.authorizerComment
            );

            if (this.dealIrConfigRecord.iR_Config.name != null && this.dealIrConfigRecord.iR_Config.name.replace(/\s/g, "").toLowerCase().length > 0) {

                if (this.actionType === this._actionEdit) {
                    if ((!this.CheckDataChange(this.dealIrunsavedConfigRecord))) {
                        this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
                        return;
                    }
                }

                this._dealIrConfigService.saveDealIrConfig(obj).subscribe(result => {
                    if (result == -1) {
                        this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._nameDuplicateMsg);
                    }
                    else if (result > 0) {
                        this.dealIrConfigId = result;
                        this._toastservice.openToast(ToasterTypes.success, this._toastTitle, savedMessage);
                        this.manageBuildIrForm.form.markAsPristine();
                        this.manageBuildIrForm.form.markAsUntouched();
                        this.viewDealIrList();
                    }
                    else
                        this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._savedErrorMsg);
                });
            }
        } else if (!this.manageBuildIrForm.form.valid) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._saveValidationMessage);
        }
        else {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._saveValidationStratMsg);
        }
        return true;

    }

    private CheckDataChange(row: DealIrConfigModel) {
        if (row.iR_Config.name == this.dealIrConfigRecord.iR_Config.name
            && row.iR_Config.description == this.dealIrConfigRecord.iR_Config.description
            && row.iR_Config.dealId == this.dealIrConfigRecord.iR_Config.dealId
            && row.iR_Config.templateId == this.dealIrConfigRecord.iR_Config.templateId
            && JSON.stringify(row.iR_ConfigStartList) == JSON.stringify(this.dealIrConfigRecord.iR_ConfigStartList)) {
            return false;
        }
        else
            return true;
    }

    viewDealIrList() {
        //this._router.navigate([this._viewIrListNavPath], { relativeTo: this._route });
        this._router.navigate([this._viewIrListNavPath]);
    }

    validateUploadedFileExtension(fileName: string) {
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
        if (this._allowedFiles.some(x => x === ext.toLowerCase()))
            return true;
        else
            return false;
    }

    setIrFileUploadControlInvalid() {
        this.manageBuildIrForm.form.controls["uploadInvoiceReceipt"].markAsDirty();
        this.manageBuildIrForm.form.controls["uploadInvoiceReceipt"].markAsTouched();
        this.manageBuildIrForm.form.controls["uploadInvoiceReceipt"].setErrors({ 'incorrect': true });
        this.irFileUploadRequiredValidation = true;
        this.dealIrConfigRecord.iR_Config.uploadedFileName = null;
        this.dealIrConfigRecord.iR_Config.originalFileName = null;
    }

    handleIrFileInput(event: any, files: FileList) {
        if (event && event.target.files) {
            let file = event.target.files.item(0);
            if (!this.validateUploadedFileExtension(file.name)) {
                this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._invalidFileFormatMsg);
                event.srcElement.value = '';
                this.setIrFileUploadControlInvalid();
                return false;
            }
            if (file.size > this._maxAllowedFileSiz) {
                this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._fileSizeExceedMsg);
                event.srcElement.value = '';
                this.setIrFileUploadControlInvalid();
                return false;
            }

            //When all validation passed, set the file name
            this.irFileToUpload = file;
            this.dealIrConfigRecord.iR_Config.originalFileName = this.irFileToUpload.name;
            this.irFileUploadRequiredValidation = false;
        }
    }

    //----------------------------------------------- Moved  ------------------------

    public assetStratList: Array<KeyValueLookupModel> = [];
    public liabilityStratList: Array<KeyValueLookupModel> = [];
    public miscStratList: Array<KeyValueLookupModel> = [];

    private readonly _templateActionAdd = 'add';


    getAllStratsList() {
        this.fetchMasterStrat(KeyValueLookupTypeEnum.IrAssetStratList);
        this.fetchMasterStrat(KeyValueLookupTypeEnum.IrLiabilityStratList);
        this.fetchMasterStrat(KeyValueLookupTypeEnum.IrMiscStratList);
    }


    fetchMasterStrat(lookupTypeId: number) {
        this._lookupService.getKeyLookupList(lookupTypeId.toString()).subscribe(result => {
            console.log('Master Strats have been fetched:');
            console.log(result);
            switch (lookupTypeId) {
                case KeyValueLookupTypeEnum.IrAssetStratList:
                    this.assetStratList = result;
                    this.setSelectedStratInList(this.assetStratList);
                    break;
                case KeyValueLookupTypeEnum.IrLiabilityStratList:
                    this.liabilityStratList = result;
                    this.setSelectedStratInList(this.liabilityStratList);
                    break;
                case KeyValueLookupTypeEnum.IrMiscStratList:
                    this.miscStratList = result;
                    this.setSelectedStratInList(this.miscStratList);
                    break;
            }
        });
    }

    setSelectedStratInList(stratList: Array<KeyValueLookupModel>) {
        if (this.actionType !== this._templateActionAdd) {
            let templateRecord = this.templateRecordData;
            stratList.forEach(function (row) {
                templateRecord.stratList.forEach(function (selected) {
                    if (row.key === selected)
                        row.isSelected = true;
                });
            });
            //Sort the selected options
            stratList.sort((a, b) => {
                return b.isSelected ? 1 : (a.isSelected ? -1 : 0)
            });
        }
    }

    getStratList(stratTypeId: number) {
        const filteredRows = this.dealIrConfigRecord.iR_ConfigStartList.filter(function (row) {
            return !row.isExcluded && row.stratTypeId == stratTypeId;
        });
        return filteredRows;
    }



    filterStrats(stratTypeId: number) {
        // let stratsList = null;
        let searchText: string = '';
        switch (stratTypeId) {
            case StratTypeEnum.Asset:
                searchText = this.assetStratSearch;
                break;
            case StratTypeEnum.Liability:
                searchText = this.liabilityStratSearch;
                break;
            case StratTypeEnum.Miscellaneous:
                searchText = this.miscStratSearch;
                break;
        }

        this.dealIrConfigRecord.iR_ConfigStartList.forEach((row, index) => {
            if (row.stratTypeId == stratTypeId) {
                if (searchText === '' || row.name.toLowerCase().indexOf(searchText.toLowerCase()) !== -1)
                    row.isExcluded = false;
                else
                    row.isExcluded = true;
            }
        });
    }

    onTabChange(tabName: string, event): boolean {
        if (tabName === "Upload" && this.dealIrConfigId === null) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._fileUploadTabMsg);
            event.stopPropagation();
        } else if (tabName === "Download" && this.dealIrConfigId === null) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._fileDownloadTabMsg);
            event.stopPropagation();
        } else if (tabName === 'Upload' || tabName === 'Download') {
            this.selectedDealBusinessEndDateList = this.dealBusinessEndDateList.filter(x => x.value == this.dealIrConfigRecord.iR_Config.dealId);
            this.selectedDealBusinessEndDateList.sort((val1, val2) => { return +new Date(val2.text) - +new Date(val1.text) });
            this._saveButtonView = false;
        } else if (tabName === 'IR-Build') {
            this._saveButtonView = true;
        }
        return false;
    }



    handleTemplateFileInput(event: any, files: FileList) {

        if (event && event.target.files) {
            let file = event.target.files.item(0);

            if (!this.validateUploadedFileExtension(file.name)) {
                this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileInvalidFileFormatMsg);
                event.srcElement.value = '';
                this.setTemplateFileUploadControlInvalid();
                return false;
            }
            if (file.size > this._maxAllowedFileSiz) {

                this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileSizeExceedMsg);
                event.srcElement.value = '';
                this.setTemplateFileUploadControlInvalid();
                return false;
            }

            //When all validation passed, set the file name
            this.templateFileToUpload = file;
            this.dealIrConfigRecord.iR_Config.originalFileName = this.templateFileToUpload.name;
            this.templateFileUploadRequiredValidation = false;
        }
    }


    setTemplateFileUploadControlInvalid() {
        this.manageBuildIrForm.form.controls["manageUploadIrForm"].markAsDirty();
        this.manageBuildIrForm.form.controls["manageUploadIrForm"].markAsTouched();
        this.manageBuildIrForm.form.controls["manageUploadIrForm"].setErrors({ 'incorrect': true });
        this.templateFileUploadRequiredValidation = true;
        this.dealIrConfigRecord.iR_Config.originalFileName = '';
    }


    onDealSelectDropDownChange(event: any) {
        this.selectedDealName = '';
        this.selectedDealBusinessEndDateList = [];
        if (event) {

            let dealId = event.dealId;
            this.dealIrConfigRecord.iR_Config.templateId = null;
            this._dealIrConfigService.getIrConfigLayoutList(dealId).subscribe(result => {
                this.dealIrConfigRecord.iR_ConfigLayoutList = result;
            });


            this._dealIrConfigService.getIrConfigStratList(dealId).subscribe(result => {
                this.dealIrConfigRecord.iR_ConfigStartList = result;
            });

            this.selectedDealBusinessEndDateList = this.dealBusinessEndDateList.filter(x => x.value == dealId);
            this.selectedDealBusinessEndDateList.sort((val1, val2) => { return +new Date(val2.text) - +new Date(val1.text) });
            this.selectedDealName = event.dealName;
        }
    }


    onDealClosingEndDate(event: any): boolean {
        this.selectedIpdDate = null;
        if (event) {
            this.selectedIpdDate = event.text;
        }
        return true;
    }

    sendForAuthorisation(workFlowStepId: number, savedMessage: string) {
        if (this.manageBuildIrForm.form.dirty || this.isCellDirty) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, "Please save your unsaved changes.");
            return false;
        }
        if (this.actionSendForAuthorization === workFlowStepId &&
            (this.dealIrConfigRecord.iR_Config.uploadedFileName === null && this.dealIrConfigRecord.iR_Config.templateId === null && this.isTemplateUploaded == true)) {
            this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._sendForAuthErrorMsg);
            return false;
        }
        let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.IR_Reporting_Management, workFlowStepId, 0, 0, this.dealIrConfigId);
        this.openModalPopup(model, savedMessage);
    }

    recall(workFlowStepId: number, savedMessage: string) {
        let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.IR_Reporting_Management, workFlowStepId, 0, 0, this.dealIrConfigId);
        this.openModalPopup(model, savedMessage);
    }

    openModalPopup(model: AuthModalConfigModel, message: string) {
        const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
            backdrop: 'static',
            keyboard: false
        });

        modalRefPopUp.componentInstance.commentPopUpConfig = model;
        modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
            this._toastservice.openToast(ToasterTypes.success, this.title, message);
            this.viewDealIrList();
        });
    }

    openAuthActionModal() {
        const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
            backdrop: 'static',
            keyboard: false
        });

        var commentModel = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.IR_Reporting_Management, AuthWorkflowStep.Approve_Reject, 0, 0, this.dealIrConfigId);
        modalRefPopUp.componentInstance.commentPopUpConfig = commentModel;
        modalRefPopUp.componentInstance.popupEmitService.subscribe((message) => {
            this._toastservice.openToast(ToasterTypes.success, this.title, message);
            this.viewDealIrList();
        });
    }

    // #region Authorise-Reject
    // onAuthoriseRejectBuildIr() {
    //     this._modalService.open(this.authoriseRejectConfirmation,
    //         { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
    //             if (result.toLowerCase() === 'approved') {
    //                 this.onSaveIrConfig(this.actionApproved, 'Approved Successfully', false)
    //             } else if (result.toLowerCase() === 'reject') {
    //                 this.onSaveIrConfig(this.actionRejected, 'Rejected Successfully', false)
    //             } else {
    //                 console.log('cancelled');
    //             }
    //         });
    // }

    // #region send for sendforauth/Recall
    // commentModalOnWorkflowAction(workFlowStepId: number, savedMessage: string) {
    //     if (this.actionSendForAuthorization === workFlowStepId &&
    //         (this.dealIrConfigRecord.iR_Config.uploadedFileName === null && this.dealIrConfigRecord.iR_Config.templateId === null)) {
    //         this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._sendForAuthErrorMsg);
    //         return false;
    //     } else {
    //         this._modalService.open(this.modalOnWorkflowAction,
    //             { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
    //                 if (result.toLowerCase() === 'save') {
    //                     this.onSaveIrConfig(workFlowStepId, savedMessage, false);
    //                 } else {
    //                     this._modalService.dismissAll();
    //                 }
    //             });
    //     }
    // }

    loadSelectList() {
        let multiListId = [SelectListEnum.DealBusinessEndDate];
        this._stratService.getMultiparameterSelectedList(multiListId).subscribe(result => {
            console.log(result);
            this.dealBusinessEndDateList = result.filter(x => x.listId == SelectListEnum.DealBusinessEndDate);
            console.log(this.dealBusinessEndDateList);
        }, (error: any) => {
            console.log(error);
        });

    }

    openAuditTrailModal() {
        const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
            size: 'lg',
            backdrop: 'static',
            keyboard: false
        });
        var auditTrailModel = new AuditTrailPopupModel(this.dealIrConfigId, AuthWorkflowType.IR_Reporting_Management)
        modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
    }

    getTitleTemplate() {
        return this.buildIrTitleTemplate?.template;
    }
    getStatusTemplate() {
        return this.buildIrStatusTemplate?.template;
    }
    getActionByTemplate() {
        return this.buildIrActionByTemplate?.template;
    }
    getActionDateTemplate() {
        return this.buildIrActionDateTemplate?.template;
    }

    getDetailsTabTemplate() {
        return this.buildIrDetailsTabTemplate?.template;
    }
    getDownloadIrTabTemplate() {
        return this.buildIrDownloadIrTabTemplate?.template;
    }
    getUploadIrTabTemplate() {
        return this.buildIrUploadIrTabTemplate?.template;
    }
    getNameTemplate() {
        return this.buildIrNameTemplate?.template;
    }

    getDescriptionTemplate() {
        return this.buildIrDescriptionTemplate?.template;
    }
    getDealNameTemplate() {
        return this.buildIrDealNameTemplate?.template;
    }
    getTemplateNameTemplate() {
        return this.buildIrTemplateNameTemplate?.template;
    }
    getAssetStratTitleTemplate() {
        return this.buildIrAssetStratTitleTemplate?.template;
    }

    getLiabilityStratTitleTemplate() {
        return this.buildIrLiabilityStratTitleTemplate?.template;
    }
    getMiscellaneousTitleTemplate() {
        return this.buildIrMiscellaneousTitleTemplate?.template;
    }
    getCollectionDateTemplate() {
        return this.BuildIrCollectionDateTemplate?.template;
    }
    getUploadTemplateLblTemplate() {
        return this.BuildIrUploadTemplateLblTemplate?.template;
    }
    getUploadTemplateTemplate() {
        return this.BuildIrUploadTemplateTemplate?.template;
    }

}
