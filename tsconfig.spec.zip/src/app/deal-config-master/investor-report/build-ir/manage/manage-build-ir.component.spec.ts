import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';
import { ActivatedRoute, Router, Params } from '@angular/router';

import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { ManageBuildIrComponent } from './manage-build-ir.component';
import { DealIrConfigModel, IR_Config } from 'src/app/deal-config/investor-report/model/deal-ir-config.model';
import { DealIrConfigService } from 'src/app/deal-config/investor-report/service/deal-ir-config.service';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';

describe('ManageBuildIrComponent', () => {
  let fixture: ComponentFixture<ManageBuildIrComponent>;
  let buildIrComponent: ManageBuildIrComponent;
  let de: DebugElement;
  let compiledElement;
  
  const dummyDealIrRecord: DealIrConfigModel = {
    iR_Config : { 
      authRequestorUserName: "",
      authorizerComment: null,
      dealId: 14,
      defaultFileName: "template-investor-report-ipd.xlsx",
      description: "Retest_2042",
      draftRequestCreatedBy: "",
      lastModifiedDate: "2021-07-02T07:21:02.153",
      lastModifiedUserName: "EUROPA\\issaram",
      name: "Retest_2042_091",
      originalFileName: null,
      status: "Draft",
      templateFileName: "Dunmore Sample Template- Investor Report_01.xlsx",
      templateId: 1,
      uploadedFileName: null,
      workFlowStepId: 1,
      isLocked: false
    },
    IR_ConfigDealList: [{dealId: 14, dealName: "ARDMORE1"}],
    iR_ConfigLayoutList: [{templateId: 1, name: "ARDMORE1"}],
    iR_ConfigStartList: [{anchorCell: "", dealIrStratMapId: 115, isSelected: true, name: "*Product Switch Report Inv", stratID: 22, stratTypeId: 1, isExcluded: false}]
  };
  const dealList: any = [{ key: 2, value: 'Ardmore1'}, {key: 3, value: 'Dunmore1'}];
  const stratTemplateList: Array<KeyValueLookupModel> = [{ key: 1, value: "Ardmore Strat Template", isExcluded:false, isSelected: false}, { key: 2, value: "Dunmore Strat Template", isExcluded:false, isSelected: false} ];
  const reportLayoutList: Array<KeyValueLookupModel> = [{ key: 1, value: "Ardmore-1 Layout", isExcluded:false, isSelected: false}, { key: 1, value: "Dunmore-1 Layout", isExcluded:false, isSelected: false} ];

  beforeEach(async(() => {
    //spy object to mock
    const mockedKeyValueLookupService = jasmine.createSpyObj('KeyValueLookupService',['getKeyLookupList']);
    const mockedDealIrConfigService = jasmine.createSpyObj('DealIrConfigService',['getDealIrConfig', 'downloadIrSheet', 'saveDealIrConfig']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [ManageBuildIrComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: DealIrConfigService, useValue: mockedDealIrConfigService }
        , { provide: KeyValueLookupService, useValue: mockedKeyValueLookupService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
        ,{ provide: ActivatedRoute,
            useValue:{
                params: of({id: 2}),
                url: of('/dealconfig/ir/buildir/edit/2')
            }
          }
      ]
    }).compileComponents();
    
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageBuildIrComponent);
    buildIrComponent = fixture.componentInstance;
    buildIrComponent.actionType = 'edit';
    buildIrComponent.dealIrConfigRecord = dummyDealIrRecord;
  });

  it('should create Manage Deal IR Config component', () => {
    const fixture = TestBed.createComponent(ManageBuildIrComponent);
    fixture.debugElement.injector.get(DealIrConfigService) as jasmine.SpyObj<DealIrConfigService>;
    fixture.debugElement.injector.get(KeyValueLookupService) as jasmine.SpyObj<KeyValueLookupService>;
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;

    // get the service
    const dealConfigService = fixture.debugElement.injector.get(DealIrConfigService);
    const lookupService = fixture.debugElement.injector.get(KeyValueLookupService);

    //Prepare the dummy result
    spyOn(dealConfigService, 'getDealIrConfig').and.callFake(() => {
      return of(dummyDealIrRecord); 
    });

    spyOn(lookupService, 'getKeyLookupList').and.callFake(() => {
      return of(dealList); 
    });

    const buildIrCompopInstance = fixture.componentInstance;    

    expect(buildIrCompopInstance).toBeDefined();
  });

  it('should be able to call the getDealIrConfig & getKeyLookupList function', () => {
    // get the service
    const dealConfigService = fixture.debugElement.injector.get(DealIrConfigService);
    const lookupService = fixture.debugElement.injector.get(KeyValueLookupService);

    //Spy on service functions
    spyOn(dealConfigService, 'getDealIrConfig').and.callFake(() => {
      return of(dummyDealIrRecord); 
    });

    spyOn(lookupService, 'getKeyLookupList').and.callFake(() => {
      return of(dealList); 
    });

    //Validate/Test the result
    expect(expect(dealConfigService.getDealIrConfig).toHaveBeenCalled).toBeTruthy();
  });

});
