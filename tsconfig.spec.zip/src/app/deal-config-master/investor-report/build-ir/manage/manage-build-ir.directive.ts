import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[buildIrTitle]'})
export class BuildIrTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrStatus]'})
export class BuildIrStatusDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrActionBy]'})
export class BuildIrActionByDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrActionDate]'})
export class BuildIrActionDateDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrDetailsTab]'})
export class BuildIrDetailsTabDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrDownloadIrTab]'})
export class BuildIrDownloadIrTabDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrUploadIrTab]'})
export class BuildIrUploadIrTabDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrName]'})
export class BuildIrNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrDescription]'})
export class BuildIrDescriptionDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrDealName]'})
export class BuildIrDealNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrTemplateName]'})
export class BuildIrTemplateNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrAssetStratTitle]'})
export class BuildIrAssetStratTitleDirective{
    constructor(public template:TemplateRef<any>){}
}
@Directive({selector :'[buildIrLiabilityStratTitle]'})
export class BuildIrLiabilityStratTitleDirective{
    constructor(public template:TemplateRef<any>){}
}
@Directive({selector :'[buildIrMiscellaneousTitle]'})
export class BuildIrMiscellaneousTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrCollectionDate]'})
export class BuildIrCollectionDateDirective{
    constructor(public template:TemplateRef<any>){}
}
@Directive({selector :'[buildIrUploadTemplateLbl]'})
export class BuildIrUploadTemplateLblDirective{
    constructor(public template:TemplateRef<any>){}
}
@Directive({selector :'[buildIrUploadTemplate]'})
export class BuildIrUploadTemplateDirective{
    constructor(public template:TemplateRef<any>){}
}