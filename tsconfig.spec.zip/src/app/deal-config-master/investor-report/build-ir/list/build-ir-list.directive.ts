import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[buildIrListTitle]'})
export class BuildIrListTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrListAddBtn]'})
export class BuildIrListAddBtnDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[buildIrListGrid]'})
export class BuildIrListGridDirective{
    constructor(public template:TemplateRef<any>){}
}