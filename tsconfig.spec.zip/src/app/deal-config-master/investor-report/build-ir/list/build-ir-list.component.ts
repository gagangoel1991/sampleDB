import { Component, ViewEncapsulation, ViewChild, OnInit, ContentChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DealIrConfigModel } from 'src/app/deal-config-master/investor-report/model/deal-ir-config.model';
import { DealIrConfigService } from 'src/app/deal-config-master/investor-report/service/deal-ir-config.service';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';

import {
    AngularGridInstance,
    CollectionService,
    Column,
    Editors,
    FieldType,
    Filters,
    FlatpickrOption,
    Formatter,
    Formatters,
    GridOption,
    GridStateChange,
    Metrics,
    MultipleSelectOption,
    OperatorType,
} from 'angular-slickgrid';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { actionPermissionButtonFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { UserPermissionModel } from 'src/app/shared/model/user-permission.model';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { UserModel } from 'src/app/shared/home/user.model';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { BuildIrListAddBtnDirective, BuildIrListGridDirective, BuildIrListTitleDirective } from './build-ir-list.directive';

@Component({
    selector: 'cw-build-ir-list',
    encapsulation: ViewEncapsulation.None,
    templateUrl: './build-ir-list.component.html',
    styleUrls: ['./build-ir-list.component.scss'],
    providers: [DealIrConfigService]
})

export class BuildIrListComponent implements OnInit {
    // [x: string]: any;

    @ContentChild(BuildIrListTitleDirective) buildIrListTitleTemplate: BuildIrListTitleDirective;
    @ContentChild(BuildIrListAddBtnDirective) buildIrListAddBtnTemplate: BuildIrListAddBtnDirective;
    @ContentChild(BuildIrListGridDirective) buildIrListGridTemplate: BuildIrListGridDirective;

    public title = 'Build IR List';
    public dealIrList: Array<DealIrConfigModel> = [];
    public dealIrGridOptions: SfpGridOptionsModel = null;
    public dealIrGridCustomCols: Array<SfpGridColumnModel> = [];
    public dealIrGridActionLinks: Array<SfpGridActionModel> = [];
    public dealIrGridExcludedCols: Array<string> = []
    public datePipe = new DatePipe('en-UK');
    public exportFileName = 'BuildIRListData';

    private readonly _dateFormat = 'yyyy-MM-dd';
    public _addBuildIrNavPath = '/dealconfig/ir/buildir/add/';
    public _editBuildIrNavPath = '/dealconfig/ir/buildir/edit/';
    public _copyBuildIrNavPath = '/dealconfig/ir/buildir/copy/';
    public _viewBuildIrNavPath = '/dealconfig/ir/buildir/view/';
    public _viewStratTemplateNavPath = '/dealconfig/ir/template/view/';
    public _recordLockedStatus = 'Locked';
    public _reportTypeName = '';
    public _permission: PermissionEnum;

    //Messages
    public _toastTitle = 'Build IR List';
    public _deletedMsg = 'Build IR is deleted successfully.';
    public _lockedRecordNotAllowedDeleteMsg = 'Build IR is locked, you cannot delete this Build IR.';
    public _deleteConfirmMsg = `Are you sure you want to delete Build IR `;
    public _deleteConfirmMsgTitle = "Delete Build IR confirmation"
    public _buttonText = 'Add Build IR';

    //-------Slick Grid Variables Start--------------
    public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
    public slickDataset: any[];
    public slickCallbackFuntions: SFP_SlickAction;
    public slickDefaultActionButtons: boolean = false;
    public slickDefaultAuditButtons: boolean = true;
    //-------Slick Grid Variables End--------------
    public loggedInUser: string;
    public userPermissionsOnIrConfig: UserPermissionModel[];
    public userDetail: UserModel;

    public canUpdate: boolean = false;
    public canView: boolean = false;
    public canDelete: boolean = false;
    public canAuthorized: boolean = false;
    private _permissionDenied: string = 'Permission Denied';    //constructor
    constructor(private _dealIdConfigService: DealIrConfigService,
        public _toastservice: GlobalToasterService,
        private _userRoleService: UserRoleService,
        private _route: ActivatedRoute,
        private _router: Router,
        private _sharedDataService: SharedDataService) {
        //Columns to exclude
        this.dealIrGridExcludedCols = ["dealIrConfigId", 'ID', 'UserName', 'dealId', 'stratTemplateId', 'reportLayoutId', 'uploadedFileName'];;
    }

    ngOnInit() { }

    InitializeData() {
        this.setUpUserRolesAndPermissions();
        this.bindDealColumns();
        this.getDealIrList();
        this.bindDealIrListActionsCallBack();
    }

    bindDealColumns() {
        debugger;
        if (this.canUpdate) {
            //Preparing grid custom columns
            this.slickColumnArray.push(new SFP_SlickColumn('', 'Action', false, false, 110, FieldType.string,
                actionPermissionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 110))
        }
        this.slickColumnArray.push
            (

                new SFP_SlickColumn('name', 'Name', true, true, 150, FieldType.string, hyperLinkFormatter),
                new SFP_SlickColumn('description', 'Description', true, true, 120, FieldType.string),
                new SFP_SlickColumn('dealName', 'Deal Name', true, true, 100, FieldType.string),
                new SFP_SlickColumn('templateName', 'Template Name', true, true, 130, FieldType.string),
                new SFP_SlickColumn('assetStratCount', 'Asset Strats Count', true, true, 80, FieldType.integer),
                new SFP_SlickColumn('liabilityStratCount', 'Liability Strats Count', true, true, 80, FieldType.integer),
                new SFP_SlickColumn('miscStratCount', 'Miscellaneous Strats Count', true, true, 80, FieldType.integer),
                new SFP_SlickColumn('isLocked', 'Is Locked', true, true, 80, FieldType.boolean),
                new SFP_SlickColumn('status', 'Status', true, true, 130, FieldType.string),
                //new SFP_SlickColumn('', 'Actions', false, false, 100, FieldType.object, actionPermissionButtonFormatter),
            );

        //SET EXPORT FILE NAME
        var myDt = new Date();
        var current_timestamp = myDt.getDate() + ' ' + (myDt.toLocaleString('default', { month: 'short' })) + ' ' + myDt.getFullYear();
        this.exportFileName = current_timestamp + '_Build IR List';
    }

    getDealIrList() {
        this.dealIrList = [];

        this._dealIdConfigService.getDealIrConfigList(this._reportTypeName).subscribe(result => {
            this.dealIrList = result;
            this.slickDataset = JSON.parse(JSON.stringify(result)); //deep copy  
        });
    }

    bindDealIrListActionsCallBack() {
        this.slickCallbackFuntions = new SFP_SlickAction(
            this.onTitleClickCallback,
            this.onGridCopyCallback,
            this.onGridEditCallback,
            {
                deleteFunc: this.onGridDeleteCallback,
                title: this._deleteConfirmMsgTitle,
                message: template([this._deleteConfirmMsg], ` \'${'name'}\'.`)
            }
        );

    }

    onGridEditCallback(record: any, currentThis: any = this) {
        if (!currentThis.canUpdate) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._permissionDenied);
            return;
        }

        currentThis._router.navigate([currentThis._editBuildIrNavPath, record.dealIrConfigId]);
    }

    onGridCopyCallback(record: any, currentThis: any = this) {
        if (!currentThis.canUpdate) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._permissionDenied);
            return;
        }

        currentThis._router.navigate([currentThis._copyBuildIrNavPath, record.dealIrConfigId]);
    }


    onGridUploadCallback(record: any, currentThis: any = this) {
        currentThis._toastservice.openToast(ToasterTypes.info, "Not implemented", "Not implemented");
    }

    onTitleClickCallback(record: any, currentThis: any = this) {
        if (!currentThis.canView) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._permissionDenied);
            return;
        }
        currentThis._router.navigate([currentThis._viewBuildIrNavPath, record.dealIrConfigId]);
    }

    onTemplateTitleClickCallback(record: any, currentThis: any = this) {
        currentThis._router.navigate([currentThis._viewStratTemplateNavPath, record.stratTemplateId]);
    }

    onGridDeleteCallback(record: any, currentThis: any = this) {
        if (!currentThis.canDelete) {
            currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._permissionDenied);
            return;
        } else
            if (record.status === currentThis._recordLockedStatus) {
                currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._lockedRecordNotAllowedDeleteMsg);
                return;
            }
        var dealIrConfigId = record.dealIrConfigId;
        currentThis._dealIdConfigService.deleteDealIrConfig(dealIrConfigId).subscribe(result => {
            if (result === -1) {//Locked record
                currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._lockedRecordNotAllowedDeleteMsg);
            }
            else {
                currentThis._toastservice.openToast(ToasterTypes.success, currentThis._toastTitle, currentThis._deletedMsg);
                currentThis.getDealIrList();
            }
        });
    }

    onAddBuildIr() {
        // this._router.navigate([this._addBuildIrNavPath], { relativeTo: this._route });
        this._router.navigate([this._addBuildIrNavPath]);
    }

    resizeGrid() {
        let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
        objSFP_Slick.resizeGrid();
    }

    setUpUserRolesAndPermissions() {
        this.canView = this._userRoleService.getPermissionAccess(this._permission, PermissionAccessTypeEnum.View);
        this.canUpdate = this._userRoleService.getPermissionAccess(this._permission, PermissionAccessTypeEnum.AddEdit);
        this.canDelete = this._userRoleService.getPermissionAccess(this._permission, PermissionAccessTypeEnum.Delete);
        this.canAuthorized = this._userRoleService.getPermissionAccess(this._permission, PermissionAccessTypeEnum.ApproveReject);
    }

    getTitleTemplate() {
        return this.buildIrListTitleTemplate?.template;
    }
    getAddBtnTemplate() {
        return this.buildIrListAddBtnTemplate?.template;
    }
    getGridTemplate() {
        return this.buildIrListGridTemplate?.template;
    }

}
