import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { BuildIrListComponent } from './build-ir-list.component';
import { DealIrConfigService } from 'src/app/deal-config/investor-report/service/deal-ir-config.service';
import { DealIrConfigModel } from 'src/app/deal-config/investor-report/model/deal-ir-config.model';
import { SfpGridComponent } from 'src/app/shared/components/grid/sfp-grid.component';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { DummyDealIrConfigList } from '../../model/spec/dummy-deal-ir-config-list.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';

describe('BuildIrListComponent', () => {
  let childFixture: ComponentFixture<SfpGridComponent>;
  let fixture: ComponentFixture<BuildIrListComponent>;
  let buildIrListComponent: BuildIrListComponent;
  let de: DebugElement;
  let compiledElement;
  const dummyDealIrList: any = DummyDealIrConfigList;
  let datePipe = new DatePipe('en-UK');

  beforeEach(async(() => {
    //spy object to mock
    const mockedDealIrConfigService = jasmine.createSpyObj('DealIrConfigService',['getDealIrConfigList','deleteDealIrConfig']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest', 'DownloadFile']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);
    
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [BuildIrListComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: DealIrConfigService, useValue: mockedDealIrConfigService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {

    fixture = TestBed.createComponent(BuildIrListComponent);

    const dealIrConfigService = fixture.debugElement.injector.get(DealIrConfigService);
    
    spyOn(dealIrConfigService, 'getDealIrConfigList').and.callFake(() => {
      return of(dummyDealIrList); 
    });

    buildIrListComponent = fixture.componentInstance;
  
    //Set the Deal IR records
    buildIrListComponent.dealIrList = dummyDealIrList;
  });

  it('should create Deal Ir Config List component', () => {
    fixture.debugElement.injector.get(DealIrConfigService) as jasmine.SpyObj<DealIrConfigService>;
    
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;
    
    expect(buildIrListComponent).toBeDefined();
  });

  it('Verify the Deal IR Config List Title->', () => { 
    expect(buildIrListComponent.title).toBe('Build Investor Report');
  });

  it('should load/call Get Deal Ir Config List', async(() => {
    const dealIrConfigService = fixture.debugElement.injector.get(DealIrConfigService);

    //Call the component function
    buildIrListComponent.getDealIrList();

    //Validate/Test the result
    expect(expect(dealIrConfigService.getDealIrConfigList).toHaveBeenCalled).toBeTruthy();
    expect(expect(buildIrListComponent.getDealIrList).toHaveBeenCalled).toBeTruthy();
  }));

  it('should have defined grid component', () => {
    childFixture = TestBed.createComponent(SfpGridComponent);
    const childApp = childFixture.componentInstance;
    expect(childApp).toBeDefined();
  });

  it('should have delete record option on Build IR grid', () => {
    const dummyRecord = dummyDealIrList[0];
    const dealIrConfigService = fixture.debugElement.injector.get(DealIrConfigService);
    let result = 'success';
    const spy = spyOn(dealIrConfigService, 'deleteDealIrConfig').and.callFake(() => {
      return of(result); 
    });

    //Call the component function
    buildIrListComponent.onGridDeleteCallback(dummyRecord, buildIrListComponent);

    //Validate/Test the result
    expect(expect(dealIrConfigService.deleteDealIrConfig).toHaveBeenCalled).toBeTruthy();
    expect(spy).toHaveBeenCalled();
    expect(expect(buildIrListComponent.onGridDeleteCallback).toHaveBeenCalled).toBeTruthy();

  });

  it('should have IR Nae clickable for view the Deal IR record', () => {
    const dummyRecord = dummyDealIrList[0];

    //Call the component function
    const dealIrConfigService = fixture.debugElement.injector.get(DealIrConfigService);

    //Validate/Test the result
    expect(expect(buildIrListComponent.onTitleClickCallback).toHaveBeenCalled).toBeTruthy();

  });

  it('should have call the edit Deal IR on edit action button ', () => {
    const dummyRecord = dummyDealIrList[0];

    //Call the component function
    buildIrListComponent.onGridEditCallback(dummyRecord, buildIrListComponent);

    //Validate/Test the result
    expect(expect(buildIrListComponent.onGridEditCallback).toHaveBeenCalled).toBeTruthy();

  });

  // it('should have call the copy Deal IR Config on copy action button ', () => {
  //   const dummyRecord = dummyDealIrList[0];

  //   //Call the component function
  //   buildIrListComponent.onGridCopyCallback(dummyRecord, buildIrListComponent);

  //   //Validate/Test the result
  //   expect(expect(buildIrListComponent.onGridCopyCallback).toHaveBeenCalled).toBeTruthy();

  // });
});
