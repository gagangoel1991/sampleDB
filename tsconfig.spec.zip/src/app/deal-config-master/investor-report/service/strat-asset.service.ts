import { Injectable } from '@angular/core';
import { StratPreviewModel, AssetStratModel, StratPreviewSearchModel } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';

@Injectable()
export class StratAssetService {

    private readonly api_url = '/stratmgt';
    private readonly  currentAsset = window.localStorage.getItem('selectedAssetId');

    constructor(private globalHttpService: GlobalHttpService) { }

    public getStratList() : Observable<any>  {
        return this.globalHttpService.GetRequest(this.api_url + '/strats/');
    }

    public getConfigStratList() : Observable<any> {
        return this.globalHttpService.GetRequest(this.api_url + '/configStrats/'+ this.currentAsset.toString());
    }

    public getBespokeStratList(cb) {
        return this.globalHttpService.GetRequest(this.api_url + '/bespokeStrats/'+ this.currentAsset.toString()).subscribe(req => {
            cb(req);
        });
    }


    public getStrat(stratId: number): Observable<any> {

        return this.globalHttpService.GetRequest(this.api_url + '/stratsDtls/' + stratId.toString());
    }

    public insertStrat(stratDatailData: AssetStratModel): Observable<any> {

        return this.globalHttpService.PostRequest(this.api_url + '/saveStrat/'+ this.currentAsset.toString(), JSON.stringify(stratDatailData));
    }


    public deleteStrat(stratId: number): Observable<any> {
        return this.globalHttpService.DeleteRequest(this.api_url + '/deleteStrat', stratId);
    }

    public getMultiparameterSelectedList(listId: any): Observable<any> {
        return this.globalHttpService.PostRequest('/selectLookup', listId);
    }

    
    public getSelectedListFilterBased(filterId: any): Observable<any> {
        return this.globalHttpService.PutRequest('/selectLookup/GetSelectedListFilterBased',  filterId);
    }

    
    public getSelectLookupDealName(filterId: any): Observable<any> {
        return this.globalHttpService.PutRequest('/selectLookup/GetSelectLookupDealName',  filterId);
    }

    public getSelectedList(listId: string): Observable<any> {
        return this.globalHttpService.GetRequest('/selectLookup/selectList/' + listId);
    }

    public getStratPreviewData(stratPreviewSearchModel: StratPreviewSearchModel): Observable<any> {
        return this.globalHttpService.PostRequest(this.api_url + '/stratPreviewData', JSON.stringify(stratPreviewSearchModel));
    }

    public getBeSpokeStratPreviewData(stratPreviewSearchModel: StratPreviewSearchModel): Observable<any> {
        return this.globalHttpService.PostRequest(this.api_url + '/beSpokeStratPreviewData', JSON.stringify(stratPreviewSearchModel));
    }

    public GetBeSpokeAssetStratDetail(stratId: number) : Observable<any> {
        return this.globalHttpService.GetRequest(this.api_url + '/beSpokeStratDtl/' + stratId);
    }
}