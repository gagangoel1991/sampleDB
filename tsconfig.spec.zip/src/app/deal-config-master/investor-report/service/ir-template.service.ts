import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';

@Injectable()
export class IrTemplateService {

    private readonly api_url = '/ir';
    private readonly  currentAsset = window.localStorage.getItem('selectedAssetId');

    constructor(private globalHttpService: GlobalHttpService) {}
    
    public getIrTemplateList( reportTypeName: string) {
        return this.globalHttpService.GetRequest(this.api_url + '/template/list/' + this.currentAsset.toString() + "/" + reportTypeName);
    }

    public getIrTemplate(templateId: number, reportTypeName:string):Observable<any> {
        return this.globalHttpService.GetRequest(this.api_url + '/template/get',  {'templateId': templateId,'reportTypeName':reportTypeName});
    }

    //this is for updation based upon form data passed
    public saveIrTemplate(templateData: FormData, reportTypeName: string):Observable<any> {
        return this.globalHttpService.PostFormDataRequest(this.api_url + '/template/save/' + this.currentAsset.toString() + "/" + reportTypeName, templateData);
    }

    public deleteIrTemplate(templateId: number): Observable<any> {
        return this.globalHttpService.DeleteRequest(this.api_url + '/template/delete', templateId);
    }

    public downloadRIrTemplateFile(templateId: number, reportTypeName = ""): Observable<any> {
        return this.globalHttpService.DownloadFile(this.api_url + "/template/downloadtemplate", {'templateId': templateId,'reportTypeName':reportTypeName});
    }


}