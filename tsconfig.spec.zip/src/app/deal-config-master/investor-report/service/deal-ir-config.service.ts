import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { Observable } from 'rxjs';
import { IAuthWorkflowModel } from 'src/app/shared/model/auth-workflow-model';
import { GenerateReportModel } from 'src/app/shared/model/generate-report-model';

@Injectable()
export class DealIrConfigService {
    private readonly  currentAsset = window.localStorage.getItem('selectedAssetId');
    constructor(private globalHttpService: GlobalHttpService) { }

    public getDealIrConfigList(reportTypeName: string): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/getlist/" + this.currentAsset.toString() + "/" + reportTypeName);
    }

    public getDealIrConfig(dealIrConfigId: number): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/get", { 'dealIrConfigId': dealIrConfigId, 'AssetClassId': this.currentAsset.toString() });
    }

    public getIrConfigLayoutList(dealId: number): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/getIrConfigLayoutList", { 'dealId': dealId, 'AssetClassId': this.currentAsset.toString() }); 
      }

    public getIrConfigStratList(dealId: number): Observable<any> {
		return this.globalHttpService.GetRequest("/ir/buildir/getIrConfigStratList" , { 'dealId': dealId, 'AssetClassId': this.currentAsset.toString() }); 
    }

    public getIrConfigDealList(dealIrConfigId: number): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/getIrConfigDealList");
    }

    public saveDealIrConfig(dealIrConfig: any): Observable<any> {
        return this.globalHttpService.PostRequest("/ir/buildir/save/"+ this.currentAsset.toString(), JSON.stringify(dealIrConfig));
    }

    public deleteDealIrConfig(dealIrConfigId: number): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/delete", { 'dealIrConfigId': dealIrConfigId });
    }

    public getStratTemplateListLookup(): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/delete");
    }

    public getReportLayoutListLookup(): Observable<any> {
        return this.globalHttpService.GetRequest("/ir/buildir/delete");
    }

    //this is for updation based upon form data passed
    public uploadDealIR(dealIrTemplate: FormData): Observable<any> {
        return this.globalHttpService.PostFormDataRequest('/ir/buildir/upload/'+ this.currentAsset.toString(), dealIrTemplate);
    }

    public downloadIrTemplateFile(dealIrConfigId: number, asAtDate: string, templateId: number, assetId: string): Observable<any> {
        const generateReportModel = new GenerateReportModel(dealIrConfigId, asAtDate, templateId, assetId);
        return this.globalHttpService.DownloadFile("/ir/buildir/download", generateReportModel);
    }
 
    public manageDealIrAuthWorkflowByUser(model: IAuthWorkflowModel): Observable<any> {
        return this.globalHttpService.PostRequest('/ir/buildir/manageDealIRAuthWorkflowByUser', model);
    }

    public manageDealIrAuthWorkflow(model: IAuthWorkflowModel): Observable<any> {
        return this.globalHttpService.PostRequest('/ir/buildir/manageDealIRAuthWorkflow', model);
    }
}
