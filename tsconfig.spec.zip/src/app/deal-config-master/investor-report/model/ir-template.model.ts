import { NumberSymbol } from '@angular/common';
import { StringMap, StringMapWithRename } from '@angular/compiler/src/compiler_facade_interface';

export class IrTemplateModel {

    public templateId: number;
    public name: string;
    public description: string;
    public originalFileName: string;
    public uploadedFileName: string;
    public isLocked: number;
    public status: string;
    public createdBy: string;
    public createdDate: string;
    public dealTypeId: number;
    
    constructor(templateId: number,  name: string
        , description: string, originalFileName: string, uploadedFileName: string
        , isLocked: number, status: string, createdBy: string, createdDate: string
        , dealTypeId: number) {
        this.templateId = templateId;
        this.name = name;
        this.description = description;
        this.originalFileName = originalFileName;
        this.uploadedFileName = uploadedFileName;
        this.isLocked = isLocked;
        this.status = status;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.dealTypeId = dealTypeId;
    }
}
