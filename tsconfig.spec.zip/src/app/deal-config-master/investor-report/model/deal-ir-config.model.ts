import { DatepickerViewModel } from "@ng-bootstrap/ng-bootstrap/datepicker/datepicker-view-model";
import { RrStratMappedField } from 'src/app/deal-config-corporate/reference-registry-report/build-rr/models/rr-strat-mapped-field.model';
import { AdhocReportField } from 'src/app/pool-selection-master/adhoc-reporting/models/adhoc-report-field.model';

export class DealIrConfigModel {
    public iR_Config: IR_Config;
    public IR_ConfigDealList: Array<IR_ConfigDealList>
    public iR_ConfigLayoutList: Array<IR_ConfigLayoutList>;
    public iR_ConfigStartList: Array<IR_ConfigStartList>;
    public iR_MappedFieldList: Array<AdhocReportField>;

    constructor(iR_Config: IR_Config, IR_ConfigDealList: Array<IR_ConfigDealList>, iR_ConfigLayoutList: Array<IR_ConfigLayoutList>,
        iR_ConfigStartList: Array<IR_ConfigStartList>) {
        this.iR_Config = iR_Config;
        this.IR_ConfigDealList = IR_ConfigDealList;
        this.iR_ConfigLayoutList = iR_ConfigLayoutList;
        this.iR_ConfigStartList = iR_ConfigStartList;
    }
}

export class IR_Config {
    public name: string;
    public description: string;
    public dealId: number;
    public templateId: number;
    public isLocked: boolean;
    public originalFileName: string;
    public uploadedFileName: string;
    public templateFileName: string;
    public defaultFileName: string;
    public workFlowStepId: number;
    public authorizerComment : string;
    public authRequestorUserName : string;
    public draftRequestCreatedBy : string;
    public lastModifiedUserName : string;
    public lastModifiedDate : string;
    public status: string;
    public reportTypeId: number;
    public canShowSecurity:boolean;
    constructor(name: string, description: string, dealId: number,
        templateId: number, isLocked: boolean, workFlowStepId: number, authorizerComment: string,
        authRequestorUserName: string, draftRequestCreatedBy : string, lastModifiedUserName : string,
        status : string, lastModifiedDate: string,canShowSecurity:boolean) {
        this.name = name;
        this.description = description;
        this.dealId = dealId;
        this.templateId = templateId;
        this.isLocked = isLocked;
        this.workFlowStepId = workFlowStepId;
        this.authorizerComment = authorizerComment;
        this.authRequestorUserName = authRequestorUserName;
        this.draftRequestCreatedBy= draftRequestCreatedBy;
        this.lastModifiedUserName = lastModifiedUserName;
        this.status = status;
        this.lastModifiedDate = lastModifiedDate;
        this.canShowSecurity=canShowSecurity;
    }

}

export class IR_ConfigDealList {
    public dealId: number;
    public dealName: string;
    constructor(dealId: number, dealName: string) {
        this.dealId = dealId;
        this.dealName = dealName;
    }
}

export class IR_ConfigLayoutList {
    public templateId: number;
    public name: string;
}

export class IR_ConfigStartList {
    public dealIrStratMapId:number;
    public stratID: number;
    public stratTypeId: number;
    public name: string;
    public isSelected: boolean;
    public anchorCell: string;
    public isExcluded: boolean;
}

export class DealIrConfigModelOld {
    public dealIrConfigId: number;
    public name: string;
    public description: string;
    public stratTemplateId: number;
    public stratTemplateName: string;
    public reportLayoutId: number;
    public reportLayoutName: string;
    public dealId: number;
    public dealName: string;
    public originalFileName: string;
    public uploadedFileName: string;
    public workFlowStepId: number;
    public status: string;
    public isLocked: boolean;
    public createdBy: string;
    public createdDate: Date;
    public modifiedBy: string;
    public modifiedDate: Date;

    constructor(dealIrConfigId: number, name: string, description: string, stratTemplateId: number, stratTemplateName: string,
        reportLayoutId: number, reportLayoutName: string, dealId: number, dealName: string, originalFileName: string,
        uploadedFileName: string, workFlowStepId: number, status: string, isLocked: boolean,
        createdBy: string, createdDate: Date, modifiedBy: string, modifiedDate: Date) {
        this.dealIrConfigId = dealIrConfigId;
        this.name = name;
        this.description = description;
        this.stratTemplateId = stratTemplateId;
        this.stratTemplateName = stratTemplateName;
        this.reportLayoutId = reportLayoutId;
        this.reportLayoutName = reportLayoutName;
        this.dealId = dealId;
        this.dealName = dealName;
        this.originalFileName = originalFileName;
        this.uploadedFileName = uploadedFileName;
        this.workFlowStepId = workFlowStepId;
        this.status = status;
        this.isLocked = isLocked;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
    }
}

export class DealIrConfigAddEditEntity {

    public dealIrConfigId:number;
    public name: string;
    public description: string;
    public dealId: number;
    public templateId: number;
    public originalFileName: string;
    public uploadedFileName: string;
    public workFlowStepId: number;
    public dealIrStratMapList: Array<DealIrStratMapList>;
    public Action: string;
    public authorizerComment: string;
    public stratMappedFieldList: Array<RrStratMappedField>;
    public canShowSecurity:number;
    constructor(
        dealIrConfigId:number,
        name: string,
        description: string,
        dealId: number,
        templateId: number,
        originalFileName: string,
        uploadedFileName: string,
        workFlowStepId: number,
        dealIrStratMapList: Array<DealIrStratMapList>,
        Action: string,
        authorizerComment: string,
        stratMappedFieldList: Array<RrStratMappedField> = null,
        canShowSecurity : number=0
    ) {
        this.dealIrConfigId=dealIrConfigId;
        this.name = name;
        this.description = description;
        this.dealId = dealId;
        this.templateId = templateId;
        this.originalFileName = originalFileName;
        this.uploadedFileName = uploadedFileName;
        this.workFlowStepId = workFlowStepId;
        this.dealIrStratMapList = dealIrStratMapList;
        this.Action = Action;
        this.authorizerComment=authorizerComment;
        this.stratMappedFieldList = stratMappedFieldList;
        this.canShowSecurity=canShowSecurity;
    }
}


export class DealIrStratMapList {
    public dealIrStratMapId: number;
    public stratId: number;
    public anchorCell: string;
    constructor(dealIrStratMapId: number, stratId: number, anchorCell: string) {
        this.dealIrStratMapId = dealIrStratMapId;
        this.stratId = stratId;
        this.anchorCell = anchorCell;
    }
}
