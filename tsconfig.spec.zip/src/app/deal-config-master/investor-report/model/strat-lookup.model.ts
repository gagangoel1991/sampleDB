export class StratLookupModel{
    public stratId:number;
    public name:string;
    public description: string;
    public isSelected: boolean;
    public isExcluded: boolean;

    constructor(stratId:number, name:string, description: string, isSelected: boolean, isExcluded: boolean){
        this.stratId = stratId;
        this.name = name;
        this.description = description;
        this.isSelected = isSelected;
        this.isExcluded = isExcluded;
    }
}