import { NumberSymbol } from '@angular/common';


export enum SelectListEnum {
    DealList = 1,
    StratAttributeList = 2,
    MinOperatorList = 3,
    MaxOperatorList = 4,
    StratFieldDataType = 5,
    DealBusinessEndDate = 15,
    DealTypeList = 7,
    DealIpdBusinessEndDate = 18,
    EmailTypeList = 26
}


export class SelectLookupModel {
    public listId: number
    public text: string;
    public value: number;

    constructor(listId: number, value: number, text: string) {
        this.listId = listId;
        this.value = value;
        this.text = text;
    }
}

export class StratPreviewModel {
    public stratId: number
    public sortOrder: number;
    public headerText: string;
    public subHeaderText: string;
    public mortgageLoans: number;
    public mortgageLoansPercent: string;
    public totalOutCapitalBalance: number;
    public totalOutCapitalBalancePercent: string;
    public trueBalance: number;
    public trueBalancePercent: string;



    constructor(stratId: number, headerText: string, subHeaderText: string, mortgageLoans: number, mortgageLoansPercent: string
        , totalOutCapitalBalance: number, totalOutCapitalBalancePercent: string, trueBalance: number, trueBalancePercent: string) {
        this.stratId = stratId;
        //this.sortOrder = sortOrder;
        this.headerText = headerText;
        this.subHeaderText = subHeaderText;
        this.mortgageLoans = mortgageLoans;
        this.mortgageLoansPercent = mortgageLoansPercent;
        this.totalOutCapitalBalance = totalOutCapitalBalance;
        this.totalOutCapitalBalancePercent = totalOutCapitalBalancePercent;
        this.trueBalance = trueBalance;
        this.trueBalancePercent = trueBalancePercent;
    }
}


export class AssetStratModel {

    public stratId: number;
    public fieldId: number;
    public fieldName: string;
    public name: string;
    public description: string;
    public stratDataType: string;
    public isLocked: number;
    public stratStatus: string;
    public createdBy: string;
    public createdDate: string;
    public stratCriteriaList: StratConfigurationModel[];
    public stratDealTypeList: number[];

    constructor(stratId: number, fieldId: number, fieldName: string, name: string
        , description: string
        , stratDataType: string, isLocked: number, stratStatus: string, createdBy: string, createdDate: string) {
        this.stratId = stratId;
        this.fieldId = fieldId;
        this.fieldName = fieldName;
        this.name = name;
        this.description = description;
        this.stratDataType = stratDataType;
        this.isLocked = isLocked;
        this.stratStatus = stratStatus;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
    }
}

export class StratPreviewSearchModel {
    public ipdDate: string;
    public dealName: string;
    public fieldId: number;
    public stratCriteriaList: StratConfigurationModel[];
    public header: boolean;
    public stratName: string;
    public assetId: string;

    constructor(ipdDate: string, dealName: string, fieldId: number, header: boolean, stratName: string, assetId: string) {
        this.ipdDate = ipdDate;
        this.dealName = dealName;
        this.fieldId = fieldId;
        this.header = header;
        this.stratName = stratName;
        this.assetId = assetId;
    }
}

export class StratConfigurationModel {
    public id: number;
    public stratConfigId: number;
    public fromValue: number;
    public fromOperatorId: number;
    public toValue: number;
    public toOperatorId: number;
    public sortOrder: number;
    public fromOperator: string;
    public toOperator: string;
    public isValidRecord: boolean;


    constructor(id: number, stratConfigId: number, fromValue: number, fromOperatorId: number, toValue: number
        , toOperatorId: number, sortOrder: number, fromOperator: string, toOperator: string, isValidRecord: boolean) {
        this.id = id;
        this.stratConfigId = stratConfigId;
        this.fromValue = fromValue;
        this.fromOperatorId = fromOperatorId;
        this.toValue = toValue;
        this.toOperatorId = toOperatorId;
        this.sortOrder = sortOrder;
        this.fromOperator = fromOperator;
        this.toOperator = toOperator;
        this.isValidRecord = this.isValidRecord;
    }
}


