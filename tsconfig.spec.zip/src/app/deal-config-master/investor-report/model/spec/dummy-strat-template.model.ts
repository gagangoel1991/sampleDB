import { StratTemplateModel } from '../strat-template-model';

export const DummyStratTemplateModel: StratTemplateModel = 
    {
        stratTemplateId: 2,
        description: "For Dunmore Deal",
        name: "Dunmore Template-1",
        status: 'Active',
        stratList: [24, 3, 39, 4, 5, 6]
    };
