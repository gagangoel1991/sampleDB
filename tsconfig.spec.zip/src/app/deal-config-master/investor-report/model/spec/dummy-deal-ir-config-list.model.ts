import { DealIrConfigModel } from 'src/app/deal-config/investor-report/model/deal-ir-config.model';

export const DummyDealIrConfigList: DealIrConfigModel[] = [
    {
        iR_Config : { 
            authRequestorUserName: "",
            authorizerComment: null,
            dealId: 14,
            defaultFileName: "template-investor-report-ipd.xlsx",
            description: "Retest_2042",
            draftRequestCreatedBy: "",
            lastModifiedDate: "2021-07-02T07:21:02.153",
            lastModifiedUserName: "EUROPA\\issaram",
            name: "Retest_2042_091",
            originalFileName: null,
            status: "Draft",
            templateFileName: "Dunmore Sample Template- Investor Report_01.xlsx",
            templateId: 1,
            uploadedFileName: null,
            workFlowStepId: 1,
            isLocked: false
          },
          IR_ConfigDealList: [{dealId: 14, dealName: "ARDMORE1"}],
          iR_ConfigLayoutList: [{templateId: 1, name: "ARDMORE1"}],
          iR_ConfigStartList: [{anchorCell: "", dealIrStratMapId: 115, isSelected: true, name: "*Product Switch Report Inv", stratID: 22, stratTypeId: 1, isExcluded: false}]
    }
]
