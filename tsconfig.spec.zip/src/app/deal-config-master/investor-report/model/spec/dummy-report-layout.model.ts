import { IrTemplateModel } from '../ir-template.model';

export const DummyReportLayoutModel: IrTemplateModel = null;