import { StratTemplateListModel } from '../strat-template-list-model';

export const DummyStratTemplateList: StratTemplateListModel[] = [
    {
        stratTemplateId: 3, 
        name: "Ardmore Template-1", 
        description: "For Ardmore Deal", 
        assetStratCount: 2, 
        liabilityStratCount: 0,
        miscellaneousStratCount: 0,
        status: 'Active',
        createdBy: "Europa\sharapi",
        createdDate: new Date("2020-12-11"),
        modifiedBy: "Europa\\sharapi",
        modifiedDate: new Date("2020-12-11")
    },
    {
        stratTemplateId: 2, 
        name: "Dunmore Template-1", 
        description: "For Dunmore Deal", 
        assetStratCount: 4, 
        liabilityStratCount: 0,
        miscellaneousStratCount: 0,
        status: 'Locked',
        createdBy: "Europa\sharapi",
        createdDate: new Date("2020-12-11"),
        modifiedBy: "Europa\\sharapi",
        modifiedDate: new Date("2020-12-11")
    }
]
