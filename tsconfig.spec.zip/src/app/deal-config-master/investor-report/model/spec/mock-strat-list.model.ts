import { AssetStratModel } from 'src/app/deal-config/investor-report/model/strat-asset.model';

export const DummyStratList: AssetStratModel[] = [
    // {
    //     "stratId": 1,
    //     //"stratAttributeId": 1,
    //     "stratAttributeName": "CurrentLTV",
    //     "name": "CurrentLTV",
    //     "description": "CurrentLTV",
    //     "stratDataType": "NUMERIC",
    //     "isLocked": 0,
    //     "stratStatus": "Active",
    //     "stratConfigList": null,
    //     "createdDate": "2020-11-25T00:00:00",
    //     "createdBy": "System",
    // },
    // {
    //     "stratId": 2,
    //     "stratAttributeId": 2,
    //     "stratAttributeName": "RegionalDistribution",
    //     "name": "RegionalDistribution",
    //     "description": "RegionalDistribution",
    //     "stratDataType": "TEXT",
    //     "isLocked": 0,
    //     "stratStatus": "Active",
    //     "stratConfigList": null,
    //     "createdDate": "2020-11-25T00:00:00",
    //     "createdBy": "System",
    // },

];



export const StratDataModel: AssetStratModel =  null;
    // {
    //     "stratId": 1,
    //     "stratAttributeId": 1,
    //     "stratAttributeName": "CurrentLTV",
    //     "name": "CurrentLTV",
    //     "description": "CurrentLTV",
    //     "stratDataType": "NUMERIC",
    //     "isLocked": 0,
    //     "stratStatus": "Active",
    //     "stratConfigList": null,
    //     "createdDate": "2020-11-25T00:00:00",
    //     "createdBy": "System",
    // };




