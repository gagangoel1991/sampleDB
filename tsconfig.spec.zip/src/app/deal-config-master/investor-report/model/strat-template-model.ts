export class StratTemplateModel{
    public stratTemplateId:number;
    public name:string;
    public description: string;
    public stratList: Array<number>;
    public status: string;

    constructor(stratTemplateId:number, name:string, description: string, stratList: Array<number>, 
        status:string){
        this.stratTemplateId = stratTemplateId;
        this.name = name;
        this.description = description;
        this.stratList = stratList;
        this.status = status;
    }
}