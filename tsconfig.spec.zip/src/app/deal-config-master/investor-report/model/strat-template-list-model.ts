export class StratTemplateListModel{
    public stratTemplateId:number;
    public name:string;
    public description: string;
    public assetStratCount: number;
    public liabilityStratCount: number;
    public miscellaneousStratCount: number;
    public status: string;
    public createdBy:string;
    public createdDate:Date;
    public modifiedBy:string;
    public modifiedDate:Date;


    constructor(stratTemplateId:number, name:string, description: string, assetStratCount: number, liabilityStratCount: number,
        status:string, miscellaneousStratCount: number, createdBy:string, createdDate: Date, modifiedBy: string, modifiedDate: Date){
        this.stratTemplateId = stratTemplateId;
        this.name = name;
        this.description = description;
        this.assetStratCount = assetStratCount;
        this.liabilityStratCount = liabilityStratCount;
        this.miscellaneousStratCount = miscellaneousStratCount;
        this.status = status;
        this.createdBy = createdBy;
        this.createdDate = createdDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
    }
}