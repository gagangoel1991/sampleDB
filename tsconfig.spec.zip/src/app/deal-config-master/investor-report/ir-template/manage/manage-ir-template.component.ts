import { Component, Input, OnInit, ViewEncapsulation, EventEmitter, Output, ViewChild, ElementRef, ContentChild } from '@angular/core';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DatePipe } from '@angular/common';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { IrTemplateModel } from 'src/app/deal-config-master/investor-report/model/ir-template.model';
import { IrTemplateService } from 'src/app/deal-config-master/investor-report/service/ir-template.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { SelectLookupModel, SelectListEnum } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { StratAssetService } from 'src/app/deal-config-master/investor-report/service/strat-asset.service';
import { IrManageTemplateDealTypeDirective, IrManageTemplateDescriptionDirective, IrManageTemplateNameDirective, IrManageTemplateTitleDirective, IrManageTemplateUploadFileDirective } from './manage-ir-template.directive';


@Component({
    selector: 'ir-manage-template',
    //encapsulation: ViewEncapsulation.None,
    templateUrl: './manage-ir-template.component.html',
    styleUrls: ['./manage-ir-template.component.scss'],
    providers: [IrTemplateService, StratAssetService]
})

export class ManageIrTemplateComponent //extends CanDeactivateForm 
    implements OnInit {

    @ContentChild(IrManageTemplateTitleDirective) irManageTemplateTitleTemplate: IrManageTemplateTitleDirective;
    @ContentChild(IrManageTemplateDealTypeDirective) irManageTemplateDealTypeTemplate: IrManageTemplateDealTypeDirective;
    @ContentChild(IrManageTemplateNameDirective) irManageTemplateNameTemplate: IrManageTemplateNameDirective;
    @ContentChild(IrManageTemplateUploadFileDirective) irManageTemplateUploadFileTemplate: IrManageTemplateUploadFileDirective;
    @ContentChild(IrManageTemplateDescriptionDirective) irManageTemplateDescriptionTemplate: IrManageTemplateDescriptionDirective;

    @ViewChild('manageIrTemplateForm') manageIrTemplateForm: NgForm;
    @ViewChild('manageIrTemplateForm') confirmUnsavedForm: NgForm;
    @Output() notifyOnTemplateSave = new EventEmitter<string>();
    @Output() manageIrTemplateEvent = new EventEmitter<NgForm>();

    public templateDetails: IrTemplateModel = null;
    public title: string = '';
    public templateForm: FormGroup;
    public templateFileToUpload: File = null;
    public actionType: string = '';
    public templateFileUploadRequiredValidation: boolean = false;
    public templateFileUploadSizeValidation: boolean = false;
    public isRecordLocked: boolean = false;
    public templateId: number = 0;
    public templateAction: string = '';
    public isReadOnlyAccess: boolean = false;
    public isAddEditAccess: boolean = false;
    public isApprovRejectAccess: boolean = false;
    public isDeleteAccess: boolean = false;
    private datePipe = new DatePipe('en-UK');
    private readonly _dateFormat = 'yyyy-MM-dd';
    private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);
    private readonly _allowedFiles = ['xlsx'];
    public templateunsavedDetails: IrTemplateModel = null;

    private readonly _templateSaveValidationMessage = 'Please fill required fields marked with asterisk(*) before saving IR template.';
    private readonly _templateActionAdd = 'add';
    private readonly _templateActionEdit = 'edit';
    private readonly _templateActionCopy = 'copy';
    private readonly _templateActionView = 'view';
    private readonly _invalidAction = 'invalid';
    public _addTemplateTitle = 'Add IR Template';
    public _editTemplateTitle = 'Edit IR Template';
    public _lockedTemplateTitle = 'This IR Template is locked, you cannot edit this';
    public _copyTemplateTitle = 'Copy IR Template';
    public _viewTemplateTitle = 'View IR Template';
    private readonly _InvalidActionTitle = 'Resource is not available';
    public _viewTemplateListNavPath = '/dealconfig/ir/template/';
    public _fileUploadErrorMsg : string = '"Investor Report" sheet is missing from uploaded file.';
    private readonly _valueChangeMessage = "You have not changed any value.";


    //Messages
    private readonly _templateNotExist = 'IR template record is not exist.';
    private readonly _templateToastTitle = 'IR Template';
    private readonly _templateTitleDuplicateMsg = 'IR template name is already exist, should be unique';
    private readonly _templateSavedMsg = 'IR template is saved successfully.';
    private readonly _templateUpdatedMsg = 'IR template is updated successfully.';
    private readonly _templateFileSizeExceedMsg = 'IR template file size cannot exceed 20MB.';
    private readonly _templateFileInvalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file type is xlsx.';
    private readonly _templateFileDownloadedMsg = 'IR template file is successfully downloaded.';

    public canUpdate: boolean = false;
    public canView: boolean = false;
    public canDelete: boolean = false;
    public canAuthorized: boolean = false;
    public loggedInUser: string;
    public dealTypeList: Array<SelectLookupModel> = [];
    private assetId = window.localStorage.getItem('selectedAssetId');
    public _reportTypeName = "";
    public backButtonText = "View IR Template List";
    public IsSaveButtonClicked: boolean = false;
    constructor(
        private _templateService: IrTemplateService,
        private _toastservice: GlobalToasterService,
        private _route: ActivatedRoute,
        private _router: Router,
        private _stratService: StratAssetService,
        private _userService: UserRoleService) {
        //super();
        this._route.params.subscribe((params: Params) => {
            this.templateId = (params['templateId'] != null) ? params['templateId'] : null;
            this.templateAction = this._router.url.split('/')[5];
        });
    }


    InitializeData() {
        switch (this.templateAction) {
            case this._templateActionAdd:
                this.title = this._addTemplateTitle;
                this.actionType = this._templateActionAdd;
                this.addTemplatetInitialize();
                break;
            case this._templateActionEdit:
                this.title = this._editTemplateTitle;
                this.actionType = this._templateActionEdit;
                this.editCopyViewTemplateInitialize(this.templateId);
                break;
            case this._templateActionCopy:
                this.title = this._copyTemplateTitle;
                this.actionType = this._templateActionCopy;
                this.editCopyViewTemplateInitialize(this.templateId);
                break;
            case this._templateActionView:
                this.title = this._viewTemplateTitle;
                this.actionType = this._templateActionView;
                this.editCopyViewTemplateInitialize(this.templateId);
                break;
            default:
                this.title = this._InvalidActionTitle;
                this.actionType = this._invalidAction;
        }
    }

    ngOnInit() {

        this.setUpUserRolesAndPermissions();
        this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.View);
        this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.AddEdit);
        this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.ApproveReject);
        this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.Delete);

    }

    editCopyViewTemplateInitialize(templateId: number) {
        this._templateService.getIrTemplate(templateId, this._reportTypeName).subscribe(result => {
            console.log('Template record is fetched:');
            if (result) {
                this.templateDetails = result;


                if (this.canUpdate == true && this.actionType == 'view' && this.templateDetails.isLocked == 0) {
                    this.actionType = 'edit';
                    this.title = this._editTemplateTitle;
                }

                this.loadSelectList();

                if (this.actionType === this._templateActionCopy) {
                    this.templateDetails.name = 'Copy of ' + this.templateDetails.name;
                }


                if (this.templateDetails.isLocked) {
                    if (this.actionType === this._templateActionEdit) {
                        this.title = this._lockedTemplateTitle;
                        this.isRecordLocked = true;
                    }
                }

                this.templateunsavedDetails = JSON.parse(JSON.stringify(this.templateDetails));


            }
            else {
                this.title = this._templateNotExist;
                this.actionType = this._invalidAction;
            }

            setTimeout(() => { this.manageIrTemplateEvent.next(this.confirmUnsavedForm); }, 500);
        });
    }

    addTemplatetInitialize() {
        this.templateDetails = new IrTemplateModel(0, null, null, null, null, null, null, null, null, null);
        this.loadSelectList();
        this.templateDetails.dealTypeId = null;
        setTimeout(() => { this.manageIrTemplateEvent.next(this.confirmUnsavedForm); }, 500);
    }

    isEditTemplate() {
        return (this.actionType === this._templateActionEdit || this.actionType === this._templateActionCopy
            || this.actionType === this._templateActionView);
    }

    validateFormState() {
        if (this.manageIrTemplateForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateSaveValidationMessage);
            return false;
        }
        return true;
    }

    loadSelectList() {
        let multiListId = [SelectListEnum.DealTypeList]
        this._stratService.getMultiparameterSelectedList(multiListId).subscribe(result => {
            this.dealTypeList = result.filter(x => x.listId == SelectListEnum.DealTypeList);
        }, (error: any) => {
            console.log(error);
        });

    }

    //Saving the IR Template data
    onSaveIrTemplate() {
        this.IsSaveButtonClicked = true;
        if (this.manageIrTemplateForm.invalid) {
            this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateSaveValidationMessage);
            Object.keys(this.manageIrTemplateForm.form.controls).forEach((key) => {
                this.manageIrTemplateForm.form.get(key).markAsTouched();
            });

            if (this.manageIrTemplateForm.form.controls["uploadTemplateFile"].invalid)
                this.templateFileUploadRequiredValidation = true;
            else
                this.templateFileUploadRequiredValidation = false;
            this.IsSaveButtonClicked = false;
            return false;
        }
        //Saving the IR Template after all validations
        const formData: FormData = new FormData();
        if (this.templateFileToUpload) {
            formData.append('templateFileAsByte', this.templateFileToUpload, this.templateFileToUpload.name);
        }
        else {
            formData.append('templateFileAsByte', null);
            formData.append('originalFileName', this.templateDetails.originalFileName);
            formData.append('uploadedFileName', this.templateDetails.uploadedFileName);
        }

        //Add other details as well in the form data
        //Set the templateId as Zero in case of Copy action
        if (this.actionType === this._templateActionCopy)
            this.templateDetails.templateId = 0;

        formData.append('templateId', this.templateDetails.templateId.toString());
        formData.append('name', this.templateDetails.name.trim());
        formData.append('description', (this.templateDetails.description) ? this.templateDetails.description : '');
        formData.append('dealTypeId', this.templateDetails.dealTypeId.toString());
        formData.append('assetId', this.assetId);

        if (this.templateDetails.name.replace(/\s/g, "").toLowerCase().length <= 0) {
            this.manageIrTemplateForm.form.controls['templateName'].setErrors({ 'required': true });
        }
        else if (this.templateDetails.originalFileName == null || this.templateDetails.uploadedFileName == 'null') {
            this.templateFileUploadRequiredValidation = true;
        }
        else {

            if (this.actionType == this._templateActionEdit) {
                if (!this.CheckDataChange(this.templateunsavedDetails)) {
                    this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
                    this.IsSaveButtonClicked = false;
                    return;
                }
            }
            
            this._templateService.saveIrTemplate(formData, this._reportTypeName).subscribe(result => {
                this.IsSaveButtonClicked = false;
                if (result === -1) {//Duplicate IR Template title
                    this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateTitleDuplicateMsg);
                    //Mark the name control as invalid
                    this.manageIrTemplateForm.form.controls['templateName'].setErrors({ 'incorrect': true });
                }
                else if (result === -2) {//IR sheet is missing from the file Template
                    this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._fileUploadErrorMsg);
                }
                else {
                    console.log('Template Data is saved');
                    console.log(this.actionType);

                    if (this.templateDetails.templateId == 0) {
                        this.templateDetails.templateId = result.templateId;
                    }

                    //Below these two line will clear the changed state of the form so that user can 
                    //be redirected back to list page without alert.
                    this.manageIrTemplateForm.form.markAsPristine();
                    this.manageIrTemplateForm.form.markAsUntouched();
                    if (this.actionType == this._templateActionAdd || this.actionType == this._templateActionCopy) {
                        this._toastservice.openToast(ToasterTypes.success, this._templateToastTitle, this._templateSavedMsg);
                    }
                    else {
                        this._toastservice.openToast(ToasterTypes.success, this._templateToastTitle, this._templateUpdatedMsg);
                    }
                    this.viewTemplateList();
                }
            });
        }
        this.IsSaveButtonClicked = false;
    }

    private CheckDataChange(row: IrTemplateModel) {
        console.log(row);
        console.log(JSON.parse(JSON.stringify(this.templateDetails)))
        if (row.dealTypeId == this.templateDetails.dealTypeId && row.name == this.templateDetails.name &&
            row.templateId == this.templateDetails.templateId
            && row.uploadedFileName == this.templateDetails.uploadedFileName &&
            row.description == this.templateDetails.description) {
            return false;
        }
        else
            return true;
    }

    viewTemplateList() {
        //this._router.navigate([this._viewTemplateListNavPath], { relativeTo: this._route });
        this._router.navigate([this._viewTemplateListNavPath]);
    }

    validateUploadedFileExtension(fileName: string) {
        var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
        if (this._allowedFiles.some(x => x === ext.toLowerCase()))
            return true;
        else
            return false;
    }

    setTemplateFileUploadControlInvalid() {
        this.manageIrTemplateForm.form.controls["uploadTemplateFile"].markAsDirty();
        this.manageIrTemplateForm.form.controls["uploadTemplateFile"].markAsTouched();
        this.manageIrTemplateForm.form.controls["uploadTemplateFile"].setErrors({ 'incorrect': true });
        this.templateFileUploadRequiredValidation = true;
        this.templateDetails.originalFileName = '';
    }

    downloadTemplateFile() {
        this._templateService.downloadRIrTemplateFile(this.templateId, this._reportTypeName).subscribe(blob => {
            console.log('IR Template file blob');
            console.log(blob);
            const a = document.createElement('a');
            const objectUrl = URL.createObjectURL(blob);
            a.href = objectUrl
            a.download = this.templateDetails.originalFileName;
            a.click();
            URL.revokeObjectURL(objectUrl);
            this._toastservice.openToast(ToasterTypes.success, this._templateToastTitle, this._templateFileDownloadedMsg);
        });
    }

    handleTemplateFileInput(event: any, files: FileList) {
        if (event && event.target.files) {
            let file = event.target.files.item(0);

            if (!this.validateUploadedFileExtension(file.name)) {
                this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileInvalidFileFormatMsg);
                event.srcElement.value = '';
                this.setTemplateFileUploadControlInvalid();
                return false;
            }
            if (file.size > this._maxAllowedFileSiz) {
                this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileSizeExceedMsg);
                event.srcElement.value = '';
                this.setTemplateFileUploadControlInvalid();
                return false;
            }

            //When all validation passed, set the file name
            this.templateFileToUpload = file;
            this.templateDetails.originalFileName = this.templateFileToUpload.name;
            this.templateFileUploadRequiredValidation = false;
        }
    }


    setUpUserRolesAndPermissions() {
        this.loggedInUser = this._userService.getCurrentLoginUser();

        this.canView = this._userService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.View);
        this.canUpdate = this._userService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.AddEdit);
        this.canDelete = this._userService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.Delete);
        this.canAuthorized = this._userService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.ApproveReject);
    }


    getTitleTemplate() {
        return this.irManageTemplateTitleTemplate?.template;
    }
    getDealTypeTemplate() {
        return this.irManageTemplateDealTypeTemplate?.template;
    }
    getNameTemplate() {
        return this.irManageTemplateNameTemplate?.template;
    }
    getUploadFileTemplate() {
        return this.irManageTemplateUploadFileTemplate?.template;
    }
    getDescriptionTemplate() {
        return this.irManageTemplateDescriptionTemplate?.template;
    }
}
