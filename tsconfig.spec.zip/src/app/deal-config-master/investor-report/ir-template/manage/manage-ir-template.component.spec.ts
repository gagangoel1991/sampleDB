import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { ManageIrTemplateComponent} from './manage-ir-template.component';
import { IrTemplateService } from 'src/app/deal-config/investor-report/service/ir-template.service';
import { IrTemplateModel } from 'src/app/deal-config/investor-report/model/ir-template.model';
import { DummyReportLayoutModel } from 'src/app/deal-config/investor-report/model/spec/dummy-report-layout.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';
import { ActivatedRoute, Router, Params } from '@angular/router';

describe('ManageIrTemplateComponent', () => {
  let fixture: ComponentFixture<ManageIrTemplateComponent>;
  let layoutComponent: ManageIrTemplateComponent;
  let de: DebugElement;
  let compiledElement;

  const dummyReportLayoutList: any = DummyReportLayoutModel;
  //const dummyLayoutRecord: any = dummyReportLayoutList[0];
  
  beforeEach(async(() => {
    //spy object to mock
    const mockedDealListService = jasmine.createSpyObj('DealListService',['getDealNames']);
    const mockedReportLayoutService = jasmine.createSpyObj('ReportLayoutService',['getInvoice', 'saveInvoiceData', 'downloadInvoiceFile', 'getInvoiceCategoryType','getInvoiceCategory','getDealCounterparty', 'getDealNextIpd']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [ManageIrTemplateComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        
        , { provide: IrTemplateService, useValue: mockedReportLayoutService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
        ,{ provide: ActivatedRoute,
            useValue:{
                params: of({reportLayoutId: 1}),
                url: of('/dealconfig/ir/layout/edit/1')
            }
          }
      ]
    }).compileComponents();
    
  }));

  beforeEach(() => {
    // fixture = TestBed.createComponent(ManageIrTemplateComponent);
    // layoutComponent = fixture.componentInstance;
    // layoutComponent.actionType = 'edit';
    // layoutComponent.reportLayoutDetails = dummyLayoutRecord;
  });

  it('should create Manage Invoice component', () => {
    // const fixture = TestBed.createComponent(ManageIrTemplateComponent);
    // fixture.debugElement.injector.get(IrTemplateService) as jasmine.SpyObj<IrTemplateService>;
    //   fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;

    // // get the service
    // const layoutService = fixture.debugElement.injector.get(IrTemplateService);
   

    // //Prepare the dummy result
    // spyOn(layoutService, 'getReportLayout').and.callFake(() => {
    //   return of(dummyLayoutRecord); 
    // });

    // const reportLayoutCompopInstance = fixture.componentInstance;    

    // expect(reportLayoutCompopInstance).toBeDefined();
  });

  it('should be able to call the GetReportLayout function', () => {
    // get the service
    //const layoutService = fixture.debugElement.injector.get(IrTemplateService); 
   

    //Spy on service functions
    // spyOn(layoutService, 'getReportLayout').and.callFake(() => {
    //   return of(dummyLayoutRecord); 
    // });

    // //Call the component function
    // layoutComponent.editCopyViewReportLayoutInitialize(layoutComponent.reportLayoutDetails.reportLayoutId);

    // //Validate/Test the result
    // expect(expect(layoutService.getReportLayout).toHaveBeenCalled).toBeTruthy();
    // expect(expect(layoutComponent.editCopyViewReportLayoutInitialize).toHaveBeenCalled).toBeTruthy();
  });

  it('should be able to call the download layout file', () => {
    // get the service
    //const reportLayoutService = fixture.debugElement.injector.get(IrTemplateService);

    // spyOn(reportLayoutService, 'downloadReportLayoutFile').and.callFake(() => {
    //   return of([]); 
    // });
    // //mock the URL.createObjectURL
    // let windowOpenSpy = spyOn(window, 'open');
    // let urlCreateObjectSpy = spyOn(URL, 'createObjectURL').and.returnValue('');

    // //Call the component function
    // layoutComponent.downloadReportLayoutFile();

    // //Validate/Test the result
    // expect(expect(reportLayoutService.downloadReportLayoutFile).toHaveBeenCalled).toBeTruthy();
  });

});
