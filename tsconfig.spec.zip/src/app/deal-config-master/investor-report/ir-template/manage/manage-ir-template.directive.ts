import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[irManageTemplateTitle]'})
export class IrManageTemplateTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[irManageTemplateDealType]'})
export class IrManageTemplateDealTypeDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[irManageTemplateName]'})
export class IrManageTemplateNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[irManageTemplateUploadFile]'})
export class IrManageTemplateUploadFileDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[irManageTemplateDescription]'})
export class IrManageTemplateDescriptionDirective{
    constructor(public template:TemplateRef<any>){}
}