import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[irTemplateListTitle]'})
export class IrTemplateListTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[irTemplateListBtnCreateNew]'})
export class IrTemplateListBtnCreateNewDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[irTemplateListGrid]'})
export class IrTemplateListGridDirective{
    constructor(public template:TemplateRef<any>){}
}