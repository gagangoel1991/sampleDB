import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, Output, EventEmitter, ContentChild } from '@angular/core';
import { IrTemplateModel } from 'src/app/deal-config-master/investor-report/model/ir-template.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { IrTemplateService } from 'src/app/deal-config-master/investor-report/service/ir-template.service';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';

import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { actionPermissionButtonFormatter, downloadLinkFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { IrTemplateListTitleDirective, IrTemplateListBtnCreateNewDirective, IrTemplateListGridDirective } from './ir-template-list.directive';

@Component({
  selector: 'ir-template-list',
  templateUrl: './ir-template-list.component.html',
  styleUrls: ['./ir-template-list.component.scss'],
  providers: [IrTemplateService]
})
export class IrTemplateListComponent implements OnInit {

  @ContentChild(IrTemplateListTitleDirective) irTemplateListTitleTemplate: IrTemplateListTitleDirective;
  @ContentChild(IrTemplateListBtnCreateNewDirective) irTemplateListBtnCreateNewTemplate: IrTemplateListBtnCreateNewDirective;
  @ContentChild(IrTemplateListGridDirective) irTemplateListGridTemplate: IrTemplateListGridDirective;

  @Output() editRecord: EventEmitter<number> = new EventEmitter();

  public isCompLoad: boolean;
  public cachedirTemplateList: Array<IrTemplateModel> = [];
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  irTemplateList: Array<IrTemplateModel> = [];
  templateGridCustomCols: Array<SfpGridColumnModel> = [];
  templateGridActionLinks: Array<SfpGridActionModel> = [];
  templateGridExcludedCols: Array<string> = []
  public templateGridOptions: SfpGridOptionsModel = null;
  public title = 'IR Template List';
  public exportFileName = 'IRTemplateListData';
  public _reportTypeName = "";
  public _permission: PermissionEnum;
  public _templateToastTitle = "Download Template";

  public _templateStatus = 'Locked';
  public _templateLockedNotAllowedDeleteMsg = 'This IR Template is locked, you cannot delete this.';
  public _templateToasterTitle = 'IR Template';
  public _templateToasterDeleteMessage = 'IR template is Deleted Successfully!!'
  public _templateDeleteConfirmMsg = 'Are you sure you want to delete the {0} template?';
  public _templateFileDownloadedMsg = 'IR template file is successfully downloaded.';
  public _deleteConfirmMsgTitle = "Delete IR Template Data confirmation"
  public _deleteConfirmMsg = 'Delete IR Template';

  public _templateViewNavigationPath = '/dealconfig/ir/template/view/';
  public _templateEditNavigationPath = '/dealconfig/ir/template/edit/';
  public _templateCopyNavigationPath = '/dealconfig/ir/template/copy/';
  public _templateCreateNavigationPath = '/dealconfig/ir/template/add';

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  public slickDefaultAuditButtons: boolean = true;
  //-------Slick Grid Variables End--------------

  //constructor

  constructor(private router: Router, private _templateService: IrTemplateService,
    public _toastservice: GlobalToasterService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _sharedDataService: SharedDataService,
    private _userService: UserRoleService) {
    this.templateGridExcludedCols = ['templateId', 'isLocked', 'uploadedFileName']
  }



  showHideLoadingImage(isShow) {
    if (isShow)
      document.getElementById('preloader').style['display'] = 'block';
    else
      document.getElementById('preloader').style['display'] = 'none';
  }

  navigateToCreateNewTemplate(): void {
    this.router.navigate([this._templateCreateNavigationPath]);
  }

  ngOnInit(): void { }

  initializeData() {
    this.getuserPermission();
    this.configureIrTemplateGrid();
    this.loadTemplateList();
    this.bindIrTemplateListActionsCallBack();
  }

  loadTemplateList() {
    this.irTemplateList = [];
    this._templateService.getIrTemplateList(this._reportTypeName).subscribe(data => {
      console.log('IR Template List data is fetched');
      this.slickDataset = JSON.parse(JSON.stringify(data)); //deep copy  
      this.isCompLoad = true;
    });
  }


  configureIrTemplateGrid() {
    if (this.isAddEditAccess) {
      this.slickColumnArray.push(new SFP_SlickColumn('', 'Action', false, false, 110, FieldType.string,
        actionPermissionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 110))
    }

    this.slickColumnArray.push
      (
        //Preparing grid custom columns
        new SFP_SlickColumn('dealType', 'Deal Type', true, true, 150, FieldType.string),
        new SFP_SlickColumn('name', 'Template Name', true, true, 150, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('description', 'Description', true, true, 150, FieldType.string),
        new SFP_SlickColumn('originalFileName', 'Template File', true, true, 200, FieldType.string, downloadLinkFormatter),
        new SFP_SlickColumn('status', 'Status', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.singleSelect)
      );

    //SET EXPORT FILE NAME
    var myDt = new Date();
    var current_timestamp = myDt.getDate() + ' ' + (myDt.toLocaleString('default', { month: 'short' })) + ' ' + myDt.getFullYear();
    this.exportFileName = current_timestamp + '_IR Template List';
  }

  bindIrTemplateListActionsCallBack() {
    this.slickCallbackFuntions = new SFP_SlickAction(
      this.onGridTemplateViewCallback,
      this.onGridTemplateCopyCallback,
      this.onGridTemplateEditCallback,
      {
        deleteFunc: this.onGridTemplateDeleteCallback,
        title: this._deleteConfirmMsgTitle,
        message: template([this._deleteConfirmMsg], ` \'${'name'}\'.`)
      },
      this.onGridDownloadTemplateFileCallback
    );

  }

  onGridDownloadTemplateFileCallback(record: any, currentThis: any = this) {
    currentThis._templateService.downloadRIrTemplateFile(record.templateId, currentThis._reportTypeName).subscribe(blob => {
      console.log('IR Template file blob');
      console.log(blob);
      const a = document.createElement('a');
      const objectUrl = URL.createObjectURL(blob);
      a.href = objectUrl
      a.download = record.originalFileName;
      a.click();
      URL.revokeObjectURL(objectUrl);
      currentThis._toastservice.openToast(ToasterTypes.success, currentThis._templateToastTitle, currentThis._templateFileDownloadedMsg);
    });
  }

  onGridTemplateViewCallback(record: any, currentThis: any = this) {
    currentThis._router.navigate([currentThis._templateViewNavigationPath, record.templateId]);
  }

  onGridTemplateEditCallback(record: any, currentThis: any = this) {
    currentThis._router.navigate([currentThis._templateEditNavigationPath, record.templateId]);
  }
    
  onGridTemplateCopyCallback(record: any, currentThis: any = this) {
    currentThis._router.navigate([currentThis._templateCopyNavigationPath, record.templateId]);
  }


  onGridTemplateDeleteCallback(record: any, currentThis: any = this) {

    if (record.status === currentThis._templateStatus) {
      currentThis._toastservice.openToast(ToasterTypes.error, currentThis._templateToasterTitle, currentThis._templateLockedNotAllowedDeleteMsg);
      return;
    }

    var templateId = record.templateId;
    currentThis.showHideLoadingImage(true);
    currentThis._templateService.deleteIrTemplate(templateId).subscribe(result => {
      if (result === "-1") {
        currentThis._toastservice.openToast(ToasterTypes.error, currentThis._templateToasterTitle, currentThis._templateLockedNotAllowedDeleteMsg);
      }
      else {
        currentThis._toastservice.openToast(ToasterTypes.success, currentThis._templateToasterTitle, currentThis._templateToasterDeleteMessage);
      }
      currentThis.loadTemplateList();
      currentThis.showHideLoadingImage(false);
    });
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  getIrListTitleTemplate() {
    return this.irTemplateListTitleTemplate?.template;
  }
  getIrListBtnCreateTemplate() {
    return this.irTemplateListBtnCreateNewTemplate?.template;
  }
  getIrListGridTemplate() {
    return this.irTemplateListGridTemplate?.template;
  }

  getuserPermission() {
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[this._permission], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[this._permission], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[this._permission], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[this._permission], PermissionAccessTypeEnum.Delete);
  }
}
