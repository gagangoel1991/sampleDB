import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { IrTemplateListComponent } from 'src/app/deal-config-master/investor-report/ir-template/list/ir-template-list.component'
import { IrTemplateService } from 'src/app/deal-config-master/investor-report/service/ir-template.service';
import { IrTemplateModel } from 'src/app/deal-config-master/investor-report/model/ir-template.model';
import { SfpGridComponent } from 'src/app/shared/components/grid/sfp-grid.component';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { DummyReportLayoutModel } from 'src/app/deal-config-master/investor-report/model/spec/dummy-report-layout.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';

describe('IrTemplateListComponent', () => {
  let childFixture: ComponentFixture<SfpGridComponent>;
  let fixture: ComponentFixture<IrTemplateListComponent>;
  let reportLayoutComponent: IrTemplateListComponent;
  let de: DebugElement;
  let compiledElement;
  const dummyReportLayoutList: any = DummyReportLayoutModel;
 // const dummyLayoutRecord: any = dummyReportLayoutList[0];
    let datePipe = new DatePipe('en-UK');

  beforeEach(async(() => {
    //spy object to mock
    const mockedReportLayoutService = jasmine.createSpyObj('IrTemplateService',['getReportLayoutList','deleteReportLayout']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['PostRequest','GetRequest','DeleteRequest']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);
    
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [IrTemplateListComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: IrTemplateService, useValue: mockedReportLayoutService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    var dummyElement = document.createElement('div');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);

    fixture = TestBed.createComponent(IrTemplateListComponent);

    
    const reportLayoutService = fixture.debugElement.injector.get(IrTemplateService);
  
    reportLayoutComponent = fixture.componentInstance;
    
    //Set the strat record
    //reportLayoutComponent.reportLayoutList = dummyReportLayoutList;;
  });

  it('should create Strat Management list component', () => {
    fixture.debugElement.injector.get(IrTemplateService) as jasmine.SpyObj<IrTemplateService>;
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;
    
    expect(reportLayoutComponent).toBeDefined();
  });

  it('Verify the Report Layout Management Title->', () => { 
    expect(reportLayoutComponent.title).toBe('Report Layout Management');
  });

  

  it('should load/call strat list async', async(() => {
    const reportLayoutService = fixture.debugElement.injector.get(IrTemplateService);

    //Call the component function
    //reportLayoutComponent.loadReportLayoutList();

    //Validate/Test the result
    // expect(expect(reportLayoutService.getReportLayoutList).toHaveBeenCalled).toBeTruthy();
    // expect(expect(reportLayoutComponent.loadReportLayoutList).toHaveBeenCalled).toBeTruthy();
  }));

  it('should have defined grid component', () => {
    childFixture = TestBed.createComponent(SfpGridComponent);
    const childApp = childFixture.componentInstance;
    expect(childApp).toBeDefined();
  });


  it('should have delete record option on strat grid', () => {
    const dummyRecord = dummyReportLayoutList[0];
    const reportLayoutService = fixture.debugElement.injector.get(IrTemplateService);
    let result = 'success';
    // const spy = spyOn(reportLayoutService, 'deleteReportLayout').and.callFake(() => {
    //   return of(result); 
    // });

    // //Call the component function
    // reportLayoutComponent.onGridreportLayoutDeleteCallback(dummyRecord, reportLayoutComponent);

    //Validate/Test the result
    // expect(expect(reportLayoutService.deleteReportLayout).toHaveBeenCalled).toBeTruthy();
    // expect(spy).toHaveBeenCalled();
    // expect(expect(reportLayoutComponent.onGridreportLayoutDeleteCallback).toHaveBeenCalled).toBeTruthy();

  });

  it('should have Strat title clickable for edit the strat', () => {
    const dummyRecord = dummyReportLayoutList[0];

    //Call the component function
    //reportLayoutComponent.onGridReportLayoutEditCallback(dummyRecord, reportLayoutComponent);

    //Validate/Test the result
    //expect(expect(reportLayoutComponent.onGridReportLayoutEditCallback).toHaveBeenCalled).toBeTruthy();

  });
});
