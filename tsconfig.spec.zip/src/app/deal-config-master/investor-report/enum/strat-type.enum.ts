export enum StratTypeEnum {
    Asset = 1,
    Liability = 2,
    Miscellaneous = 3
}