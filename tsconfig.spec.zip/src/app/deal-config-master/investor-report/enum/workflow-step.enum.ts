export enum WorkFlowStepEnum {
    Draft = 1,
    SendForAuthorization = 2,
    Approved = 3,
    Rejected = 4,
    Closed = 5
}

