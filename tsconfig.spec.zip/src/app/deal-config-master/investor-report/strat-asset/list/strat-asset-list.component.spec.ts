import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { StratAssetListComponent } from 'src/app/deal-config-master/investor-report/strat-asset/list/strat-asset-list.component'
import { StratAssetService } from 'src/app/deal-config-master/investor-report/service/strat-asset.service';
import { AssetStratModel, SelectListEnum } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { SfpGridComponent } from 'src/app/shared/components/grid/sfp-grid.component';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { DummyStratList } from 'src/app/deal-config-master/investor-report/model/spec/mock-strat-list.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';

describe('StratAssetListComponent', () => {
  let childFixture: ComponentFixture<SfpGridComponent>;
  let fixture: ComponentFixture<StratAssetListComponent>;
  let stratComponent: StratAssetListComponent;
  let de: DebugElement;
  let compiledElement;
  const dummyStratList: any = DummyStratList;
  const dummyStratRecord: any = dummyStratList[0];
    let datePipe = new DatePipe('en-UK');

  beforeEach(async(() => {
    //spy object to mock
    const mockedStratAssetService = jasmine.createSpyObj('StratAssetService',['getStratList','deleteStrat']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['PostRequest','GetRequest','DeleteRequest']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);
    
    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [StratAssetListComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: StratAssetService, useValue: mockedStratAssetService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
      ]
    }).compileComponents();
  }));

  beforeEach(() => {
    var dummyElement = document.createElement('div');
    document.getElementById = jasmine.createSpy('HTML Element').and.returnValue(dummyElement);

    fixture = TestBed.createComponent(StratAssetListComponent);

    
    const stratAssetService = fixture.debugElement.injector.get(StratAssetService);
  
    stratComponent = fixture.componentInstance;
    
    //Set the strat record
    stratComponent.stratList = dummyStratList;;
  });

  it('should create Strat Management list component', () => {
    fixture.debugElement.injector.get(StratAssetService) as jasmine.SpyObj<StratAssetService>;
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;
    
    expect(stratComponent).toBeDefined();
  });

  it('Verify the Strat Management Title->', () => { 
    expect(stratComponent.title).toBe('Strat Management');
  });

  

  it('should load/call strat list async', async(() => {
    const stratAssetService = fixture.debugElement.injector.get(StratAssetService);

    //Call the component function
    stratComponent.loadStratList();

    //Validate/Test the result
    expect(expect(stratAssetService.getStratList).toHaveBeenCalled).toBeTruthy();
    expect(expect(stratComponent.loadStratList).toHaveBeenCalled).toBeTruthy();
  }));

  it('should have defined grid component', () => {
    childFixture = TestBed.createComponent(SfpGridComponent);
    const childApp = childFixture.componentInstance;
    expect(childApp).toBeDefined();
  });


  it('should have delete record option on strat grid', () => {
    const dummyRecord = dummyStratList[0];
    const stratAssetService = fixture.debugElement.injector.get(StratAssetService);
    let result = 'success';
    const spy = spyOn(stratAssetService, 'deleteStrat').and.callFake(() => {
      return of(result); 
    });

    //Call the component function
    stratComponent.onGridStratDeleteCallback(dummyRecord, stratComponent);

    //Validate/Test the result
    expect(expect(stratAssetService.deleteStrat).toHaveBeenCalled).toBeTruthy();
    expect(spy).toHaveBeenCalled();
    expect(expect(stratComponent.onGridStratDeleteCallback).toHaveBeenCalled).toBeTruthy();

  });

  it('should have Strat title clickable for edit the strat', () => {
    const dummyRecord = dummyStratList[0];

    //Call the component function
    stratComponent.onGridStratEditCallback(dummyRecord, stratComponent);

    //Validate/Test the result
    expect(expect(stratComponent.onGridStratEditCallback).toHaveBeenCalled).toBeTruthy();

  });
});
