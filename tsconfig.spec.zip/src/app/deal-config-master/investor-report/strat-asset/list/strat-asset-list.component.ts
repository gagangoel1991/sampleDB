import { Router, ActivatedRoute } from '@angular/router';
import { Component, OnInit, Output, EventEmitter, ContentChild } from '@angular/core';
import { AssetStratModel } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { StratAssetService } from 'src/app/deal-config-master/investor-report/service/strat-asset.service';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';

import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { actionPermissionButtonFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';
import { StratListConfigTabNameDirective, StratListCreateNewBtnDirective, StratListGridDirective, StratListNonConfigTabNameDirective, StratListTitleDirective } from './strat-asset-list.directive';

@Component({
  selector: 'ir-strat-asset-list',
  templateUrl: './strat-asset-list.component.html',
  styleUrls: ['./strat-asset-list.component.scss'],
  providers: [StratAssetService]
})
export class StratAssetListComponent implements OnInit {

  @ContentChild(StratListTitleDirective) StratListTitleTemplate: StratListTitleDirective;
  @ContentChild(StratListConfigTabNameDirective) StratListConfigTabNameTemplate: StratListConfigTabNameDirective;
  @ContentChild(StratListNonConfigTabNameDirective) StratListNonConfigTabNameTemplate: StratListNonConfigTabNameDirective;
  @ContentChild(StratListCreateNewBtnDirective) StratListCreateNewBtnTemplate: StratListCreateNewBtnDirective;
  @ContentChild(StratListGridDirective) StratListGridTemplate: StratListGridDirective;
    

  @Output() editRecord: EventEmitter<number> = new EventEmitter();

  public isCompLoad: boolean;
  public cachedStratList: Array<AssetStratModel> = [];
  stratList: Array<AssetStratModel> = [];
  bespokeStratList: Array<AssetStratModel> = [];
  stratGridCustomCols: Array<SfpGridColumnModel> = [];
  bespokeStratGridCustomCols: Array<SfpGridColumnModel> = [];
  stratGridActionLinks: Array<SfpGridActionModel> = [];
  stratGridExcludedCols: Array<string> = []
  public stratGridOptions: SfpGridOptionsModel = null;
  public bespokeStratGridOptions: SfpGridOptionsModel = null;
  title = 'Asset Strats List';
  public exportFileName = 'AssetStratsListData';
  public exportFileNameNonConfig = 'NonConfigAssetStratsListData';

  private readonly _stratToasterTitle = 'Strat';
  private readonly _stratToasterDeleteMessage = 'Strat Deleted Successfully!!'
  private readonly _stratDeleteConfirmMsg = 'Are you sure you want to delete the {0} strat?';
  private readonly _stratStatus = 'Locked';
  private readonly _stratLockedNotAllowedDeleteMsg = 'Strat is locked, you cannot delete this strat.';

  public _assetStartViewPath = '/dealconfig/ir/assetstrat/configlist/view/';
  public _assetStratEditPath = '/dealconfig/ir/assetstrat/configlist/edit/';
  public _assetStratCopyPath = '/dealconfig/ir/assetstrat/configlist/copy/';
  public _nonConfigAssetStratViewPath = '/dealconfig/ir/assetstrat/nonconfiglist/view/';
  public  _assetStratAddPath = '/dealconfig/ir/assetstrat/configlist/create';

  public stratType: string;
  public isNonConfigTab: boolean;
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;



  //-------Slick Grid Variables Start--------------
  public slickConfigColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickConfigDataset: any[];
  public slickConfigCallbackFuntions: SFP_SlickAction;
  public slickConfigDefaultActionButtons: boolean = false;
  public slickConfigDefaultAuditButtons: boolean = true;
  public slickConfigHeight: string = "calc(100vh - 65px)";
  //----------------
  public slickNonConfigColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickNonConfigDataset: any[];
  public slickNonConfigCallbackFuntions: SFP_SlickAction;
  public slickNonConfigDefaultActionButtons: boolean = false;
  // public slickNonConfigHeight: string = "calc(100vh - 70px)";
  //-------Slick Grid Variables End--------------

  public isConfigTabDisabled = false;
  constructor(private router: Router, private _StratAssetService: StratAssetService,
    public _toastservice: GlobalToasterService,
    private _route: ActivatedRoute,
    private _sharedDataService: SharedDataService,
    private _router: Router,
    private _userService: UserRoleService) {
    this.stratGridExcludedCols = ['stratId', 'fieldId', 'isLocked'];
    this.stratType = this._route.snapshot.paramMap.get('stratType');
    this.isNonConfigTab = this.stratType == 'nonconfiglist' ? true : false;
  }



  showHideLoadingImage(isShow) {
    if (isShow)
      document.getElementById('preloader').style['display'] = 'block';
    else
      document.getElementById('preloader').style['display'] = 'none';
  }

  navigateToCreateStrat(): void { 
    this.router.navigate([this._assetStratAddPath]);
  }


  ngOnInit(): void {
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.Delete);

    this.configureStratGrid();
    this.configureBespokeStratGrid();


    this.loadStratList();
    this.loadBespokeStratList();


    this.bindStratConfigActionsCallBack();
    this.bindStratNonConfigActionsCallBack();
  }


  loadStratList() {
    this.stratList = [];
    this._StratAssetService.getConfigStratList().subscribe(data => {
      this.slickConfigDataset = JSON.parse(JSON.stringify(data));
    });
  }



  loadBespokeStratList() {
    this.bespokeStratList = [];
    this._StratAssetService.getBespokeStratList(data => {
      this.slickNonConfigDataset = JSON.parse(JSON.stringify(data));
    });
    this.isCompLoad = true;
  }


  configureStratGrid() {
    if (this.isAddEditAccess) {
      this.slickConfigColumnArray.push(new SFP_SlickColumn('', 'Action', false, false, 110, FieldType.string,
        actionPermissionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 110))
    }
    this.slickConfigColumnArray.push
      (
        // Preparing grid custom columns
        new SFP_SlickColumn('dealTypeNames', 'Deal Type', true, true, 100, FieldType.string),
        new SFP_SlickColumn('name', 'Strat Name', true, true, 150, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('fieldName', 'Strat Field', true, true, 150, FieldType.string),
        new SFP_SlickColumn('description', 'Description', true, true, 100, FieldType.string),
        new SFP_SlickColumn('stratDataType', 'Type', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.singleSelect),
        new SFP_SlickColumn('stratStatus', 'Status', true, true, 100, FieldType.string)
      );

      //SET EXPORT FILE NAME
      var myDt = new Date();
      var current_timestamp = myDt.getDate() +' '+ (myDt.toLocaleString('default', { month: 'short' })) +' '+  myDt.getFullYear();
      this.exportFileName = current_timestamp + '_Asset Strats List';
  }


  configureBespokeStratGrid() {

    this.slickNonConfigColumnArray.push
      (
        // Preparing grid custom columns
        new SFP_SlickColumn('dealTypeNames', 'Deal Type', true, true, 100, FieldType.string),
        new SFP_SlickColumn('name', 'Strat Name', true, true, 150, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('fieldName', 'Strat Field', true, true, 150, FieldType.string),
        new SFP_SlickColumn('description', 'Description', true, true, 50, FieldType.string),
        new SFP_SlickColumn('stratDataType', 'Type', true, true, 50, FieldType.string, undefined, SFP_SlickFilterType.singleSelect),
        new SFP_SlickColumn('stratStatus', 'Status', true, true, 50, FieldType.string),
        new SFP_SlickColumn('createdBy', 'Created By', true, true, 50, FieldType.string),
        new SFP_SlickColumn('createdDate', 'Created Date', true, true, 50, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true)
      );

       //SET EXPORT FILE NAME
       var myDt = new Date();
       var current_timestamp = myDt.getDate() +' '+ (myDt.toLocaleString('default', { month: 'short' })) +' '+  myDt.getFullYear();
       this.exportFileNameNonConfig = current_timestamp + '_NonConfig Asset Strats List';
  }



  bindStratConfigActionsCallBack() {
    var objSFP_SlickAction = new SFP_SlickAction(
      this.onGridStratViewCallback,
      this.onGridStratCopyCallback,
      this.onGridStratEditCallback,
      {
        deleteFunc: this.onGridStratDeleteCallback,
        title: "Delete Strat Data confirmation",
        message: template`Are you sure you want to delete strat  \'${'name'}\'.`
      }
    );
    this.slickConfigCallbackFuntions = objSFP_SlickAction;
  }




  bindStratNonConfigActionsCallBack() {
    this.slickNonConfigCallbackFuntions = new SFP_SlickAction(
      this.onGridBespokeStratViewCallback
    );
  }


  onGridStratViewCallback(record: any, currentThis: any = this) {
    currentThis._router.navigate([currentThis._assetStartViewPath, record.stratId]);
  }


  onGridBespokeStratViewCallback(record: any, currentThis: any = this) {
    console.log('View Strat id : ' + record.stratId.toString()); 
    currentThis._router.navigate([currentThis._nonConfigAssetStratViewPath, record.stratId]);
  }


  onGridStratEditCallback(record: any, currentThis: any = this) {
    console.log('Edit Strat id : ' + record.stratId.toString());
    currentThis._router.navigate([currentThis._assetStratEditPath, record.stratId]);
  }

  onGridStratCopyCallback(record: any, currentThis: any = this) {
    console.log('Copy Strat id : ' + record.stratId.toString());
    currentThis._router.navigate([currentThis._assetStratCopyPath, record.stratId]);
  }


  onGridStratDeleteCallback(record: any, currentThis: any = this) {
    var stratId = record.stratId;

    if (record.stratStatus === currentThis._stratStatus) {
      currentThis._toastservice.openToast(ToasterTypes.error, currentThis._stratToasterTitle, currentThis._stratLockedNotAllowedDeleteMsg);
      return;
    }

    currentThis._StratAssetService.deleteStrat(stratId).subscribe(result => {
      currentThis._toastservice.openToast(ToasterTypes.success, 'Strat', 'Strat is deleted successfully');
      currentThis.loadStratList();
    });

  }


  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  getTitleTemplate() {
    return this.StratListTitleTemplate?.template;
  }
  getConfigTabNameTemplate() {
    return this.StratListConfigTabNameTemplate?.template;
  }
  getNonConfigTabNameTemplate() {
    return this.StratListNonConfigTabNameTemplate?.template;
  }
  getCreateNewBtnTemplate() {
    return this.StratListCreateNewBtnTemplate?.template;
  }
  getGridTemplate() {
    return this.StratListGridTemplate?.template;
  }
  
}
