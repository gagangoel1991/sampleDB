import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[stratListTitle]'})
export class StratListTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[stratListConfigTabName]'})
export class StratListConfigTabNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[stratListNonConfigTabName]'})
export class StratListNonConfigTabNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[stratListCreateNewBtn]'})
export class StratListCreateNewBtnDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[stratListGrid]'})
export class StratListGridDirective{
    constructor(public template:TemplateRef<any>){}
}