import { Variable } from '@angular/compiler/src/render3/r3_ast';
import { Component, ContentChild, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { Router } from '@angular/router';
import { subString } from 'src/app/shared/pipes/sub-string.pipe';
import { AssetStratModel, SelectListEnum, SelectLookupModel, StratPreviewSearchModel } from '../../model/strat-asset.model';
import { BespokeModel, BespokeUIModel } from "src/app/deal-config-master/model/bespoke.model";
import { StratAssetService } from '../../service/strat-asset.service';
import { NgForm } from '@angular/forms';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DatePipe } from '@angular/common';
import { ViewNonConfigStratCreatedByDirective, ViewNonConfigStratCreatedDateDirective, ViewNonConfigStratDescriptionDirective, ViewNonConfigStratEndDateDirective, ViewNonConfigStratFieldDirective, ViewNonConfigStratPreviewDirective, ViewNonConfigStratResultTblDirective, ViewNonConfigStratSelectDealDirective, ViewNonConfigStratStatusDirective, ViewNonConfigStratTypeDirective } from './view-non-config-strat.directive';

@Component({
  selector: 'sfp-view-non-config-strat',
  templateUrl: './view-non-config-strat.component.html',
  styleUrls: ['./view-non-config-strat.component.scss'],
  providers: [StratAssetService, subString, DatePipe],
  encapsulation: ViewEncapsulation.None,

})
export class ViewNonConfigStratComponent implements OnInit {

  @ContentChild(ViewNonConfigStratPreviewDirective) ViewNonConfigStratPreviewTemplate: ViewNonConfigStratPreviewDirective;
  @ContentChild(ViewNonConfigStratFieldDirective) ViewNonConfigStratFieldTemplate: ViewNonConfigStratFieldDirective;
  @ContentChild(ViewNonConfigStratDescriptionDirective) ViewNonConfigStratDescriptionTemplate: ViewNonConfigStratDescriptionDirective;
  @ContentChild(ViewNonConfigStratStatusDirective) ViewNonConfigStratStatusTemplate: ViewNonConfigStratStatusDirective;
  @ContentChild(ViewNonConfigStratTypeDirective) ViewNonConfigStratTypeTemplate: ViewNonConfigStratTypeDirective;
  @ContentChild(ViewNonConfigStratCreatedByDirective) ViewNonConfigStratCreatedByTemplate: ViewNonConfigStratCreatedByDirective;
  @ContentChild(ViewNonConfigStratCreatedDateDirective) ViewNonConfigStratCreatedDateTemplate: ViewNonConfigStratCreatedDateDirective;
  @ContentChild(ViewNonConfigStratSelectDealDirective) ViewNonConfigStratSelectDealTemplate: ViewNonConfigStratSelectDealDirective;
  @ContentChild(ViewNonConfigStratEndDateDirective) ViewNonConfigStratEndDateTemplate: ViewNonConfigStratEndDateDirective;
  @ContentChild(ViewNonConfigStratResultTblDirective) ViewNonConfigStratResultTblTemplate: ViewNonConfigStratResultTblDirective;
 
  public dealNameList: Array<SelectLookupModel> = [];
  public objBeSpokeModel: BespokeModel = new BespokeModel();
  public objBeSpokeUIModel: BespokeUIModel = new BespokeUIModel();

  public loadStartedCallsCount = 0;
  public loadCompletedCallsCount = 0;
  public previewStartedCalls = 0;
  public previewCompletedCalls = 0;

  public selectedDeal = null;
  public dealBusinessEndDateList: Array<SelectLookupModel> = [];
  public selectedDealBusinessEndDateList: Array<SelectLookupModel> = [];
  public selectedIpdDate: string = null;
  public selectedDealForIpd: number = null;

  public stratID: number;
  public objAssetStratModel: AssetStratModel;

  public todayDate: Date = new Date;
  private  assetId = window.localStorage.getItem('selectedAssetId');

  @ViewChild('stratSearchForm') stratForm: NgForm;

  public _viewStratListNavPath = '/dealconfig/ir/assetstrat/nonconfiglist';
  private readonly _toastTitle = 'Preview Non-Configurable Strat';
  private readonly _toastValidationMessage = "Please fill all required fields.";
  private readonly _toastDateValidationMessage = "Please select collection end date less than or equal to current system date.";
  private readonly _toastInvalidStartIdMessage = "Invalid Start Id.";

  constructor(private _stratService: StratAssetService, private _router: Router,
    private _toastservice: GlobalToasterService, private datePipe: DatePipe) {
    this.objAssetStratModel = new AssetStratModel(null, null, null, null, null, null, null, null, null, null);
    this.stratID = parseInt(this._router.url.split('/')[7]);
    if (isNaN(this.stratID)) {
      this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._toastInvalidStartIdMessage);
      this._router.navigate([this._viewStratListNavPath]);
    }
  }


  ngOnInit(): void {
    this.loadDealList();
    this.loadBespokeStrat();
  }

  loadDealList() {
    this.loadStartedCallsCount = this.loadStartedCallsCount + 1;
    let multiListId = [ SelectListEnum.DealBusinessEndDate]
    this._stratService.getMultiparameterSelectedList(multiListId).subscribe(
      result => {
        this.dealBusinessEndDateList = result.filter(x => x.listId == SelectListEnum.DealBusinessEndDate);
        console.log(this.dealBusinessEndDateList);
      },
      undefined,
      () => {
        this.loadCompletedCallsCount = this.loadCompletedCallsCount + 1;
      });
  }

  
  loadDealNameSelectList() {
    let filterId = this.objAssetStratModel.stratDealTypeList;
    this._stratService.getSelectLookupDealName(filterId).subscribe(result => {
      this.dealNameList = result.filter(x => x.listId == SelectListEnum.DealList);
    }, (error: any) => {
      console.log(error);
    });

  }

  loadBespokeStrat() {
    this.loadStartedCallsCount = this.loadStartedCallsCount + 1;
    this._stratService.GetBeSpokeAssetStratDetail(this.stratID).subscribe(
      result => {
        this.objAssetStratModel = result;
        this.loadDealNameSelectList() 
      },
      undefined,
      () => {
        this.loadCompletedCallsCount = this.loadCompletedCallsCount + 1;
      });
  }

  GetPreviewData() {
    if (new Date(this.selectedIpdDate) > this.todayDate) {
      this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._toastDateValidationMessage);
      this.selectedIpdDate = null; 
      return;     
    }
    else if (this.stratForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this._toastTitle, this._toastValidationMessage);
      Object.keys(this.stratForm.form.controls).forEach((key) => {
        this.stratForm.form.get(key).markAsTouched();
      });     
      return;
    }

    let selectedIpdDate = this.datePipe.transform(this.selectedIpdDate, 'yyyy-MM-dd');
    let obj = new StratPreviewSearchModel(selectedIpdDate, this.selectedDeal, this.objAssetStratModel.fieldId, true, this.objAssetStratModel.fieldName, this.assetId);

      this.previewStartedCalls = this.previewStartedCalls + 1;
      this._stratService.getBeSpokeStratPreviewData(obj).subscribe(
        result => {
          //Deep Copy
          this.objBeSpokeModel = JSON.parse(JSON.stringify(result));
          this.PrepareTableGroupHeader();
          this.PrepareTableHeader();
          this.PrepareTableData();
        },
        undefined,
        () => {
          this.previewCompletedCalls = this.previewCompletedCalls + 1;
        }
      );
    }

  PrepareTableGroupHeader() {
    //Deep Copy
    this.objBeSpokeUIModel.groupHeader = JSON.parse(JSON.stringify(this.objBeSpokeModel.header));

    if (!(this.objBeSpokeUIModel.groupHeader === null)){
    let maxColumnCount = Object.keys(this.objBeSpokeModel.data[0]).length;

    //Inserting missing Group Header Columns
    for (let i = 1; i <= maxColumnCount; i++) {
      var elem = this.objBeSpokeUIModel.groupHeader.find(element => element.columnNo == i);
      if (elem == undefined)
        this.objBeSpokeUIModel.groupHeader.push({ header: "", columnNo: i, columnSpan: 1 });
      else
        i = i + elem.columnSpan - 1;
    }

    //Sorting Group Header Columns by Column Number
    this.objBeSpokeUIModel.groupHeader.sort(function (a, b) {
      if (a.columnNo < b.columnNo) { return -1; }
      if (a.columnNo > b.columnNo) { return 1; }
      return 0;
    });
  }
  

  }

  PrepareTableHeader() {
    //Preserved Keys Order
    
    
      this.objBeSpokeUIModel.header = Object.keys(this.objBeSpokeModel.data[0]);
  }

  PrepareTableData() {
    //Nested Rows and Columns array
    
      this.objBeSpokeUIModel.data = JSON.parse(JSON.stringify(this.objBeSpokeModel.data));

      for (const [key, value] of Object.entries(this.objBeSpokeUIModel.data)) {
        this.objBeSpokeUIModel.data[key] = Object.values(value);
      }
    
  }

  navigateToViewStratList(): void {
    this._router.navigate([this._viewStratListNavPath]);
  }


  generatePreview() {
    this.GetPreviewData();
  }


  onDealSelectDropDownChange(event: any) {
    this.selectedDealForIpd = null;
    this.selectedDealBusinessEndDateList =[];
    if (event){
      this.selectedDealBusinessEndDateList = this.dealBusinessEndDateList.filter(x => x.value == event.value);
      this.selectedDealBusinessEndDateList.sort((val1, val2)=> {return +new Date(val2.text) - +new Date(val1.text)});
    }
  }

  
  onDealClosingEndDate(event: any): boolean {
    this.selectedIpdDate = null; 
    if (event){
      this.selectedIpdDate = event.text;
     }
    return true;
  }

  getPreviewTemplate() {
    return this.ViewNonConfigStratPreviewTemplate?.template;
  }
  getFieldTemplate() {
    return this.ViewNonConfigStratFieldTemplate?.template;
  }
  getDescriptionTemplate() {
    return this.ViewNonConfigStratDescriptionTemplate?.template;
  }
  getStatusTemplate() {
    return this.ViewNonConfigStratStatusTemplate?.template;
  }
  getTypeTemplate() {
    return this.ViewNonConfigStratTypeTemplate?.template;
  }
  getCreatedByTemplate() {
    return this.ViewNonConfigStratCreatedByTemplate?.template;
  }
  getCreatedDateTemplate() {
    return this.ViewNonConfigStratCreatedDateTemplate?.template;
  }
  getSelectDealTemplate() {
    return this.ViewNonConfigStratSelectDealTemplate?.template;
  }
  getEndDateTemplate() {
    return this.ViewNonConfigStratEndDateTemplate?.template;
  }
  getResultTblTemplate() {
    return this.ViewNonConfigStratResultTblTemplate?.template;
  }

}