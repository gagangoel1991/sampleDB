import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[viewNonConfigStratPreview]'})
export class ViewNonConfigStratPreviewDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratField]'})
export class ViewNonConfigStratFieldDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratDescription]'})
export class ViewNonConfigStratDescriptionDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratStatus]'})
export class ViewNonConfigStratStatusDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratType]'})
export class ViewNonConfigStratTypeDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratCreatedBy]'})
export class ViewNonConfigStratCreatedByDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratCreatedDate]'})
export class ViewNonConfigStratCreatedDateDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratSelectDeal]'})
export class ViewNonConfigStratSelectDealDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratEndDate]'})
export class ViewNonConfigStratEndDateDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[viewNonConfigStratResultTbl]'})
export class ViewNonConfigStratResultTblDirective{
    constructor(public template:TemplateRef<any>){}
}