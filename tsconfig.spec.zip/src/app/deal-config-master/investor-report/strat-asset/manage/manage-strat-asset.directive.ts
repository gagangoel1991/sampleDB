import { Directive, TemplateRef } from '@angular/core';

@Directive({selector :'[manageStratDetailsTab]'})
export class ManageStratDetailsTabDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratPreviewTab]'})
export class ManageStratPreviewTabDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratTitle]'})
export class ManageStratTitleDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageDealType]'})
export class ManageStratDealTypeDirective{
    constructor(public template:TemplateRef<any>){}
}
 
@Directive({selector :'[manageStratFieldName]'})
export class ManageStratFieldNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratName]'})
export class ManageStratNameDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratDescription]'})
export class ManageStratDescriptionDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratConfigDetails]'})
export class ManageStratConfigDetailsDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratSelectDeal]'})
export class ManageStratSelectDealDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratCollectionEndDate]'})
export class ManageStratCollectionEndDateDirective{
    constructor(public template:TemplateRef<any>){}
}

@Directive({selector :'[manageStratGrid]'})
export class ManageStratGridDirective{
    constructor(public template:TemplateRef<any>){}
}