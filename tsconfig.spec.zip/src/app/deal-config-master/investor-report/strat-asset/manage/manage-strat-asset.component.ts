import { ActivatedRoute, Router, Params } from '@angular/router';
import { Component, Input, OnInit, ViewEncapsulation, EventEmitter, Output, ViewChild, ElementRef, ContentChild } from '@angular/core';
import { DatePipe } from '@angular/common';
import { NgbModal, NgbModalOptions } from '@ng-bootstrap/ng-bootstrap';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SelectLookupModel, AssetStratModel, StratPreviewModel, StratConfigurationModel, StratPreviewSearchModel } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { SelectListEnum } from 'src/app/deal-config-master/investor-report/model/strat-asset.model';
import { SfpDropDownConfigModel } from 'src/app/shared/components/dropdown/sfp-drop-down-config.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel, CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { StratAssetService } from 'src/app/deal-config-master/investor-report/service/strat-asset.service';
import { FormBuilder, FormGroup, Validators, NgForm } from '@angular/forms';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { PermissionEnum } from '../../../../shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from '../../../../shared/model/user-permission-accesstype.enum';

import {
  AngularGridInstance,
  CollectionService,
  Column,
  Editors,
  FieldType,
  Filters,
  FlatpickrOption,
  Formatter,
  Formatters,
  GridOption,
  GridStateChange,
  Metrics,
  MultipleSelectOption,
  OperatorType,
} from 'angular-slickgrid';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { currencyFormatter, percentFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { UserRoleService } from '../../../../shared/services/user-role-service';
import { ManageStratCollectionEndDateDirective, ManageStratConfigDetailsDirective, ManageStratDealTypeDirective, ManageStratDescriptionDirective, ManageStratDetailsTabDirective, ManageStratFieldNameDirective, ManageStratGridDirective, ManageStratNameDirective, ManageStratPreviewTabDirective, ManageStratSelectDealDirective, ManageStratTitleDirective } from './manage-strat-asset.directive';



@Component({
  selector: 'cw-manage-strat-asset',
  templateUrl: './manage-strat-asset.component.html',
  styleUrls: ['./manage-strat-asset.component.scss'],
  providers: [StratAssetService]
})


export class ManageStratAssetComponent //extends CanDeactivateForm 
implements OnInit {
  @ContentChild(ManageStratDetailsTabDirective) ManageStratDetailsTabTemplate: ManageStratDetailsTabDirective;
  @ContentChild(ManageStratPreviewTabDirective) ManageStratPreviewTabTemplate: ManageStratPreviewTabDirective;
  @ContentChild(ManageStratTitleDirective) ManageStratTitleTemplate: ManageStratTitleDirective;
  @ContentChild(ManageStratDealTypeDirective) ManageStratDealTypeTemplate: ManageStratDealTypeDirective;
  @ContentChild(ManageStratFieldNameDirective) ManageStratFieldNameTemplate: ManageStratFieldNameDirective;
  @ContentChild(ManageStratNameDirective) ManageStratNameTemplate: ManageStratNameDirective;
  @ContentChild(ManageStratDescriptionDirective) ManageStratDescriptionTemplate: ManageStratDescriptionDirective;
  @ContentChild(ManageStratConfigDetailsDirective) ManageStratConfigDetailsTemplate: ManageStratConfigDetailsDirective;
  @ContentChild(ManageStratSelectDealDirective) ManageStratSelectDealTemplate: ManageStratSelectDealDirective;
  @ContentChild(ManageStratCollectionEndDateDirective) ManageStratCollectionEndDateTemplate: ManageStratCollectionEndDateDirective;
  @ContentChild(ManageStratGridDirective) ManageStratGridTemplate: ManageStratGridDirective;
 
  public title = 'Asset Strats List';
  public stratDetails: AssetStratModel = null;
  public searchStratDetails: StratPreviewSearchModel = null;
  public stratGridOptions: SfpGridOptionsModel = null;
  public stratAttributeNameList: Array<SelectLookupModel> = [];
  public minOperatorList: Array<SelectLookupModel> = [];
  public maxOperatorList: Array<SelectLookupModel> = [];
  public dealNameList: Array<SelectLookupModel> = [];
  public dealTypeList: Array<SelectLookupModel> = [];

  public stratGridCustomCols: Array<SfpGridColumnModel> = [];
  public stratGridActionLinks: Array<SfpGridActionModel> = [];
  public stratGridExcludedCols: Array<string> = []
  public datePipe = new DatePipe('en-UK');
  public searchSubmitted = false;
  public exportFileName = 'AssetStratsListData';
  public stratunsavedDetails: AssetStratModel = null;

  private readonly _stratSaveValidationMessage = 'Please fill required fields.';
  private readonly _stratPreviewValidationMessage = 'Please fill valid values for preview.';
  public actionType: string = '';
  private readonly _stratActionAdd = 'create';
  private readonly _stratActionEdit = 'edit';
  private readonly _stratActionCopy = 'copy';
  private readonly _stratActionView = 'view';
  private readonly _invalidAction = 'invalid';
  private readonly _addStratTitle = 'Add Strat';
  private readonly _editStratTitle = 'Edit Strat';
  private readonly _lockedsSratTitle = 'This Strat is locked, you cannot edit this strat';
  private readonly _copyStratTitle = 'Copy Strat';
  private readonly _viewStratTitle = 'View Strat';
  private readonly _InvalidActionTitle = 'Resource is not available';
  public _viewStratListNavPath = '/dealconfig/ir/assetstrat/configlist';

  //Strat Messages
  private readonly _stratNotExist = 'Strat record is not exist.';
  private readonly _stratToastTitle = 'Strat';
  public readonly _stratSavedMsg = 'Strat is saved successfully.';
  public readonly _stratUpdatedMsg = 'Strat is updated successfully.';
  public readonly _stratSavedPreviewMsg = 'Strat for preview is saved successfully.';
  private readonly _stratTitleDuplicateMsg = 'Strat name should be unique. Please re-enter strat name.'
  private readonly _valueChangeMessage = "You have not changed any value.";

  //Strat Config Messages
  private readonly _stratConfigSortOrderDuplicateMsg = 'Sort order could not have duplicate values';
  private readonly _stratConfigSortOrderBlankMsg = 'Sort order should have valid value';
  private readonly _stratConfigNoRangeMsg = 'Please add the valid range';
  private readonly _sortOrderInValidMsg = 'Sort order can not left blank';
  private readonly _rangeInValidMsg = 'Please enter valid range';
  private readonly _rangeViolateMsg = 'Please enter valid range';
  private readonly _lockedStratTitle = 'This strat is locked, you cannot edit this Strat';
  private readonly _stratConfigCopy = 'Copy';
  private readonly _toastDateValidationMessage = "Please select collection end date less than or equal to current system date.";
  stratCriteriaList: Array<StratConfigurationModel> = [];
  stratPreviewData: Array<StratPreviewModel> = [];
  gridOrginalSource: Array<StratPreviewModel> = [];

  public submitted = false;
  private readonly _firstTab = 'Strat Data';
  private readonly _secondTab = 'Preview Strat';
  private readonly _dateFormat = 'yyyy-MM-dd';
  private readonly _defaultDate = '1900-01-01';
  private readonly maxRangeValue = 10000000000;
  private readonly minRangeValue = -10000000000;
  public todayDate: Date = new Date;

  public counter: number = 0;
  public isShowNextBtn: boolean = true;
  public isShowBackBtn: boolean = false;
  public isShowSaveBtn: boolean = false;
  public showAddStratSection: boolean = false;
  public activeSecondTab: string = '';
  public activeFirstTab: string = 'active';
  public dataTypeText: string = 'TEXT';

  public selectedStratName: string = '';
  public selectedfieldId: number;
  public selectedStratAttributeName: string = '';
  public selectedStratDataType: string = '';
  public selectedDealId: number = null;
  public selectedDealForIpd: number = null;
  public selectedDealName: string = null;

  public dealBusinessEndDateList: Array<SelectLookupModel> = [];
  public selectedDealBusinessEndDateList: Array<SelectLookupModel> = [];
  public selectedIpdDate: string = null;
  public stratAction: string;
  public stratId: number;
  public stratNameLength: number = 28;

  public currentDate = new Date();
  public isReadOnlyAccess: boolean = false;
  public isAddEditAccess: boolean = false;
  public isApprovRejectAccess: boolean = false;
  public isDeleteAccess: boolean = false;
  public isPreviewButtonClicked = false;


  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  //-------Slick Grid Variables End--------------

  public canUpdate: boolean = false;
  public canView: boolean = false;
  public canDelete: boolean = false;
  public canAuthorized: boolean = false;
  public loggedInUser: string;

  @ViewChild('createStratForm') createStratForm: NgForm;
  @ViewChild('stratSearchForm') stratSearchForm: NgForm;
  @ViewChild('createStratForm') confirmUnsavedForm: NgForm;
  @Output() manageIrStratEvent = new EventEmitter<NgForm>();
  
  constructor(
    private _stratService: StratAssetService,
    private _toastservice: GlobalToasterService,
    private _userRoleService: UserRoleService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _sharedDataService: SharedDataService,
    private _userService: UserRoleService) {

    //super();

    this.showHideLoadingImage(false);

    this._route.params.subscribe((params: Params) => {
      this.stratId = (params['stratId'] != null) ? params['stratId'] : null;
      this.stratAction = this._router.url.split('/')[6];

      switch (this.stratAction) {
        case this._stratActionAdd:
          this.title = this._addStratTitle;
          this.actionType = this._stratActionAdd;
          this.addStratInitialize();
          break;
        case this._stratActionEdit:
          this.title = this._editStratTitle;
          this.actionType = this._stratActionEdit;
          this.editCopyViewStratInitialize(this.stratId);
          break;
        case this._stratActionCopy:
          this.title = this._copyStratTitle;
          this.actionType = this._stratActionCopy;
          this.editCopyViewStratInitialize(this.stratId);
          break;
        case this._stratActionView:
          this.title = this._viewStratTitle;
          this.actionType = this._stratActionView;
          this.editCopyViewStratInitialize(this.stratId);
          break;
        default:
          this.title = this._InvalidActionTitle;
          this.actionType = this._invalidAction;
      }
    });
  }


  ngOnInit() {
    this.setUpUserRolesAndPermissions();
    this.searchStratDetails = new StratPreviewSearchModel(null, null, null, null, null, null);
    this.searchStratDetails.stratCriteriaList = [];
    this.stratDetails = new AssetStratModel(null, null, null, null, null, null, null, null, null, null);
    this.isReadOnlyAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.View);
    this.isAddEditAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.AddEdit);
    this.isApprovRejectAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.ApproveReject);
    this.isDeleteAccess = this._userService.isUserHasPermission(PermissionEnum[PermissionEnum.CW_IR_Config], PermissionAccessTypeEnum.Delete);

    // this.stratGridExcludedCols = ['stratId', 'fieldId', 'sortOrder', 'trueBalance', 'trueBalancePercent', 'subHeaderText']
  }





  editCopyViewStratInitialize(stratId: number) {
    this._stratService.getStrat(stratId).subscribe(result => {
      console.log('Strat record is fetched:');
      console.log(result);
      if (result) {


        this.stratDetails = result;


        if (this.canUpdate == true && this.actionType == 'view' && this.stratDetails.isLocked == 0) {
          this.actionType = 'edit';
          this.title = this._editStratTitle;
        }


        this.stratCriteriaList = [];
        this.stratDetails.stratCriteriaList.forEach(x => {
          this.stratCriteriaList.push(
            {
              'id': ++this.counter,
              'stratConfigId': x.stratConfigId,
              'fromValue': x.fromValue,
              'fromOperatorId': x.fromOperatorId,
              'toValue': x.toValue,
              'toOperatorId': x.toOperatorId,
              'sortOrder': x.sortOrder,
              'fromOperator': x.fromOperator,
              'toOperator': x.toOperator,
              'isValidRecord': false
            }
          );
        });


        this.loadSelectList();
        this.loadDealNameSelectList();



        this.selectedStratName = this.stratDetails.name;
        this.visibleRangeFrame(this.stratDetails.fieldId);

        if (this.actionType === this._stratActionCopy) {
          this.stratDetails.name = 'Copy of ' + this.stratDetails.name;
          this.stratDetails.name = this.stratDetails.name.substr(0, this.stratNameLength);
        }

        if (this.stratDetails.isLocked) {
          if (this.actionType === this._stratActionEdit) {
            this.title = this._lockedStratTitle;
            this.actionType = 'view';
          }
        }

        this.stratunsavedDetails = JSON.parse(JSON.stringify(this.stratDetails));
        this.stratunsavedDetails.stratCriteriaList = JSON.parse(JSON.stringify(this.stratCriteriaList));

      }
      else {
        this.title = this._stratNotExist;
        this.actionType = this._invalidAction;
      }
    });

    setTimeout(()=>{ this.manageIrStratEvent.next(this.confirmUnsavedForm); }, 500);
  }

  addStratInitialize() {
    this.stratDetails = new AssetStratModel(0, 0, null, null, null, null, null, null, null, null);
    this.stratDetails.stratCriteriaList = [];
    this.stratDetails.stratDealTypeList = [];
    this.loadSelectList();
    this.stratDetails.fieldId = null;

    setTimeout(()=>{ this.manageIrStratEvent.next(this.confirmUnsavedForm); }, 500);
  }

  loadSelectList() {
    let multiListId = [SelectListEnum.DealList, SelectListEnum.StratAttributeList, SelectListEnum.MinOperatorList, SelectListEnum.MaxOperatorList, SelectListEnum.DealBusinessEndDate, SelectListEnum.DealTypeList]
    this._stratService.getMultiparameterSelectedList(multiListId).subscribe(result => {
      this.dealTypeList = result.filter(x => x.listId == SelectListEnum.DealTypeList);
      this.stratAttributeNameList = result.filter(x => x.listId == SelectListEnum.StratAttributeList);
      this.minOperatorList = result.filter(x => x.listId == SelectListEnum.MinOperatorList);
      this.maxOperatorList = result.filter(x => x.listId == SelectListEnum.MaxOperatorList);
      this.dealBusinessEndDateList = result.filter(x => x.listId == SelectListEnum.DealBusinessEndDate);
    }, (error: any) => {
      console.log(error);
      alert(error.message);
    });

  }

  loadDealNameSelectList() {
    let filterId = this.stratDetails.stratDealTypeList;
    this._stratService.getSelectLookupDealName(filterId).subscribe(result => {
      this.dealNameList = result.filter(x => x.listId == SelectListEnum.DealList);
    }, (error: any) => {
      console.log(error);
    });

  }

  AddstratCriteriaList(): void {
    let sortOrder: number = 1
    this.stratDetails.stratCriteriaList = [];
    this.stratCriteriaList.forEach(x => {
      this.stratDetails.stratCriteriaList.push(
        {
          'id': x.id,
          'stratConfigId': x.stratConfigId,
          'fromValue': x.fromValue,
          'fromOperatorId': x.fromOperatorId,
          'toValue': x.toValue,
          'toOperatorId': x.toOperatorId,
          'sortOrder': sortOrder++,
          'fromOperator': x.fromOperator,
          'toOperator': x.toOperator,
          'isValidRecord': x.isValidRecord
        }
      );
    });
  }

  showHideLoadingImage(isShow) {
    if (isShow)
      document.getElementById('preloader').style['display'] = 'block';
    else
      document.getElementById('preloader').style['display'] = 'none';
  }

  onRemoveClick(id: number): void {
    if (this.stratCriteriaList.length > 0) {
      let item = this.stratCriteriaList.find(x => x.id == id);
      let index = this.stratCriteriaList.indexOf(item);
      if (index >= -1) {
        this.stratCriteriaList.splice(index, 1);
        this.counter--;
        console.log(this.stratCriteriaList);

        this.counter = 0
        this.stratCriteriaList.forEach(x => { x.id = ++this.counter, x.stratConfigId = ++this.counter });

        console.log(this.stratCriteriaList);
      }
    }
  }

  onAddClick(rowAction: string, id: number): void {
    if (rowAction === this._stratConfigCopy) {
      let item = this.stratCriteriaList.find(x => x.id == id);
      this.counter = Math.max.apply(Math, this.stratCriteriaList.map(function (o) { return o.id; })) + 1;
      let index = this.stratCriteriaList.indexOf(item);
      let listItem = new StratConfigurationModel(this.counter, this.counter, item.fromValue, item.fromOperatorId, item.toValue, item.toOperatorId, 0, item.fromOperator, item.toOperator, false);
      this.stratCriteriaList.splice(index, 0, listItem);
    } else {
      if (this.stratCriteriaList.length <= 0)
        this.counter = 1;
      else
        this.counter = Math.max.apply(Math, this.stratCriteriaList.map(function (o) { return o.id; })) + 1;


      this.stratCriteriaList.push(
        {
          'id': this.counter,
          'stratConfigId': this.counter,
          'fromValue': null,
          'fromOperatorId': null,
          'toValue': null,
          'toOperatorId': null,
          'sortOrder': 0,
          'fromOperator': null,
          'toOperator': null,
          'isValidRecord': false
        }
      );
    }

    console.log(this.stratCriteriaList);

  }

  clearstratCriteriaList(): void {
    if (this.selectedStratDataType === this.dataTypeText) {
      this.stratCriteriaList = [];
      this.stratDetails.stratCriteriaList = [];
      this.counter = 0;
    }
  }

  navigateToViewStratList(): void {
    //this._router.navigate([this._viewStratListNavPath], { relativeTo: this._route })
    this._router.navigate([this._viewStratListNavPath]);
  }

  onDealSelectDropDownChange(event: any) {
    this.selectedDealForIpd = null;
    this.selectedDealName = '';

    this.selectedDealBusinessEndDateList = [];
    if (event) {
      this.selectedDealBusinessEndDateList = this.dealBusinessEndDateList.filter(x => x.value == event.value);
      this.selectedDealBusinessEndDateList.sort((val1, val2) => { return +new Date(val2.text) - +new Date(val1.text) });
      this.selectedDealName = event.text;
    }
  }

  onDealClosingEndDate(event: any): boolean {
    this.selectedIpdDate = null;
    if (event) {
      this.selectedIpdDate = event.text;
    }
    return true;
  }



  displayRangeBucketFrame(event) {
    if (event) {
      this.selectedStratDataType = '';
      this.selectedfieldId = event.value;
      this.visibleRangeFrame(this.selectedfieldId);
    }
  }

  visibleRangeFrame(fieldId: number) {

    let listId = SelectListEnum.StratFieldDataType.toString();
    this._stratService.getSelectedList(listId).subscribe(result => {
      console.log('attribute feild type list Fetched:');
      let attribute = result.filter(x => x.value == fieldId);
      if (attribute.length > 0)
        this.selectedStratDataType = attribute[0].text;
      console.log(this.selectedStratDataType);

      if (this.selectedStratDataType.toUpperCase() !== this.dataTypeText.toUpperCase())
        this.showAddStratSection = true;
      else
        this.showAddStratSection = false;


    }, (error: any) => {
      this.showAddStratSection = false;
      this.selectedStratDataType = this.dataTypeText;
    });
  }

  isRangeViolate(): boolean {
    let attribute = this.stratCriteriaList.filter(x => x.fromValue > this.maxRangeValue || x.toValue > this.maxRangeValue
      || x.fromValue < this.minRangeValue || x.toValue < this.minRangeValue);

    if (attribute.length > 0) {
      attribute.forEach(x => { x.isValidRecord = true });
      return true;
    }

    return false;
  }

  isFromAndToRangeValid(): boolean {
    this.stratCriteriaList.forEach(x => { x.isValidRecord = false });

    let attribute = this.stratCriteriaList.filter(x => (x.fromValue === null && x.toValue === null)
      || (x.fromOperatorId === null && x.toOperatorId === null)
      || (x.fromOperatorId === x.toOperatorId)
      || (x.fromOperatorId !== null && x.fromValue === null)
      || (x.fromOperatorId === null && x.fromValue !== null)
      || (x.toOperatorId !== null && x.toValue === null)
      || (x.toOperatorId === null && x.toValue !== null
        || ((x.fromOperatorId !== null && x.toOperatorId !== null) && (x.toValue < x.fromValue))
      )

    );
    if (attribute.length > 0) {
      attribute.forEach(x => { x.isValidRecord = true });
      return true;
    }

    return false;
  }


  onTabChange(tabName: string, event): boolean {
    if (tabName === this._firstTab) {
      this.activeSecondTab = '';
      this.activeFirstTab = 'active'
    }

    if (tabName === this._secondTab) {
      if (this.stratDetails.stratId == null) {
        this.loadDealNameSelectList();
      }
      this.saveStratData(this._stratSavedPreviewMsg);
      if (this.activeSecondTab !== 'active') {
        event.stopPropagation();
        this.activeFirstTab = 'active'
        return false;
      }
    }
  }

  getStratDataPreviewBind() {
    this.slickColumnArray = <SFP_SlickColumn[]>[];
    this.slickColumnArray.push
      (
        // new SFP_SlickColumn('sortOrderNo', 'Sort Order', true, true, 100, FieldType.string),
        new SFP_SlickColumn('headerText', 'Header Text', true, true, 100, FieldType.string),
        // new SFP_SlickColumn('subHeaderText', 'Sub-Header Text', true, true, 100, FieldType.string),
        new SFP_SlickColumn('mortgageLoans', 'Mortgage Loans', true, true, 100, FieldType.string),
        new SFP_SlickColumn('mortgageLoansPercent', 'Mortgage Loans (%)', true, true, 150, FieldType.string, percentFormatter),
        new SFP_SlickColumn('totalOutCapitalBalance', 'Capital Balance', true, true, 150, FieldType.string, currencyFormatter),
        new SFP_SlickColumn('totalOutCapitalBalancePercent', 'Capital Balance (%)', true, true, 100, FieldType.string, percentFormatter),
        // new SFP_SlickColumn('trueBalance', 'True Balance', true, true, 100, FieldType.string),
        // new SFP_SlickColumn('trueBalancePercent', 'True Balance (%)', true, true, 100, FieldType.string),

      );
  }



  onStratDataPreview(): boolean {

    // this.stratGridOptions = null;

    if (this.stratSearchForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratPreviewValidationMessage);
      Object.keys(this.stratSearchForm.form.controls).forEach((key) => {
        this.stratSearchForm.form.get(key).markAsTouched();
      });
      return false;
    } else if (!this.selectedDealName || !this.selectedIpdDate) {
      this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratPreviewValidationMessage);
      return;
    }
    else {
      // this.showHideLoadingImage(true);
      this.isPreviewButtonClicked = true;
      this.searchStratDetails.dealName = this.selectedDealName;
      this.searchStratDetails.fieldId = this.stratDetails.fieldId;
      this.searchStratDetails.ipdDate = this.selectedIpdDate;
      this.searchStratDetails.stratName = this.selectedStratName;
      this.clearstratCriteriaList();

      this.searchStratDetails.stratCriteriaList = [];
      this.stratDetails.stratCriteriaList.forEach(x => {
        this.searchStratDetails.stratCriteriaList.push(
          {
            'id': x.id,
            'stratConfigId': x.stratConfigId,
            'fromValue': x.fromValue,
            'fromOperatorId': x.fromOperatorId,
            'toValue': x.toValue,
            'toOperatorId': x.toOperatorId,
            'sortOrder': x.sortOrder,
            'fromOperator': x.fromOperator,
            'toOperator': x.toOperator,
            'isValidRecord': x.isValidRecord
          }
        );
      });


      this._stratService.getStratPreviewData(this.searchStratDetails).subscribe(result => {

        this.stratPreviewData = result;

        this.slickDataset = JSON.parse(JSON.stringify(result)); //deep copy

        this.getStratDataPreviewBind();

        this.stratSearchForm.form.markAsPristine();
        this.stratSearchForm.form.markAsUntouched();
        this.isPreviewButtonClicked = false;
      }, (error: any) => {
        alert(error.message);
        this.stratPreviewData = null
        // this.showHideLoadingImage(false);
      });
    }

  }




  saveStratData(saveMessage: string) {
    console.log(saveMessage);

    if (this.stratDetails.name == null) {
      //  this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratSaveValidationMessage)
      this.createStratForm.form.controls['name'].setErrors({ 'required': true });
    }
    if (this.stratDetails.name != null && this.stratDetails.name.replace(/\s/g, "").toLowerCase().length <= 0) {
      //  this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratSaveValidationMessage)
      this.createStratForm.form.controls['name'].setErrors({ 'required': true });
    }
    if (this.createStratForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratSaveValidationMessage);
      Object.keys(this.createStratForm.form.controls).forEach((key) => {
        this.createStratForm.form.get(key).markAsTouched();
      });
      return false;
    } else if (this.counter <= 0 && this.showAddStratSection) {
      this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratConfigNoRangeMsg);
      return false;
    } else if (this.isFromAndToRangeValid() && this.showAddStratSection) {// strat is not saved
      this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._rangeInValidMsg);
      return false;
    } else if (this.isRangeViolate() && this.showAddStratSection) {// strat is not saved
      this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._rangeViolateMsg);
      return false;

    } else if (this._stratSavedPreviewMsg === saveMessage) {
      this.AddstratCriteriaList();
      this.activeFirstTab = '';
      this.activeSecondTab = 'active';
      return false;
    }
    else {

      this.clearstratCriteriaList();

      this.AddstratCriteriaList();
      if (this.actionType === this._stratActionCopy)
        this.stratDetails.stratId = 0;


      this.stratDetails.isLocked = 0;

      this.stratDetails.name = this.stratDetails.name.trim();

      this.stratDetails.stratId = this.stratDetails.stratId == null ? 0 : this.stratDetails.stratId;
      console.log(this.actionType)
      if (this.actionType === this._stratActionEdit) {
        if (!this.CheckDataChange(this.stratunsavedDetails)) {
          this._toastservice.openToast(ToasterTypes.error, this.title, this._valueChangeMessage);
          return;
        }
      }

      this._stratService.insertStrat(this.stratDetails).subscribe(result => {
        if (result.stratId === -1) {// strat is not saved
          this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratTitleDuplicateMsg);
        }
        else if (result.stratId === 0) {// strat is not saved
          this._toastservice.openToast(ToasterTypes.error, this._stratToastTitle, this._stratTitleDuplicateMsg);
        }
        else {
          console.log('Strat Data is saved');
          this.selectedStratName = this.stratDetails.name;
          this.stratDetails.stratId = result.stratId;

          this.createStratForm.form.markAsPristine();
          this.createStratForm.form.markAsUntouched();
          this._toastservice.openToast(ToasterTypes.success, this._stratToastTitle, saveMessage);

          this.navigateToViewStratList();
        }

      }, (error: any) => {
        console.log(error);
        alert(error.message);
      });
    }
  }

  private CheckDataChange(row: AssetStratModel) {
    console.log(row);
    console.log(JSON.parse(JSON.stringify(this.stratDetails)))
    if (row.fieldId == this.stratDetails.fieldId
      && row.fieldName == this.stratDetails.fieldName
      && row.name == this.stratDetails.name
      && row.description == this.stratDetails.description
      && row.stratDataType == this.stratDetails.stratDataType
      && JSON.stringify(row.stratCriteriaList) === JSON.stringify(this.stratDetails.stratCriteriaList)
      && JSON.stringify(row.stratDealTypeList) == JSON.stringify(this.stratDetails.stratDealTypeList)
    ) {
      return false;
    }
    else
      return true;
  }


  setUpUserRolesAndPermissions() {
    this.loggedInUser = this._userRoleService.getCurrentLoginUser();

    this.canView = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.View);
    this.canUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.AddEdit);
    this.canDelete = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.Delete);
    this.canAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.ApproveReject);
  }

  getDetailsTabTemplate() {
    return this.ManageStratDetailsTabTemplate?.template;
  }
  getPreviewTabTemplate() {
    return this.ManageStratPreviewTabTemplate?.template;
  }
  getTitleTemplate() {
    return this.ManageStratTitleTemplate?.template;
  }
  getDealTypeTemplate() {
    return this.ManageStratDealTypeTemplate?.template;
  }
  getFieldNameTemplate() {
    return this.ManageStratFieldNameTemplate?.template;
  }
  getStratNameTemplate() {
    return this.ManageStratNameTemplate?.template;
  }
  getDescriptionTemplate() {
    return this.ManageStratDescriptionTemplate?.template;
  }
  getConfigDetailsTemplate() {
    return this.ManageStratConfigDetailsTemplate?.template;
  }
  getSelectDealTemplate() {
    return this.ManageStratSelectDealTemplate?.template;
  }
  getCollectionEndDateTemplate() {
    return this.ManageStratCollectionEndDateTemplate?.template;
  }
  getGridTemplate() {
    return this.ManageStratGridTemplate?.template;
  }

}