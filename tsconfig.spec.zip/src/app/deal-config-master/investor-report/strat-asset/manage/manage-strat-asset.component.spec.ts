import { ComponentFixture, TestBed, async, inject, fakeAsync, tick } from '@angular/core/testing';
import { RouterTestingModule } from "@angular/router/testing";
import { DebugElement } from '@angular/core';
import { ManageStratAssetComponent } from './manage-strat-asset.component';
import { StratAssetService } from 'src/app/deal-config/investor-report/service/strat-asset.service';
import { AssetStratModel, SelectLookupModel, SelectListEnum } from 'src/app/deal-config/investor-report/model/strat-asset.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HttpClient } from '@angular/common/http';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { FormsModule } from '@angular/forms';
import { By } from '@angular/platform-browser';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { StratDataModel }  from 'src/app/deal-config/investor-report/model/spec/mock-strat-list.model';
import { NgSelectModule } from '@ng-select/ng-select';
import { CustomControlModule } from 'src/app/shared/modules/custom-control.module';
import { DatePipe } from '@angular/common';
import { of } from 'rxjs';
import { ActivatedRoute, Router, Params } from '@angular/router';

describe('ManageStratAssetComponent', () => {
  let fixture: ComponentFixture<ManageStratAssetComponent>;
  let stratComponent: ManageStratAssetComponent;
  let de: DebugElement;
  let compiledElement;
  const dummyStratRecord: AssetStratModel =   {
    "stratId": 1,
    "fieldId": 1,
    "fieldName": "CurrentLTV",
    "name": "CurrentLTV",
    "description": "CurrentLTV",
    "stratDataType": "NUMERIC",
    "isLocked": 0,
    "stratStatus": "Active",
    "stratCriteriaList": null,
    "createdDate": "2020-11-25T00:00:00",
    "createdBy": "System",
    "stratDealTypeList" : [25, 26],
};

  
  const dealList: Array<SelectLookupModel> = [ new SelectLookupModel(SelectListEnum.DealList, 2, 'Ardmore1'), new SelectLookupModel(  SelectListEnum.DealList,3,'Dunmore1')];
  const stratAttributeNameList: Array<SelectLookupModel> = [ new SelectLookupModel(SelectListEnum.StratAttributeList, 1, 'CurrentLTV'), new SelectLookupModel(  SelectListEnum.StratAttributeList, 2 ,'RegionalDistribution')];
  const operatorList: Array<SelectLookupModel> = [ ];

  
  beforeEach(async(() => {
    //spy object to mock
    const mockedStratAssetService = jasmine.createSpyObj('StratAssetService',['getStrat', 'insertStrat', 'getSelectedList', 'getStratPreviewData']);
    const mockedGlobalHttpService = jasmine.createSpyObj('GlobalHttpService',['GetRequest','PostRequest','DeleteRequest']);
    const mockedToasterService = jasmine.createSpyObj('GlobalToasterService', ['openToast']);

    TestBed.configureTestingModule({
      imports: [RouterTestingModule, NgSelectModule, FormsModule, CustomControlModule],
      declarations: [ManageStratAssetComponent],
      providers: [LogMaster, LogConsole, ConstantService, HttpClient
        , { provide: StratAssetService, useValue: mockedStratAssetService }
        , { provide: GlobalHttpService, useValue: mockedGlobalHttpService }
        , { provide: GlobalToasterService, useValue: mockedToasterService }
        ,{ provide: ActivatedRoute,
            useValue:{
                params: of({id: 1}),
                url: of('/dealconfig/ir/stratsmgmt/edit/1')
            }
          }
      ]
    }).compileComponents();
    
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ManageStratAssetComponent);
    stratComponent = fixture.componentInstance;
    stratComponent.actionType = 'edit';
    stratComponent.stratDetails = dummyStratRecord;
  });

  
  it('should create Manage Strat component', () => {
    const fixture = TestBed.createComponent(ManageStratAssetComponent);
    fixture.debugElement.injector.get(StratAssetService) as jasmine.SpyObj<StratAssetService>;
    fixture.debugElement.injector.get(GlobalToasterService) as jasmine.SpyObj<GlobalToasterService>;

    // get the service
    const stratService = fixture.debugElement.injector.get(StratAssetService);
    

    //Prepare the dummy result
    spyOn(stratService, 'getStrat').and.callFake(() => {
      return of(dummyStratRecord); 
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(dealList); 
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(operatorList); // return the Strat category type
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(stratAttributeNameList); // return the counterparty list 
    });


    const stratMgmtCompopInstance = fixture.componentInstance;    

    expect(stratMgmtCompopInstance).toBeDefined();
  });

  it('should be able to call the GetStrat function', () => {
    // get the service
    const stratService = fixture.debugElement.injector.get(StratAssetService); 

    //Spy on service functions
    spyOn(stratService, 'getStrat').and.callFake(() => {
      return of(dummyStratRecord); 
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(stratAttributeNameList); 
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(operatorList); // return the counterparty list 
    });

   

    //Call the component function
    stratComponent.editCopyViewStratInitialize(stratComponent.stratDetails.stratId);

    //Validate/Test the result
    expect(expect(stratService.getStrat).toHaveBeenCalled).toBeTruthy();
    expect(expect(stratComponent.editCopyViewStratInitialize).toHaveBeenCalled).toBeTruthy();
  });

  

  it('should call loadSelectedList function ', function () {
    // get the service
    
    const stratService = fixture.debugElement.injector.get(StratAssetService); 

    //Spy on service functions
    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(dealList); 
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(stratAttributeNameList); 
    });

    spyOn(stratService, 'getSelectedList').and.callFake(() => {
      return of(operatorList); 
    });
    
    //Call the component function
    stratComponent.loadSelectList();

    //Validate/Test the result
    expect(expect(stratComponent.loadSelectList).toHaveBeenCalled).toBeTruthy();
    expect(expect(stratService.getSelectedList).toHaveBeenCalled).toBeTruthy();
  });


});
