export class BespokeModel
{
    public header : any;
    public data : any;
}


export class BespokeUIModel
{
    public groupHeader : any;
    public header : any;
    public data : any;
}