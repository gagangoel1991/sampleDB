export class DealNoteInformationModel {
    public dealNoteId: number
    public dealId: number
    public name: string
    public iSIN: string
    public validFrom: string
    public validTo: string
    public maturityDate :string
    public earlyRedemptionDate: string
    public earlyRedemptionDateNextIpd :string
    public authorizerComment: string
    public dealStatusId : number
    public isActive :boolean
    public finalMaturityDate :string
    public modifiedBy?: string
    public modifiedDate?: string
    
    constructor(dealNoteId: number,
        dealId: number,
        name: string,
        iSIN: string,
        validFrom: string,
        validTo: string,
        maturityDate : string,
        earlyRedemptionDate: string,
        earlyRedemptionDateNextIpd :string,
        authorizerComment:string,
        dealStatusId : number,
        isActive :boolean,
        finalMaturityDate : string,
        modifiedBy?: string,
        modifiedDate?: string
        
    ) {
        this.dealNoteId = dealNoteId;
        this.dealId = dealId;
        this.name = name;
        this.iSIN = iSIN;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.maturityDate =maturityDate;
        this.earlyRedemptionDate = earlyRedemptionDate;
        this.earlyRedemptionDateNextIpd =earlyRedemptionDateNextIpd;
        this.authorizerComment =authorizerComment;
        this.dealStatusId =dealStatusId;
        this.isActive = isActive;
        this.finalMaturityDate = finalMaturityDate;
        this.modifiedBy = modifiedBy;
        this.modifiedDate = modifiedDate;
        
    }
}