export class DealModel {
    public dealId: number;
    public dealName: string;
    public dealPublicName: string;
    public internalDealName: string;
    public description: string;
    public ownerName: string;
    public businessAreaId: number;
    public dealTypeId: number;
    public dealStatusId: number;
    public dealStatus: string;
    public closingDate: Date;
    public dealMaturityDate?: Date;
    public firstIpdDate?: Date;
    public cashCollectionStartDate: Date;
    public ipdFrequencyId?: number;
    public dealCurrencyId: number;
    public jurisdictionMarkerId: number;
    public furtherAdvancesAutoTopUpFlagId: number;
    public balanceTransferAutoTopUpFlagId: number;
    public mortgageAutoTopUpFlagId: number;
    public dealAccountingTypeId: number;
    public authorizerComment: string;
    public modifiedBy: string;
    public modifiedDate: string;
    public createdBy: string;
    public workflowActionedBy: string;
    public workflowActionedDate: string;
    public earlyRedemptionDate: Date
    isMinorAmendment: boolean = false;
    public isCwDeal: boolean;
    public redactedFacilityIds: string;
	
	public cashReportingFlagId: number;
    public dealInitialSize: string;
    public topupEndDate: Date;
    public topupFlagId: number;
    public riskRetentionPercent: number;
    public riskRetentionMethodId: number;
    public riskRetentionHolderId: number;
    public ronaCalculatedBasedOnId: number;
    public fxRateDate: Date;
    public facilitySharingAllowedId: number;
    public enableHistoricFlaggingId: number;
    public facilityPercentChangeAllowedId: number;
    public legalRetentionPercent: number;
    // constructor(id: number,
    //     dealName: string,
    //     dealPublicName: string,
    //     internalDealName: string,
    //     description: string,
    //     ownerName: string,
    //     businessAreaId: number,
    //     dealTypeId: number,
    //     dealStatus: number,
    //     closingDate: Date,
    //     dealMaturityDate: Date,
    //     firstIpdDate: Date,
    //     cashCollectionStartDate: Date,
    //     ipdFrequencyId: number,
    //     dealCurrencyId: number,
    //     jurisdictionMarkerId: number,
    //     furtherAdvancesAutoTopUpFlagId: number,
    //     balanceTransferAutoTopUpFlagId: number,
    //     mortgageAutoTopUpFlagId: number,
    //     dealAccountingTypeId: number,) {
    //     this.id = id;
    //     this.dealName = dealName;
    //     this.dealPublicName = dealPublicName;
    //     this.internalDealName = internalDealName;
    //     this.description = description;
    //     this.ownerName = ownerName;
    //     this.businessAreaTypeId = businessAreaId;
    //     this.dealTypeId = dealTypeId;
    //     this.dealStatus = dealStatus;
    //     this.closingDate = closingDate;
    //     this.dealMaturityDate = dealMaturityDate;
    //     this.firstIpdDate = firstIpdDate;
    //     this.cashCollectionStartDate = cashCollectionStartDate;
    //     this.ipdFrequencyId = ipdFrequencyId;
    //     this.dealCurrencyId = dealCurrencyId;
    //     this.jurisdictionMarkerId = jurisdictionMarkerId;
    //     this.furtherAdvancesAutoTopUpFlagId = furtherAdvancesAutoTopUpFlagId;
    //     this.balanceTransferAutoTopUpFlagId = balanceTransferAutoTopUpFlagId;
    //     this.mortgageAutoTopUpFlagId = mortgageAutoTopUpFlagId;
    //     this.dealAccountingTypeId = dealAccountingTypeId;
    //}
}