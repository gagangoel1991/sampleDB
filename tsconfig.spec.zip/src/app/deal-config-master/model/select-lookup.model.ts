export class SelectLookupModel {
    public listId: number
    public text: string;
    public value: number;

    constructor(listId: number, value: number, text: string) {
        this.listId = listId;
        this.value = value;
        this.text = text;
    }
}

export enum SelectListEnum {
    AssetType=6,
    DealType=7,
    IpdFrequency=8,
    JurisdicationMarker=9,
    FurtherAdvancesAutoTopUpFlag=10,
    BalanceTransferAutoTopUpFlag=11,
    MortgageAutoTopUpFlag=12,
    DealAccountingType=13,
    Currency=14
}