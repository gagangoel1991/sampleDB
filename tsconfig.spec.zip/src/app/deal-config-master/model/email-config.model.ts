export class EmailConfigModel {
    public emailConfigId: number;
    public emailTypeId: number;
    public emailType: string;
    public internalName: string;
    public displayName: string;
    public emailFrom: string;
    public emailTo: string;
    public emailCC: string;
    public emailBCC: string;
    public emailSubject: string;
    public emailBody: string;
    public emailImportance: boolean;
    public emailImportanceText: string;
    public emailFormat: string;
    public attachment: boolean;
    public attachmentText: string;
    public isActive: boolean;
    public activeStatus: string;
    public createdBy: string;
    public createdDate: string;
    public modifiedBy?: string;
    public modifiedDate?: string;
   
}