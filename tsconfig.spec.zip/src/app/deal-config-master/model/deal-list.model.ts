export class DealNameModel{
    public dealId:number;
    public dealName: string;

    constructor(dealId:number, dealName: string){
        this.dealId = dealId;
        this.dealName = dealName;
    }
}

export class DealListModel{
    public dealId:number;
    public dealName: string;

    constructor(dealId:number, dealName: string){
        this.dealId = dealId;
        this.dealName = dealName;
    }
}

export class DealIpdModel{
    public dealId:number;
    public ipdDate: string;

    constructor(dealId:number, ipdDate: string){
        this.dealId = dealId;
        this.ipdDate = ipdDate;
    }
}