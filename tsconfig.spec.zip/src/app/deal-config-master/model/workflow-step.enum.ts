export enum WorkFlowStepEnum {
    Draft = 33,
    SendForAuthorization = 34,
    Approved = 35,
    Rejected = 36,
    Recall = 37,
    Collapse =57,
    Terminate =58,
    SendForAuthorisationCollapse=59,
    SendForAuthorisationTerminate=60,
    CollapseReject =61,
    TerminateReject=62,
    SendForAuthorisationUpdateDeal =71,
    RejectUpdateDeal=72,
    AuthorisedUpdateDeal=73

}