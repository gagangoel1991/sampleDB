import { Routes, RouterModule, PreloadAllModules, CanActivate   } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { PageNotFoundComponent } from 'src/app/shared/components/page-not-found/page-not-found.component';
import { AuthGuardService as AuthGuard } from 'src/app/core/guard/auth-guard.service';
import { AppModule} from './app.module';
import { UserResolverService } from './core/services/resolver/user-service.resolver';

export const routes: Routes = [
  {
    path: 'servicedown',
    loadChildren: () => import('./shared/components/servicedown/servicedown.module')
    .then(m => m.ServiceDownModule)
  },
  {
    path: '',
    loadChildren: () => import('./shared/home/home.module')
    .then(m => m.HomeModule),
    canActivate: [AuthGuard], resolve: { data: UserResolverService }
  },
  { path: '**', component: PageNotFoundComponent  }
];

export const routing: ModuleWithProviders<AppModule> = RouterModule.forRoot(routes, {
   preloadingStrategy: PreloadAllModules,  // <- comment this line for enable lazy load
});
