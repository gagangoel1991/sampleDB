import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { PerfectScrollbarModule } from 'ngx-perfect-scrollbar';
import { PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { PerfectScrollbarConfigInterface } from 'ngx-perfect-scrollbar';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = { suppressScrollX: true };
import { DirectivesModule } from '../core/theme/directives/directives.module';
import { PipesModule } from '../core/theme/pipes/pipes.module';
import { routing } from './deal-config.routing';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { CustomControlModule } from '../shared/modules/custom-control.module';
import { NgSelectModule } from '@ng-select/ng-select';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { AngularSlickgridModule } from 'angular-slickgrid';

import { ManageDealComponent } from './deal-management/manage/manage-deal.component';
import { DealListComponent } from './deal-management/list/deal-list.component';
import { StratAssetListComponent } from 'src/app/deal-config/investor-report/strat-asset/list/strat-asset-list.component';
import { ManageStratAssetComponent } from 'src/app/deal-config/investor-report/strat-asset/manage/manage-strat-asset.component';
import { IrTemplateListComponent } from 'src/app/deal-config/investor-report/ir-template/list/ir-template-list.component';
import { ManageIrTemplateComponent } from 'src/app/deal-config/investor-report/ir-template/manage/manage-ir-template.component';
import { BuildIrListComponent } from 'src/app/deal-config/investor-report/build-ir/list/build-ir-list.component';
import { ManageBuildIrComponent } from 'src/app/deal-config/investor-report/build-ir/manage/manage-build-ir.component';
import { ViewNonConfigStratComponent } from './investor-report/strat-asset/view-non-config-strat/view-non-config-strat.component';
import { DealNoteComponent } from './deal-management/deal-note/deal-note.component';
import { EmailListComponent } from './email-config/list/email-list.component';
import { ManageEmailComponent } from './email-config/manage/manage-email.component';


@NgModule({
  imports: [
    CommonModule,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    MultiselectDropdownModule,
    routing,
    NgxDatatableModule,
    CustomControlModule,
    NgSelectModule,
    NgbModule,
    AngularSlickgridModule.forRoot()
  ],
  declarations: [
    DealListComponent,
    ManageIrTemplateComponent,
    IrTemplateListComponent,
    StratAssetListComponent,
    ManageStratAssetComponent,
    BuildIrListComponent,
    ManageBuildIrComponent,
    ViewNonConfigStratComponent,    
    ManageDealComponent, DealNoteComponent, EmailListComponent, ManageEmailComponent
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }
  ]
})
export class DealConfigurationModule { }
