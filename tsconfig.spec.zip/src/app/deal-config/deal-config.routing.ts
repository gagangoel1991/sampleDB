import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { CanDeactivateGuardService } from 'src/app/core/guard/can-deactivate/can-deactivate-guard.service';

import { DealConfigurationModule } from './deal-config.module';
import { IrTemplateListComponent } from 'src/app/deal-config/investor-report/ir-template/list/ir-template-list.component';
import { ManageIrTemplateComponent } from 'src/app/deal-config/investor-report/ir-template/manage/manage-ir-template.component';
import { StratAssetListComponent } from 'src/app/deal-config/investor-report/strat-asset/list/strat-asset-list.component';
import { ManageStratAssetComponent } from 'src/app/deal-config/investor-report/strat-asset/manage/manage-strat-asset.component';
import { BuildIrListComponent } from 'src/app/deal-config/investor-report/build-ir/list/build-ir-list.component';
import { ManageBuildIrComponent } from 'src/app/deal-config/investor-report/build-ir/manage/manage-build-ir.component';
import { ManageDealComponent } from './deal-management/manage/manage-deal.component';
import { DealListComponent } from './deal-management/list/deal-list.component';
import { ViewNonConfigStratComponent } from './investor-report/strat-asset/view-non-config-strat/view-non-config-strat.component';
import { EmailListComponent } from './email-config/list/email-list.component';
import { ManageEmailComponent } from './email-config/manage/manage-email.component';


export const routes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'deal', component: DealListComponent, data: { breadcrumb: 'Deal Management' } },
    { path: 'deal/create', component: ManageDealComponent, data: { breadcrumb: 'Deal Management > New Deal' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'deal/copy/:dealId', component: ManageDealComponent, data: { breadcrumb: 'Deal Management > Copy Deal' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'deal/view/:dealId', component: ManageDealComponent, data: { breadcrumb: 'Deal Management > View Deal' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'email', component: EmailListComponent, data: { breadcrumb: 'Email Configuration' } },
    { path: 'email/create', component: ManageEmailComponent, data: { breadcrumb: 'Email Configuration > New Email Configuration' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'email/copy/:emailConfigId', component: ManageEmailComponent, data: { breadcrumb: 'Email Configuration > Copy Email Configuration' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'email/view/:emailConfigId', component: ManageEmailComponent, data: { breadcrumb: 'Email Configuration > View Email Configuration' }, canDeactivate: [CanDeactivateGuardService] },
    
    { path: 'ir/assetstrat', component: StratAssetListComponent, data: { breadcrumb: 'Strat Management' } },
    { path: 'ir/assetstrat/:stratType', component: StratAssetListComponent, data: { breadcrumb: 'Strat Management' } },
    { path: 'ir/assetstrat/configlist/create', component: ManageStratAssetComponent, data: { breadcrumb: 'Strat Management > Create Strat' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/assetstrat/configlist/copy/:stratId', component: ManageStratAssetComponent, data: { breadcrumb: 'Strat Management > Copy Strat' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/assetstrat/configlist/view/:stratId', component: ManageStratAssetComponent, data: { breadcrumb: 'Strat Management > View Strat' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/assetstrat/nonconfiglist/view/:stratId', component: ViewNonConfigStratComponent },

    { path: 'ir/template', component: IrTemplateListComponent, data: { breadcrumb: 'IR Template' } },
    { path: 'ir/template/add', component: ManageIrTemplateComponent, data: { breadcrumb: 'IR Template > Add Template' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/template/copy/:templateId', component: ManageIrTemplateComponent, data: { breadcrumb: 'IR Template > Copy Template' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/template/view/:templateId', component: ManageIrTemplateComponent, data: { breadcrumb: 'IR Template > View Template' } },
    { path: 'ir/buildir', component: BuildIrListComponent, data: { breadcrumb: 'IR > Build IR' } },
    {
        path: 'ir/buildir/add', component: ManageBuildIrComponent, data: { breadcrumb: 'IR > Build IR > Add' },
        canDeactivate: [CanDeactivateGuardService],
    },
    {
        path: 'ir/buildir/copy/:id', component: ManageBuildIrComponent, data: { breadcrumb: 'IR > Build IR > Copy Ir Config' },
        canDeactivate: [CanDeactivateGuardService],
    },
    {
        path: 'ir/buildir/view/:id', component: ManageBuildIrComponent, data: { breadcrumb: 'IR > Build IR > View IR Config' },
        canDeactivate: [CanDeactivateGuardService],
    }
];

export const routing: ModuleWithProviders<DealConfigurationModule> = RouterModule.forChild(routes);