import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ManageIrTemplateComponent } from 'src/app/deal-config-master/investor-report/ir-template/manage/manage-ir-template.component';

@Component({
  selector: 'cl-manage-ir-template',
  templateUrl: './cl-manage-ir-template.component.html',
  styleUrls: ['./cl-manage-ir-template.component.scss']
})
export class ClManageIrTemplateComponent extends CanDeactivateForm  implements AfterViewInit {
  @ViewChild(ManageIrTemplateComponent) ManageIrTemplateComponent: ManageIrTemplateComponent;
  @ViewChild('manageIrTemplateForm') confirmUnsavedForm: NgForm; 

  constructor() { 
    super();
  }

  ngAfterViewInit(): void {
    this.ManageIrTemplateComponent._fileUploadErrorMsg = 'Please make sure you have Disclaimer, 1 - Communications, 2 - Tranching, 3 - Stratification Tables, 4 - Losses & 5 - Delinquencies tabs in your template';
    this.ManageIrTemplateComponent._viewTemplateListNavPath = 'cl/' + this.ManageIrTemplateComponent._viewTemplateListNavPath;
    this.ManageIrTemplateComponent.InitializeData();
  }

  setChildComponent(myNgForm : NgForm)
  {
    this.confirmUnsavedForm = myNgForm;
  }
  
}