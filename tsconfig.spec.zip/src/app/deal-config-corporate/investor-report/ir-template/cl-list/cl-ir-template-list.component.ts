import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { IrTemplateListComponent } from 'src/app/deal-config-master/investor-report/ir-template/list/ir-template-list.component';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';

@Component({
  selector: 'cl-ir-template-list',
  templateUrl: './cl-ir-template-list.component.html',
  styleUrls: ['./cl-ir-template-list.component.scss']
})
export class ClIrTemplateListComponent implements AfterViewInit {
  @ViewChild(IrTemplateListComponent) IrTemplateListComponent: IrTemplateListComponent;

  constructor() {
  }

  ngAfterViewInit(): void {
    this.IrTemplateListComponent._templateCreateNavigationPath = 'cl/' + this.IrTemplateListComponent._templateCreateNavigationPath;
    this.IrTemplateListComponent._templateViewNavigationPath = 'cl/' + this.IrTemplateListComponent._templateViewNavigationPath;
    this.IrTemplateListComponent._templateEditNavigationPath = 'cl/' + this.IrTemplateListComponent._templateEditNavigationPath;
    this.IrTemplateListComponent._templateCopyNavigationPath = 'cl/' + this.IrTemplateListComponent._templateCopyNavigationPath;
    this.IrTemplateListComponent._permission = PermissionEnum.CW_IR_Config;
    this.IrTemplateListComponent.initializeData();    
  }

}