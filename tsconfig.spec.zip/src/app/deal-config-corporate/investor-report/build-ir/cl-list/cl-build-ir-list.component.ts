import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { BuildIrListComponent } from 'src/app/deal-config-master/investor-report/build-ir/list/build-ir-list.component';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';


@Component({
  selector: 'cl-build-ir-list',
  templateUrl: './cl-build-ir-list.component.html',
  styleUrls: ['./cl-build-ir-list.component.scss']
})
export class ClBuildIrListComponent implements AfterViewInit {
  
  @ViewChild(BuildIrListComponent) buildIrListComponent: BuildIrListComponent;

  constructor() { }

  ngAfterViewInit(): void {
    this.buildIrListComponent._addBuildIrNavPath = 'cl/' + this.buildIrListComponent._addBuildIrNavPath;
    this.buildIrListComponent._editBuildIrNavPath = 'cl/' + this.buildIrListComponent._editBuildIrNavPath;
    this.buildIrListComponent._copyBuildIrNavPath = 'cl/' + this.buildIrListComponent._copyBuildIrNavPath;
    this.buildIrListComponent._viewBuildIrNavPath = 'cl/' + this.buildIrListComponent._viewBuildIrNavPath;
    this.buildIrListComponent._viewStratTemplateNavPath = 'cl/' + this.buildIrListComponent._viewStratTemplateNavPath;
    this.buildIrListComponent._permission = PermissionEnum.CW_IR_Config;
    this.buildIrListComponent.InitializeData();
  }

}