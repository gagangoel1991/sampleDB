import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ManageBuildIrComponent } from 'src/app/deal-config-master/investor-report/build-ir/manage/manage-build-ir.component';
 
@Component({
  selector: 'cl-manage-build-ir',
  templateUrl: './cl-manage-build-ir.component.html',
  styleUrls: ['./cl-manage-build-ir.component.scss']
})
export class ClManageBuildIrComponent extends CanDeactivateForm  
implements AfterViewInit {
  @ViewChild(ManageBuildIrComponent) manageBuildIrComponent: ManageBuildIrComponent;
  @ViewChild('manageBuildIrForm') confirmUnsavedForm: NgForm;

  constructor() { 
    super();
  }

  ngAfterViewInit(): void { 
    this.manageBuildIrComponent._fileUploadErrorMsg = 'Please make sure you have Disclaimer, 1 - Communications, 2 - Tranching, 3 - Stratification Tables, 4 - Losses & 5 - Delinquencies tabs in your template';
    this.manageBuildIrComponent._viewIrListNavPath = 'cl/' + this.manageBuildIrComponent._viewIrListNavPath;
  }

  setChildComponent(myNgForm : NgForm)
  { 
    this.confirmUnsavedForm = myNgForm;
  }

}