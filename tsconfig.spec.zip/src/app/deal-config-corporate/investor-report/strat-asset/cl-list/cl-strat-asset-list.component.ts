import { AfterViewInit, ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { StratAssetListComponent } from 'src/app/deal-config-master/investor-report/strat-asset/list/strat-asset-list.component';


@Component({
  selector: 'cl-strat-asset-list',
  templateUrl: './cl-strat-asset-list.component.html',
  styleUrls: ['./cl-strat-asset-list.component.scss']
})
export class ClStratAssetListComponent implements AfterViewInit {
  @ViewChild(StratAssetListComponent) stratAssetListComponent: StratAssetListComponent;

  constructor(private cd: ChangeDetectorRef) { 
  }

  ngAfterViewInit(): void { 
    this.stratAssetListComponent.isNonConfigTab = true;
    this.stratAssetListComponent.isConfigTabDisabled = true;
    this.cd.detectChanges();
    this.stratAssetListComponent._assetStartViewPath = 'cl/' + this.stratAssetListComponent._assetStartViewPath;
    this.stratAssetListComponent._assetStratEditPath = 'cl/' + this.stratAssetListComponent._assetStratEditPath;
    this.stratAssetListComponent._assetStratCopyPath = 'cl/' + this.stratAssetListComponent._assetStratCopyPath;
    this.stratAssetListComponent._nonConfigAssetStratViewPath = 'cl/' + this.stratAssetListComponent._nonConfigAssetStratViewPath;
    this.stratAssetListComponent._assetStratAddPath = 'cl/' + this.stratAssetListComponent._assetStratAddPath;
  }

}