import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ManageStratAssetComponent } from 'src/app/deal-config-master/investor-report/strat-asset/manage/manage-strat-asset.component';
 
@Component({
  selector: 'cl-manage-strat-asset',
  templateUrl: './cl-manage-strat-asset.component.html',
  styleUrls: ['./cl-manage-strat-asset.component.scss']
})
export class ClManageStratAssetComponent extends CanDeactivateForm
implements AfterViewInit {
  @ViewChild(ManageStratAssetComponent) manageStratAssetComponent: ManageStratAssetComponent;
  @ViewChild('createStratForm') confirmUnsavedForm: NgForm; 

  constructor() { 
    super();
  }

  ngAfterViewInit(): void {
    this.manageStratAssetComponent._viewStratListNavPath = 'cl/' + this.manageStratAssetComponent._viewStratListNavPath;
  }

  setChildComponent(myNgForm : NgForm)
  { 
    this.confirmUnsavedForm = myNgForm;
  }
}