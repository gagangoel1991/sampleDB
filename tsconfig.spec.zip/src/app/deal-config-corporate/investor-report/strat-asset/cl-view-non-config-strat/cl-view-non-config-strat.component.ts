import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { ViewNonConfigStratComponent } from 'src/app/deal-config-master/investor-report/strat-asset/view-non-config-strat/view-non-config-strat.component';
 

@Component({
  selector: 'cl-view-non-config-strat',
  templateUrl: './cl-view-non-config-strat.component.html',
  styleUrls: ['./cl-view-non-config-strat.component.scss']
})
export class ClViewNonConfigStratComponent implements AfterViewInit {
  @ViewChild(ViewNonConfigStratComponent) viewNonConfigStratComponent: ViewNonConfigStratComponent;

  constructor() { 
  }

  ngAfterViewInit(): void {
    this.viewNonConfigStratComponent._viewStratListNavPath = 'cl/' + this.viewNonConfigStratComponent._viewStratListNavPath;
  }

}