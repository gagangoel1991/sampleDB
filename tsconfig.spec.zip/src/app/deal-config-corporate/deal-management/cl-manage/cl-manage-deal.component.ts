import { AfterViewInit, ChangeDetectorRef, Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ManageDealComponent } from 'src/app/deal-config-master/deal-management/manage/manage-deal.component';


import { COMMA, ENTER } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';



@Component({
    selector: 'cl-sfp-deal-create',
    templateUrl: 'cl-manage-deal.component.html',
    styleUrls: ['./cl-manage-deal.component.scss'],

})

export class ClManageDealComponent extends CanDeactivateForm implements AfterViewInit {

    private _errDuplicateRedactedFacilityId = "Duplicate Redacted Facility id found."

    constructor(public _toastservice: GlobalToasterService, private cdr: ChangeDetectorRef) {
        super();
    }

    @ViewChild(ManageDealComponent)
    manageDealComponent: ManageDealComponent;


    confirmUnsavedForm: NgForm;
    isLoadCompleted: boolean = false;

    ngAfterViewInit(): void {
        this.manageDealComponent._dealListNavPath = '/cl/dealconfig/deal';
        this.confirmUnsavedForm = this.manageDealComponent.confirmUnsavedForm;
        this.isLoadCompleted = true;
        this.manageDealComponent.riskRetentionPercentage = 95.238095;
        this.cdr.detectChanges();
    }


    onLoadDealModel() {
        this.loadRedactedFacilityIds();
    }


    isDisabled() {
        return this.manageDealComponent.actionType === 'view'
            || (this.manageDealComponent.actionType === 'edit'
                && (this.manageDealComponent.workflowStepId == this.manageDealComponent.actionSendForAuthorization
                    || this.manageDealComponent.workflowStepId == this.manageDealComponent.actionSendForAuthorizationCollapse
                    || this.manageDealComponent.workflowStepId == this.manageDealComponent.actionSendForAuthorizationTerminate
                    || this.manageDealComponent.workflowStepId == this.manageDealComponent.actionCollapse
                    || this.manageDealComponent.workflowStepId == this.manageDealComponent.actionTerminate
                    || this.manageDealComponent.workflowStepId == this.manageDealComponent.actionCollapseReject))
    }

    isMinorAmendmentDisabled() {
        return !this.manageDealComponent.minerAmendmentClicked && this.isDisabled();
    }


    //============Start:Redacted Facility Ids=====================    
    readonly separatorKeysCodes: number[] = [ENTER];
    redactedFacilityIds: RedactedFacilityId[] = [];

    loadRedactedFacilityIds() {
        if (this.manageDealComponent.dealModel.redactedFacilityIds != undefined) {
            this.redactedFacilityIds.length = 0;
            this.manageDealComponent.dealModel.redactedFacilityIds.split(",").forEach(eachfacilityId => {
                if (eachfacilityId) {
                    this.redactedFacilityIds.push({ facilityId: eachfacilityId });
                }
            })
        }
    }

    onKeypressEvent(event: any) {
        if (event.key === ',' || (event.key >= '0' && event.key <= '9')) {
            return true;
        }
        else {
            return false;
        }
    }

    addRedactedFacilityId(event: MatChipInputEvent): void {
        const input = event.input;
        var value = event.value;
        var isDuplicateFould: Boolean = false;
        var isNonNumericFound: Boolean = false;

        var EnteredIDs = value.replace(' ', '').split(',');

        // Check duplicates. 
        // Check Aany non-numeric found on copy-past
        EnteredIDs.forEach(x => {
            value = x.toString();
            if ((value || '').trim()) {
                if (this.redactedFacilityIds.filter(x => x.facilityId == value.trim()).length > 0) {
                    isDuplicateFould = true;
                }
                if (!(/^\d+$/.test(value))) {
                    isNonNumericFound = true;
                }
            }
        });

        if (isDuplicateFould) {
            this._toastservice.openToast(ToasterTypes.error, this.manageDealComponent.title, this._errDuplicateRedactedFacilityId);
            return;
        }

        if (isNonNumericFound) {
            this._toastservice.openToast(ToasterTypes.error, this.manageDealComponent.title, 'Invalid Id entered.');
            return;
        }

        //Check if any non-numeric found on copy-past

        EnteredIDs.forEach(x => {
            value = x.toString();
            // Add RedactedFacilityId
            if ((value || '').trim()) {
                this.redactedFacilityIds.unshift({ facilityId: value.trim() });
                this.manageDealComponent.dealModel.redactedFacilityIds = this.redactedFacilityIds.map(x => x.facilityId).join(",");
            }
        });

        // Reset the input value
        if (input) {
            input.value = '';
        }
    }

    removeRedactedFacilityId(redactedFacilityId: RedactedFacilityId): void {
        const index = this.redactedFacilityIds.indexOf(redactedFacilityId);

        if (index >= 0) {
            this.redactedFacilityIds.splice(index, 1);
            this.manageDealComponent.dealModel.redactedFacilityIds = this.redactedFacilityIds.map(x => x.facilityId).join(",");
        }
    }
    //============Start:Redacted Facility Ids=====================
}




export interface RedactedFacilityId {
    facilityId: string;
}
