import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FieldType, Formatters } from 'angular-slickgrid';
import { DealListComponent } from 'src/app/deal-config-master/deal-management/list/deal-list.component';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { currencyFormatter, hyperLinkFormatter, numberFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SFP_SlickColumn } from 'src/app/shared/components/slick-grid/slick-grid.model';

@Component({
  selector: 'cl-cw-deal-list',
  templateUrl: './cl-deal-list.component.html',
  styleUrls: ['./cl-deal-list.component.scss']
})
export class ClDealListComponent implements AfterViewInit{

  @ViewChild(DealListComponent) dealListComponent: DealListComponent;

  ngAfterViewInit(): void{
    this.dealListComponent.slickColumnArray.push
    ( 
      new SFP_SlickColumn('cashReporting', 'Cash Reporting', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.multiSelect),
      new SFP_SlickColumn('dealInitialSize', 'Deal Initial Size', true, true, 100, FieldType.string, numberFormatter), 
      new SFP_SlickColumn('topupEndDate', 'Topup End Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
      new SFP_SlickColumn('topupFlag', 'Topup Flag', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.multiSelect),
      new SFP_SlickColumn('riskRetentionPercent', 'Regulatory Allocation Percent', true, true, 200, FieldType.string),
      new SFP_SlickColumn('riskRetentionMethod', 'Risk Retention Method', true, true, 100, FieldType.string, undefined, SFP_SlickFilterType.multiSelect),
      new SFP_SlickColumn('riskRetentionHolder', 'Risk Retention Holder', true, true, 100, FieldType.string , undefined, SFP_SlickFilterType.multiSelect)
    );
  }

}