import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { AdhocReportService } from 'src/app/pool-selection-master/adhoc-reporting/services/adhoc-report.service';
import * as _ from 'lodash';
import { Dictionary } from 'lodash';
import { AdhocReportField } from 'src/app/pool-selection-master/adhoc-reporting/models/adhoc-report-field.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { ReferenceRegistryService } from 'src/app/reports/reference-registry-report/services/reference-registry-report.service';
import { DatePipe } from '@angular/common';
import { saveAs } from 'file-saver';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';
import { AuthWorkflowType } from 'src/app/shared/model/auth-workflow-enum';
import { AuthModalConfigModel } from 'src/app/shared/model/auth-modal-config.model';
import { AuthWorkflowPopupComponent } from 'src/app/shared/components/auth-workflow/auth-workflow-popup.component';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { KeyValueLookupService } from 'src/app/shared/services/key-value-lookup.service';
import { KeyValueLookupTypeEnum } from 'src/app/shared/enum/key-value-lookup-type.enum';
import { KeyValueLookupModel } from 'src/app/shared/model/key-value-lookup.model';
import { ReffRegistryReportSelectBisnsDate } from 'src/app/reports/model/reference-registry.model';
import { SelectListEnum } from 'src/app/shared/model/select-lookup.model';
import { SelectLookupService } from 'src/app/shared/services/select-lookup.service';
import { NgForm } from '@angular/forms';
import { DealIrConfigAddEditEntity, DealIrConfigModel } from 'src/app/deal-config-master/investor-report/model/deal-ir-config.model';
import { selectedFieldsInfo } from 'src/app/shared/components/field-selector-utility/models/selectedFields.model';
import { UrlAction } from 'src/app/shared/model/url-action.model';
import { AdhocReportType } from 'src/app/shared/components/field-selector-utility/models/adhoc-report-type.model';
import { RrReportField } from '../models/rr-report-field.model';
import { RrWorkFlowStepEnum } from '../models/rr-workflow-step.enum';
import { RrStratMappedField } from '../models/rr-strat-mapped-field.model';
import { RrPopupResponse } from '../models/rr-popup-response.model';

@Component({
  selector: 'cl-build-rr',
  templateUrl: './build-rr.component.html',
  styleUrls: ['./build-rr.component.scss'],
  providers: [ReferenceRegistryService, KeyValueLookupService, SelectLookupService, AdhocReportService],
  // encapsulation: ViewEncapsulation.None
})
export class ClBuildRrComponent implements OnInit {

  public selectedTab: number;

  public title: string = '';
  public selectedDealName: string = '';
  public tabIRBuildActive: string = 'active';
  public tabDownloadActive: string = '';
  public tabUploadActive: string = '';

  public dealRrrConfigId: number;
  public actionType: UrlAction;

  public id: any;


  public dealNameList: Array<KeyValueLookupModel>;
  public adhocReportTypeList: AdhocReportType[];
  public adhocReportTypeRefReg: AdhocReportType;



  selectedDealId: number;
  myDate = new Date();
  isReportCalled: boolean = false;
  public businessDateList: Array<ReffRegistryReportSelectBisnsDate> = [];
  public businessDate: string;


  private readonly _addRecordTitle = 'Add Build RR for : ';

  private readonly _editRecordTitle = 'Edit Build RR for : ';
  private readonly _copyRecordTitle = 'Copy Build RR for : ';

  private readonly _invalidActionTitle = 'Resource is not available';

  private readonly _reportGenerationSuccessMessage = 'Report generated successfully!!';

  private readonly _title = "Reference Registry Report";
  private readonly _refRegNotFoundMsg = "Reference Registry Report not found for given parameters.";
  private readonly _templateSavedMsg = 'Build RR template is saved successfully.';
  private readonly _templateTitleDuplicateMsg = 'Build RR template name is already exist, should be unique';
  private readonly _templateDownloadMessage = 'Uploaded Template Download successfully';
  private readonly _savedMsg = 'Build RR is saved successfully.';


  public _isDisabled = false;

  private readonly _refRegLstUrl = '/cl/dealconfig/rr/buildrr';

  private readonly _reffRegistryReportDatabaseError = 'An error occured while processing your request.';
  private readonly _templateFileUploadErrorMsg = 'Please select Build RR template file for sucessfull upload.';
  private readonly _templateFileSizeExceedMsg = 'Build RR file size cannot exceed 20MB.';
  private readonly _templateFileInvalidFileFormatMsg = 'Selected file format/type is not allowed. Allowed file types is xlsx.';
  private readonly _templateToastTitle = 'Build RR Template';
  private readonly _nameDuplicateMsg = 'Build RR name should be unique, please enter another name';
  private readonly _savedErrorMsg = 'Build RR not saved successfully.';

  allDataLoaded: boolean = true;

  vintageDateInvalid: boolean = true;
  public templateFileToUpload: File = null;

  dynamicReportFields = new Array<RrReportField>();
  groupedDynamicReportFields: Dictionary<RrReportField[]>;
  groupedDynamicSelctedReportFields: Dictionary<RrReportField[]>;
  selectedFieldsInfoArray: any = new Object();

  datePipe = new DatePipe('en-UK');

  public templateFileUploadRequiredValidation: boolean = false;

  displayFieldNameSet = new Set();
  ValueSet = new Set();



  //Start: Page controls permission 
  canSave: boolean = false;
  canUpdate: boolean = false;
  canSendForAuthorisation: boolean = false;
  canAuthoriseReject: boolean = false;
  canRecall: boolean = false;
  isChangeRestricted: boolean = true;
  //End: Page controls permission 


  //Start: user role permission
  canUserView: boolean = false;
  canUserUpdate: boolean = false;
  canUserDelete: boolean = false;
  canUserAuthorized: boolean = false;
  canUploadTemplate: boolean = false;
  canDownloadUploadedTemplate: boolean = false;
  //End: user role permission

  public dealIrConfigRecord: DealIrConfigModel;
  public dealIrConfigRecordCopy: DealIrConfigModel;
  public actionDraft: number;
  private readonly _allowedFiles = ['xlsx'];


  private readonly _maxAllowedFileSiz: number = (1024 * 1024 * 20);
  public selectedTabName: string = 'Build-RR';

  @ViewChild('manageBuildIrForm') manageBuildIrForm: NgForm;
  @ViewChild('manageUploadIrForm') manageUploadIrForm: NgForm;

  public get UrlAction() {
    return UrlAction;
  }

  constructor(private _AdhocReportService: AdhocReportService, private _route: ActivatedRoute,
    private _router: Router, private _toastservice: GlobalToasterService,
    private _referenceRegistryService: ReferenceRegistryService,
    private _modalService: NgbModal, private _userRoleService: UserRoleService,
    private _lookupService: KeyValueLookupService, private _selectLookupService: SelectLookupService,) {
    console.clear();
    this._route.params.subscribe((params: Params) => {

      this.dealRrrConfigId = (params['id'] && params['id'] != null) ? params['id'] : null;
      var actionType = (params['action'] && params['action'] != null) ? params['action'] : null;

      if (!isNaN(this.dealRrrConfigId)) {

      }


      this.dealRrrConfigId = this.dealRrrConfigId ?? 0;

      switch (actionType) {

        case UrlAction.add:
          this.actionType = UrlAction.add;
          this.title = this._addRecordTitle;
          this.dealRrrConfigId = this.dealRrrConfigId ?? 0;
          this.onAddAction();
          break;
        case UrlAction.view:
          this.actionType = UrlAction.view;
          this.title = this._editRecordTitle;
          this.onViewAction();
          break;
        case UrlAction.copy:
          this.title = this._copyRecordTitle;
          this.actionType = UrlAction.copy;
          this.onViewAction();
          break;
        default:
          this.title = this._invalidActionTitle;

      }
    });

  }

  ngOnInit(): void {
    this.actionDraft = RrWorkFlowStepEnum.Draft;
    this.setUpUserRolesAndPermissions();
    this.getBusinessDates();
  }

  onAddAction() {
    this.getPageInitialData();
  }

  onViewAction() {
    this.getPageInitialData();
  }

  getPageInitialData() {
    this.getRefRegDeals();
  }

  getRefRegDeals() {
    this._lookupService.getKeyLookupList(KeyValueLookupTypeEnum.ReferenceRegistryDeals.toString()).subscribe(result => {
      this.dealNameList = result;
      this.getAdhocReportTypeList();
    });
  }

  getAdhocReportTypeList() {
    this._AdhocReportService.getAdhocReportTypeList().subscribe(result => {
      this.adhocReportTypeList = result;
      this.adhocReportTypeRefReg = this.adhocReportTypeList.filter(x => x.reportTypeName == "Reference registry")[0];
      this.getReportFields();

    });
  }


  getReportTemplateDataById() {


    this._referenceRegistryService.getbuildRrrConfig(this.dealRrrConfigId).subscribe(result => {

      this.dealIrConfigRecord = JSON.parse(JSON.stringify(result));
      this.dealIrConfigRecordCopy = JSON.parse(JSON.stringify(result));

      this.dealIrConfigRecord.iR_Config.reportTypeId = this.adhocReportTypeRefReg.adhocReportTypeId;

      //Ref Reg ID Not Found in DB 
      if (this.dealIrConfigRecord.iR_Config == null) {
        this._toastservice.openToast(ToasterTypes.error, this._title, this._refRegNotFoundMsg);
        this.redirectToRefRegListingPage();
      }
      //Not a Ref Reg Report
      if (this.dealIrConfigRecord.iR_Config.reportTypeId != this.adhocReportTypeRefReg.adhocReportTypeId) {
        this._toastservice.openToast(ToasterTypes.error, this._title, this._refRegNotFoundMsg);
        this.redirectToRefRegListingPage();
      }
      else if (this.actionType == UrlAction.copy) {
        this.dealRrrConfigId = 0;
        this.dealIrConfigRecord.iR_Config.name = this.dealIrConfigRecord.iR_Config.name + "_Copy";
        if (!this.dealIrConfigRecord.iR_Config.canShowSecurity)
          this.removeTab('security');

        this.allDataLoaded = true;
        this.dealIrConfigRecord.iR_Config.workFlowStepId = null;
        this.dealIrConfigRecord.iR_Config.status = null;
      }
      else {
        this.dealRrrConfigId = this.dealRrrConfigId;
        if (!this.dealIrConfigRecord.iR_Config.canShowSecurity)
          this.removeTab('security');

        this.allDataLoaded = true;
      }
      this.selectedDealName = this.dealNameList.filter(list => list.key == this.dealIrConfigRecord.iR_Config.dealId)[0]?.value;



      this.setButtonAndControlsVisibility();
    });

  }


  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.dealRrrConfigId, AuthWorkflowType.RR_Reporting_Management)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }
  onChange() {
    this.dealIrConfigRecord.iR_Config.canShowSecurity = !this.dealIrConfigRecord.iR_Config.canShowSecurity;
    if (!this.dealIrConfigRecord.iR_Config.canShowSecurity)
      this.removeTab('security');
    else
      this.rebindPanels(this.dynamicReportFields);

  }

  private getReportFields() {
    this._AdhocReportService.getReportFields().subscribe(result => {
      this.dynamicReportFields = result;

      // Adding Facility Id as a Security level field to display on UI
      let facilityidCol = this.dynamicReportFields.filter(field => field.title.toLowerCase() === 'facilityid')[0];
      facilityidCol = JSON.parse(JSON.stringify(facilityidCol));
      facilityidCol.criteriaFieldTable = 'Security';
      this.dynamicReportFields.push(facilityidCol);

      this.groupedDynamicReportFields = _.groupBy(this.dynamicReportFields, dynamicReportField => dynamicReportField.criteriaFieldTable);
      this.getReportTemplateDataById();
    });

  }

  removeTab(tabName: string) {
    let fieldNameList = [];
    this.rebindPanels(this.dynamicReportFields.filter(x => x.criteriaFieldTable.toLowerCase() !== tabName.toLowerCase()));
    fieldNameList = this.dynamicReportFields.filter(x => x.criteriaFieldTable.toLowerCase() !== tabName.toLowerCase()).map(field => field.title);
    this.dealIrConfigRecord.iR_MappedFieldList = this.dealIrConfigRecord.iR_MappedFieldList.filter(field => fieldNameList.includes(field.title));
  }

  rebindPanels(dynamicReportFields) {
    this.groupedDynamicReportFields = _.groupBy(dynamicReportFields, dynamicReportField => dynamicReportField.criteriaFieldTable);
  }

  onTabChange(tabName: string, event) {
    if ((tabName == 'Download' || tabName == 'Upload') && (this.isAnyUnsavedChange() || this.dealRrrConfigId == -1)) {
      this._toastservice.openToast(ToasterTypes.error, "Reference Registry", "Please save the Build RR Details first.");
      event.stopPropagation();
      return false;
    }
    else {
      this.selectedTabName = tabName;
    }
  }

  viewDealRRRList() {
    this.redirectToRefRegListingPage();
  }


  onDealDropDownChange(objRefRegDealList: KeyValueLookupModel) {
    if (objRefRegDealList != undefined) {
      this.selectedDealName = objRefRegDealList.value;
    }
    else {
      this.selectedDealName = "";
    }
  }

  selectedFields(arrAdhocReportField: selectedFieldsInfo) {

    console.log(arrAdhocReportField);

    this.selectedFieldsInfoArray[arrAdhocReportField.uniqueKey] = arrAdhocReportField.selectedFields;


    var keyFields = this.groupedDynamicReportFields[arrAdhocReportField.uniqueKey];

    keyFields.forEach(element => {
      this.dealIrConfigRecord.iR_MappedFieldList.forEach((selectedElement, index) => {
        if (element.value == selectedElement.value) {
          this.dealIrConfigRecord.iR_MappedFieldList.splice(index, 1);
        }
      });
    });

    this.selectedFieldsInfoArray[arrAdhocReportField.uniqueKey].forEach(element => {
      this.dealIrConfigRecord.iR_MappedFieldList.push(element);
    });


  }



  isAllFieldsValid(): boolean {

    this.dealIrConfigRecord.iR_Config.dealId = this.dealIrConfigRecord.iR_Config.dealId == 0 ? null : this.dealIrConfigRecord.iR_Config.dealId;

    this.manageBuildIrForm.form.controls["irName"].markAsDirty();
    this.manageBuildIrForm.form.controls["irName"].markAsTouched();
    // this.manageBuildIrForm.form.controls["irName"].setErrors({ 'incorrect': true });

    this.manageBuildIrForm.form.controls["dealName"].markAsDirty();
    this.manageBuildIrForm.form.controls["dealName"].markAsTouched();
    // this.manageBuildIrForm.form.controls["dealName"].setErrors({ 'incorrect': true });
    this.displayFieldNameSet.clear();
    this.ValueSet.clear();
    this.dealIrConfigRecord.iR_MappedFieldList.forEach(x => {
      this.displayFieldNameSet.add(x.displayFieldName);
      this.ValueSet.add(x.value);
    })
    if (this.displayFieldNameSet.size != this.ValueSet.size) {
      this._toastservice.openToast(ToasterTypes.error, "Reference Registry", "Field Display Name should be unique.");
      return false;
    }



    if (this.manageBuildIrForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, "Reference Registry", "Please fill all required fields.");
      return false;
    }
    else if (this.dealIrConfigRecord.iR_MappedFieldList.length == 0) {
      this._toastservice.openToast(ToasterTypes.error, "Reference Registry", "Please select atleast one report field.");
      return false;
    }
    else {
      return true;
    }
  }

  RrStratMappedField: Array<RrStratMappedField>;

  save() {
    this.RrStratMappedField = new Array<RrStratMappedField>();



    if (!this.isAnyUnsavedChange()) {
      this._toastservice.openToast(ToasterTypes.error, "Reference Registry", "Please make changes to save.");
    } else if (this.isAllFieldsValid()) {
      this.dealIrConfigRecord.iR_MappedFieldList.forEach(x => {
        this.RrStratMappedField.push(new RrStratMappedField(x.value, x.fieldOrderId, x.displayFieldName, x.aggregationId))
      })

      let Action = this.actionType == UrlAction.copy || this.actionType == UrlAction.add ? "Add" : "Update"

      let obj = new DealIrConfigAddEditEntity(
        this.dealRrrConfigId ?? 0,
        this.dealIrConfigRecord.iR_Config.name,
        this.dealIrConfigRecord.iR_Config.description,
        this.dealIrConfigRecord.iR_Config.dealId,
        this.dealIrConfigRecord.iR_Config.templateId,
        this.dealIrConfigRecord.iR_Config.originalFileName,
        this.dealIrConfigRecord.iR_Config.uploadedFileName,
        RrWorkFlowStepEnum.Draft.valueOf(),
        null,
        Action,
        this.dealIrConfigRecord.iR_Config.authorizerComment,
        this.RrStratMappedField,
        this.dealIrConfigRecord.iR_Config.canShowSecurity ? 1 : 0
      );
      
      console.log('Saved Entity : ', obj);
      this._referenceRegistryService.savebuildRrrConfig(obj).subscribe(result => {
        if (result == -1) {
          this._toastservice.openToast(ToasterTypes.error, this._title, this._nameDuplicateMsg);
        }
        else if (result > 0) {

          this._toastservice.openToast(ToasterTypes.success, this._title, this._savedMsg);
          this.manageBuildIrForm.form.markAsPristine();
          this.manageBuildIrForm.form.markAsUntouched();
          this.dealRrrConfigId = result;
          if (!(this.actionType == UrlAction.copy || this.actionType == UrlAction.add)) {
            this.onViewAction();
          }
          else {
            this.redirectToRefRegListingPage();
          }

        }
        else
          this._toastservice.openToast(ToasterTypes.error, this._title, this._savedErrorMsg);

      });
    }

  }


  redirectToRefRegListingPage() {
    this._router.navigate([this._refRegLstUrl], { relativeTo: this._route });
  }

  getSelectedReportFields(tabName: string) {
    let eachTabSelectedFields: Array<AdhocReportField> = new Array<AdhocReportField>();
    let fieldsInTab = this.groupedDynamicReportFields[tabName];



    fieldsInTab.forEach((item1) => {
      this.dealIrConfigRecord.iR_MappedFieldList.forEach((item2) => {
        if (item1.value == item2.value) {
          eachTabSelectedFields.push(item2);
        }
      })
    });
    return eachTabSelectedFields;
  }



  getBusinessDates() {
    this.businessDateList = [];
    this.businessDate = null;
    let multiListId = [SelectListEnum.CorporateFacilityBussDates]
    this._selectLookupService.getMultiparameterSelectedList(multiListId).subscribe(result => {
      result.forEach(x => {
        let formattedDateText = this.datePipe.transform(x.text, "MMM yyyy");
        this.businessDateList.push({ key: x.text, value: formattedDateText });
      });

      this.businessDateList.sort((val1, val2) => { return +new Date(val2.key) - +new Date(val1.key) });

    });
  }



  generateReffRegistryReportData() {

    if (this.businessDate == null || this.businessDate == '') {
      this._toastservice.openToast(ToasterTypes.error, 'Report Generation', 'Please select business date.');
    }
    else {
      this.isReportCalled = true;
      this._referenceRegistryService.GetRefRegistryReport(this.dealRrrConfigId, this.businessDate, 'response')
        .subscribe(output => {
          this.HandleResponse(output);
        },
          () => {
            this.isReportCalled = false;
          }
        );
    }
  }

  HandleResponse(output: any) {
    if (output !== null) {
      this.downloadReffRegistryReport(output, false);
    } else {
      this._toastservice.openToast(ToasterTypes.error, 'Report Generation', this._reffRegistryReportDatabaseError);
    }
    this.isReportCalled = false;
  }

  downloadReffRegistryReport(result: any, isDynamicReport: boolean = false) {
    let currentDeal = this.dealNameList.filter(list => list.key == this.dealIrConfigRecord.iR_Config.dealId)[0].value;
    const reportName = currentDeal + '_' + this.datePipe.transform(this.businessDate, 'dd MMM yyyy');
    let blob: Blob = null;

    if (isDynamicReport) {
      blob = new Blob([result.body], { type: 'text/csv; charset=utf-8' });
    }
    else {
      blob = new Blob([result.body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    }
    saveAs(blob, reportName);
    this._toastservice.openToast(ToasterTypes.info, 'Report Generation', this._reportGenerationSuccessMessage);
  }

  isAnyUnsavedChange(): boolean {

    let diff1 = _.differenceWith(this.dealIrConfigRecord.iR_MappedFieldList, this.dealIrConfigRecordCopy.iR_MappedFieldList, _.isEqual);
    let diff2 = _.differenceWith(this.dealIrConfigRecordCopy.iR_MappedFieldList, this.dealIrConfigRecord.iR_MappedFieldList, _.isEqual);

    if (diff1.length > 0
      || diff2.length > 0
      || this.dealIrConfigRecordCopy.iR_Config.dealId != this.dealIrConfigRecord.iR_Config.dealId
      || this.dealIrConfigRecordCopy.iR_Config.name != this.dealIrConfigRecord.iR_Config.name
      || this.dealIrConfigRecordCopy.iR_Config.description != this.dealIrConfigRecord.iR_Config.description
      || this.dealIrConfigRecordCopy.iR_Config.templateId != this.dealIrConfigRecord.iR_Config.templateId
      || this.dealIrConfigRecordCopy.iR_Config.canShowSecurity != this.dealIrConfigRecord.iR_Config.canShowSecurity) {
      return true
    }
    else {
      return false;
    }
  }

  sendForAuthorisation() {
    if (!this.isAnyUnsavedChange()) {
      let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.RR_Reporting_Management, RrWorkFlowStepEnum.SendForAuthorisation.valueOf(), 0, 0, this.dealRrrConfigId);
      this.openModalPopup(model);
    } else {
      this._toastservice.openToast(ToasterTypes.error, "Reference Registry", "Please save the Build RR Details first.");
    }
  }

  openModalPopup(model: AuthModalConfigModel) {

    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static',
      keyboard: false
    });

    modalRefPopUp.componentInstance.commentPopUpConfig = model;

    modalRefPopUp.componentInstance.popupEmitService.subscribe((objRrPopupResponse: RrPopupResponse) => {

      switch (objRrPopupResponse.authWorkflowModel.workflowStep.valueOf()) {
        case RrWorkFlowStepEnum.SendForAuthorisation:
          break;
        case RrWorkFlowStepEnum.Approve_Reject:
          objRrPopupResponse.authWorkflowModel.workflowStep = objRrPopupResponse.response ? RrWorkFlowStepEnum.Authorise.valueOf() : RrWorkFlowStepEnum.Reject.valueOf();
          break;
        case RrWorkFlowStepEnum.Recall:
          break;
      }

      this._referenceRegistryService.manageRRAuthWorkflow(objRrPopupResponse.authWorkflowModel).subscribe(result => {
        if (result > 0)
          this._toastservice.openToast(ToasterTypes.success, "Reference Registry", "Record updated sucessfully.");
        this.onViewAction();
      });

      objRrPopupResponse.modalService.dismissAll();
    });
  }

  authoriseReject() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.RR_Reporting_Management, RrWorkFlowStepEnum.Approve_Reject.valueOf(), 0, 0, this.dealRrrConfigId);
    this.openModalPopup(model);
  }

  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.RR_Reporting_Management, RrWorkFlowStepEnum.Draft.valueOf(), 0, 0, this.dealRrrConfigId);
    this.openModalPopup(model);
  }


  handleTemplateFileInput(event: any) {

    if (event && event.target.files) {
      let file = event.target.files.item(0);

      if (!this.validateUploadedFileExtension(file.name)) {
        this._toastservice.openToast(ToasterTypes.error, this._title, this._templateFileInvalidFileFormatMsg);
        event.srcElement.value = '';
        this.setTemplateFileUploadControlInvalid();
        return false;
      }
      if (file.size > this._maxAllowedFileSiz) {

        this._toastservice.openToast(ToasterTypes.error, this._title, this._templateFileSizeExceedMsg);
        event.srcElement.value = '';
        this.setTemplateFileUploadControlInvalid();
        return false;
      }

      //When all validation passed, set the file name
      this.templateFileToUpload = file;
      this.dealIrConfigRecord.iR_Config.originalFileName = this.templateFileToUpload.name;
      this.templateFileUploadRequiredValidation = false;
    }
  }

  validateUploadedFileExtension(fileName: string) {
    var ext = fileName.substring(fileName.lastIndexOf('.') + 1);
    if (this._allowedFiles.some(x => x === ext.toLowerCase()))
      return true;
    else
      return false;
  }

  setTemplateFileUploadControlInvalid() {
    this.manageBuildIrForm.form.controls["manageUploadIrForm"].markAsDirty();
    this.manageBuildIrForm.form.controls["manageUploadIrForm"].markAsTouched();
    this.manageBuildIrForm.form.controls["manageUploadIrForm"].setErrors({ 'incorrect': true });
    this.templateFileUploadRequiredValidation = true;
    this.dealIrConfigRecord.iR_Config.originalFileName = '';
  }





  onUploadDealIr() {
    if (this.manageUploadIrForm.invalid) {
      this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileUploadErrorMsg);
      Object.keys(this.manageUploadIrForm.form.controls).forEach((key) => {
        this.manageUploadIrForm.form.get(key).markAsTouched();
      });

      //this.dealIrConfigId
      if (this.manageUploadIrForm.form.controls["uploadTemplateFile"].invalid)
        this.templateFileUploadRequiredValidation = true;
      else
        this.templateFileUploadRequiredValidation = false;

      return false;
    }

    if (this.dealIrConfigRecord.iR_Config.originalFileName === null) {
      this._toastservice.openToast(ToasterTypes.error, this._templateToastTitle, this._templateFileUploadErrorMsg);
    } else {

      //Saving the RR Template after all validations
      const formData: FormData = new FormData();
      if (this.templateFileToUpload) {
        formData.append('templateFileAsByte', this.templateFileToUpload, this.templateFileToUpload.name);
      }
      else {
        formData.append('templateFileAsByte', null);
        formData.append('originalFileName', this.dealIrConfigRecord.iR_Config.originalFileName);
        formData.append('uploadedFileName', this.dealIrConfigRecord.iR_Config.uploadedFileName);
      }

      formData.append('dealIrConfigId', this.dealRrrConfigId.toString());
      formData.append('action', 'Upload');


      this._referenceRegistryService.uploadDealIR(formData).subscribe(result => {

        if (result === "duplicate") {//Duplicate RR Template title
          this._toastservice.openToast(ToasterTypes.error, this._title, this._templateTitleDuplicateMsg);
          //Mark the name control as invalid
          this.manageUploadIrForm.form.controls['templateName'].setErrors({ 'incorrect': true });
        }
        else {
          //Below these two line will clear the changed state of the form so that user can 
          //be redirected back to list page without alert.
          this.dealIrConfigRecord.iR_Config.uploadedFileName = result;
          this.manageUploadIrForm.form.markAsPristine();
          this.manageUploadIrForm.form.markAsUntouched();
          this._toastservice.openToast(ToasterTypes.success, this._title, this._templateSavedMsg);
          this.setButtonAndControlsVisibility();
        }
      });
    }

  }

  downloadRrrTemplate() {

    if (this.dealIrConfigRecord.iR_Config.uploadedFileName != null) {
      this._referenceRegistryService.downloadBuildRefRegTemplate(this.dealIrConfigRecord.iR_Config.uploadedFileName).subscribe(blob => {
        console.log('Invoice file blob');
        console.log(blob);
        const a = document.createElement('a');
        const objectUrl = URL.createObjectURL(blob);
        a.href = objectUrl
        a.download = this.dealIrConfigRecord.iR_Config.originalFileName;
        a.click();
        URL.revokeObjectURL(objectUrl);
        this._toastservice.openToast(ToasterTypes.success, this._title, this._templateDownloadMessage);
      });

    }
  }

  setButtonAndControlsVisibility() {

    let loggedInUser = this._userRoleService.getCurrentLoginUser();

    this.isChangeRestricted = !(this.canUserUpdate && (this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.Draft.valueOf() || this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.Recall || this.actionType == UrlAction.add || this.actionType == UrlAction.copy));
    this.canSave = this.actionType == UrlAction.add || this.actionType == UrlAction.copy;
    this.canUpdate = this.canUserUpdate && (this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.Draft.valueOf() || this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.Recall);
    this.canRecall = this.canUserUpdate && this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.SendForAuthorisation && loggedInUser?.toLowerCase() == this.dealIrConfigRecord.iR_Config.lastModifiedUserName?.toLowerCase();
    this.canSendForAuthorisation = this.canUserUpdate && this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.Draft.valueOf();
    this.canAuthoriseReject = this.canUserAuthorized && this.dealIrConfigRecord.iR_Config.workFlowStepId == RrWorkFlowStepEnum.SendForAuthorisation.valueOf() && loggedInUser?.toLowerCase() != this.dealIrConfigRecord.iR_Config.lastModifiedUserName?.toLowerCase();
    this.canUploadTemplate = this.canUserUpdate && (this.canSave || this.canUpdate);
    this.canDownloadUploadedTemplate = this.actionType == UrlAction.view && this.dealIrConfigRecord.iR_Config.uploadedFileName != null;


  }

  setUpUserRolesAndPermissions() {
    this.canUserView = this._userRoleService.getPermissionAccess(PermissionEnum.PS_ReffRegistryReportManagement, PermissionAccessTypeEnum.View);
    this.canUserUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.PS_ReffRegistryReportManagement, PermissionAccessTypeEnum.AddEdit);
    this.canUserDelete = this._userRoleService.getPermissionAccess(PermissionEnum.PS_ReffRegistryReportManagement, PermissionAccessTypeEnum.Delete);
    this.canUserAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.PS_ReffRegistryReportManagement, PermissionAccessTypeEnum.ApproveReject);
  }

}