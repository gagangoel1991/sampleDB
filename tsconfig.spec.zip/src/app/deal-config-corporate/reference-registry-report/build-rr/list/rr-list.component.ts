import { AfterViewInit, Component, OnInit, ViewChild } from '@angular/core';
import { FieldType } from 'angular-slickgrid';
import { BuildIrListComponent } from 'src/app/deal-config-master/investor-report/build-ir/list/build-ir-list.component';
import { AdhocReportService } from 'src/app/pool-selection-master/adhoc-reporting/services/adhoc-report.service';
import { ReferenceRegistryService } from 'src/app/reports/reference-registry-report/services/reference-registry-report.service';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { actionPermissionButtonFormatter, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SFP_SlickColumn } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';

@Component({
  selector: 'cl-rr-list',
  templateUrl: './rr-list.component.html',
  styleUrls: ['./rr-list.component.scss'],
  providers: [ReferenceRegistryService, AdhocReportService]
})
export class ClRrListComponent implements AfterViewInit {

  @ViewChild(BuildIrListComponent) buildIrListComponent: BuildIrListComponent;

  //----only for TS-------
  slickColumnArray: any;
  canUpdate: any;
  exportFileName: any;
  //-----------


  ngAfterViewInit(): void {
    debugger;
    this.buildIrListComponent.title = 'Build RR List';
    this.buildIrListComponent._buttonText = 'Add Build RR';
    this.buildIrListComponent._addBuildIrNavPath = 'cl/dealconfig/rr/buildrr/add';
    this.buildIrListComponent._editBuildIrNavPath = 'cl/dealconfig/rr/buildrr/view';
    this.buildIrListComponent._viewBuildIrNavPath = 'cl/dealconfig/rr/buildrr/view';
    this.buildIrListComponent._copyBuildIrNavPath = 'cl/dealconfig/rr/buildrr/copy';
    this.buildIrListComponent._reportTypeName = 'Reference Registry';
    // ----
    this.buildIrListComponent._toastTitle = 'Build RR List';
    this.buildIrListComponent._deletedMsg = 'Build RR is deleted successfully.';
    this.buildIrListComponent._lockedRecordNotAllowedDeleteMsg = 'Build RR is locked, you cannot delete this Build RR.';
    this.buildIrListComponent._deleteConfirmMsg = `Are you sure you want to delete Build RR `;
    this.buildIrListComponent._deleteConfirmMsgTitle = "Delete Build RR confirmation";
    //---------------------
    this.buildIrListComponent._permission = PermissionEnum.PS_ReffRegistryReportManagement;
    this.buildIrListComponent.InitializeData();
    this.buildIrListComponent.bindDealColumns = this.bindDealColumns;
    this.buildIrListComponent.InitializeData();

  }


  bindDealColumns() {

    this.slickColumnArray = <SFP_SlickColumn[]>[];

    if (this.canUpdate) {
      //Preparing grid custom columns
      this.slickColumnArray.push(new SFP_SlickColumn('', 'Action', false, false, 110, FieldType.string,
        actionPermissionButtonFormatter, SFP_SlickFilterType.singleSelect, false, true, null, 110))
    }

    this.slickColumnArray.push
      (

        new SFP_SlickColumn('name', 'Name', true, true, 150, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('description', 'Description', true, true, 120, FieldType.string),
        new SFP_SlickColumn('dealName', 'Deal Name', true, true, 100, FieldType.string),
        new SFP_SlickColumn('templateName', 'Template Name', true, true, 130, FieldType.string),
        new SFP_SlickColumn('isLocked', 'Is Locked', true, true, 80, FieldType.boolean),
        new SFP_SlickColumn('status', 'Status', true, true, 130, FieldType.string)
      );



    //SET EXPORT FILE NAME
    var myDt = new Date();
    var current_timestamp = myDt.getDate() + ' ' + (myDt.toLocaleString('default', { month: 'short' })) + ' ' + myDt.getFullYear();
    this.exportFileName = current_timestamp + '_Build RR List';
  }

}