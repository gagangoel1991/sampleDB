import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { IAuthWorkflowModel } from 'src/app/shared/model/auth-workflow-model';

export class RrPopupResponse {
    response: boolean
    authWorkflowModel: IAuthWorkflowModel;
    modalService: NgbModal

    constructor(_response: boolean, _authWorkflowModel: IAuthWorkflowModel, _modalService: NgbModal) {
        this.response = _response;
        this.authWorkflowModel = _authWorkflowModel;
        this.modalService = _modalService;
    }
}