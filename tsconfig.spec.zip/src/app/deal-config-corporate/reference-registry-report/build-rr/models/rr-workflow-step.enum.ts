export enum RrWorkFlowStepEnum {
    Approve_Reject = -1,
    Draft = 74,
    SendForAuthorisation = 75,
    Authorise = 76,
    Reject = 77,
    Close = 78,
    Recall = 79,
}
