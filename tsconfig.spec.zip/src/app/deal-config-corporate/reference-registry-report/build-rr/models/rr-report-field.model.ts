import { LookupTitleValue } from 'src/app/core/models/lookup-title-value.model';

export class RrReportField extends LookupTitleValue {
    fieldOrderId: number;
    displayFieldName: string;
    aggregationId?: number;
    fieldDescription: string;
    fieldDataType: number;
    criteriaFieldTable: string;
}