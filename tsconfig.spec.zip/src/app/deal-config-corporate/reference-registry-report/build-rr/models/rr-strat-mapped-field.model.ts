export class RrStratMappedField {
    fieldId: number;
    fieldOrderId: number;
    displayFieldName: string;
    aggregationTypeId: number;
    constructor(
        fieldId: number,
        fieldOrderId: number,
        displayFieldName: string,
        aggregationTypeId: number,
    ) {
        this.fieldId = fieldId;
        this.fieldOrderId = fieldOrderId;
        this.displayFieldName = displayFieldName;
        this.aggregationTypeId = aggregationTypeId;
    }

}