import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { NgForm } from '@angular/forms';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { ManageIrTemplateComponent } from 'src/app/deal-config-master/investor-report/ir-template/manage/manage-ir-template.component';

@Component({
  selector: 'cl-manage-rr-template',
  templateUrl: './manage-rr-template.component.html',
  styleUrls: ['./manage-rr-template.component.scss']
})
export class ClManageRrTemplateComponent extends CanDeactivateForm implements AfterViewInit {
  @ViewChild(ManageIrTemplateComponent) ManageIrTemplateComponent: ManageIrTemplateComponent;
  @ViewChild('manageIrTemplateForm') confirmUnsavedForm: NgForm;

  constructor() {
    super();
  }

  ngAfterViewInit(): void {
    this.ManageIrTemplateComponent._viewTemplateListNavPath = 'cl/dealconfig/ir/template/';
    this.ManageIrTemplateComponent._reportTypeName = "Reference Registry";
    // if (this.ManageIrTemplateComponent.templateAction != 'add')
    //   this.ManageIrTemplateComponent.editCopyViewTemplateInitialize(this.ManageIrTemplateComponent.templateId);
    this.ManageIrTemplateComponent.backButtonText = "View RR Template List";
    this.ManageIrTemplateComponent._viewTemplateListNavPath = '/cl/dealconfig/rr/template/';
    this.ManageIrTemplateComponent._addTemplateTitle = 'Add RR Template';
    this.ManageIrTemplateComponent._editTemplateTitle = 'Edit RR Template';
    this.ManageIrTemplateComponent._lockedTemplateTitle = 'This RR Template is locked, you cannot edit this';
    this.ManageIrTemplateComponent._copyTemplateTitle = 'Copy RR Template';
    this.ManageIrTemplateComponent._viewTemplateTitle = 'View RR Template';
    this.ManageIrTemplateComponent.InitializeData();
  }

  setChildComponent(myNgForm: NgForm) {
    this.confirmUnsavedForm = myNgForm;
  }

}