import { AfterViewInit, Component, ViewChild } from '@angular/core';
import { IrTemplateListComponent } from 'src/app/deal-config-master/investor-report/ir-template/list/ir-template-list.component';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';

@Component({
  selector: 'cl-rr-template-list',
  templateUrl: './rr-template-list.component.html',
  styleUrls: ['./rr-template-list.component.scss']
})
export class ClRrTemplateListComponent implements AfterViewInit {
  @ViewChild(IrTemplateListComponent) IrTemplateListComponent: IrTemplateListComponent;

  constructor() {
  }

  ngAfterViewInit(): void {
    //-----------------------
    this.IrTemplateListComponent._templateCreateNavigationPath = '/cl/dealconfig/rr/template/add';
    this.IrTemplateListComponent._templateViewNavigationPath = '/cl/dealconfig/rr/template/view/';
    this.IrTemplateListComponent._templateEditNavigationPath = '/cl/dealconfig/rr/template/edit/';
    this.IrTemplateListComponent._templateCopyNavigationPath = '/cl/dealconfig/rr/template/copy/';
    //-----------------------
    this.IrTemplateListComponent._permission = PermissionEnum.PS_ReffRegistryReportManagement;

    //-----------------------
    this.IrTemplateListComponent.title = "RR Template List";
    this.IrTemplateListComponent._reportTypeName = "Reference Registry";
    //-----------------------
    this.IrTemplateListComponent._templateLockedNotAllowedDeleteMsg = 'This RR Template is locked, you cannot delete this.';
    this.IrTemplateListComponent._templateToasterTitle = 'RR Template';
    this.IrTemplateListComponent._templateToasterDeleteMessage = 'RR template is Deleted Successfully!!'
    this.IrTemplateListComponent._templateFileDownloadedMsg = 'RR template file is successfully downloaded.';
    this.IrTemplateListComponent._deleteConfirmMsg = 'Delete RR Template';
    this.IrTemplateListComponent. _deleteConfirmMsgTitle = "Delete RR Template Data confirmation"
    //-----------------------
    this.IrTemplateListComponent.initializeData();
  }

}