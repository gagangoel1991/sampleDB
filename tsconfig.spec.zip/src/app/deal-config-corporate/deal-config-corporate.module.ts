import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgSelectModule } from '@ng-select/ng-select';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { PerfectScrollbarConfigInterface, PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { DirectivesModule } from '../core/theme/directives/directives.module';
import { PipesModule } from '../core/theme/pipes/pipes.module';
import { DealConfigurationMasterModule } from '../deal-config-master/deal-config-master.module';
import { CustomControlModule } from '../shared/modules/custom-control.module';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = { suppressScrollX: true };

import { dealConfigCorporateRouting } from './deal-config-corporate.routing';
import { ClDealListComponent } from './deal-management/cl-list/cl-deal-list.component';
import { ClManageDealComponent } from './deal-management/cl-manage/cl-manage-deal.component';
import { ClBuildIrListComponent } from './investor-report/build-ir/cl-list/cl-build-ir-list.component';
import { ClManageBuildIrComponent } from './investor-report/build-ir/cl-manage/cl-manage-build-ir.component';
import { ClIrTemplateListComponent } from './investor-report/ir-template/cl-list/cl-ir-template-list.component';
import { ClManageIrTemplateComponent } from './investor-report/ir-template/cl-manage/cl-manage-ir-template.component';
import { ClStratAssetListComponent } from './investor-report/strat-asset/cl-list/cl-strat-asset-list.component';
import { ClManageStratAssetComponent } from './investor-report/strat-asset/cl-manage/cl-manage-strat-asset.component';
import { ClViewNonConfigStratComponent } from './investor-report/strat-asset/cl-view-non-config-strat/cl-view-non-config-strat.component';
import { ClRrListComponent } from './reference-registry-report/build-rr/list/rr-list.component';
import { ClBuildRrComponent } from './reference-registry-report/build-rr/manage/build-rr.component';
import { ClRrTemplateListComponent } from './reference-registry-report/rr-template/list/rr-template-list.component';
import { ClManageRrTemplateComponent } from './reference-registry-report/rr-template/manage/manage-rr-template.component';

@NgModule({
  declarations: [
    ClIrTemplateListComponent,
    ClManageIrTemplateComponent,
    ClStratAssetListComponent,
    ClManageStratAssetComponent,
    ClViewNonConfigStratComponent,
    ClBuildIrListComponent,
    ClManageBuildIrComponent,
    ClDealListComponent,
    ClManageDealComponent,
    ClRrTemplateListComponent,
    ClManageRrTemplateComponent,
    ClRrListComponent,
    ClBuildRrComponent
  ],
  imports: [
    dealConfigCorporateRouting,
    DealConfigurationMasterModule,
    MatChipsModule,
    MatIconModule,
    MatFormFieldModule,
    CommonModule,
    FormsModule,
    NgSelectModule,
    NgbModule,
    CustomControlModule,
    CommonModule,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    FormsModule,
    ReactiveFormsModule,
    MultiselectDropdownModule,  
  ],
  providers: [{
    provide: PERFECT_SCROLLBAR_CONFIG,
    useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
  }],
  entryComponents: []

})
export class DealConfigurationCorporateModule { }
