import { Routes, RouterModule } from '@angular/router';
import { ModuleWithProviders } from '@angular/core';
import { CanDeactivateGuardService } from 'src/app/core/guard/can-deactivate/can-deactivate-guard.service';

import { DealConfigurationCorporateModule } from './deal-config-Corporate.module';
//import { IrTemplateListComponent } from 'src/app/deal-config-master/investor-report/ir-template/list/ir-template-list.component';
//import { ManageIrTemplateComponent } from 'src/app/deal-config-master/investor-report/ir-template/manage/manage-ir-template.component';
//import { StratAssetListComponent } from 'src/app/deal-config-master/investor-report/strat-asset/list/strat-asset-list.component';
//import { ManageStratAssetComponent } from 'src/app/deal-config-master/investor-report/strat-asset/manage/manage-strat-asset.component';
//import { BuildIrListComponent } from 'src/app/deal-config-master/investor-report/build-ir/list/build-ir-list.component';
//import { ManageBuildIrComponent } from 'src/app/deal-config-master/investor-report/build-ir/manage/manage-build-ir.component';
 
//import { DealListComponent } from '../deal-config-master/deal-management/list/deal-list.component';
// import { ManageDealComponent } from '../deal-config-master/deal-management/manage/manage-deal.component';
//import { ViewNonConfigStratComponent } from '../deal-config-master/investor-report/strat-asset/view-non-config-strat/view-non-config-strat.component';

import { ClStratAssetListComponent } from './investor-report/strat-asset/cl-list/cl-strat-asset-list.component';
import { ClManageStratAssetComponent } from './investor-report/strat-asset/cl-manage/cl-manage-strat-asset.component';
import { ClIrTemplateListComponent } from './investor-report/ir-template/cl-list/cl-ir-template-list.component';
import { ClManageIrTemplateComponent } from './investor-report/ir-template/cl-manage/cl-manage-ir-template.component';
import { ClBuildIrListComponent } from './investor-report/build-ir/cl-list/cl-build-ir-list.component';
import { ClManageBuildIrComponent } from './investor-report/build-ir/cl-manage/cl-manage-build-ir.component';
import { ClViewNonConfigStratComponent } from './investor-report/strat-asset/cl-view-non-config-strat/cl-view-non-config-strat.component';
import { ClDealListComponent } from './deal-management/cl-list/cl-deal-list.component';
import { ClManageDealComponent } from './deal-management/cl-manage/cl-manage-deal.component';
import { ClRrListComponent } from './reference-registry-report/build-rr/list/rr-list.component';
import { ClBuildRrComponent } from './reference-registry-report/build-rr/manage/build-rr.component';
import { ClRrTemplateListComponent } from './reference-registry-report/rr-template/list/rr-template-list.component';
import { ClManageRrTemplateComponent } from './reference-registry-report/rr-template/manage/manage-rr-template.component';

 

export const routes: Routes = [
    { path: '', redirectTo: 'dashboard', pathMatch: 'full' },
    { path: 'deal', component: ClDealListComponent, data: { breadcrumb: 'Deal Management' } },
    { path: 'deal/create', component: ClManageDealComponent, data: { breadcrumb: 'Deal Management > New Deal' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'deal/copy/:dealId', component: ClManageDealComponent, data: { breadcrumb: 'Deal Management > Copy Deal' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'deal/view/:dealId', component: ClManageDealComponent, data: { breadcrumb: 'Deal Management > View Deal' }, canDeactivate: [CanDeactivateGuardService] },

    { path: 'ir/assetstrat', component: ClStratAssetListComponent, data: { breadcrumb: 'Strat Management' } },
    { path: 'ir/assetstrat/:stratType', component: ClStratAssetListComponent, data: { breadcrumb: 'Strat Management' } },
    { path: 'ir/assetstrat/configlist/create', component: ClManageStratAssetComponent, data: { breadcrumb: 'Strat Management > Create Strat' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/assetstrat/configlist/copy/:stratId', component: ClManageStratAssetComponent, data: { breadcrumb: 'Strat Management > Copy Strat' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/assetstrat/configlist/view/:stratId', component: ClManageStratAssetComponent, data: { breadcrumb: 'Strat Management > View Strat' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/assetstrat/nonconfiglist/view/:stratId', component: ClViewNonConfigStratComponent },

    { path: 'ir/template', component: ClIrTemplateListComponent, data: { breadcrumb: 'IR Template' } },
    { path: 'ir/template/add', component: ClManageIrTemplateComponent, data: { breadcrumb: 'IR Template > Add Template' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/template/copy/:templateId', component: ClManageIrTemplateComponent, data: { breadcrumb: 'IR Template > Copy Template' }, canDeactivate: [CanDeactivateGuardService] },
    { path: 'ir/template/view/:templateId', component: ClManageIrTemplateComponent, data: { breadcrumb: 'IR Template > View Template' } },
    { path: 'ir/buildir', component: ClBuildIrListComponent, data: { breadcrumb: 'IR > Build IR' } },
    {
        path: 'ir/buildir/add', component: ClManageBuildIrComponent, data: { breadcrumb: 'IR > Build IR > Add' },
        canDeactivate: [CanDeactivateGuardService],
    },
    {
        path: 'ir/buildir/copy/:id', component: ClManageBuildIrComponent, data: { breadcrumb: 'IR > Build IR > Copy Ir Config' },
        canDeactivate: [CanDeactivateGuardService],
    },
    {
        path: 'ir/buildir/view/:id', component: ClManageBuildIrComponent, data: { breadcrumb: 'IR > Build IR > View IR Config' },
        canDeactivate: [CanDeactivateGuardService],
    },
    { path: 'rr/template', component: ClRrTemplateListComponent },
    { path: 'rr/template/add', component: ClManageRrTemplateComponent },
    { path: 'rr/template/copy/:templateId', component: ClManageRrTemplateComponent },
    { path: 'rr/template/view/:templateId', component: ClManageRrTemplateComponent },

    { path: 'rr/buildrr', component: ClRrListComponent },
    { path: 'rr/buildrr/:action', component: ClBuildRrComponent },
    { path: 'rr/buildrr/:action/:id', component: ClBuildRrComponent }
];

export const dealConfigCorporateRouting: ModuleWithProviders<DealConfigurationCorporateModule> = RouterModule.forChild(routes);