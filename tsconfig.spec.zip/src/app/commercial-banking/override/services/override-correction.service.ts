import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { GlobalHttpService } from "src/app/core/services/api/global.http.service";
import { FacilitySecurityLinkList } from "../models/override-data-list.model";


@Injectable({ providedIn: 'root' })
class OverrideService {

    private readonly apiUrl: string = '/commercialbanking';
    constructor(private _globalHttpService: GlobalHttpService) { }

    getUpdateOverrideList(dealID,asAtDate): Observable<any> {
        return this._globalHttpService.GetRequest(this.apiUrl + '/cb/getUpdateOverrideList/' + dealID.toString()  + '/' + asAtDate.toString());
    }

    public GetLinkageAuditReportData(dealID, vintageDate) {
      return this._globalHttpService.GetRequestWithBlobType(this.apiUrl + '/getLinkageAuditReportData'
       + '/' + dealID.toString() +'/'+ vintageDate
       , null, null, 'response');
    }

    public GetFacilityOverrideData(dealID, asAtDate, isTemplate) {
        return this._globalHttpService.GetRequestWithBlobType(this.apiUrl + '/downloadFacilityOverrideData' 
        + '/' + dealID.toString() 
        + '/' + isTemplate.toString()
        + '/' + asAtDate.toString() 
        , null, null, 'response');
      }
      public GetSecurityOverrideData(dealID, asAtDate, isTemplate) {
        return this._globalHttpService.GetRequestWithBlobType(this.apiUrl + '/downloadSecurityOverrideData'
         + '/' + dealID.toString() 
         + '/' + isTemplate.toString()
         + '/' + asAtDate.toString()
         , null, null, 'response');
      }

      public GetComparisionData(dealIrConfigId, dealID, asAtDate,previousReportingDate,anyDiffFlag, entity) { 
        return this._globalHttpService.GetRequestWithBlobType(this.apiUrl + '/downloadComparisionData'
        + '/' + dealIrConfigId.toString() 
        + '/' + dealID.toString() 
        + '/' + asAtDate.toString()
        + '/' + previousReportingDate.toString()
        + '/' + anyDiffFlag.toString()
        + '/' + entity.toString()
        , null, null, 'response');
      }
    
    
      public saveOverrideData(templateData: FormData, dealID : string, asAtDate:string):Observable<any> {
        return this._globalHttpService.PostFormDataRequest(this.apiUrl + '/saveOverrideData'+ '/' + dealID 
        + '/' + asAtDate, templateData);
      }

    public downloadAuditTrailReport(dealId: string, entityType: string, vintageDate: string): Observable<any> {
      return this._globalHttpService.GetRequestWithBlobType(this.apiUrl 
        + '/downloadOverrideAuditTrail'
        + '/' + dealId.toString()
        + '/' + entityType.toString()
        + '/' + vintageDate.toString(), null, null, 'response');
    }

    getOverrideVintageDatesList(dealID: string): Observable<any> {
      return this._globalHttpService.GetRequest(this.apiUrl + '/getOverrideVintageDatesList/' + dealID.toString());
    }

    public GetFacilitySecurityLinkStatus(asAtDate:string, comparisonDate:string, dealID : string):Observable<any> {
      return this._globalHttpService.GetRequest(this.apiUrl + '/cb/getFacilitySecurityLinkStatus/' 
                + asAtDate.toString() 
                + '/' + comparisonDate.toString()  
                + '/' + dealID.toString());
    }

    public resetOverrideData(DealOverrideParentId : string, entityType:string):Observable<any> {
      return this._globalHttpService.GetRequest(this.apiUrl + '/resetOverrideData'+ '/' + DealOverrideParentId 
      + '/' + entityType);
    }
     
}

export { OverrideService }