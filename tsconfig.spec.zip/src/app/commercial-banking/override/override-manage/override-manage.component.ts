import { DatePipe } from '@angular/common';
import { Component, OnInit, ViewChild, ViewEncapsulation } from '@angular/core';
import { FormBuilder, FormGroup, NgForm } from '@angular/forms';
import { ActivatedRoute, Router, Params } from '@angular/router';
import { DealModel } from 'src/app/deal-config-master/model/deal.model';
import { SelectListEnum } from 'src/app/shared/model/select-lookup.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SelectLookupService } from 'src/app/shared/services/select-lookup.service';

import { OverrideVintageDate } from '../models/override-vintage-date.model';
import { saveAs } from 'file-saver';
import { HeaderCollectionModel } from 'src/app/cash-waterfall/ipd-run-process/model/deal-subloan.model';
import { ExportExcelUtility } from 'src/app/shared/utility/export-excel-utility';
import * as xlsx from 'xlsx';
import { OverrideService } from '../services/override-correction.service';
import { CanDeactivateForm } from 'src/app/core/guard/can-deactivate/can-deactivate-form.component';
import { AuthWorkflowService } from 'src/app/shared/services/auth-workflow-service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthWorkflowStatusModel } from 'src/app/shared/model/auth-workflow-status.model';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';
import { AuthWorkflowStep, AuthWorkflowType } from 'src/app/shared/model/auth-workflow-enum';
import { AuthModalConfigModel } from 'src/app/shared/model/auth-modal-config.model';
import { AuthWorkflowPopupComponent } from 'src/app/shared/components/auth-workflow/auth-workflow-popup.component';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { UserModel } from 'src/app/shared/home/user.model';
import { UserPermissionModel } from 'src/app/shared/model/user-permission.model';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { SFP_SlickColumn } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { FieldType } from 'angular-slickgrid';
import { GenerateOverrideAuditTrailReport } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { EditableGridColumnModel } from 'src/app/shared/model/editable-grid-column.model';
import { FacilitySecurityLinkList } from '../models/override-data-list.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { OrderByPipe } from 'ngx-pipes';

@Component({
  selector: 'override-manage',
  encapsulation: ViewEncapsulation.None,
  templateUrl: './override-manage.component.html',
  styleUrls: ['./override-manage.component.scss'],
  providers: [OrderByPipe, SelectLookupService]
})
export class OverrideManageComponent extends CanDeactivateForm implements OnInit {

  private dealId: number = 0;

  public title: string = "Reference Registry Override";
  public workflowStepId = 1;
  public dealModel: DealModel;
  public businessDate : any;
  public comparisionBusinessDate : any;
  private rbnDealName : string;
  public rbnStatus : string;
  private rbnActionBy : string;
  private rbnActionDate : string;
  public lastAuthVintageDate : any;
  public DealOverrideParentId = 0;
  
  public chkFirbnActionBylterDiffOnly: boolean;
  datePipe = new DatePipe('en-UK');
  
  public _viewUpdateAndOverrideNavPath = '/cl/commercialbanking/override';

  chkFilterDiffOnly : boolean;
  isReportCalled: boolean = false;
  isFacilityCompareCalled: boolean = false;
  isSecurityCompareCalled: boolean = false;
  isSaveCalled: boolean = false;
  public isLinkageDataLoading: boolean = false;
  private readonly _templateDownloadSuccessMessage = 'File downloaded successfully!!';
  public reportdate: string;
  public uploadFileNameFacility : string = '';
  public uploadFileNameSecurity : string = '';
  public validFileExtensions: string[] = ['xlsx'];
  public uploadFileName = '';
  public uploadedData: [][];
  public isNoRecordsError: boolean;
  public isInvalidFormatError: boolean;
  public templateFileToUploadFacility: File = null;
  public templateFileToUploadSecurity: File = null;
  public exportHeaders: Array<HeaderCollectionModel> = [];
  public exportExcelUtility = new ExportExcelUtility();

  public ddcAuthStatusModel: AuthWorkflowStatusModel;
  ddcStatusId: number;
  public isSheetSubmittedOrAuthorised: boolean;
  userDetail: UserModel = new UserModel('', '', '', '', '', '', []);
  userName: string;
  userPermissionOnDealDataCorrection: UserPermissionModel[];
  public isAuthoriser: boolean = false;
  public isUser: boolean = false; 
  public viewOnlyUser: boolean;
  public slickDataset: any[];
  //public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];

  public linkGridCols: Array<EditableGridColumnModel> = [];
  public linkageList: Array<FacilitySecurityLinkList> = <FacilitySecurityLinkList[]>[];
  public sourcelinkageList: Array<FacilitySecurityLinkList> = <FacilitySecurityLinkList[]>[];
  public updatedlinkageList: Array<FacilitySecurityLinkList> = <FacilitySecurityLinkList[]>[];
  public exportlinkageList: Array<any> = [];
  public filteredData = [];
  public linkageForm: Array<FormGroup> = [];
  public exportFileName = 'FacilitySecurityLinkStatus.xlsx';
  public ColumnMode = ColumnMode;
  public selectedSortCol = '';
  public colSortType = 'asc';
  public isListEdited = false; 
  public isCheckboxTouched = 0;
  public isFacilityDownloadAvailable = 0;
  public isSecurityDownloadAvailable = 0;
  public IsLinkagesAvailable = 0;
  public OtherDraftAvailableMonth = ''; 

  public FacilityFileUploadData:string[][];
  public SecurityFileUploadData:string[][];
  public resetEntity : string;
  public resultObj:any;
  public uploadError:string;

  vintageDateList: OverrideVintageDate[] = new Array<OverrideVintageDate>();

  @ViewChild('overrideForm') confirmUnsavedForm: NgForm;
  @ViewChild('overrideForm') overrideForm: NgForm;
  @ViewChild('resetConfirmation') resetConfirmation: any;
  @ViewChild('errorResponseDownload') errorResponseDownload: any;

  constructor(private _selectLookupService: SelectLookupService, 
    private _router: Router, 
    private _route: ActivatedRoute,
    private _overrideService: OverrideService,
    private _globalToasterService: GlobalToasterService,
    private _userService: UserRoleService,
    private _ddcAuthWorkflowService: AuthWorkflowService,
    private _modalService: NgbModal,
    private fb: FormBuilder,
    private _sharedDataService: SharedDataService,
    private ngxOrderPipe: OrderByPipe) {
    super();
    this.ddcAuthStatusModel = new AuthWorkflowStatusModel('', '', 1, '', '', '', '');
    this._route.params.subscribe((params: Params) => {
      this.dealId = (params['dealId'] && params['dealId'] != null) ? params['dealId'] : null;
    });  
  }

  ngOnInit(): void {
    this.isLinkageDataLoading = false;
    this.dealModel = new DealModel() //temporary 
    this.getBusinessDates();
    this.getOverrideDetailToBanner(); 
    this.setUpUserRolesAndPermissions();
    
    this.bindUpdateAndOverrideColumns();
  }
 
  getOverrideDetailToBanner() {
    this.rbnDealName = "";
    this.rbnStatus= "";
    this.rbnActionBy = "";
    this.rbnActionDate= "";
    this.lastAuthVintageDate = "";
    this.DealOverrideParentId = 0;
    this.isFacilityDownloadAvailable = 0;
    this.isSecurityDownloadAvailable = 0;
    this.IsLinkagesAvailable = 0;
    this.OtherDraftAvailableMonth = '';

    if(this.dealId)
    {
      this._overrideService.getUpdateOverrideList(this.dealId.toString(),  (this.businessDate ? this.businessDate : ''))
      .subscribe(result => {

        let lstOverrideDetail: any[];
        lstOverrideDetail = JSON.parse(JSON.stringify(result)); 
        //console.log(lstOverrideDetail);
        if(lstOverrideDetail && lstOverrideDetail.length > 0)
        {
          this.rbnDealName = lstOverrideDetail[0].dealName;

          if(this.businessDate)
          {
            this.rbnStatus = lstOverrideDetail[0].status;
            this.rbnActionBy = lstOverrideDetail[0].lastActionBy;
            this.rbnActionDate = 
                  lstOverrideDetail[0].lastActionDate ? this.datePipe.transform(lstOverrideDetail[0].lastActionDate, 'dd-MM-yyyy') : '';
            this.lastAuthVintageDate =lstOverrideDetail[0].lastAuthVintageDate;
            this.DealOverrideParentId = lstOverrideDetail[0].dealOverrideParentId;
            this.ddcStatusId = lstOverrideDetail[0].statusId;
            this.isFacilityDownloadAvailable = lstOverrideDetail[0].isFacilityDownloadAvailable;
            this.isSecurityDownloadAvailable = lstOverrideDetail[0].isSecurityDownloadAvailable;
            this.IsLinkagesAvailable = lstOverrideDetail[0].isLinkagesAvailable;
            this.OtherDraftAvailableMonth = lstOverrideDetail[0].otherDraftAvailableMonth;


			this.initializeWorkflowStep(this.ddcStatusId);

            this.viewOnlyUser = (
              (lstOverrideDetail[0].createdBy 
                && lstOverrideDetail[0].createdBy !== '' 
                && (this.ddcAuthStatusModel.stepName.toLowerCase() != 'authorise' 
                && lstOverrideDetail[0].createdBy.toLowerCase() !== this.userName)  
                ) 
              || !this.isUser);

            
          }
        }
      });
    }
  }

  getBusinessDates() {
    let multiListId = [SelectListEnum.CorporateFacilityBussDates]
    this._selectLookupService.getMultiparameterSelectedList(multiListId).subscribe(result => {
      result.forEach(x => {
        let formattedDateText = this.datePipe.transform(x.text, "MMM yyyy");
        this.vintageDateList.push({ key: x.text, value: formattedDateText });
      });

      this.vintageDateList.sort((val1, val2) => { return +new Date(val2.key) - +new Date(val1.key) });

    });
  }

  onViewUpdateAndOverrideList() {    
    this._router.navigate([this._viewUpdateAndOverrideNavPath]);
  }

  onSave() { 
    
      if(this.isReportCalled ===  true) {
        this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'Previous action is Inprogress, Please try later');
        return;
      }

      if (!this.businessDate) {
        this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'Please select Vintage date');
        return;
      }

     if(this.businessDate < this.datePipe.transform(this.lastAuthVintageDate, 'yyyy-MM-dd'))
      {
        this._globalToasterService.openToast(ToasterTypes.error, 'Data Override', 'Override Vintage date should not be less than ' 
        + this.datePipe.transform(this.lastAuthVintageDate, 'MMM yyyy'));
        return;
     }
      
      /*var EditedRows = this.linkageList.filter(x => x?.isListEdited == 1);
      if(EditedRows.length == 0 &&  !this.templateFileToUploadFacility && !this.templateFileToUploadSecurity)
      {
          this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'No changes detected. Nothing to save');
          return;
      }*/
      
      if(this.isCheckboxTouched == 0 &&  !this.templateFileToUploadFacility && !this.templateFileToUploadSecurity)
      {
          this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'No changes detected. Nothing to save');
          return;
      }

      if(this.OtherDraftAvailableMonth &&  this.OtherDraftAvailableMonth != '')
      {
          this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'Cannot save, Draft data is already available for ' + this.OtherDraftAvailableMonth );
          return;
      }

      //if ( !this.templateFileToUploadFacility && !this.templateFileToUploadSecurity ) {
      //  this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'Please select at least one file to upload');
      //}
       
      {
          const FormDataFacilitySecurity: FormData  = this.prepareFileToUpload();

          this.isReportCalled =  true;
          this.isSaveCalled = true;
          this._globalToasterService.openToast(ToasterTypes.info, 'Data save started', ''); 

          this._overrideService.saveOverrideData(FormDataFacilitySecurity, this.dealId.toString(), this.businessDate)
          .subscribe(result => { 
            this.handleSaveResponse(result);
            this.isReportCalled =  false;  
            this.isSaveCalled = false;

          }); 
      }
  }

 
  DownloadFacility(isTemplate: any) {

    if(this.isReportCalled ===  true) {
      this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'Previous action is in progress. Please try later');
    }
    else {
      if ( isTemplate == 0 && !this.businessDate) {
        this._globalToasterService.openToast(ToasterTypes.error, 'Data Override', 'Please select Vintage date');
      }
      else if( (this.isFacilityDownloadAvailable == 0 && isTemplate == 0) || 
               (this.rbnStatus.toLowerCase() == 'authorised' && isTemplate == 0)){
        this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'No facility override data available to export');
      }
      else{
        this.isReportCalled =  true; 
        this.reportdate = this.businessDate;
        this._globalToasterService.openToast(ToasterTypes.info, 'Download started', '');
        this._overrideService.GetFacilityOverrideData(this.dealId,  ( (isTemplate == 1) ? '': this.businessDate) , isTemplate)
          .subscribe(output => { 
              if (output !== null) { 
                this.downloadAsExcelData(output, 'FacilityOverride');
              } else {
                this._globalToasterService.openToast(ToasterTypes.error,'Download template', 'error occured');
              }
              this.isReportCalled =  false;
          },
          error => {
            this.isReportCalled =  false;
          }
        );
      }
    }
  }

  DownloadComparisonFacility()
  {
    this.DownloadComparison('facility', '_FacilityComparison'); 
  }
  
  DownloadSecurity(isTemplate: any) {
    if(this.isReportCalled ===  true) {
      this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'Previous action is in progress. Please try later');
    }
    else {
          //if (this.overrideForm.invalid) 
          if ( isTemplate == 0 && !this.businessDate) {
            this._globalToasterService.openToast(ToasterTypes.error, 'Data Override', 'Please fille Vintage date');
          }
          else if( (this.isSecurityDownloadAvailable == 0 && isTemplate == 0) || 
                   (this.rbnStatus.toLowerCase() == 'authorised' && isTemplate == 0)){
            this._globalToasterService.openToast(ToasterTypes.warning, 'Data Override', 'No security override data available to export');
          }
          else{
            this.isReportCalled =  true; 
            this.reportdate = this.businessDate;
            this._globalToasterService.openToast(ToasterTypes.info, 'Download started', '');
            this._overrideService.GetSecurityOverrideData(this.dealId, (isTemplate == 1 ? '' : this.businessDate), isTemplate)
              .subscribe(output => { 
                  if (output !== null) { 
                    this.downloadAsExcelData(output, 'SecurityOverride');
                  } else {
                    this._globalToasterService.openToast(ToasterTypes.error,'Download template', 'error occured');
                  }
                  this.isReportCalled =  false;
              },
              error => {
                this.isReportCalled =  false;
              }
            );
          }
    }
  }

  DownloadComparisonSecurity()
  {
     this.DownloadComparison('security', '_SecurityComparison');
  }

  DownloadComparison(entity : string, fileName : string)
  {
    if(this.isReportCalled ===  true) {
      this._globalToasterService.openToast(ToasterTypes.warning, 'Download comparison', 'Previous action is in progress. Please try later');
    }
    else {
      //if (this.overrideForm.invalid) {
      //  this._globalToasterService.openToast(ToasterTypes.error, 'Download comparison', 'Please fill all fields');
      //}

      if (!this.businessDate || !this.comparisionBusinessDate) {
        this._globalToasterService.openToast(ToasterTypes.error, 'Data Override', 'Please select Vintage date and Comparison date');
      }

      else if(this.comparisionBusinessDate >= this.businessDate)
      {
        this._globalToasterService.openToast(ToasterTypes.error, 'Download comparison', 'Vintage date should be greater than Comparison date');
      }
      else{
        this.isReportCalled =  true; 
        this.reportdate = this.businessDate;
        this._globalToasterService.openToast(ToasterTypes.info, 'Download started', '');

        if(entity.toLowerCase() == 'facility')
        {
          this.isFacilityCompareCalled = true;
        }
        else this.isSecurityCompareCalled = true;

        var AnyDifference = 0;
        if(this.chkFilterDiffOnly == true)
        {
          AnyDifference = 1;
        }

        this._overrideService.GetComparisionData(0,this.dealId,  this.businessDate, this.comparisionBusinessDate, AnyDifference, entity)
          .subscribe(output => { 
              if (output !== null) { 
                this.downloadAsExcelData(output, fileName);
              } else {
                this._globalToasterService.openToast(ToasterTypes.error,'Download comparison', 'error occured');
              }
              this.isReportCalled =  false;
              this.isFacilityCompareCalled = false;
              this.isSecurityCompareCalled = false;

          },
          error => {
            this.isReportCalled =  false;
            this.isFacilityCompareCalled = false;
            this.isSecurityCompareCalled = false;

          }
        );
      }
    }
  }

  onDiffCheckboxChange(e) {  
    this.chkFilterDiffOnly = false;
    if (e.target.checked) {
      this.chkFilterDiffOnly = true;
    } 
  } 
  
  downloadAsExcelData(result: any, ReportName: string) { 

    let reportName = ReportName;
    if(this.reportdate)
    {
      reportName = this.datePipe.transform(this.reportdate, 'yyyy-MM-dd') +'_'+ this.rbnDealName +'_'+ ReportName;
    }
     
    let blob: Blob = null; 
      blob = new Blob([result.body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, reportName); 
    this._globalToasterService.openToast(ToasterTypes.info,'Report Generation', this._templateDownloadSuccessMessage);
  }


fileChangeFacility(input)
{ 
    this.uploadFileNameFacility = '';
    this.templateFileToUploadFacility = null;
    this.FacilityFileUploadData = null;
    const reader = new FileReader();

    if (this.validateRequiredFileExtension(input.files[0].name, this.validFileExtensions)) { 
        reader.onload = (e: any) => {
            const bstr: string = e.target.result as string;

            const wb: xlsx.WorkBook = xlsx.read(bstr, { type: 'binary',cellText:false,cellDates:true});
            const ws: xlsx.WorkSheet = wb.Sheets[wb.SheetNames[0]]; 
            this.uploadedData = xlsx.utils.sheet_to_json(ws, { header: 1, raw: false,dateNF:'dd-mm-yyyy' }); 
           
            if (this.uploadedData.length <= 1) { 
              this._globalToasterService.openToast(ToasterTypes.error, 'Upload Facility', 'No record found');
            }
            else
            { 
              this.uploadFileNameFacility = input.files[0].name;
              this.templateFileToUploadFacility = input.files[0];
              this.FacilityFileUploadData = this.uploadedData;
              this.setPageDirty();
            }
        };
        reader.readAsBinaryString(input.files[0]);
    }
    else {
      this._globalToasterService.openToast(ToasterTypes.error, 'Upload Facility', 'Invalid file extension');
    }
}

RemoveFiles(): void { 
  this.uploadFileNameFacility = '';
  this.templateFileToUploadFacility = null; 

  this.uploadFileNameSecurity = '';
  this.templateFileToUploadSecurity = null; 

  this.setPageDirty();
}

RemoveFile_Facility(): void { 
  this.uploadFileNameFacility = '';
  this.templateFileToUploadFacility = null;
  //this.makeFormDirty();
  this.setPageDirty();
}
RemoveFile_Security(): void { 
  this.uploadFileNameSecurity = '';
  this.templateFileToUploadSecurity = null;
  //this.makeFormDirty();
  this.setPageDirty();
}

makeFormDirty() {
  this.overrideForm.control.markAsTouched();
  this.overrideForm.control.markAsDirty();
}


dateChanged()
{
  this.getOverrideDetailToBanner();
  this.setPageDirty();
  this.loadFacilitySecurityLinkGrid();
}
compareDateChanged()
{
  this.setPageDirty();
  this.loadFacilitySecurityLinkGrid();
}

/*chkInput()
{
  console.log(this.linkageList);
}*/

loadFacilitySecurityLinkGrid()
{
   // clear the array /

  this.linkageList = [];
  this.filteredData = [];
  this.sourcelinkageList = [];
  this.exportlinkageList = [];

  this.isListEdited = false;

  // Find previous month in the list for the current selected AsAtDate
  /*let PrevBusinessDate : any = null;
  let objectModifiedIndex = this.vintageDateList.findIndex(
    selectedDate => selectedDate.key == this.businessDate
  ); 
  objectModifiedIndex = objectModifiedIndex + 1; 
  if(this.vintageDateList[objectModifiedIndex])
  {
    PrevBusinessDate = this.vintageDateList[objectModifiedIndex].key;
  }*/
  //

  if (this.businessDate && this.comparisionBusinessDate) {
  //if (this.businessDate && PrevBusinessDate) {
      if(this.comparisionBusinessDate >= this.businessDate)
      {
        this._globalToasterService.openToast(ToasterTypes.error, 'Validation Error', 
            'Vintage date should be greater than Comparison date');
      }
      else
      { 
        this.isLinkageDataLoading = true;
        this._overrideService.GetFacilitySecurityLinkStatus(this.businessDate, this.comparisionBusinessDate, this.dealId.toString())
        .subscribe(result => {
          //this.slickDataset = JSON.parse(JSON.stringify(result));
          this.bindUpdateAndOverrideColumns();
          this.bindDataToGrid(result);
          this.createMultipleFormGroups();
          this.isLinkageDataLoading = false;
        });
      }
  } 
}

bindUpdateAndOverrideColumns() { 
    this.linkGridCols = []
    this.linkGridCols.push(new EditableGridColumnModel('securityId', 'Security Id', 210, false, '', '', '', true, false, ''));
    this.linkGridCols.push(new EditableGridColumnModel('cradleSecurityId', 'Cradle Security Id', 200, false, '', '', '', true, false, ''));
    this.linkGridCols.push(new EditableGridColumnModel('connectionId', 'Connection Id', 200, false, '', '', '', true, false, ''));
    //this.linkGridCols.push(new EditableGridColumnModel('securityKey', 'Security Key', 200, false, '', '', '', true, false, ''));
    this.linkGridCols.push(new EditableGridColumnModel('facilityId', 'Facility ID', 180, false, '', '', '', true, false, ''));
    this.linkGridCols.push(new EditableGridColumnModel('isLinked', 'Relink or Delink Security', 120, true, 'check', '', '', true, false, ''));
} 

bindDataToGrid(result: any) { 
  console.log(result);
  this.linkageList = JSON.parse(JSON.stringify(result));
  this.filteredData = this.linkageList;
  this.sourcelinkageList = JSON.parse(JSON.stringify(result));
  this.exportlinkageList = JSON.parse(JSON.stringify(result));
  //this.updatedlinkageList = JSON.parse(JSON.stringify(result));
}

private createMultipleFormGroups() {
  var formControl = {};
  for (let index = 0; index < this.linkageList.length; index++) {
    var model = this.linkageList[index];
    Object.keys(model).forEach(element => {
      formControl[element] = [''];
    });
    this.linkageForm.push(this.fb.group(formControl))
  }
}

getHeight() {
  let containerElem = document.getElementById("dcTable");
  let remainHeight = document.documentElement.clientHeight - (containerElem.getBoundingClientRect().top + window.scrollY);
  this._sharedDataService.triggerWindowResize(1000);
  return {
    'height': remainHeight-50 + "px",
    'width' : "100%"
  };
}

getFilteredColumn() {
  const filteredCol = this.linkGridCols.filter(function (col) {
    return col.isChecked;
  });
  return filteredCol;
}

IsCellValueChanged(row: any, name: string) { 
  var sourceRow = this.sourcelinkageList.filter(x => x?.facilityId == row?.facilityId 
                                                 && x?.securityId == row?.securityId
                                                 && x?.connectionId == row?.connectionId
                                                 && x?.isLinked == row?.isLinked );
  if (sourceRow.length) 
  {
   /* if (
             this.getRefinedValue(row[name]) == this.getRefinedValue(sourceRow[0][name])
          && this.getRefinedValue(row[name]) == this.getRefinedValue(sourceRow[0][name])
          && this.getRefinedValue(row[name]) == this.getRefinedValue(sourceRow[0][name])
        ) 
    { */
      return false
  }
  else 
  {
    return true
  }
  //}
  //else if (row.ModifiedBy && this.getRefinedValue(row[name]) != '')
  //  return true; 
  //else
  //  return false;
}

getRefinedValue(val: any) {
  if (val == undefined || val == null)
    return "";
  else
    return val;
}

onChecked(rowIndex: any, row: any, isChecked: boolean) { 
  var sourceRow = this.sourcelinkageList.filter(x => x?.facilityId == row?.facilityId 
    && x?.securityId == row?.securityId
    && x?.connectionId == row?.connectionId
    && x?.isLinked == row?.isLinked );
  if (sourceRow.length)
  {
    row.isListEdited = 0;
  }
  else
  {
    row.isListEdited = 1;
    this.isListEdited = true;
    this.setPageDirty(); 
  }

  this.isCheckboxTouched = 1;

  //console.log(this.sourcelinkageList);
  
  //console.log(this.linkageList.filter(x => x?.isLinked == '1' || x.isLinked == 'true')); 
}

sfpGridColumnFilter(event, colName, colIdx) {
  if (this.linkageList) {
    const filteredCol = this.linkGridCols.filter(function (col) {
      return col.isChecked;
    });
    const searchValue = event.target.value.toLowerCase();
    filteredCol[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

    let tempGridData = this.filteredData;
    filteredCol.forEach(function (col) {
      if (col.filterText !== '' && tempGridData.length > 0) {
        tempGridData = tempGridData.filter(function (row) {
          return String(row[col.columnName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
        });
      }
    });
    this.linkageList = tempGridData;
  }
}

customSort(colName: string) {
  let filter = colName;
  if (colName !== this.selectedSortCol) {
    this.colSortType = 'asc';
    this.selectedSortCol = colName;
  } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
    this.colSortType = 'desc';
    filter = '-' + filter;
  } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
    this.colSortType = 'asc';
  }

  this.linkageList = this.ngxOrderPipe.transform(this.linkageList, filter);
  console.log('Sorting Colum: ' + colName);
}


getRowClass = (row) => {
   let rowColor = 'cw-ngx-row-bg-color';

  var sourceRow = this.sourcelinkageList.filter(x => x?.facilityId == row?.facilityId 
                                                  && x?.securityId == row?.securityId
                                                  && x?.connectionId == row?.connectionId
                                                  && x?.isLinked == row?.isLinked);

   // alert(sourceRow.length);

  if (sourceRow.length) {
    return { [rowColor]: false };    
   /* for (let key of Object.keys(row)) 
    {
      if (this.getRefinedValue(sourceRow[0][key]) != this.getRefinedValue(row[key])) 
        {
          return { [rowColor]: true };        
        }
    }*/
  } else{
    return { [rowColor]: true }; 
    //if (row.ModifiedBy)
    //  return { [rowColor]: true };
  } 
}


setPageDirty()
{
  if ( this.templateFileToUploadFacility || this.templateFileToUploadSecurity || this.isListEdited == true) { 
    this.overrideForm.control.markAsTouched();
    this.overrideForm.control.markAsDirty();
  } 
  else
  { 
    this.overrideForm.control.markAsUntouched();
    this.overrideForm.control.markAsPristine();
  }
}

fileChangeSecurity(input)
{
    this.uploadFileNameSecurity = '';
    this.templateFileToUploadSecurity = null;
    this.SecurityFileUploadData = null;

    const reader = new FileReader(); 
    if (this.validateRequiredFileExtension(input.files[0].name, this.validFileExtensions)) { 
        reader.onload = (e: any) => {
            const bstr: string = e.target.result as string;
            const wb: xlsx.WorkBook = xlsx.read(bstr, { type: 'binary',cellText:false,cellDates:true});
            const ws: xlsx.WorkSheet = wb.Sheets[wb.SheetNames[0]]; 
            this.uploadedData = xlsx.utils.sheet_to_json(ws, { header: 1, raw: false,dateNF:'dd-mm-yyyy' }); 
            
            if (this.uploadedData.length <= 1) { 
              this._globalToasterService.openToast(ToasterTypes.error, 'Upload Security', 'No record found');
            }
            else
            { 
              this.uploadFileNameSecurity = input.files[0].name;
              this.templateFileToUploadSecurity = input.files[0];
              this.SecurityFileUploadData = this.uploadedData;
              this.setPageDirty();
            }
        };
        reader.readAsBinaryString(input.files[0]);
    }
    else {
      this._globalToasterService.openToast(ToasterTypes.error, 'Upload Security', 'Invalid file extension');
    }
}


handleSaveResponse(result : any)
{
  this.resultObj = JSON.parse(result);
  console.log(this.resultObj);  
  let EntityTitle = 'Data override'; 
  if(this.resultObj.entityName) EntityTitle = EntityTitle  +'-' + this.resultObj.entityName;

  if(this.resultObj.returnCode == -1)
  {
    this.uploadError = 'The file format for uploaded file is incorrect';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -2)
  {
    this.uploadError ='Column name missing in uploaded file';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -3)
  {
    this.uploadError = 'No field configured for '+ EntityTitle +' to upload';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -4)
  {
    this.uploadError = 'The column name in the file uploaded is incorrect, please check';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -5)
  {
    this.uploadError = 'Data type not configured for field(s)';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -6)
  {
    this.uploadError = 'Incorrect data type in uploaded file.';
    //this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, 'Incorrect data type in uploaded file, Please check downloaded error file');
  }
  //else if(this.resultObj == -7)
  //{
  //  this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, 'Data type not configured');
  //}
  else if(this.resultObj.returnCode == -8)
  {
    this.uploadError = 'Tab name in the uploaded file should be '+ EntityTitle +', please check';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -9)
  {
    this.uploadError = 'Invalid file format. Data should start from first cell';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -10)
  {
    this.uploadError = 'Key field not configured for this upload';
    this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -11)
  {
    this.uploadError = 'The value entered for update attribute is not in line with the upstream data.';
    //this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, 'The value entered for update attribute is not in line with the upstream data. Please check downloaded error file');
  }
  else if(this.resultObj.returnCode == -12)
  {
    this.uploadError = 'Duplicate key values found.';
    //this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, 'Duplicate key values found. Please check downloaded error file');
  }
  else if(this.resultObj.returnCode == -13)
  {
    this.uploadError = 'Data error found.';
    //this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, 'Data error found. Please check downloaded error file');
  }
  else if(this.resultObj.returnCode == -14)
  {
    this.uploadError = 'Invalid key value found.';
    //this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == -15)
  {
    this.uploadError = 'Invalid RONA found.';
    //this._globalToasterService.openToast(ToasterTypes.error, EntityTitle, this.uploadError);
  }
  else if(this.resultObj.returnCode == 0)
  {
    this.RemoveFiles();
    this._globalToasterService.openToast(ToasterTypes.success, EntityTitle, ' Data saved successfully.'); 
    this.getOverrideDetailToBanner();
    this.isListEdited = false;
    this.isCheckboxTouched = 0;

    //this.updatedlinkageList = this.linkageList;
    //console.log(this.updatedlinkageList);
  } 
  
  //this.exportErrorListToExcel(this.resultObj);
  if(this.resultObj.isErrorListAvailable == 1)
  {  
    this.ShowErrorPopup();
  }
}

prepareFileToUpload()
{
    const formData: FormData = new FormData();

      if (this.templateFileToUploadFacility) {
        formData.append('facility', this.templateFileToUploadFacility, this.templateFileToUploadFacility.name);
      }
      if (this.templateFileToUploadSecurity) {
        formData.append('security', this.templateFileToUploadSecurity, this.templateFileToUploadSecurity.name);
      }

    var isListEdited = 0;
    var SelectedLinkRows = this.linkageList; //.filter(x => x?.isLinked == '1' || x.isLinked == 'true');
    //var EditedRows = this.linkageList.filter(x => x?.isListEdited == 1);
    //if(EditedRows.length > 0 )
    if(this.isCheckboxTouched == 1)
    {
      isListEdited = 1;
    }

    formData.append('dealId', this.dealId.toString());
    formData.append('AsAtDate', this.businessDate.toString());
    formData.append('linkageList', JSON.stringify(SelectedLinkRows));
    formData.append('isListEdited', isListEdited.toString());

    formData.append('FacilityFileUploadData', JSON.stringify(this.FacilityFileUploadData));
    formData.append('SecurityFileUploadData', JSON.stringify(this.SecurityFileUploadData));
    
    return formData;
}


validateRequiredFileExtension(name: any, fileExtensions: string[]): boolean {
  const ext = name.substring(name.lastIndexOf('.') + 1);
  const validExtension = (element: string) => element.toLowerCase() === ext.toLowerCase();
  return fileExtensions.some(validExtension);
}


openAuditTrailModal() {
  const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
    size: 'lg',
    backdrop: 'static',
    keyboard: false
  });
  // pass id values from [corp].[DealOverrideParent] table for below function call. 
  // But what if more than one authorized record for same deal/date.
  // Needs BAs confirmation

   var auditTrailModel = new AuditTrailPopupModel( this.DealOverrideParentId , AuthWorkflowType.DealDataCorrection)
   modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
}

authoriseReject() { 
  var model = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.DealDataCorrection, AuthWorkflowStep.Approve_Reject, 0, 0, this.DealOverrideParentId,'', null);
  this.openModalPopup(model, '');
}
recall() {
  let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.DealDataCorrection, AuthWorkflowStep.Recall, 0, 0, this.DealOverrideParentId, '', null);
  this.openModalPopup(model, 'Deal data correction recalled successfully');
}
sendForAuthorisation() { 
        let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.DealDataCorrection, AuthWorkflowStep.SendForAuthorisation, 0, 0, this.DealOverrideParentId, '', null);
        this.openModalPopup(model, 'Deal data correction has been send for Authorisation successfully');
}

openModalPopup(model: AuthModalConfigModel, message: string) {
  const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
    backdrop: 'static', 
    keyboard: false
  });
  modalRefPopUp.componentInstance.commentPopUpConfig = model;
  modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
    this._globalToasterService.openToast(ToasterTypes.success, this.title, message ? message : val);
    this.checkAuthorisationStatus();
  });
}

checkAuthorisationStatus() {
  if(this.DealOverrideParentId && this.DealOverrideParentId > 0)
  {
    this._ddcAuthWorkflowService.getAuthWorkflowStatus(this.DealOverrideParentId, AuthWorkflowType.DealDataCorrection)
    .subscribe((result) => { 
      console.log(result); 
      this.ddcAuthStatusModel = result;
      this.ddcStatusId = this.ddcAuthStatusModel.status; 
       
      if(this.ddcAuthStatusModel.status === 2) this.rbnStatus = 'Pending Authorisation';
      else if (this.ddcAuthStatusModel.status === 3) this.rbnStatus = 'Authorised';
      else if (this.ddcAuthStatusModel.status === 4) this.rbnStatus = 'Rejected';
      else this.rbnStatus = 'Draft';
      
      //if(result.stepName === "SendForAuthorisation"  || result.stepName === "Authorise") {
      //  this.isSheetSubmittedOrAuthorised = true;
      //}
      //else {
      //  this.isSheetSubmittedOrAuthorised = false;
      //}

      this.initializeWorkflowStep(this.ddcStatusId); 

    }); 
  } 
}

public initializeWorkflowStep(statusId : number) { 

  this.ddcAuthStatusModel.stepName = 'Draft';

  if(this.DealOverrideParentId && this.DealOverrideParentId > 0)
  {   
    if(statusId === 2) {
      this.ddcAuthStatusModel.stepName = 'SendForAuthorisation';
      //this.isSheetSubmittedOrAuthorised = true;
      this.rbnStatus = 'Pending Authorisation';
    }
    else if(statusId === 3) {
      this.ddcAuthStatusModel.stepName = 'Authorise';
      //this.isSheetSubmittedOrAuthorised = true;
      this.rbnStatus = 'Authorised';
    }
    else if(statusId === 4) {
      this.ddcAuthStatusModel.stepName = 'Reject';
      //this.isSheetSubmittedOrAuthorised = false;
      this.rbnStatus = 'Rejected';
    } 
    else {
      this.ddcAuthStatusModel.stepName = 'Draft';
      //this.isSheetSubmittedOrAuthorised = false;
      this.rbnStatus = 'Draft';
    }
  }
}

setUpUserRolesAndPermissions() {
  if (this._userService.userPermissionList.length > 0) {
        this.userPermissionOnDealDataCorrection 
        = this._userService.userPermissionList.filter(x => x.permission === PermissionEnum[PermissionEnum.CB_DealDataCorrectionManagement]);      
      }
  if(this._userService.userDetail !== undefined) {
   this.userDetail = this._userService.userDetail;
   this.setUserName(this.userDetail.userName.toLowerCase());
  }
  if(this.userPermissionOnDealDataCorrection.length > 0 && this.userPermissionOnDealDataCorrection.find(x =>
    x.permissionAccessType === PermissionAccessTypeEnum[PermissionAccessTypeEnum.ApproveReject]) !== undefined) {
      this.isAuthoriser = true;
    }
  if(this.userPermissionOnDealDataCorrection.length > 0 && this.userPermissionOnDealDataCorrection.find(x =>
    x.permissionAccessType === PermissionAccessTypeEnum[PermissionAccessTypeEnum.AddEdit]) !== undefined) {
      this.isUser = true;
    }
  this.viewOnlyUser = !this.isUser;
}

setUserName(userName: string) {
  this.userName = userName;
}


ResetOverrideData(Entity:string) {
  this.resetEntity = Entity;
  this._modalService.open(this.resetConfirmation,
  { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
          if (result.toLowerCase() === 'delete') 
            {
                this.resetOverrideDataConfirmed(this.resetEntity)
            } 
            else if (result.toLowerCase() === 'cancel') 
                 return false;
            else return false;
  });
}

resetOverrideDataConfirmed(confirmation:string)
{
  if (confirmation.toLowerCase() === 'delete') 
  {
    if(this.DealOverrideParentId && this.DealOverrideParentId > 0)
    {
      this._overrideService.resetOverrideData(this.DealOverrideParentId.toString(), this.resetEntity)
      .subscribe(result => {
        if (result == 1) {
          this.getOverrideDetailToBanner();
          if(this.resetEntity.toLowerCase() == 'relinking')
          {
            this.IsLinkagesAvailable = 0;
            this.loadFacilitySecurityLinkGrid();
          }
          this._globalToasterService.openToast(ToasterTypes.success, 'Reset ' + this.resetEntity, this.resetEntity + ' override data deleted successfully');
        }
        else{
          this._globalToasterService.openToast(ToasterTypes.error, 'Reset ' + this.resetEntity, 'Error while resetting '+ this.resetEntity + ' override data');
        }
      });
    }
  }
  else if (confirmation.toLowerCase() === 'cancel') 
        return false;
}


ShowErrorPopup() {
  this._modalService.open(this.errorResponseDownload,
     { ariaLabelledBy: 'modal-basic-title', backdrop: 'static', keyboard: false }).result.then((result: string) => {
            if (result.toLowerCase() === 'export') 
            {
                this.exportErrorSummary(result.toLowerCase())
            } 
            else if (result.toLowerCase() === 'cancel') 
                 return false;
            else return false;
  });
}

exportErrorSummary(confirmation:string)
{
  if (confirmation.toLowerCase() === 'export') 
  {
    this.exportHeaders = []
      for(let i = 0; i <= this.resultObj.errorExcelHeaderList.length-1; i++)
      {
        let HdrModel = new HeaderCollectionModel( this.resultObj.errorExcelHeaderList[i] ,this.resultObj.errorExcelHeaderList[i]); 
        this.exportHeaders.push(HdrModel); 
      }
    this.exportExcelUtility.exportDataToExcel(this.exportHeaders, JSON.parse(JSON.stringify(this.resultObj.errorListJson)), this.resultObj.entityName+"_UploadError.xlsx"); 
    this._globalToasterService.openToast(ToasterTypes.success, 'Error file exported successfully');
  }
  else if (confirmation.toLowerCase() === 'cancel') 
        return false;
}


}
