
export class OverrideVintageDate {
    public key: string; 
    public value: string;     

    constructor(businessDate: string, formattedText: string) {
        this.key=businessDate; 
        this.value = formattedText;
    }
}