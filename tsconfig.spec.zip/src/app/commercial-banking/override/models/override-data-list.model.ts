export class OverrideDataList {
    public dealName: string;
    public status: string;
    public overrideBy: string;
    public overrideDate: Date;
    public authorisedBy: string;
    public authorisedDate: Date;
    public currentOverrideVintageDate: Date;
    public lastOverrideVintageDate: Date;
}

export class FacilitySecurityLinkList {
    facilityId: string;
    securityId: string; 
    cradleSecurityId: string;
    connectionId: string;
    securityKey: string;
    isLinked: string;
    isListEdited: number;
}