import { DatePipe } from '@angular/common';
import { Component, OnInit } from '@angular/core';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { ActivatedRoute, Router } from '@angular/router';
import { FieldType, Formatters } from 'angular-slickgrid';
import { CommonPopupConfigModel, SfpGridActionModel, SfpGridColumnModel, SfpGridOptionsModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { SFP_SlickFilterType } from 'src/app/shared/components/slick-grid/slick-grid.filter';
import { actionPermissionButtonFormatter, GenerateOverrideAuditTrailReport, hyperLinkFormatter } from 'src/app/shared/components/slick-grid/slick-grid.formatter';
import { SFP_SlickAction, SFP_SlickColumn, SFP_SlickGridUtility, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { UserModel } from 'src/app/shared/home/user.model';
import { saveAs } from 'file-saver';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { UserPermissionModel } from 'src/app/shared/model/user-permission.model';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { OverrideDataList } from '../models/override-data-list.model';
import { OverrideService } from '../services/override-correction.service';
import { OverrideAuditPopupComponent } from 'src/app/shared/components/override-audit-popup/override-audit-popup.component';

@Component({
  selector: 'override-list',
  templateUrl: './override-list.component.html',
  styleUrls: ['./override-list.component.scss'],
  providers: [OverrideService]
})
export class OverrideListComponent implements OnInit {
  public title = 'Override List';

  public overrideDataList: OverrideDataList[] = new Array<OverrideDataList>();
  public UpdateAndOverrideGridOptions: SfpGridOptionsModel = null;
  public UpdateAndOverrideGridCustomCols: Array<SfpGridColumnModel> = [];
  public UpdateAndOverrideGridActionLinks: Array<SfpGridActionModel> = [];
  public UpdateAndOverrideGridExcludedCols: Array<string> = []
  public datePipe = new DatePipe('en-UK');
  public exportFileName: string = '';
  private readonly _templateDownloadSuccessMessage = 'File downloaded successfully!!';

  public _addUpdateAndOverrideNavPath = '/cl/commercialbanking/override/add';
  public _viewUpdateAndOverrideNavPath = '/cl/commercialbanking/override/view/';

  //-------Slick Grid Variables Start--------------
  public slickColumnArray: SFP_SlickColumn[] = <SFP_SlickColumn[]>[];
  public slickDataset: any[];
  public slickCallbackFuntions: SFP_SlickAction;
  public slickDefaultActionButtons: boolean = false;
  public slickDefaultAuditButtons: boolean = false;
  //-------Slick Grid Variables End--------------
  public loggedInUser: string;
  public userPermissionsOnIrConfig: UserPermissionModel[];
  public userDetail: UserModel;

  public canUpdate: boolean = false;
  public canView: boolean = false;
  public canDelete: boolean = false;
  public canAuthorized: boolean = false;
  public isReportCalled: boolean = false;
  private _permissionDenied: string = 'Permission Denied';    //constructor

  private readonly _popupTitle: string = 'Override Audit Report';

  constructor(
    public _toastservice: GlobalToasterService,
    private _userRoleService: UserRoleService,
    private _route: ActivatedRoute,
    private _router: Router,
    private _modalService: NgbModal,
    private _sharedDataService: SharedDataService,
    private _overrideService: OverrideService) {
    //Columns to exclude
    this.UpdateAndOverrideGridExcludedCols = ["UpdateAndOverrideConfigId", 'ID', 'UserName', 'dealId', 'stratTemplateId', 'reportLayoutId', 'uploadedFileName'];;
  }

  ngOnInit() {

    this.setUpUserRolesAndPermissions();

    this.bindUpdateAndOverrideColumns();
    this.bindUpdateAndOverrideListActionsCallBack();
    this.getUpdateAndOverrideList();

    this.setExportFileName();
  }

  bindUpdateAndOverrideColumns() {
    this.slickColumnArray.push
      (
        new SFP_SlickColumn('dealName', 'Deal Name', true, true, 80, FieldType.string, hyperLinkFormatter),
        new SFP_SlickColumn('status', 'Status', true, true, 100, FieldType.string),
        new SFP_SlickColumn('overrideBy', 'Override By', true, true, 80, FieldType.string),
        new SFP_SlickColumn('overrideDate', 'Last update date', true, true, 80, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('authorisedBy', 'Authorised By', true, true, 80, FieldType.integer),
        new SFP_SlickColumn('authorisedDate', 'Authorised Date', true, true, 80, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('currentOverrideVintageDate', 'Current Override Vintage Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('lastOverrideVintageDate', 'Last Override Vintage Date', true, true, 100, FieldType.dateEuro, Formatters.dateEuro, SFP_SlickFilterType.date, true),
        new SFP_SlickColumn('auditTrailRpeort', 'Audit Trail Rpeort', false, false, 100, FieldType.string, GenerateOverrideAuditTrailReport),
      );
  }

  setExportFileName() {
    var dt = new Date();
    var current_timestamp = dt.getDate() + ' ' + (dt.toLocaleString('default', { month: 'short' })) + ' ' + dt.getFullYear();
    this.exportFileName = current_timestamp + '_' + this.title;
  }

  getUpdateAndOverrideList() {
    this._overrideService.getUpdateOverrideList(0,'').subscribe(result => {
      this.slickDataset = JSON.parse(JSON.stringify(result));
    });
  }


  bindUpdateAndOverrideListActionsCallBack() {   
    this.slickCallbackFuntions = new SFP_SlickAction(
      this.onTitleClickCallback,
      null,
      null,
      null,
      this.onDownloadCallback
    );
  }

  onTitleClickCallback(record: any, currentThis: any = this) {
    if (!currentThis.canView) {
      currentThis._toastservice.openToast(ToasterTypes.error, currentThis._toastTitle, currentThis._permissionDenied);
      return;
    }
    currentThis._router.navigate([currentThis._viewUpdateAndOverrideNavPath, record.dealId]);
  }

  onDownloadCallback(rowData: any, parentThis: any) {
    const modalRefDel = parentThis._modalService.open(OverrideAuditPopupComponent, {
        backdrop: 'static',
        keyboard: false
    });
    modalRefDel.componentInstance.dealId = rowData.dealId;
    modalRefDel.componentInstance.dealName = rowData.dealName.toString();
    modalRefDel.result.then(result => {
        if (result === 'confirmed') {
            console.log('Model closed');
        }
    });
    try {
      modalRefDel.componentInstance.popupEmitService.subscribe((data: any) => {
        parentThis.downloadAuditTrailReportWrapper(data.dealId, data.dealName, data.entityType, data.vintageDate);
        parentThis._toastservice.openToast(ToasterTypes.info, 'Report Generation', 'Starting Report generation');
      });
    } catch (error) {
      console.log(error);
    }
  }

  downloadAuditTrailReportWrapper(dealId: number, dealName: string, entityType: string, vintageDate: string) {
    setTimeout(() => this.downloadAuditTrailReport(dealId, dealName, entityType, vintageDate));
  }

  downloadAuditTrailReport(dealId: number, dealName: string, entityType: string, vintageDate: string) {
    if(entityType.toLowerCase() == 'facilitysecuritylink')
    {
        this.DownloadLinkAuditReport(dealId,dealName,vintageDate);
    }
    else
    {
      this._overrideService.downloadAuditTrailReport(dealId.toString(), entityType, vintageDate).subscribe(result => {
        if (result !== null) { 
          this.downloadAsExcelData(result, dealName, vintageDate);
        } else {
          this._toastservice.openToast(ToasterTypes.error,'Download comparison', 'error occured');
        }
      });
    }
  }

  downloadAsExcelData(result: any, dealName: string, vintageDate: string) { 

    let reportName: string;
    if(vintageDate)
    {
      reportName = this.datePipe.transform(vintageDate, 'yyyyMMdd') +'_'+ dealName + '_override_audit_report';
    }
     
    let blob: Blob = null; 
    blob = new Blob([result.body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, reportName); 
    this._toastservice.openToast(ToasterTypes.info,'Report Generation', this._templateDownloadSuccessMessage);
  }

  onLinkAuditDownloadCallback(rowData: any, parentThis: any = this) { 
    parentThis.DownloadLinkAuditReport(rowData['dealId'], rowData['dealName']);
  }

  DownloadLinkAuditReport(dealId: number, dealName : string, vintageDate: string) { 
    if(this.isReportCalled ===  true) {
      this._toastservice.openToast(ToasterTypes.warning, 'Data Override', 'Previous download is in progress. Please try later');
    }
    else {
        this.isReportCalled =  true;
        this._toastservice.openToast(ToasterTypes.info, 'Download started', '');
        this._overrideService.GetLinkageAuditReportData(dealId, vintageDate).subscribe(output => { 
              if (output !== null) { 
                this.downloadAuditAsExcelData(output, 'Linkage Audit Report -' + dealName);
              } else {
                this._toastservice.openToast(ToasterTypes.error,'Download template', 'error occured');
              }
              this.isReportCalled =  false;
          },
          error => {
            this.isReportCalled =  false;
          }
        ); 
    }
  }

  downloadAuditAsExcelData(result: any, ReportName: string) {
    let reportName = ReportName;     
    let blob: Blob = null; 
      blob = new Blob([result.body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
    saveAs(blob, reportName); 
    this._toastservice.openToast(ToasterTypes.info,'Report Generation', this._templateDownloadSuccessMessage);
  }

  resizeGrid() {
    let objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this._sharedDataService);
    objSFP_Slick.resizeGrid();
  }

  setUpUserRolesAndPermissions() {

    this.loggedInUser = this._userRoleService.getCurrentLoginUser();

    this.canView = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.View);
    this.canUpdate = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.AddEdit);
    this.canDelete = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.Delete);
    this.canAuthorized = this._userRoleService.getPermissionAccess(PermissionEnum.CW_IR_Config, PermissionAccessTypeEnum.ApproveReject);

    this.canView = true;
    this.canUpdate = true;
    this.canDelete = true;
    this.canAuthorized = true;
  }


  onUpdateAndOverride() {
    this._router.navigate([this._addUpdateAndOverrideNavPath]);
  }

}
