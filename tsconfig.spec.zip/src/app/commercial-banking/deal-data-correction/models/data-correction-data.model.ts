class DataCorrectionDetail {
    correctionBasicInfo: CorrectionBasicInfo;
    facilityCorrectedDataList: Array<FacilityCorrectionList>;
    facilityOrigionalDataList: Array<FacilityCorrectionList>;
    securityCorrectedDataList: Array<SecurityCorrectionList>;
    securityOrigionalDataList: Array<SecurityCorrectionList>;
}
class CorrectionBasicInfo {
    correctionId: number;
    correctionDate: any = new Date();
    dealId: number = 1;
    entityId: number = 1;
    fsId: number = null;
    connectionId: number = null;
    status: string = null;
    correctedData: string; 

    dealCorrectionStatusId : number = null;
    createdBy : string = null;
    authorizedBy: string = null;
    authorizedDate: string = null;
}
class CorrectedKeyValue {
    attributeId: number;
    value: string
}
class CorrectionAttribute {
    attributeId: number;
    attributeName: string;
    displayName: string;
    entityType: string;
    dataType: string;
    isEditable: boolean;
    isChecked: boolean;
    isHideAllowed: boolean;
    filterText: string;
}
class FacilityCorrectionList {
    facilityId: number;
    securityId: number;
    firstInterestMargin: number;
    interestCharge: number;
    ltvOverride: number;
    developmentLtcOverride: number;
    developmentLtcValue: number;
    facilityTypeCode: string;
    interestBasis: string;
    interestBasisCode: string;
    costCentre: string;
    facilityCurrencyCode: string;
    facilitySourceCode: string;
    cisCode: string;
}
class SecurityCorrectionList {
    securityId: number;
    facilityId: string;
    connectionId: number;
    cradleSecurityId: number;
    valnSourceCode: string;
    GrossValueAmt: number;
    propertyNatureCode: string;
    propertyPostcode: string;
    securityDescription: string;
}
export { CorrectionBasicInfo, CorrectionAttribute, FacilityCorrectionList as FacilityCorrectionList, SecurityCorrectionList, CorrectedKeyValue, DataCorrectionDetail }