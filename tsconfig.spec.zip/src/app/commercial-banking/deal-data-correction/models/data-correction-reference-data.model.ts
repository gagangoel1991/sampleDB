import { LookupTitleValue } from "src/app/core/models/lookup-title-value.model";

class DataCorrectionReferenceData {
  deals: Array<LookupTitleValue>;
  entities: Array<LookupTitleValue>;
}

export { DataCorrectionReferenceData }