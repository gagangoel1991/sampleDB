class DataCorrectionList {
  id: number;
  date: Date;
  deal: string;
  entity: string;
  facility: string;
  status: string;
  createdBy: string;
  createdDate: Date;
}
export { DataCorrectionList }