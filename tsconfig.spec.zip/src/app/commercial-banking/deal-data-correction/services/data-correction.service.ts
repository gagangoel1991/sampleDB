import { Injectable } from "@angular/core";
import { Observable } from "rxjs";
import { GlobalHttpService } from "src/app/core/services/api/global.http.service";
import { GlobalToasterService } from "src/app/shared/services/globaltoaster.service";
import { CorrectionAttribute, CorrectionBasicInfo, DataCorrectionDetail } from "../models/data-correction-data.model";

@Injectable({
    providedIn: 'root'
}
)
class DataCorrectionService {

    private readonly apiUrl: string = '/commercialbanking';
    private readonly refDataUrl: string = '/cb/datacorrectionRef';
    private readonly correctionDetail: string = '/cb/datacorrection';
    private readonly dataAttribute: string = '/cb/dataattribute';
    private readonly savecorrectionDetail: string = '/cb/savedatacorrection';
    
    constructor(
        private _globalHttpService: GlobalHttpService,
        private _globaltoasterService: GlobalToasterService
    ) { }

    getReferenceData(): Observable<any> {
        return this._globalHttpService.GetRequest(this.apiUrl + this.refDataUrl);
    }
    getDataAttribute(entityId: number): Observable<CorrectionAttribute[]> {
        return this._globalHttpService.GetRequest(this.apiUrl + this.dataAttribute+`/` +entityId);
    }
    getDataCorrectionDetail(basicInfo: CorrectionBasicInfo): Observable<DataCorrectionDetail> {
        return this._globalHttpService.PostRequest(this.apiUrl + this.correctionDetail, basicInfo);
    }
    saveDataCorrection(basicInfo: CorrectionBasicInfo): Observable<any>{

        return this._globalHttpService.PostRequest(this.apiUrl + this.savecorrectionDetail, basicInfo);
    }
}

export { DataCorrectionService }