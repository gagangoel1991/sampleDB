import { AfterViewChecked, ChangeDetectorRef, Component, OnInit, ViewEncapsulation } from '@angular/core';
import { OrderByPipe } from 'ngx-pipes';
import { LookupTitleValue } from 'src/app/core/models/lookup-title-value.model';
import { SFP_SlickGridUtility } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { CorrectionBasicInfo, CorrectionAttribute, DataCorrectionDetail, FacilityCorrectionList, CorrectedKeyValue } from '../models/data-correction-data.model';
import { DataCorrectionService } from '../services/data-correction.service';
import { ColumnMode } from '@swimlane/ngx-datatable';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';
import { DatePipe, formatDate } from '@angular/common';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ContextMenuService } from 'ngx-contextmenu';
import { UserRoleService } from 'src/app/shared/services/user-role-service';
import { UserModel } from 'src/app/shared/home/user.model';
import { UserPermissionModel } from 'src/app/shared/model/user-permission.model';
import { PermissionAccessTypeEnum } from 'src/app/shared/model/user-permission-accesstype.enum';
import { PermissionEnum } from 'src/app/shared/model/user-permission.enum';
import { AuthWorkflowService } from 'src/app/shared/services/auth-workflow-service';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { AuthWorkflowPopupComponent } from 'src/app/shared/components/auth-workflow/auth-workflow-popup.component';
import { WorkflowAuditTrailPopupComponent } from 'src/app/shared/components/audit/workflow-audit-trail-popup/workflow-audit-trail-popup.component';
import { AuthModalConfigModel } from 'src/app/shared/model/auth-modal-config.model';
import { AuthWorkflowType, AuthWorkflowStep } from 'src/app/shared/model/auth-workflow-enum';
import { AuthWorkflowStatusModel } from 'src/app/shared/model/auth-workflow-status.model';
import { AuditTrailPopupModel } from 'src/app/shared/model/workflow-audit-trail.model';

@Component({
  selector: 'cb-deal-data-correction',
  templateUrl: './data-correction.component.html',
  styleUrls: ['./data-correction.component.scss'],
  providers: [OrderByPipe, DatePipe],
  encapsulation: ViewEncapsulation.None
})
export class DataCorrectionComponent implements OnInit, AfterViewChecked {

  //Variable Declarations
  public title = 'Create Data Correction Sheet';
  public FSText: string = 'Facility Id';
  public submitted = false;
  public isSheetSubmittedOrAuthorised: boolean;
  public viewOnlyUser: boolean;
  public isChangeRestricted: any;
  public currentDate: Date;
  public dateInvalid: boolean = false;
  public isNewSpreadsheet: boolean = true;
  public loadingIndicator = true;
  public dealList: LookupTitleValue[];
  public entityList: LookupTitleValue[];
  public rows: any = [];
  public totalCount: Number = 0;
  public closeResult: string;
  public selectedSortCol = '';
  public colSortType = 'asc';
  public dataCorrectionDetail: DataCorrectionDetail;
  public correctionBasicInfo: CorrectionBasicInfo;
  public correctionAttribute: Array<CorrectionAttribute>;
  public correctedList = [];//Array<FacilityCorrectionList>
  public origionalList = [];// Array<FacilityCorrectionList>
  public tempCorrectedList = [];
  public filteredData = [];
  public editing = {};
  public dataCorrectionForm: Array<FormGroup> = [];
  public readonly _numberRegex = "^-?[0-9]{0,16}(\.[0-9]{1,4})?$";
  public exportFileName = 'DataCorrectionSheet.xlsx'
  public correctedListLoaded: boolean = true;
  public requiredFieldMessage = `Please fill the required field values!`;
  public fieldUpdatedMessage = `No change detected!`;
  public saveSuccessMessage = `Data Saved successfully!`;
  public saveFailedMessage = `Data Saving failed!`;
  public noDataFoundMessage = `No data found for given date!`;
  public cannotEditDuetoStatus = `Cannot edit. The current status is : `;
  public cannotEditReadOnlys = `Cannot edit by readonly user`;

  public ddcAuthStatusModel: AuthWorkflowStatusModel;
  ddcStatusId: number;
  DealDataCorrectionId: any = 0;
  ddcStatus: string;
  ddcCreatedBy = '';
  userDetail: UserModel = new UserModel('', '', '', '', '', '', []);
  userName: string;
  userPermissionOnDealDataCorrection: UserPermissionModel[];
  public isAuthoriser: boolean = false;
  public isUser: boolean = false;
  modifiedDate:any;
  public isDataLoadingStarted = false;

  constructor(
    private _datacorrectionService: DataCorrectionService,
    private _sharedDataService: SharedDataService,
    private _ngxOrderPipe: OrderByPipe,
    private _toastrService: GlobalToasterService,
    private _datePipe: DatePipe,
    private fb: FormBuilder,
    private _contextMenuService: ContextMenuService,
    private _changeDetectorRef: ChangeDetectorRef,
    private _userService: UserRoleService,
    private _ddcAuthWorkflowService: AuthWorkflowService,
    private _modalService: NgbModal
  ) {
    this.currentDate = new Date();
    this.ddcAuthStatusModel = new AuthWorkflowStatusModel('', '', 1, '', '', '', '');
  }

  ngOnInit(): void {
    this.correctionBasicInfo = new CorrectionBasicInfo();
    this.getDataAttribute(this.correctionBasicInfo.entityId);
    this.getReferenceData();
    this.getDataCorrectionDetail();
    this.setUpUserRolesAndPermissions();
  }
  ngAfterViewChecked(): void {
    this._changeDetectorRef.detectChanges();
  }
  //Get & Load Reference Data
  private getReferenceData() {
    this.dealList = [];
    this._datacorrectionService.getReferenceData()
      .subscribe(result => {
        this.dealList = result.deal;
        this.entityList = result.entity;
      });
  }
  //Get & Load attribute list
  private getDataAttribute(entityId: number): void {
    this.correctionAttribute = [];
    let facAttObject: any, secAttObject: any;
    let facIndex: number, secIndex: number;
    const facilityId: string = 'facilityId', securityId: string = 'securityId';

    this._datacorrectionService.getDataAttribute(this.correctionBasicInfo.entityId)
      .subscribe(result => {

        facAttObject = result.filter(x => x.attributeName === facilityId);
        secAttObject = result.filter(x => x.attributeName === securityId);
        facIndex = result.findIndex(x => x.attributeName === facilityId);
        secIndex = result.findIndex(x => x.attributeName === securityId);

        if (entityId === 1 && facIndex != 0) {
          result[secIndex] = facAttObject[0];
          result[facIndex] = secAttObject[0];
        }
        else if (entityId === 2 && secIndex != 0) {
          result[facIndex] = secAttObject[0];
          result[secIndex] = facAttObject[0];
        }

        this.correctionAttribute = result;
        console.log(this.correctionAttribute);
      });
  }
  //Get Data CorrectionDetail list
  private getDataCorrectionDetail(): void {
    this.editing = {};
    this.tempCorrectedList = [];
    this.correctedList = [];
    this.correctedListLoaded = false;
    this.correctionBasicInfo.correctionId = null;

    this.showHideLoadingImage(true); 
    this._datacorrectionService.getDataCorrectionDetail(this.correctionBasicInfo)
      .subscribe(result => {
        this.showHideLoadingImage(false); 
        if (result !== null) {
          this.correctionBasicInfo = result.correctionBasicInfo;
          this.filteredData = this.correctionBasicInfo.entityId === 1 ? result.facilityCorrectedDataList : result.securityCorrectedDataList;
          this.correctedList = this.correctionBasicInfo.entityId === 1 ? result.facilityCorrectedDataList : result.securityCorrectedDataList;
          this.origionalList = this.correctionBasicInfo.entityId === 1 ? result.facilityOrigionalDataList : result.securityOrigionalDataList;

          console.log(this.correctionBasicInfo);
          console.log(this.filteredData);
          console.log(this.correctedList);

          if(this.correctionBasicInfo)
          { 
              this.viewOnlyUser = (
                (this.correctionBasicInfo.createdBy 
                  && this.correctionBasicInfo.createdBy !== '' 
                  && this.correctionBasicInfo.createdBy.toLowerCase() !== this.userName) 
                || !this.isUser);

              this.initializeWorkflowStep(this.correctionBasicInfo.dealCorrectionStatusId); 
              //For concurrency
              //this.syncRecordModifiedDate();
          }

          //Progress bar
          setTimeout(() => {
            this.loadingIndicator = false;
          }, 10);

          if (this.correctedList) {
            this.createFormGroups();
            //this.messageCallback(ToasterTypes.info, this.title, `Data refreshed!`);
          }
          else {
            this.messageCallback(ToasterTypes.info, this.title, this.noDataFoundMessage);
          }
          // Insert data for origional data list
          if (this.correctedList) {
            this.correctedList.forEach(obj => this.tempCorrectedList.push(Object.assign({}, obj)));
          }
          //console.log(this.tempDataCorrectionList);
          this.correctedListLoaded = true;
        }
      });
  }
  showPopupCommentsHistory(title: string) {
  }
  resizeGrid() {
    if (document.getElementsByTagName('ngx-datatable').length > 0) {
      this._sharedDataService.triggerWindowResize(200);
    }
  }
  customSort(colName: string) {
    let filter = colName;
    if (colName !== this.selectedSortCol) {
      this.colSortType = 'asc';
      this.selectedSortCol = colName;
    } else if (colName === this.selectedSortCol && this.colSortType === 'asc') {
      this.colSortType = 'desc';
      filter = '-' + filter;
    } else if (colName === this.selectedSortCol && this.colSortType === 'desc') {
      this.colSortType = 'asc';
    }

    this.correctedList = this._ngxOrderPipe.transform(this.correctedList, filter);
    console.log('Sorting Colum: ' + colName);
  }

  getFilteredColumn() {
    if (this.correctionAttribute) {
      const filteredCol = this.correctionAttribute.filter(function (col) {
        return col.isChecked;
      });
      return filteredCol;
    }
  }
  dataCorrectionColumnFilter(event, colName, colIdx) {
    if (this.correctedList) {
      const filteredCol = this.correctionAttribute.filter(function (col) {
        return col.isChecked;
      });
      const searchValue = event.target.value.toLowerCase();
      filteredCol[colIdx].filterText = (searchValue === 'blank' || searchValue === 'undefined') ? 'null' : searchValue.trim();

      let tempGridData = this.filteredData;
      console.log(tempGridData);
      filteredCol.forEach(function (col) {
        if (col.filterText !== '' && tempGridData.length > 0) {
          tempGridData = tempGridData.filter(function (row) {
            return String(row[col.attributeName]).toLowerCase().indexOf(col.filterText) !== -1 || !col.filterText;
          });
        }
      });
      this.correctedList = tempGridData;
    }
  }
  getRowClass = (row) => {
    var sourceRow = this.correctionBasicInfo.entityId === 1
      ? this.origionalList.filter(x => x.facilityId == row?.facilityId)
      : this.origionalList.filter(x => x.securityId == row?.securityId && x.connectionId == row?.connectionId);
    if (sourceRow.length) {
      // if (sourceRow[0]['status'] == AuthWorkflowStep.Authorise) {
      // return { 'cb-ngx-row-bg-authorised': true };
      //}
      for (let key of Object.keys(row)) {
        if (sourceRow[0][key] != row[key]) { 
          if(this.correctionBasicInfo.status.toLowerCase() == 'authorised')
          {
            return { 'cpb-ngx-row-bg-authorised': true };
          }
          else
          return { 'cpb-ngx-row-bg-color': true };
        }
      }
    }
  }
  getHeight() {
    let containerElem = document.getElementById("ngxDiv");
    let remainHeight = document.documentElement.clientHeight - (containerElem.getBoundingClientRect().top + window.scrollY);
    this._sharedDataService.triggerWindowResize(1000);
    return {
      'height': remainHeight + "px"
    };
  }
  private createFormGroups() {
    this.dataCorrectionForm = [];
    for (let index = 0; index < this.correctedList.length; index++) {
      this.dataCorrectionForm.push(
        this.setupFormGroup());
    }
  }
  private setupFormGroup(): FormGroup {
    let frmGroup: FormGroup;
    if (this.correctionBasicInfo.entityId === 1) {
      frmGroup = this.fb.group({
        // facilityId: ['', []]
        // ,securityId: ['', []]
        firstInterestMargin: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        , interestCharge: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        , ltvOverride: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        , developmentLtcValue: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        , developmentLtcOverride: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        , facilityTypeCode: ['', []]
        , interestBasis: ['', []]
        , interestBasisCode: ['', []]
        , costCentre: ['', []]
        , facilityCurrencyCode: ['', []]
        , facilitySourceCode: ['', []]
        , cisCode: ['', []]
      });
    }
    else if (this.correctionBasicInfo.entityId === 2) {
      frmGroup = this.fb.group({
        connectionId: ['', []]
        , valnSourceCode: ['', []]
        , grossValueAmt: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
        , propertyNatureCode: ['', []]
        , propertyPostcode: ['', []]
        , securityDescription: ['', []]
        , cradleSecurityId: ['', [Validators.required, Validators.pattern(this._numberRegex)]]
      })
    }
    return frmGroup;
  }

  onSearch() {
    if (this.correctionBasicInfo && !this.dateInvalid) {
      console.log(this.correctionBasicInfo.correctionDate);
      this.getDataCorrectionDetail();
    }
  }

  OnTypeChange(value: any) {
    this.FSText = value === '1' ? 'Facility Id' : 'Security Id';
    this.getDataAttribute(Number(value));
    this.getDataCorrectionDetail();
  }
  // Validating controls while editing
  IsValidControl(name: any, isSubmitted: boolean, rowIndex: number) {
    var fieldName = this.dataCorrectionForm[rowIndex].controls[name]
    var isValid: Boolean = true
    if ((fieldName.touched || isSubmitted) && (fieldName.errors?.required || fieldName.errors?.pattern)) {
      isValid = false;
    }
    return isValid;
  }
  // Check data changes while saving
  private CheckDataChange(row: any) {
    var originalRow = this.correctionBasicInfo.entityId === 1
      ? this.tempCorrectedList.filter(x => x.facilityId == row?.facilityId)
      : this.tempCorrectedList.filter(x => x.securityId == row.securityId);

    if (originalRow.length) {
      for (let key of Object.keys(row)) {
        if (row[key] != originalRow[0][key]) {
          return true
        }
      }
    }
    else
      return false;
  }

  prepareEdit(rowIndex: number)
  {
    if (this.viewOnlyUser) {
      this._toastrService.openToast(ToasterTypes.warning, this.title, this.cannotEditReadOnlys);
    }
    else if(this.isSheetSubmittedOrAuthorised) {
      this._toastrService.openToast(ToasterTypes.warning, this.title, this.cannotEditDuetoStatus + this.ddcStatus);
    }
    else this.editing[rowIndex] = true;
  }

  //Edit row cancellation
  cancel(row: any, rowIndex: number) {
    this.editing[rowIndex] = false;
    const oldRow = this.tempCorrectedList[rowIndex];
    this.correctedList[rowIndex] = oldRow;
    this.correctedList = JSON.parse(JSON.stringify(this.correctedList));
  }
  getUpdatedAttributes(row: any): Array<CorrectedKeyValue> {
    let correctedAttributes = [];
    const keys = Object.keys(row);
    const fsId: any = this.correctionBasicInfo.entityId == 1 ? row['facilityId'] : row['securityId'];
    const connectionId: any = this.correctionBasicInfo.entityId == 2 ? row['connectionId'] : null;
    var originalRow = this.correctionBasicInfo.entityId == 1
      ? this.tempCorrectedList.filter(x => x.facilityId == row?.facilityId)
      : this.tempCorrectedList.filter(x => x.securityId == row?.securityId && x.correctionId == row?.correctionId);

    for (let i = 0; i < keys.length; i++) {
      if (originalRow[0][keys[i]] !== row[keys[i]]) {
        //console.log(originalRow[0][keys[i]]);
        const attributeId = this.correctionAttribute.find(x => x.attributeName === keys[i]).attributeId;
        let fsKeyValueObject: object = { 'facilitySecurityId': fsId, 'connectionId': connectionId,'attributeId': attributeId, 'value': row[keys[i]] };
        correctedAttributes.push(fsKeyValueObject);
      }
    }
    return correctedAttributes;
  }
  //Save row  
  save(row: any, rowIndex: any) {
    this.correctionBasicInfo.status = "Draft";
    this.submitted = true;
    if (this.dataCorrectionForm[rowIndex].valid) {
      if (!this.CheckDataChange(row)) {
        this.messageCallback(ToasterTypes.warning, this.title, this.fieldUpdatedMessage);
        return;
      }
      this.correctionBasicInfo.correctedData = JSON.stringify(this.getUpdatedAttributes(row));
      this._datacorrectionService.saveDataCorrection(this.correctionBasicInfo).subscribe(
        result => {
          const resultObj = JSON.parse(result);
          if ((resultObj.basicReturnCode === 101 || resultObj.basicReturnCode === 1011) && resultObj.detailReturnCode === 102) {
            this.messageCallback(ToasterTypes.success, this.title, this.saveSuccessMessage);
          }
          else {
            this.messageCallback(ToasterTypes.error, this.title, this.saveFailedMessage);
          }

          if(resultObj.dataCorrectionIdReturnCode)
          { 
             this.correctionBasicInfo.correctionId = resultObj.dataCorrectionIdReturnCode;
          }

          this.checkAuthorisationStatus();
        }
      )
      //Re-bind data again once saved
      this.editing[rowIndex] = false;
      this.correctedList = JSON.parse(JSON.stringify(this.correctedList));
      this.tempCorrectedList = JSON.parse(JSON.stringify(this.correctedList));
    }
    else
      this.messageCallback(ToasterTypes.error, this.title, this.requiredFieldMessage);
  }
  public messageCallback(toasterTypes: ToasterTypes, title: string, message: string) {
    this._toastrService.openToast(toasterTypes, title, message);
  }
  setDate(date: Date) {
    this.correctionBasicInfo.correctionDate = date.toDateString();
  }
  public onContextMenu($event: MouseEvent, item: any): void {
    this._contextMenuService.show.next({
      event: $event,
      item: item
    });
    $event.preventDefault();
    $event.stopPropagation();
  }

  checkAuthorisationStatus() {
    if(this.correctionBasicInfo && this.correctionBasicInfo.correctionId && this.correctionBasicInfo.correctionId > 0)
    {
      this._ddcAuthWorkflowService.getAuthWorkflowStatus(this.correctionBasicInfo.correctionId, AuthWorkflowType.DealDataCorrection)
      .subscribe((result) => {
        this.ddcAuthStatusModel = result;
        this.ddcStatusId = this.ddcAuthStatusModel.status;
         
        if(this.ddcAuthStatusModel.status === 2) this.ddcStatus = 'Pending Authorisation';
        else if (this.ddcAuthStatusModel.status === 3) this.ddcStatus = 'Authorised';
        else if (this.ddcAuthStatusModel.status === 4) this.ddcStatus = 'Rejected';
        else this.ddcStatus = 'Draft';
        
        if(result.stepName === "SendForAuthorisation"  || result.stepName === "Authorise") {
          this.isSheetSubmittedOrAuthorised = true;
        }
        else {
          this.isSheetSubmittedOrAuthorised = false;
        }

        this.initializeWorkflowStep(this.ddcStatusId); 

      }); 
    }
    // for concurrency
    this.syncRecordModifiedDate();
  }


  public initializeWorkflowStep(statusId : number) { 
    if(this.correctionBasicInfo)
    {
      if(statusId === 2) {
        this.ddcAuthStatusModel.stepName = 'SendForAuthorisation';
        this.isSheetSubmittedOrAuthorised = true;
        this.ddcStatus = 'Pending Authorisation';
      }
      else if(statusId === 3) {
        this.ddcAuthStatusModel.stepName = 'Authorise';
        this.isSheetSubmittedOrAuthorised = true;
        this.ddcStatus = 'Authorised';
      }
      else if(statusId === 4) {
        this.ddcAuthStatusModel.stepName = 'Reject';
        this.isSheetSubmittedOrAuthorised = false;
        this.ddcStatus = 'Rejected';
      } 
      else {
        this.ddcAuthStatusModel.stepName = 'Draft';
        this.isSheetSubmittedOrAuthorised = false;
        this.ddcStatus = 'Draft';
      }
    }
  }

  setUpUserRolesAndPermissions() {
    if (this._userService.userPermissionList.length > 0) {
          this.userPermissionOnDealDataCorrection 
          = this._userService.userPermissionList.filter(x => x.permission === PermissionEnum[PermissionEnum.PS_EligibilityManagement]);      
    }
    if(this._userService.userDetail !== undefined) {
     this.userDetail = this._userService.userDetail;
     this.setUserName(this.userDetail.userName.toLowerCase());
    }
    if(this.userPermissionOnDealDataCorrection.length > 0 && this.userPermissionOnDealDataCorrection.find(x =>
      x.permissionAccessType === PermissionAccessTypeEnum[PermissionAccessTypeEnum.ApproveReject]) !== undefined) {
        this.isAuthoriser = true;
      }
    if(this.userPermissionOnDealDataCorrection.length > 0 && this.userPermissionOnDealDataCorrection.find(x =>
      x.permissionAccessType === PermissionAccessTypeEnum[PermissionAccessTypeEnum.AddEdit]) !== undefined) {
        this.isUser = true;
      }
    this.viewOnlyUser = !this.isUser;
  }

  setUserName(userName: string) {
    this.userName = userName;
  }

  onDealDataWorkflowSubmit(actionBtn: string) {
    if (this.correctionBasicInfo && this.correctionBasicInfo.correctionId && this.correctionBasicInfo.correctionId > 0) {
      if (actionBtn === 'authorisereject') {
        this.authoriseReject();
      } 
      else if (actionBtn === 'sendforsuthorisation') {
        this.sendForAuthorisation();
      } 
      else if (actionBtn === 'recallauhorisation') {
        this.recall();
      }
    } else {
      this._toastrService.openToast(ToasterTypes.error, this.title, 'No Data updatated');
    }
  }

  authoriseReject() { 
    var model = new AuthModalConfigModel('Authorise/Reject Confirmation!!', 'Authorise/Reject with your comments', 'Comment is required.', AuthWorkflowType.DealDataCorrection, AuthWorkflowStep.Approve_Reject, 0, 0, this.correctionBasicInfo.correctionId,'', null);
    this.openModalPopup(model, '');
  }
  recall() {
    let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.DealDataCorrection, AuthWorkflowStep.Recall, 0, 0, this.correctionBasicInfo.correctionId, '', null);
    this.openModalPopup(model, 'Deal data correction recalled successfully');
  }
  sendForAuthorisation() { 
          let model = new AuthModalConfigModel('Comment', 'Please provide your comments', 'Comment is required.', AuthWorkflowType.DealDataCorrection, AuthWorkflowStep.SendForAuthorisation, 0, 0, this.correctionBasicInfo.correctionId, '', null);
          this.openModalPopup(model, 'Deal data correction has been send for Authorisation successfully');
  }

  openModalPopup(model: AuthModalConfigModel, message: string) {
    const modalRefPopUp = this._modalService.open(AuthWorkflowPopupComponent, {
      backdrop: 'static', 
      keyboard: false
    });
    modalRefPopUp.componentInstance.commentPopUpConfig = model;
    modalRefPopUp.componentInstance.popupEmitService.subscribe((val) => {
      this._toastrService.openToast(ToasterTypes.success, this.title, message ? message : val);
      this.checkAuthorisationStatus();
    });
  }

  syncRecordModifiedDate()
  {
      this._ddcAuthWorkflowService.getEntityAuditDetails(this.correctionBasicInfo.correctionId, AuthWorkflowType.DealDataCorrection).subscribe((result) => {
        this.modifiedDate = result.modifiedDate;
      });
  }

  openAuditTrailModal() {
    const modalRefPopUp = this._modalService.open(WorkflowAuditTrailPopupComponent, {
      size: 'lg',
      backdrop: 'static',
      keyboard: false
    });
    var auditTrailModel = new AuditTrailPopupModel(this.correctionBasicInfo.correctionId, AuthWorkflowType.DealDataCorrection)
    modalRefPopUp.componentInstance.auditTrailConfig = auditTrailModel;
  }

  showHideLoadingImage(isShow) {
    if (isShow){
      document.getElementById('preloader').style['display'] = 'block';
      this.isDataLoadingStarted = true;
    }
    else{
      document.getElementById('preloader').style['display'] = 'none';
      this.isDataLoadingStarted = false;
    }
  }

}