import { Component, OnInit } from '@angular/core';
import { SFP_SlickGridUtility, SFP_SlickAction, SFP_SlickColumn, template } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SfpGridOptionsModel, SfpGridColumnModel, SfpGridActionModel } from '../../../shared/components/grid/sfp-gridOptions.model';
import { FieldType, Formatters } from 'angular-slickgrid';
import { ActivatedRoute, Router } from '@angular/router';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';

@Component({
  selector: 'sfp-deal-data-correction-list',
  templateUrl: './data-correction-list.component.html',
  styleUrls: ['./data-correction-list.component.scss']
})
export class DataCorrectionListComponent implements OnInit {

  slickDataset: any;
  slickDefaultHiddenColumns: any;
  slickDefaultActionButtons: any;
  slickCallbackFuntions: any;
  slickColumnArray: any;
  slickExportFileName: any;
  title: string = 'Data Correction List';
  constructor(private router: Router
    , private activatedRoute: ActivatedRoute
    , private sharedDataService: SharedDataService) { }

  ngOnInit(): void {
  }

  onAddDataCorrectionSpreadsheet() {
    this.router.navigate(['/commercialbanking/datacorrection/create']);
  }

  clearFilter() {
    this.router.onSameUrlNavigation = 'reload';
    this.router.navigate(['/commercialbanking/datacorrectionlist'], { relativeTo: this.activatedRoute });
    this.router.routeReuseStrategy.shouldReuseRoute = function () {
      return false;
    };
  }
  resizeGrid() {
    const objSFP_Slick: SFP_SlickGridUtility = new SFP_SlickGridUtility(this.sharedDataService);
    objSFP_Slick.resizeGrid();
  }
}
