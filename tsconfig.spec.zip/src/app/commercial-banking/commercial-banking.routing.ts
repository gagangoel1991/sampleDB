import { ModuleWithProviders } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CanDeactivateGuardService } from 'src/app/core/guard/can-deactivate/can-deactivate-guard.service';

import { CommercialBankingModule } from './commercial-banking.module';
import { DataCorrectionListComponent } from './deal-data-correction/deal-data-correction-list/data-correction-list.component';
import { DataCorrectionComponent } from './deal-data-correction/new-deal-data-correction/data-correction.component';
import { OverrideListComponent } from './override/override-list/override-list.component';
import { OverrideManageComponent } from './override/override-manage/override-manage.component';

export const routes: Routes = [

    { path: '', redirectTo: 'datacorrection/create', pathMatch: 'full' },
    //{ path: 'datacorrectionlist', component: DataCorrectionListComponent, data: { breadcrum: 'Data Correction List' } },
    { path: 'datacorrection/create', component: DataCorrectionComponent, data: { breadcrum: 'Data Correction' } },
    { path: 'override', component: OverrideListComponent },
    { path: 'override/view/:dealId', component: OverrideManageComponent, data: { breadcrum: 'Override' }, canDeactivate: [CanDeactivateGuardService] }
]
export const commercialBankingRouting: ModuleWithProviders<CommercialBankingModule> = RouterModule.forChild(routes);