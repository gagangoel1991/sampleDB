import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { commercialBankingRouting } from './commercial-banking.routing';
import { DataCorrectionComponent } from './deal-data-correction/new-deal-data-correction/data-correction.component';
import { DataCorrectionListComponent } from './deal-data-correction/deal-data-correction-list/data-correction-list.component';
import { CustomControlModule } from '../shared/modules/custom-control.module';
import { PerfectScrollbarConfigInterface, PerfectScrollbarModule, PERFECT_SCROLLBAR_CONFIG } from 'ngx-perfect-scrollbar';
import { DirectivesModule } from '../core/theme/directives/directives.module';
import { PipesModule } from '../core/theme/pipes/pipes.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MultiselectDropdownModule } from 'angular-2-dropdown-multiselect';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { OverrideManageComponent } from './override/override-manage/override-manage.component';
import { OverrideListComponent } from './override/override-list/override-list.component';
import { NgSelectModule } from '@ng-select/ng-select';
const DEFAULT_PERFECT_SCROLLBAR_CONFIG: PerfectScrollbarConfigInterface = { suppressScrollX: true };

@NgModule({
  declarations: [
    DataCorrectionComponent,
    DataCorrectionListComponent,
    OverrideListComponent,
    OverrideManageComponent,   
  ],
  imports: [
    CommonModule,
    CustomControlModule,
    commercialBankingRouting,
    PerfectScrollbarModule,
    DirectivesModule,
    PipesModule,
    FormsModule,
    MultiselectDropdownModule,
    NgxDatatableModule,
    CustomControlModule,
    ReactiveFormsModule,
    NgSelectModule,
  ],
  providers: [
    {
      provide: PERFECT_SCROLLBAR_CONFIG,
      useValue: DEFAULT_PERFECT_SCROLLBAR_CONFIG
    }],
  entryComponents: []

})
export class CommercialBankingModule { }
