import { HttpHeaders } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from '@environment'; 

@Injectable()
export class ConstantService {

  private token: string;
  get AuthToken() {
    return this.token;
  }
  set AuthToken(value) {
    this.token = value;
  }

  readonly apiEndPoint = environment.apiEndPoint;

  readonly apiHeaders = new HttpHeaders().set('Content-Type', 'application/json').set('Accept', 'application/json');
  readonly apiPostFormHeaders = new HttpHeaders().set('Content-Type', 'multipart/form-data').set('Accept', 'multipart/form-data');
  readonly withCredential = true;
}
