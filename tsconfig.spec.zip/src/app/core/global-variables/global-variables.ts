export class GlobalVariables {
    public static isAssetClassUpdated: boolean = false;
}
