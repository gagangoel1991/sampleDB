import { TestBed } from '@angular/core/testing';
import { LogMaster, LogType } from '../global-log.service';
import { LogFactory } from '../log-factory';
import { LogPublisherService } from '../log-publisher.service';

describe("Service: Log-LogPublisher", () => {

  let publisher: LogPublisherService;
  beforeEach(() => {
    TestBed.configureTestingModule({
      providers: [LogPublisherService, LogType, LogMaster]
    })
    publisher = new LogPublisherService();
  });

  afterEach(() => {
    publisher = null;
  });

  class FakeClient extends LogFactory {
    Log(entry: LogMaster, type: LogType): boolean {
      return true
    }
    Dispose(): boolean {
      return true;
    }
  }

  it('should create an instance', () => {
    expect(publisher).toBeTruthy();
  });

  it('should be able to push log factory subclass into publisher', () => {
    let logFactory: LogFactory[] = [];
    let fakingPublisher = (): any => {
      logFactory.push(new FakeClient())
    }
    expect(publisher).toBeDefined();
    spyOn(publisher, "buildPublishers").call(fakingPublisher);
  });
});