import { LogFactory } from './log-factory';
import { LogMaster, LogType } from './global-log.service';
import { GlobalHttpService } from '../api/global.http.service';
import { Injectable } from "@angular/core";


@Injectable()
export class LogApi extends LogFactory {

  messageBody: string;

  constructor() {
    super();
    // Set location
    this.location = "/logs";
  }

  // Add log entry to back end data store using API
  Log(entry: LogMaster, api: GlobalHttpService, type: LogType): boolean {
    this.messageBody = entry.BuildLogMessage(type);
    if (this.messageBody) {
      api.PostRequest(this.location, { message: this.messageBody }).subscribe();
      return true;
    }
    else
      return false;
  }

  // Clear all log entries from Api
  Dispose(id: number, api: GlobalHttpService): boolean {
    api.DeleteRequest(this.location, id).subscribe();
    return true;
  }
}