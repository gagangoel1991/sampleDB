import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HomeService } from 'src/app/shared/home/home.service';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class IpdProcessMenuResolverService implements Resolve<any> {
    private _globalHttpService: GlobalHttpService;

    constructor(private globalHttpService: GlobalHttpService) {
        this._globalHttpService = globalHttpService;
    }

    resolve(route: ActivatedRouteSnapshot) {
        console.log('IPD Run Process menu resolver is called.');
        return this._globalHttpService.GetRequest('/auth0/getdealipdmenu', {dealId: route.params['dealId']}).toPromise();
    }
}
