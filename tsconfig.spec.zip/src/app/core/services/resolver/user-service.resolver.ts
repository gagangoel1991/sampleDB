import { Resolve, ActivatedRouteSnapshot } from '@angular/router';
import { Injectable } from '@angular/core';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { HomeService } from 'src/app/shared/home/home.service';
import { Observable } from 'rxjs';

@Injectable({
    providedIn: 'root'
})
export class UserResolverService implements Resolve<any> {
    private _globalHttpService: GlobalHttpService;

    constructor(private globalHttpService: GlobalHttpService) {
        this._globalHttpService = globalHttpService;
    }

    resolve(route: ActivatedRouteSnapshot) {
        const selectedAssetId = window.localStorage.getItem('selectedAssetId');
        console.log('user service resolver is called.');
        return this._globalHttpService.GetRequest('/auth0/getAppInitialData/' + selectedAssetId, null).toPromise();
    }
}
