import { TestBed } from '@angular/core/testing';
import { HttpClientModule, HttpEvent, HttpEventType, HttpResponse } from '@angular/common/http';
import { HttpClientTestingModule, HttpTestingController } from '@angular/common/http/testing';
import { GlobalHttpService } from './global.http.service';
import { ConstantService } from '../../constants/constant.service';
import { LogConsole } from '../log/log-console';

describe('Service: API-GlobalHttpService', () => {

  let globalHttpService: GlobalHttpService;
  let constant: ConstantService;
  let httpCtrl: HttpTestingController;

  beforeEach(() => {
    TestBed.configureTestingModule({
      imports: [HttpClientModule, HttpClientTestingModule],
      providers: [{ provide: GlobalHttpService, useClass: GlobalHttpService },
        ConstantService,
        LogConsole
      ]
    })
    globalHttpService = TestBed.get(GlobalHttpService);
    constant = TestBed.get(ConstantService);
    httpCtrl = TestBed.get(HttpTestingController);
  });

    afterEach(() => {
    httpCtrl.verify();
    globalHttpService = null;
    constant = null;
    httpCtrl = null;
    //console.clear();
  });

  function callback() {
    return true;
  }

  it('service should be created', () => {
    expect(globalHttpService).toBeTruthy();
    expect(globalHttpService).toBeDefined();
  });

  xit('should have a get http request', () => {
    globalHttpService.GetRequest("/endpoint", callback).subscribe((res) => {
    });
    let mockReq = httpCtrl.expectOne(constant.apiEndPoint + "/endpoint");
    expect(mockReq.request.method).toEqual('GET');
    mockReq.flush([]);
  });

  xit('should get data response as json', () => {
    const dummy = [{
      "key": 1,
      "value": "data"
    }];
    //Requesting get and moking data
    globalHttpService.GetRequest("/endpoint", callback).
      subscribe((res: HttpEvent<any>) => {
        switch (res.type) {
          case HttpEventType.Response:
            expect(res.body).toEqual(dummy);
            expect(res.body).toContain(dummy);
        }
      });
    //Mocking and validate response
    let mockReq = httpCtrl.expectOne(constant.apiEndPoint + "/endpoint");
    expect(mockReq.cancelled).toBeFalsy();
    expect(mockReq.request.responseType).toEqual('json');
    mockReq.flush(dummy);
  });

  it('should have a post http request', () => {
    globalHttpService.PostRequest("/endpoint", null, callback).subscribe((res) => {
    });
    let mockReq = httpCtrl.expectOne(constant.apiEndPoint + "/endpoint");
    expect(mockReq.request.method).toEqual('POST');
    mockReq.flush([]);
  }
  );

  it('should post data and return response as json', () => {
    const dummy = [{
      "key": 100,
      "value": "data"
    }];
    //Requesting get and moking data
    globalHttpService.PostRequest("/endpoint", dummy, callback).
      subscribe(res => {
        expect(res).toEqual(dummy, 'should return data'), fail;
      });
    //Mocking and validate response
    let mockReq = httpCtrl.expectOne(constant.apiEndPoint + "/endpoint");
    expect(mockReq.cancelled).toBeFalsy();
    expect(mockReq.request.responseType).toEqual('json');
    expect(mockReq.request.body).toBe(dummy);

    const expectedResponse = new HttpResponse({ status: 201, statusText: 'Created', body: dummy });
    mockReq.event(expectedResponse);
    //console.log(mockReq.request.body);
    mockReq.flush(dummy);
  }
  );

  it('should have a delete http request', () => {
    globalHttpService.DeleteRequest("/endpoint", null, callback).subscribe((res) => {
    });
    let request = httpCtrl.expectOne(constant.apiEndPoint + "/endpoint/null");
    expect(request.request.method).toEqual('DELETE');
    request.flush([]);
  });
})