import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, throwError, of, Observer, observable } from 'rxjs';
import { catchError, tap, finalize } from 'rxjs/operators';
import { ConstantService } from 'src/app/core/constants/constant.service';
import { LogMaster, LogType } from '../log/global-log.service';
import { LogConsole } from '../log/log-console';
import { delay } from 'rxjs/operators';

@Injectable()
export class GlobalHttpService {

  body: Object;
  endPoint = this.constant.apiEndPoint;

  constructor(private httpClient: HttpClient, private constant: ConstantService, private logMaster: LogMaster,
    private logConsole: LogConsole) { }

  // Get Request
  GetRequest(path: string, param: any = null, clientCallback: Function = null): Observable<any> {
    return (
      this.httpClient.get(this.endPoint + path,
        { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential, params: param }
      )
    ).pipe(catchError(error => {
      this.LogError(error.message);
      return throwError(error);
    })
      , finalize(() => {
        if (clientCallback) {
          clientCallback();
        }
      })
    );
  }

  GetRequestWithBlobType(path: string, param: any = null, clientCallback: Function = null, observe = null): Observable<any> {
    return (
      this.httpClient.get(
        this.endPoint + path,
        {
          headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential, params: param,
          responseType: 'blob', observe: observe !== null ? observe : null
        }
      )
    ).pipe(catchError(error => {
      this.LogError(error.message);
      return throwError(error);
    })
      , finalize(() => {
        if (clientCallback) {
          clientCallback();
        }
      })
    );
  }
  GetRequestWithResolverDelay(path: string, param: any = null, clientCallback: Function = null): Observable<any> {

    if (param != null) {
      path = path + `?+${param}`;
    }
    return (this.httpClient.get(
      this.endPoint + path,
      { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential }
    )
    ).pipe(catchError(error => {
      this.LogError(error.message);
      return throwError(error);
    })
      , finalize(() => {
        if (clientCallback) {
          clientCallback();
        }
      })
    ).pipe(delay(500));
  }
  PutRequest(path: string, data: Object, clientCallback: Function = null): Observable<any> {

    return (this.httpClient.put(
      this.endPoint + path,
      data,
      { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          if (clientCallback) {
            clientCallback();
          }
        })
      );
  }

  PatchRequest(path: string, data: Object, clientCallback: Function = null): Observable<any> {

    return (this.httpClient.patch(
      this.endPoint + path,
      data,
      { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          clientCallback();
        })
      );
  }

  PatchRequestWithBlobType(path: string, data: Object, clientCallback: Function = null, observe = null): Observable<any> {

    return (this.httpClient.patch(
      this.endPoint + path,
      data,
      { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential,
        responseType: 'blob', observe: observe !== null ? observe : null }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          if (clientCallback) {
            clientCallback();
          }
        })
      );
  }
  // Post Request
  PostRequest(path: string, data: Object, clientCallback: Function = null): Observable<any> {

    return (this.httpClient.post(
      this.endPoint + path,
      data,
      { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          if (clientCallback) {
            clientCallback();
          }
        })
      );
  }
  // Upload Request
  UploadRequest(path: string, data: Object, header: object = null, clientCallback: Function = null): Observable<any> {

    const headers = new HttpHeaders().append('Content-Disposition', 'multipart/form-data');
    return (this.httpClient.post(
      this.endPoint + path,
      data,
      { headers: headers , withCredentials: this.constant.withCredential }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          if (clientCallback) {
            clientCallback();
          }
        })
      );
  }
  PostFormDataRequest(path: string, data: Object, clientCallback: Function = null): Observable<any> {

    return (this.httpClient.post(
      this.endPoint + path,
      data,
      { withCredentials: this.constant.withCredential }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          clientCallback();
        })
      );
  }

  DownloadFile(path: string, param: any = null): Observable<Blob> {
    return this.httpClient.get(this.endPoint + path,
      {
        withCredentials: this.constant.withCredential, responseType: 'blob', params: param
      }
    ).pipe(catchError(error => {
      this.LogError(error.message);
      return throwError(error);
    }));
  }

  // Delete Request
  DeleteRequest(path: string, id: number, clientCallback: Function = null): Observable<any> {
    return (this.httpClient.delete(
      `${this.endPoint}${path}/${id}`,
      { headers: this.constant.apiHeaders, withCredentials: this.constant.withCredential }
    ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          clientCallback();
        })
      );
  }

  LogError(errorMessage: string) {
    this.logMaster.Message = `HTTP Error: ${errorMessage}`;
    this.logConsole.Log(this.logMaster, LogType.Info);
  }

  // Post Request
  PostRequestWithRequestHeaders(path: string, data: Object, clientCallback: Function = null, extraHeaders: Object = null): Observable<any> {
    var apiHeaders = this.constant.apiHeaders;
    if (extraHeaders != null) {      
      for (var key in extraHeaders) {
        apiHeaders = apiHeaders.append(key, extraHeaders[key]);
      }
    }
    return (
      this.httpClient.post(
        this.endPoint + path,
        data,
        { headers: apiHeaders, withCredentials: this.constant.withCredential }
      ))
      .pipe(catchError(error => {
        this.LogError(error.message);
        return throwError(error);
      })
        , finalize(() => {
          if (clientCallback) {
            clientCallback();
          }
        })
      );
  }

  GetRequestWithRequestHeaders(path: string, param: any = null, clientCallback: Function = null, extraHeaders: Object = null): Observable<any> {
    var apiHeaders = this.constant.apiHeaders;
    if (extraHeaders != null) {     
      for (var key in extraHeaders) {
        apiHeaders = apiHeaders.append(key, extraHeaders[key]);
      }
    }   
    return (
      this.httpClient.get(this.endPoint + path,
        { headers: apiHeaders, withCredentials: this.constant.withCredential, params: param }
      )
    ).pipe(catchError(error => {
      this.LogError(error.message);
      return throwError(error);
    })
      , finalize(() => {
        if (clientCallback) {
          clientCallback();
        }
      })
    );
  }
}
