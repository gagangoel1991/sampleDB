import { Component, OnInit, Input } from '@angular/core';
import { LogMaster, LogType } from 'src/app/core/services/log/global-log.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';

@Component({
  selector: 'az-sample',
  templateUrl: './sample.component.html',
  styleUrls: ['./sample.component.scss']
})
export class SampleComponent implements OnInit {

  constructor(private logEntry: LogMaster
    , private logConsole: LogConsole
    , private apiService: GlobalHttpService
    , private fb: FormBuilder
  ) { }

  @Input() frmName: string="Login Page";
  //@Output() someEvent: new EventEmitter<string>();  

  loginForm: FormGroup;
  ngOnInit(): void {
    this.loginForm = this.fb.group({
      fcUserName: new FormControl('', [Validators.required, Validators.minLength(4)]),
      fcUserPwd: new FormControl('', [Validators.required, Validators.minLength(6)]),
      fcDomain: new FormControl('', [Validators.required]),
      fcSubmit: new FormControl('')
    });
  }
  payload: any = JSON.stringify({});

  OnClick() {
    this.apiService.GetRequest("/Books", () => { console.log("This Callback function executed") }).subscribe(
      result => {
        this.payload = JSON.stringify(result);
        this.logEntry.Message = JSON.stringify(result);

        this.logConsole.Log(this.logEntry, LogType.Info);
      },
      error => { console.log(`Error while getting data: ${error}`) },
      () => console.log('HTTP request has been completed')
    )
  }}