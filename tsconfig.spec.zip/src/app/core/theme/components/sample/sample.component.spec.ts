import { FormBuilder, ReactiveFormsModule, FormGroup, FormControl } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import { async, ComponentFixture, TestBed, inject } from '@angular/core/testing';
import { By } from '@angular/platform-browser';
import { SampleComponent } from './sample.component';
import { SampleChildComponent } from '../sample-child/sample-child.component';
import { GlobalHttpService } from 'src/app/core/services/api/global.http.service';
import { LogMaster } from 'src/app/core/services/log/global-log.service';
import { LogConsole } from 'src/app/core/services/log/log-console';
import { ConstantService } from 'src/app/core/constants/constant.service';

describe('Component: GeneralComponent', () => {
  let component: SampleComponent;
  let fixture: ComponentFixture<SampleComponent>;
  let childFixture:ComponentFixture<SampleChildComponent>;
  let apiService: GlobalHttpService;
  let submitEl: any;
  
  beforeEach(async(
    () => {
      TestBed.configureTestingModule({
        declarations: [SampleComponent, SampleChildComponent],
        providers: [LogMaster, LogConsole, GlobalHttpService, ConstantService, FormBuilder],
        imports: [HttpClientModule, ReactiveFormsModule]
      })
        .compileComponents();
    }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SampleComponent);
    childFixture = TestBed.createComponent(SampleChildComponent);

    component = fixture.componentInstance;

    fixture.detectChanges();

    apiService = TestBed.get(GlobalHttpService);
    submitEl = fixture.debugElement
  });

  it('should have a defined component', () => {
    //if component is created
    expect(component).toBeDefined();
  });

  it('should invalid when form is empty', () => {
    expect(component.loginForm.valid).toBeFalsy();
    expect(submitEl.nativeElement.querySelector('button').disabled).toBeTruthy();
  });

  it('should inject api service dependency', () => {
    expect(
      inject([GlobalHttpService], (api: GlobalHttpService) => {
        expect(apiService).toBe(api);
      })).toBeTruthy();
  });

  it('should create a FormGroup having FormControls', () => {
    component.ngOnInit();
    expect(component.loginForm instanceof FormGroup).toBe(true);

    //expect(component.loginForm.controls['fcUserName'] instanceof FormControl).toBe(true);
    Object.keys(component.loginForm.controls).forEach(key => {
      expect(component.loginForm.controls[key] instanceof FormControl).toBe(true);
    });
  });

  it('should return true only if the form control is valid', () => {
    //Validating Required field validation
    component.loginForm.controls['fcUserName'].setValue('');
    component.loginForm.controls['fcUserPwd'].setValue('');
    component.loginForm.controls['fcDomain'].setValue('');
    fixture.detectChanges();
    expect(component.loginForm.valid).toBeFalsy();

    //Validating MinLength validation
    component.loginForm.controls['fcUserName'].setValue('fm\singsho');
    component.loginForm.controls['fcUserPwd'].setValue('password');
    component.loginForm.controls['fcDomain'].setValue('FM');
    fixture.detectChanges();
    expect(component.loginForm.get('fcUserName').value.length).toBeGreaterThanOrEqual(4);
    expect(component.loginForm.get('fcUserPwd').value.length).toBeGreaterThanOrEqual(8);
    expect(component.loginForm.get('fcDomain').value.length).not.toBeUndefined();

    //Submit button should be enabeld if form is valid
    expect(submitEl.nativeElement.querySelector('button').disabled).toBeFalsy();
  });

  it('should get the payload on form submit', () => {
    component.loginForm.controls['fcUserName'].setValue('fm\singsho');
    component.loginForm.controls['fcUserPwd'].setValue('password');
    component.loginForm.controls['fcDomain'].setValue('FM');
    component.OnClick();
    expect(component.payload).toEqual(JSON.stringify({}));
    expect(component.payload).not.toBeUndefined();
  });
  
  it('should pass properties to child properly', ()=>{
    let childDebugElement = fixture.debugElement.query(By.directive(SampleChildComponent));
    expect(childDebugElement).toBeTruthy();
    const childEl = childDebugElement.queryAll(By.css('h2'))[0].nativeElement.innerHTML;
    expect(childEl).toBe('Login Page');
  });
});