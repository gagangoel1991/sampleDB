import { Component, Input, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NgbModal } from '@ng-bootstrap/ng-bootstrap';
import { GlobalVariables } from 'src/app/core/global-variables/global-variables';
import { Asset } from 'src/app/core/models/asset.model';
import { CommonPopupComponent } from 'src/app/shared/components/confirm-common-popup/sfp-common-popup.component';
import { CommonPopupConfigModel } from 'src/app/shared/components/grid/sfp-gridOptions.model';
import { InfoPopupComponent } from 'src/app/shared/components/info-popup/info-popup.component';
import { SFP_SlickInstance } from 'src/app/shared/components/slick-grid/slick-grid.model';
import { SharedDataService } from 'src/app/shared/services/shared-data.service';
import { AppState } from '../../../../app.state';
import { UserModel } from '../../../../shared/home/user.model';
import { SfpBatchStatusInfo } from '../../../../shared/model/sfp-batchstatus-info.model';

@Component({
    selector: 'sfs-navbar',
    templateUrl: './navbar.component.html',
    styleUrls: ['./navbar.component.scss']
})

export class NavbarComponent implements OnInit {
    @Input() userDetail: UserModel = new UserModel('', '', '', '', '', '', []);

    public batchInfo: SfpBatchStatusInfo = new SfpBatchStatusInfo();

    public isMenuCollapsed: boolean = false;
    public userFullName: string = 'Kaushik';
    public userNameWithRole: string = 'Kapil Sharma - Read Only';
    public userRole: string = 'Read Only';
    public isAssetBeingUpdated: boolean = false;
    public assetClassList: any;
    public selectedAssetClassId: string;
    public currentAssetClass: Asset;
    public isBatchCompleted: boolean = true;

    private _router: Router;
    private _updatedAssetTitle = 'Asset Class Updated';
    private _updatingAssetTitle = 'Updating Asset Class';
    private _updatedAssetClassMsg = 'Change in asset class detected. Page will reload.';
    private _updatingAssetClassMsg = 'Make sure you have no unsaved changes related to current asset class in any tab. \nDo you want to continue?';
    
    constructor(private _state: AppState,
                private _sharedDataService: SharedDataService,
                private _modalService: NgbModal,
                router: Router) {
        this._state.subscribe('menu.isCollapsed', (isCollapsed) => {
            this.isMenuCollapsed = isCollapsed;
        });
        this._router = router;
    }

    ngOnInit() {
        this.assetClassList = this.userDetail.assetClassList;
        this.selectedAssetClassId = this.userDetail.selectedAssetClass.toString();
        //this.selectedAssetClassId = '2';

        this.currentAssetClass = this.getAssetClass(this.selectedAssetClassId);
        window.localStorage.setItem('selectedAssetId', this.selectedAssetClassId);

        if(this.getCurrentAssetValue() === 'Retail') {
            this.getSFPBatchInformation();
        }
    }
    public closeSubMenus() {
        /* when using <sfs-sidebar> instead of <sfs-menu> uncomment this line */
        // this._sidebarService.closeAllSubMenus();
    }
     
    public getSFPBatchInformation() {
        this._sharedDataService.getSFPBatchInformation(sfpBatchInformation => {
            this.batchInfo = sfpBatchInformation; 
        });
    }

    public toggleMenu() {
        this.isMenuCollapsed = !this.isMenuCollapsed;
        this._state.notifyDataChanged('menu.isCollapsed', this.isMenuCollapsed);

        // Below block loop on slick instances and call the resize grid function
        // reference - https://github.com/ghiscoding/Angular-Slickgrid/issues/175
        const SfpSlickInstance: SFP_SlickInstance[] = this._sharedDataService.getSfpSlickInstance();
        SfpSlickInstance.forEach((element) => {
            element.angularGridInstance.resizerService.resizeGrid();
        });

        // For ngx datatable
        if (document.getElementsByTagName('ngx-datatable').length > 0) {
            this._sharedDataService.triggerWindowResize(200);
        }

    }

    getAssetClass(id) {
        for (const asset of this.assetClassList) {
            if (asset.classId === id) {
                return asset;
            }
        }
    }

    public changeAsset(asset: Asset) {
        if (asset.classId !== window.localStorage.getItem('selectedAssetId')) {
            this.isAssetBeingUpdated = true;
            const modalRefDel = this._modalService.open(CommonPopupComponent, {
                backdrop: 'static',
                keyboard: false
            });
            modalRefDel.componentInstance.popupConfig =
                        new CommonPopupConfigModel(this._updatingAssetTitle, this._updatingAssetClassMsg);
            modalRefDel.componentInstance.isWarningDisabled = true;
            modalRefDel.result.then(result => {
                if (result === 'confirmed') {
                    this.currentAssetClass = asset;
                    window.localStorage.setItem('selectedAssetId', this.currentAssetClass.classId);
                    GlobalVariables.isAssetClassUpdated = true;
                    this._router.navigate([''])
                        .then(() => window.location.reload());
                }
                this.isAssetBeingUpdated = false;
            });
        }
    }

    getCurrentAssetValue() {
        if (!this.isAssetBeingUpdated) {
            const storedValue = window.localStorage.getItem('selectedAssetId');
            if (storedValue) {
                if (storedValue !== this.currentAssetClass.classId) {
                    this.currentAssetClass = this.getAssetClass(storedValue);
                    const modalRefDel = this._modalService.open(InfoPopupComponent, {
                        ariaLabelledBy: 'modal-basic-title',
                        backdrop: 'static',
                        keyboard: false
                    });
                    modalRefDel.componentInstance.popupConfig =
                                new CommonPopupConfigModel(this._updatedAssetTitle, this._updatedAssetClassMsg);
                    modalRefDel.result.then(() => {
                        GlobalVariables.isAssetClassUpdated = true;
                        this._router.navigate([''])
                            .then(() => window.location.reload());
                    });
                }
            }
        }
        return this.currentAssetClass.className;
    }
    isMultiAssetUser() {
        return this.assetClassList.length > 1;
    }

}
