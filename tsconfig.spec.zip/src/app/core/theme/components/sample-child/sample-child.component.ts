import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'az-sample-child',
  templateUrl: './sample-child.component.html',
  styleUrls: ['./sample-child.component.scss']
})
export class SampleChildComponent implements OnInit {

  constructor() { }

  @Input() formName: string="Sample header";
  ngOnInit(): void {
  }

}
