import {Injectable} from '@angular/core'

@Injectable()
export class MessagesService {

    private _notifications = [
        {
            text: 'IR template is pending for authorization',
            time: '1 min ago'
        },
        {
            text: 'A new pool is pending for authorization.',
            time: '2 hrs ago'
        },
        {
            text: 'EC configurations are pending for authorization.',
            time: '5 hrs ago'
        },
        {
            text: 'Dunmore1 IPD is pending for authorization',
            time: '1 day ago'
        }
    ];

    public getNotifications():Array<Object> {
        return this._notifications;
    }

}