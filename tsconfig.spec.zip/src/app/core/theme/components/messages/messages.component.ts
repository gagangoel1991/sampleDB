import {Component, ViewEncapsulation} from '@angular/core';

import {MessagesService} from './messages.service';

@Component({
    selector: 'sfs-navbar-msg',
    encapsulation: ViewEncapsulation.None,
    styleUrls: ['./messages.component.scss'],
    templateUrl: './messages.component.html',
    providers: [MessagesService]
})

export class MessagesComponent{     
    public notifications:Array<Object>;

    constructor (private _messagesService:MessagesService){
        this.notifications = _messagesService.getNotifications();
    }

}