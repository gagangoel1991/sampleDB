export const menuItems = [
  {
    title: 'Home',
    routerLink: '',
    icon: 'fa-home',
    selected: false,
    expanded: false,
    order: 0
  }, 
  {
    title: 'DashBoard',
    routerLink: 'sfpdashboard',
  },
  {
    title: 'Cash Waterfall',
    routerLink: 'cashwaterfall',
    icon: 'fa-money',
    selected: false,
    expanded: true,
    order: 200,
    subMenu: [
      {
        title: 'Dashboard',
        routerLink: '/cashwaterfall/dashboard',
        icon: 'fa-list',
      },
      {
        title: 'Active Deals',
        routerLink: '/cashwaterfall/deallist',
        icon: 'fa-list',
      },
      {
        title: 'Invoice Management',
        routerLink: '/cashwaterfall/invoicemgmt',
        icon: 'fa-list',
      },
      {
        title: 'New Deal Onboard',
        routerLink: '/cashwaterfall/newdeal',
        icon: 'fa-gear',
      }
    ]
  },
  {
    title: 'Pool Selection',
    routerLink: 'poolselection',
    icon: 'fa-suitcase',
    selected: false,
    expanded: false,
    disabled: true,
    order: 200,
    subMenu: [
      {
        title: 'Pool Management',
        routerLink: '/poolselection/poolmanagement',
        icon: 'fa-files-o',
      },
      {
        title: 'Eligibility Criteria',
        routerLink: '/poolselection/eligibilitycriteriamanagement',
        icon: 'fa-files-o',
      },
      {
        title: 'Concentration Management',
        routerLink: '/poolselection/concentrationmanagement',
        icon: 'fa-files-o',
      },
      {
        title: 'Field Management12',
        routerLink: '/poolselection/fieldmanagement',
        icon: 'fa-files-o',
      }
    ]
  },
  {
    title: 'Reports',
    routerLink: 'reports',
    icon: 'fa-bar-chart',
    selected: false,
    expanded: false,
    order: 0
  }, 
  {
    title: 'Contact Support',
    routerLink: 'contactus',
    icon: 'fa-phone-square',
    selected: false,
    expanded: false,
    order: 0
  },
  {
    title: 'About',
    routerLink: 'aboutsfs',
    icon: 'fa-info-circle',
    selected: false,
    expanded: false,
    order: 0
  }
];
