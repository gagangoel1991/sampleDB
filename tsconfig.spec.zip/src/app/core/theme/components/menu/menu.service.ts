import { Injectable } from '@angular/core';
import {GlobalHttpService} from 'src/app/core/services/api/global.http.service';
import { Observable} from 'rxjs';

@Injectable()
export class MenuService {
  
  private _globalHttpService: GlobalHttpService;

  constructor(private globalHttpService: GlobalHttpService) {
    this._globalHttpService = globalHttpService;
  }

  public getMenuItems():Observable<any> {
    return this.globalHttpService.GetRequest('/auth0/getAppInitialData', null);
  }
 
}
