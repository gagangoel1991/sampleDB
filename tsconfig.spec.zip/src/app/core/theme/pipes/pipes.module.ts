import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppPicturePipe } from './appPicture/appPicture.pipe';
import { ProfilePicturePipe } from './profilePicture/profilePicture.pipe';
import { MailSearchPipe } from './search/mail-search.pipe';
import { SearchPipe } from './search/search.pipe';
import { CustomCurrencyPipe } from 'src/app/shared/pipes/custom-currency.pipe';
import { subString } from 'src/app/shared/pipes/sub-string.pipe';
import { ObjectArrayFilterByKeyValue } from 'src/app/shared/pipes/object-array-filter.pipe';
import { getRegexByDataType } from 'src/app/shared/pipes/get-regex-by-data-type.pipe';
import { ReplaceLineBreaks } from 'src/app/shared/pipes/replace-line-breaks.pipe';
import { FilterLookupTitleValuePipe } from 'src/app/shared/pipes/filter-lookup-title-value.pipe';


@NgModule({
    imports: [
        CommonModule
    ],
    declarations: [
        AppPicturePipe,
        ProfilePicturePipe,
        MailSearchPipe,
        SearchPipe,
        CustomCurrencyPipe,
        subString,
        ObjectArrayFilterByKeyValue,
        getRegexByDataType,
        ReplaceLineBreaks,
        FilterLookupTitleValuePipe
    ],
    exports: [
        AppPicturePipe,
        ProfilePicturePipe,
        MailSearchPipe,
        SearchPipe,
        CustomCurrencyPipe,
        subString,
        ObjectArrayFilterByKeyValue,
        getRegexByDataType,
        ReplaceLineBreaks,
        FilterLookupTitleValuePipe
    ]
})
export class PipesModule { }
