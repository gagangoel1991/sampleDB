export class Asset {
    classId: string;
    className: string;
    description: string;
    code: string;
}
