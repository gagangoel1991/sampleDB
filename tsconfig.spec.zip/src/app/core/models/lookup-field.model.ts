export class LookUpField {
    title: string;
    value: number;
    type: string;
    Description: string;
    ReferenceLookup: string;
    isAuthorised: boolean;
}

export class LookUpOperator {
    title: string;
    value: number;
    type: string;
    text: string;
}

export class FieldLookupData {
    templateName: string;
    fieldName: string;
    value: string;
    Options: string
}
