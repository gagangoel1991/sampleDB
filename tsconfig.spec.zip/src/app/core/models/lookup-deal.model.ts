export class LookUpDeal {
    dealKey: number;
    dealName: string;
    dealPublicName: string;
    dealType: string;
    dealStatus: string;
    dealCalculatedBasedOn: string;
}
