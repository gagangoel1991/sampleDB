export enum AssetType {
    Retail = '1',
    Corporate = '2',
    NatWestMarkets = '5'
}
