export class LookupTitleValue {
    title: string;
    value: number;
}
