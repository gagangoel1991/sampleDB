export class LookUpEligibility {
    title: string;
    value: number;
    isAuthorised: boolean;
}
