import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpRequest, HttpHandler, HttpResponse, HttpErrorResponse } from '@angular/common/http';
import { tap, finalize } from 'rxjs/operators';
import { delay } from 'q';
// import { ProgressbarService } from '../theme/components/progressbar/Service/progressbar.service';
import { ConstantService } from '../constants/constant.service';
import { LogConsole } from '../services/log/log-console';
import { LogMaster } from '../services/log/global-log.service';
import { LogApi } from '../services/log/log-api';
import { GlobalHttpService } from '../services/api/global.http.service';
import { Router } from '@angular/router';
import { GlobalToasterService, ToasterTypes } from 'src/app/shared/services/globaltoaster.service';

@Injectable()
export class HttpSharedIntercepterService implements HttpInterceptor {
  constructor(
    // private progressService: ProgressbarService,
    private apiService: GlobalHttpService, private constant: ConstantService
    , private logConsole: LogConsole
    , private logMaster: LogMaster,
    private logApi: LogApi,
    private router: Router, private _toastservice: GlobalToasterService
    ) { }

  intercept(request: HttpRequest<any>, next: HttpHandler) {

    const startTime = Date.now();
    let status: string;

    const requestWithAuthHeader = request.clone({
      headers: request.headers.set('withCredentials', 'true')
    });

    this.logMaster.Message = `Added AuthCode to Api request`;
    this.logMaster.ExtraInfo = [`URL header: ${requestWithAuthHeader.url}`];
    // this.logConsole.Log(this.logEntry, LogType.Info);
    // this.logApi.Log(this.logEntry, this.apiService, LogType.Error);
    delay(10000);
    // this.progressService.show();

    return next.handle(requestWithAuthHeader).pipe(

      tap(
        event => {
          status = '';
          if (event instanceof HttpResponse) {
            status = 'succeeded';
            this.logMaster.Message = `Http request is success`;
            // this.logConsole.Log(this.logEntry, LogType.Info);
          }
        },
        error => {
          status = 'failed';
          this.logMaster.Message = `Http Request failed`;
          if (error instanceof HttpErrorResponse) {
            if ((error.url && error.url.indexOf('checkHeartBeat') >= 0)
              || (error.url && error.url.indexOf('getAppInitialData') >= 0)) {
              this.router.navigate(['/servicedown']);
            } else if (error.status === 401 || error.status === 412) {
              this.router.navigate(['/unauthorised']);
            }   
            else if(error.status === 399){ 
              debugger;
              const errorSpecificSummaryText = this.setErrorSpecificSummary(error);
              this._toastservice.openToast(ToasterTypes.warning, 'Page Refresh Required', errorSpecificSummaryText); 
            }   
            else if(error.status === 398){ 
              debugger;
              const errorSpecificSummaryText = this.setErrorSpecificSummary(error);
              this._toastservice.openToast(ToasterTypes.warning, 'Another process in progress', errorSpecificSummaryText); 
            }    
            else {
              
                var serverLogSummaryText = this.setServerLogSummary(error);
              
                const errorSpecificSummaryText = this.setErrorSpecificSummary(error);
                this._toastservice.openToast(ToasterTypes.error, 'Error',
                errorSpecificSummaryText + serverLogSummaryText.toString());
            }
          }
          // this.logConsole.Log(this.logEntry, LogType.Error);
        }
      ),
      finalize(() => {
        const elapsedTime = Date.now() - startTime;
        const message = `Http Method: ${request.method} Parameter: ${request.urlWithParams} ${status} in ${elapsedTime}  ms`;
        this.logMaster.Message = message;
        // this.logConsole.Log(this.logEntry, LogType.Info);

        // this.progressService.hide();
      })
    );
  }

  setServerLogSummary(error: HttpErrorResponse): string {
    let basicSummary = '';
    if (error.error !== undefined && error.error.ErrorId !== undefined) {
      basicSummary = (error.error.ErrorId !== 0)
        ? ` Error number ` + error.error.ErrorId.toString() + ` has been logged in application.`
        : ` Error detail has been logged in application server logs.`;
    }

    basicSummary = basicSummary + `
    If problem persists, share it with application support at Group Chat Channel: Treasury_Sol_Service_Management`;

    return basicSummary;
  }

  setErrorSpecificSummary(error: HttpErrorResponse): string {
    let errorSpecificSummary = '';
    let StatusCode = error.status;
    if (error.error.StatusCode !== undefined)
    { 
       StatusCode = error.error.StatusCode;
    }

    switch (StatusCode) {
      case 398:         
        errorSpecificSummary = `Another Process is already running`;
        break;
      case 399:         
        errorSpecificSummary = `Please refresh this page as some other user has made the changes.  Note - Refresh will cause loss to your any unsaved changes.`;
        break;
      case 400:
        errorSpecificSummary = `Service failed to understand / process task due to Bad Request.`;
        break;
      case 403:
        errorSpecificSummary = `You are not authorised to perform this operation.`;
        break;
      case 404:
        errorSpecificSummary = `Requested resource was not found.`;
        break;
      case 405:
        errorSpecificSummary = `Application Service does not allow this operation for type of request submitted.`;
        break;
      case 408:
      case 0:
        errorSpecificSummary = `Application service could not respond back or Time allocated for the operation has expired.`;
        break;
      case 500:
        errorSpecificSummary = `Internal Server Error. Server encountered something it did not expect.`;
        break;
      case 507:
        errorSpecificSummary = `Insufficient memory to continue the execution of the program`;
        break;
      case 511:
        errorSpecificSummary = `Insufficient application network permissions to perform this operation.`;
        break;

      //
      case 1001:
        errorSpecificSummary = `Server Error. Trying to access data from beyond collection range.`;
        break;
      case 1002:
          errorSpecificSummary = `Server Error. Trying to access data from beyond collection range.`
          break;
      case 1003:
          errorSpecificSummary = `Data exceeds the Excel range of 1048576 rows.`; 
          break;
      case 1004:
          errorSpecificSummary =  `Unable to process due to invalid argument exception.`;
          break;
      case 1005:
          errorSpecificSummary = `Unable to process due to invalid argument exception.`;
          break;
      case 1006:
          errorSpecificSummary =  `Excel Error : Expected worksheer not available.`;
          break;
      case 1007:
          errorSpecificSummary = `The file you are looking for is not available.`;
          break;
      case 1008:
          errorSpecificSummary = `Server Error. Trying to access data from beyond collection range.`;
          break;
      case 1009:
          errorSpecificSummary = `Arithmetic exception occurred.`;
          break;
      case 1010:
          errorSpecificSummary = `Divide by zero error occurred.`;
          break;

      // DATABASE RELATED EXCEPTIONS
      case 2812:
        errorSpecificSummary = `Database error : Stored procedure is not found.`;
        break;
      case 208:
        errorSpecificSummary = `Database error : Invalid database object.` ;
        break;
      case 501:
        errorSpecificSummary = `Database error : Incorrect number of columns in table-valued parameter.`;
        break;
      case 4121:
        errorSpecificSummary = `Database error : Incorrect column or user defined function.`;
        break; 
      case 213:
        errorSpecificSummary = `Database error : Column name or number of supplied values does not match table definition.`;
        break; 
      case 207:
        errorSpecificSummary = `Database error : Invalid Column Name.`;
        break;
      case 229:
        errorSpecificSummary = `Database error : Insert permission was denied.`;
        break;
      case 916:
        errorSpecificSummary = `Database error : Access to the database denied.` ;
        break;
      case 512:
        errorSpecificSummary = `Database error : Incorrect subquery which returns more than 1 value.`;
        break;
      case 515:
        errorSpecificSummary = `Database error : Cannot insert NULL into table column.`;
        break; 
      case 201:
        errorSpecificSummary = `Database error : Parameter to stored procedure or function was not supplied.`;
        break;
      case 245:
        errorSpecificSummary = `Database error : Data conversion failed.`;
        break;
      case 9002:
        errorSpecificSummary = `Database error : Transaction log is full.`;
        break; 
      case 2627:
        errorSpecificSummary = `Database error : Cannot insert duplicate key.`;
        break;
      case 5313:
        errorSpecificSummary = `Database error : Refers to an invalid synonym object.`;
        break;
      case 1205:
         errorSpecificSummary = `Database error : Transaction was deadlocked on lock resources with another process.`;
        break;
      case 4060:
        errorSpecificSummary = `Database error : Cannot open database. Database not available or login failed.`;
        break;
      case 927:
        errorSpecificSummary = `Database error : Database cannot be opened. It is in the middle of a restore.`;
        break;
      case -2:
        errorSpecificSummary = `Database error : Timeout expired at database.`;
        break;
      case 1011:
        errorSpecificSummary = `File access error : Unable to access the shared path.`;
        break;
      case 1012:
        errorSpecificSummary = `File error : The file is being used by another process. Please try later`;
        break;

      default:
        errorSpecificSummary = `Something went wrong. Please try again.`;
    }

    return errorSpecificSummary;
  }

}
