import {Injectable} from '@angular/core';
import {GlobalHttpService} from 'src/app/core/services/api/global.http.service';

@Injectable()
export class AuthService {

  private _globalHttpService: GlobalHttpService;

  constructor(private globalHttpService: GlobalHttpService) {
    this._globalHttpService = globalHttpService;
  }

  public async checkApiHeartBeat(): Promise<any> {
    const res = await this.globalHttpService.GetRequest('/auth0/checkHeartBeat', null).toPromise();
    console.log(res);
    console.log('Get the result');
    return res;

    // return true;
  }

  public getDefaultAssetClass(): Promise<any> {
    return this.globalHttpService.GetRequest('/auth0/getDefaultAssetClass', null).toPromise();
  }
}
