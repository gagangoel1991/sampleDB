import { Injectable } from '@angular/core';
import { CanDeactivate } from '@angular/router';
import { GlobalVariables } from '../../global-variables/global-variables';
import { CanDeactivateComponent } from './can-deactivate.component';

@Injectable()
export class CanDeactivateGuardService implements CanDeactivate<CanDeactivateComponent> {
    canDeactivate(component: CanDeactivateComponent): boolean {
        if (!component.canDeactivate() && !GlobalVariables.isAssetClassUpdated) {
            if (confirm(`You have unsaved changes!\nChanges that you made may not be saved.`)) {
                return true;
            } else {
                return false;
            }
        }
        return true;
    }
}
