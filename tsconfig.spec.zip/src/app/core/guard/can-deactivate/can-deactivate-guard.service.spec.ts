import { TestBed } from '@angular/core/testing';
import { CanDeactivateGuardService } from './can-deactivate-guard.service';

describe('Service: Can Deactivate Guard', () => {
    let canDeactivateGuardService: CanDeactivateGuardService;

    beforeEach(() => {
      TestBed.configureTestingModule({
        providers: [ CanDeactivateGuardService ]
      });
      canDeactivateGuardService = TestBed.inject(CanDeactivateGuardService);
    });

    afterEach(() => {
        canDeactivateGuardService = null;
    });

    function callback() {
        return true;
    }

    it('service should be created', () => {
      expect(canDeactivateGuardService).toBeTruthy();
      expect(canDeactivateGuardService).toBeDefined();
    });

    it('service should implement canDeactivate', () => {
        expect(canDeactivateGuardService.canDeactivate).toBeDefined();
    });
});
