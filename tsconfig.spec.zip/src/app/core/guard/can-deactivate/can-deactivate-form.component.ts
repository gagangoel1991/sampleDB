import { NgForm } from '@angular/forms';
import { CanDeactivateComponent } from './can-deactivate.component';

export abstract class CanDeactivateForm extends CanDeactivateComponent {
    abstract get confirmUnsavedForm(): NgForm;

    canDeactivate(): boolean {
        return this.confirmUnsavedForm.submitted || !this.confirmUnsavedForm.dirty;
    }
}
