import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AssetType } from '../models/asset-type.enum';

@Injectable()
export class CorporateGuardService implements CanActivate {
  constructor(public router: Router) {}
  canActivate() {
    if (window.localStorage.getItem('selectedAssetId') === AssetType.Corporate) {
      return true;
    } else {
      return this.router.createUrlTree(['/unauthorised']);
    }
  }
}
