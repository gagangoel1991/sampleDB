import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AssetType } from '../models/asset-type.enum';

@Injectable()
export class NWMGuardService implements CanActivate {
  constructor(public router: Router) {}
  canActivate() {
    if (window.localStorage.getItem('selectedAssetId') === AssetType.NatWestMarkets) {
      return true;
    } else {
      return this.router.createUrlTree(['/unauthorised']);
    }
  }
}
