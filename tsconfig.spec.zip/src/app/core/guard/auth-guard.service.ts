import { Injectable } from '@angular/core';
import { Router, CanActivate } from '@angular/router';
import { AssetType } from '../models/asset-type.enum';
import { AuthService } from './auth.service';

@Injectable()
export class AuthGuardService implements CanActivate {
  constructor(public auth: AuthService, public router: Router) {}
  async canActivate() {
    try {
      const result = await this.auth.checkApiHeartBeat();
      console.log(result);
      if (result) {
          console.log('API is running');
          let selectedAssetClass = window.localStorage.getItem('selectedAssetId');
          if (!selectedAssetClass) {
            selectedAssetClass = await this.auth.getDefaultAssetClass();
            window.localStorage.setItem('selectedAssetId', selectedAssetClass ? selectedAssetClass : AssetType.Retail);
            return true;
          } else {
            return true;
          }
      } else {
        return this.router.createUrlTree(['/servicedown']);
      }
    } catch (error) {
      return this.router.createUrlTree(['/servicedown']);
    }

  }
}
