import { Injectable } from '@angular/core';
import { CanActivate, Router } from '@angular/router';
import { AssetType } from '../models/asset-type.enum';

@Injectable()
export class HomeGuardService implements CanActivate {
  constructor(public router: Router) {}
  canActivate() {
    const selectedAssetId = window.localStorage.getItem('selectedAssetId');
    if (selectedAssetId === AssetType.Retail) {
      return this.router.createUrlTree(['/rt']);
    } else if (selectedAssetId === AssetType.Corporate) {
      return this.router.createUrlTree(['/cl']);
    } else if (selectedAssetId === AssetType.NatWestMarkets) {
      return this.router.createUrlTree(['/nwm']);
    }
  }
}
