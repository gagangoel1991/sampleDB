USE [SFP_Lombard]
GO

IF OBJECT_ID('lom.Manufacturer') IS NOT NULL
	DROP TABLE lom.Manufacturer
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE lom.Manufacturer
(
ManufacturerId INT IDENTITY(1,1) NOT NULL,
Code varchar(50),
Name varchar(512),
LombardSourceSystemId smallint,
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_Manufacturer] PRIMARY KEY CLUSTERED 
(
	[ManufacturerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO

ALTER TABLE lom.Manufacturer  WITH CHECK ADD CONSTRAINT [FK_MLombardSourceSystemId] FOREIGN KEY(LombardSourceSystemId)
REFERENCES lom.LombardSourceSystem (LombardSourceSystemId)



