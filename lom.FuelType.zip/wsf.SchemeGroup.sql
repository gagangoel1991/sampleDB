USE [SFP_Lombard]
GO

IF OBJECT_ID('wsf.SchemeGroup') IS NOT NULL
	DROP TABLE wsf.SchemeGroup
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE wsf.SchemeGroup
(
SchemeGroupId smallint IDENTITY(1,1) NOT NULL,
Code varchar(40),
Name varchar(256),
Description varchar(512),
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_SchemeGroup] PRIMARY KEY CLUSTERED 
(
	[SchemeGroupId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO
