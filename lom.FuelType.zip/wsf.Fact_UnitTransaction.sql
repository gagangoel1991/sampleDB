USE [SFP_Lombard]
GO

IF OBJECT_ID('wsf.Fact_UnitTransaction') IS NOT NULL
	DROP TABLE wsf.Fact_UnitTransaction
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE wsf.Fact_UnitTransaction
(
UnitTransactionKey INT IDENTITY(1,1) NOT NULL,
BusinessDate Date,
SourceTransactionId VARCHAR(40),
UnitKey INT,
DueDate DATETIME,
BankDate Decimal(38, 16),
TransactionTypeId TinyInt,
Amount Decimal(38, 16),
VATAmount Decimal(38, 16),
TransactionEntryTypeId INT,
PaymentMethodId INT,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_UnitTransactionKey] PRIMARY KEY CLUSTERED 
(
	[UnitTransactionKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO


ALTER TABLE wsf.Fact_UnitTransaction  WITH CHECK ADD CONSTRAINT [FK_FTUnitKey] FOREIGN KEY(UnitKey)
REFERENCES  lom.Dim_Unit  (UnitKey)

GO


ALTER TABLE wsf.Fact_UnitTransaction  WITH CHECK ADD CONSTRAINT [FK_TransactionTypeId] FOREIGN KEY(TransactionTypeId)
REFERENCES lom.TransactionType (TransactionTypeId)
GO

--ALTER TABLE wsf.Fact_UnitTransaction  WITH CHECK ADD CONSTRAINT [FK_TransactionEntryTypeId] FOREIGN KEY(TransactionEntryTypeId)
--REFERENCES cfg.LookupValue (LookupValueId)

--GO


--ALTER TABLE wsf.Fact_UnitTransaction  WITH CHECK ADD CONSTRAINT [FK_PaymentMethodId] FOREIGN KEY(PaymentMethodId)
--REFERENCES cfg.LookupValue (LookupValueId)

GO

