USE [SFP_Lombard]
GO

IF OBJECT_ID('wsf.Dim_UnitFinance') IS NOT NULL
	DROP TABLE wsf.Dim_UnitFinance
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE wsf.Dim_UnitFinance
(
UnitFinanceKey INT,
UnitKey INT,
PurchasePrice Decimal(38, 16),
PurhcaseVat Decimal(38, 16),
FundingAmount Decimal(38, 16),
VATClassificationTypeId INT,
OriginalCapitalValuation Decimal(38, 16),
ValidFrom Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_UnitFinanceKey] PRIMARY KEY CLUSTERED 
(
	[UnitFinanceKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]



--ALTER TABLE wsf.Dim_UnitFinance  WITH CHECK ADD CONSTRAINT [FK_UnitSchemeKey] FOREIGN KEY(UnitKey)
--REFERENCES wsf.Dim_UnitScheme(UnitSchemeKey)
--GO


ALTER TABLE wsf.Dim_UnitFinance  WITH CHECK ADD CONSTRAINT [FK_UnitKey] FOREIGN KEY(UnitKey)
REFERENCES lom.Dim_Unit(UnitKey)

GO


--VATClassificationTypeId Foreign Key


GO