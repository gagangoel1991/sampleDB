USE [SFP_Lombard]
GO

IF OBJECT_ID('lom.LombardSourceSystem') IS NOT NULL
	DROP TABLE lom.LombardSourceSystem
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE lom.LombardSourceSystem
(
LombardSourceSystemId smallint identity(1,1) ,
Code Varchar(40),
Name varchar(256),
Description varchar(512),
CreatedDate Datetime,
CreatedBy Varchar(80),
CONSTRAINT [PK_LombardSourceSystem] PRIMARY KEY CLUSTERED 
(
	[LombardSourceSystemId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO



