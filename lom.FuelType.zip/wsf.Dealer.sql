USE [SFP_Lombard]
GO

IF OBJECT_ID('wsf.Dealer') IS NOT NULL
	DROP TABLE wsf.Dealer
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE wsf.Dealer
(
DealerId INT IDENTITY(1,1) NOT NULL,
Code varchar(50),
Name varchar(512),
TradingAs varchar(512),
GroupDealerId int,
ValidFrom Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_Dealer] PRIMARY KEY CLUSTERED 
(
	[DealerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO
