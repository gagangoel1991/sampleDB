USE [SFP_Lombard]
GO

IF OBJECT_ID('lom.UnitMarque') IS NOT NULL
	DROP TABLE lom.UnitMarque
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE lom.UnitMarque
(
UnitMarqueId Smallint IDENTITY(1,1) NOT NULL,
Code varchar(40),
Name Varchar(128),
Description Varchar(512),
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_UnitMarque] PRIMARY KEY CLUSTERED 
(
	[UnitMarqueId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO
