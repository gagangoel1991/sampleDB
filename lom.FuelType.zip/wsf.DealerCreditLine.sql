USE [SFP_Lombard]
GO

IF OBJECT_ID('wsf.DealerCreditLine') IS NOT NULL
	DROP TABLE wsf.DealerCreditLine
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE wsf.DealerCreditLine
(
DealerCreditLineId INT IDENTITY(1,1) NOT NULL,
DealerId INT,
ManufacturerId INT,
CreditLineTypeId int,
CreditLineStatusId int,
CreditLimit Decimal(36, 18),
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_DealerCreditLine] PRIMARY KEY CLUSTERED 
(
	[DealerCreditLineId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO


ALTER TABLE wsf.DealerCreditLine  WITH CHECK ADD CONSTRAINT [FK_DealerId] FOREIGN KEY(DealerId)
REFERENCES wsf.Dealer (DealerId)

GO

ALTER TABLE wsf.DealerCreditLine  WITH CHECK ADD CONSTRAINT [FK_ManufacturerId] FOREIGN KEY(ManufacturerId)
REFERENCES lom.Manufacturer(ManufacturerId)

GO


--ALTER TABLE wsf.DealerCreditLine  WITH CHECK ADD CONSTRAINT [FK_CreditTypeLookupValueId] FOREIGN KEY(CreditLineTypeId)
--REFERENCES cfg.LookupValue (LookupValueId)

--GO


--ALTER TABLE wsf.DealerCreditLine  WITH CHECK ADD CONSTRAINT [FK_CreditStatusLookupValueId] FOREIGN KEY(CreditLineStatusId)
--REFERENCES cfg.LookupValue (LookupValueId)

GO
