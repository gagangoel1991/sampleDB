USE [SFP_Lombard]
GO

IF OBJECT_ID('lom.AssetSubClassType') IS NOT NULL
	DROP TABLE lom.AssetSubClassType
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE lom.AssetSubClassType
(
AssetSubClassTypeId smallint IDENTITY(1,1) NOT NULL,
Code varchar(40),
Name varchar(256),
Description varchar(512),
AssetClassId [int],
ParentAssetSubClassTypeId smallint,
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_AssetSubClassType] PRIMARY KEY CLUSTERED 
(
	[AssetSubClassTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]

GO


ALTER TABLE lom.AssetSubClassType  WITH CHECK ADD CONSTRAINT [FK_AssetClassId] FOREIGN KEY(AssetClassId)
REFERENCES lom.AssetClass (AssetClassId)

GO
