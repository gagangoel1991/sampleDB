USE [SFP_Lombard]
GO

IF OBJECT_ID('wsf.Scheme') IS NOT NULL
	DROP TABLE wsf.Scheme
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE wsf.Scheme
(
SchemeId int IDENTITY(1,1) NOT NULL,
Code varchar(40),
SchemeNumber INT,
Name varchar(256),
AssetType varchar(256),
SchemeGroupId smallint,
Description varchar(512),
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_Scheme] PRIMARY KEY CLUSTERED 
(
	[SchemeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO



ALTER TABLE wsf.Scheme  WITH CHECK ADD CONSTRAINT [FK_SchemeGroupId] FOREIGN KEY(SchemeGroupId)
REFERENCES wsf.SchemeGroup (SchemeGroupId)

GO
