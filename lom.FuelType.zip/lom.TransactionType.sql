USE [SFP_Lombard]
GO

IF OBJECT_ID('lom.TransactionType') IS NOT NULL
	DROP TABLE lom.TransactionType
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE lom.TransactionType
(
TransactionTypeId TinyInt IDENTITY(1,1) NOT NULL,
Code Varchar(40),
Name Varchar(128),
Description Varchar(512),
ValidFrom  Datetime,
ValidTo Datetime,
CreatedBy Varchar(128),
CreatedDate Datetime,
CONSTRAINT [PK_TransactionType] PRIMARY KEY CLUSTERED 
(
	[TransactionTypeId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO
