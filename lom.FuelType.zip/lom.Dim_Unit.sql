USE [SFP_Lombard]
GO

IF OBJECT_ID('lom.Dim_Unit') IS NOT NULL
	DROP TABLE lom.Dim_Unit
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE lom.Dim_Unit
(
UnitKey INT IDENTITY(1,1) NOT NULL,
LombardSourceSystemId smallint,
SourceUnitId Varchar(40),
Description varchar(512),
Vin VARCHAR(128),
CrisNo VARCHAR(128),
SerialNo VARCHAR(40),
ConsignmentNo VARCHAR(40),
RegistrationNumber VARCHAR(40),
RegistrationDate Datetime,
UnitMarqueId Smallint,
UnitTypeId INT,
ManufacturerSchemeMapId INT,
InvoiceNo VARCHAR(40),
OrderNo VARCHAR(40),
AcceptanceDate Datetime,
ExpiryDate Datetime,
Mileage Decimal(38, 16),
CapCode VARCHAR(128),
HPIReference Decimal(38, 16),
FuelTypeId TinyInt,
Co2Emission int,
ValidFrom Datetime,
ValidTo Datetime,
CONSTRAINT [PK_UnitKey] PRIMARY KEY CLUSTERED 
(
	[UnitKey] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON) ON [PRIMARY]
) ON [PRIMARY]


GO


ALTER TABLE lom.Dim_Unit  WITH CHECK ADD CONSTRAINT [FK_LombardSourceSystemId] FOREIGN KEY(LombardSourceSystemId)
REFERENCES lom.LombardSourceSystem (LombardSourceSystemId)
GO

GO


--ALTER TABLE lom.Dim_Unit  WITH CHECK ADD CONSTRAINT [FK_UnitTypeId] FOREIGN KEY(UnitTypeId)
--REFERENCES cfg.LookupValue (LookupValueId)

--GO


--ALTER TABLE lom.Dim_Unit  WITH CHECK ADD CONSTRAINT [FK_VATClassificationTypeId] FOREIGN KEY(VATClassificationTypeId)
--REFERENCES cfg.LookupValue (LookupValueId)

--GO



ALTER TABLE lom.Dim_Unit  WITH CHECK ADD CONSTRAINT [FK_DUUnitMarqueId] FOREIGN KEY(UnitMarqueId)
REFERENCES lom.UnitMarque (UnitMarqueId)

GO


ALTER TABLE lom.Dim_Unit  WITH CHECK ADD CONSTRAINT [FK_DUFuelTypeId] FOREIGN KEY(FuelTypeId)
REFERENCES lom.FuelType (FuelTypeId)

GO


ALTER TABLE lom.Dim_Unit  WITH CHECK ADD CONSTRAINT [FK_ManufacturerSchemeMapId] FOREIGN KEY(ManufacturerSchemeMapId)
REFERENCES wsf.ManufacturerSchemeMap(ManufacturerSchemeMapId)

GO
