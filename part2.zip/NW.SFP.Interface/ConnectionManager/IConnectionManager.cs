﻿using NW.SFP.Message.ConnectionManager;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace NW.SFP.Interface.ConnectionManager
{
    public interface IConnectionManager : IDisposable
    {
        SQLSource ConnectionSource { get; set; }
        CommandType CommandType { get; set; }
        string CommandText { get; set; }
        int CommandTimeOut { get; set; }
        List<SqlParameter> ParameterListOutput { get; set; }
        List<SqlParameter> GetOutputParameterList();
        List<SqlParameter> ParameterListInput { get; set; }
        DataSet ExecuteDataSet();
        void ExecuteNonQuery();
    }
}
