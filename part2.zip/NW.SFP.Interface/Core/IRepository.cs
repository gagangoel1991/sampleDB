﻿namespace NW.SFP.Interface.Core
{

    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public interface IRepository<TEntity>
           where TEntity : new()
    {
        IEnumerable<TEntity> Execute(IDbCommand command);

        TEntity ExecuteToEntity(IDbCommand command);

        TEntity Map<TEntity>(IDataRecord record);

        int ExecuteNonQuery(IDbCommand command);
    }
}
