﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.Core
{
    public interface ILoggerService
    {
        /// <summary>
        /// For logging the info in the database/Txt file
        /// </summary>
        /// <param name="logInfo"></param>
        void LogInfo(LogInfoEntity logInfo);

        /// <summary>
        /// For logging the error 
        /// </summary>
        /// <param name="logError"></param>
        void LogError(LogErrorEntity logError);
    }
}
