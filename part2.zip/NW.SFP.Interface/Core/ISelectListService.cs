﻿namespace NW.SFP.Interface.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.Core;

    public interface ISelectLookupService
    {
        IEnumerable<SelectLookupEntity> GetParametrizedSelectList(DataTable ListId, string AssetClassId = "1");

        IEnumerable<SelectLookupEntity> GetParametrizedSelectListFilterBased(DataTable ListId, DataTable FilterId);
    }
}
