﻿using NW.SFP.Message.Common;

namespace NW.SFP.Interface.Core
{
    public interface IAuthWorkflowController
    {
        int ManageAuthWorkflow(AuthWorkflowEntity authWorkflowEntity);

        AuthWorkflowEntity GetAuthWorkflowStatus(AuthWorkflowEntity authWorkflowEntity);

        int ManageAuthWorkflowByUser(AuthWorkflowEntity authWorkflowEntity);
    }
}
