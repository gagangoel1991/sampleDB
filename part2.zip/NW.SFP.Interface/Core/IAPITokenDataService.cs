﻿using NW.SFP.Message.Core;
using NW.SFP.Message.Core.Token;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.Core
{
    public interface IAPITokenDataService
    {
        public APITokenUpdateOutputEntity UpdateAPIToken(APITokenEntity objAPITokenEntity);
        public Guid? GetAPITokenbyKey(APITokenEntity objAPITokenEntity);
    }
}
