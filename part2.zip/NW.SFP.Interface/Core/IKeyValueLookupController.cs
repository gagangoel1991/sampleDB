﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.Core
{
    public interface IKeyValueLookupController
    {
        /// <summary>
        /// This will return the key value lookup data based of type
        /// </summary>
        /// <param name="lookupTypeIds"></param>
        IList<KeyValueLookupEntity> GetKeyValueLookupData(string lookupTypeIds);
    }
}
