﻿using NW.SFP.Message.core;
using System.Collections.Generic;

namespace NW.SFP.Interface.Core
{
    public interface IDateListController
    {
        IList<HolidayDate> GetHolidayList();
    }
}
