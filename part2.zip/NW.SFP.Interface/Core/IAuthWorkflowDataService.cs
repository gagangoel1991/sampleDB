﻿using NW.SFP.Message.Common;

namespace NW.SFP.Interface.Core
{
    public interface IAuthWorkflowDataService
    {
        int ManageAuthWorkflow(AuthWorkflowEntity authWorkflowEntity);

        AuthWorkflowEntity GetAuthWorkflowStatus(AuthWorkflowEntity authWorkflowEntity);

        AuthAuditEntity GetEntityAuditDetails(AuthWorkflowEntity authWorkflowEntity);
    }
}
