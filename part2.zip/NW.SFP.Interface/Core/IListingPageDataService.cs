﻿using NW.SFP.Message.core;

namespace NW.SFP.Interface.Core
{
    public interface IListingPageDataService
    {
        ListingPreference GetUserListingPreference(string listingPageName, string userName);
        int SaveUserListingPreference(ListingPreference listingPreference, string userName);
    }
}
