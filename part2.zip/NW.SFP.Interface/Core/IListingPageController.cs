﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.core;

namespace NW.SFP.Interface.Core
{
    public interface IListingPageController
    {
        ActionResult<ListingPreference> GetUserListingPreference(string listingPageName);
        ActionResult<int> SaveUserListingPreference(ListingPreference listingPreference);
    }
}
