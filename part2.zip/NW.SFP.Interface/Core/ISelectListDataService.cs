﻿namespace NW.SFP.Interface.Core
{
    using System.Collections.Generic;
    using System.Data;
    using NW.SFP.Message.Core;

    public interface ISelectLookupDataService
    {
        IEnumerable<SelectLookupEntity> GetParametrizedSelectList(DataTable ListId, string AssetClassId = "1");

        IEnumerable<SelectLookupEntity> GetParametrizedSelectListFilterBased(DataTable ListId, DataTable FilterId);
    }
}
