﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IFieldManagementDataService
    {
        #region IFieldManagementDataService Interface Members        
        public IDictionary<string, FieldManagement.FieldInfo>GetFieldsData(int assetId, string fieldType);
        public IList<FieldManagement.FieldDataType> GetFieldsDataType();
        public IList<BasicLookUpData> GetArithmeticOperators();
        public IList<FieldFunction> GetFunctions(string loggedInUserName);
        public FieldFunction GetFunctionDetail(int functionId, string loggedInUserName);
        public string SaveCustomField(FieldManagement.CustomFieldAttribute customFieldDetail, string userName);
        public int AmendCustomField(FieldManagement.CustomFieldAttribute customFieldAttribute, string userName);
        public FieldManagement.CustomFieldDetail GetCustomFieldDetail(int fieldId);
        IList<Field> GetFields(int assetId, string loggedInUserName);
        int DeleteField(int fieldId, string loggedInUserName);
        public IList<EligibilityCriteriaAttributes> GetECByField(int fieldId, string loggedInUserName);
        public int UpdateECsOnFieldChange(FieldRename fieldNameChangeModel, string loggedInUserName);
        #endregion
    }
}
