﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IConcentrationDataService
    {
        public string SaveConcentration(ConcentrationTest concentrationTest, string userName);
        public int AmendConcentration(ConcentrationTest concentrationTest, string userName);
        public IList<ConcentrationTestList> GetConcentrationTestList(int assetClassId, string userName);
        public int DeleteConcentrationTest(int concTestId, string userName);
        public ConcentrationTest GetConcentrationTestByID(int concentrationTestId);
    }
}
