﻿using System;
using System.Collections.Generic;
using NW.SFP.Message.PS;

namespace NW.SFP.Interface.PS
{
    public interface IReplinesReportDataService
    {
        ReplinseReportData GetReplinesReportData(DateTime inceptionDate, int dealKey, string userName);
    }
}
