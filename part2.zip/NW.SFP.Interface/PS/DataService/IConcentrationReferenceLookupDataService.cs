﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IConcentrationReferenceLookupDataService
    {
        ConcentrationReferenceData GetConcentrationReferenceData(int assetClassId, string userName);
        List<BasicLookUpData> GetConcentrationFieldsData(string type,  int assetClassId, string userName);
        ConcentrationFieldReferenceData GetConcentrationFieldReferenceData(int fieldId, string userName);
    }
}
