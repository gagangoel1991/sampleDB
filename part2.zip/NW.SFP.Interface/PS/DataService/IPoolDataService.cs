﻿using System;
using System.Collections.Generic;
using System.IO;
using ClosedXML.Excel;
using NW.SFP.Message.PS;

namespace NW.SFP.Interface.PS
{
    public interface IPoolDataService
    {
        IList<PoolList> GetPools(int assetId, string userName);
        int DeletePool(int poolId, string userName);
        Pool GetPoolById(int poolId, string userName);
        IList<PoolSourceDealSummary> GetPoolSourceDealSummaryById(int poolId, string userName);
        int CreatePool(Pool pool, string userName);
        int UpdatePool(Pool pool, string userName);
        IList<Pool> BuildPool(int poolId, string loggedInUserName, int assetId);
        IList<ExportAdvanceSourceData> ExportAdvanceSourceData(int poolId, string loggedInUserName, int reportTypeId);
        IList<ExportAdvanceSourceData> GeneratePoolExtractReportCB(int poolId, string loggedInUserName, int reportTypeId);
        IList<long> ValidateUploadAsset(IList<long> assets, string vintageDate, string loggedInUserName, int AssetClassId);
        MemoryStream GenerateDrillThroughReport(int poolId, string loggedInUserName);
        MemoryStream GenerateDetailedReport(int poolId, string loggedInUserName);
        MemoryStream GenerateECSummaryReportCB(int poolId, string loggedInUserName, bool isStandAlone = true, XLWorkbook workbook = null, MemoryStream stream = null);
        MemoryStream GenerateIneligibilityDetailedReportCB(int poolId, string loggedInUserName);
        MemoryStream GenerateEligibilityDetailedReportCB(int poolId, string loggedInUserName);
        int ValidateDrillThroughReport(int poolId, string loggedInUserName);
        int ValidateDrillThroughReportCB(int poolId, string loggedInUserName);
        int ValidateEligibilityReportCB(int poolId, string loggedInUserName);
        IList<BrandList> GetBrandList();
        int ValidateSubmitAndUpdatePool(SubmittedPoolData submittedPoolData, string loggedInUserName);
        int UpdatePoolAuthorisationStatus(int poolId, bool isRejected, string comments, string userName, System.DateTime ModifiedDate);
        IList<int> GetDependentPools(int poolId, string userName);
        PoolValidationSummary ValidateSubmittedLoans(int poolId, string userName);
        PoolExclusionChangeImpact ValidateExclusionChangeImpact(int poolId, string userName);
        IList<string> GetPoolRegionWithHoliday(int poolId, string effectiveDate, string userName); 
        PoolEcAndCtReportData GetPoolEcAndCtReportData(int poolId, string userName);
        PoolEcAndCtReportDataCB GetPoolEcAndCtReportDataCB(int poolId, string userName);
        string GetPoolSourceDealsById(int poolId, string userName);
        public IList<PoolAccount> GetPoolDetailsById(int poolId, string dealId, string vintageDate, string userName);
        public int UpdatePoolAccounts(IList<PoolAccount> accounts, int poolId, string userName);
        public IList<LoanInclusionReason> GetPoolInclusionReasons();
        string GetPoolLastFlagDateById(int poolId, string userName);
    }
}
