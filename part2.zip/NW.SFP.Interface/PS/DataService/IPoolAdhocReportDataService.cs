﻿using NW.SFP.Message.PS;
using System.Collections.Generic;
using System.IO;

namespace NW.SFP.Interface.PS.DataService
{
    public interface IPoolAdhocReportDataService
    {
        IList<PoolAdhocReportTemplateList> GetAdhocReports(string loggedInUserName, int assetClassId);
        IList<AdhocReportField> GetFieldsForReports(string loggedInUserName, int assetClassId);
        ReportTemplateData GetReportTemplateData(int reportTemplateId, string loggedInUserName);
        IDictionary<int, List<AdhocReportOperator>> GetDatatypeAggregationMap(string loggedInUserName);
        int SaveReportTemplateData(ReportTemplateData reportTemplateData, string loggedInUserName);
        int DeleteReportTemplateData(int reportTemplateId, string loggedInUserName);
        AdhocReportRefData GetReportRefData(string loggedInUserName, int assetClassId);
        MemoryStream GenerateReportData(int reportTemplateId, int poolId, string loggedInUserName, ReportTemplateData reportTemplateData, bool isCsv);        
        IList<AdhocReportTypeEntity> GetAdhocReportTypeList(string LoggedInUserName);
    }
}
