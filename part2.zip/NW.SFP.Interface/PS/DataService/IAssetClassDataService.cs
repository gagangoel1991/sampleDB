﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IAssetClassDataService
    {
        #region IAssetClassDataService Interface Members
        public IList<AssetClass> GetAssetClass();
        #endregion
    }
}
