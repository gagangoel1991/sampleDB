﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IEligibilityDataService
    {
        #region IEligibilityDataService Interface Members
        public IDictionary<string, EligibilityCriteria.Field> GetEligibilityFields(int assetId);
        public IList<EligibilityCriteria.ECRegulation> GetEligibilityRegulation();
        public IList<EligibilityCriteria.ECType> GetEligibilityType(int assetId);
        public IList<EligibilityCriteria.FieldInfo> GetEligibilityFieldInfo(int fieldId);
        public string SaveEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes, string userName);
        public int AmendEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes, string userName);
        public IList<EligibilityCriteriaDetail> GetEligibilityCriteria(int eligibilityId, int assetId);
        public IList<QueryExpressionDetail> GetEligibilityCriteriaExpression(int eligibilityId);
        public IList<EligibilityCriteriaList> GetEligibilityCriterias(int assetId, string userName);
        public int DeleteEligibility(int ecId, string userName);
        public bool ValidateEcFields(int eligibilityId);
        public IList<EligibilityCriteriaPoolsList> GetEcPoolsReportData(int EcID, string userName);
        #endregion
    }
}
