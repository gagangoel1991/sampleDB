﻿using System.Collections.Generic;
using NW.SFP.Message.PS;
using Microsoft.AspNetCore.Mvc;

namespace NW.SFP.Interface.PS
{
    public interface IPoolController
    {
        ActionResult<IList<PoolList>> GetPools(int assetId);
        ActionResult<int> DeletePool(int poolId);
        ActionResult<Pool> GetPoolById(int poolId);
        ActionResult<IList<PoolSourceDealSummary>> GetPoolSourceDealSummaryById(int poolId);
        ActionResult<int> CreatePool(Pool pool);
        ActionResult<int> UpdatePool(Pool pool);
        ActionResult<IList<BrandList>> GetBrandList();
        ActionResult<int> UpdatePoolAuthorisationStatus(int poolId, bool isRejected, string comments, System.DateTime ModifiedDate);
        ActionResult<IList<int>> GetDependentPools(int poolId);
        ActionResult<PoolValidationSummary> ValidateSubmittedLoans(int poolId, bool isQueueRequired);
        ActionResult<PoolExclusionChangeImpact> ValidateExclusionChangeImpact(int poolId);
        public ActionResult<IList<string>> GetPoolRegionWithHoliday(int poolId, string effectiveDate);
        ActionResult<bool> IsCurrentPoolInSubmissionQueue(int poolId);
    }
}