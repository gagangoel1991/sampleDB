﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IAssetClassController
    {
        #region IAssetController Interface Members
        public ActionResult<IList<AssetClass>> GetAssetClass();
        #endregion
    }
}
