﻿using System.Collections.Generic;
using NW.SFP.Message.PS;
using Microsoft.AspNetCore.Mvc;
using System;

namespace NW.SFP.Interface.PS
{
    public interface IDashboardPoolSelectionController
    {
        ActionResult<IList<DashboardSummary>> GetDashboardSummary(int assetClassId = 1);
        ActionResult<IList<DashboardSummary>> GetPreviousWork(DateTime fromDate, DateTime toDate, int assetClassId = 1);
        ActionResult<DealFlagDeFlagData> GetDashBoardDealsData(string analysisDate, bool IsInitial, int assetClassId = 1);
        ActionResult<IList<DashBoardPoolData>> GetDashBoardCompletedPoolData(string fromDate, string toDate, int assetClassId = 1);
        ActionResult<IList<DashBoardFailedPoolData>> GetFailedPoolData(string analysisDate, int assetClassId = 1);
    }
}