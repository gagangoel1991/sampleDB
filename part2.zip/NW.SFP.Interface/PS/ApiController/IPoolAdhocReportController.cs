﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS.ApiController
{
    public interface IPoolAdhocReportController
    {
        public ActionResult<IList<PoolAdhocReportTemplateList>> GetAdhocReports(int assetClassId);
    }
}
