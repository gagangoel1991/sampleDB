﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IReplinesReportController
    {
        #region IEligibilityController Interface Members
        ActionResult GetReplinesReportData(string inceptionDate, int dealKey);
        #endregion
    }
}
