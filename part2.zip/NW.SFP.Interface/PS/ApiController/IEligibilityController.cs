﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IEligibilityController
    {
        #region IEligibilityController Interface Members
        public IDictionary<string, EligibilityCriteria.Field> GetEligibilityFields(int assetId);
        public ActionResult<IList<EligibilityCriteria.ECRegulation>> GetEligibilityRegulation();
        public ActionResult<IList<EligibilityCriteria.ECType>> GetEligibilityType(int assetId);
        public IList<EligibilityCriteria.FieldInfo> GetEligibilityFieldInfo(int fieldId);
        public ActionResult<string> SaveEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes);
        public ActionResult<int> AmendEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes);
        public ActionResult<IList<EligibilityCriteriaDetail>> GetEligibilityCriteria(int eligibilityId, int assetId);
        public ActionResult<IList<QueryExpressionDetail>> GetEligibilityCriteriaExpression(int eligibilityId);
        public ActionResult<IList<EligibilityCriteriaList>> GetEligibilityCriterias(int assetId);
        public ActionResult<int> DeleteEligibility(int? ecId);
        public ActionResult<bool> ValidateEcFields(int eligibilityId);

        #endregion
    }
}
