﻿using NW.SFP.Message.PS;
using Microsoft.AspNetCore.Mvc;

namespace NW.SFP.Interface.PS
{
    public interface IPoolReferenceLookupController
    {
        ActionResult<PoolReferenceData> GetPoolReferenceData(int assetId);
    }
}