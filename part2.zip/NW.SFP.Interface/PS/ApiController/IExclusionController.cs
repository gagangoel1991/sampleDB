﻿using NW.SFP.Message.PS;
using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;

namespace NW.SFP.Interface.PS
{
    public interface IExclusionController
    {
        ActionResult<Exclusion> GetExclusionById(int exclusionId);
        ActionResult<int> CreateExclusion(Exclusion exclusion);
        ActionResult<IList<ExclusionValidationResult>> ValidateExclusion(Exclusion exclusion);
        public ActionResult<ExclusionData> GetExclusionManagementData();
    }
}
