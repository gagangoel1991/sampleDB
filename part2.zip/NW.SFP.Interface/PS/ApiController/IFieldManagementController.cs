﻿using DocumentFormat.OpenXml.Drawing;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IFieldManagementController
    {
        #region IFieldManagementController Interface Members
        public IDictionary<string, FieldManagement.FieldInfo> GetFieldsData(int assetId, string fieldType);
        public ActionResult<IList<FieldManagement.FieldDataType>> GetFieldsDataType();
        public ActionResult<IList<BasicLookUpData>> GetArithmeticOperators();
        public ActionResult<IList<FieldFunction>> GetFunctions();
        public ActionResult<FieldFunction> GetFunctionDetail(int functionId);
        public ActionResult<string> SaveCustomField(FieldManagement.CustomFieldAttribute customFieldDetail);
        public ActionResult<int> AmendCustomField(FieldManagement.CustomFieldAttribute customFieldAttribute);
        public ActionResult<FieldManagement.CustomFieldDetail> GetCustomFieldDetail(int fieldId);
        public ActionResult<IList<EligibilityCriteriaAttributes>> GetECByField(int fieldId);
        public ActionResult<int> UpdateECsOnFieldChange(FieldRename fieldNameChangeModel);
        #endregion
    }
}
