﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IConcentrationController
    {
        public ActionResult<string> SaveConcentration(ConcentrationTest concentrationTest);
        public ActionResult<int> AmendConcentration(ConcentrationTest concentrationTest);
        public ActionResult<IList<ConcentrationTestList>> GetConcentrationTestList(int assetClassId);
        public ActionResult<int> DeleteConcentrationTest(int? ctId);
        public ActionResult<ConcentrationTest> GetConcentrationTestbyId(int? concentrationTestId);
    }
}
