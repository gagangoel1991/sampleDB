﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IConcentrationlReferenceLookupController
    {
        ActionResult<ConcentrationReferenceData> GetConcentrationReferenceData(int assetClassId);
        ActionResult<List<BasicLookUpData>> GetConcentrationFieldsData(string type, int assetClassId);         
    }
}