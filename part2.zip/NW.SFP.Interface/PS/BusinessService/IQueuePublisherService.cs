﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IQueuePublisherService
    {
        public object DeQueue(string processName);
    }
}
