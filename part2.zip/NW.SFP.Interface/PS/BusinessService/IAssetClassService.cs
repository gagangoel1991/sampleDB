﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IAssetClassService
    {
        #region IAssetController Interface Members
        public IList<AssetClass> GetAssetClass();
        #endregion IAssetController Interface Members
    }
}
