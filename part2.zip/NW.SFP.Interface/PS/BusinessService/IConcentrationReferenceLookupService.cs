﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IConcentrationReferenceLookupService
    {
        public ConcentrationReferenceData GetConcentrationReferenceData(int assetClassId, string userName);
        public List<BasicLookUpData> GetConcentrationFieldsData(string type, int assetClassId, string userName);
        public ConcentrationFieldReferenceData GetConcentrationFieldReferenceData(int fieldId, string userName);        
    }
}
