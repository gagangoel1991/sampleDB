﻿using System;
using System.Collections.Generic;
using System.IO;
using NW.SFP.Message.PS;

namespace NW.SFP.Interface.PS
{
    public interface IReplinesReportService
    {
        MemoryStream GetReplinesReportData(DateTime inceptionDate, int dealKey, string userName);
    }
}
