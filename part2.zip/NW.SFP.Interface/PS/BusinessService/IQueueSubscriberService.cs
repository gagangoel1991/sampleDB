﻿using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IQueueSubscriberService
    {
        PoolValidationSummary SendPoolSubmissionToQueue(int poolId, string userName);
        void SetQueueProcessItemStatus(string processName,bool Status);
        int GetCurrentPoolId();
        bool IsCurrentPoolInSubmissionQueue(int PoolId);
    }
}
