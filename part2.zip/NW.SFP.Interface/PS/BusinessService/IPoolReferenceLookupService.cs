﻿using NW.SFP.Message.PS;

namespace NW.SFP.Interface.PS
{
    public interface IPoolReferenceLookupService
    {
        PoolReferenceData GetPoolReferenceData(string userName, int assetId);
    }
}