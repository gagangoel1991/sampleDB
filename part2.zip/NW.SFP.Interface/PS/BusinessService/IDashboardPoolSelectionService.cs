﻿using System.Collections.Generic;
using NW.SFP.Message.PS;
using System;

namespace NW.SFP.Interface.PS
{
    public interface IDashboardPoolSelectionService
    {
        IList<DashboardSummary> GetDashboardSummary(string userName, int assetClassId);
        IList<DashboardSummary> GetPreviousWork(DateTime fromDate, DateTime toDate, string userName, int assetClassId);
        IList<DashBoardPoolData> GetDashBoardCompletedPoolData(DateTime fromDate, DateTime toDate, string userName, int assetClassId);
        DealFlagDeFlagData GetDashBoardDealsData(DateTime analysisDate, string userName, bool IsInitial, int assetClassId);
        IList<DashBoardFailedPoolData> GetFailedPoolData(DateTime analysisDate, string userName, int assetClassId);
    }
}
