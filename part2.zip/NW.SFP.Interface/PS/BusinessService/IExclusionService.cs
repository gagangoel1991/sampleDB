﻿using System.Collections.Generic;
using NW.SFP.Message.PS;

namespace NW.SFP.Interface.PS
{
    public interface IExclusionService
    {
        Exclusion GetExclusionByID(int exclusionId, string userName);
        int CreateExclusion(Exclusion exclusion, string userName);
        IList<ExclusionValidationResult> ValidateExclusion(Exclusion exclusion, string userName);
        public ExclusionData GetExclusionManagementData(string userName);
    }
}
