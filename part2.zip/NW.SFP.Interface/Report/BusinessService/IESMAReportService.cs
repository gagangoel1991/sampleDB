﻿using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NW.SFP.Interface.Report
{
   public interface IESMAReportService
    {
        MemoryStream GetESMA4Data(string dealName, DateTime ipdDate, string userName, int poolId, string poolName);
        MemoryStream GetFCAAnnex4Data(string dealName, DateTime ipdDate, string userName, int poolId, string poolName);
        MemoryStream GetESMA9ata(string dealName, DateTime ipdDate, string userName, int poolId, string poolName);
        MemoryStream GetFCAAnnex9Data(string dealName, DateTime asAtDate, string userName, int poolId, string poolName);
    }
}
