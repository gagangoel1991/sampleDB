﻿using ClosedXML.Excel;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW.IR;
using NW.SFP.Message.PS;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NW.SFP.Interface.Report
{
    public interface IReferenceRegistryReportService
    {
        MemoryStream GenerateReferenceRegistryReportData(int dealIrConfigId, string AsAtDate, string loggedInUserName, bool replaceFormula = false, int poolId =0, string ReportOutputType = "");
        MemoryStream DownloadFinalReferenceRegistryReport(int dealId, string AsAtDate, string loggedInUserName, int poolId = 0, string ReportOutputType = "");
        int ManageRRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity);        
        
        int SaveDealRrrConfig(DealIrConfigAddEditEntity dealIrConfigData, string loggedInUserName, string ReportTypeName);

        DealIrConfigEntity GetRefRegData(int DealIrConfigId, string UserName, int AssetClassID);

        int checkReferenceRegistryTemplateAvailable(int dealId, string AsAtDate, string loggedInUserName);
        IList<RRReportField> GetFieldsForReports(string loggedInUserName, int assetClassId);
    }
}