﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NW.SFP.Interface.Report.BusinessService
{
   public interface INWMReportsService
    {
       
        public MemoryStream GenerateAssetReportData(DateTime AsAtDate, string userName);
        public MemoryStream GenerateLoansOutstandingReportData(DateTime AsAtDate, string userName);
    }

}
