﻿using NW.SFP.Message.Report;
using NW.SFP.Message.SFP.Model;
using System.Collections.Generic;


namespace NW.SFP.Interface.Report.BusinessService
{
    public interface IReportService
    {
        ReportConfigs GetReportConfig(string loggedInUserName);
        IList<HypoPool> GetHypoPools(string loggedInUserName,int assetClassId,int poolStatusId);
        Message.Report.Report GetReports(string loggedInUserName, int id);
        SfpBatchDataDto SetReportForQueue(string loggedInUserName, Message.Report.Report report);
        IList<ReportQueue> GetReportQueue(string loggedInUserName);
    }
}
