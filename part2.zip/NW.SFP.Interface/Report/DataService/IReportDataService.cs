﻿using NW.SFP.Message.Report;
using NW.SFP.Message.SFP.Model;
using System.Collections.Generic;

namespace NW.SFP.Interface.Report.DataService
{
    public interface IReportDataService
    {
        ReportConfigs GetReportConfig(string loggedInUserName);
        IList<HypoPool> GetHypoPools(string loggedInUserName, int assetClassId, int poolStatusId);
        Message.Report.Report GetReports(string loggedInUserName, int id);
        SfpBatchDataModel SetReportForQueue(string loggedInUserName, Message.Report.Report report);
        IList<ReportQueue> GetReportQueue(string loggedInUserName);
    }
}
