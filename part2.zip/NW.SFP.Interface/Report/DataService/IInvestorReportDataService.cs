﻿using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.Report
{
    public interface IInvestorReportDataService
    {
        InvestorReportResultEntity GetInvestorReportFileName(int dealId, string ipdDate, string formatType);

        InvestorReportResultEntity Save(InvestorReportResultEntity reportEntity, string UserName);
    }
}
