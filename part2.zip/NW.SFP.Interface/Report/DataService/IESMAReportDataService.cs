﻿using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.Report
{
    public interface IESMAReportDataService
    {
        ESMA4 GetESMA4Data(string dealName, DateTime ipdDate, string userName, int poolId);
        ESMA4 GetFCAAnnex4Data(string dealName, DateTime ipdDate, string userName, int poolId);
        ESMA9 GetESMA9Data(string dealName, DateTime ipdDate, string userName, int poolId);
        ESMA9 GetFCAAnnex9Data(string dealName, DateTime ipdDate, string userName, int poolId);
    }
}
