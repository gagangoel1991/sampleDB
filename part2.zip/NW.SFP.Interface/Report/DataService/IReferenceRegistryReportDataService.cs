﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW.IR;
using NW.SFP.Message.PS;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace NW.SFP.Interface.Report
{
    public interface IReferenceRegistryReportDataService
    {       
        int ManageRRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity);
        DataTable GetRrStratData(string StratName, int DealIrConfigId, string AsAtDate, int DealID, string UserName, int poolId =0, string ReportOutputType = "");
        int GetRRAuthorisedDealConfigId(int dealId, string AsAtDate, string loggedInUserName);
        IList<RRReportField> GetFieldsForReports(string loggedInUserName, int assetClassId);
    }
}