﻿using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace NW.SFP.Interface.Report.DataService
{
    public interface INWMReportsDataService
    {
        List<AssetRegisterReportEntity> GenerateAssestReportData(DateTime AsAtDate, string userName);
        List<LoansOutstandingReportEntity> GenerateLoansOutstandingReportData(DateTime AsAtDate, string userName);
    }
}
