﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;

namespace NW.SFP.Interface.PS
{
    public interface IESMAReportController
    {
        #region IEligibilityController Interface Members

        ActionResult GetESMA4ReportData(string asAtDate, string dealName, int poolId, string poolName);
        ActionResult GetESMA9ReportData(string asAtDate, string dealName, int poolId, string poolName);

        #endregion
    }
}
