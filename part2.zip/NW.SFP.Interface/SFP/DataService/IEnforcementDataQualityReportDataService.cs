﻿using NW.SFP.Message.SFP.DataQuality;
using System.Collections.Generic;

namespace NW.SFP.Interface.SFP
{
    public interface IEnforcementDataQualityReportDataService
    {
        #region IDealDataCorrectionService Interface Members
        List<EnforcementDetail> GetEnforcementDataQualityDetailReport();
        List<EnforcementSummary> GetEnforcementDataQualitySummaryReport();
        int GetEnforcementDataValidationStatus();

        #endregion
    }
}
