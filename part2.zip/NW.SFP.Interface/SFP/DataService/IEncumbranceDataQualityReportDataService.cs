﻿using NW.SFP.Message.SFP.DataQuality;
using System.Collections.Generic;

namespace NW.SFP.Interface.SFP
{
    public interface IEncumbranceDataQualityReportDataService
    {
        #region IDealDataCorrectionService Interface Members
        List<EncumbranceSummary> GetEncumbranceDataQualitySummaryReport();
        List<EncumbranceDetail> GetEncumbranceDataQualityDetailReport();
        int GetEncumbranceDataValidationStatus();
        #endregion
    }
}
