﻿using NW.SFP.Message.SFP.Model;
using System.Collections.Generic;

namespace NW.SFP.Interface.SFP
{
    public interface IReportLookUpDataService
    {
        List<ReportLookupModel> GetReportLookupData();
        ReportLookupModel GetReportLookupDataById(int reportLookUWorkPadpId);
        ReportLookupModel InsertReportLookUpData(ReportLookupModel reportLookUpData);
        int DeleteReportLookUpData(int lookupId);
        void SupportInsertReportLookUpData(ReportLookupModel reportLookUpData);
        ReportLookupModel UpdateWorkpadReportLookUpData(ReportLookupModel reportLookUpData);
        List<ReportLookupReferenceModel> GetReportLookUpReferenceData();
        int UpdateLookUpActionWorkFlow(string userName, string action, int lookupIds);
    }
}
