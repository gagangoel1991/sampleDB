﻿using NW.SFP.Message.SFP.Model;

namespace NW.SFP.Interface.SFP
{
    public interface ISfpBatchStatusDataService
    {
        BatchStatusDetailModel GetSFPBatchStatusData();
    }
}
