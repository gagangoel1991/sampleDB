﻿using NW.SFP.Message.SFP;
using NW.SFP.Message.SFP.Model;
using System.Collections.Generic;

namespace NW.SFP.Interface.SFP
{
    public interface IReportLookUpService
    {
        List<ReportLookupDto> GetReportLookupData();
        ReportLookupDto GetReportLookupDataById(int lookUpId);
        ReportLookupDto InsertReportLookUpData(ReportLookupDto reportLookUpData);
        int DeleteReportLookUpData(int lookupId);
        void SupportInsertReportLookUpData(ReportLookupModel reportLookUpData);
        ReportLookupDto UpdateWorkpadReportLookUpData(ReportLookupDto  reportLookUpData);
        ReportLookupReferenceDataDto GetReportLookUpReferenceData();
        int UpdateLookUpActionWorkFlow(string userName, string action, int lookupId);
    }
}
