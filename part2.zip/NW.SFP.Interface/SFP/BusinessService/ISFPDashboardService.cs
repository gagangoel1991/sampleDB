﻿using NW.SFP.Message.SFP;

namespace NW.SFP.Interface.SFP
{
    public interface ISFPDashboardService
    {
        SfpDashBoardDataList GetSFPDashBoardData(string userName);
    }
}
