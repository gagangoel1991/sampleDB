﻿using NW.SFP.Message.SFP;

namespace NW.SFP.Interface.SFP
{
    public interface IEncumbranceDataQualityReportService
    {
        EncumbranceDataQualityReport GetEncumbranceDataQualityReportData();
        int GetEncumbrancedataValidationStatus();
    }
}
