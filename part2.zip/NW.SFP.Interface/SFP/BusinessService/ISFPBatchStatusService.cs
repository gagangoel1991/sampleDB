﻿using NW.SFP.Message.SFP.DTO;
    
namespace NW.SFP.Interface.SFP
{
    public interface ISfpBatchStatusService
    {
        BatchStatusDetailDto GetSFPBatchStatusData();
    }
}
