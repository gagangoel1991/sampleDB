﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.SFP;
using NW.SFP.Message.SFP.DTO;

namespace NW.SFP.Interface.SFP
{
    public interface IEnforcementDataQualityReportController
    {
        ActionResult<EnforcementDataQualityReport> GetEnforcementDataQualityReportData();
        ActionResult<int> GetEnforcementDataValidationStatus();
    }
}