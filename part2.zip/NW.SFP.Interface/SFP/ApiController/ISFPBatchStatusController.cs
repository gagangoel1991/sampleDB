﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.SFP.DTO;

namespace NW.SFP.Interface.SFP
{
    public interface ISfpBatchStatusController
    {
        ActionResult<BatchStatusDetailDto> GetSFPBatchStatusData();
    }
}