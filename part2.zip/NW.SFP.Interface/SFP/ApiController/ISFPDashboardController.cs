﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.SFP;

namespace NW.SFP.Interface.SFP
{
    public interface ISFPDashboardController
    {
        ActionResult<SfpDashBoardDataList> GetSFPDashBoardData();
    }
}