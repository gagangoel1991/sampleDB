﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.SFP;
using NW.SFP.Message.SFP.DTO;

namespace NW.SFP.Interface.SFP
{
    public interface IEncumbranceDataQualityReportController
    {
        ActionResult<EncumbranceDataQualityReport> GetEncumbranceDataQualityReportData();
        ActionResult<int> GetEncumbranceDataValidationStatus();
    }
}