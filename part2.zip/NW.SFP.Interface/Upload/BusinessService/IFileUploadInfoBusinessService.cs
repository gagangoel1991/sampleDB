﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.Upload;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace NW.SFP.Interface.Upload
{
    public interface IFileUploadInfoBusinessService
    {
        #region IFileInfoBusinessService Interface Members
        IList<FileUploadInfo> GetFileUploadReferenceData(string userName, string userAdGroupName, int assetClassId);

        Task<FileUploadResult> UploadFile(IFormFile file, int fileId, string userName);
        IList<UploadFileWorflowState> GetFileWorkflowState(int fileInfoId, string loggedInUserName);
        bool SetFileWorkflowState(int fileInfoId, string fileStatus, string loggedInUserName);
        bool CheckFileExists(string fileName, string selectedAssetClassCode);
        bool MoveFile(string filename, string selectedAssetClassCode);
        UploadFileStageData LoadStagingData(int fileInfoId, string loggedInUserName);
        string GetCopyFileSharedPath(string selectedAssetClassCode);
        IList<UploadETLMessage> GetUploadETLMessages(int fileInfoId, string loggedInUserName);
        #endregion
    }
}