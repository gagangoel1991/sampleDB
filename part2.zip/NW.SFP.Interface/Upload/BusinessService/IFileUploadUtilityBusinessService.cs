﻿using NW.SFP.Message.Upload;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.Upload.BusinessService
{
    public interface IFileUploadUtilityBusinessService
    {

        public int SaveFileUploadUtilityDetails(FileUploadUtilityAddEntity objFileUploadUtilityAddEntity);
        public FileUploadUtilityConfiguration GetFileUploadUtilityConfiguration(int FileUploadUtilityConfigurationId, string UserName);
        IList<FileUploadUtilityDetailsEntity> GetFileUploadUtilityDetails(int FileUploadUtilityConfigurationId, int ReferenceId, string UserName);
        int DeleteFileUploadUtilityDetails(int FileUploadUtilityDetailsId, string UserName);
    }
}
