﻿using Microsoft.AspNetCore.Http;
using NW.SFP.Message.Upload;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NW.SFP.Interface.Upload
{
    public interface IFileUploadUtilityDataService
    {
        int SaveFileUploadUtilityDetails(FileUploadUtilityAddEntity objFileUploadUtilityAddEntity);
        FileUploadUtilityConfiguration GetFileUploadUtilityConfiguration(int FileUploadUtilityConfigurationId, string UserName);
        IList<FileUploadUtilityDetailsEntity> GetFileUploadUtilityDetails(int FileUploadUtilityConfigurationId, int ReferenceId, string UserName);
        int DeleteFileUploadUtilityDetails(int FileUploadUtilityDetailsId, string UserName);
    }
}
