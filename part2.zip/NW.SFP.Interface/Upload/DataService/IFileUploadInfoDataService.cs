﻿using Microsoft.AspNetCore.Http;
using NW.SFP.Message.Upload;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NW.SFP.Interface.Upload
{
    public interface IFileUploadInfoDataService
    {
        #region IDealDataCorrectionService Interface Members
        IList<FileUploadInfo> GetFileUploadReferenceData(string userName, string userAdGroupName, int assetClassId);

        Task<FileUploadResult> UploadFile(IFormFile file, int fileId, string userName);
        IList<UploadFileWorflowState> GetFileWorkflowState(int fileInfoId, string loggedInUserName);
        bool SetFileWorkflowState(int fileInfoId, string fileStatus, string loggedInUserName);
        bool CheckFileExists(string fileName, string sharedPath);
        bool MoveFile(string filename, string sharedPath);
        UploadFileStageData LoadStagingData(int fileInfoId, string loggedInUserName);
        IList<UploadETLMessage> GetUploadETLMessages(int fileInfoId, string loggedInUserName);
        #endregion
    }
}
