﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.Upload;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NW.SFP.Interface.Upload
{
    public interface IFileUploadInfoController
    {
        #region IFileInfoController Interface Members
        public ActionResult<IList<FileUploadInfo>> GetFileUploadReferenceData (int userRoleId);
        public ActionResult<Task<FileUploadResult>> UploadFile(IFormFile file, int fileId);
        #endregion
    }
}
