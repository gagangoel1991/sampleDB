﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.Interface.CB
{
    public interface IDataCorrectionRefController
    {
        #region IDataCorrectionReferenceController Interface Members        
        public ActionResult<DataCorrectionReference> GetDataCorrectionReferenceData();
        #endregion
    }
}
