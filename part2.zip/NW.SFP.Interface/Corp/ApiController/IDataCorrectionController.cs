﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.CB;
using NW.SFP.Message.Corp;
using System.Collections.Generic;

namespace NW.SFP.Interface.CB
{
    public interface IDataCorrectionController
    {
        #region IDealDataCorrectionController Interface Members
        public ActionResult<IList<DataCorrectionAttribute>> GetDataCorrectionAttribute(int entityId);
        public ActionResult<DataCorrectionDetail> GetDataCorrectionDetail(DataCorrectionBasicInfo basicInfo);
        public ActionResult<string> SaveDataCorrection(DataCorrectionBasicInfo basicInfo);
        public IList<UpdateOverrideListEntity> GetUpdateOverrideList(int dealId, string AsAtDate);
        public ActionResult DownloadAuditTrailReport(int dealId, string entityType, string vintageDate);
        public IList<string> GetOverrideVintageDatesList(int dealId);
        #endregion
    }
}
