﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.Interface.CB
{
    public interface ILossManagementController
    {
        #region ILossManagementController Interface Members
        public ActionResult<IList<LossManagementList>> GetLossManagementList();
        #endregion
    }
}
