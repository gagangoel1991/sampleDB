﻿using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.Interface.CB
{
    public interface IDataCorrectionRefDataService
    {
        #region IDealDataCorrectionService Interface Members        
        public DataCorrectionReference GetDataCorrectionReferenceData(string userName);
        #endregion
    }
}
