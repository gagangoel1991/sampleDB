﻿using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.Interface.CB
{
    public interface ILossManagementDataService
    {
        #region ILossManagementDataService Interface Members
        IList<LossManagementList> GetLossManagementList(string userName);
        LossManagementRefData GetLossManagementRefData(string userName);
        IList<LossManagementList> GetLossUpdatedData (string userName);
        int UploadWriteOffFile(IList<WriteOffData> writeOffData, string userName);
        DefaultDateData GetDefaultDateData(DefaultDateData defaultDateParam, string userName);
        int UpdateLossDetails(LossManagementList lossManagementList, string userName);
        decimal? LoadAllocatedLoss(int lossManagementId, string userName);
        #endregion
    }
}
