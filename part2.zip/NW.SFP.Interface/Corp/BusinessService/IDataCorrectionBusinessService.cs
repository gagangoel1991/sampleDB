﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using NW.SFP.Message.CB;
using NW.SFP.Message.Corp;
using System.Collections.Generic;
using System.IO;

namespace NW.SFP.Interface.CB
{
    public interface IDataCorrectionBusinessService
    {
        #region IDealDataCorrectionService Interface Members
        IList<DataCorrectionAttribute> GetDataCorrectionAttribute(int entityId, string userName);
        public DataCorrectionDetail GetDataCorrectionDetail(DataCorrectionBasicInfo basicInfo, string userName);
        public string SaveDataCorrection(DataCorrectionBasicInfo basicInfo, string userName);
        public IList<UpdateOverrideListEntity> GetUpdateOverrideList(string userName, int dealId, string AsAtDate);
        public MemoryStream getLinkageAuditReportData(int dealId, string AsAtDate, string loggedInUserName);
        public MemoryStream getFacilityOverrideData(int dealId, string AsAtDate, string loggedInUserName, int isTemplate);
        public MemoryStream getSecurityOverrideData(int dealId, string AsAtDate, string loggedInUserName, int isTemplate);
        public MemoryStream GetOverrideAuditTrailData(int dealId, string entityType, string vintageDate, string userName);
        public IList<string> GetOverrideVintageDateList(int dealId, string userName);



        int saveOverrideData(int dealId, string AsAtDate, string loggedInUserName, IFormFileCollection files,
           List<FacilitySecurityLink> LinkList, string isListEdited, IFormCollection formCollection,
          out List<Dictionary<string, string>> ErrorExcel, out List<string> LstcolumnNames, out string ErrorEntity);

        public MemoryStream getFacilityComparisionData(int DealIrConfigId, int dealId, string AsAtDate,
            string PreviousReportingDate, int AnyDiffFlag, string userName);
        public MemoryStream getSecurityComparisionData(int DealIrConfigId, int dealId, string AsAtDate,
            string PreviousReportingDate, int AnyDiffFlag, string userName);

        public string validatePoolAndOverrideAuthorize(int callFromOverrideAuth, int id);
        public IList<FacilitySecurityLinkEntity> getFacilitySecurityLinkStatus(string userName, string AsAtDate, string ComparisonDate, int dealId);

        public string resetOverrideData(int DealOverrideParentId, string Entity);

        #endregion
    }
}
