﻿namespace NW.SFP.Interface.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;
    using ClosedXML.Excel;
    using NW.SFP.Message.CW.IR;

    public interface IAutomatedPostWaterfallControlService
    {
        IEnumerable<ExcelUploadEntity> GetPostWfControlList(string DealName, string AsAtDate);

        DataTable GetStratData(string AsAtDate, string DealName, int FieldId, string StratName, string LoggedInUserName, string ReportTypeName);

        bool GenerateAutomatedPostWaterfallFile(string DealName, string AsAtDate, string LoggedInUserName);

        void CopyInvestorReportTabData(string IRFileName, IXLWorkbook _toWb, string sheetName, int startColNo, int endColNo, int startRowNo, int endRowNo);

        List<PostWaterfallReconcileEntity> GetPostWaterfallTabData(string IRFileName, string sheetName);

        public List<PostWaterfallEntity> GetPostWaterfallOutputFileData();
    }
}
