﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.BusinessService
{
    public interface IBondRatingService
    {
        BondRating GetBondRatingData(IPDFeedParam ipdFeedParam);

        int SaveBondRatingData(dynamic bondRatingEntity, string loggedInUser);

        IList<CreditRatingEntity> GetCreditRatings(string loggedInUserName);

        int ResetBondRatingData(int ipdRunId, string loggedInUser);

        bool IsBondRatingEdited(int ipdRunId, string loggedInUser);
    }
}
