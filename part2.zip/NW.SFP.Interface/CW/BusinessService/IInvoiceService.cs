﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IInvoiceService
    {
        /// <summary>
        /// This will return the invoice data based on the parameters
        /// </summary>
        /// <param name="invoiceParams"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams, string userName);

        /// <summary>
        /// This will return the single invoice record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        InvoiceDataEntity GetInvoice(int invoiceId, string loggedInUser);


        /// <summary>
        /// Delete Invoice Data
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        int DeleteInvoiceData(int invoiceId, string userName);

        /// <summary>
        /// This will save the invoice data record.
        /// </summary>
        /// <param name="invoiceData"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        int SaveInvoiceData(InvoiceDataEntity invoiceData, string userName);

        /// <summary>
        /// IPD specific Invoice data
        /// </summary>
        /// <param name="iPDFeedParam"></param>
        /// <returns></returns>
        IList<InvoiceDataEntity> GetInvoiceIpdData(IPDFeedParam iPDFeedParam);

        decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate, string userName);
    }
}
