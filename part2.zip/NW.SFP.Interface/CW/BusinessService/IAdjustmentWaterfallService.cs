﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IAdjustmentWaterfallService
    {
        /// <summary>
        /// this will return Adjustment Principal Waterfall data
        /// </summary>
        /// <returns></returns>
        IList<AdjustmentWaterfallEntity> GetAdjustmentWaterfallData(IPDFeedParam ipdFeedParam);

        int SavePrincipalWaterfall(IEnumerable<AdjustmentWaterfallEntity> adjustmentWaterfallEntity, string loggedInUser);

        IList<AdjustmentOutputEntity> GetAdjustmentRppOutputData(IPDFeedParam ipdFeedParam);

        IList<AdjustmentOutputEntity> GetAdjustmentPppOutputData(IPDFeedParam ipdFeedParam);
    }
}
