﻿namespace NW.SFP.Interface.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;

    public interface IStratService
    {
        IEnumerable<StratEntity> GetAssetStratList(int stratType, int AssetClassId, string ReportTypeName = "");

        StratEntity GetAssetStratDetail(int StratId, string UserName, string ReportTypeName = "");

        StratEntity Save(StratEntity strat, string UserName, int AssetClassId, string ReportTypeName = "");

        StratEntity Update(StratEntity strat, string UserName);

        int Delete(int StratId, string UserName);

        DataTable GetStratPreviewData(string StratName, string AsAtDate, string DealName);

        DataTable GetStratPreviewData(StratPreviewSearchEntity stratPreviewSearchEntity);

        BespokeStratPreviewEntity GetBeSpokeStratPreviewData(StratPreviewSearchEntity stratPreviewSearchEntity);

        StratEntity GetBeSpokeAssetStratDetail(int StratId, string UserName);
    }
}
