﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IIpdAuthWorkflowService
    {
        int ManageIpdAuthWorkflow(IpdWorkflowEntity ipdWorkflowEntity);

        IpdWorkflowEntity GetIpdAuthWorkflowStatus(IpdWorkflowEntity ipdWorkflowEntity);

        int ValidateIPD(int dealIpdRunId, int workFlowStep, string userName);
    }
}
