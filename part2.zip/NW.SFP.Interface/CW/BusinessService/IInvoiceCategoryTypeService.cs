﻿using System;
using System.Collections.Generic;
using System.Text;
using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IInvoiceCategoryTypeService
    {
        /// <summary>
        /// This will return the invoice category Type
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        IList<InvoiceCategoryTypeEntity> GetInvoiceCategoryType(string userName);
    }
}
