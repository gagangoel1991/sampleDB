﻿using System;
using System.Collections.Generic;
using System.Text;
using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IInvoiceCategoryService
    {
        /// <summary>
        /// This will return the invoice categories based on type
        /// </summary>
        /// <param name="invoiceCategoryTypeId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryTypeId, string userName);
    }
}
