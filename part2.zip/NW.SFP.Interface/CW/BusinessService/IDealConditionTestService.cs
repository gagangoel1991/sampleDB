﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
   public interface IDealConditionTestService
    {

        public List<DealConditionTestEntity> GetDealConditionTestData(IPDFeedParam iPDFeedParam);

        public int SaveDealConditionTestData(DealConditionTestEntity dealConditionTestEntity, string loggedInUser);
    }
}
