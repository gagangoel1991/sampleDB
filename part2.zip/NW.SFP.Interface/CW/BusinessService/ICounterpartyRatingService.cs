﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface ICounterpartyRatingService
    {
        CounterpartyRatingEntity GetCounterpartyRatingData(IPDFeedParam ipdFeedParam);

        int SaveCounterpartyRatingData(dynamic bondRatingEntity, string loggedInUser);

        IList<CreditRatingEntity> GetCreditRatings(string loggedInUserName);

        int ResetCounterpartyRatingData(int ipdRunId, string loggedInUser);

        bool IsCPRatingEdited(int ipdRunId, string loggedInUser);
    }
}
