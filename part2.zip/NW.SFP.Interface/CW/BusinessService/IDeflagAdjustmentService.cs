﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDeflagAdjustmentService
    {
     
        DataTable GetRepurchasePoolAdjustmentData();
        DataTable GetAdjustmentPoolData(int poolAdjustmentId);

      
        DataTable GetDeflagAdjustmentExcelData(int poolAdjustmentId, string userName);

       
        DataTable GetControlCheckData(int poolAdjustmentId, string userName);

		int ManageDeflagAdjustmentAuditAuthWorkflowByUser(IPDFeedParam authWorkflowEntity);

        int DeflagAdjustmentSentforAuthorization(DefalgAdjustmentEntity DefalgAdjustmentEntity);


    }
}
