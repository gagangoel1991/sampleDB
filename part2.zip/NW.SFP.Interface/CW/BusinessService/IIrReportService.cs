﻿namespace NW.SFP.Interface.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;
    using NW.SFP.Message.CW.IR;

    public interface IIrReportService
    {
        IEnumerable<ExcelUploadEntity> GetIrDealStratList(string DealName, string AsAtDate);

        IEnumerable<ExcelUploadEntity> GetBuildIrStratList(int dealIrConfigId, string AsAtDate, string ReportTypeName);

        DataTable GetStratData(string AsAtDate, string DealName, int FieldId, string StratName, string LoggedInUserName, string ReportTypeName);

        bool GenerateIRFile(string SourceFile, string TargetFile, string ParentWorkSheet, bool GenerateFinalIrCopy, string ProtectSheetKey, int DealIrConfigId, string AsAtDate, IEnumerable<ExcelUploadEntity> _ExcelUploadEntity, string LoggedInUserName, string ReportTypeName, int AssetID);

        public IR_Config GetDealIRConfigByDealId(int DealId, string ReportTypeName);
    }
}
