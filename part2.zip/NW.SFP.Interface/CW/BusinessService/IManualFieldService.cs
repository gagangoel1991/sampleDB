﻿using NW.SFP.Message;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.BusinessService
{
    public interface IManualFieldService
    {
        List<ManualFieldEntity> GetManualFieldData(int DealIpdRunId,int mfGrouptypeId, string UserName);
        int UpdateManualFieldData(List<ManualFieldKeyValue> ManualFieldKeyValue,int mfGrouptypeId, string UserName);
        int ResetManualFieldData(int DealIpdRunId,int mfGrouptypeId, string UserName);

        int ResetManualFieldDealSwapData(int DealIpdRunId, int mfGrouptypeId, string UserName);
    }
}
