﻿using Microsoft.AspNetCore.Http;
using NW.SFP.Message.CW.IpdRunProcess;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Text;

namespace NW.SFP.Interface.CW.BusinessService
{
    public interface IRatingUploadService
    {
        public IList<DealIpdDateEntity> GetDealIpdDates();
        public RatingFileParsedResult ParseRatingFile(IFormFile RatingFile, int DealId);
        public IList<RatingListingData> GetRatingListingData();
        public int SaveUserRatingData(IFormFile RatingFile, RatingFileUpload ObjRatingFileUpload);
        public IList<RatingMasterData> GetRatingMasterData(int DealId);
        public RatingSavedData GetUserRatingSavedData(int userRatingFileUploadDetailId);
        public bool UploadRatingDataRecordExist(RatingFileUpload ratingFileUpload);
        public int DeleteRatingData(int userRatingFileUploadDetailId, string LoggedInUserNamed);

    }
}
