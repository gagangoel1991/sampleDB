﻿using NW.SFP.Message.CW;


namespace NW.SFP.Interface.CW
{
    public interface ISubloanService
    {
        Subloan GetSubloan(IPDFeedParam iPDFeedParam);
    }
}
