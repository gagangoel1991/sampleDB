﻿namespace NW.SFP.Interface.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using ClosedXML.Excel;
    using System.IO;
    using System.Net.Http;

    public interface IExcelService
    {

        void WriteDataIntoExcel(DataTable dataTable, IXLWorksheet ws, int rowNumber, int startColIndex);

        HttpResponseMessage DownLoadExcel(string FileName, string OutputFileName);

        void WriteDataIntoExcel(DataTable dataTable, IXLWorksheet ws, string anchorCell);


        bool IsWorksheetExist(IXLWorkbook _wb, string _wsName);

        void ReplaceFormulaWithValue(IXLWorksheet _ws, int startColNo, int endColNo, int startRowNo, int endRowNo);

        bool IsWorksheetsExist(IXLWorkbook workbook, string[] _wsNames);
        bool IsWorksheetsExist(IXLWorkbook workbook, string[] _wsNames, out string MissingSheetName);
    }
}
