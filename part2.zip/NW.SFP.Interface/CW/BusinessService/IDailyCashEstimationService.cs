﻿using ClosedXML.Excel;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDailyCashEstimationService
    {
        List<DailyCashEstimationDataEntity> GetDailyCashEstimationData(string dealName, string asAtDate, string loggedInUser);
        List<DailyCashEstimationDataEntity> GetCashEstimationDistinct(string dealName, string asAtDate, string loggedInUser);
        public IXLWorkbook GetDailyCashEstimationExcel(string dealName, string asAtDate, string loggedInUser);
        public DateTime GetCollectionDate(string asAtDate, string dealName, string loggedInUser);
    }
}
