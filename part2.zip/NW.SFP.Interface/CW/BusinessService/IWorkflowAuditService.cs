﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.BusinessService
{
    public interface IWorkflowAuditService
    {
        IList<WorkflowAuditEntity> GetWorkflowAuditData(int workflowTypeId, int referenceId, string loggedInUser);
    }
}
