﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using ClosedXML.Excel;

namespace NW.SFP.Interface.CW
{
    public interface IDailyCashCollectionsService
    {
        public DataTable GetDealCollectionHistoryData(DailyCollectionHistoryParam dailyCollectionHistParam, string userName);
        public DataTable GetPNRSplitData(string asAtDate, string adviceDate, string dealName, string userName);
        public DataTable GetDealDailyCollectionData(string asAtDate, string userName);
        public DataTable GetCBOutputData(DailyCollectionHistoryParam cbOutputParam, string userName);
        public IXLWorkbook GetDealDailyCollectionsExcel(string asAtDate,string loggedInUser);
        public IXLWorkbook GetPNRSplitExcel(string asAtDate, string adviceDate, string dealName, string userName);
        public IXLWorkbook GetCBOutputExcel(DailyCollectionHistoryParam cbOutputParam, string userName);

        public bool GenerateCollectionHistoryFile(DailyCollectionHistoryParam dailyCollectionHistParam, string SourceFile, string TargetFile, string userName);

        public string GetDownloadFileStream(string SourceFile);

        public DataTable GetEmailDataForCollectionOutput(string emailType, string asAtDate,string attachmentFileLocation ,string userName);
    }
}