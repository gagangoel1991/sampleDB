﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface IIpdSummaryService
    {
        List<IpdSummaryResultEntity> GetIpdSummaryData(int dealId, int ipdRunId, string loggedInUserName);
    }
}
