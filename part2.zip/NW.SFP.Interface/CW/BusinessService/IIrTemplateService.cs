﻿namespace NW.SFP.Interface.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;

    public interface IIrTemplateService
    {
        IList<IrTemplateEntity> GetTemplateList(int assetClassId, string ReportTypeName = "");

        IrTemplateEntity GetTemplateDetail(int templateId, string UserName, string ReportTypeName = "");

        int Save(IrTemplateEntity template, string UserName, int assetClassId, string ReportTypeName = "");

        int Delete(int templateId, string UserName);
    }
}
