﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IUpstreamDataAuthWorkflowService
    {
        IPDFeedParam GetUpstreamDataAuthWorkflowStatus(IPDFeedParam upstreamDataWorkflowEntity);

        int ManageUpstreamDataAuthWorkflow(IPDFeedParam upstreamDataWorkflowEntity);
    }
}
