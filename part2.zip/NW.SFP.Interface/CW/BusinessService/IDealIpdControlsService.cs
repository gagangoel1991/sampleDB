﻿using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW.BusinessService
{
    public interface IDealIpdControlsService
    {
        public StormVsSfpEntity StormVsSfp(int dealId, int ipdRunId, string loggedInUser);
        public DataSet StormVsSfpExcelData(int dealId, int ipdRunId, string loggedInUser);
    }
}
