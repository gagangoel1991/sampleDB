﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface IPdlBreakdownService
    {
        List<PdlBreakdownEntity> GetPDLBreakdownData(IPDFeedParam ipdFeedParam);
    }
}
