﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IEmailService
    {
        void AttachmentforEmail(DataTable obj,string GeneratedFileName);
    }
}
