﻿using ClosedXML.Excel;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.Interface.CW
{
    public interface IBookingService
    {
        List<BookingTradesEntity> GetBookingTabData(IPDFeedParam ipdFeedParam);

        List<BookingEntity> GetBookingsIPDData(IPDFeedParam ipdFeedParam);

        IXLWorkbook GetBookingExcel(IPDFeedParam ipdFeedParam,bool isSwapSummaryData);

        DataTable GetBookingNwbFoFeesData(IPDFeedParam ipdFeedParam);

        DataTable GetBookingNwbFoLdData(IPDFeedParam ipdFeedParam);

        DataTable GetBookingLLPMoFeesData(IPDFeedParam ipdFeedParam);

        DataTable GetBookingLoansAndDepositsData(IPDFeedParam ipdFeedParam);

        DataTable GetBookingSwapSummaryData(IPDFeedParam ipdFeedParam);

        DataTable GetBookingReconData(IPDFeedParam ipdFeedParam);
        bool GetBookingReconExcelData(IPDFeedParam ipdFeedParam, string BackupTemplate, string GeneratedFileName);

        public string GetDownloadFileStream(string SourceFile);

        bool ProcessBookingData(IPDFeedParam ipdFeedParam);
    }
}
