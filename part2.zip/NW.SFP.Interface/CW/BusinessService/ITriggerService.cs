﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface ITriggerService
    {
        public List<RatingTriggerEntity> GetRatingTriggers(IPDFeedParam iPDFeedParam);

        List<NonRatingTriggerEntity> GetNonRatingTriggers(IPDFeedParam iPDFeedParam);

        int SaveNonRatingTrigger(NonRatingTriggerEntity nonRatingTriggerEntity);

        int ResetNontRatingTrigger(int dealId, int ipdRunId, string loggedInUser);

        int ResetTriggersConditions(int ipdRunId, string loggedInUser);

        public List<RatingTriggerEntity> GetSwapRatingTriggers(IPDFeedParam iPDFeedParam);
    }
}
