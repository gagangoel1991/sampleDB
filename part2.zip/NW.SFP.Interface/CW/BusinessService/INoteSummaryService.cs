﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface INoteSummaryService
    {
        DealNoteSummary GetDealNoteSummary(IPDFeedParam ipdFeedParam);
    }
}
