﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;


namespace NW.SFP.Interface.CW
{
    public interface IDataLoadService
    {
        bool ProcessDataLoad(string loadType, string asAtDate, string userName);

        DataTable GetDataLoadDates();

    }
}
