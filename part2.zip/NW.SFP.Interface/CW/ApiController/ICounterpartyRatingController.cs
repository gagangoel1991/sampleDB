﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface ICounterpartyRatingController
    {
        CounterpartyRatingEntity GetCounterpartyRatingData(int dealId, int ipdRunId);

        int SaveCounterpartyRatingData(dynamic cpRatingEntity);

        IList<CreditRatingEntity> GetCreditRatings();

        int ResetCounterpartyRatingData(int ipdRunId);

        bool IsCPRatingEdited(int ipdRunId);
    }
}
