﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface ITriggerController
    {
        public List<RatingTriggerEntity> GetRatingTriggers(int dealId, int ipdRunId);

        List<NonRatingTriggerEntity> GetNonRatingTriggers(int dealId, int ipdRunId);

        int SaveNonRatingTrigger(NonRatingTriggerEntity nonRatingTriggerEntity);
    }
}
