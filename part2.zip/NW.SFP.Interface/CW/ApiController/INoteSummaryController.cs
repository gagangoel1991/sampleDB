﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface INoteSummaryController
    {
        DealNoteSummary GetDealNoteSummary(int dealId, int ipdRunId);
    }
}
