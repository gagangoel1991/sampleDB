﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IInterestRateController
    {
        InterestRate GetInterestRateData(int dealId, int ipdRunId);

        int SaveInterestRate(InterestRateEntity interestRateEntity);
    }
}
