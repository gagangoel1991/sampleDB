﻿using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.ApiController
{
    public interface IDealIpdControlsController
    {
        public StormVsSfpEntity StormVsSfp(int dealId, int ipdRunId);        
        public string PreStormVsSfpReportDownload(int dealId, int ipdRunId);
    }
}
