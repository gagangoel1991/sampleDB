﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.Email;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IEmailConfigController
    {
        IList<EmailConfigEntity> GetEmailConfigList();
        int SaveEmailConfig(EmailConfigEntity dealEntity);
        IActionResult GetEmailConfig(int emailConfigId);
                
    }
}
