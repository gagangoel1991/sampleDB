﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.ApiController
{
    public interface ICashLadderController
    {
        /// <summary>
        /// This will return the cash ladder data
        /// </summary>
        /// <returns></returns>
        CashLadder GetCashLadderData(int dealId, int ipdRunId);


        int SaveCashLadderData(UpdateCashLadderEntity objUpdateCashLadderEntity);
    }
}
