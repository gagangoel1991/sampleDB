﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IManualFieldController
    {
        dynamic GetManualFieldData(int DealIpdRunId,int mfGrouptypeId);
        int UpdateManualFieldData(List<ManualFieldKeyValue> ManualFieldKeyValue, int mfGrouptypeId);
        int ResetManualFieldData(int DealIpdRunId, int mfGrouptypeId);
    }
}
