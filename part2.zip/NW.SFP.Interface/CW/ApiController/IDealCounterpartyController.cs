﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDealCounterpartyController
    {
        /// <summary>
        /// This will return the counter party of a deal
        /// </summary>
        /// <param name="dealId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        IList<DealCounterpartyEntity> GetDealCounterparty(int dealId);
    }
}
