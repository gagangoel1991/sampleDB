﻿using DocumentFormat.OpenXml.Drawing.Charts;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDeflagController
    {
        /// <summary>
        /// This will return the Repurchase Pool Adjustment List
        /// </summary>
        DataTable GetRepurchasePoolAdjustment();
        DataTable GetAdjustmentPoolDetails(int poolCashCollectionAdjustmentId);
        string GetDeflagAdjustmentExcelFile(int poolCashCollectionAdjustmentId);

        DataTable GetControlCheckData(int poolCashCollectionAdjustmentId);
    }
}
