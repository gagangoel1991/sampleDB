﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDealDateController
    {
        /// <summary>
        /// This will return the next IPDs of a deal
        /// </summary>
        /// <param name="dealId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        IList<DealIpdEntity> GetDealNextIpd(int dealId);
    }
}
