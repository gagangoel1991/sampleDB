﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.ApiController
{
    public interface IBondRatingController
    {
        BondRating GetBondRatingData(int dealId, int ipdRunId);

        int SaveBondRatingData(dynamic bondRatingEntity);

        IList<CreditRatingEntity> GetCreditRatings();

        int ResetBondRatingData(int ipdRunId);

        bool IsBondRatingEdited(int ipdRunId);
    }
}
