﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface
{
    public interface IIrTemplateController
    {
        IList<IrTemplateEntity> GetTemplateList(int assetClassId, string reportTypeName = "");

        IrTemplateEntity GetTemplateDetail(int templateId, string reportTypeName = "");

        int SaveTemplate(IrTemplateEntity template, int assetClassId, string reportTypeName = "");

        int DeleteTemplate(int templateId);
    }
}
