﻿using NW.SFP.Message.CW.IpdRunProcess;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.ApiController
{
    public interface IRatingUploadController
    {
        IList<DealIpdDateEntity> GetDealIpdDates();
        public IList<RatingListingData> GetRatingListingData();
        public RatingSavedData GetUserRatingSavedData(int userRatingFileUploadDetailId);
    }
}
