﻿using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.Interface.CW
{
    public interface IPdlSummaryController
    {
        DataTable GetPDLSummaryData(int dealId, int ipdRunId);
    }
}
