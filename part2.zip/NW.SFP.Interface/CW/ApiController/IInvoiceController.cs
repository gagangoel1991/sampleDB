﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface
{
    public interface IInvoiceController
    {
        /// <summary>
        /// This will return the invoice category Type
        /// </summary>
        IList<InvoiceCategoryTypeEntity> GetInvoiceCategoryType();

        /// <summary>
        /// This will return the invoice categories based on type
        /// </summary>
        /// <param name="invoiceCategoryTypeId"></param>
        /// <returns></returns>
        IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryTypeId);

        /// <summary>
        /// This will return the invoice data based on the parameters
        /// </summary>
        /// <param name="invoiceParams"></param>
        /// <returns></returns>
        IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams);

        /// <summary>
        /// This will return the single invoice record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        InvoiceDataEntity GetInvoice(int invoiceId);


        /// <summary>
        /// This will delete the invoice record 
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        int DeleteInvoiceData(int invoiceId);

        ///// <summary>
        ///// This will save the invoice data record.
        ///// </summary>
        ///// <param name="invoiceData"></param>
        ///// <returns></returns>
        //int SaveInvoiceData(InvoiceDataEntity invoiceData);

        /// <summary>
        /// IPD specific data for Automated data
        /// </summary>
        /// <param name="iPDFeedParam"></param>
        /// <returns></returns>
        IList<InvoiceDataEntity> GetInvoiceIpdData(int dealId, int ipdRunId);

        decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate);
    }
}
