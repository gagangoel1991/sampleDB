﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface IReserveController
    {
        List<ReserveEntity> GetReserve(int dealId, int ipdRunId);
    }
}
