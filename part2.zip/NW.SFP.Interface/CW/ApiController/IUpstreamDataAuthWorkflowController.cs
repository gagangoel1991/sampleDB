﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IUpstreamDataAuthWorkflowController
    {
        IPDFeedParam GetUpstreamDataAuthWorkflowStatus(IPDFeedParam authWorkflowEntity);

        int ManageUpstreamDataAuthWorkflow(IPDFeedParam authWorkflowEntity);

        int ManageUpstreamDataAuthWorkflowByUser(IPDFeedParam authWorkflowEntity);
    }
}
