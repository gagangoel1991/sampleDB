﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDealController
    {
        /// <summary>
        /// This will return the deal details 
        /// </summary>
        /// <returns></returns>
        IList<DealEntity> GetDealList(int assetClassId);
        /// <summary>
        /// create deal
        /// </summary>
        /// <returns></returns>
        int SaveDeal(DealEntity dealEntity, int assetClassId);


        IActionResult GetDeal(int dealId);

        IActionResult DeleteDeal(int dealId);

        int ManageDealAuthWorkflow(IPDFeedParam authWorkflowEntity);
    }
}
