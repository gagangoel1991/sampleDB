﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface IWorkflowAuditController
    {
        IList<WorkflowAuditEntity> GetWorkflowAuditData(int workflowTypeId, int referenceId);
    }
}
