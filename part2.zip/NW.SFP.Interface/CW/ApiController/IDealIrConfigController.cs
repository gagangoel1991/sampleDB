﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;

namespace NW.SFP.Interface
{
    public interface IDealIrConfigController
    {
        // <summary>
        /// This will return the Deal IR Config List
        /// </summary>
        /// <returns></returns>
        IList<DealIrConfigListEntity> GetDealIrConfigList(int AssetClassId, string ReportTypeName);

        /// <summary>
        /// This will return the single Deal IR Config record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <returns></returns>
        DealIrConfigEntity GetDealIrConfig(int dealIrConfigId, int AssetClassId);

        /// <summary>
        /// This will delete the Deal IR Config record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <returns></returns>
        int DeleteDealIrConfig(int dealIrConfigId);

        /// <summary>
        /// This will save the Deal Ir Config record.
        /// </summary>
        /// <param name="dealIrConfigData"></param>
        /// <returns></returns>
        int SaveDealIrConfig(DealIrConfigAddEditEntity dealIrConfigData, int AssetClassId);

        IActionResult Download(int dealIrConfigId, string AsAtDate, int templateId, int assetId = 1);

        string UploadTemplate([FromForm] DealIrConfigAddEditEntity dealIrConfigData, int assetClassId);

        int ManageDealIRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity);

        List<IR_ConfigStartList> getIrConfigStratList(int dealId, int AssetClassId);

        List<IR_ConfigLayoutList> getIrConfigLayoutList(int dealId, int AssetClassId);
    }
}
