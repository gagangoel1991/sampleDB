﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface ICollectionLedgerController
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        CollectionLedger GetCollectionLedgerData(int dealId, int ipdRunId);
        /// <summary>
        ///  
        /// </summary>
        /// <returns></returns>
        int UpdateCollectionLedgerData(UpdateCollectionLedgerEntity objUpdateCollectionLedgerEntity);
    }
}
