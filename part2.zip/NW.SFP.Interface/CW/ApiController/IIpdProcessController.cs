﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.ApiController
{
    public interface IIpdProcessController
    {
        /// <summary>
        /// This will return the deal IPD left menu items
        /// </summary>
        /// <param name="dealId"></param>
        /// <returns></returns>
        IList<MenuItemEntity> GetDealIpdMenuData(int dealId);
    }
}
