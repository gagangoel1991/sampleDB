﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IIpdAuthWorkflowController
    {
        int ManageIpdAuthWorkflow(IpdWorkflowEntity ipdWorkflowEntity);

        IpdWorkflowEntity GetIpdAuthWorkflowStatus(IpdWorkflowEntity ipdWorkflowEntity);

        int ManageIpdAuthWorkflowByUser(IpdWorkflowEntity ipdWorkflowEntity);

        int ValidateIPD(int dealIpdRunId, int workFlowStep);
    }
}
