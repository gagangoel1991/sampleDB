﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.ApiController
{
    public interface IDailyCollectionController
    {
        /// <summary>
        /// This will return the Daily Collection Entity data
        /// </summary>
        /// <returns></returns>
        DailyCollection GetDailyCollectionData(int dealId, int ipdRunId);

        int SaveDailyCollectionData(DailyCollectionEntity dailyCollectionEntity);
    }
}
