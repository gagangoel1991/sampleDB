﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface ISubloanController
    {
        Subloan GetSubloan(int dealId, int ipdRunId);
    }
}
