﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface
{
    public interface IIrLookupController
    {
        /// <summary>
        /// This will return the Strats Master List based on strat type
        /// </summary>
        /// <param name="stratTypeId"></param>
        /// <returns></returns>
        IList<StratLookup> GetStratLookup(int stratTypeId);
    }
}
