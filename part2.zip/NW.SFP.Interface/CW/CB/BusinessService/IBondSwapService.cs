﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.CB
{
    public interface IBondSwapService
    {
        List<BondSwapEntity> GetBondSwapData(IPDFeedParam ipdFeedParam);
    }
}
