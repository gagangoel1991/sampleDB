﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.CB
{
    public interface ILedgersFundService
    {
        List<RevenueLedgerFund> GetRevenueLedger(IPDFeedParam ipdFeedParam);

        List<PrincipalLedgerFund> GetPrincipalLedger(IPDFeedParam ipdFeedParam);

        List<PaymentLedgerFund> GetPaymentLedger(IPDFeedParam ipdFeedParam);

        List<MaturingLoansLedgerFund> GetMaturingLoansLedger(IPDFeedParam ipdFeedParam);

        List<CapitalAccountLedgerEntity> GetCapitalAccountLedger(IPDFeedParam ipdFeedParam);
    }
}
