﻿using NW.SFP.Message.CW;
using System.Collections.Generic;
using ClosedXML.Excel;
using System.Data;

namespace NW.SFP.Interface.CW.CB
{
    public interface IFundsFacadeService
    {
        List<SwapCollateralEntity> GetSwapCollateral(IPDFeedParam ipdFeedParam);

        List<ReserveFundEntity> GetReserveFund(IPDFeedParam ipdFeedParam);

        List<PreMaturityLiquidityEntity> GetPreMaturityLiquidityFund(IPDFeedParam ipdFeedParam);

        List<CouponPaymentEntity> GetCouponPaymentFund(IPDFeedParam ipdFeedParam);

        public IXLWorkbook GetReserveFundExcel(IPDFeedParam IpdFeedParam);

        public DataTable GetReserveFundIpdDateHeader(IPDFeedParam ipdFeedParam);

        List<RevenueLedgerFund> GetRevenueLedger(IPDFeedParam ipdFeedParam);

        List<PrincipalLedgerFund> GetPrincipalLedger(IPDFeedParam ipdFeedParam);


        List<PaymentLedgerFund> GetPaymentLedger(IPDFeedParam ipdFeedParam);

        List<MaturingLoansLedgerFund> GetMaturingLoansLedger(IPDFeedParam ipdFeedParam);

        List<CapitalAccountLedgerEntity> GetCapitalAccountLedger(IPDFeedParam ipdFeedParam);

    }
}
