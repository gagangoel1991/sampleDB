﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW.CB
{
    public interface ICBNoteSummaryService
    {
        CBNoteSummary GetNoteSummary(IPDFeedParam ipdFeedParam);
    }
}
