﻿using ClosedXML.Excel;
using NW.SFP.Message.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.CB
{
    public interface ITestService
    {
        Tuple<List<TestDataEntity>, List<DateTime>, dynamic> GetTestDataSummary(IPDFeedParam ipdFeedParam);

        List<TestDataEntity> GetTestData(IPDFeedParam ipdFeedParam, string testTypeName);

        public IXLWorkbook GetTestExcel(IPDFeedParam IpdFeedParam, string TestTypeName);
    }
}
