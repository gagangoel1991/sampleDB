﻿using ClosedXML.Excel;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.CB
{
    public interface ICollectionsAndReservesInterestService
    {
        public List<CollectionsEntity> GetCollectionData(int DealIpdRunId, string UserName);
        public List<ReservesEntity> GetReservesData(int DealIpdRunId, string UserName);
        public IXLWorkbook GetCollandIntExcelSheet(int DealIpdRunId, string UserName);
        public dynamic GetCollandIntData(int DealIpdRunId, string UserName);
        public decimal GetReserveFinalRequiredAmount(int DealIpdRunId, string UserName);
    }
}
