﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW.CB
{
    public interface IReserveFundService
    {
        DataTable GetReserveFund(IPDFeedParam ipdFeedParam);

        DataTable GetReserveFundIpdDateHeader(IPDFeedParam ipdFeedParam);
    }
}
