﻿using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.Interface.CW.CB
{
    public interface ILedgersFundDataService
    {
        DataTable GetRevenueLedger(IPDFeedParam ipdFeedParam);

        DataTable GetPrincipalLedger(IPDFeedParam ipdFeedParam);

        DataTable GetPaymentLedger(IPDFeedParam ipdFeedParam);

        DataTable GetMaturingLoansLedger(IPDFeedParam ipdFeedParam);

        DataTable GetCapitalAccountLedger(IPDFeedParam ipdFeedParam);
    }
}
