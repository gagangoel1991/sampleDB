﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.CB
{
    public interface ICouponPaymentDataService
    {
        List<CouponPaymentEntity> GetCouponPaymentFund(IPDFeedParam ipdFeedParam);
    }
}
