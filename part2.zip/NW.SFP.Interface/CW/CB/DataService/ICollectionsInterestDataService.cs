﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.CB
{
    public interface ICollectionsInterestDataService
    {
        public List<CollectionsEntity> GetCollectionData(int DealIpdRunId, string UserName);
    }
}
