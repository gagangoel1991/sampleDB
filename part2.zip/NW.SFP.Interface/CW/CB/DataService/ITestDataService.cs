﻿using NW.SFP.Message.CB;
using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.Interface.CW.CB
{
    public interface ITestDataService
    {
        DataTable GetTestDataSummary(IPDFeedParam ipdFeedParam);

        DataTable GetTestData(IPDFeedParam ipdFeedParam, string testTypeName);
    }
}
