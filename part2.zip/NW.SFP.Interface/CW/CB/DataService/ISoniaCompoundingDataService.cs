﻿using NW.SFP.Message.CB;
using System;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.CB
{
    public interface ISoniaCompoundingDataService
    {
        public List<SoniaCompoundingSummaryEntity> GetSoniaCompoundingSummary(int dealId, int ipdRunId, string UserName);
        public List<dynamic> GetSoniaCompoundingData(DateTime accrualStartDate, DateTime accrualEndDate, string UserName);

    }
}
