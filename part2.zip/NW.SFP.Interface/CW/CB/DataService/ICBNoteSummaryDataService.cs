﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW.CB
{
    public interface ICBNoteSummaryDataService
    {
        CBNoteSummary GetNoteSummary(IPDFeedParam ipdFeedParam);
    }
}
