﻿using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.CB
{
    public interface ISoniaCompoundingController
    {
        public List<SoniaCompoundingSummaryEntity> GetSoniaCompoundingSummary(int dealId, int ipdRunId);
    }
}
