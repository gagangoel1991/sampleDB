﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW.CB
{
    public interface ICBNoteSummaryController
    {
        CBNoteSummary GetNoteSummary(int dealId, int ipdRunId);
    }
}
