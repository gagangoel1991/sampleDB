﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.CB
{
    public interface IDealSwapController
    {
        public List<DealSwapEntity> GetDealSwapData(int dealId, int ipdRunId);
    }
}
