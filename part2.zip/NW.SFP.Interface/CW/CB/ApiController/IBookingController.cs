﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.Interface.CW.CB
{
    public interface IBookingController
    {
        public List<BookingTradesEntity> GetBookingTradesData(int dealId, int ipdRunId);

    }
}
