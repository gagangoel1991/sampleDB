﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.CB
{
    public interface IFundsController
    {
        List<SwapCollateralEntity> GetSwapCollateral(int dealId, int ipdRunId);

        List<ReserveFundEntity> GetReserveFund(int dealId, int ipdRunId);

        List<PreMaturityLiquidityEntity> GetPreMaturityLiquidityFund(int dealId, int ipdRunId);

        List<CouponPaymentEntity> GetCouponPaymentFund(int dealId, int ipdRunId);

        List<RevenueLedgerFund> GetRevenueLedger(int dealId, int ipdRunId);
    }
}
