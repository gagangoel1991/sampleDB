﻿using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.Interface.CW
{
    public interface IDataLoadDataService
    {
        bool ProcessDataLoad(string loadType, string asAtDate, string userName);

        DataTable GetDataLoadDates();

    }
}
