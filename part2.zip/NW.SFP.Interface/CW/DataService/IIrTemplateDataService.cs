﻿namespace NW.SFP.Interface.CW
{
    
    using System.Collections.Generic;
    using System.Data;
    using NW.SFP.Message.CW;

    public interface IIrTemplateDataService
    {
        IList<IrTemplateEntity> GetTemplateList(int assetClassId, string ReportTypeName = "");

        IrTemplateEntity GetTemplateDetail(int ReportLayoutId, string UserName, string ReportTypeName = "");

        int Save(IrTemplateEntity reportLayout, string UserName, int assetClassId, string ReportTypeName = "");

        int Delete(int ReportLayoutId, string UserName);
    }
}
