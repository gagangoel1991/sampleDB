﻿using NW.SFP.Message.CW.IpdRunProcess;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IRatingUploadDataService
    {
        public IList<DealIpdDateEntity> GetDealIpdDates();
        public IList<RatingMasterData> GetRatingMasterData(int DealId);
        public int SaveUserRatingData(RatingFileUpload ratingFileUpload);
        public IList<RatingListingData> GetRatingListingData();
        public RatingSavedData GetUserRatingSavedData(int userRatingFileUploadDetailId);
        public bool UploadRatingDataRecordExist(RatingFileUpload ratingFileUpload);
        public int DeleteRatingData(int userRatingFileUploadDetailId, string LoggedInUserNamed);        
    }
}
