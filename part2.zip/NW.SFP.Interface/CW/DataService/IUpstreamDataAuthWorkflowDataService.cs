﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IUpstreamDataAuthWorkflowDataService
    {

        int ManageUpstreamDataAuthWorkflow(IPDFeedParam upstreamDataWorkflowEntity);

        IPDFeedParam GetUpstreamDataAuthWorkflowStatus(IPDFeedParam upstreamDataWorkflowEntity);
    }
}
