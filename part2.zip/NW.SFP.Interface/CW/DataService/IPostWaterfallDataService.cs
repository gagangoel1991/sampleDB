﻿using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
  public interface IPostWaterfallDataService
    {
        
        public List<PostWaterfallEntity> PostWaterfallOutputFileData();


        
    }
}
