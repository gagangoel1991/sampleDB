﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
    public interface ICashLadderDataService
    {
        /// <summary>
        /// This will return the cash ladder data
        /// </summary>
        /// <returns></returns>
        CashLadder GetCashLadderData(IPDFeedParam ipdFeedParam);

        int SaveCashLadderData(UpdateCashLadderEntity objUpdateCashLadderEntity, string loggedInUser);
    }
}
