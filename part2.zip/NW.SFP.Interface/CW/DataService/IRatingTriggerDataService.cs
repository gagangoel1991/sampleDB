﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface IRatingTriggerDataService
    {
        public List<RatingTriggerEntity> GetRatingTriggers(IPDFeedParam iPDFeedParam);

        public List<RatingTriggerEntity> GetSwapRatingTriggers(IPDFeedParam iPDFeedParam);
    }
}
