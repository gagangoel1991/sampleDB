﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.Interface.CW
{
    public interface IBookingIPDDataService
    {
        List<BookingEntity> GetBookingsIPDData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingNwbFoFeesData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingNwbFoLdData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingLLPMoFeesData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingLoansAndDepositsData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingSwapSummaryData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingReconData(IPDFeedParam ipdFeedParam);
        DataTable GetBookingReconAnalysisTabData(IPDFeedParam ipdFeedParam);

        bool ProcessBookingData(IPDFeedParam ipdFeedParam);
    }
}
