﻿namespace NW.SFP.Interface.CW
{
    
    using System.Collections.Generic;
    using System.Data;
    using NW.SFP.Message.CW;

    public interface IStratDealTypeDataService
    {
        IEnumerable<StratDealType> GetDealTypeList(int StratId, string UserName);

    }

}
