﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface INonRatingTriggerDataService
    {
        List<NonRatingTriggerEntity> GetNonRatingTriggers(IPDFeedParam iPDFeedParam);

        int SaveNonRatingTrigger(NonRatingTriggerEntity nonRatingTriggerEntity);

        int ResetNontRatingTrigger(int dealId, int ipdRunId, string loggedInUser);

        int ResetTriggersConditions(int ipdRunId, string loggedInUser);
    }
}
