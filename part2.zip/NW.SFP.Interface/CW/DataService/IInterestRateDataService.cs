﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface IInterestRateDataService
    {
        InterestRate GetInterestRateData(IPDFeedParam ipdFeedParam);

        int SaveInterestRate(InterestRateEntity interestRateEntity, string loggedInUser);
    }
}
