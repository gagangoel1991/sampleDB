﻿using NW.SFP.Message.CW;
using System.Collections.Generic;


namespace NW.SFP.Interface.CW.DataService
{
    public interface IDailyCollectionDataService
    {
        /// <summary>
        /// This will return the Daily Collection Entity data
        /// </summary>
        /// <returns></returns>
        IList<DailyCollectionEntity> GetDailyCollectionData(IPDFeedParam ipdFeedParam);

        int SaveDailyCollectionData(DailyCollectionEntity dailyCollectionEntity, string user);

        IList<DailyCollectionEntity> GetSourceCollectionData(IPDFeedParam ipdFeedParam);

        IList<string> GetColumns(IPDFeedParam ipdFeedParam);
    }
}
