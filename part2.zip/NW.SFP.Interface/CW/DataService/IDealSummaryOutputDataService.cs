﻿using ClosedXML.Excel;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW
{
  public  interface IDealSummaryOutputDataService
    {

        List<DealSummaryDataEntity> GetDealSummaryOutputData(DataTable ListCollDate, string dealName, string dealCategoryName,string viewType, string loggedInUser);

        int SaveDealSummayAdjustment(List<DealSummarySaveAdjustmentModel> dealSummarySaveAdjustmentModel, string loggedInUser);

        List<DealSummaryDataEntity> GetDealSummaryAuditData(DataTable ListCollDate, string dealName,string loggedInUser);

        int SaveDealSummayAudit(DealSummarySaveAuditModel dealSummarySaveAuditModel, string loggedInUser);

        int ManageDealSummaryAuditAuthWorkflow(IPDFeedParam authWorkflowEntity);

        public List<DateTime> GetCollectionDateList(DateTime? asAtDate, string dealName,string dateType, string loggedInUser);

        int GetLoadDailyEstimationDealSummary(string asAtDate, string dealName, bool isEstimationData,string loggedInUser);
        int GetLoadDeflagAdjustmentDealSummary(string asAtDate, string dealName, int isDeFlagAdjustment, string loggedInUser);

        List<bool> GetDealSummaryLoadDataEstimation(DataTable ListCollDate, string dealName, string loggedInUser);

        
        int IsActualGMSDataAvaliable(string asAtDate, string dealName, bool isEstimationData, string loggedInUser);



    }
}
