﻿using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.Interface.CW
{
    public interface IPdlSummaryDataService
    {
        DataTable GetPDLSummaryData(IPDFeedParam feedParms);
    }
}
