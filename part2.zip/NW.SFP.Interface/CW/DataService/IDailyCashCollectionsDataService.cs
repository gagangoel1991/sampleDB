﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDailyCashCollectionsDataService
    {
        DataTable GetDailyCashEstimationData(string dealName, string asAtDate, string loggedInUserName);

        DateTime GetCollectionDate(string asAtDate, string dealName, string loggedInUserName);

        DataTable GetDealCollectionHistoryData(DailyCollectionHistoryParam dailyCollectionHistParam, string userName);
        
        DataTable GetPNRSplitData(string asAtDate, string adviceDate, string dealName, string userName);

        DataTable GetDealDailyCollectionData(string asAtDate, string userName);
        DataTable GetCBOutputData(DailyCollectionHistoryParam cbOutputParam, string userName);
        DataTable GetEmailDataForCollectionOutput(string emailType, string userName);
    }
}
