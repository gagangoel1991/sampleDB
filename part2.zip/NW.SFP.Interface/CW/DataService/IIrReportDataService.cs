﻿namespace NW.SFP.Interface.CW
{
    
    using System.Collections.Generic;
    using System.Data;
    using NW.SFP.Message.CW;
    using NW.SFP.Message.CW.IR;

    public interface IIrReportDataService
    {
        IEnumerable<ExcelUploadEntity> GetExcelReportList(string DealName, string AsAtDate);
       

        IEnumerable<ExcelUploadEntity> GetExcelReportList(int dealIrConfigId, string AsAtDate, string ReportTypeName);

        DataTable GetIrStratData(string AsAtDate, string DealName, int FieldId, string StratName, string loggedInUserName, string ReportTypeName, int AssetId = 1);

        IEnumerable<ExcelUploadEntity> GetExcelPostWFControlList(string DealName, string AsAtDate);

        public IR_Config GetDealIRConfigByDealId(int DealId, string ReportTypeName);

        void CheckAndLoadMortgageFieldData(string DealName, string AsAtDate);
    }
}
