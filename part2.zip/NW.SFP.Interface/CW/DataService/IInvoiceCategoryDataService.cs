﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IInvoiceCategoryDataService
    {
        /// <summary>
        /// This will return the invoice categories based on type
        /// </summary>
        /// <param name="invoiceCategoryTypeId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryTypeId, string userName);
    }
}
