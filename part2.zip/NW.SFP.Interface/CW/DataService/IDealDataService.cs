﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDealDataService
    {

        /// <summary>
        /// This will return the deal details 
        /// </summary>
        /// <returns></returns>
        IList<DealEntity> GetDealList(string loggedInUser, int assetClassId);


        int SaveDeal(DealEntity dealEntity, int assetClassId);

        DealEntity GetDeal(int dealId, string userName);

        int DeleteDeal(int dealId, string userName);

        int ManageDealAuthWorkflow(IPDFeedParam authWorkflowEntity);

        int DealCollapseSentforAuthorization(DealEntity dealEntity);

        int GetValidateCollapseDeal(int dealId, string userName);

        string GetDealLatestAuthorisedIpdDate(int dealId, string userName);

        public List<DealSecurityItemsList> getDealSecurityListItems(int dealId, string userName);
    }
}
