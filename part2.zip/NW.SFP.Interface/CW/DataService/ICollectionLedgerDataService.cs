﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
    public interface ICollectionLedgerDataService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        CollectionLedger GetCollectionLedgerData(IPDFeedParam ipdFeedParam);
        /// <summary>
        ///  
        /// </summary>
        /// <returns></returns>
        int UpdateCollectionLedgerData(UpdateCollectionLedgerEntity objUpdateCollectionLedgerEntity, string loggedInUser);
    }
}
