﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.Email;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IEmailConfigDataService
    {
        IList<EmailConfigEntity> GetEmailConfigList(string loggedInUser);


        int SaveEmailConfig(EmailConfigEntity emailConfigEntity);

        EmailConfigEntity GetEmailConfig(int emailConfigId, string userName);
        int DeleteEmailConfig(int emailConfigId, string userName);
    }
}
