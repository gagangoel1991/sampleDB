﻿namespace NW.SFP.Interface.CW
{
    
    using System.Collections.Generic;
    using System.Data;
    using NW.SFP.Message.CW;

    public interface IStratConfigtDataService
    {
        IEnumerable<StratCriteriaEntity> GetAssetStratCriteriaList(int StratId, string UserName);

        StratCriteriaEntity Save(StratCriteriaEntity stratConfig, string UserName, string ReportTypeName);

        StratCriteriaEntity Update(StratCriteriaEntity stratConfig, string UserName);

        bool Delete(int StratId, string Username);

    }
}
