﻿using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IDealIpdControlsDataService
    {
        public StormVsSfpEntity StormVsSfp(int dealId, int ipdRunId,string loggedInUser);
        public DataSet StormVsSfpExcelData(int dealId, int ipdRunId, string loggedInUser);
    }
}
