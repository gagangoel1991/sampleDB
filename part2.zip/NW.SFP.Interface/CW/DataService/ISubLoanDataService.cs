﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface ISubloanDataService
    {
        Subloan GetSubloan(IPDFeedParam iPDFeedParam);
    }
}
