﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface ICounterpartyRatingDataService
    {
        CounterpartyRatingEntity GetCounterpartyRatingData(IPDFeedParam ipdFeedParam);

        int SaveCounterpartyRatingData(dynamic cpRatingEntity, string loggedInUser);

        int ResetCounterpartyRatingData(int ipdRunId, string loggedInUser);

        bool IsCPRatingEdited(int ipdRunId, string loggedInUser);
    }
}
