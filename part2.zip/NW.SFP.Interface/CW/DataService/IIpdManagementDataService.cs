﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IIpdManagementDataService
    {
       public IList<IpdManagementResultEntity> GetIpdMgmtDashboardData(string userName);
    }
}
