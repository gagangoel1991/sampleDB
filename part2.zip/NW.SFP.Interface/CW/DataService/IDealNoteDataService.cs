﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
  public interface IDealNoteDataService
    {
        /// <summary>
        /// This will return the deal details 
        /// </summary>
        /// <returns></returns>
        IList<DealNoteInfoEntity> GetDealNoteList(IPDFeedParam ipdFeedParam, string loggedInUser);

        int SaveDealNoteData(DealNoteInfoEntity dealNoteInfoEntity);

        int ManageDealNoteAuthWorkflow(IPDFeedParam authWorkflowEntity);

        int DealNoteSentforAuthorization(DealNoteInfoEntity dealNoteInfoEntity);
    }
}
