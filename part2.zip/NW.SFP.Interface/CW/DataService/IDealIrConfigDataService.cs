﻿using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IDealIrConfigDataService
    {
        /// <summary>
        /// This will return the Deal IR Config List
        /// </summary>
        /// <returns></returns>
        IList<DealIrConfigListEntity> GetDealIrConfigList(string loggedInUserName, string ReportTypeName, int AssetClassId);

        /// <summary>
        /// This will return the single Deal IR Config record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        DealIrConfigEntity GetDealIrConfig(int dealIrConfigId, string loggedInUser, string ReportTypeName, int AssetClassId = 1);

        /// <summary>
        /// This will delete the Deal IR Config record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <param name="loggedInUserName"></param>
        /// <returns></returns>
        int DeleteDealIrConfig(int dealIrConfigId, string loggedInUserName);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        List<IR_ConfigDealList> getIrConfigDealList(int dealIrConfigId, string loggedInUser, string ReportTypeName);

        /// <summary>
        /// 
        /// </summary>
        /// <returns></returns>
        List<IR_ConfigLayoutList> getIrConfigLayoutList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassID);


        List<IR_ConfigStartList> GetIrConfStartList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassId = 1);

        /// <summary>
        /// This will save the Deal Ir Config record.
        /// </summary>
        /// <param name="dealIrConfigData"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        int SaveDealIrConfig(DealIrConfigAddEditEntity dealIrConfigData, string loggedInUserName, string ReportTypeName, int AssetClassId);

        int ManageDealIRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity);
    }
}
