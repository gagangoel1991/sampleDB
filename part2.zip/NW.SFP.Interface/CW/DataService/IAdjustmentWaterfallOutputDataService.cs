﻿using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.Interface.CW
{
    public interface IAdjustmentWaterfallOutputDataService
    {
        /// <summary>
        /// this will return Adjustment output Waterfall data
        /// </summary>
        /// <returns></returns>
        IList<AdjustmentOutputEntity> GetAdjustmentRppOutputData(IPDFeedParam ipdFeedParam);

        IList<AdjustmentOutputEntity> GetAdjustmentPppOutputData(IPDFeedParam ipdFeedParam);
    }
}
