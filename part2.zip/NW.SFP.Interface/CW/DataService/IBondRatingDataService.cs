﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IBondRatingDataService
    {
        BondRating GetBondRatingData(IPDFeedParam ipdFeedParam);

        int SaveBondRatingData(dynamic bondRatingEntity, string loggedInUser);

        int ResetBondRatingData(int ipdRunId, string loggedInUser);

        bool IsBondRatingEdited(int ipdRunId, string loggedInUser);
    }
}
