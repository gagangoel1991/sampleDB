﻿using NW.SFP.Message.CW;

namespace NW.SFP.Interface.CW
{
    public interface INoteSummaryDataService
    {
        DealNoteSummary GetDealNoteSummary(IPDFeedParam ipdFeedParam);
    }
}
