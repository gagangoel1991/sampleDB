﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.Interface.CW
{
    public interface IBookingDataService
    {
        List<BookingTradesEntity> GetBookingTabData(IPDFeedParam ipdFeedParam);
    }
}
