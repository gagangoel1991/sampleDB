﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IAdjustmentWaterfallDataService
    {
        /// <summary>
        /// this will return Adjustment Principal Waterfall data
        /// </summary>
        /// <returns></returns>
        IList<AdjustmentWaterfallEntity> GetAdjustmentWaterfallData(IPDFeedParam ipdFeedParam);

        int SavePrincipalWaterfall(IEnumerable<AdjustmentWaterfallTypeEntity> adjustmentLineItem, string loggedInUser);
    }
}
