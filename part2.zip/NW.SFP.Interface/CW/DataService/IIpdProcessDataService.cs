﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IIpdProcessDataService
    {

    }
}
