﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IIrLookupDataService
    {
        /// <summary>
        /// This will return the Strats Master List based on strat type
        /// </summary>
        /// <param name="stratTypeId"></param>
        /// <param name="loggedInUserName"></param>
        /// <returns></returns>
        IList<StratLookup> GetStratLookup(int stratTypeId, string loggedInUserName);
    }
}
