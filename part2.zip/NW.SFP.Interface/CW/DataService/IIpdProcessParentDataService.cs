﻿using NW.SFP.Message.CW;
using System;

namespace NW.SFP.Interface.CW.DataService
{
    public interface IIpdProcessParentDataService
    {
        /// <summary>
        /// 
        /// </summary>
        /// <param name="ipdFeedParam"></param>
        /// <returns></returns>
        DealIpdBasicInfoEntity GetIpdProcessParentData(IPDFeedParam ipdFeedParam);

        int RunIPD(int dealIpdRunId, string userName);

        int InitiateIPD(int dealId, DateTime ipdDate, string userName);

        int ResetIPD(int dealId, DateTime ipdDate, string userName);
        int WithdrawIPD(IpdWorkflowEntity ipdWorkflowEntity, string userName);
        int SaveOverridedIRFile(OverrideIrEntity overrideIREntity, string UserName);
    }
}