﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Interface.CW
{
    public interface IInvoiceFacadeService
    {
        /// <summary>
        /// This will return the invoice category Type
        /// </summary>
        IList<InvoiceCategoryTypeEntity> GetInvoiceCategoryType(string loggedInUser);

        /// <summary>
        /// This will return the invoice categories based on type
        /// </summary>
        /// <param name="invoiceCategoryTypeId"></param>
        /// <returns></returns>
        IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryTypeId, string loggedInUser);

        /// <summary>
        /// This will return the invoice data based on the parameters
        /// </summary>
        /// <param name="invoiceParams"></param>
        /// <returns></returns>
        IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams, string loggedInUser);

        /// <summary>
        /// This will return the single invoice record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        InvoiceDataEntity GetInvoice(int invoiceId, string loggedInUser);

        /// <summary>
        /// This will remove the Invoice Record based on the parameter
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        int DeleteInvoiceData(int invoiceId, string loggedInUser);

        /// <summary>
        /// This will save the invoice data record.
        /// </summary>
        /// <param name="invoiceData"></param>
        /// <returns></returns>
        int SaveInvoiceData(InvoiceDataEntity invoiceData, string loggedInUser);

        /// <summary>
        /// IPD specific Invoice data
        /// </summary>
        /// <param name="iPDFeedParam"></param>
        /// <returns></returns>
        IList<InvoiceDataEntity> GetInvoiceIpdData(IPDFeedParam iPDFeedParam);

        decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate, string userName);
    }
}
