﻿using Microsoft.Extensions.Options;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.Report
{
  public  class InvestorReportService : IInvestorReportService
    {

        private readonly IInvestorReportDataService _investorReportDataService;
        private readonly IOptions<ReportSettings> _reportSettings;

        public InvestorReportService(IInvestorReportDataService InvestorReportDataService, IOptions<ReportSettings> reportSettings)
        {
            this._investorReportDataService = InvestorReportDataService;
            this._reportSettings = reportSettings;
        }

        public InvestorReportResultEntity GetInvestorReportFileName(int dealId, string ipdDate, string formatType)
        {
            return _investorReportDataService.GetInvestorReportFileName(dealId, ipdDate, formatType);
        }

        public InvestorReportResultEntity Save(InvestorReportResultEntity reportEntity, string UserName)
        {
            InvestorReportResultEntity reportDataEntity = this._investorReportDataService.Save(reportEntity, UserName);
            return reportDataEntity;
        }

    }
}
