﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Text;
using NW.SFP.Message.PS;
using System.Reflection;
using System.Linq;
using NW.SFP.Interface.Report.BusinessService;
using NW.SFP.Interface.Report.DataService;

namespace NW.SFP.BusinessService.Report
{
    public class NWReportsService: INWMReportsService
    {
        private readonly INWMReportsDataService  _iNWMReportsDataService;
        private readonly IOptions<ReportSettings> _reportSettings;
        public NWReportsService(INWMReportsDataService NWMReportsDataService, IOptions<ReportSettings> reportSettings)
        {
            this._iNWMReportsDataService = NWMReportsDataService;
            this._reportSettings = reportSettings;
        }
        
        public MemoryStream GenerateAssetReportData(DateTime AsAtDate, string loggedInUserName)
        {
            return ExcelSheetForNWMAsset(_iNWMReportsDataService.GenerateAssestReportData(AsAtDate, loggedInUserName));
            
        }
        private MemoryStream ExcelSheetForNWMAsset(List<AssetRegisterReportEntity> nwmasset)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                string TabName;

                TabName = $" Asset_Register";
               
                var worksheetExposure = workbook.Worksheets.Add(TabName);
                FillAssetRegisterExposureReportWorksheet(nwmasset, worksheetExposure);
                workbook.SaveAs(stream);
                return stream;
            }

        }
        private void FillAssetRegisterExposureReportWorksheet(List<AssetRegisterReportEntity> nwmasset, IXLWorksheet worksheet)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForAssetRegisterReport())
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Fill.BackgroundColor = XLColor.FromArgb(198, 89, 17);
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            if (nwmasset != null)
            {
                foreach (var data in nwmasset)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 1).Value = data.AsAtDate;
                    worksheet.Cell(currentRow, 2).Value = data.FacilityCurrencyConcatenationString;
                    worksheet.Cell(currentRow, 3).Value = data.FacilityCurrencyCISConcatenationString;
                    worksheet.Cell(currentRow, 4).Value = data.DealName;
                    worksheet.Cell(currentRow, 5).SetValue(data.FacilityFCN);
                    worksheet.Cell(currentRow, 6).SetValue(data.FacilityPrismId);
                    worksheet.Cell(currentRow, 7).Value = data.FacilityName;
                    worksheet.Cell(currentRow, 8).SetValue(data.PrismIDorFCNid); 
                    worksheet.Cell(currentRow, 9).Value = data.FacilityCcy;
                    worksheet.Cell(currentRow, 10).Value = data.OSTCcy;
                    worksheet.Cell(currentRow, 11).Value = data.FacilityType;
                    worksheet.Cell(currentRow, 12).Value = data.Book;
                    worksheet.Cell(currentRow, 13).Value = data.HostBankNetCommitment;
                    worksheet.Cell(currentRow, 14).Value = data.HostBankNetOutstanding;
                    worksheet.Cell(currentRow, 15).Value = data.DrawnEUR;
                    worksheet.Cell(currentRow, 16).Value = data.DrawnGBP;
                    worksheet.Cell(currentRow, 17).Value = data.DrawnUSD;
                    worksheet.Cell(currentRow, 18).Value = data.DrawnJPY;
                    worksheet.Cell(currentRow, 19).Value = data.RelationsPrimaryKey;
                    worksheet.Cell(currentRow, 20).Value = data.TradeAllocated;
                    worksheet.Cell(currentRow, 21).Value = data.FacilityCurrencyConcatenationString;
                    worksheet.Cell(currentRow, 22).Value = data.PercentAllocatedToTrade;
                    worksheet.Cell(currentRow, 23).Value = data.EncumberedIndicator;
                    worksheet.Cell(currentRow, 24).Value = data.EncumberedCCY;
                    worksheet.Cell(currentRow, 25).Value = data.EncumberedGBP;
                    worksheet.Cell(currentRow, 26).Value = data.EncumberedEUR;
                    worksheet.Cell(currentRow, 27).Value = data.OSTHostBankNet;
                    worksheet.Cell(currentRow, 28).Value = data.EncumberedUSD;
                    worksheet.Cell(currentRow, 29).Value = data.EncumberedJPY;
                    worksheet.Cell(currentRow, 30).Value = data.AvailableCCY;
                    worksheet.Cell(currentRow, 31).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 31).Value = data.AgreementDate;
                    worksheet.Cell(currentRow, 32).Value = data.AvailableGBP;
                    worksheet.Cell(currentRow, 33).Value = data.AvailableEUR;
                    worksheet.Cell(currentRow, 34).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 34).Value = data.FinalMaturityDate;
                    worksheet.Cell(currentRow, 35).Value = data.AvailableUSD;
                    worksheet.Cell(currentRow, 36).Value = data.AvailableJPY;
                    worksheet.Cell(currentRow, 37).Style.DateFormat.Format = "dd/mm/yyyy HH:mm:ss";
                    worksheet.Cell(currentRow, 37).Value = data.AllocationTimestamp;
                    worksheet.Cell(currentRow, 38).Value = data.AllocationUser;
                    worksheet.Cell(currentRow, 39).Value = data.AllocatedTo;
                    worksheet.Cell(currentRow, 40).Value = data.ISIN;
                    worksheet.Cell(currentRow, 41).Value = data.CollateralAssetCompanyNucleusId;
                    worksheet.Cell(currentRow, 42).Value = data.TradeGroup;
                    worksheet.Cell(currentRow, 43).Value = data.VAndRA;
                    worksheet.Cell(currentRow, 44).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 44).Value = data.ScheduledMaturity;
                    worksheet.Cell(currentRow, 45).Value = data.ReportingTemplate;
                    worksheet.Cell(currentRow, 46).Value = data.BorrowerCIS;
                    worksheet.Cell(currentRow, 47).Value = data.BorrowerName;
                    worksheet.Cell(currentRow, 48).Value = data.CountryOfResidence;
                    worksheet.Cell(currentRow, 49).Value = data.CountryOfIncorporation;
                    worksheet.Cell(currentRow, 50).Value = data.CountryOfRisk;
                    worksheet.Cell(currentRow, 51).Value = data.Agent;
                    worksheet.Cell(currentRow, 52).Value = data.CompanyNumber;
                    worksheet.Cell(currentRow, 53).Value = data.Lev1;
                    worksheet.Cell(currentRow, 54).Value = data.Lev2;
                    worksheet.Cell(currentRow, 55).Value = data.Lev3;
                    worksheet.Cell(currentRow, 56).Value = data.Sponsor;
                    worksheet.Cell(currentRow, 57).Value = data.BorrowerInternalRating;
                    worksheet.Cell(currentRow, 58).Value = data.BorrowerInternalRatingImplied;
                    worksheet.Cell(currentRow, 59).Value = data.GradingScale;
                    worksheet.Cell(currentRow, 60).Value = data.GradingModel;
                    worksheet.Cell(currentRow, 61).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 61).Value = data.RatingApprovalDate;
                    worksheet.Cell(currentRow, 62).Value = data.IBCALongTermRating;
                    worksheet.Cell(currentRow, 63).Value = data.UltimateRiskParentCISCode;
                    worksheet.Cell(currentRow, 64).Value = data.MoodysLongTermCPRatingGrdm;
                    worksheet.Cell(currentRow, 65).Value = data.SPLongTermRatingGrdm;
                    worksheet.Cell(currentRow, 66).Value = data.DoTEligible;
                    worksheet.Cell(currentRow, 67).Value = data.ECBEligible;
                    worksheet.Cell(currentRow, 68).Value = data.NoBorrowerSetOff;
                    worksheet.Cell(currentRow, 69).Value = data.ContractLaw;
                    worksheet.Cell(currentRow, 70).Value = data.W8Sent;
                    worksheet.Cell(currentRow, 71).Value = data.FacilityWarnings;
                    worksheet.Cell(currentRow, 72).Value = data.EligibilityComments1;
                    worksheet.Cell(currentRow, 73).Value = data.EligibilityComments2;
                    worksheet.Cell(currentRow, 74).Value = data.EligibilityComments3;
                    worksheet.Cell(currentRow, 75).Value = data.FacilityEncumberedOutsideProcess;
                    worksheet.Cell(currentRow, 76).Value = data.TimeToLegalMaturity;
                    worksheet.Cell(currentRow, 77).Value = data.TimeToLegalMaturityBucket;
                    worksheet.Cell(currentRow, 78).Value = data.IneligibilityExceptions;
                    worksheet.Cell(currentRow, 79).Value = data.Entity;
                    worksheet.Cell(currentRow, 80).Value = data.CountryOfTaxClassification;
                    worksheet.Cell(currentRow, 81).Value = data.CountryOfTaxNote;
                    worksheet.Cell(currentRow, 82).Value = data.IneligibilityValidation;
                    worksheet.Cell(currentRow, 83).Value = data.AssessmentNeeded;
                    worksheet.Cell(currentRow, 84).Value = data.ConditionPrecedents;
                    worksheet.Cell(currentRow, 85).Value = data.SNPEligibility;
                    worksheet.Cell(currentRow, 86).Value = data.RSFUnencumbered;
                    worksheet.Cell(currentRow, 87).Value = data.TopCoCISCodeEncrypted;
                    worksheet.Cell(currentRow, 88).Value = data.LegalEntityCISCodeEncrypted;
                    worksheet.Cell(currentRow, 89).Value = data.ClientClassification;
                    worksheet.Cell(currentRow, 90).Value = data.SeniorityRank;
                    worksheet.Cell(currentRow, 91).Value = data.FacilityInternalRating;
                    worksheet.Cell(currentRow, 92).Value = data.DeskDesc;
                    worksheet.Cell(currentRow, 93).Value = data.SubDeskDesc;
                    worksheet.Cell(currentRow, 94).Value = data.CostCentreName;
                    worksheet.Cell(currentRow, 95).Value = data.CostCentreDesc;
                    worksheet.Cell(currentRow, 96).Value = data.CountryOfBalanceSheetLocation;
                    worksheet.Cell(currentRow, 97).Value = data.TradingBankingIndicator;
                    worksheet.Cell(currentRow, 98).Value = data.DivisionName;
                    worksheet.Cell(currentRow, 99).Value = data.BusinessConsolidation1Desc;
                    worksheet.Cell(currentRow, 100).Value = data.BusinessConsolidation2Desc;
                    worksheet.Cell(currentRow, 101).Value = data.BusinessConsolidation3Desc;
                    worksheet.Cell(currentRow, 102).Value = data.BusinessConsolidation4Desc;
                    worksheet.Cell(currentRow, 103).Value = data.BusinessConsolidation5Desc;
                    worksheet.Cell(currentRow, 104).Value = data.SicCode;
					worksheet.Cell(currentRow, 105).Value = data.ContractualSeniority;
                }
            }
            setHeaderFormat(worksheet);
        }
       
        

        private List<string> GetHeaderDisplayNameForAssetRegisterReport()
        {
            var item = new AssetRegisterReportEntity();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> assetRegisterHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                assetRegisterHeader.Add(GetDisplayName(type, info, false));
            }
            return assetRegisterHeader;
        }
        private static String GetDisplayName(Type type, PropertyInfo info, bool hasMetaDataAttribute, string splitChar = "", int nameItemIndex = -1)
        {
            string DisplayName = "";
            if (!hasMetaDataAttribute)
            {
                object[] attributes = info.GetCustomAttributes(typeof(DisplayAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var displayName = (DisplayAttribute)attributes[0];
                    DisplayName = displayName.Name;
                }
                else
                {
                    DisplayName = info.Name;
                }
            }
            else
            {
                PropertyDescriptor propDesc = TypeDescriptor.GetProperties(type).Find(info.Name, true);
                DisplayNameAttribute displayAttribute =
                    propDesc.Attributes.OfType<DisplayNameAttribute>().FirstOrDefault();
                DisplayName = displayAttribute != null ? displayAttribute.DisplayName : null;
            }

            if (!string.IsNullOrEmpty(splitChar) && nameItemIndex > -1)
            {
                string[] displayNameAry = DisplayName.Split(splitChar);

                if (displayNameAry.Count() > nameItemIndex)
                {
                    DisplayName = displayNameAry[nameItemIndex];
                }
            }

            return DisplayName;
        }

        private static void setHeaderFormat(IXLWorksheet worksheet, int RowID = 1)
        {
            worksheet.Row(RowID).Style.Font.SetBold();
            worksheet.Columns().AdjustToContents();
            worksheet.Row(RowID).Height = 35;
            worksheet.Row(RowID).Style.Font.FontColor = XLColor.White;
            worksheet.Row(RowID).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
            worksheet.Row(RowID).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
        }

        public MemoryStream GenerateLoansOutstandingReportData(DateTime AsAtDate, string loggedInUserName)
        {
            return ExcelSheetForNWMLoansOutstanding(_iNWMReportsDataService.GenerateLoansOutstandingReportData(AsAtDate, loggedInUserName));

        }
        private MemoryStream ExcelSheetForNWMLoansOutstanding(List<LoansOutstandingReportEntity> nwmout)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                string TabName;

                TabName = $" LoansOutstanding";

                var worksheetExposure = workbook.Worksheets.Add(TabName);
                FillLoansOutstandingExposureReportWorksheet(nwmout, worksheetExposure);
                workbook.SaveAs(stream);
                return stream;
            }

        }
        private void FillLoansOutstandingExposureReportWorksheet(List<LoansOutstandingReportEntity> nwmout, IXLWorksheet worksheet)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForLoansOutstandingReport())
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Fill.BackgroundColor = XLColor.FromArgb(198, 89, 17);
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            if (nwmout != null)
            {
                foreach (var data in nwmout)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.FacilityCurrencyConcatenationString;
                    worksheet.Cell(currentRow, 2).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 2).Value = data.AsAtDate;
                    worksheet.Cell(currentRow, 3).Value = data.PrimaryKey;
                    worksheet.Cell(currentRow, 4).Value = data.FacilityCurrencyCISConcatenationString;
                    worksheet.Cell(currentRow, 5).Value = data.DealName;
                    worksheet.Cell(currentRow, 6).SetValue(data.FacilityFCN);
                    worksheet.Cell(currentRow, 7).SetValue(data.FacilityName);
                    worksheet.Cell(currentRow, 8).SetValue(data.PrismIDorFCNid);
                    worksheet.Cell(currentRow, 9).SetValue(data.FacilityPrismId);
                    worksheet.Cell(currentRow, 10).Value = data.FacilityStatus;
                    worksheet.Cell(currentRow, 11).Value = data.FacilityType;
                    worksheet.Cell(currentRow, 12).SetValue(data.FacilityANSIId);
                    worksheet.Cell(currentRow, 13).Value = data.LiqRiskBookCode;
                    worksheet.Cell(currentRow, 14).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 14).Value = data.AgreementDate;
                    worksheet.Cell(currentRow, 15).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 15).Value = data.EffectiveDate;
                    worksheet.Cell(currentRow, 16).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 16).Value = data.ExpiryDate;
                    worksheet.Cell(currentRow, 17).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 17).Value = data.FinalMaturityDate;
                    worksheet.Cell(currentRow, 18).Value = data.FacilityCcy;
                    worksheet.Cell(currentRow, 19).Value = data.MidFactorOSTCcyEUR;
                    worksheet.Cell(currentRow, 20).Value = data.DrawnEUR;
                    worksheet.Cell(currentRow, 21).Value = data.GlobalCurrentCommitment;
                    worksheet.Cell(currentRow, 22).Value = data.MidFactorOSTCcyGBP;
                    worksheet.Cell(currentRow, 23).Value = data.GlobalOutstandingCommitment;
                    worksheet.Cell(currentRow, 24).Value = data.DrawnGBP;
                    worksheet.Cell(currentRow, 25).Value = data.GlobalAvailabletoDraw;
                    worksheet.Cell(currentRow, 26).Value = data.MidFactorOSTCcyUSD;
                    worksheet.Cell(currentRow, 27).Value = data.DrawnUSD;
                    worksheet.Cell(currentRow, 28).Value = data.MidFactorOSTCcyJPY;
                    worksheet.Cell(currentRow, 29).Value = data.DrawnJPY;
                    worksheet.Cell(currentRow, 30).Value = data.HostBankNetCommitment;
                    worksheet.Cell(currentRow, 31).Value = data.HostBankNetOutstanding;
                    worksheet.Cell(currentRow, 32).Value = data.OSTAlias;
                    worksheet.Cell(currentRow, 33).Value = data.CurrentAmount;
                    worksheet.Cell(currentRow, 34).Value = data.OSTInternalId;
                    worksheet.Cell(currentRow, 35).Value = data.OriginalAmount;
                    worksheet.Cell(currentRow, 36).Value = data.MatchedFundedAmount;
                    worksheet.Cell(currentRow, 37).Value = data.OSTType;
                    worksheet.Cell(currentRow, 38).Value = data.NonMatchFundedAmount;
                    worksheet.Cell(currentRow, 39).Value = data.DiscountAmount;
                    worksheet.Cell(currentRow, 40).Value = data.OSTPricingOption;
                    worksheet.Cell(currentRow, 41).Value = data.OSTSource;
                    worksheet.Cell(currentRow, 42).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 42).Value = data.OSTEffectiveDate;
                    worksheet.Cell(currentRow, 43).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 43).Value = data.OSTRepricingDate;
                    worksheet.Cell(currentRow, 44).Value = data.OSTRePricingFreq;
                    worksheet.Cell(currentRow, 45).Value = data.OSTBaseRate;
                    worksheet.Cell(currentRow, 46).Value = data.OSTSpread;
                    worksheet.Cell(currentRow, 47).Value = data.FxToFac;
                    worksheet.Cell(currentRow, 48).Value = data.OSTAllInRate;
                    worksheet.Cell(currentRow, 49).Value = data.CSPLID;
                    worksheet.Cell(currentRow, 50).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 50).Value = data.OSTSpreadStartDate;
                    worksheet.Cell(currentRow, 51).Value = data.PerfStatusCode;
                    worksheet.Cell(currentRow, 52).Value = data.HolidayCalendars;
                    worksheet.Cell(currentRow, 53).Value = data.OSTCcy;
                    worksheet.Cell(currentRow, 54).Value = data.CycleFrequencyPeriod;
                    worksheet.Cell(currentRow, 55).Value = data.CycleFrequencyPeriodMultiplier;
                    worksheet.Cell(currentRow, 56).Value = data.OSTHostBankNet;
                    worksheet.Cell(currentRow, 57).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 57).Value = data.CurrentCycleStart;
                    worksheet.Cell(currentRow, 58).Value = data.Book;
                    worksheet.Cell(currentRow, 59).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 59).Value = data.CurrentCycleEndDate;
                    worksheet.Cell(currentRow, 60).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 60).Value = data.AdjustedDueDate;
                    worksheet.Cell(currentRow, 61).Value = data.EndDateRuleDesc;
                    worksheet.Cell(currentRow, 62).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 62).Value = data.ActualDueDate;
                    worksheet.Cell(currentRow, 63).Value = data.RateBasis;
                    worksheet.Cell(currentRow, 64).Value = data.BorrowerLinkingString;
                    worksheet.Cell(currentRow, 65).Value = data.BorrowerRID;
                    worksheet.Cell(currentRow, 66).Value = data.BorrowerCIS;
                    worksheet.Cell(currentRow, 67).Value = data.BorrowerName;
                    worksheet.Cell(currentRow, 68).Value = data.CountryOfResidence;
                    worksheet.Cell(currentRow, 69).Value = data.CountryOfIncorporation;
                    worksheet.Cell(currentRow, 70).Value = data.CountryOfRisk;
                    worksheet.Cell(currentRow, 71).Value = data.Agent;
                    worksheet.Cell(currentRow, 72).Value = data.CompanyNumber;
                    worksheet.Cell(currentRow, 73).Value = data.Lev1;
                    worksheet.Cell(currentRow, 74).Value = data.Lev2;
                    worksheet.Cell(currentRow, 75).Value = data.Lev3;
                    worksheet.Cell(currentRow, 76).Value = data.CountryOfCollateral;
                    worksheet.Cell(currentRow, 77).Value = data.AssetTypeMB;
                    worksheet.Cell(currentRow, 78).Value = data.RatingSource;
                    worksheet.Cell(currentRow, 79).Value = data.IsConduit;
                    worksheet.Cell(currentRow, 80).Value = data.Format;
                    worksheet.Cell(currentRow, 81).Value = data.RatingSP;
                    worksheet.Cell(currentRow, 82).Value = data.RatingMD;
                    worksheet.Cell(currentRow, 83).Value = data.RatingFT;
                    worksheet.Cell(currentRow, 84).Value = data.RatingDBRS;
                    worksheet.Cell(currentRow, 85).Value = data.RatingARC;
                    worksheet.Cell(currentRow, 86).Value = data.PreclearedMedio;
                    worksheet.Cell(currentRow, 87).Value = data.PreclearableMedio;
                    worksheet.Cell(currentRow, 88).Value = data.Sponsor;
                    worksheet.Cell(currentRow, 89).Value = data.BorrowerInternalRating;
                    worksheet.Cell(currentRow, 90).Value = data.BorrowerInternalRatingImplied;
                    worksheet.Cell(currentRow, 91).Value = data.GradingScaleCode;
                    worksheet.Cell(currentRow, 92).Value = data.GradingModelCode;
                    worksheet.Cell(currentRow, 93).Value = data.GradingScale;
                    worksheet.Cell(currentRow, 94).Value = data.GradingModel;
                    worksheet.Cell(currentRow, 95).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 95).Value = data.RatingApprovalDate;
                    worksheet.Cell(currentRow, 96).Value = data.IBCAShortTermRating;
                    worksheet.Cell(currentRow, 97).Value = data.IBCALongTermRating;
                    worksheet.Cell(currentRow, 98).Value = data.UltimateRiskParentCISCode;
                    worksheet.Cell(currentRow, 99).Value = data.MoodysLongTermCPRatingGrdm;
                    worksheet.Cell(currentRow, 100).Value = data.MoodysSTCRatingGrdm;
                    worksheet.Cell(currentRow, 101).Value = data.SPShortTermRatingGrdm;
                    worksheet.Cell(currentRow, 102).Value = data.SPLongTermRatingGrdm;
                    worksheet.Cell(currentRow, 103).Value = data.OECDMarker;
                    worksheet.Cell(currentRow, 104).Value = data.DoTEligible;
                    worksheet.Cell(currentRow, 105).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 105).Value = data.DoTRecordDate;
                    worksheet.Cell(currentRow, 106).Value = data.DoTContact;
                    worksheet.Cell(currentRow, 107).Value = data.DoTComments;
                    worksheet.Cell(currentRow, 108).Value = data.ECBEligible;
                    worksheet.Cell(currentRow, 109).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 109).Value = data.ECBRecordDate;
                    worksheet.Cell(currentRow, 110).Value = data.ECBContact;
                    worksheet.Cell(currentRow, 111).Value = data.ECBComments;
                    worksheet.Cell(currentRow, 112).Value = data.NoBorrowerSetOff;
                    worksheet.Cell(currentRow, 113).Value = data.ContractLaw;
                    worksheet.Cell(currentRow, 114).Value = data.W8Sent;
                    worksheet.Cell(currentRow, 115).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 115).Value = data.W8SentDate;
                    worksheet.Cell(currentRow, 116).Value = data.W8Sender;
                    worksheet.Cell(currentRow, 117).Value = data.TaxEligibilityOverride;
                    worksheet.Cell(currentRow, 118).Style.DateFormat.Format = "dd/mm/yyyy";
                    worksheet.Cell(currentRow, 118).Value = data.TaxRecordDate;
                    worksheet.Cell(currentRow, 119).Value = data.TaxContact;
                    worksheet.Cell(currentRow, 120).Value = data.TaxComments;
                    worksheet.Cell(currentRow, 121).Value = data.FacilityWarnings;
                    worksheet.Cell(currentRow, 122).Value = data.EligibilityComments1;
                    worksheet.Cell(currentRow, 123).Value = data.EligibilityComments2;
                    worksheet.Cell(currentRow, 124).Value = data.EligibilityComments3;
                    worksheet.Cell(currentRow, 125).Value = data.FacilityEncumberedOutsideProcess;
                    worksheet.Cell(currentRow, 126).Value = data.TimeToLegalMaturity;
                    worksheet.Cell(currentRow, 127).Value = data.TimeToLegalMaturityBucket;
                    worksheet.Cell(currentRow, 128).Value = data.ExpectedAmortisationTime;
                    worksheet.Cell(currentRow, 129).Value = data.TimeToAmortisationMaturityBucket;
                    worksheet.Cell(currentRow, 130).Value = data.IneligibilityExceptions;
                    worksheet.Cell(currentRow, 131).Value = data.Entity;
                    worksheet.Cell(currentRow, 132).Value = data.CountryOfTaxClassification;
                    worksheet.Cell(currentRow, 133).Value = data.CountryOfTaxNote;
                    worksheet.Cell(currentRow, 134).Value = data.IneligibilityValidation;
                    worksheet.Cell(currentRow, 135).Value = data.AssessmentNeeded;
                    worksheet.Cell(currentRow, 136).Value = data.ConditionPrecedents;
                    worksheet.Cell(currentRow, 137).Value = data.SNPEligibility;
                    worksheet.Cell(currentRow, 138).Value = data.RSFUnencumbered;
                    worksheet.Cell(currentRow, 139).Value = data.TopCoCISCodeEncrypted;
                    worksheet.Cell(currentRow, 140).Value = data.LegalEntityCISCodeEncrypted;
                    worksheet.Cell(currentRow, 141).Value = data.ClientClassification;
                    worksheet.Cell(currentRow, 142).Value = data.SeniorityRank;
                    worksheet.Cell(currentRow, 143).Value = data.FacilityInternalRating;
                    worksheet.Cell(currentRow, 144).Value = data.DeskId;
                    worksheet.Cell(currentRow, 145).Value = data.DeskDesc;
                    worksheet.Cell(currentRow, 146).Value = data.SubDeskDesc;
                    worksheet.Cell(currentRow, 147).Value = data.CostCentreName;
                    worksheet.Cell(currentRow, 148).Value = data.CostCentreDesc;
                    worksheet.Cell(currentRow, 149).Value = data.SeniorTraderName;
                    worksheet.Cell(currentRow, 150).Value = data.CountryOfBalanceSheetLocation;
                    worksheet.Cell(currentRow, 151).Value = data.TradingBankingIndicator;
                    worksheet.Cell(currentRow, 152).Value = data.DivisionName;
                    worksheet.Cell(currentRow, 153).Value = data.BusinessConsolidation1Desc;
                    worksheet.Cell(currentRow, 154).Value = data.BusinessConsolidation2Desc;
                    worksheet.Cell(currentRow, 155).Value = data.BusinessConsolidation3Desc;
                    worksheet.Cell(currentRow, 156).Value = data.BusinessConsolidation4Desc;
                    worksheet.Cell(currentRow, 157).Value = data.BusinessConsolidation5Desc;
                    worksheet.Cell(currentRow, 158).Value = data.SicCode;
                }
            }
            setHeaderFormat(worksheet);
        }


      
        private List<string> GetHeaderDisplayNameForLoansOutstandingReport()
        {
            var item = new LoansOutstandingReportEntity();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> loansOutstandingHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                loansOutstandingHeader.Add(GetDisplayName(type, info, false));
            }
            return loansOutstandingHeader;
        }
        
    }

}
