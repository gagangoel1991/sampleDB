﻿using Microsoft.Extensions.Options;
using NW.SFP.Interface.Report.BusinessService;
using NW.SFP.Interface.Report.DataService;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using NW.SFP.Message.SFP.Model;
using System.Collections.Generic;
using System.Net;

namespace NW.SFP.BusinessService.Report
{
    public class ReportService : IReportService
    {
        private readonly IReportDataService _reportDataService;
        private readonly IOptions<ReportSettings> _reportSettings;

        public ReportService(IReportDataService reportDataService, IOptions<ReportSettings> reportSettings)
        {
            _reportDataService = reportDataService;
            _reportSettings = reportSettings;
        }

        public IList<HypoPool> GetHypoPools(string loggedInUserName, int assetClassId, int poolStatusId)
        {
            return _reportDataService.GetHypoPools(loggedInUserName, assetClassId, poolStatusId);
        }

        public ReportConfigs GetReportConfig(string loggedInUserName)
        {
            return _reportDataService.GetReportConfig(loggedInUserName);
        }

        public IList<ReportQueue> GetReportQueue(string loggedInUserName)
        {
           return _reportDataService.GetReportQueue(loggedInUserName);
        }

        public Message.Report.Report GetReports(string loggedInUserName, int id)
        {
            return _reportDataService.GetReports(loggedInUserName, id);
        }

        public SfpBatchDataDto SetReportForQueue(string loggedInUserName, Message.Report.Report report)
        {
            SfpBatchDataDto reportDto = new SfpBatchDataDto();
            SfpBatchDataModel reportModel = _reportDataService.SetReportForQueue(loggedInUserName, report);
            
            reportDto.BatchId = reportModel.BatchId;
            reportDto.IsResultValid = reportModel.IsResultValid;
            reportDto.ValidationErrorMessage = string.IsNullOrEmpty(reportModel.ValidationErrorMessage) ? "" : reportModel.ValidationErrorMessage;

            if (reportDto.IsResultValid)
            {
                GenerateReport();
            }
            return reportDto;
        }

        /// <summary>
        /// Calls the code to run the reporting framework executable as a process in the background on the server
        /// </summary>
        private void GenerateReport()
        {
            //  launch SFP Reporting Framework on the server as a separate process. Only runs a single instance of the Reporting Framework.
            RunProcess.ExecuteProcess(_reportSettings.Value.SFPReportingFrameworkPath);
        }
    }
}
