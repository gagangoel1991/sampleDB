﻿using System.Diagnostics;
using System.IO;
using Microsoft.Extensions.Options;
using NW.SFP.Message.Core;

namespace NW.SFP.BusinessService.Report
{
    /// <summary>
    /// Class used to run an executable as a Process on the server
    /// </summary>
    public static class RunProcess
    {
        /// <summary>
        /// Runs an executable exe on the server as a separate process. Only runs a single instance of the process.
        /// </summary>
        /// <param name="executingAssemblyPath">Path of the executable</param>
        public static void ExecuteProcess(string executingAssemblyPath)
        {
            ProcessStartInfo startInfo = new ProcessStartInfo();
            startInfo.CreateNoWindow = true;
            startInfo.UseShellExecute = false;
            startInfo.FileName = executingAssemblyPath;
            startInfo.WindowStyle = ProcessWindowStyle.Hidden;

            // Start the process only if it is not already running. Only want a single instance of the process to be running.
            if (Process.GetProcessesByName(Path.GetFileNameWithoutExtension(executingAssemblyPath)).Length == 0) 
            {
                // Start the process with the info we specified.
                using (Process _exeProcess = Process.Start(startInfo))
                {
                    // Do Nothing since we are treating this call as Asynchronous that will run on background thread with no impact to other UI functionality.
                }
            }
        }

    }
}
