﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using NW.SFP.BusinessService.CW;
using NW.SFP.Common;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Common;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.IR;
using NW.SFP.Message.PS;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace NW.SFP.BusinessService.Report
{
    public class ReferenceRegistryReportService : IReferenceRegistryReportService
    {
        private readonly IDealIrConfigDataService _dealIrConfigDataService;
        private IIrReportDataService _reportRepository;
        private IExcelService _excelService;
        private readonly IReferenceRegistryReportDataService _referenceRegistryReportDataService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        public ReferenceRegistryReportService(IReferenceRegistryReportDataService ReferenceRegistryReportDataService,
            IDealIrConfigDataService dealIrConfigDataService, IIrReportDataService reportRepository, IExcelService excelService
            , IOptions<CashWaterfallSettings> cwSettings)
        {
            this._referenceRegistryReportDataService = ReferenceRegistryReportDataService;
            this._dealIrConfigDataService = dealIrConfigDataService;
            this._reportRepository = reportRepository;
            this._excelService = excelService;
            this._cwSettings = cwSettings;
        }

        public MemoryStream GenerateReferenceRegistryReportData(int dealIrConfigId, string AsAtDate, string loggedInUserName, 
            bool replaceFormula = false, int poolId = 0, string ReportOutputType = "")
        {
            List<string> parentWorkSheet = new List<string>() { "disclaimer", "facility", "security" };
            string ReportTypeName = "Reference Registry";
            string sysFieldsWorksheetName = "sysFields";
            string SourcePath = "";
            string TempWorkSheet = "tempWs";


            DealIrConfigEntity objDealIrConfigEntity = _dealIrConfigDataService.GetDealIrConfig(dealIrConfigId, loggedInUserName, "Reference Registry", Convert.ToInt32(AssetType.Corporate));
            int dealId = objDealIrConfigEntity.IR_Config.DealId;


            if (!string.IsNullOrEmpty(objDealIrConfigEntity.IR_Config.UploadedFileName))
                SourcePath = _cwSettings.Value.RrConfigFileLocation;
            else
                SourcePath = _cwSettings.Value.RrTemplateFileLocation;

            IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = this._reportRepository.GetExcelReportList(dealIrConfigId, AsAtDate, ReportTypeName);

            string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
            string OutPutFileName = _ExcelUploadEntity.First().DownloadIrFileName;

            string TemplatePath = string.Concat(SourcePath, TemplateFile);
            string BackupTemplate = string.Concat(SourcePath, "TempFile-" + Math.Abs(Environment.TickCount), OutPutFileName);


            if (TemplateFile == null)
            {
                IXLWorkbook wb = new XLWorkbook();
                IXLWorksheet ws = wb.Worksheets.Add(TempWorkSheet);
                wb.SaveAs(BackupTemplate);
            }
            else if (!System.IO.File.Exists(BackupTemplate))
            {
                System.IO.File.Copy(TemplatePath, BackupTemplate);
            }

            List<ExcelUploadEntity> refRegStratDataSets = _ExcelUploadEntity.ToList();
            var _tasks = new List<Task<DataTable>>();
            foreach (ExcelUploadEntity _ExelUpld in refRegStratDataSets)
            {
                _tasks.Add(Task.Run(() => _ExelUpld.ReportDataTable
                = this._referenceRegistryReportDataService.GetRrStratData(_ExelUpld.StratName, dealIrConfigId, 
                AsAtDate, dealId, loggedInUserName, poolId, ReportOutputType)));
            }
            Task.WaitAll(_tasks.ToArray());

            using (var workbook = new XLWorkbook(BackupTemplate))
            {
                foreach (var refRegStratDataSet in refRegStratDataSets)
                {
                    if (!_excelService.IsWorksheetExist(workbook, refRegStratDataSet.WorkSheetName))
                        workbook.AddWorksheet(refRegStratDataSet.WorkSheetName);
                    IXLWorksheet ws = workbook.Worksheet(refRegStratDataSet.WorkSheetName);
                    if (_excelService.IsWorksheetExist(workbook, refRegStratDataSet.WorkSheetName))
                        ws.CellsUsed().Value = String.Empty;
                    ws.Cell(1, 1).InsertTable(refRegStratDataSet.ReportDataTable, false);
                    foreach (var cell in ws.CellsUsed())
                    {
                        cell.Value = cell.Value;
                    }
                    ws.Columns().AdjustToContents();
                }

                #region Custom SysFields Datable                
                if (_excelService.IsWorksheetExist(workbook, sysFieldsWorksheetName))
                {
                    workbook.Worksheet(sysFieldsWorksheetName).Delete();
                }
                IXLWorksheet sysFieldsWorkSheet = workbook.AddWorksheet(sysFieldsWorksheetName);
                sysFieldsWorkSheet.Cell("A1").Value = "Business Date";
                sysFieldsWorkSheet.Cell("B1").Value = AsAtDate;
                sysFieldsWorkSheet.Columns().AdjustToContents();
                #endregion


                workbook.CalculateMode = XLCalculateMode.Auto;
                workbook.CalculationOnSave = true;
                workbook.Save();

                if (replaceFormula)
                {
                    foreach (IXLWorksheet ws in workbook.Worksheets)
                    {

                        //If the Sheet is not Genrated By Strat Then Replace all Formula in it with value
                        if (!refRegStratDataSets.Any(x => x.WorkSheetName == ws.Name))
                            _excelService.ReplaceFormulaWithValue(ws, 1, ws.Columns().Count(), 1, ws.Rows().Count());

                    }
                    //Also Delete SysFields Tab
                    if (_excelService.IsWorksheetExist(workbook, sysFieldsWorksheetName))
                    {
                        workbook.Worksheet(sysFieldsWorksheetName).Delete();
                    }
                }

                if (_excelService.IsWorksheetExist(workbook, TempWorkSheet))
                {
                    workbook.Worksheet(TempWorkSheet).Delete();
                }




                workbook.Save();

                using (var ms = new MemoryStream())
                {

                    workbook.SaveAs(ms);

                    File.Delete(BackupTemplate);

                    return ms;
                }
            }

        }
        public MemoryStream DownloadFinalReferenceRegistryReport(int dealId, string AsAtDate, string loggedInUserName, int poolId=0, string ReportOutputType = "")
        {
            int AuhrosedDealIrConfigId = _referenceRegistryReportDataService.GetRRAuthorisedDealConfigId(dealId, AsAtDate, loggedInUserName);
            return GenerateReferenceRegistryReportData(AuhrosedDealIrConfigId, AsAtDate, loggedInUserName, true, poolId, ReportOutputType);

        }

        public int checkReferenceRegistryTemplateAvailable(int dealId, string AsAtDate, string loggedInUserName)
        {
            return _referenceRegistryReportDataService.GetRRAuthorisedDealConfigId(dealId, AsAtDate, loggedInUserName);
        }

        public int ManageRRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            return _referenceRegistryReportDataService.ManageRRAuthWorkflow(authWorkflowEntity);
        }

        public int SaveDealRrrConfig(DealIrConfigAddEditEntity dealIrConfigData, string loggedInUserName, string ReportTypeName)
        {
            return _dealIrConfigDataService.SaveDealIrConfig(dealIrConfigData, loggedInUserName, ReportTypeName, 2);
        }

        public DealIrConfigEntity GetRefRegData(int DealIrConfigId, string UserName, int AssetClassId)
        {

            DealIrConfigEntity objDealIrConfigEntity = _dealIrConfigDataService.GetDealIrConfig(DealIrConfigId, UserName, "Reference Registry", AssetClassId);
            return objDealIrConfigEntity;
        }

        public IList<RRReportField> GetFieldsForReports(string loggedInUserName, int assetClassId)
        {
            return _referenceRegistryReportDataService.GetFieldsForReports(loggedInUserName, assetClassId);
        }


    }
}