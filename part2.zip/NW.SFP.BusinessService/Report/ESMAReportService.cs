﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Text;
using NW.SFP.Message.PS;
using System.Reflection;
using System.Linq;

namespace NW.SFP.BusinessService.Report
{
  public  class ESMAReportService: IESMAReportService
    {

        private readonly IESMAReportDataService _esmaReportDataService;
        private readonly IOptions<ReportSettings> _reportSettings;

        public ESMAReportService(IESMAReportDataService ESMAReportDataService, IOptions<ReportSettings> reportSettings)
        {
            this._esmaReportDataService = ESMAReportDataService;
            this._reportSettings = reportSettings;
        }

        public MemoryStream GetESMA4Data(string dealName, DateTime ipdDate, string userName, int poolId, string poolName)
        {
            if(dealName == null || dealName.Equals("null"))
            {
                dealName = null;
                return ExcelSheetForESMA4(_esmaReportDataService.GetESMA4Data(dealName, ipdDate, userName, poolId), poolName);
            }
            else
            {
                return ExcelSheetForESMA4(_esmaReportDataService.GetESMA4Data(dealName, ipdDate, userName, poolId), dealName);
            }
            
        }

        public MemoryStream GetESMA9ata(string dealName, DateTime ipdDate, string userName, int poolId, string poolName)
        {
            if (dealName == null || dealName.Equals("null"))
            {
                dealName = null;
                return ExcelSheetForESMA9(_esmaReportDataService.GetESMA9Data(dealName, ipdDate, userName, poolId), poolName);
            }
            else
            {
                return ExcelSheetForESMA9(_esmaReportDataService.GetESMA9Data(dealName, ipdDate, userName, poolId), dealName);
            }


        }

        public MemoryStream GetFCAAnnex4Data(string dealName, DateTime ipdDate, string userName, int poolId, string poolName)
        {
            if (dealName == null || dealName.Equals("null"))
            {
                dealName = null;
                return ExcelSheetForFCA4(_esmaReportDataService.GetFCAAnnex4Data(dealName, ipdDate, userName, poolId), poolName);
            }
            else
            {
                return ExcelSheetForFCA4(_esmaReportDataService.GetFCAAnnex4Data(dealName, ipdDate, userName, poolId), dealName);
            }
                
        }

        public MemoryStream GetFCAAnnex9Data(string dealName, DateTime ipdDate, string userName, int poolId, string poolName)
        {
            if (dealName == null || dealName.Equals("null"))
            {
                dealName = null;
                return ExcelSheetForFCA9(_esmaReportDataService.GetFCAAnnex9Data(dealName, ipdDate, userName, poolId), poolName);
            }
            else
            {
                return ExcelSheetForFCA9(_esmaReportDataService.GetFCAAnnex9Data(dealName, ipdDate, userName, poolId), dealName);
            }
                

        }
        private MemoryStream ExcelSheetForESMA4(ESMA4 esma4, string DealName = "")
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                string TabName;

                if (DealName.Length >= 11) DealName = DealName.Substring(0, 10);
                TabName = $"" + DealName + " ESMA Annex4";

                var worksheetExposure = workbook.Worksheets.Add(TabName);
                FillESMA4ExposureReportWorksheet(esma4, worksheetExposure, SetESMAHeader);

                TabName = $"" + DealName + " ESMA Annex4 Security";

                var worksheetColletral = workbook.Worksheets.Add(TabName);
                FillESMA4ColletralReportWorksheet(esma4, worksheetColletral); 
                workbook.SaveAs(stream);
                return stream;
            }
        }

        private MemoryStream ExcelSheetForFCA4(ESMA4 esma4, string DealName = "")
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                string TabName;
                if (DealName.Length > 11) DealName = DealName.Substring(0, 11);
                TabName = $"" + DealName + " FCA Annex4";
                var worksheetExposure = workbook.Worksheets.Add(TabName);
                FillESMA4ExposureReportWorksheet(esma4, worksheetExposure, SetFCAHeader);

                TabName = $"" + DealName + " FCA Annex4 Security";

                var worksheetColletral = workbook.Worksheets.Add(TabName);
                FillESMA4ColletralReportWorksheet(esma4, worksheetColletral);
                workbook.SaveAs(stream);
                return stream;
            }
        }


        private MemoryStream ExcelSheetForESMA9(ESMA9 esma9, string DealName = "")
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                string TabName;
                if (DealName.Length >= 11) DealName = DealName.Substring(0, 10);
                TabName = $"" + DealName + " ESMA Annex9";

                var worksheetExposure = workbook.Worksheets.Add(TabName);
                FillESMA9ExposureReportWorksheet(esma9, worksheetExposure, SetESMAHeader);

                TabName = $"" + DealName + " ESMA Annex9 Security";
                var worksheetCollateral = workbook.Worksheets.Add(TabName);
                FillESMA9ColletralReportWorksheet(esma9, worksheetCollateral);

                workbook.SaveAs(stream);
                return stream;
            }
        }

        private MemoryStream ExcelSheetForFCA9(ESMA9 fca9, string DealName = "")
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                string TabName;
                if (DealName.Length > 11) DealName = DealName.Substring(0, 11);
                TabName = $"" + DealName + " FCA Annex9";

                var worksheetExposure = workbook.Worksheets.Add(TabName);
                FillESMA9ExposureReportWorksheet(fca9, worksheetExposure, SetFCAHeader);

                TabName = $"" + DealName + " FCA Annex9 Security";
                var worksheetCollateral = workbook.Worksheets.Add(TabName);
                FillESMA9ColletralReportWorksheet(fca9, worksheetCollateral);

                workbook.SaveAs(stream);
                return stream;
            }
        }


        private void FillESMA4ColletralReportWorksheet(ESMA4 esma4, IXLWorksheet worksheet)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForESMA4ColletralReport(";",1))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Font.Bold = true;
                worksheet.Cell(currentRow, columnNo).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            columnNo = 1;
            currentRow++;
            foreach (string headerName in GetHeaderDisplayNameForESMA4ColletralReport(";", 0))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Fill.BackgroundColor = XLColor.FromArgb(198, 89, 17);
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            var excelDateFormatExpr = "[$-en-GB]dd mmmm yyyy;@";
            if (esma4 != null)
            {
                foreach (var data in esma4.esma4Collateral)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.UniqueIdentifier;
                    worksheet.Cell(currentRow, 2).Value = data.UnderlyingExposureIdentifier;
                    worksheet.Cell(currentRow, 3).Value = data.OriginalCollateralIdentifier;
                    worksheet.Cell(currentRow, 4).Value = data.NewCollateralIdentifier;
                    worksheet.Cell(currentRow, 5).Value = data.GeographicRegionCollateral;
                    worksheet.Cell(currentRow, 6).Value = data.SecurityType;
                    worksheet.Cell(currentRow, 7).Value = data.ChargeType;
                    worksheet.Cell(currentRow, 8).Value = data.Lien;
                    worksheet.Cell(currentRow, 9).Value = data.CollateralType;
                    worksheet.Cell(currentRow, 10).Value = data.CurrentValuationAmount;
                    worksheet.Cell(currentRow, 11).Value = data.CurrentValuationMethod;
                    worksheet.Cell(currentRow, 12).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 12).Value = data.CurrentValuationDate;
                    worksheet.Cell(currentRow, 13).Value = data.OriginalValuationAmount;
                    worksheet.Cell(currentRow, 14).Value = data.OriginalValuationMethod;
                    worksheet.Cell(currentRow, 15).Value = data.OriginalValuationDate;
                    worksheet.Cell(currentRow, 16).Value = data.DateOfSale;
                    worksheet.Cell(currentRow, 17).Value = data.SalePrice;
                    worksheet.Cell(currentRow, 18).Value = data.CollateralCurrency;
                    worksheet.Cell(currentRow, 19).Value = data.GuarantorCountry;
                    worksheet.Cell(currentRow, 20).Value = data.GuarantorESASubsector;
                }
            }
            SetHeaderFormat(worksheet,2);
        }

        private string SetFCAHeader(string[] headers)
        {
            if (headers.Length > 1)
            {
                return headers[1];
            }
            else
            {
                return headers[0];
            }
        }
        private string SetESMAHeader(string[] headers)
        {
            return headers[0];
        }
        private void FillESMA4ExposureReportWorksheet(ESMA4 esma4, IXLWorksheet worksheet, Func<string[], string> SetReportHeader)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForESMA4ExposureReport(";",1))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Font.Bold = true;
                worksheet.Cell(currentRow, columnNo).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            columnNo = 1;
            currentRow++;
            foreach (string headerName in GetHeaderDisplayNameForESMA4ExposureReport(";",0))
            {
                worksheet.Cell(currentRow, columnNo).Value = SetReportHeader(headerName.Split('|'));
                worksheet.Cell(currentRow, columnNo).Style.Fill.BackgroundColor = XLColor.FromArgb(198, 89, 17);
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }


            var excelDateFormatExpr = "[$-en-GB]dd mmmm yyyy;@";
            var excelAmountFormatExpr = "#,##0.00";
            var excelRatePercentFormatExpr = "0.000000";
            if (esma4 != null)
            {
                foreach (var data in esma4.esma4Exposure)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.UniqueIdentifier;
                    worksheet.Cell(currentRow, 2).Value = data.OriginalUnderlyingExposureIdentifier;
                    worksheet.Cell(currentRow, 3).Value = data.NewUnderlyingExposureIdentifier;
                    worksheet.Cell(currentRow, 4).Value = data.OriginalObligorIdentifier;
                    worksheet.Cell(currentRow, 5).Value = data.NewObligorIdentifier;
                    worksheet.Cell(currentRow, 6).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 6).Value = data.DataCutOffDate;
                    worksheet.Cell(currentRow, 7).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 7).Value = data.PoolAdditionDate;
                    worksheet.Cell(currentRow, 8).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 8).Value = data.DateOfRepurchase;
                    worksheet.Cell(currentRow, 9).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 9).Value = data.RedemptionDate;
                    worksheet.Cell(currentRow, 10).Value = data.GeographicRegionObligor;
                    worksheet.Cell(currentRow, 11).Value = data.GeographicRegionClassification;
                    worksheet.Cell(currentRow, 12).Value = data.CreditImpairedObligor;
                    worksheet.Cell(currentRow, 13).Value = data.CustomerType;
                    worksheet.Cell(currentRow, 14).Value = data.NACEIndustryCode;
                    worksheet.Cell(currentRow, 15).Value = data.ObligorBaselIIISegment;
                    worksheet.Cell(currentRow, 16).Value = data.EnterpriseSize;
                    worksheet.Cell(currentRow, 17).Value = data.Revenue;
                    worksheet.Cell(currentRow, 18).Value = data.TotalDebt;
                    worksheet.Cell(currentRow, 19).Value = data.EBITDA;
                    worksheet.Cell(currentRow, 20).Value = data.EnterpriseValue;
                    worksheet.Cell(currentRow, 21).Value = data.FreeCashflow;
                    worksheet.Cell(currentRow, 22).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 22).Value = data.DateOfFinancials;
                    worksheet.Cell(currentRow, 23).Value = data.FinancialStatementCurrency;
                    worksheet.Cell(currentRow, 24).Value = data.DebtType;
                    worksheet.Cell(currentRow, 25).Value = data.SecuritisedReceivables;
                    worksheet.Cell(currentRow, 26).Value = data.InternationalSecuritiesIdentificationNumber;
                    worksheet.Cell(currentRow, 27).Value = data.Seniority;
                    worksheet.Cell(currentRow, 28).Value = data.Syndicated;
                    worksheet.Cell(currentRow, 29).Value = data.LeveragedTransaction;
                    worksheet.Cell(currentRow, 30).Value = data.ManagedByCLO;
                    worksheet.Cell(currentRow, 31).Value = data.PaymentInKind;
                    worksheet.Cell(currentRow, 32).Value = data.SpecialScheme;
                    worksheet.Cell(currentRow, 33).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 33).Value = data.OriginationDate;
                    worksheet.Cell(currentRow, 34).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 34).Value = data.MaturityDate;
                    worksheet.Cell(currentRow, 35).Value = data.OriginationChannel;
                    worksheet.Cell(currentRow, 36).Value = data.Purpose;
                    worksheet.Cell(currentRow, 37).Value = data.CurrencyDenomination;
                    worksheet.Cell(currentRow, 38).Value = data.OriginalPrincipalBalance;
                    worksheet.Cell(currentRow, 39).Value = data.CurrentPrincipalBalance;
                    worksheet.Cell(currentRow, 40).Value = data.PriorPrincipalBalances;
                    worksheet.Cell(currentRow, 41).Value = data.MarketValue;
                    worksheet.Cell(currentRow, 42).Value = data.TotalCreditLimit;
                    worksheet.Cell(currentRow, 43).Value = data.PurchasePrice;
                    worksheet.Cell(currentRow, 44).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 44).Value = data.PutDate;
                    worksheet.Cell(currentRow, 45).Value = data.PutStrike;
                    worksheet.Cell(currentRow, 46).Value = data.AmortisationType;
                    worksheet.Cell(currentRow, 47).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 47).Value = data.PrincipalGracePeriodEndDate;
                    worksheet.Cell(currentRow, 48).Value = data.ScheduledPrincipalPaymentFrequency;
                    worksheet.Cell(currentRow, 49).Value = data.ScheduledInterestPaymentFrequency;
                    worksheet.Cell(currentRow, 50).Style.NumberFormat.Format = excelAmountFormatExpr;
                    worksheet.Cell(currentRow, 50).Value = data.PaymentDue;
                    worksheet.Cell(currentRow, 51).Value = data.BalloonAmount;
                    worksheet.Cell(currentRow, 52).Value = data.InterestRateType;
                    worksheet.Cell(currentRow, 53).Style.NumberFormat.Format = excelRatePercentFormatExpr;
                    worksheet.Cell(currentRow, 53).Value = data.CurrentInterestRate;
                    worksheet.Cell(currentRow, 54).Value = data.CurrentInterestRateIndex;
                    worksheet.Cell(currentRow, 55).Value = data.CurrentInterestRateIndexTenor;
                    worksheet.Cell(currentRow, 56).Style.NumberFormat.Format = excelRatePercentFormatExpr;
                    worksheet.Cell(currentRow, 56).Value = data.CurrentInterestRateMargin;
                    worksheet.Cell(currentRow, 57).Value = data.InterestRateResetInterval;
                    worksheet.Cell(currentRow, 58).Value = data.InterestRateCap;
                    worksheet.Cell(currentRow, 59).Value = data.InterestRateFloor;
                    worksheet.Cell(currentRow, 60).Value = data.RevisionMargin1;
                    worksheet.Cell(currentRow, 61).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 61).Value = data.InterestRevisionDate1;
                    worksheet.Cell(currentRow, 62).Value = data.RevisionMargin2;
                    worksheet.Cell(currentRow, 63).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 63).Value = data.InterestRevisionDate2;
                    worksheet.Cell(currentRow, 64).Value = data.RevisionMargin3;
                    worksheet.Cell(currentRow, 65).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 65).Value = data.InterestRevisionDate3;
                    worksheet.Cell(currentRow, 66).Value = data.RevisedInterestRateIndex;
                    worksheet.Cell(currentRow, 67).Value = data.RevisedInterestRateIndexTenor;
                    worksheet.Cell(currentRow, 68).Value = data.NumberOfPaymentsBeforeSecuritisation;
                    worksheet.Cell(currentRow, 69).Value = data.PercentageOfPrepaymentsAllowedPerYear;
                    worksheet.Cell(currentRow, 70).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 70).Value = data.PrepaymentLockOutEndDate;
                    worksheet.Cell(currentRow, 71).Value = data.PrepaymentFee;
                    worksheet.Cell(currentRow, 72).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 72).Value = data.PrepaymentFeeEndDate;
                    worksheet.Cell(currentRow, 73).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 73).Value = data.PrepaymentDate;
                    worksheet.Cell(currentRow, 74).Value = data.CumulativePrepayments;
                    worksheet.Cell(currentRow, 75).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 75).Value = data.DateOfRestructuring;
                    worksheet.Cell(currentRow, 76).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 76).Value = data.DateLastInArrears;
                    worksheet.Cell(currentRow, 77).Value = data.ArrearsBalance;
                    worksheet.Cell(currentRow, 78).Value = data.NumberOfDaysInArrears;
                    worksheet.Cell(currentRow, 79).Value = data.AccountStatus;
                    worksheet.Cell(currentRow, 80).Value = data.ReasonForDefaultorForeclosure;
                    worksheet.Cell(currentRow, 81).Value = data.DefaultAmount;
                    worksheet.Cell(currentRow, 82).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 82).Value = data.DefaultDate;
                    worksheet.Cell(currentRow, 83).Value = data.AllocatedLosses;
                    worksheet.Cell(currentRow, 84).Value = data.CumulativeRecoveries;
                    worksheet.Cell(currentRow, 85).Value = data.RecoverySource;
                    worksheet.Cell(currentRow, 86).Value = data.Recourse;
                    worksheet.Cell(currentRow, 87).Value = data.DepositAmount;
                    worksheet.Cell(currentRow, 88).Value = data.InterestRateSwapNotional;
                    worksheet.Cell(currentRow, 89).Value = data.InterestRateSwapProviderLegalEntityIdentifier;
                    worksheet.Cell(currentRow, 90).Value = data.InterestRateSwapProvider;
                    worksheet.Cell(currentRow, 91).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 91).Value = data.InterestRateSwapMaturityDate;
                    worksheet.Cell(currentRow, 92).Value = data.CurrencySwapNotional;
                    worksheet.Cell(currentRow, 93).Value = data.CurrencySwapProviderLegalEntityIdentifier;
                    worksheet.Cell(currentRow, 94).Value = data.CurrencySwapProvider;
                    worksheet.Cell(currentRow, 95).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 95).Value = data.CurrencySwapMaturityDate;
                    worksheet.Cell(currentRow, 96).Value = data.OriginalLenderName;
                    worksheet.Cell(currentRow, 97).Value = data.OriginalLenderLegalEntityIdentifier;
                    worksheet.Cell(currentRow, 98).Value = data.OriginalLenderEstablishmentCountry;
                    worksheet.Cell(currentRow, 99).Value = data.OriginatorName;
                    worksheet.Cell(currentRow, 100).Value = data.OriginatorLegalEntityIdentifier;
                    worksheet.Cell(currentRow, 101).Value = data.OriginatorEstablishmentCountry;

                }
            }
            SetHeaderFormat(worksheet,2);

        }


        private void FillESMA9ColletralReportWorksheet(ESMA9 esma9, IXLWorksheet worksheet)
        {
            var currentRow = 1;
            var excelDateFormatExpr = "[$-en-GB]dd mmmm yyyy;@";
            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForESMA9ColletralReport(";", 1))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Font.Bold = true;
                worksheet.Cell(currentRow, columnNo).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            columnNo = 1;
            currentRow++;
            foreach (string headerName in GetHeaderDisplayNameForESMA9ColletralReport(";", 0))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Fill.BackgroundColor = XLColor.FromArgb(198, 89, 17);
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            if (esma9 != null)
            {
                foreach (var data in esma9.esma9Collateral)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.UniqueIdentifier;
                    worksheet.Cell(currentRow, 2).Value = data.OriginalUnderlyingExposureIdentifier;
                    worksheet.Cell(currentRow, 3).Value = data.OriginalCollateralIdentifier;
                    worksheet.Cell(currentRow, 4).Value = data.NewCollateralIdentifier;
                    worksheet.Cell(currentRow, 5).Value = data.GeographicRegionCollateral;
                    worksheet.Cell(currentRow, 6).Value = data.SecurityType;
                    worksheet.Cell(currentRow, 7).Value = data.ChargeType;
                    worksheet.Cell(currentRow, 8).Value = data.Lien;
                    worksheet.Cell(currentRow, 9).Value = data.CollateralType;
                    worksheet.Cell(currentRow, 10).Value = data.CurrentValuationAmount;
                    worksheet.Cell(currentRow, 11).Value = data.CurrentValuationMethod;
                    worksheet.Cell(currentRow, 12).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 12).Value = data.CurrentValuationDate;
                    worksheet.Cell(currentRow, 13).Value = data.CurrentLoanToValue;
                    worksheet.Cell(currentRow, 14).Value = data.OriginalValuationAmount;
                    worksheet.Cell(currentRow, 15).Value = data.OriginalValuationMethod;
                    worksheet.Cell(currentRow, 16).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 16).Value = data.OriginalValuationDate;
                    worksheet.Cell(currentRow, 17).Value = data.OriginalLoanToValue;
                    worksheet.Cell(currentRow, 18).Value = data.DateOfSale;
                    worksheet.Cell(currentRow, 19).Value = data.SalePrice;
                    worksheet.Cell(currentRow, 20).Value = data.CollateralCurrency;
                }
            }
            SetHeaderFormat(worksheet, 2);
        }

        private void FillESMA9ExposureReportWorksheet(ESMA9 esma9, IXLWorksheet worksheet, Func<string[], string> SetReportHeader)
        {
            var currentRow = 1;
            var excelDateFormatExpr = "[$-en-GB]dd mmmm yyyy;@";
            var excelAmountFormatExpr = "#,##0.00";
            var excelRatePercentFormatExpr = "0.000000";
            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForESMA9ExposureReport(";", 1))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                worksheet.Cell(currentRow, columnNo).Style.Font.Bold = true;
                worksheet.Cell(currentRow, columnNo).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            columnNo = 1;
            currentRow++;
            foreach (string headerName in GetHeaderDisplayNameForESMA9ExposureReport(";", 0))
            {
                worksheet.Cell(currentRow, columnNo).Value = SetReportHeader(headerName.Split('|')); 
                worksheet.Cell(currentRow, columnNo).Style.Fill.BackgroundColor = XLColor.FromArgb(198, 89, 17);
                worksheet.Cell(currentRow, columnNo).Style.Border.SetRightBorder(XLBorderStyleValues.Thin);
                columnNo++;
            }

            if (esma9 != null)
            {
                foreach (var data in esma9.esma9Exposure)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.UniqueIdentifier;
                    worksheet.Cell(currentRow, 2).Value = data.OriginalUnderlyingExposureIdentifier;
                    worksheet.Cell(currentRow, 3).Value = data.NewUnderlyingExposureIdentifier;
                    worksheet.Cell(currentRow, 4).Value = data.OriginalObligorIdentifier;
                    worksheet.Cell(currentRow, 5).Value = data.NewObligorIdentifier;
                    worksheet.Cell(currentRow, 6).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 6).Value = data.DataCutOffDate;
                    worksheet.Cell(currentRow, 7).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 7).Value = data.PoolAdditionDate;
                    worksheet.Cell(currentRow, 8).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 8).Value = data.DateOfRepurchase;
                    worksheet.Cell(currentRow, 9).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 9).Value = data.RedemptionDate;
                    worksheet.Cell(currentRow, 10).Value = data.Description;
                    worksheet.Cell(currentRow, 11).Value = data.GeographicRegionObligor;
                    worksheet.Cell(currentRow, 12).Value = data.GeographicRegionClassification;
                    worksheet.Cell(currentRow, 13).Value = data.EmploymentStatus;
                    worksheet.Cell(currentRow, 14).Value = data.CreditImpairedObligor;
                    worksheet.Cell(currentRow, 15).Value = data.ObligorLegalType;
                    worksheet.Cell(currentRow, 16).Value = data.SICCode;
                    worksheet.Cell(currentRow, 17).Value = data.PrimaryIncome;
                    worksheet.Cell(currentRow, 18).Value = data.PrimaryIncomeType;
                    worksheet.Cell(currentRow, 19).Value = data.PrimaryIncomeCurrency;
                    worksheet.Cell(currentRow, 20).Value = data.PrimaryIncomeVerification;
                    worksheet.Cell(currentRow, 21).Value = data.Revenue;
                    worksheet.Cell(currentRow, 22).Value = data.FinancialStatementCurrency;
                    worksheet.Cell(currentRow, 23).Value = data.InternationalSecuritiesIdentificationNumber;
                    worksheet.Cell(currentRow, 24).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 24).Value = data.OriginationDate;
                    worksheet.Cell(currentRow, 25).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 25).Value = data.MaturityDate;
                    worksheet.Cell(currentRow, 26).Value = data.CurrencyDenomination;
                    worksheet.Cell(currentRow, 27).Value = data.OriginalPrincipalBalance;
                    worksheet.Cell(currentRow, 28).Value = data.CurrentPrincipalBalance;
                    worksheet.Cell(currentRow, 29).Style.NumberFormat.Format = excelAmountFormatExpr;
                    worksheet.Cell(currentRow, 29).Value = data.TotalCreditLimit;
                    worksheet.Cell(currentRow, 30).Value = data.PurchasePrice;
                    worksheet.Cell(currentRow, 31).Value = data.AmortisationType;
                    worksheet.Cell(currentRow, 32).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 32).Value = data.PrincipalGracePeriodEndDate;
                    worksheet.Cell(currentRow, 33).Value = data.ScheduledPrincipalPaymentFrequency;
                    worksheet.Cell(currentRow, 34).Value = data.ScheduledInterestPaymentFrequency;
                    worksheet.Cell(currentRow, 35).Style.NumberFormat.Format = excelAmountFormatExpr;
                    worksheet.Cell(currentRow, 35).Value = data.PaymentDue;
                    worksheet.Cell(currentRow, 36).Value = data.DebtToIncomeRatio;
                    worksheet.Cell(currentRow, 37).Value = data.BalloonAmount;
                    worksheet.Cell(currentRow, 38).Value = data.InterestRateResetInterval;
                    worksheet.Cell(currentRow, 39).Style.NumberFormat.Format = excelRatePercentFormatExpr;
                    worksheet.Cell(currentRow, 39).Value = data.CurrentInterestRate;
                    worksheet.Cell(currentRow, 40).Value = data.CurrentInterestRateIndex;
                    worksheet.Cell(currentRow, 41).Value = data.CurrentInterestRateIndexTenor;
                    worksheet.Cell(currentRow, 42).Style.NumberFormat.Format = excelRatePercentFormatExpr;
                    worksheet.Cell(currentRow, 42).Value = data.CurrentInterestRateMargin;
                    worksheet.Cell(currentRow, 43).Value = data.InterestRateCap;
                    worksheet.Cell(currentRow, 44).Value = data.InterestRateFloor;
                    worksheet.Cell(currentRow, 45).Value = data.NumberOfPaymentsBeforeSecuritisation;
                    worksheet.Cell(currentRow, 46).Value = data.PercentageOfPrepaymentsAllowedPerYear;
                    worksheet.Cell(currentRow, 47).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 47).Value = data.PrepaymentLockOutEndDate;
                    worksheet.Cell(currentRow, 48).Value = data.PrepaymentFee;
                    worksheet.Cell(currentRow, 49).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 49).Value = data.PrepaymentFeeEndDate;
                    worksheet.Cell(currentRow, 50).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 50).Value = data.PrepaymentDate;
                    worksheet.Cell(currentRow, 51).Value = data.CumulativePrepayments;
                    worksheet.Cell(currentRow, 52).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 52).Value = data.DateLastInArrears;
                    worksheet.Cell(currentRow, 53).Value = data.ArrearsBalance;
                    worksheet.Cell(currentRow, 54).Value = data.NumberOfDaysInArrears;
                    worksheet.Cell(currentRow, 55).Value = data.AccountStatus;
                    worksheet.Cell(currentRow, 56).Value = data.ReasonForDefaultorForeclosure;
                    worksheet.Cell(currentRow, 57).Value = data.DefaultAmount;
                    worksheet.Cell(currentRow, 58).Style.NumberFormat.Format = excelDateFormatExpr;
                    worksheet.Cell(currentRow, 58).Value = data.DefaultDate;
                    worksheet.Cell(currentRow, 59).Value = data.AllocatedLosses;
                    worksheet.Cell(currentRow, 60).Value = data.CumulativeRecoveries;
                    worksheet.Cell(currentRow, 61).Value = data.OriginalLenderName;
                    worksheet.Cell(currentRow, 62).Value = data.OriginalLenderLegalEntityIdentifier;
                    worksheet.Cell(currentRow, 63).Value = data.OriginalLenderEstablishmentCountry;
                    worksheet.Cell(currentRow, 64).Value = data.OriginatorName;
                    worksheet.Cell(currentRow, 65).Value = data.OriginatorLegalEntityIdentifier;
                    worksheet.Cell(currentRow, 66).Value = data.OriginatorEstablishmentCountry;
                }
            }
            SetHeaderFormat(worksheet, 2);
        }


        private static String GetDisplayName(Type type, PropertyInfo info, bool hasMetaDataAttribute, string splitChar = "", int nameItemIndex = -1)
        {
            string DisplayName = "";
            if (!hasMetaDataAttribute)
            {
                object[] attributes = info.GetCustomAttributes(typeof(DisplayAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var displayName = (DisplayAttribute)attributes[0];
                    DisplayName = displayName.Name;
                }
                else
                {
                    DisplayName = info.Name;
                } 
            }
            else
            {
                PropertyDescriptor propDesc = TypeDescriptor.GetProperties(type).Find(info.Name, true);
                DisplayNameAttribute displayAttribute =
                    propDesc.Attributes.OfType<DisplayNameAttribute>().FirstOrDefault();
                DisplayName = displayAttribute != null ? displayAttribute.DisplayName : null;
            }

            if(!string.IsNullOrEmpty(splitChar) && nameItemIndex > -1)
            {
                string[] displayNameAry = DisplayName.Split(splitChar);

                if(displayNameAry.Count() > nameItemIndex)
                {
                    DisplayName = displayNameAry[nameItemIndex];
                }
            }

            return DisplayName;
        }

        private List<string> GetHeaderDisplayNameForESMA4ColletralReport(string splitChar = "", int nameItemIndex = -1)
        {
            var item = new ESMA4Collateral();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> esma4ColletralHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                esma4ColletralHeader.Add(GetDisplayName(type, info, false, splitChar, nameItemIndex));
            }
            return esma4ColletralHeader;
        }

        private List<string> GetHeaderDisplayNameForESMA4ExposureReport(string splitChar = "", int nameItemIndex = -1)
        {
            var item = new ESMA4Exposure();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> esma4ExposureHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                esma4ExposureHeader.Add(GetDisplayName(type, info, false, splitChar, nameItemIndex));
            }
            return esma4ExposureHeader;
        }

        private List<string> GetHeaderDisplayNameForESMA9ColletralReport(string splitChar = "", int nameItemIndex = -1)
        {
            var item = new ESMA9Collateral();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> esma9ColletralHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                esma9ColletralHeader.Add(GetDisplayName(type, info, false, splitChar, nameItemIndex));
            }
            return esma9ColletralHeader;
        }

        private List<string> GetHeaderDisplayNameForESMA9ExposureReport(string splitChar = "", int nameItemIndex = -1)
        {
            var item = new ESMA9Exposure();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> esma9ExposureHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                esma9ExposureHeader.Add(GetDisplayName(type, info, false, splitChar, nameItemIndex));
            }
            return esma9ExposureHeader;
        }
        private static void SetHeaderFormat(IXLWorksheet worksheet, int RowID = 1)
        {
            worksheet.Row(RowID).Style.Font.SetBold();
            worksheet.Columns().AdjustToContents();
            worksheet.Row(RowID).Height = 35;
            worksheet.Row(RowID).Style.Font.FontColor = XLColor.White;
            worksheet.Row(RowID).Style.Alignment.SetHorizontal(XLAlignmentHorizontalValues.Center);
            worksheet.Row(RowID).Style.Alignment.SetVertical(XLAlignmentVerticalValues.Center);
        }

    }
}
