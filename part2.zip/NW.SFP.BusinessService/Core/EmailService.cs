﻿using NW.SFP.Interface.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.BusinessService.Core
{
    public class EmailService : IEmailService
    {


        public void AttachmentforEmail(DataTable obj,string GeneratedFileName)
        {
            try
            {
                //Microsoft.Office.Interop.Outlook.Application oApp = new Microsoft.Office.Interop.Outlook.Application();
                //Microsoft.Office.Interop.Outlook.MailItem oMsg = (Microsoft.Office.Interop.Outlook.MailItem)oApp.CreateItem(Microsoft.Office.Interop.Outlook.OlItemType.olMailItem);



                //oMsg.Subject = obj.Rows[0]["EmailSubject"].ToString();
                //oMsg.BodyFormat = Microsoft.Office.Interop.Outlook.OlBodyFormat.olFormatHTML;
                //oMsg.HTMLBody = obj.Rows[0]["EmailBody"].ToString();
                //oMsg.Attachments.Add(GeneratedFileName, Microsoft.Office.Interop.Outlook.OlAttachmentType.olByValue, Type.Missing, Type.Missing);
                //oMsg.Display(true);



           //     var lst = _dailyCashEstimationService.GetDailyCashEstimationData(dealName, asAtDate, LoggedInUserName);
           //     return lst;
            }
            catch (Exception ex)
            {
            //    LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCashEstimationSummary", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
            //    this._loggerService.LogError(logError);



                throw ex;
            }
        }
    }

}
