﻿namespace NW.SFP.BusinessService.Core
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.Core;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;

    public class SelectlookupService : ISelectLookupService
    {
        private ISelectLookupDataService selectListRepository;

        public SelectlookupService(ISelectLookupDataService selectListRepository)
        {
            this.selectListRepository = selectListRepository;
        }

        public IEnumerable<SelectLookupEntity> GetParametrizedSelectList(DataTable ListId, String AssetClassId)
        {
            return this.selectListRepository.GetParametrizedSelectList(ListId, AssetClassId);
        }

        public IEnumerable<SelectLookupEntity> GetParametrizedSelectListFilterBased(DataTable ListId, DataTable FilterId)
        {
            return this.selectListRepository.GetParametrizedSelectListFilterBased(ListId, FilterId);
        }    
	}
}
