﻿using NW.SFP.Interface.Core;
using NW.SFP.Message.Core;
using NW.SFP.Message.Core.Token;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.Core
{
    public class APITokenService : IAPITokenService
    {
        private readonly IAPITokenDataService _APITokenDataService;

        public APITokenService(IAPITokenDataService APITokenDataService)
        {
            this._APITokenDataService = APITokenDataService;
        }

        public APITokenEntity APITokenEntity { get; set; }

        public Guid? GetAPITokenbyKey(APITokenEntity objAPITokenEntity)
        {
            return _APITokenDataService.GetAPITokenbyKey(objAPITokenEntity);
        }

        public APITokenUpdateOutputEntity UpdateAPIToken(APITokenEntity objAPITokenEntity)
        {
            return _APITokenDataService.UpdateAPIToken(objAPITokenEntity);
        }
    }
}
