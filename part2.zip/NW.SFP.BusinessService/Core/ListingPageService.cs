﻿using NW.SFP.Interface.Core;
using NW.SFP.Message.core;

namespace NW.SFP.BusinessService.Core
{
    public class ListingPageService : IListingPageService
    {
        private readonly IListingPageDataService _listingPageDataService;

        public ListingPageService(IListingPageDataService listingPageDataService)
        {
            _listingPageDataService = listingPageDataService;
        }

        public ListingPreference GetUserListingPreference(string listingPageName, string userName)
        {
            return _listingPageDataService.GetUserListingPreference(listingPageName, userName);
        }

        public int SaveUserListingPreference(ListingPreference listingPreference, string userName)
        {
            return _listingPageDataService.SaveUserListingPreference(listingPreference, userName);
        }
    }
}
