﻿using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class KeyValueLookupService : IKeyValueLookupService
    {
        private readonly IKeyValueLookupDataService _keyValueLookupDataService;
        //private readonly IFactory factory;

        public KeyValueLookupService(IKeyValueLookupDataService keyValueLookupDataService)
        {
            this._keyValueLookupDataService = keyValueLookupDataService;
        }


        /// <summary>
        /// This will return the key value lookup data based of type
        /// </summary>
        /// <param name="lookupTypeIds"></param>
        ///<param name="loggedInUserName"></param>
        public IList<KeyValueLookupEntity> GetKeyValueLookupData(string lookupTypeIds, string loggedInUserName)
        {
            return this._keyValueLookupDataService.GetKeyValueLookupData(lookupTypeIds, loggedInUserName);
        }
    }
}
