﻿namespace NW.SFP.BusinessService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using ClosedXML.Excel;
    using System.IO;
    using System.Configuration;
    using System.Net;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.CW;
    using NW.SFP.Interface.CW;
    using System.Net.Http;
    using System.Net.Http.Headers;
    using NW.SFP.Common;
    using Microsoft.AspNetCore.Mvc;

    public class ExcelService : IExcelService
    {
        public void WriteDataIntoExcel(DataTable _psDatatable, IXLWorksheet _ws, int _rowNumber, int _startcellIndex)
        {
            try
            {
                _ws.Clear();

                if (_psDatatable != null)
                {
                    //Column Headings
                    
                    for (var col = 0; col < _psDatatable.Columns.Count; col++)
                    {
                        _ws.Cell(1, col + 1).Value = Utils.GetUntilOrSame(_psDatatable.Columns[col].ColumnName, "~");
                    }

                    var rangeWithData = _ws.Cell(_rowNumber, _startcellIndex).InsertData(_psDatatable.AsEnumerable());
                         
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public void WriteDataIntoExcel(DataTable _psDatatable, IXLWorksheet _ws, string _anchorCell)
        {
            try
            {
                if(_anchorCell.Length > 0 && _psDatatable != null)
                {                   
                    var rangeWithData = _ws.Cell(_anchorCell).InsertData(_psDatatable.AsEnumerable());
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool IsWorksheetExist(IXLWorkbook _wb, string _wsName)
        {
            bool isExist = _wb.Worksheets.Any(item => item.Name.ToUpper() == _wsName.ToUpper());
            return isExist;
        }

        public bool IsWorksheetsExist(IXLWorkbook _wb, string[] _wsNames)
        {
            bool isExist = true;
            foreach (string sheetName in _wsNames)
            {
                isExist = isExist && _wb.Worksheets.Any(item => item.Name.Trim().ToUpper() == sheetName.Trim().ToUpper());
            }
            return isExist;
        }

        public bool IsWorksheetsExist(IXLWorkbook _wb, string[] _wsNames, out string MissingSheetName)
        {
            bool isExist = true;
            MissingSheetName = "";
            foreach (string sheetName in _wsNames)
            { 
                isExist = isExist && _wb.Worksheets.Any(item => item.Name.Trim().ToUpper() == sheetName.Trim().ToUpper());
                if(!isExist)
                {
                    MissingSheetName = sheetName;
                    return isExist;
                }
            }
            return isExist;
        }

        public HttpResponseMessage DownLoadExcel(string FileName, string OutputFileName)
        {
            byte[] fileBytes = System.IO.File.ReadAllBytes(FileName);
            var result = new HttpResponseMessage(HttpStatusCode.OK)
            {
                Content = new ByteArrayContent(fileBytes)
            };
            result.Content.Headers.ContentDisposition = new System.Net.Http.Headers.ContentDispositionHeaderValue("attachment")
            {
                FileName = OutputFileName
            };
            result.Content.Headers.ContentType = new MediaTypeHeaderValue("application/octet-stream");

            return result;
        }


        public void ReplaceFormulaWithValue(IXLWorksheet _ws, int startColNo, int endColNo, int startRowNo, int endRowNo)
        {
            try
            {
                for (var currentCol = startColNo; currentCol <= endColNo; currentCol++)
                {
                    for (var currentRow = startRowNo; currentRow <= endRowNo; currentRow++)
                    {

                        var isFormula = _ws.Cell(currentRow, currentCol).HasFormula;

                        if (isFormula)
                        {
                            ChangeCellValue(_ws, currentRow, currentCol);
                        }

                    }
                }

                _ws.PageSetup.PrintAreas.Add(startRowNo, startColNo, endRowNo, endColNo);

            }
            catch (Exception ex)
            {

            }
        }

        void ChangeCellValue(IXLWorksheet _ws, int currentRow, int currentCol)
        {
            try
            {
                var value = _ws.Cell(currentRow, currentCol).Value;

                _ws.Cell(currentRow, currentCol).Value = value;
            }
            catch (Exception ex)
            {

            }
        }

        
    }
}