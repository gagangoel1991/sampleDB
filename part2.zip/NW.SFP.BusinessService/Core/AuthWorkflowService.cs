﻿using NW.SFP.Interface.Core;
using NW.SFP.Message.Common;

namespace NW.SFP.BusinessService.Core
{
    public class AuthWorkflowService : IAuthWorkflowService
    {
        private readonly IAuthWorkflowDataService _authWorkflowDataService;
        public AuthWorkflowService(IAuthWorkflowDataService authWorkflowDataService)
        {
            _authWorkflowDataService = authWorkflowDataService;
        }

        public AuthWorkflowEntity GetAuthWorkflowStatus(AuthWorkflowEntity authWorkflowEntity)
        {
            return _authWorkflowDataService.GetAuthWorkflowStatus(authWorkflowEntity);
        }

        public int ManageAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            return _authWorkflowDataService.ManageAuthWorkflow(authWorkflowEntity);
        }

        public AuthAuditEntity GetEntityAuditDetails(AuthWorkflowEntity authWorkflowEntity)
        {
            return _authWorkflowDataService.GetEntityAuditDetails(authWorkflowEntity);
        }
        
    }
}
