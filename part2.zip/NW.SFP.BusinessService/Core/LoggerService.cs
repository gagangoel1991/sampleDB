﻿using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.Core
{
    public class LoggerService : ILoggerService
    {
        #region Variable(s) declaration and Constructor
        private readonly ILoggerDataService _loggerDataService;

        public LoggerService(ILoggerDataService loggerDataService)
        {
            this._loggerDataService = loggerDataService;
        }
        #endregion

        #region Methods

        /// <summary>
        /// For logging the info in the database/Txt file
        /// </summary>
        /// <param name="logInfo"></param>
        public void LogInfo(LogInfoEntity logInfo)
        {
            this._loggerDataService.LogInfo(logInfo);
        }

        /// <summary>
        /// For logging the error 
        /// </summary>
        /// <param name="logError"></param>
        public void LogError(LogErrorEntity logError)
        {
            this._loggerDataService.LogError(logError);
        }

        #endregion
    }
}
