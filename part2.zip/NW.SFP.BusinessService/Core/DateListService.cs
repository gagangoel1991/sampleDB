﻿using NW.SFP.Interface.Core;
using NW.SFP.Message.core;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.Core
{
    public class DateListService : IDateListService
    {
        private readonly IDateListDataService _dateListDataService;
        public DateListService(IDateListDataService dateListDataService)
        {
            _dateListDataService = dateListDataService;
        }

        public IList<HolidayDate> GetHolidayList()
        {
            return _dateListDataService.GetHolidayList();
        }
    }
}
