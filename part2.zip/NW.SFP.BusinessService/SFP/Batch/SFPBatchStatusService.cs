﻿using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP.Model;
using NW.SFP.Message.SFP.DTO;

namespace NW.SFP.BusinessService.SFP
{
    /// <summary>
    /// This class will hold the business logic for Batch Status details that is to be displayed at the application
    /// </summary>
    public class SfpBatchStatusService : ISfpBatchStatusService
    {
        private readonly ISfpBatchStatusDataService _sfpBatchDataService;

        private BatchStatusDetailModel _batchInfo;
        private BatchStatusDetailDto _batchDataDto;

        /// <summary>
        /// Constructor 
        /// </summary>
        /// <param name="sfpBatchDataService"> Data service object</param>
        /// <param name="batchInfo"> Database mapping object</param>
        /// <param name="batchDataDto">DTO Object</param>
        public SfpBatchStatusService(ISfpBatchStatusDataService sfpBatchDataService, BatchStatusDetailDto batchDataDto)
        {
            this._sfpBatchDataService = sfpBatchDataService;
            this._batchDataDto = batchDataDto;
        }

        /// <summary>
        /// Method to fetch Batch Status Data
        /// </summary>
        /// <returns></returns>
        public BatchStatusDetailDto GetSFPBatchStatusData()
        {
            this._batchInfo =  this._sfpBatchDataService.GetSFPBatchStatusData();
            CreateBatchInformation();
            return this._batchDataDto;
        }


        /// <summary>
        /// Method to create logic for Batch Information
        /// </summary>
        private void CreateBatchInformation()
        {
            _batchDataDto.BatchStatusHeaderText = $"SFP batch status for {_batchInfo.RelatesToDate}";
            _batchDataDto.RefreshedAt = $"refreshed at {_batchInfo.RefreshedAt}";

            _batchDataDto.ReportStausHeaderText = $"Reports Available";
            _batchDataDto.ReportState = _batchInfo.ReportState;
            _batchDataDto.IsReportBatchComplete = _batchInfo.IsReportBatchComplete;
            _batchDataDto.ReportCompletionText = _batchInfo.IsReportBatchComplete ? $"{_batchInfo.ReportState} at {_batchInfo.ReportStateChangedDatetime}" : _batchInfo.ReportState;

            _batchDataDto.SSASTabularHeaderText = $"PowerBI Available";
            _batchDataDto.SSASTabularState = _batchInfo.SSASTabularState;
            _batchDataDto.IsSSASTabularBatchComplete = _batchInfo.IsSSASTabularBatchComplete;
            _batchDataDto.SSASTabularCompletionText = _batchInfo.IsSSASTabularBatchComplete ? $"{_batchInfo.SSASTabularState} at {_batchInfo.SSASTabularStateChangedDatetime}" : _batchInfo.SSASTabularState;
        }
    }
}