﻿using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP;
using NW.SFP.Message.SFP.DataQuality;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.SFP
{
    /// <summary>
    /// This class will hold the business logic for Enforcement Data Quality Report of the Upload Functionality
    /// </summary>
    public class EnforcementDataQualityReportService : IEnforcementDataQualityReportService
    {
        private readonly IEnforcementDataQualityReportDataService _sfpDataQualityReportDataService;

        public EnforcementDataQualityReportService(IEnforcementDataQualityReportDataService sfpDataQualityReportDataService)
        {
            this._sfpDataQualityReportDataService = sfpDataQualityReportDataService;
        }

        public EnforcementDataQualityReport GetEnforcementDataQualityReportData()
        {
            EnforcementDataQualityReport enforcementDataQuality = new EnforcementDataQualityReport();
            enforcementDataQuality.enforcementDetailData = _sfpDataQualityReportDataService.GetEnforcementDataQualityDetailReport();
            enforcementDataQuality.enforcementSummaryData = _sfpDataQualityReportDataService.GetEnforcementDataQualitySummaryReport();
            enforcementDataQuality.enforcementDetailData = this.PopulateRuleDescriptionForEnforcement(enforcementDataQuality.enforcementDetailData, enforcementDataQuality.enforcementSummaryData);
            return enforcementDataQuality;
        }

        public int GetEnforcementDataValidationStatus()
        {
            return _sfpDataQualityReportDataService.GetEnforcementDataValidationStatus();
        }

        private List<EnforcementDetail> PopulateRuleDescriptionForEnforcement(List<EnforcementDetail> enforcementDetailData, List<EnforcementSummary> enforcementSummaryData)
        {
            foreach(EnforcementSummary enforcementSummary in enforcementSummaryData)
            {
                foreach(EnforcementDetail enforcementDetail in enforcementDetailData)
                {
                    if(enforcementSummary.RuleId == enforcementDetail.RuleId)
                    {
                        enforcementDetail.RuleDescription = enforcementSummary.RuleDescription;
                    }
                }
            }
            return enforcementDetailData;
        }

    }
}