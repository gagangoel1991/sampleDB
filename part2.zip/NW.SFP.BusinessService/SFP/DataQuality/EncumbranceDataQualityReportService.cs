﻿using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP;
using NW.SFP.Message.SFP.DataQuality;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.SFP
{
    public class EncumbranceDataQualityReportService : IEncumbranceDataQualityReportService
    {
        private readonly IEncumbranceDataQualityReportDataService _sfpDataQualityReportDataService;

        public EncumbranceDataQualityReportService(IEncumbranceDataQualityReportDataService sfpDataQualityReportDataService)
        {
            this._sfpDataQualityReportDataService = sfpDataQualityReportDataService;
        }

        public EncumbranceDataQualityReport GetEncumbranceDataQualityReportData()
        {
            EncumbranceDataQualityReport encumbranceDataQuality = new EncumbranceDataQualityReport();
            encumbranceDataQuality.encumbranceDetailData = _sfpDataQualityReportDataService.GetEncumbranceDataQualityDetailReport();
            encumbranceDataQuality.encumbranceSummaryData = _sfpDataQualityReportDataService.GetEncumbranceDataQualitySummaryReport();
            encumbranceDataQuality.encumbranceDetailData = this.PopulateRuleDescriptionForEncumbrance(encumbranceDataQuality.encumbranceDetailData, encumbranceDataQuality.encumbranceSummaryData);
            return encumbranceDataQuality;
        }

        public int GetEncumbrancedataValidationStatus()
        {
            return _sfpDataQualityReportDataService.GetEncumbranceDataValidationStatus();
        }

        private List<EncumbranceDetail> PopulateRuleDescriptionForEncumbrance(List<EncumbranceDetail> encumbranceDetailData, List<EncumbranceSummary> encumbranceSummaryData)
        {
            foreach (EncumbranceSummary encumbranceSummary in encumbranceSummaryData)
            {
                foreach (EncumbranceDetail encumbranceDetail in encumbranceDetailData)
                {
                    if (encumbranceSummary.RuleId == encumbranceDetail.RuleId)
                    {
                        encumbranceDetail.RuleDescription = encumbranceSummary.RuleDescription;
                    }
                }
            }
            return encumbranceDetailData;
        }

    }
}