﻿using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP.Model;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.SFP
{
    public class ReportLookUpService : IReportLookUpService
    {
        private readonly IReportLookUpDataService _sfpReportLookUpService;

        public ReportLookUpService(IReportLookUpDataService sfpReportLookUpService)
        {
            this._sfpReportLookUpService = sfpReportLookUpService;
        }

        public List<ReportLookupDto> GetReportLookupData()
        {
            List<ReportLookupDto> reportLookUpList = new List<ReportLookupDto>();
            List<ReportLookupModel> reportLookUpModelList = _sfpReportLookUpService.GetReportLookupData();
            foreach(ReportLookupModel lookupModel in reportLookUpModelList)
            {
                reportLookUpList.Add(MapReportLookUpDTOAndModel(lookupModel));
            }
           return reportLookUpList;
        }

        public ReportLookupDto GetReportLookupDataById(int lookUpId)
        {
            return MapReportLookUpDTOAndModel(_sfpReportLookUpService.GetReportLookupDataById(lookUpId));
        }

        public ReportLookupDto InsertReportLookUpData(ReportLookupDto reportLookUpData)
        {
            return MapReportLookUpDTOAndModel(_sfpReportLookUpService.InsertReportLookUpData(this.MapReportLookUpDTOAndModel(reportLookUpData)));
        }

        public int DeleteReportLookUpData(int lookupId)
        {
            return _sfpReportLookUpService.DeleteReportLookUpData(lookupId);
        }

        public void SupportInsertReportLookUpData(ReportLookupModel reportLookUpData)
        {
            _sfpReportLookUpService.SupportInsertReportLookUpData(reportLookUpData);
        }

        public ReportLookupDto UpdateWorkpadReportLookUpData(ReportLookupDto reportLookUpData)
        {
            return MapReportLookUpDTOAndModel(_sfpReportLookUpService.UpdateWorkpadReportLookUpData(MapReportLookUpDTOAndModel(reportLookUpData)));
        }

        public ReportLookupReferenceDataDto GetReportLookUpReferenceData()
        {
            return this.BindReportLookUpReferenceData(_sfpReportLookUpService.GetReportLookUpReferenceData());
        }

        public int UpdateLookUpActionWorkFlow(string userName, string action, int lookupId)
        {
            return this._sfpReportLookUpService.UpdateLookUpActionWorkFlow(userName, action, lookupId);
        }

        #region Lookup Report Reference data

        private ReportLookupReferenceDataDto BindReportLookUpReferenceData(List<ReportLookupReferenceModel>  reportRefDataModel)
        {
            ReportLookupReferenceDataDto lookUpRefdata = new ReportLookupReferenceDataDto();
            foreach(ReportLookupReferenceModel objRefLookUp in reportRefDataModel)
            {
                if(objRefLookUp.FieldName == "ReportLookUpData_ReportTemplateName")
                {
                    lookUpRefdata.ReportTemplateReferenceData.Add(new ReportLookupReferenceDto()
                    {
                        ReportLookUpReferenceId = objRefLookUp.Id,
                        ReportLookUpReferenceValue = objRefLookUp.Value
                    });
                }
                if (objRefLookUp.FieldName == "ReportLookUpData_LookUpName")
                {
                    lookUpRefdata.ReportLookUpNameReferenceData.Add(new ReportLookupReferenceDto()
                    {
                        ReportLookUpReferenceId = objRefLookUp.Id,
                        ReportLookUpReferenceValue = objRefLookUp.Value
                    });
                }
            }
            return lookUpRefdata;
       }


        private ReportLookupModel MapReportLookUpDTOAndModel(ReportLookupDto reportLookUpData)
        {
            return new ReportLookupModel()
            {
                ReportLookUpId = reportLookUpData.ReportLookUpId,
                Status = reportLookUpData.Status,
                ReportTemplateName = reportLookUpData.ReportTemplateName,
                LookUpName = reportLookUpData.LookUpName,
                LookUpValue = reportLookUpData.LookUpValue,
                LookUpValueDescription = reportLookUpData.LookUpValueDescription,
                ReportValue = reportLookUpData.ReportValue,
                Changer = reportLookUpData.Changer,
                Requester = reportLookUpData.Requester,
                Authoriser = reportLookUpData.Authoriser,
                ReportLookUpWorkPadId = reportLookUpData.ReportLookUpWorkPadId,
                ValidationStatus = reportLookUpData.ValidationStatus
            };

        }


        private ReportLookupDto MapReportLookUpDTOAndModel(ReportLookupModel reportLookUpData)
        {
            return new ReportLookupDto()
            {
                ReportLookUpId = reportLookUpData.ReportLookUpId,
                Status = reportLookUpData.Status,
                ReportTemplateName = reportLookUpData.ReportTemplateName,
                LookUpName = reportLookUpData.LookUpName,
                LookUpValue = reportLookUpData.LookUpValue,
                LookUpValueDescription = reportLookUpData.LookUpValueDescription,
                ReportValue = reportLookUpData.ReportValue,
                Changer = reportLookUpData.Changer,
                Requester = reportLookUpData.Requester,
                Authoriser = reportLookUpData.Authoriser,
                ReportLookUpWorkPadId = reportLookUpData.ReportLookUpWorkPadId,
                ValidationStatus = reportLookUpData.ValidationStatus
            };

        }

        #endregion
    }
}