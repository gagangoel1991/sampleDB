﻿using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP;

namespace NW.SFP.BusinessService.SFP
{
    public class SFPDashboardService : ISFPDashboardService
    {
        private readonly ISfpDashboardDataService _sfpDashboardDataService;

        public SFPDashboardService(ISfpDashboardDataService sfpDashboardDataService)
        {
            this._sfpDashboardDataService = sfpDashboardDataService;
        }

        public SfpDashBoardDataList GetSFPDashBoardData(string userName)
        {
            return this._sfpDashboardDataService.GetSFPDashBoardData(userName);
        }
    }
}