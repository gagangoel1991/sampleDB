﻿using NW.SFP.Common;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Linq;
using ClosedXML.Excel;
using System.Data;

namespace NW.SFP.BusinessService.CW.CB
{
    public class FundsFacadeService : IFundsFacadeService
    {

        private readonly ISwapCollateralService _swapCollateralService;
        private readonly IReserveFundService _reserveFundService;
        private readonly IPreMaturityLiquidityService _preMaturityLiquidityService;
        private readonly ICouponPaymentService _couponPaymentService;
        private readonly ILedgersFundService _ledgersFundService;
        string HeaderColour = "#248dad";
        string HeaderTextColour = "#ffffff";
        string OddRowColour = "#e6e6e6";
        string EvenRowColour = "#f2f2f2";

        public FundsFacadeService(ISwapCollateralService swapCollateralService, IReserveFundService reserveFundService, IPreMaturityLiquidityService preMaturityLiquidityService, ICouponPaymentService couponPaymentService
            , ILedgersFundService ledgersFundService)
        {
            _swapCollateralService = swapCollateralService;
            _reserveFundService = reserveFundService;
            _preMaturityLiquidityService = preMaturityLiquidityService;
            _couponPaymentService = couponPaymentService;
            _ledgersFundService = ledgersFundService;
        }

        public List<SwapCollateralEntity> GetSwapCollateral(IPDFeedParam ipdFeedParam)
        {
            return _swapCollateralService.GetSwapCollateral(ipdFeedParam);
        }

        public List<ReserveFundEntity> GetReserveFund(IPDFeedParam ipdFeedParam)
        {
            var dt = _reserveFundService.GetReserveFund(ipdFeedParam);
            if (dt != null)
            {
                var reserveFundData = Utils.ConvertDataTable<ReserveFundEntity>(dt);

                List<ReserveFundEntity> hierarchy = new List<ReserveFundEntity>();

                hierarchy = GetChildLineItems(reserveFundData, null);

                return hierarchy;
            }

            return null;
        }

        public List<ReserveFundEntity> GetChildLineItems(List<ReserveFundEntity> lineItems, int? parentId)
        {
            return lineItems
                    .Where(c => c.ParentTestLineItemId == parentId)
                    .GroupBy(c => c.TestLineItemId)
                    .Select(c => new ReserveFundEntity
                    {
                        DisplayName = c.Select(x => x.DisplayName).FirstOrDefault(),
                        InternalTestLineItem = c.Select(x => x.InternalTestLineItem).FirstOrDefault(),
                        LineItemValues = c.OrderByDescending(x => x.IpdDate).Select(x => x.LineItemValue).ToArray(),
                        ParentTestLineItemId = c.Select(x => x.ParentTestLineItemId).FirstOrDefault(),
                        LineItemTooltip = c.Select(x => x.LineItemTooltip).FirstOrDefault(),
                        ChildLineItems = GetChildLineItems(lineItems, c.Key)
                    })
                    .ToList();
        }

        public List<PreMaturityLiquidityEntity> GetPreMaturityLiquidityFund(IPDFeedParam ipdFeedParam)
        {
            return _preMaturityLiquidityService.GetPreMaturityLiquidityFund(ipdFeedParam);
        }

        public List<CouponPaymentEntity> GetCouponPaymentFund(IPDFeedParam ipdFeedParam)
        {
            return _couponPaymentService.GetCouponPaymentFund(ipdFeedParam);
        }

        public IXLWorkbook GetReserveFundExcel(IPDFeedParam IpdFeedParam)
        {
            var dtReserveFundExcel = new DataTable();
            string headerParam = string.Empty;
            string excelSheetName = string.Empty;
            IXLWorkbook workbook = new XLWorkbook();

            dtReserveFundExcel = _reserveFundService.GetReserveFund(IpdFeedParam);
            headerParam = "Reserve Ledger";

            if (dtReserveFundExcel != null)
            {
                var reserveFundEntityData = Utils.ConvertDataTable<ReserveFundEntity>(dtReserveFundExcel);
                var Hierarchy = GetChildLineItems(reserveFundEntityData, null);
                IXLWorksheet worksheet = workbook.Worksheets.Add("Reserve Ledger");
                var IpdDates = reserveFundEntityData.OrderByDescending(x => x.IpdDate).Select(x => x.IpdDate).Distinct().ToList();
                int RowNumber = 1;
                int DepthLevel = 0;
                HeaderExcelGenerator(headerParam, IpdDates, ref worksheet, ref RowNumber);
                RecursiveExcelGenerator(Hierarchy, ref worksheet, ref RowNumber, DepthLevel);
                worksheet.Columns().AdjustToContents();
            }

            return workbook;
        }

        public void HeaderExcelGenerator(string FirstCellName, List<DateTime> IpdDates, ref IXLWorksheet worksheet, ref int RowNumber)
        {
            worksheet.Row(RowNumber).FirstCell().Value = FirstCellName;
            for (int i = 0; i < IpdDates.Count(); i++)
            {
                worksheet.Row(RowNumber).Cell(i + 2).Value = IpdDates.ElementAt(i);
            }
            worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            worksheet.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
            RowNumber++;
        }

        public void RecursiveExcelGenerator(List<ReserveFundEntity> Hierarchy, ref IXLWorksheet worksheet, ref int RowNumber, int DepthLevel)
        {
            for (int i = 0; i < Hierarchy.Count(); i++)
            {
                var reserveFundEntityObj = Hierarchy.ElementAt(i);
                string Spaces = new string(' ', DepthLevel * 2);
                worksheet.Row(RowNumber).FirstCell().Value = Spaces + reserveFundEntityObj.DisplayName;

                // For parent columns value filling
                for (int j = 0; j < reserveFundEntityObj.LineItemValues.Count(); j++)
                {
                    worksheet.Row(RowNumber).Cell(j + 2).Value = reserveFundEntityObj.LineItemValues.ElementAt(j);
                }

                if (reserveFundEntityObj.ChildLineItems != null && reserveFundEntityObj.ChildLineItems.Count() > 0)
                {
                    worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
                    RowNumber++;
                    RecursiveExcelGenerator(reserveFundEntityObj.ChildLineItems, ref worksheet, ref RowNumber, DepthLevel + 1);
                }
                else
                {
                    // For Child columns value filling
                    for (int j = 0; j < reserveFundEntityObj.LineItemValues.Count(); j++)
                    {
                        worksheet.Row(RowNumber).Cell(j + 2).Value = reserveFundEntityObj.LineItemValues.ElementAt(j);
                    }
                    worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
                    RowNumber++;
                }
            }
        }
        
        public DataTable GetReserveFundIpdDateHeader(IPDFeedParam ipdFeedParam)
        {
            DataTable objDt = new DataTable();
            var obj = _reserveFundService.GetReserveFund(ipdFeedParam);
            if (obj != null)
            {
                DataView view = obj.DefaultView;
                view.Sort = "IpdDate DESC";
                objDt = view.ToTable(true, "IpdDate");
            }
            return objDt;
        }


        public List<RevenueLedgerFund> GetRevenueLedger(IPDFeedParam ipdFeedParam)
        {
            return _ledgersFundService.GetRevenueLedger(ipdFeedParam);
        }

        public List<PrincipalLedgerFund> GetPrincipalLedger(IPDFeedParam ipdFeedParam)
        {
            return _ledgersFundService.GetPrincipalLedger(ipdFeedParam);
        }

        public List<PaymentLedgerFund> GetPaymentLedger(IPDFeedParam ipdFeedParam)
        {
            return _ledgersFundService.GetPaymentLedger(ipdFeedParam);
        }

        public List<MaturingLoansLedgerFund> GetMaturingLoansLedger(IPDFeedParam ipdFeedParam)
        {
            return _ledgersFundService.GetMaturingLoansLedger(ipdFeedParam);
        }

        public List<CapitalAccountLedgerEntity> GetCapitalAccountLedger(IPDFeedParam ipdFeedParam)
        {
            return _ledgersFundService.GetCapitalAccountLedger(ipdFeedParam);
        }
    }
}
