﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class InvoiceFacadeService : IInvoiceFacadeService
    {
        private readonly IInvoiceService _invoiceService;
        private readonly IInvoiceCategoryService _invoiceCategoryService;
        private readonly IInvoiceCategoryTypeService _invoiceCategoryTypeService;
        //private readonly IFactory factory;

        public InvoiceFacadeService(IInvoiceService invoiceService, IInvoiceCategoryService invoiceCategoryService,
            IInvoiceCategoryTypeService invoiceCategoryTypeService)
        {
            this._invoiceService = invoiceService;
            this._invoiceCategoryService = invoiceCategoryService;
            this._invoiceCategoryTypeService = invoiceCategoryTypeService;
        }

        /// <summary>
        /// This will return the invoice category Type
        /// </summary>
        public IList<InvoiceCategoryTypeEntity> GetInvoiceCategoryType(string loggedInUser)
        {
            return this._invoiceCategoryTypeService.GetInvoiceCategoryType(loggedInUser);
        }

        /// <summary>
        /// This will return the invoice categories based on type
        /// </summary>
        /// <param name="invoiceCategoryTypeId"></param>
        /// <returns></returns>
        public IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryTypeId, string loggedInUser)
        {
            return this._invoiceCategoryService.GetInvoiceCategory(invoiceCategoryTypeId, loggedInUser);
        }

        /// <summary>
        /// This will return the invoice data 
        /// </summary>
        /// <param name="invoiceParams"></param>
        /// <returns></returns>
        public IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams, string loggedInUser)
        {
            return _invoiceService.GetInvoiceList(invoiceParams, loggedInUser);
        }

        /// <summary>
        /// This will return the single invoice record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public InvoiceDataEntity GetInvoice(int invoiceId, string loggedInUser)
        {
            return _invoiceService.GetInvoice(invoiceId, loggedInUser);
        }

        /// <summary>
        /// This will save the invoice data 
        /// </summary>
        /// <param name="invoiceData"></param>
        /// <returns></returns>
        public int SaveInvoiceData(InvoiceDataEntity invoiceData, string loggedInUser)
        {
            return _invoiceService.SaveInvoiceData(invoiceData, loggedInUser);
        }

        /// <summary>
        /// This will return the invoice data 
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        public int DeleteInvoiceData(int invoiceId, string loggedInUser)
        {
            return _invoiceService.DeleteInvoiceData(invoiceId, loggedInUser);
        }

        public IList<InvoiceDataEntity> GetInvoiceIpdData(IPDFeedParam iPDFeedParam)
        {
            return _invoiceService.GetInvoiceIpdData(iPDFeedParam);
        }

        public decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate, string userName)
        {
            return _invoiceService.GetSpotRate(dealId, invoiceCurrencyId, spotRateDate, userName);
        }
    }
}
