﻿using Microsoft.Extensions.Options;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Interface.CW;
using System;
using System.Collections.Generic;
using System.Text;
using System.Data;

namespace NW.SFP.BusinessService.CW
{
    public class DataLoadService : IDataLoadService
    {

        private readonly IDataLoadDataService _loadDataService;


        public DataLoadService(IDataLoadDataService LoadDataService)
        {
            this._loadDataService = LoadDataService;
        }

        public bool ProcessDataLoad(string loadType, string asAtDate, string userName)
        {
            return _loadDataService.ProcessDataLoad(loadType, asAtDate, userName);
        }

        public DataTable GetDataLoadDates()
        {
            return _loadDataService.GetDataLoadDates();
        }

    }
}
