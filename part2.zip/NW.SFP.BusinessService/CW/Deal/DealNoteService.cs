﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
   public class DealNoteService : IDealNoteService
    {
        private readonly IDealNoteDataService _dealNoteDataService;

        //private readonly IFactory factory;

        public DealNoteService(IDealNoteDataService dealNoteDataService)
        {
            this._dealNoteDataService = dealNoteDataService;
        }

        /// <summary>
        /// This will return the active deals detail
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealNoteInfoEntity> GetDealNoteList(IPDFeedParam ipdFeedParam,string loggedInUser)
        {
            return _dealNoteDataService.GetDealNoteList(ipdFeedParam,loggedInUser);
        }

        public int SaveDealNoteData(DealNoteInfoEntity dealNoteInfoEntity)
        {
            return _dealNoteDataService.SaveDealNoteData(dealNoteInfoEntity);
        }

        public int ManageDealNoteAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            return _dealNoteDataService.ManageDealNoteAuthWorkflow(authWorkflowEntity);
        }

        public int DealNoteSentforAuthorization(DealNoteInfoEntity dealNoteInfoEntity)
        {
            return _dealNoteDataService.DealNoteSentforAuthorization(dealNoteInfoEntity);
        }
    }
}
