﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class DealDateService : IDealDateService
    {
        private readonly IDealDateDataService _dealDateDataService;

        public DealDateService(IDealDateDataService dealdateDataService)
        {
            this._dealDateDataService = dealdateDataService;
        }

        /// <summary>
        /// This will return the active deals names
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealIpdEntity> GetDealNextIpd(int dealId, string loggedInUser)
        {
            return _dealDateDataService.GetDealNextIpd(dealId, loggedInUser);
        }
    }
}
