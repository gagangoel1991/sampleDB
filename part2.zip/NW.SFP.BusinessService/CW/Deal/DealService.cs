﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class DealService : IDealService
    {
        private readonly IDealDataService _dealDataService;

        //private readonly IFactory factory;

        public DealService(IDealDataService dealDataService)
        {
            this._dealDataService = dealDataService;
        }


        /// <summary>
        /// This will return the active deals detail
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealEntity> GetDealList(string loggedInUser, int assetClassId)
        {
            return _dealDataService.GetDealList(loggedInUser , assetClassId);
        }

        public int SaveDeal(DealEntity dealEntity, int assetClassId)
        {
            return _dealDataService.SaveDeal(dealEntity, assetClassId);
        }


        public DealEntity GetDeal(int dealId, string userName)
        {
            return _dealDataService.GetDeal(dealId, userName);
        }

        public int DeleteDeal(int dealId, string userName)
        {
            return _dealDataService.DeleteDeal(dealId, userName);
        }

        public int ManageDealAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            return _dealDataService.ManageDealAuthWorkflow(authWorkflowEntity);
        }

        public int DealCollapseSentforAuthorization(DealEntity dealEntity)
        {
            return _dealDataService.DealCollapseSentforAuthorization(dealEntity);
        }

        public int GetValidateCollapseDeal(int dealId, string userName)
        {
            return _dealDataService.GetValidateCollapseDeal(dealId, userName);
        }


        public string GetDealLatestAuthorisedIpdDate(int dealId, string userName)
        {
            return _dealDataService.GetDealLatestAuthorisedIpdDate(dealId, userName);
        }

        public List<DealSecurityItemsList> getDealSecurityListItems(int dealId, string userName)
        {

            return this._dealDataService.getDealSecurityListItems(dealId, userName);
        }




    }
}
