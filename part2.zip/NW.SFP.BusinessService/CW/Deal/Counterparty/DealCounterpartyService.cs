﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class DealCounterpartyService : IDealCounterpartyService
    {
        private readonly IDealCounterpartyDataService _dealCounterpartyDataService;

        public DealCounterpartyService(IDealCounterpartyDataService dealCounterpartyDataService)
        {
            this._dealCounterpartyDataService = dealCounterpartyDataService;
        }

        /// <summary>
        /// This will return the deal counter party
        /// </summary>
        /// <param name="dealId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealCounterpartyEntity> GetDealCounterparty(int dealId, string loggedInUser)
        {
            return this._dealCounterpartyDataService.GetDealCounterparty(dealId, loggedInUser);
        }
    }
}
