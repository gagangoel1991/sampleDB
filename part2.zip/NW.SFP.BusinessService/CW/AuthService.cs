﻿using NW.SFP.Interface.CW;
using NW.SFP.Message;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class AuthService : IAuthService
    {
        private readonly IAuthDataService _authDataService;

        public AuthService(IAuthDataService authDataService)
        {
            this._authDataService = authDataService;
        }

        /// <summary>
        /// This will return the user's default asset class
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="adGroupName"></param>
        /// <returns></returns>
        public string GetDefaultAssetClass(string userName, string adGroupName)
        {
            return this._authDataService.GetDefaultAssetClass(userName, adGroupName);
        }

        /// <summary>
        /// This will return the user basic detail and all left menu items
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="adGroupName"></param>
        /// <param name="selectedAssetId"></param>
        /// <returns></returns>
        public UserDetailEntity GetUserAndMenuData(string userName, string adGroupName, int selectedAssetId)
        {
            return this._authDataService.GetUserAndMenuData(userName, adGroupName, selectedAssetId);
        }

        /// <summary>
        /// This will return the deal IPD left menu items
        /// </summary>
        /// <param name="dealId"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public IList<MenuItemEntity> GetDealIpdMenuData(int dealId, string userName)
        {
            return this._authDataService.GetDealIpdMenuData(dealId, userName);
        }

        /// <summary>
        /// This will validate the user action based on the user role
        /// </summary>
        /// <param name="authParams"></param>
        /// <returns></returns>
        public bool IsUserActionAuthorized(UserAuthParams authParams)
        {
            return this._authDataService.IsUserActionAuthorized(authParams);
        }

        /// <summary>
        /// This will return the AD Group Names
        /// </summary>
        /// <param name="currentUser"></param>
        /// <returns></returns>
        public IList<string> GetADGroup(string currentUser)
        {
            return this._authDataService.GetADGroup(currentUser);
        }
    }
}
