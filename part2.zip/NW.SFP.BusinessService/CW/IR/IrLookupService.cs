﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class IrLookupService : IIrLookupService
    {
        private readonly IIrLookupDataService _irLookupDataService;
        //private readonly IFactory factory;

        public IrLookupService(IIrLookupDataService irLookupDataService)
        {
            this._irLookupDataService = irLookupDataService;
        }

        /// <summary>
        /// This will return the Strats Master List based on strat type
        /// </summary>
        /// <param name="stratTypeId"></param>
        /// <param name="loggedInUserName"></param>
        /// <returns></returns>
        public IList<StratLookup> GetStratLookup(int stratTypeId, string loggedInUserName)
        {
            return _irLookupDataService.GetStratLookup(stratTypeId, loggedInUserName);
        }
    }
}
