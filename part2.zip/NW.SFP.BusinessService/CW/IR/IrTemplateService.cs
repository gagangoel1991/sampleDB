﻿namespace NW.SFP.BusinessService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.CW;
    using NW.SFP.Interface.CW;


    public class IrTemplateService : IIrTemplateService
    {
        private IIrTemplateDataService templateRepository;

        //private readonly IFactory factory;

        public IrTemplateService(IIrTemplateDataService templateRepository)
        {
            this.templateRepository = templateRepository;
        }

        public IList<IrTemplateEntity> GetTemplateList(int assetClassId, string ReportTypeName = "")
        {
            IList<IrTemplateEntity> templateList = this.templateRepository.GetTemplateList(assetClassId, ReportTypeName);
            return templateList;
        }

        public IrTemplateEntity GetTemplateDetail(int templateId, string UserName, string ReportTypeName = "")
        {
            IrTemplateEntity template = this.templateRepository.GetTemplateDetail(templateId, UserName, ReportTypeName);
            return template;
        }


        public int Save(IrTemplateEntity template, string UserName, int assetClassId, string ReportTypeName = "")
        {
            return this.templateRepository.Save(template, UserName, assetClassId, ReportTypeName);
        }

        public int Delete(int templateId, string UserName)
        {
            return this.templateRepository.Delete(templateId, UserName);
        }
      
    }
}
