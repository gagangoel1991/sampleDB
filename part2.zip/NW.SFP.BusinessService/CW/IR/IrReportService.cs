﻿namespace NW.SFP.BusinessService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.CW;
    using NW.SFP.Interface.CW;
    using ClosedXML.Excel;
    using NW.SFP.Message.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Message.CW.IR;
    using System.Threading.Tasks;
    using NW.SFP.Common;

    public class IrReportService : IIrReportService
    {
        private IIrReportDataService reportRepository;
        private IExcelService _excelService;
        private readonly ILoggerService _loggerService;


        public IrReportService(IIrReportDataService reportRepository, IExcelService excelService, ILoggerService loggerService)
        {
            this.reportRepository = reportRepository;
            this._excelService = excelService;
            this._loggerService = loggerService;


        }

        public IEnumerable<ExcelUploadEntity> GetIrDealStratList(string DealName, string AsAtDate)
        {
                IEnumerable<ExcelUploadEntity> report = this.reportRepository.GetExcelReportList(DealName, AsAtDate);
                return report;
        }

        public DataTable GetStratData(string AsAtDate, string DealName, int FieldId, string StratName, string LoggedInUserName, string ReportTypeName)
        {
            DataTable data = this.reportRepository.GetIrStratData(AsAtDate, DealName, FieldId, StratName, LoggedInUserName, ReportTypeName);
            return data;
        }

        public IEnumerable<ExcelUploadEntity> GetBuildIrStratList(int dealIrConfigId, string AsAtDate, string ReportTypeName)
        {
            IEnumerable<ExcelUploadEntity> report = this.reportRepository.GetExcelReportList(dealIrConfigId, AsAtDate, ReportTypeName);
            return report;
        }

        public bool GenerateIRFile(string SourceFile, string TargetFile, string ParentSheet, bool GenerateFinalIrCopy,
             string ProtectSheetKey, int DealIrConfigId, string AsAtDate, IEnumerable<ExcelUploadEntity> _ExcelUploadEntity,
             string LoggedInUserName, string ReportTypeName, int AssetId = 1)
        {

            LogInfoEntity logInfo = new LogInfoEntity() { LogDetail = "IR file file writing started on  " + SourceFile, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = 1, UserName = LoggedInUserName };
            this._loggerService.LogInfo(logInfo);

            string ParentWorkSheet = (ParentSheet.Split(',').Length > 0 ? ParentSheet.Split(',')[0] : ParentSheet);
           
            string[] worksheetNames = ParentWorkSheet.Split('|');
            using (var workbook = new XLWorkbook(SourceFile))
            {

                logInfo = new LogInfoEntity() { LogDetail = "IR temp file started on  " + SourceFile, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = 1, UserName = LoggedInUserName };
                this._loggerService.LogInfo(logInfo);
                if (ReportTypeName.ToLower() == "htt" || _excelService.IsWorksheetsExist(workbook, worksheetNames))
                {
                    List<ExcelUploadEntity> _assetDataValues = _ExcelUploadEntity.ToList();
                    if (AssetId == (int)AssetType.Retail)
                    {
                        this.reportRepository.CheckAndLoadMortgageFieldData(_ExcelUploadEntity.First().DealName, AsAtDate);
                        var _tasks = new List<Task<DataTable>>();
                        foreach (ExcelUploadEntity _ExelUpld in _assetDataValues)
                        {
                            _tasks.Add(Task.Run(() => _ExelUpld.ReportDataTable
                            = this.reportRepository.GetIrStratData(AsAtDate, _ExelUpld.DealName, _ExelUpld.FieldId, _ExelUpld.StratName, LoggedInUserName, ReportTypeName, AssetId)));
                        }
                        Task.WaitAll(_tasks.ToArray());
                    }
                    else if(AssetId == (int)AssetType.Corporate)
                    {   // Temporary fix to handle DeadLock issue in CB IR report
                        foreach (ExcelUploadEntity _ExelUpld in _assetDataValues)
                        {
                            _ExelUpld.ReportDataTable
                            = this.reportRepository.GetIrStratData(AsAtDate, _ExelUpld.DealName, _ExelUpld.FieldId, _ExelUpld.StratName, LoggedInUserName, ReportTypeName, AssetId);
                        }
                    }
                    
                    foreach (ExcelUploadEntity excelReport in _ExcelUploadEntity)
                    {
                        string ReportName = string.IsNullOrEmpty(ReportTypeName) ? "IR" : ReportTypeName;
                        logInfo = new LogInfoEntity() { LogDetail = ReportName + " data fetch started for strat  " + excelReport.StratName, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                        this._loggerService.LogInfo(logInfo);


                        //Populate Data table
                        var dtGetReportAssetData = new DataTable();
                        dtGetReportAssetData = excelReport.ReportDataTable;



                        if (_excelService.IsWorksheetExist(workbook, excelReport.WorkSheetName) == false)
                        {
                            workbook.Worksheets.Add(excelReport.WorkSheetName);
                        }
                        if (excelReport.IsMappingSheetRequire == 1 || ReportName.ToLower() == "ir")
                            _excelService.WriteDataIntoExcel(dtGetReportAssetData, workbook.Worksheet(excelReport.WorkSheetName), excelReport.RowStartIndex, excelReport.ColumnStartIndex);

                        if (dtGetReportAssetData != null && (ReportName.ToLower() == "ir" || string.IsNullOrEmpty(ReportTypeName.Trim())) ||
                            excelReport.WorkSheetName == ParentWorkSheet)
                            dtGetReportAssetData.Columns.RemoveAt(0);

                        if ((ReportTypeName.ToLower() == "htt" && excelReport.IsMappingSheetRequire == 0) || (AssetId == (int)AssetType.Corporate))
                            _excelService.WriteDataIntoExcel(dtGetReportAssetData, workbook.Worksheet(excelReport.WorkSheetName), excelReport.AnchorCell);
                        else if (ReportTypeName.ToLower() != "htt" && ReportTypeName.ToLower() != "annex2d")
                            _excelService.WriteDataIntoExcel(dtGetReportAssetData, workbook.Worksheet(ParentWorkSheet), excelReport.AnchorCell);

                        logInfo = new LogInfoEntity() { LogDetail = ReportName + " data fetch completed for strat  " + excelReport.StratName, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                        this._loggerService.LogInfo(logInfo);
                       }
                        
                        
    
                        if (GenerateFinalIrCopy)
                        {
                            foreach (IXLWorksheet worksheet in workbook.Worksheets)
                            {
                                _excelService.ReplaceFormulaWithValue(workbook.Worksheet(worksheet.Name), _ExcelUploadEntity.First().IrFormatColStartIndex, _ExcelUploadEntity.First().IrFormatColEndIndex, _ExcelUploadEntity.First().IrFormatRowStartIndex, _ExcelUploadEntity.First().IrFormatRowEndIndex);

                            }
                            if (ReportTypeName.ToLower() != "htt")
                            {
                                SetupIrDownloadFileFormat(workbook, ParentWorkSheet, ProtectSheetKey);
                            }
                            else
                            {
                                SetupIrDownloadFileFormat(workbook, _ExcelUploadEntity);
                            }
                            
                        }

                    logInfo = new LogInfoEntity() { LogDetail = "IR final save process started " + TargetFile, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);

                    workbook.SaveAs(TargetFile);

                    logInfo = new LogInfoEntity() { LogDetail = "IR final save process ended " + TargetFile, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);

                }

                return true;


            }
        }
        void SetupIrDownloadFileFormat(IXLWorkbook _wb, IEnumerable<ExcelUploadEntity> excelUploadEntities)
        {
            foreach (ExcelUploadEntity excelReport in excelUploadEntities)
            {
                if(excelReport.IsMappingSheetRequire==1)
                {
                    foreach (IXLWorksheet sheetFrom in _wb.Worksheets)
                    {
                        if (sheetFrom.Worksheet.Name.ToUpper() == excelReport.WorkSheetName.ToUpper())
                        {
                            sheetFrom.Delete();
                        }
                    }
                }                
            }
        }

        void SetupIrDownloadFileFormat(IXLWorkbook _wb, string parentWorkSheet, string protectSheetKey)
            {

                foreach (IXLWorksheet sheetFrom in _wb.Worksheets)
                {
                    if (sheetFrom.Worksheet.Name.StartsWith("sys"))
                    {
                        sheetFrom.Delete();
                        //sheetFrom.Protect(protectSheetKey);
                    }
                }
            }

        public IR_Config GetDealIRConfigByDealId(int DealId, string ReportTypeName)
        {
            IR_Config report = this.reportRepository.GetDealIRConfigByDealId(DealId, ReportTypeName);
            return report;
        }

        }
    }
