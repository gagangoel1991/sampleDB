﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.BusinessService.CW
{
    public class DealIrConfigService : IDealIrConfigService
    {
        private readonly IDealIrConfigDataService _dealIrConfigDataService;

        public DealIrConfigService(IDealIrConfigDataService dealIrConfigDataService)
        {
            this._dealIrConfigDataService = dealIrConfigDataService;
        }

        /// <summary>
        /// This will return the Deal IR Config List
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public IList<DealIrConfigListEntity> GetDealIrConfigList(string userName, string ReportTypeName, int AssetClassId)
        {
            return _dealIrConfigDataService.GetDealIrConfigList(userName, ReportTypeName, AssetClassId);
        }

        /// <summary>
        /// This will return the single Deal IR Config record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public DealIrConfigEntity GetDealIrConfig(int dealIrConfigId, string loggedInUser, string ReportTypeName, int AssetClassId)
        {
            return _dealIrConfigDataService.GetDealIrConfig(dealIrConfigId, loggedInUser, ReportTypeName, AssetClassId);
        }

        /// <summary>
        /// This will save the Deal Ir Config record.
        /// </summary>
        /// <param name="dealIrConfigData"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public int SaveDealIrConfig(DealIrConfigAddEditEntity dealIrConfigData, string loggedInUser, string ReportTypeName, int AssetClassId)
        {
            return _dealIrConfigDataService.SaveDealIrConfig(dealIrConfigData, loggedInUser, ReportTypeName, AssetClassId);
        }

        /// <summary>
        /// Delete Deal Ir Config Record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public int DeleteDealIrConfig(int dealIrConfigId, string loggedInUser)
        {
            return _dealIrConfigDataService.DeleteDealIrConfig(dealIrConfigId, loggedInUser);
        }

        public List<IR_ConfigDealList> getIrConfigDealList(int dealIrConfigId, string loggedInUser, string ReportTypeName)
        {
            return _dealIrConfigDataService.getIrConfigDealList(dealIrConfigId, loggedInUser, ReportTypeName);
        }

        public List<IR_ConfigLayoutList> getIrConfigLayoutList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassID)
        {
            return _dealIrConfigDataService.getIrConfigLayoutList(dealIrConfigId, dealId, loggedInUser, ReportTypeName, AssetClassID);
        }

        public List<IR_ConfigStartList> GetIrConfStartList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassID)
        {
            return _dealIrConfigDataService.GetIrConfStartList(dealIrConfigId, dealId, loggedInUser, ReportTypeName, AssetClassID);
        }


        public int ManageDealIRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            return _dealIrConfigDataService.ManageDealIRAuthWorkflow(authWorkflowEntity);
        }
    }
}
