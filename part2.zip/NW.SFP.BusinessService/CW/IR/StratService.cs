﻿namespace NW.SFP.BusinessService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.CW;
    using NW.SFP.Interface.CW;

    public class StratService : IStratService
    {
        private IStratDataService assetStratRepository;
        private IStratConfigtDataService assetStratConfigRepository;
        private IStratDealTypeDataService stratDealTypeRepository;
        //private readonly IFactory factory;

        public StratService(IStratDataService assetStratRepository, IStratConfigtDataService assetStratConfigRepository, IStratDealTypeDataService stratDealTypeRepository)
        {
            this.assetStratRepository = assetStratRepository;
            this.assetStratConfigRepository = assetStratConfigRepository;
            this.stratDealTypeRepository = stratDealTypeRepository;
        }

        public IEnumerable<StratEntity> GetAssetStratList(int stratType, int AssetClassId, string ReportTypeName ="")
        {
            IEnumerable<StratEntity> assetStratListModel = this.assetStratRepository.GetAssetStratList(stratType, AssetClassId, ReportTypeName);
            return assetStratListModel;
        }

        public StratEntity GetAssetStratDetail(int assetStratId, string UserName, string ReportTypeName="")
        {
            StratEntity assetStratModel = this.assetStratRepository.GetAssetStratDetail(assetStratId, UserName, ReportTypeName);
            assetStratModel.StratCriteriaList = this.assetStratConfigRepository.GetAssetStratCriteriaList(assetStratId, UserName);
            var SelectedStratDealTypeList = this.stratDealTypeRepository.GetDealTypeList(assetStratId, UserName);

            List<int> DealTypeIds = new List<int>();

            foreach(var dealtypeId in SelectedStratDealTypeList)
            {
                DealTypeIds.Add(dealtypeId.DealTypeId);
            }

            assetStratModel.StratDealTypeList = DealTypeIds;

            return assetStratModel;
        }


        public StratEntity Save(StratEntity assetStratModel, string UserName, int AssetClassId, string ReportTypeName = "")
        {
            StratEntity assetStratDataModel = this.assetStratRepository.Save(assetStratModel, UserName, AssetClassId, "");

            if (assetStratDataModel.StratId == -1)
                return assetStratDataModel;

            var isDeleted = this.assetStratConfigRepository.Delete(assetStratDataModel.StratId, UserName);

            if (isDeleted)
            {
                foreach (var stratConfig in assetStratDataModel.StratCriteriaList)
                {
                    stratConfig.StratId = assetStratDataModel.StratId;
                    var stratConfigDataModel = this.assetStratConfigRepository.Save(stratConfig, UserName, ReportTypeName);
                }
            }
            return assetStratDataModel;
        }

        public StratEntity Update(StratEntity assetStratModel, string UserName)
        {
            return null;
        }

        public int Delete(int StratId, string UserName)
        {
            return this.assetStratRepository.Delete(StratId, UserName);
        }

        public DataTable GetStratPreviewData(string StratName, string AsAtDate, string DealName)
        {
            DataTable data = this.assetStratRepository.GetStratPreviewData(StratName, AsAtDate, DealName);
            return data;
        }

        public DataTable GetStratPreviewData(StratPreviewSearchEntity stratPreviewSearchEntity)
        {
            DataTable data = this.assetStratRepository.GetStratPreviewData(stratPreviewSearchEntity).Data;
            return data;
        }
        public BespokeStratPreviewEntity GetBeSpokeStratPreviewData(StratPreviewSearchEntity stratPreviewSearchEntity)
        {
            return this.assetStratRepository.GetStratPreviewData(stratPreviewSearchEntity);
        }

        public StratEntity GetBeSpokeAssetStratDetail(int StratId, string UserName)
        {

            StratEntity assetStratModel = this.assetStratRepository.GetBeSpokeAssetStratDetail(StratId, UserName);
            var SelectedStratDealTypeList = this.stratDealTypeRepository.GetDealTypeList(StratId, UserName);
            List<int> DealTypeIds = new List<int>();
            foreach (var dealtypeId in SelectedStratDealTypeList)
            {
                DealTypeIds.Add(dealtypeId.DealTypeId);
            }
            assetStratModel.StratDealTypeList = DealTypeIds;

            return assetStratModel;
        }
    }
}
