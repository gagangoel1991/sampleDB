﻿using ClosedXML.Excel;
using NW.SFP.Common;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class DailyCashEstimationService : IDailyCashEstimationService
    {
        private readonly IDailyCashCollectionsDataService _dailyCashCollectionsDataService;
        string HeaderColour = "#248dad";
        string HeaderTextColour = "#ffffff";
        string SubHeaderColour = "#808080";
        string SubHeaderTextColour = "#ffffff";

        public DailyCashEstimationService(IDailyCashCollectionsDataService dailyCashCollectionsDataService)
        {
            this._dailyCashCollectionsDataService = dailyCashCollectionsDataService;
        }

        public List<DailyCashEstimationDataEntity> GetDailyCashEstimationData(string dealName, string asAtDate, string loggedInUserName)
        {

            List<DailyCashEstimationDataEntity> dailyCashData = new List<DailyCashEstimationDataEntity>();
            var dt = _dailyCashCollectionsDataService.GetDailyCashEstimationData(dealName, asAtDate, loggedInUserName);
            if (dt != null)
            {
                var tmpData = Utils.ConvertDataTable<DailyCashEstimationDataEntity>(dt);
                return tmpData;
            }

            return null;
        }

        public List<DailyCashEstimationDataEntity> GetCashEstimationDistinct(string dealName, string asAtDate, string loggedInUserName)
        {
            List<DailyCashEstimationDataEntity> tmpDataMonth = new List<DailyCashEstimationDataEntity>();
            List<DailyCashEstimationDataEntity> dailyAndmonthlyData = new List<DailyCashEstimationDataEntity>();

            var dt = _dailyCashCollectionsDataService.GetDailyCashEstimationData(dealName, asAtDate, loggedInUserName);
            if (dt != null)
            {
                var tmpData = Utils.ConvertDataTable<DailyCashEstimationDataEntity>(dt);
                dailyAndmonthlyData = GetGroupedLineItems(tmpData, "Daily");
                tmpDataMonth = GetGroupedLineItems(tmpData, "Monthly");
                dailyAndmonthlyData.AddRange(tmpDataMonth);
                return dailyAndmonthlyData;
            }
            return null;
        }

        public List<DailyCashEstimationDataEntity> GetGroupedLineItems(List<DailyCashEstimationDataEntity> lineItems, string estimationType)
        {
            if (estimationType == "ALL")
            {
                return lineItems
                    .GroupBy(c => c.LineItem)
                    .Select(c => new DailyCashEstimationDataEntity
                    {
                        IsParent = c.Select(x => x.IsParent).FirstOrDefault(),
                        EstimationType = c.Select(x => x.EstimationType).FirstOrDefault(),
                        LineItem = c.Select(x => x.LineItem).FirstOrDefault(),
                        CollectionDate = c.Select(x => x.CollectionDate).FirstOrDefault(),
                    }).ToList();
            }
            else
            {
                return lineItems
                    .Where(c => c.EstimationType == estimationType)
                    .GroupBy(c => c.LineItem)
                    .Select(c => new DailyCashEstimationDataEntity
                    {
                        IsParent = c.Select(x => x.IsParent).FirstOrDefault(),
                        EstimationType = c.Select(x => x.EstimationType).FirstOrDefault(),
                        LineItem = c.Select(x => x.LineItem).FirstOrDefault(),
                        CollectionDate = c.Select(x => x.CollectionDate).FirstOrDefault(),
                    }).ToList();
            }
        }

        public IXLWorkbook GetDailyCashEstimationExcel(string dealName, string asAtDate, string loggedInUserName)
        {
            string TestTypeName = dealName;
            string FirstCell = string.Empty;
            string SecondCell = string.Empty;
            FirstCell = "  ";
            SecondCell = "  ";
            IXLWorkbook workbook = new XLWorkbook();
            List<DailyCashEstimationDataEntity> dailyCashFullData = new List<DailyCashEstimationDataEntity>();
            List<DailyCashEstimationDataEntity> dailyCashGroupingData = new List<DailyCashEstimationDataEntity>();
            List<DailyCashEstimationDataEntity> distinctBrandsTemp = new List<DailyCashEstimationDataEntity>();
            string[] distinctBrands;

            var dt = _dailyCashCollectionsDataService.GetDailyCashEstimationData(dealName, asAtDate, loggedInUserName);
            if (dt != null)
            {
                var distinctTmp = Utils.ConvertDataTable<DailyCashEstimationDataEntity>(dt);
                distinctBrandsTemp = GetDistinctBrands(distinctTmp);

                distinctBrands = ((IEnumerable)distinctBrandsTemp.Select(x => x.BrandName)).Cast<object>()
                            .Select(x => x.ToString())
                            .ToArray();

                // Find out max length value from array and place that value at last in the array.
                string maxLengthValue = distinctBrands.OrderByDescending(s => s.Length).First();
                distinctBrands = distinctBrands.Where(s => s != maxLengthValue).ToArray();
                distinctBrands = distinctBrands.Append(maxLengthValue).ToArray();

                var tmpData = Utils.ConvertDataTable<DailyCashEstimationDataEntity>(dt);
                dailyCashFullData = tmpData;

                var tmpDataGrouping = Utils.ConvertDataTable<DailyCashEstimationDataEntity>(dt);
                dailyCashGroupingData = GetGroupedLineItems(tmpDataGrouping, "ALL");

                IXLWorksheet worksheet = workbook.Worksheets.Add(TestTypeName);
                HeaderExcelGenerator(FirstCell, SecondCell, distinctBrands, ref worksheet);
                ExcelDataGenerator(dailyCashGroupingData, distinctBrands, dailyCashFullData, ref worksheet);
                worksheet.Columns().AdjustToContents();
            }
            return workbook;
        }

        public void HeaderExcelGenerator(string FirstCellName, string SecondCell, string[] distinctBrands, ref IXLWorksheet worksheet)
        {
            int RowNumber = 1;
            worksheet.Row(RowNumber).FirstCell().Value = FirstCellName;
            worksheet.Row(RowNumber).Cell(2).Value = SecondCell;
            int iCounter = 3;
            char startChar;
            char endChar;
            char charIncreament = 'F';
            int singleWindow = 1;
            foreach (var item in distinctBrands)
            {
                string rangeValue = string.Empty;
                worksheet.Row(RowNumber).Cell(iCounter).Value = item.ToString();
                iCounter = iCounter + 3;

                // Logic to Merge 3 Cells dynamically
                if (singleWindow == 1)
                {
                    worksheet.Range("C1:E1").Merge();
                    singleWindow++;
                }
                else
                {
                    // Increment characters A to so on..
                    startChar = charIncreament;
                    charIncreament++;
                    charIncreament++;
                    endChar = charIncreament;
                    rangeValue = startChar + "1:" + endChar + "1";
                    worksheet.Range(rangeValue).Merge();
                    charIncreament++;
                }
            }

            // Sub-Header Creation
            worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            worksheet.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;

            int RowNum = 2;
            worksheet.Row(RowNum).FirstCell().Value = "  ";
            worksheet.Row(RowNum).Cell(2).Value = "Collection Date";
            int iCount = 3;
            foreach (var item in distinctBrands)
            {
                worksheet.Row(RowNum).Cell(iCount).Value = "Principal";
                iCount++;
                worksheet.Row(RowNum).Cell(iCount).Value = "Revenue";
                iCount++;
                worksheet.Row(RowNum).Cell(iCount).Value = "Total";
                iCount++;
            }
            worksheet.Row(RowNum).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(SubHeaderColour);
            worksheet.Row(RowNum).Cells().Style.Font.FontColor = XLColor.FromHtml(SubHeaderTextColour);
            worksheet.Row(RowNum).Cells().Style.Font.Bold = true;
            RowNumber++;
        }

        public void ExcelDataGenerator(List<DailyCashEstimationDataEntity> dailyCashGroupingData, string[] distinctBrands, List<DailyCashEstimationDataEntity> dailyCashFullData, ref IXLWorksheet worksheet)
        {
            int RowNumber = 3;
            for (int i = 0; i < dailyCashGroupingData.Count(); i++)
            {
                string LineItem = dailyCashGroupingData[i].LineItem;
                DateTime CollectionDate = dailyCashGroupingData[i].CollectionDate;
                decimal Principal = 0;
                decimal Revenue = 0;
                decimal Total = 0;
                int iCount = 1;

                worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;
                iCount++;

                if (CollectionDate == DateTime.MinValue)
                    worksheet.Row(RowNumber).Cell(iCount).Value = "";
                else
                    worksheet.Row(RowNumber).Cell(iCount).Value = CollectionDate;
                iCount++;

                foreach (var item in distinctBrands)
                {
                    ReturnAmountColumns(dailyCashFullData, dailyCashGroupingData[i].LineItem, item.ToString(), out Principal, out Revenue, out Total);

                    worksheet.Row(RowNumber).Cell(iCount).Value = Principal > 0 ? Principal.ToString() : "";
                    iCount++;
                    worksheet.Row(RowNumber).Cell(iCount).Value = Revenue > 0 ? Revenue.ToString() : "";
                    iCount++;
                    worksheet.Row(RowNumber).Cell(iCount).Value = Total > 0 ? Total.ToString() : "";
                    iCount++;
                }

                if (dailyCashGroupingData[i].IsParent > 0)
                {
                    worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
                }
                RowNumber++;
            }
        }

        public List<DailyCashEstimationDataEntity> GetDistinctBrands(List<DailyCashEstimationDataEntity> distinctBrands)
        {
            return distinctBrands
                    .GroupBy(c => c.BrandName)
                    .Select(c => new DailyCashEstimationDataEntity
                    {
                        BrandName = c.Select(x => x.BrandName).FirstOrDefault(),
                    }).ToList();
        }

        public void ReturnAmountColumns(List<DailyCashEstimationDataEntity> dailyCashFullData, string LineItem, string BrandName, out decimal Principal, out decimal Revenue, out decimal Total)
        {
            Principal = 0;
            Revenue = 0;
            Total = 0;

            var AmtValues = (from d in dailyCashFullData
                             where d.LineItem == LineItem && d.BrandName == BrandName
                             select new
                             {
                                 d.Principal,
                                 d.Revenue,
                                 d.Total
                             }).First();

            if (AmtValues != null)
            {
                decimal.TryParse(AmtValues.Principal.ToString(), out Principal);
                decimal.TryParse(AmtValues.Revenue.ToString(), out Revenue);
                decimal.TryParse(AmtValues.Total.ToString(), out Total);
            }
        }

        public DateTime GetCollectionDate(string asAtDate, string dealName, string loggedInUser)
        {
            return _dailyCashCollectionsDataService.GetCollectionDate(asAtDate, dealName, loggedInUser);
        }
    }
}