﻿using ClosedXML.Excel;
using NW.SFP.Common;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class DealSummaryOutputService : IDealSummaryOutputService
    {

        private readonly IDealSummaryOutputDataService _dealSummaryOutputDataService;

        private readonly IDailyCollectionDealDataSummary _dailyCollectionDealDataSummary;

        public DealSummaryOutputService(IDealSummaryOutputDataService dealSummaryOutputDataService, IDailyCollectionDealDataSummary dailyCollectionDealDataSummary)
        {
            this._dealSummaryOutputDataService = dealSummaryOutputDataService;
            this._dailyCollectionDealDataSummary = dailyCollectionDealDataSummary;
        }

        public List<DealSummaryDataEntity> GetDealSummaryOutputData(DataTable ListCollDate, string dealName, string dealCategoryName,string viewType ,string loggedInUser)
        {
            return _dealSummaryOutputDataService.GetDealSummaryOutputData(ListCollDate, dealName, dealCategoryName, viewType, loggedInUser);
        }

        public int SaveDealSummayAdjustment(List<DealSummarySaveAdjustmentModel> dealSummarySaveAdjustmentModel, string loggedInUser)
        {
            return _dealSummaryOutputDataService.SaveDealSummayAdjustment(dealSummarySaveAdjustmentModel, loggedInUser);
        }


        public List<DealSummaryDataEntity> GetDealSummaryAuditData(DataTable ListCollDate, string dealName, string loggedInUser)
        {
            return _dealSummaryOutputDataService.GetDealSummaryAuditData(ListCollDate, dealName, loggedInUser);
        }

        public int SaveDealSummayAudit(DealSummarySaveAuditModel dealSummarySaveAuditModel, string loggedInUser)
        {
            return _dealSummaryOutputDataService.SaveDealSummayAudit(dealSummarySaveAuditModel, loggedInUser);
        }

        public int ManageDealSummaryAuditAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            return _dealSummaryOutputDataService.ManageDealSummaryAuditAuthWorkflow(authWorkflowEntity);
        }

        public DailyCollectionDates GetCollectionDateList(DateTime asAtDate, string dealName, string loggedInUser)
        {
            DailyCollectionDates objdailyCollection = new DailyCollectionDates();
            objdailyCollection.AdviceDates = _dealSummaryOutputDataService.GetCollectionDateList(asAtDate, dealName, "Advice", loggedInUser);


            var maxAdviceDate = objdailyCollection.AdviceDates.Max(); //.ToString("yyyy-MM-dd");

            objdailyCollection.CollectionDates = _dealSummaryOutputDataService.GetCollectionDateList(maxAdviceDate, dealName, "Collection", loggedInUser);

            return objdailyCollection;

        }

        public DailyCollectionDealSummaryModel GetDailyCollectionDealSummary(DateTime adviceDate, string dealName, string loggedInUser)
        {
            return _dailyCollectionDealDataSummary.GetDailyCollectionDealSummary(adviceDate, dealName, loggedInUser);
        }

        public IXLWorkbook GetDealSummaryExcel(DailyCollectionDatesExcel dailyCollectionDatesExcel, string loggedInUserer)
        {
            string dealName = dailyCollectionDatesExcel.dealName;
            string FirstCell = string.Empty;
            string SecondCell = string.Empty;
            FirstCell = "  ";
            SecondCell = "  ";
            IXLWorkbook workbook = new XLWorkbook();
            DailyCollectionDealSummaryModel objdailyCollectionDealSummaryData = new DailyCollectionDealSummaryModel();
            DailyCollectionDates objdailyCollectionData = new DailyCollectionDates();
            if (dailyCollectionDatesExcel.isMultiDateList == true)
            {
                objdailyCollectionData.AdviceDates = dailyCollectionDatesExcel.AdviceDates;
                objdailyCollectionData.CollectionDates = dailyCollectionDatesExcel.CollectionDates;
                objdailyCollectionDealSummaryData = _dailyCollectionDealDataSummary.GetDailyCollectionDealSummary(dailyCollectionDatesExcel.AdviceDates[0], dealName, loggedInUserer);
            }
            else
            {
                objdailyCollectionDealSummaryData = _dailyCollectionDealDataSummary.GetDailyCollectionDealSummary(dailyCollectionDatesExcel.adviceDate, dealName, loggedInUserer);
                objdailyCollectionData.AdviceDates = _dealSummaryOutputDataService.GetCollectionDateList(dailyCollectionDatesExcel.adviceDate, dealName, "Advice", loggedInUserer);
                objdailyCollectionData.CollectionDates = _dealSummaryOutputDataService.GetCollectionDateList(dailyCollectionDatesExcel.adviceDate, dealName, "Collection", loggedInUserer);
            }
            List<DealSummaryDataEntity> dailyCollectionOuputData = new List<DealSummaryDataEntity>();
            DealSummaryDataModel dealSummaryDataModel = new DealSummaryDataModel();
            string[] collectionEndDateList = null;
            List<string> collectionDateList = new List<string>();
            for (int i = 0; i < objdailyCollectionData.AdviceDates.Count; i++)
            {
                string collectionDate = objdailyCollectionData.AdviceDates[i].ToString("dd-MMM-yyyy");
                collectionDateList.Add(collectionDate);
            }
            collectionEndDateList = collectionDateList.ToArray();
            dealSummaryDataModel.adviceDate = collectionEndDateList;
            dealSummaryDataModel.dealCategoryName = "Deal Summary - Output";

            DataTable ListCollDate = Utils.SetSelectListTableDateValues(dealSummaryDataModel.adviceDate);
            dailyCollectionOuputData = _dealSummaryOutputDataService.GetDealSummaryOutputData(ListCollDate, dealName, dealSummaryDataModel.dealCategoryName, dailyCollectionDatesExcel.viewType,loggedInUserer);

            List<DealSummaryDataEntity> dailyCollectionAdjustmentData = new List<DealSummaryDataEntity>();
            dealSummaryDataModel.dealCategoryName = "Deal Summary - Adjustments";
            dailyCollectionAdjustmentData = _dealSummaryOutputDataService.GetDealSummaryOutputData(ListCollDate, dealName, dealSummaryDataModel.dealCategoryName, dailyCollectionDatesExcel.viewType, loggedInUserer);


            List<DealSummaryDataEntity> dailyCollectionDeflagData = new List<DealSummaryDataEntity>();
            dealSummaryDataModel.dealCategoryName = "Deal Summary - DeflagBreakup";
            dailyCollectionDeflagData = _dealSummaryOutputDataService.GetDealSummaryOutputData(ListCollDate, dealName, dealSummaryDataModel.dealCategoryName, dailyCollectionDatesExcel.viewType, loggedInUserer);

            List<DealSummaryDataEntity> dailyCollectionControlCheckData = new List<DealSummaryDataEntity>();
            dealSummaryDataModel.dealCategoryName = "Deal Summary - ControlCheck";
            dailyCollectionControlCheckData = _dealSummaryOutputDataService.GetDealSummaryOutputData(ListCollDate, dealName, dealSummaryDataModel.dealCategoryName, dailyCollectionDatesExcel.viewType, loggedInUserer);


            List<DealSummaryDataEntity> dailyCollectionAuditData = new List<DealSummaryDataEntity>();
            dailyCollectionAuditData = _dealSummaryOutputDataService.GetDealSummaryAuditData(ListCollDate, dealName, loggedInUserer);
            
            IXLWorksheet worksheet = workbook.Worksheets.Add(dealName);
            HeaderExcelGenerator(FirstCell, SecondCell, objdailyCollectionData, objdailyCollectionDealSummaryData, dealName, ref worksheet);
            ExcelDataGenerator(dailyCollectionOuputData, objdailyCollectionData, dailyCollectionAdjustmentData, dailyCollectionDeflagData, dailyCollectionControlCheckData,dailyCollectionAuditData,dealName, ref worksheet);
            worksheet.Columns().AdjustToContents();
            return workbook;
        }


        public void HeaderExcelGenerator(string FirstCellName, string SecondCell, DailyCollectionDates distinctCollectionDates,
                                                     DailyCollectionDealSummaryModel objdailyCollectionDealSummaryData,string dealName, ref IXLWorksheet worksheet)
        {
            int RowNumber = 1;
            //worksheet.Row(RowNumber).FirstCell().Value = FirstCellName;
            //worksheet.Row(RowNumber).Cell(2).Value = SecondCell;
            RowNumber++;

            worksheet.Row(RowNumber).FirstCell().Value = "Next IPD";
            if (objdailyCollectionDealSummaryData!=null)
            {
                worksheet.Row(RowNumber).Cell(2).Value = objdailyCollectionDealSummaryData.NextIpd;
            }
            worksheet.Row(RowNumber).Cell(3).Value = "Collection Start Date";
            if (objdailyCollectionDealSummaryData != null)
            {
                worksheet.Row(RowNumber).Cell(4).Value = objdailyCollectionDealSummaryData.CollectionAdvicestartDate;
            }
            worksheet.Row(RowNumber).Cell(5).Value = "Rate Reset";
            if (objdailyCollectionDealSummaryData != null)
            {
                worksheet.Row(RowNumber).Cell(6).Value = objdailyCollectionDealSummaryData.RateReset;
            }
            RowNumber++;


            worksheet.Row(RowNumber).FirstCell().Value = "Previous IPD";
            if (objdailyCollectionDealSummaryData != null)
            {
                worksheet.Row(RowNumber).Cell(2).Value = objdailyCollectionDealSummaryData.PreviousIpd;
            }
            worksheet.Row(RowNumber).Cell(3).Value = "Collection End Date";
            if (objdailyCollectionDealSummaryData != null)
            {
                worksheet.Row(RowNumber).Cell(4).Value = objdailyCollectionDealSummaryData.CollectionAdviceEndDate;
            }

            if (dealName.ToLower() != "deimos")
            {
                worksheet.Row(RowNumber).Cell(5).Value = "Current Euribor";
                if (objdailyCollectionDealSummaryData != null)
                {
                    worksheet.Row(RowNumber).Cell(6).Value = objdailyCollectionDealSummaryData.CurrentEuribor;
                }
            }
            RowNumber++;
            int iCounter = 2;
            char startChar;
            char endChar;
            char charIncreament = 'F';
            int singleWindow = 1;

            worksheet.Row(RowNumber).FirstCell().Value = "Advice Date";
            foreach (var item in distinctCollectionDates.AdviceDates)
            {
                string rangeValue = string.Empty;
                worksheet.Row(RowNumber).Cell(iCounter).Value = item;
                iCounter = iCounter + 1;

                // Logic to Merge 3 Cells dynamically

            }
            iCounter = 2;
            RowNumber++;
            worksheet.Row(RowNumber).FirstCell().Value = "Collection Date";
            foreach (var item in distinctCollectionDates.CollectionDates)
            {
                string rangeValue = string.Empty;
                worksheet.Row(RowNumber).Cell(iCounter).Value = item;
                iCounter = iCounter + 1;

                // Logic to Merge 3 Cells dynamically

            }

            
        }

        public void ExcelDataGenerator(List<DealSummaryDataEntity> dailyCollectionOuputData, DailyCollectionDates distinctCollectionDates,
                                       List<DealSummaryDataEntity> dailyCollectionAdjustmentData, List<DealSummaryDataEntity> dailyCollectionDeflagData, List<DealSummaryDataEntity> dailyCollectionControlCheckData,
                                       List<DealSummaryDataEntity> dailyCollectionAuditData,string dealName,ref IXLWorksheet worksheet)
        {
            int RowNumber = 8;
            //OutPut Data
            var dailyCollectionOuputDataList = dailyCollectionOuputData as List<DealSummaryDataEntity>;
            var outputCollectionLineItemList = dailyCollectionOuputDataList.Select(  s => s.LineItem ).Distinct();
            List<string> outputCollectionLineItemListData = outputCollectionLineItemList.ToList();


            worksheet.Row(RowNumber).FirstCell().Value = "Collection Output";
            worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
            RowNumber++;
            RowNumber++;
            for (int i = 0; i < outputCollectionLineItemListData.Count; i++)
            {
                int iCount = 1;
                string LineItem = outputCollectionLineItemListData[i];

                worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;

                for (int j = 0; j < distinctCollectionDates.CollectionDates.Count ; j++)
                {
                    // iCount++;
                    //  int jCount = 1;
                    for (int k = 0; k < dailyCollectionOuputData.Count; k++)
                    {
                        if (distinctCollectionDates.CollectionDates[j] == dailyCollectionOuputData[k].CollectionDate && dailyCollectionOuputData[k].LineItem == LineItem)
                        {
                            worksheet.Row(RowNumber).Cell(j + 2).Value = dailyCollectionOuputData[k].Value;
                        }
                    }

                }

                //     DateTime CollectionDate = dailyCashGroupingData[i].CollectionDate;


                //worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;
                //iCount++;

                //if (CollectionDate == DateTime.MinValue)
                //    worksheet.Row(RowNumber).Cell(iCount).Value = "";
                //else
                //    worksheet.Row(RowNumber).Cell(iCount).Value = CollectionDate;
                //iCount++;

                //foreach (var item in distinctBrands)
                //{
                //    ReturnAmountColumns(dailyCashFullData, dailyCashGroupingData[i].LineItem, item.BrandName, out Principal, out Revenue, out Total);

                //    worksheet.Row(RowNumber).Cell(iCount).Value = Principal > 0 ? Principal.ToString() : "";
                //    iCount++;
                //    worksheet.Row(RowNumber).Cell(iCount).Value = Revenue > 0 ? Revenue.ToString() : "";
                //    iCount++;
                //    worksheet.Row(RowNumber).Cell(iCount).Value = Total > 0 ? Total.ToString() : "";
                //    iCount++;
                //}

                //if (dailyCashGroupingData[i].IsParent > 0)
                //{
                //    worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;

                RowNumber++;
            }


            //Adjustment Data

            RowNumber++;
            RowNumber++;
            var dailyCollectionAdjustmentDataList = dailyCollectionAdjustmentData as List<DealSummaryDataEntity>;
            var adjustmenCollectiontLineItemList = dailyCollectionAdjustmentDataList.Select(s => s.LineItem).Distinct();
            List<string> adjustmentCollectionLineItemListData = adjustmenCollectiontLineItemList.ToList();

            worksheet.Row(RowNumber).FirstCell().Value = "Adjustment";
            worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
            RowNumber++;
            RowNumber++;
            for (int i = 0; i < adjustmentCollectionLineItemListData.Count; i++)
            {
                int iCount = 1;
                string LineItem = adjustmentCollectionLineItemListData[i];

                worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;

                for (int j = 0; j < distinctCollectionDates.CollectionDates.Count; j++)
                {
                    // iCount++;
                    //  int jCount = 1;
                    for (int k = 0; k < dailyCollectionAdjustmentData.Count; k++)
                    {
                        if (distinctCollectionDates.CollectionDates[j] == dailyCollectionAdjustmentData[k].CollectionDate && dailyCollectionAdjustmentData[k].LineItem == LineItem)
                        {
                            worksheet.Row(RowNumber).Cell(j + 2).Value = dailyCollectionAdjustmentData[k].Value;
                        }
                    }

                } 
                RowNumber++;
            }

            //Deflag Breakup Data

            RowNumber++;
            RowNumber++;
            var dailyCollectionDeflagDataList = dailyCollectionDeflagData as List<DealSummaryDataEntity>;
            var deflagCollectiontLineItemList = dailyCollectionDeflagDataList.Select(s => s.LineItem).Distinct();
            List<string> deflagCollectionLineItemListData = deflagCollectiontLineItemList.ToList();


            worksheet.Row(RowNumber).FirstCell().Value = "Deflag-Breakup";
            worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
            RowNumber++;
            RowNumber++;
            for (int i = 0; i < deflagCollectionLineItemListData.Count; i++)
            {
                int iCount = 1;
                string LineItem = deflagCollectionLineItemListData[i];

                worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;

                for (int j = 0; j < distinctCollectionDates.CollectionDates.Count; j++)
                {
                    // iCount++;
                    //  int jCount = 1;
                    for (int k = 0; k < dailyCollectionDeflagData.Count; k++)
                    {
                        if (distinctCollectionDates.CollectionDates[j] == dailyCollectionDeflagData[k].CollectionDate && dailyCollectionDeflagData[k].LineItem == LineItem)
                        {
                            worksheet.Row(RowNumber).Cell(j + 2).Value = dailyCollectionDeflagData[k].Value;
                        }
                    }

                }
                RowNumber++;
            }

            //ControlCheck Data

            RowNumber++;
            RowNumber++;
            var dailyCollectionControlCheckDataList = dailyCollectionControlCheckData as List<DealSummaryDataEntity>;
            var dailyCollectionControlCheckLatestDate = dailyCollectionControlCheckDataList.Where(a => a.CollectionDate == distinctCollectionDates.CollectionDates[0]).Select(a => a.CollectionDate).ToList();
            var controlCheckCollectiontLineItemList = dailyCollectionControlCheckDataList.Select(s => s.LineItem).ToList();
            List<string> controlCheckCollectionLineItemListData = controlCheckCollectiontLineItemList.ToList();
            worksheet.Row(RowNumber).FirstCell().Value = "Control Checks and Balance";
            worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
            RowNumber++;
            RowNumber++;
            for (int i = 0; i < dailyCollectionControlCheckLatestDate.Count; i++)
            {
                int iCount = 1;
                string LineItem = controlCheckCollectiontLineItemList[i];
                int subLineItem = dailyCollectionControlCheckDataList[i].isSubLineItems;
                int isParentDailyCollectionId = dailyCollectionControlCheckDataList[i].ParentDailyCollectionLineItemId;
                int isDailyCollectionId = dailyCollectionControlCheckDataList[i].DailyCollectionLineItemId;
                var controlCheckCollectionDataEntityObj = dailyCollectionControlCheckLatestDate.ElementAt(i);
                if (subLineItem == 0 && isParentDailyCollectionId > 0 && isDailyCollectionId > 0)
                {
                    string Spaces = new string(' ', 1 * 2);
                    worksheet.Row(RowNumber).Cell(iCount).Value = Spaces + "  " + LineItem;                 
                }

                if (subLineItem == 0 && isDailyCollectionId > 0 && isParentDailyCollectionId == 0)
                {
                    worksheet.Row(RowNumber).Cell(iCount).Value =  LineItem;
                }
                if (subLineItem == 1 && isParentDailyCollectionId > 0)
                {
                    worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;
                    worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                }

                for (int j = 0; j < distinctCollectionDates.CollectionDates.Count; j++)
                {
                    for (int k = 0; k < dailyCollectionControlCheckData.Count; k++)
                    {
                        

                        if (distinctCollectionDates.CollectionDates[j] == dailyCollectionControlCheckData[k].CollectionDate && dailyCollectionControlCheckData[k].LineItem == LineItem)
                        {
                            worksheet.Row(RowNumber).Cell(j + 2).Value = dailyCollectionControlCheckData[k].Value;
                        }
                    }

                }
                RowNumber++;
            }


            //Audit Data

            RowNumber++;
            RowNumber++;
            var dailyCollectionAuditDataList = dailyCollectionAuditData as List<DealSummaryDataEntity>;
            var auditCollectiontLineItemList = dailyCollectionAuditDataList.Select(s => s.LineItem).Distinct();
            List<string> auditCollectionLineItemListData = auditCollectiontLineItemList.ToList();


            worksheet.Row(RowNumber).FirstCell().Value = "Audit";
            worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
            RowNumber++;
            RowNumber++;
            for (int i = 0; i < auditCollectionLineItemListData.Count; i++)
            {
                int iCount = 1;
                string LineItem = auditCollectionLineItemListData[i];

                string auditModifiedDate = null;

                worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;

                for (int j = 0; j < distinctCollectionDates.CollectionDates.Count; j++)
                {
                    for (int k = 0; k < dailyCollectionAuditData.Count; k++)
                    {
                        if (distinctCollectionDates.CollectionDates[j] == dailyCollectionAuditData[k].CollectionDate && dailyCollectionAuditData[k].LineItem == LineItem)
                        {
                            if (dailyCollectionAuditData[k].ModifiedDate.HasValue)
                            {
                                 auditModifiedDate = dailyCollectionAuditData[k].ModifiedDate.Value.ToString("dd-MMM-yyyy : HH:mm:ss");
                            }
                            worksheet.Row(RowNumber).Cell(j + 2).Value = dailyCollectionAuditData[k].ModifiedBy + " (" + auditModifiedDate + ")";
                        }
                    }

                }
                RowNumber++;
            }
        }



        public int GetLoadDailyEstimationDealSummary(string adviceDate, string dealName, bool isEstimationData, string loggedInUser)
        {
            return _dealSummaryOutputDataService.GetLoadDailyEstimationDealSummary(adviceDate, dealName, isEstimationData, loggedInUser);
        }


        public List<bool> GetDealSummaryLoadDataEstimation(DataTable ListCollDate, string dealName,  string loggedInUser)
        {
            return _dealSummaryOutputDataService.GetDealSummaryLoadDataEstimation(ListCollDate, dealName, loggedInUser);
        }

        public int IsActualGMSDataAvaliable(string adviceDate, string dealName, bool isEstimationData, string loggedInUser)
        {
            return _dealSummaryOutputDataService.IsActualGMSDataAvaliable(adviceDate, dealName, isEstimationData, loggedInUser);
        }

        public int GetLoadDeflagAdjustmentDealSummary(string adviceDate, string dealName, int isDeFlagAdjustment, string loggedInUser)
        {
            return _dealSummaryOutputDataService.GetLoadDeflagAdjustmentDealSummary(adviceDate, dealName, isDeFlagAdjustment, loggedInUser);
        }




    }

}

