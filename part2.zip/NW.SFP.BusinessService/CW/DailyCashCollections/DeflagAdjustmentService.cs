﻿using NW.SFP.Common;
using NW.SFP.DataService.CW;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class DeflagAdjustmentService : IDeflagAdjustmentService
    {
        private readonly IDeflagAdjustmentDataService _deflagAdjustmentDataService;
        public DeflagAdjustmentService(IDeflagAdjustmentDataService deflagAdjustmentDataService)
        {
            this._deflagAdjustmentDataService = deflagAdjustmentDataService;
        }

        public DataTable GetRepurchasePoolAdjustmentData()
        {
            return _deflagAdjustmentDataService.GetRepurchasePoolAdjustmentData();
        }

        public DataTable GetAdjustmentPoolData(int poolAdjustmentId)
        {
            return _deflagAdjustmentDataService.GetAdjustmentPoolData(poolAdjustmentId);
        }


        public DataTable GetDeflagAdjustmentExcelData(int poolAdjustmentId , string userName)
        {
            return _deflagAdjustmentDataService.GetDeflagAdjustmentExcelData(poolAdjustmentId, userName);
        }

        public DataTable GetControlCheckData(int poolAdjustmentId , string userName)
        {
            return _deflagAdjustmentDataService.GetControlCheckData(poolAdjustmentId , userName);
        }

        public int ManageDeflagAdjustmentAuditAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            return _deflagAdjustmentDataService.ManageDeflagAdjustmentAuditAuthWorkflowByUser(authWorkflowEntity);
        }

        public int DeflagAdjustmentSentforAuthorization(DefalgAdjustmentEntity DefalgAdjustmentEntity)
        {
            return _deflagAdjustmentDataService.DeflagAdjustmentSentforAuthorization(DefalgAdjustmentEntity);
        }
    }
}
