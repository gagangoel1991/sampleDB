﻿using ClosedXML.Excel;
using NW.SFP.Common;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class DailyCashCollectionsService : IDailyCashCollectionsService
    {
        private readonly IDailyCashCollectionsDataService _dailyCashCollectionsDataService;
        string HeaderColour = "#248dad";
        string HeaderTextColour = "#ffffff";
        string SubHeaderColour = "#808080";
        string SubHeaderTextColour = "#ffffff";
        private readonly ILoggerService _loggerService;
        private IExcelService _excelService;

        public DailyCashCollectionsService(IDailyCashCollectionsDataService dailyCashCollectionsDataService, IExcelService excelService, ILoggerService loggerService)
        {
            this._dailyCashCollectionsDataService = dailyCashCollectionsDataService;
            this._excelService = excelService;
            this._loggerService = loggerService;
        }

        public DataTable GetDealCollectionHistoryData(DailyCollectionHistoryParam dailyCollectionHistParam, string userName)
        {
            return _dailyCashCollectionsDataService.GetDealCollectionHistoryData(dailyCollectionHistParam, userName);
        }
        public DataTable GetPNRSplitData(string asAtDate, string adviceDate, string dealName, string userName)
        {
            return _dailyCashCollectionsDataService.GetPNRSplitData(asAtDate, adviceDate, dealName, userName);
        }
        public DataTable GetDealDailyCollectionData(string asAtDate, string userName)
        {
            return _dailyCashCollectionsDataService.GetDealDailyCollectionData(asAtDate, userName);
        }
        public DataTable GetCBOutputData(DailyCollectionHistoryParam cbOutputParam, string userName)
        {
            return _dailyCashCollectionsDataService.GetCBOutputData(cbOutputParam, userName);
        }
        public IXLWorkbook GetDealDailyCollectionsExcel(string asAtDate,string loggedInUserName)
        {
            IXLWorkbook workbook = new XLWorkbook();
            
            IXLWorksheet worksheet = workbook.Worksheets.Add("Daily Collection Output");
            DataTable dt = _dailyCashCollectionsDataService.GetDealDailyCollectionData(asAtDate, loggedInUserName);
            int RowNumber = 1;

            if (dt != null)
            {
                // Create Excel header
                worksheet.Row(RowNumber).Cell(1).Value = "Advice Date";
                worksheet.Row(RowNumber).Cell(2).Value = "Collection Date";
                worksheet.Row(RowNumber).Cell(3).Value = "Context Name";
                worksheet.Row(RowNumber).Cell(4).Value = "Originator";
                worksheet.Row(RowNumber).Cell(5).Value = "Principal Receipts";
                worksheet.Row(RowNumber).Cell(6).Value = "Revenue Receipts";
                worksheet.Row(RowNumber).Cell(7).Value = "Other Collections";
                worksheet.Row(RowNumber).Cell(8).Value = "Total Daily Cash";
                worksheet.Row(RowNumber).Cell(9).Value = "Deal Name";
                worksheet.Row(RowNumber).Cell(10).Value = "Daily Cash Movement";
                worksheet.Row(RowNumber).Cell(11).Value = "Compare";
                worksheet.Row(RowNumber).Cell(12).Value = "Data Source";
                worksheet.Row(RowNumber).Cell(13).Value = "Difference";
                worksheet.Row(RowNumber).Cell(14).Value = "Loss Processed Previous Day";
                worksheet.Row(RowNumber).Cell(15).Value = "Flagging/Deflagging Adjustment";
                worksheet.Row(RowNumber).Cell(16).Value = "Residual Difference";

                // Header formatting
                worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
                worksheet.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
                worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
                RowNumber++;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    worksheet.Row(RowNumber).Cell(1).Value = dt.Rows[i]["AdviceDate"].ToString();
                    worksheet.Row(RowNumber).Cell(2).Value = dt.Rows[i]["CollectionDate"].ToString();
                    worksheet.Row(RowNumber).Cell(3).Value = dt.Rows[i]["ContextName"].ToString();
                    worksheet.Row(RowNumber).Cell(4).Value = dt.Rows[i]["Originator"].ToString();
                    worksheet.Row(RowNumber).Cell(5).Value = dt.Rows[i]["PrincipalReceipts"].ToString();
                    worksheet.Row(RowNumber).Cell(6).Value = dt.Rows[i]["RevenueReceipts"].ToString();
                    worksheet.Row(RowNumber).Cell(7).Value = dt.Rows[i]["OtherCollections"].ToString();
                    worksheet.Row(RowNumber).Cell(8).Value = dt.Rows[i]["TotalDailyCash"].ToString();
                    worksheet.Row(RowNumber).Cell(9).Value = dt.Rows[i]["DealName"].ToString();
                    worksheet.Row(RowNumber).Cell(10).Value = dt.Rows[i]["DailyCashMovement"].ToString();
                    worksheet.Row(RowNumber).Cell(11).Value = dt.Rows[i]["Compare"].ToString();
                    worksheet.Row(RowNumber).Cell(12).Value = dt.Rows[i]["DataSource"].ToString();
                    worksheet.Row(RowNumber).Cell(13).Value = dt.Rows[i]["Difference"].ToString();
                    worksheet.Row(RowNumber).Cell(14).Value = dt.Rows[i]["LossProcessedPreviousDay"].ToString();
                    worksheet.Row(RowNumber).Cell(15).Value = dt.Rows[i]["FlaggingDeflaggingAdjustment"].ToString();
                    worksheet.Row(RowNumber).Cell(16).Value = dt.Rows[i]["ResidualDifference"].ToString();

                    RowNumber++;
                }
            }

            
            return workbook;
        }
        public IXLWorkbook GetPNRSplitExcel(string asAtDate, string adviceDate, string dealName, string userName)
        {
            IXLWorkbook workbook = new XLWorkbook();
            IXLWorksheet worksheet = workbook.Worksheets.Add("P & R Split");
            GetPNRSplitExcelData(asAtDate, adviceDate, dealName, userName, worksheet);
            return workbook;
        }

        private void GetPNRSplitExcelData(string asAtDate, string adviceDate, string dealName, string userName, IXLWorksheet worksheet)
        {
            DataTable dt = _dailyCashCollectionsDataService.GetPNRSplitData(asAtDate, adviceDate, dealName, userName);
            int RowNumber = 1;

            if (dt != null)
            {
                // Create Excel header
                worksheet.Row(RowNumber).Cell(1).Value = "Advice Date";
                worksheet.Row(RowNumber).Cell(2).Value = "Collection Date";
                worksheet.Row(RowNumber).Cell(3).Value = "Securitisation Name";
                worksheet.Row(RowNumber).Cell(4).Value = "Alias";
                worksheet.Row(RowNumber).Cell(5).Value = "Originator";
                worksheet.Row(RowNumber).Cell(6).Value = "Gross Principal Collections";
                worksheet.Row(RowNumber).Cell(7).Value = "Net Principal Collections";
                worksheet.Row(RowNumber).Cell(8).Value = "Interest Collections";
                worksheet.Row(RowNumber).Cell(9).Value = "Fee Collections";
                worksheet.Row(RowNumber).Cell(10).Value = "Total Cash Collections";

                // Header formatting
                worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
                worksheet.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
                worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
                RowNumber++;

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    worksheet.Row(RowNumber).Cell(1).Value = dt.Rows[i]["AdviceDate"].ToString();
                    worksheet.Row(RowNumber).Cell(2).Value = dt.Rows[i]["CollectionDate"].ToString();
                    worksheet.Row(RowNumber).Cell(3).Value = dt.Rows[i]["SecuritisationName"].ToString();
                    worksheet.Row(RowNumber).Cell(4).Value = dt.Rows[i]["Alias"].ToString();
                    worksheet.Row(RowNumber).Cell(5).Value = dt.Rows[i]["Originator"].ToString();
                    if (dt.Rows[i]["SecuritisationName"].ToString() == "" || dt.Rows[i]["SecuritisationName"].ToString() == null)
                    {
                        worksheet.Row(RowNumber).Cell(6).Value = dt.Rows[i]["GrossPrincipalCollections"].ToString();
                        worksheet.Row(RowNumber).Cell(7).Value = dt.Rows[i]["NetPrincipalCollections"].ToString();
                        worksheet.Row(RowNumber).Cell(8).Value = dt.Rows[i]["InterestCollections"].ToString();
                        worksheet.Row(RowNumber).Cell(9).Value = dt.Rows[i]["FeesCollection"].ToString();
                        worksheet.Row(RowNumber).Cell(10).Value = dt.Rows[i]["TotalCashCollections"].ToString();
                        worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
                    }
                    else
                    {
                        worksheet.Row(RowNumber).Cell(6).Value = dt.Rows[i]["GrossPrincipalCollections"].ToString();
                        worksheet.Row(RowNumber).Cell(7).Value = dt.Rows[i]["NetPrincipalCollections"].ToString();
                        worksheet.Row(RowNumber).Cell(8).Value = dt.Rows[i]["InterestCollections"].ToString();
                        worksheet.Row(RowNumber).Cell(9).Value = dt.Rows[i]["FeesCollection"].ToString();
                        worksheet.Row(RowNumber).Cell(10).Value = dt.Rows[i]["TotalCashCollections"].ToString();
                    }

                    RowNumber++;
                }
            }
        }

        public IXLWorkbook GetCBOutputExcel(DailyCollectionHistoryParam cbOutputParam, string userName)
        {
            IXLWorkbook workbook = new XLWorkbook();
            IXLWorksheet worksheet = workbook.Worksheets.Add("CB IPD Collections");
            DataTable dt = _dailyCashCollectionsDataService.GetCBOutputData(cbOutputParam, userName);
            int RowNumber = 1;

            // Create Excel header
            worksheet.Row(RowNumber).Cell(1).Value = "Advice Date";
            worksheet.Row(RowNumber).Cell(2).Value = "Cash Collection Date";
            worksheet.Row(RowNumber).Cell(3).Value = "Gross Principal Collections Fees and Other Movements";
            worksheet.Row(RowNumber).Cell(4).Value = "Less Principal Element of Further Advances";
            worksheet.Row(RowNumber).Cell(5).Value = "Plus Repurchase Amounts";
            worksheet.Row(RowNumber).Cell(6).Value = "Net Principal Collections";
            worksheet.Row(RowNumber).Cell(7).Value = "Revenue Collections";
            worksheet.Row(RowNumber).Cell(8).Value = "Daily Cash Movement";

            // Header formatting
            worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            worksheet.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
            RowNumber++;

            for (int i = 0; i < dt.Rows.Count; i++)
            {
                worksheet.Row(RowNumber).Cell(1).Value = dt.Rows[i]["AdviceDate"].ToString();
                worksheet.Row(RowNumber).Cell(2).Value = dt.Rows[i]["CashCollectionDate"].ToString();
                worksheet.Row(RowNumber).Cell(3).Value = dt.Rows[i]["GrossPrincipalCollectionsFeesandOtherMovements"].ToString();
                worksheet.Row(RowNumber).Cell(4).Value = dt.Rows[i]["LessPrincipalElementofFurtherAdvances"].ToString();
                worksheet.Row(RowNumber).Cell(5).Value = dt.Rows[i]["PlusRepurchaseAmounts"].ToString();
                worksheet.Row(RowNumber).Cell(6).Value = dt.Rows[i]["NetPrincipalCollections"].ToString();
                worksheet.Row(RowNumber).Cell(7).Value = dt.Rows[i]["RevenueCollections"].ToString();
                worksheet.Row(RowNumber).Cell(8).Value = dt.Rows[i]["DailyCashMovement"].ToString();
                RowNumber++;
            }
            return workbook;
        }


        public bool GenerateCollectionHistoryFile(DailyCollectionHistoryParam dailyCollectionHistParam, string SourceFile, string TargetFile, string userName )
        {
            LogInfoEntity logInfo = new LogInfoEntity() { LogDetail = "Collection history writing started on  " + SourceFile, ActionPerformed = "DailyCashCollectionsService.GenerateCollectionHistoryFile", ModuleId = 1, UserName = userName };
            this._loggerService.LogInfo(logInfo);

            using (var workbook = new XLWorkbook(SourceFile))
            {

                logInfo = new LogInfoEntity() { LogDetail = "Collection history file started on  " + SourceFile, ActionPerformed = "DailyCashCollectionsService.GenerateCollectionHistoryFile", ModuleId = 1, UserName = userName };
                this._loggerService.LogInfo(logInfo);

                DataTable dtCollectionHistory = _dailyCashCollectionsDataService.GetDealCollectionHistoryData(dailyCollectionHistParam, userName);

                _excelService.WriteDataIntoExcel(dtCollectionHistory, workbook.Worksheet("Collection_History"), "A4");

                logInfo = new LogInfoEntity() { LogDetail = "Collection history final save process started " + TargetFile, ActionPerformed = "DailyCashCollectionsService.GenerateCollectionHistoryFile", ModuleId = 1, UserName = userName };
                this._loggerService.LogInfo(logInfo);

                workbook.SaveAs(TargetFile);
            }

            return true;
        }


        public string GetDownloadFileStream(string SourceFile)
        {
            using (var workbook = new XLWorkbook(SourceFile))
            {

                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
        }

        
        public DataTable GetEmailDataForCollectionOutput(string emailType, string asAtDate,string attachmentFileLocation, string userName)
        {

            
            IXLWorkbook workbook=  GetDealDailyCollectionsExcel(asAtDate, userName);       

            string getPNRCollectionDate = _dailyCashCollectionsDataService.GetCollectionDate(asAtDate, "DUNMORE1", userName).ToString("yyyy-MM-dd");
            IXLWorksheet worksheet = workbook.Worksheets.Add("P & R Split");
            GetPNRSplitExcelData(getPNRCollectionDate, asAtDate, "DUNMORE1", userName, worksheet);

            workbook.SaveAs(attachmentFileLocation);
            
            return _dailyCashCollectionsDataService.GetEmailDataForCollectionOutput(emailType, userName);
        }
    }
}
