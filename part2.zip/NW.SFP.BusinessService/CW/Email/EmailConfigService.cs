﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.Email;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class EmailConfigService : IEmailConfigService
    {
        private readonly IEmailConfigDataService _emailConfigDataService;

        public EmailConfigService(IEmailConfigDataService emailConfigDataService)
        {
            this._emailConfigDataService = emailConfigDataService;
        }

        public IList<EmailConfigEntity> GetEmailConfigList(string loggedInUser)
        {
            return _emailConfigDataService.GetEmailConfigList(loggedInUser);
        }

        public int SaveEmailConfig(EmailConfigEntity emailConfigEntity)
        {
            return _emailConfigDataService.SaveEmailConfig(emailConfigEntity);
        }


        public EmailConfigEntity GetEmailConfig(int emailConfigId, string userName)
        {
            return _emailConfigDataService.GetEmailConfig(emailConfigId, userName);
        }
        public int DeleteEmailConfig(int emailConfigId, string userName)
        {
            return _emailConfigDataService.DeleteEmailConfig(emailConfigId, userName);
        }

    }
}
