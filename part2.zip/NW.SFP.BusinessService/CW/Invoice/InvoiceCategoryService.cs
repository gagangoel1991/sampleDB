﻿using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class InvoiceCategoryService: IInvoiceCategoryService
    {
        private readonly IInvoiceCategoryDataService _invoiceCategoryDataService;

        public InvoiceCategoryService(IInvoiceCategoryDataService invoiceCategoryDataService)
        {
            this._invoiceCategoryDataService = invoiceCategoryDataService;
        }

        /// <summary>
        /// This will return the Invoice Categories based on category type
        /// </summary>
        /// <param name="invoiceCategoryType"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryType, string userName)
        {
            return _invoiceCategoryDataService.GetInvoiceCategory(invoiceCategoryType, userName);
        }
    }
}
