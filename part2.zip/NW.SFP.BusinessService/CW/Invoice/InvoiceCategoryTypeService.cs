﻿using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class InvoiceCategoryTypeService : IInvoiceCategoryTypeService
    {
        private readonly IInvoiceCategoryTypeDataService _invoiceCategoryTypeDataService;

        public InvoiceCategoryTypeService(IInvoiceCategoryTypeDataService invoiceCategoryTypeDataService)
        {
            this._invoiceCategoryTypeDataService = invoiceCategoryTypeDataService;
        }

        /// <summary>
        /// This will return the Invoice Category Type
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public IList<InvoiceCategoryTypeEntity> GetInvoiceCategoryType(string userName)
        {
            return _invoiceCategoryTypeDataService.GetInvoiceCategoryType(userName);
        }
    }
}
