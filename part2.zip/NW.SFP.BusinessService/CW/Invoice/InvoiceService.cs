﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class InvoiceService : IInvoiceService
    {
        private readonly IInvoiceDataService _invoiceDataService;
        //private readonly IFactory factory;

        public InvoiceService(IInvoiceDataService invoiceDataService)
        {
            this._invoiceDataService = invoiceDataService;
        }

        /// <summary>
        /// This will return the invoice data 
        /// </summary>
        /// <param name="invoiceParams"></param>
        /// <returns></returns>
        public IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams, string userName)
        {
            return _invoiceDataService.GetInvoiceList(invoiceParams, userName);
        }

        /// <summary>
        /// This will return the single invoice record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public InvoiceDataEntity GetInvoice(int invoiceId, string loggedInUser)
        {
            return _invoiceDataService.GetInvoice(invoiceId, loggedInUser);
        }

        /// <summary>
        /// This will save the invoice data 
        /// </summary>
        /// <param name="invoiceData"></param>
        /// <returns></returns>
        public int SaveInvoiceData(InvoiceDataEntity invoiceData, string userName)
        {
            return _invoiceDataService.SaveInvoiceData(invoiceData, userName);
        }

        /// <summary>
        /// This will return the invoice data 
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        public int DeleteInvoiceData(int invoiceId, string userName)
        {
            return _invoiceDataService.DeleteInvoiceData(invoiceId, userName);
        }

        public IList<InvoiceDataEntity> GetInvoiceIpdData(IPDFeedParam iPDFeedParam)
        {
            return _invoiceDataService.GetInvoiceIpdData(iPDFeedParam);
        }

        public decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate, string userName)
        {
            return _invoiceDataService.GetSpotRate(dealId, invoiceCurrencyId, spotRateDate, userName);
        }
    }
}
