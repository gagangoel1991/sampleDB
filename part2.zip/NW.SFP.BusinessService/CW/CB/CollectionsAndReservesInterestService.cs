﻿using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using ClosedXML.Excel;
using System.Linq;
using NW.SFP.Interface.CW.CB;

namespace NW.SFP.BusinessService.CW.CB
{
    public class CollectionsAndReservesInterestService : ICollectionsAndReservesInterestService
    {

        private readonly IReservesInterestDataService _reservesDataService;
        private readonly ICollectionsInterestDataService _collectionsDataService;

        public CollectionsAndReservesInterestService(ICollectionsInterestDataService collectionsDataService, IReservesInterestDataService reservesDataService)
        {
            this._collectionsDataService = collectionsDataService;
            this._reservesDataService = reservesDataService;
        }
        public List<CollectionsEntity> GetCollectionData(int DealIpdRunId, string UserName)
        {
            return _collectionsDataService.GetCollectionData(DealIpdRunId, UserName);
        }
        public List<ReservesEntity> GetReservesData(int DealIpdRunId, string UserName)
        {
            return _reservesDataService.GetReservesData(DealIpdRunId, UserName);
        }
        public decimal GetReserveFinalRequiredAmount(int DealIpdRunId, string UserName)
        {
            return _reservesDataService.GetReserveFinalRequiredAmount(DealIpdRunId, UserName);
        }

        public IXLWorkbook GetCollandIntExcelSheet(int DealIpdRunId, string UserName)
        {
            string HeaderGreen = "#5D7430";
            string HeaderColour = "#248dad";
            string SubHeaderColour = "#7d898d";
            string HighlightColour = "#dba44e";
            string HeaderTextColour = "#ffffff";
            string OddRowColour = "#e6e6e6";
            string EvenRowColour = "#f2f2f2";

            var ListCollectionsdata = GetCollectionData(DealIpdRunId, UserName);
            var ListReservesData = GetReservesData(DealIpdRunId, UserName);
            var FinalRequiredAmount = GetReserveFinalRequiredAmount(DealIpdRunId, UserName);

            IXLWorkbook workbook = new XLWorkbook();
            int GroupStartRowNo = 0;

            //UI Worksheet 
            var UiData = GetCollandIntFormattedData(ListCollectionsdata, ListReservesData, FinalRequiredAmount);
            IXLWorksheet worksheetUi = workbook.Worksheets.Add("Summary");

            int RowNumber = 1;

            worksheetUi.Row(RowNumber).FirstCell().Value = "IPD Date";
            var DateColNo = 1;
            foreach (DateTime IpdDate in UiData.IpdDates)
            {
                worksheetUi.Row(RowNumber).Cell(DateColNo + 1).Value = IpdDate;
                DateColNo++;
            }

            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            worksheetUi.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheetUi.Row(RowNumber).Cells().Style.Font.Bold = true;
            RowNumber++;

            worksheetUi.Row(RowNumber).Cell(1).Value = "Total Interest (A+B)";
            var TotIntCol = 1;
            foreach (decimal TotInt in UiData.TotalInterest)
            {
                worksheetUi.Row(RowNumber).Cell(TotIntCol + 1).Value = TotInt;
                TotIntCol++;
            }

            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
            RowNumber++;

            worksheetUi.Row(RowNumber).Cell(1).Value = "Collection";
            worksheetUi.Row(RowNumber).Cell(1).Style.Font.Bold = true;
            worksheetUi.Row(RowNumber).Cell(1).Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheetUi.Row(RowNumber).Cells(1, ((List<DateTime>)UiData.IpdDates).Count() + 1).Style.Fill.BackgroundColor = XLColor.FromHtml(SubHeaderColour);
            RowNumber++;

            GroupStartRowNo = RowNumber;
            var CollectionsColNumber = 2;
            foreach (var ResultCollection in UiData.ResultCollectionData)
            {
                worksheetUi.Row(RowNumber).Cell(CollectionsColNumber).Value = ResultCollection.PrincipalReceipts;
                worksheetUi.Row(RowNumber + 1).Cell(CollectionsColNumber).Value = ResultCollection.RevenueReceipts;
                worksheetUi.Row(RowNumber + 2).Cell(CollectionsColNumber).Value = ResultCollection.InterestOnCollections;
                CollectionsColNumber++;
            }

            worksheetUi.Row(RowNumber).Cell(1).Value = "Principal Receipts";
            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
            RowNumber++;

            worksheetUi.Row(RowNumber).Cell(1).Value = "Revenue Receipts";
            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
            RowNumber++;

            worksheetUi.Rows(GroupStartRowNo, RowNumber).Group();

            worksheetUi.Row(RowNumber).Cell(1).Value = "Interest on Collection (A)";
            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);

            RowNumber++;

            worksheetUi.Row(RowNumber).Cell(1).Value = "Reserve";
            worksheetUi.Row(RowNumber).Cell(1).Style.Font.Bold = true;
            worksheetUi.Row(RowNumber).Cell(1).Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheetUi.Row(RowNumber).Cells(1, ((List<DateTime>)UiData.IpdDates).Count() + 1).Style.Fill.BackgroundColor = XLColor.FromHtml(SubHeaderColour);
            RowNumber++;
            GroupStartRowNo = RowNumber;

            var ReserveColNumber = 2;
            foreach (var ResultReserve in UiData.ResultReserveData)
            {
                worksheetUi.Row(RowNumber).Cell(ReserveColNumber).Value = ResultReserve.RequiredAmount;
                worksheetUi.Row(RowNumber + 1).Cell(ReserveColNumber).Value = ResultReserve.InterestOnReserves;
                ReserveColNumber++;
            }

            worksheetUi.Row(RowNumber).Cell(1).Value = "Required Amount";
            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
            RowNumber++;

            worksheetUi.Rows(GroupStartRowNo, RowNumber).Group();

            worksheetUi.Row(RowNumber).Cell(1).Value = "Interest on Reserve (B)";
            worksheetUi.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
            RowNumber++;


            worksheetUi.Columns().AdjustToContents();


            //Worksheet Collections Tab
            IXLWorksheet worksheetCollections = workbook.Worksheets.Add("Collection");
            worksheetCollections.Cell(1, 1).InsertTable(ListCollectionsdata.Where(x => x.CollectionDate != null));
            worksheetCollections.Tables.FirstOrDefault().Theme = XLTableTheme.None;
            var CollectionsHeaderRow = worksheetCollections.Tables.FirstOrDefault().HeadersRow();
            CollectionsHeaderRow.Cell(1).Style.Fill.BackgroundColor = XLColor.FromHtml(HighlightColour);
            CollectionsHeaderRow.Cells(2, 7).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            CollectionsHeaderRow.Cells(8, 13).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderGreen);
            CollectionsHeaderRow.Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            CollectionsHeaderRow.Style.Font.Bold = true;
            var CollectionTableRows = worksheetCollections.Tables.FirstOrDefault().Rows().Skip(1); // Skip header row;
            if (ListCollectionsdata.Where(x => x.CollectionDate != null).Count() > 0)
            {
                foreach (var row in CollectionTableRows)
                {
                    if (Convert.ToDecimal(row.Cell("J").Value) != 0)
                    {
                        row.Style.Fill.BackgroundColor = XLColor.FromHtml(HighlightColour);
                    }
                }
            }
            worksheetCollections.Columns().AdjustToContents();

            //Worksheet Reserves Tab
            IXLWorksheet worksheetReserves = workbook.Worksheets.Add("Reserve");
            worksheetReserves.Cell(1, 1).InsertTable(ListReservesData.Where(x => x.CollectionDate != null));
            worksheetReserves.Tables.FirstOrDefault().Theme = XLTableTheme.None;
            var ReserveHeaderRow = worksheetReserves.Tables.FirstOrDefault().HeadersRow();
            ReserveHeaderRow.Cell(1).Style.Fill.BackgroundColor = XLColor.FromHtml(HighlightColour);
            ReserveHeaderRow.Cells(2, 4).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            ReserveHeaderRow.Cells(5, 6).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderGreen);
            ReserveHeaderRow.Cells(7, 10).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            ReserveHeaderRow.Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            ReserveHeaderRow.Style.Font.Bold = true;
            if (ListReservesData.Where(x => x.CollectionDate != null).Count() > 0)
            {
                var ReserveTableRows = worksheetReserves.Tables.FirstOrDefault().Rows().Skip(1); // Skip header row;
                foreach (var row in ReserveTableRows)
                {
                    if (Convert.ToDecimal(row.Cell("H").Value) != 0)
                    {
                        row.Style.Fill.BackgroundColor = XLColor.FromHtml(HighlightColour);
                    }
                }
            }
            worksheetReserves.Columns().AdjustToContents();

            return workbook;
        }



        public dynamic GetCollandIntFormattedData(List<CollectionsEntity> ListCollectionsdata, List<ReservesEntity> ListReservesData, decimal FinalRequiredAmount)
        {
            //All Distinct Ipd dates from both collections in descending order
            var IpdDates = ListCollectionsdata.GroupBy(x => x.IpdDate).Select(x => x.Key).Union((ListReservesData.GroupBy(x => x.IpdDate).Select(x => x.Key))).OrderByDescending(x => x).ToList();

            //Collection Grouped Data Per IPD
            var ResultCollectionData = ListCollectionsdata
                                       .GroupBy(x => x.IpdDate)
                                       .OrderByDescending(x => x.Key)
                                       .Select(x => new
                                       {
                                           IpdDate = x.Key,
                                           PrincipalReceipts = x.Where(z => z.CollectionDate >= z.CollectionCalendarStart && z.CollectionDate <= z.CollectionCalendarEnd).Sum(y => y.PrincipalReceiptAmount),
                                           RevenueReceipts = x.Where(z => z.CollectionDate >= z.CollectionCalendarStart && z.CollectionDate <= z.CollectionCalendarEnd).Sum(y => y.RevenueReceiptAmount),
                                           InterestOnCollections = x.Where(z => z.DepositDate >= z.CollectionCalendarStart && z.DepositDate <= z.CollectionCalendarEnd).Sum(y => y.InterestAmount)
                                       });

            //Reserve Grouped Data Per IPD 
            //For First/Current IPD - Replacing Reserve Required Amount 
            var ResultReserveData = ListReservesData
                                    .GroupBy(x => x.IpdDate)
                                    .OrderByDescending(x => x.Key)
                                    .Select((x, index) => new
                                    {
                                        IpdDate = x.Key,
                                        RequiredAmount = (index == 0 ? FinalRequiredAmount : (x.Where(z => z.CollectionDate >= z.CollectionCalendarStart && z.CollectionDate <= z.CollectionCalendarEnd).OrderByDescending(x => x.AdviceDate).FirstOrDefault()?.RequiredAmount)) ?? 0,
                                        InterestOnReserves = x.Where(z => z.DepositDate >= z.CollectionCalendarStart && z.DepositDate <= z.CollectionCalendarEnd).Sum(y => y.InterestAmount)
                                    });

            //Collection + Reserve Total Interest per IPD
            var TotalInterest = ResultCollectionData
                                .Join(ResultReserveData, colData => colData.IpdDate, resData => resData.IpdDate, (colData, resData) => new { colData, resData })
                                .GroupBy(x => x.colData.IpdDate)
                                .OrderByDescending(z => z.Key)
                                .Select(x => x.Sum(x => x.colData.InterestOnCollections) + x.Sum(x => x.resData.InterestOnReserves));



            //Final Result Set
            var Result = new
            {
                IpdDates,
                TotalInterest,
                ResultCollectionData,
                ResultReserveData
            };

            return Result;
        }


        public dynamic GetCollandIntData(int DealIpdRunId, string UserName)
        {
            var ListCollectionsdata = GetCollectionData(DealIpdRunId, UserName);
            var ListReservesData = GetReservesData(DealIpdRunId, UserName);
            var FinalRequiredAmount = GetReserveFinalRequiredAmount(DealIpdRunId, UserName);
            return GetCollandIntFormattedData(ListCollectionsdata, ListReservesData, FinalRequiredAmount);
        }


    }

}
