﻿using NW.SFP.Common;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.BusinessService.CW.CB
{
    public class LedgersFundService : ILedgersFundService
    {
        private readonly ILedgersFundDataService _ledgersFundDataService;

        public LedgersFundService(ILedgersFundDataService ledgersFundDataService)
        {
            _ledgersFundDataService = ledgersFundDataService;

        }

        public List<RevenueLedgerFund> GetRevenueLedger(IPDFeedParam ipdFeedParam)
        {
            var dt = _ledgersFundDataService.GetRevenueLedger(ipdFeedParam);
            if (dt != null)
            {
                var funds = Utils.ConvertDataTable<RevenueLedgerFund>(dt);
                return funds;
            }
            return null;
        }

        public List<PrincipalLedgerFund> GetPrincipalLedger(IPDFeedParam ipdFeedParam)
        {
            var dt = _ledgersFundDataService.GetPrincipalLedger(ipdFeedParam);
            if (dt != null)
            {
                var funds = Utils.ConvertDataTable<PrincipalLedgerFund>(dt);
                return funds;
            }
            return null;
        }


        public List<PaymentLedgerFund> GetPaymentLedger(IPDFeedParam ipdFeedParam)
        {
            var dt = _ledgersFundDataService.GetPaymentLedger(ipdFeedParam);
            if (dt != null)
            {
                var funds = Utils.ConvertDataTable<PaymentLedgerFund>(dt);
                return funds;
            }
            return null;
        }

        public List<MaturingLoansLedgerFund> GetMaturingLoansLedger(IPDFeedParam ipdFeedParam)
        {
            var dt = _ledgersFundDataService.GetMaturingLoansLedger(ipdFeedParam);
            if (dt != null)
            {
                var funds = Utils.ConvertDataTable<MaturingLoansLedgerFund>(dt);
                return funds;
            }
            return null;
        }

        public List<CapitalAccountLedgerEntity> GetCapitalAccountLedger(IPDFeedParam ipdFeedParam)
        {
            var dt = _ledgersFundDataService.GetCapitalAccountLedger(ipdFeedParam);
            if (dt != null)
            {
                var funds = Utils.ConvertDataTable<CapitalAccountLedgerEntity>(dt);
                return funds;
            }
            return null;
        }
    }
}
