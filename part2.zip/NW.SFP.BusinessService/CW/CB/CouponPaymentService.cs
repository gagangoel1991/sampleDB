﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW.CB
{
    public class CouponPaymentService : ICouponPaymentService
    {
        private readonly ICouponPaymentDataService _couponPaymentDataService;

        public CouponPaymentService(ICouponPaymentDataService couponPaymentDataService)
        {
            _couponPaymentDataService = couponPaymentDataService;

        }

        public List<CouponPaymentEntity> GetCouponPaymentFund(IPDFeedParam ipdFeedParam)
        {
            return _couponPaymentDataService.GetCouponPaymentFund(ipdFeedParam);
        }
    }
}
