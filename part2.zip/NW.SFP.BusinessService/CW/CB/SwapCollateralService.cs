﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW.CB
{
    public class SwapCollateralService : ISwapCollateralService
    {
        private readonly ISwapCollateralDataService _swapCollateralDataService;

        public SwapCollateralService(ISwapCollateralDataService swapCollateralDataService)
        {
            _swapCollateralDataService = swapCollateralDataService;

        }

        public List<SwapCollateralEntity> GetSwapCollateral(IPDFeedParam ipdFeedParam)
        {
            return _swapCollateralDataService.GetSwapCollateral(ipdFeedParam);
        }
    }
}
