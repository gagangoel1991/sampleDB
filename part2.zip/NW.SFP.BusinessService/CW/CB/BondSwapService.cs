﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW.CB
{
    public class BondSwapService : IBondSwapService
    {
        private readonly IBondSwapDataService _bondSwapDataService;

        public BondSwapService(IBondSwapDataService bondSwapDataService)
        {
            _bondSwapDataService = bondSwapDataService;

        }

        public List<BondSwapEntity> GetBondSwapData(IPDFeedParam ipdFeedParam)
        {
            return _bondSwapDataService.GetBondSwapData(ipdFeedParam);
        }
    }
}
