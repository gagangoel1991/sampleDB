﻿using System;
using System.Collections.Generic;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CB;

namespace NW.SFP.BusinessService.CW.CB
{
    public class SoniaCompoundingService : ISoniaCompoundingService
    {
        private readonly ISoniaCompoundingDataService _soniaCompoundingDataService;

        public SoniaCompoundingService(ISoniaCompoundingDataService soniaCompoundingDataService)
        {
            this._soniaCompoundingDataService = soniaCompoundingDataService; 
        }
        public List<SoniaCompoundingSummaryEntity> GetSoniaCompoundingSummary(int dealId, int ipdRunId, string UserName)
        {
           return _soniaCompoundingDataService.GetSoniaCompoundingSummary(dealId, ipdRunId, UserName);
        }
        public List<dynamic> GetSoniaCompoundingData(DateTime accrualStartDate, DateTime accrualEndDate, string UserName)
        {
            return _soniaCompoundingDataService.GetSoniaCompoundingData(accrualStartDate, accrualEndDate, UserName);
        }
    }

}
