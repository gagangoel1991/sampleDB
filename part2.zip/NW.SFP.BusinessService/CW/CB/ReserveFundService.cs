﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.BusinessService.CW.CB
{
    public class ReserveFundService : IReserveFundService
    {
        private readonly IReserveFundDataService _reserveFundDataService;

        public ReserveFundService(IReserveFundDataService reserveFundDataService)
        {
            _reserveFundDataService = reserveFundDataService;

        }

        public DataTable GetReserveFund(IPDFeedParam ipdFeedParam)
        {
            return _reserveFundDataService.GetReserveFund(ipdFeedParam);
        }

        public DataTable GetReserveFundIpdDateHeader(IPDFeedParam ipdFeedParam)
        {
            return _reserveFundDataService.GetReserveFundIpdDateHeader(ipdFeedParam);
        }
    }
}
