﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW.CB
{
    public class PreMaturityLiquidityService : IPreMaturityLiquidityService
    {
        private readonly IPreMaturityLiquidityDataService _preMaturityLiquidityDataService;

        public PreMaturityLiquidityService(IPreMaturityLiquidityDataService preMaturityLiquidityDataService)
        {
            _preMaturityLiquidityDataService = preMaturityLiquidityDataService;

        }

        public List<PreMaturityLiquidityEntity> GetPreMaturityLiquidityFund(IPDFeedParam ipdFeedParam)
        {
            return _preMaturityLiquidityDataService.GetPreMaturityLiquidityFund(ipdFeedParam);
        }
    }
}
