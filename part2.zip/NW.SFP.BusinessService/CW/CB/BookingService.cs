﻿using ClosedXML.Excel;
using NW.SFP.Common;
using NW.SFP.DataService.CW;
using NW.SFP.DataService.CW.CB;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.BusinessService.CW.CB
{
    public class BookingService : IBookingService
    {
        private readonly IBookingDataService _bookingDataService;

        private readonly IBookingIPDDataService _bookingIPDDataService;

        private readonly ILoggerService _loggerService;
        private IExcelService _excelService;

        public BookingService(IBookingDataService bookingDataService, IBookingIPDDataService bookingIPDDataService
                                , IExcelService excelService, ILoggerService loggerService)
        {
            _bookingDataService = bookingDataService;
            _bookingIPDDataService = bookingIPDDataService;
            this._excelService = excelService;
            this._loggerService = loggerService;
        }

        public List<BookingTradesEntity> GetBookingTabData(IPDFeedParam ipdFeedParam)
        {
            return _bookingDataService.GetBookingTabData(ipdFeedParam);
        }

        public List<BookingEntity> GetBookingsIPDData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingsIPDData(ipdFeedParam);
        }

        public IXLWorkbook GetBookingExcel(IPDFeedParam ipdFeedParam, bool isSwapSummaryData)
        {
            string dealName = "Deimos";
            string FirstCell = string.Empty;
            string SecondCell = string.Empty;
            FirstCell = "  ";
            SecondCell = "  ";
            IXLWorkbook workbook = new XLWorkbook();
            List<BookingTradesEntity> bookingTradesListData = new List<BookingTradesEntity>();
            List<BookingEntity> bookingIPDListData = new List<BookingEntity>();
            List<BookingSwapSummaryEntity> bookingSwapSummaryData= new List<BookingSwapSummaryEntity>();
            decimal totalSwapAmount =0.0M ;

            if (isSwapSummaryData)
            {
                DataTable booksummary = _bookingIPDDataService.GetBookingSwapSummaryData(ipdFeedParam);
                bookingSwapSummaryData = Utils.ConvertDataTable<BookingSwapSummaryEntity>(booksummary);
                totalSwapAmount = bookingSwapSummaryData.Where(s => s.TotalAmount.ToString() != "").Select(s => s.TotalAmount).Sum();
                bookingSwapSummaryData = bookingSwapSummaryData.Where( s => s.Reference !=null ).ToList();
            }
            else
            {
                bookingTradesListData = _bookingDataService.GetBookingTabData(ipdFeedParam);

                bookingIPDListData = _bookingIPDDataService.GetBookingsIPDData(ipdFeedParam);
            }

            IXLWorksheet worksheet = workbook.Worksheets.Add(dealName);
            ExcelDataGenerator(bookingTradesListData, bookingIPDListData, ref worksheet,isSwapSummaryData, bookingSwapSummaryData, totalSwapAmount);
            worksheet.Columns().AdjustToContents();
            return workbook;
        }

        public void ExcelDataGenerator(List<BookingTradesEntity> bookingTradesListData, List<BookingEntity> bookingIPDListData, ref IXLWorksheet worksheet,bool isSwapSummaryData, List<BookingSwapSummaryEntity> bookingSwapSummaryData,decimal totalSwapAmount)
        {
            int RowNumber = 1;

            //Maturing Trades
            if (isSwapSummaryData)
            {
                worksheet.Row(RowNumber).FirstCell().Value = "Swap Summary";
                worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                RowNumber++;
                RowNumber++;

                int iMCount = 1;
                worksheet.Row(RowNumber).Cell(iMCount).Value = "";
                worksheet.Row(RowNumber).Cell(iMCount + 1).Value = "Reference";
                worksheet.Row(RowNumber).Cell(iMCount + 1).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 2).Value = "Netted";
                worksheet.Row(RowNumber).Cell(iMCount + 2).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 3).Value = "Currency";
                worksheet.Row(RowNumber).Cell(iMCount + 3).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 4).Value = "Pay Amount";
                worksheet.Row(RowNumber).Cell(iMCount + 4).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 5).Value = "Credit Account";
                worksheet.Row(RowNumber).Cell(iMCount + 5).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 6).Value = "Currency";
                worksheet.Row(RowNumber).Cell(iMCount + 6).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 7).Value = "Receipt Amount";
                worksheet.Row(RowNumber).Cell(iMCount + 7).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iMCount + 8).Value = "Debit Account";
                worksheet.Row(RowNumber).Cell(iMCount + 8).Style.Font.Bold = true;

                RowNumber++;
     //           List<BookingTradesEntity> maturingTradesListData = bookingTradesListData.Where(s => s.GroupName == "Maturing_Trades").ToList();
                for (int i = 0; i < bookingSwapSummaryData.Count; i++)
                {
                    int iCount = 2;
       //             string LineItem = maturingTradesListData[i].LineItem;
                    worksheet.Row(RowNumber).Cell(iCount).Value = bookingSwapSummaryData[i].Reference;
                    worksheet.Row(RowNumber).Cell(iCount+1).Value = "Yes";
                    worksheet.Row(RowNumber).Cell(iCount + 2).Value = bookingSwapSummaryData[i].PayCurrency;
                    worksheet.Row(RowNumber).Cell(iCount + 3).Value = bookingSwapSummaryData[i].PayAmount;
                    worksheet.Row(RowNumber).Cell(iCount + 4).Value = bookingSwapSummaryData[i].CreditAccount;
                    worksheet.Row(RowNumber).Cell(iCount + 5).Value = bookingSwapSummaryData[i].ReceiveCurrency;
                    worksheet.Row(RowNumber).Cell(iCount + 6).Value = bookingSwapSummaryData[i].ReceiveAmount;
                    worksheet.Row(RowNumber).Cell(iCount + 7).Value = bookingSwapSummaryData[i].DebitAccount;

                    RowNumber++;
                }

                RowNumber++;

                
                worksheet.Row(RowNumber).Cell(6).Value = "Net NWB Receipt";
                worksheet.Row(RowNumber).Cell(6).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(8).Value = totalSwapAmount;
                worksheet.Row(RowNumber).Cell(8).Style.Font.Bold = true;

            }
            else
            {
                worksheet.Row(RowNumber).FirstCell().Value = "Maturing Trades";
                worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                RowNumber++;
                RowNumber++;

                int iMCount = 1;
                worksheet.Row(RowNumber).Cell(iMCount).Value = "";
                worksheet.Row(RowNumber).Cell(iMCount + 1).Value = "Principal";
                worksheet.Row(RowNumber).Cell(iMCount + 2).Value = "Interest";
                worksheet.Row(RowNumber).Cell(iMCount + 3).Value = "Total";

                RowNumber++;
                List<BookingTradesEntity> maturingTradesListData = bookingTradesListData.Where(s => s.GroupName == "Maturing_Trades").ToList();
                for (int i = 0; i < maturingTradesListData.Count; i++)
                {
                    int iCount = 1;
                    string LineItem = maturingTradesListData[i].LineItem;
                    worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;

                    int valueCount = 2;
                    worksheet.Row(RowNumber).Cell(valueCount).Value = Decimal.Round(Convert.ToDecimal(maturingTradesListData[i].Principal), 2);
                    worksheet.Row(RowNumber).Cell(valueCount + 1).Value = Decimal.Round(Convert.ToDecimal(maturingTradesListData[i].Interest), 2);

                    decimal maturingTradesPrincipal = 0.0M;
                    decimal maturingTradesInterest = 0.0M;
                    decimal maturingTradesTotal = 0.0M;

                    if (!string.IsNullOrEmpty(maturingTradesListData[i].Principal))
                    {
                        maturingTradesPrincipal = Convert.ToDecimal(maturingTradesListData[i].Principal);
                    }
                    if (!string.IsNullOrEmpty(maturingTradesListData[i].Interest))
                    {
                        maturingTradesInterest = Convert.ToDecimal(maturingTradesListData[i].Interest);
                    }
                    maturingTradesTotal = maturingTradesPrincipal + maturingTradesInterest;
                    worksheet.Row(RowNumber).Cell(valueCount + 2).Value = Decimal.Round(maturingTradesTotal, 2);

                    RowNumber++;
                }

                //New GIC Loan Information

                RowNumber++;
                RowNumber++;
                worksheet.Row(RowNumber).FirstCell().Value = "New GIC Loan Information";
                worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                RowNumber++;

                int iNCount = 1;
                worksheet.Row(RowNumber).Cell(iNCount).Value = "";
                worksheet.Row(RowNumber).Cell(iNCount + 1).Value = "Principal";
                worksheet.Row(RowNumber).Cell(iNCount + 1).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iNCount + 2).Value = "Interest";
                worksheet.Row(RowNumber).Cell(iNCount + 2).Style.Font.Bold = true;
                worksheet.Row(RowNumber).Cell(iNCount + 3).Value = "Total";
                worksheet.Row(RowNumber).Cell(iNCount + 3).Style.Font.Bold = true;

                RowNumber++;
                List<BookingTradesEntity> maturingNewGICLoanListData = bookingTradesListData.Where(s => s.GroupName == "New_GIC_Loan_Information").ToList();
                for (int i = 0; i < maturingNewGICLoanListData.Count; i++)
                {
                    int iCount = 1;
                    string LineItem = maturingNewGICLoanListData[i].LineItem;
                    worksheet.Row(RowNumber).Cell(iCount).Value = LineItem;

                    int valueCount = 2;
                    decimal newGICPrincipal = 0;
                    decimal newGICInterest = 0;
                    decimal newGICTotal = 0;

                    worksheet.Row(RowNumber).Cell(valueCount).Value = maturingNewGICLoanListData[i].Principal;
                    worksheet.Row(RowNumber).Cell(valueCount + 1).Value = maturingNewGICLoanListData[i].Interest;
                    
                    if ((maturingNewGICLoanListData[i].Principal != "False" && maturingNewGICLoanListData[i].Principal != "FALSE"
                        && maturingNewGICLoanListData[i].Principal != "TRUE" && maturingNewGICLoanListData[i].Principal != "True") && !(maturingNewGICLoanListData[i].Principal.Contains("/")))
                    {
                        newGICPrincipal = Convert.ToDecimal(maturingNewGICLoanListData[i].Principal);
                    }
                    if ((maturingNewGICLoanListData[i].Interest != null && maturingNewGICLoanListData[i].Interest.Length > 0) && !(maturingNewGICLoanListData[i].Interest.Contains("/")))
                    {
                        newGICInterest = Convert.ToDecimal(maturingNewGICLoanListData[i].Interest);
                    }

                    if (newGICPrincipal > 0 && newGICInterest > 0)
                    {
                        newGICTotal = newGICPrincipal + newGICInterest;
                        worksheet.Row(RowNumber).Cell(valueCount + 2).Value = Decimal.Round(newGICTotal, 2);
                    }

                    RowNumber++;
                }

                //NW Collections Account (4607236 - LDNAWELO-GBP)

                RowNumber++;
                RowNumber++;

                var bookingGroupNameData = bookingIPDListData.OrderBy(s => s.GroupSortOrder).Where(s => s.LineItemOperatorInTotal != null)
                            .Select(s => new { s.GroupName, s.LineItemOperatorInTotal }).Distinct();


                List<BookingIPDEntity> bookingGroupNameListData = bookingGroupNameData
                                .Select(s => new BookingIPDEntity { GroupName = s.GroupName, LineItemOperatorInTotal = s.LineItemOperatorInTotal }).ToList();
                List<string> LineItemOperationalData = bookingIPDListData.Where(s => s.GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)")
                                                        .Select(s => s.LineItemOperatorInTotal).Distinct().ToList();
                for (int i = 0; i < bookingGroupNameListData.Count; i++)
                {

                    string groupName = bookingGroupNameListData[i].GroupName;
                    if ((bookingGroupNameListData[i].LineItemOperatorInTotal != "IPD" && bookingGroupNameListData[i].LineItemOperatorInTotal != "IPD+1"))
                    {
                        worksheet.Row(RowNumber).FirstCell().Value = groupName.Replace("_", " ");
                        worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                    }

                    RowNumber++;
                    RowNumber++;
                    if (groupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD-1")
                    {
                        worksheet.Row(RowNumber).FirstCell().Value = "IPD-1";
                        worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                    }

                    if (groupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD")
                    {
                        worksheet.Row(RowNumber).FirstCell().Value = "IPD";
                        worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                    }

                    if (groupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD+1")
                    {
                        worksheet.Row(RowNumber).FirstCell().Value = "IPD+1";
                        worksheet.Row(RowNumber).FirstCell().Style.Font.Bold = true;
                    }

                    RowNumber++;
                    int iCount = 1;

                    worksheet.Row(RowNumber).Cell(iCount).Value = "Type";
                    worksheet.Row(RowNumber).Cell(iCount).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 1).Value = "Flip";
                    worksheet.Row(RowNumber).Cell(iCount + 1).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 2).Value = "Description";
                    worksheet.Row(RowNumber).Cell(iCount + 2).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 3).Value = "Currency";
                    worksheet.Row(RowNumber).Cell(iCount + 3).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 4).Value = "Cr/Dr";
                    worksheet.Row(RowNumber).Cell(iCount + 4).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 5).Value = "Amount";
                    worksheet.Row(RowNumber).Cell(iCount + 5).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 6).Value = "Book";
                    worksheet.Row(RowNumber).Cell(iCount + 6).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 7).Value = "CounterParty";
                    worksheet.Row(RowNumber).Cell(iCount + 7).Style.Font.Bold = true;
                    worksheet.Row(RowNumber).Cell(iCount + 8).Value = "Fee Type";
                    worksheet.Row(RowNumber).Cell(iCount + 8).Style.Font.Bold = true;

                    RowNumber++;

                    List<BookingEntity> bookingIPDListDataValues = bookingIPDListData.Where(s => s.GroupName == groupName).ToList();

                    //Other group Data values

                    for (int j = 0; j < bookingIPDListDataValues.Count; j++)
                    {
                        if ((bookingIPDListDataValues[j].GroupName == "NW_Collections_Account_(4607236 - LDNAWELO-GBP)" && bookingIPDListDataValues[j].Name != "Net Cashflow")
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Transaction_Account_(600001 - 48803413 / NWBCOVBONDS-GBP)" && bookingIPDListDataValues[j].Name != "Net Cashflow")
                            || (bookingIPDListDataValues[j].GroupName == "NW_Collections_Account-(4607236 - LDNAWELO-GBP)" && (bookingIPDListDataValues[j].Name != "Net Cashflow" && bookingIPDListDataValues[j].Name != "RBS Funding Increase/Decrease"))
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD-1" && (bookingIPDListDataValues[j].Name != "Net IPD-1 Cashflow" && bookingIPDListDataValues[j].Name != "Net Account Balance"))
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD" && (bookingIPDListDataValues[j].Name != "Net IPD Cashflow" && bookingIPDListDataValues[j].Name != "Net Account Balance"))
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD+1" && (bookingIPDListDataValues[j].Name != "Net IPD+1 Cashflow" && bookingIPDListDataValues[j].Name != "Net IPD Period Cashflow" && bookingIPDListDataValues[j].Name != "Net Account Balance")))
                        {
                            worksheet.Row(RowNumber).Cell(1).Value = bookingIPDListDataValues[j].AccountType;
                            worksheet.Row(RowNumber).Cell(2).Value = bookingIPDListDataValues[j].Flip;
                            worksheet.Row(RowNumber).Cell(3).Value = bookingIPDListDataValues[j].Name;
                            worksheet.Row(RowNumber).Cell(4).Value = bookingIPDListDataValues[j].Currency;
                            worksheet.Row(RowNumber).Cell(5).Value = bookingIPDListDataValues[j].TransactionType;
                            worksheet.Row(RowNumber).Cell(6).Value = Decimal.Round(Convert.ToDecimal(bookingIPDListDataValues[j].Value), 2);
                            worksheet.Row(RowNumber).Cell(7).Value = bookingIPDListDataValues[j].BookCode;
                            worksheet.Row(RowNumber).Cell(8).Value = bookingIPDListDataValues[j].CounterPartyCode;
                            worksheet.Row(RowNumber).Cell(9).Value = bookingIPDListDataValues[j].FeeType;

                            RowNumber++;
                        }
                        if ((bookingIPDListDataValues[j].GroupName == "NW_Collections_Account_(4607236 - LDNAWELO-GBP)" && bookingIPDListDataValues[j].Name == "Net Cashflow")
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Transaction_Account_(600001 - 48803413 / NWBCOVBONDS-GBP)" && bookingIPDListDataValues[j].Name == "Net Cashflow")
                            || (bookingIPDListDataValues[j].GroupName == "NW_Collections_Account-(4607236 - LDNAWELO-GBP)" && (bookingIPDListDataValues[j].Name == "Net Cashflow" || bookingIPDListDataValues[j].Name == "RBS Funding Increase/Decrease"))
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD-1" && (bookingIPDListDataValues[j].Name == "Net IPD-1 Cashflow" || bookingIPDListDataValues[j].Name == "Net Account Balance"))
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD" && (bookingIPDListDataValues[j].Name == "Net IPD Cashflow" || bookingIPDListDataValues[j].Name == "Net Account Balance"))
                            || (bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD+1" && (bookingIPDListDataValues[j].Name == "Net IPD+1 Cashflow" || bookingIPDListDataValues[j].Name == "Net IPD Period Cashflow" || bookingIPDListDataValues[j].Name == "Net Account Balance")))
                        {
                            worksheet.Row(RowNumber).Cell(3).Value = bookingIPDListDataValues[j].Name;
                            worksheet.Row(RowNumber).Cell(3).Style.Font.Bold = true;
                            worksheet.Row(RowNumber).Cell(6).Value = bookingIPDListDataValues[j].Value;
                            worksheet.Row(RowNumber).Cell(6).Style.Font.Bold = true;
                            if((bookingIPDListDataValues[j].GroupName == "NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)" 
                                && bookingIPDListDataValues[j].LineItemOperatorInTotal == bookingGroupNameListData[i].LineItemOperatorInTotal 
                                && bookingGroupNameListData[i].LineItemOperatorInTotal == "IPD" 
                                && (bookingIPDListDataValues[j].Name == "Net Account Balance")))
                            {
                                worksheet.Row(RowNumber).Cell(7).Value = "(does not include IPD collections)";
                            }
                            RowNumber++;
                        }

                    }

                    RowNumber++;
                    RowNumber++;

                }

            }



        }

        public DataTable GetBookingNwbFoFeesData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingNwbFoFeesData(ipdFeedParam);
        }

        public DataTable GetBookingNwbFoLdData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingNwbFoLdData(ipdFeedParam);
        }

        public DataTable GetBookingLLPMoFeesData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingLLPMoFeesData(ipdFeedParam);
        }

        public DataTable GetBookingLoansAndDepositsData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingLoansAndDepositsData(ipdFeedParam);
        }

        public DataTable GetBookingSwapSummaryData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingSwapSummaryData(ipdFeedParam);
        }

        public DataTable GetBookingReconData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.GetBookingReconData(ipdFeedParam);
        }

        public bool GetBookingReconExcelData(IPDFeedParam ipdFeedParam, string SourceFile, string TargetFile)
        {

            LogInfoEntity logInfo = new LogInfoEntity() { LogDetail = "Collection history writing started on  " + SourceFile, ActionPerformed = "BookingService.GetBookingReconData", ModuleId = 1, UserName = ipdFeedParam.UserName };
            this._loggerService.LogInfo(logInfo);
            using (var workbook = new XLWorkbook(SourceFile))
            {

                logInfo = new LogInfoEntity() { LogDetail = "Booking Recon file started on  " + SourceFile, ActionPerformed = "BookingService.GetBookingReconData", ModuleId = 1, UserName = ipdFeedParam.UserName };
                this._loggerService.LogInfo(logInfo);

                DataTable dtBookingRecon = _bookingIPDDataService.GetBookingReconData(ipdFeedParam);

                DataTable dtBookingReconAnalysis = _bookingIPDDataService.GetBookingReconAnalysisTabData(ipdFeedParam);

                _excelService.WriteDataIntoExcel(dtBookingReconAnalysis, workbook.Worksheet("Analysis"), 2,1);

                _excelService.WriteDataIntoExcel(dtBookingRecon, workbook.Worksheet("Reference_Values"), "A4");

                logInfo = new LogInfoEntity() { LogDetail = "Booking Recon final save process started " + TargetFile, ActionPerformed = "BookingService.GetBookingReconData", ModuleId = 1, UserName = ipdFeedParam.UserName };
                this._loggerService.LogInfo(logInfo);

                workbook.SaveAs(TargetFile);

               // _excelService.DownLoadExcel(TargetFile, "Booking_Recon");

            //    return workbook;
            }

            return true;
            
        }

        public string GetDownloadFileStream(string SourceFile)
        {
            using (var workbook = new XLWorkbook(SourceFile))
            {

                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
        }


        public bool ProcessBookingData(IPDFeedParam ipdFeedParam)
        {
            return _bookingIPDDataService.ProcessBookingData(ipdFeedParam);
        }

    }
}
