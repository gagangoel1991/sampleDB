﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using NW.SFP.Message.CB;
using System.Collections.Generic;
using NW.SFP.Common;
using System.Linq;
using System;
using ClosedXML.Excel;
using System.Data;

namespace NW.SFP.BusinessService.CW.CB
{
    public class TestService : ITestService
    {
        private readonly ITestDataService _testDataService;
        string HeaderColour = "#248dad";
        string HeaderTextColour = "#ffffff";
        string OddRowColour = "#e6e6e6";
        string EvenRowColour = "#f2f2f2";

        public TestService(ITestDataService testDataService)
        {
            _testDataService = testDataService;

        }

        public Tuple<List<TestDataEntity>, List<DateTime>, dynamic> GetTestDataSummary(IPDFeedParam ipdFeedParam)
        {
            var dt = _testDataService.GetTestDataSummary(ipdFeedParam);
            if (dt != null)
            {
                var TestSummarydata = Utils.ConvertDataTable<TestDataEntity>(dt);

                var Hierarchy = GetChildLineItems(TestSummarydata, null);
                var IpdDates = TestSummarydata.Select(x => x.IpdDate).Distinct().ToList();
                var Tabs = TestSummarydata.Where(x => x.ParentTestLineItemId == null && x.UITabName != null)
                    .Select(x => new { x.UITabName, x.DisplayName, x.InternalTestLineItem }).Distinct().ToList();

                return new Tuple<List<TestDataEntity>, List<DateTime>, dynamic>(Hierarchy, IpdDates, Tabs);
            }

            return null;
        }

        public List<TestDataEntity> GetTestData(IPDFeedParam ipdFeedParam, string testTypeName)
        {
            var dt = _testDataService.GetTestData(ipdFeedParam, testTypeName);
            if (dt != null)
            {
                var testdata = Utils.ConvertDataTable<TestDataEntity>(dt);

                List<TestDataEntity> hierarchy = new List<TestDataEntity>();

                hierarchy = GetChildLineItems(testdata, null);

                return hierarchy;
            }

            return null;
        }

        public List<TestDataEntity> GetChildLineItems(List<TestDataEntity> lineItems, int? parentId)
        {
            return lineItems
                    .Where(c => c.ParentTestLineItemId == parentId)
                    .GroupBy(c => c.TestLineItemId)
                    .Select(c => new TestDataEntity
                    {
                        //TestLineItemId = c.TestLineItemId,
                        DisplayName = c.Select(x => x.DisplayName).FirstOrDefault(),
                        UITabName = c.Select(x => x.UITabName).FirstOrDefault(),
                        InternalTestLineItem = c.Select(x => x.InternalTestLineItem).FirstOrDefault(),
                        LineItemValues = c.OrderByDescending(x => x.IpdDate).Select(x => x.LineItemValue).ToArray(),
                        ParentTestLineItemId = c.Select(x => x.ParentTestLineItemId).FirstOrDefault(),
                        ChildLineItems = GetChildLineItems(lineItems, c.Key)
                    })
                    .ToList();
        }

        public IXLWorkbook GetTestExcel(IPDFeedParam IpdFeedParam, string TestTypeName)
        {
            var dtTestExcel = new DataTable();
            string headerParam = string.Empty;
            string excelSheetName = string.Empty;
            IXLWorkbook workbook = new XLWorkbook();
            
            if (TestTypeName == "TestSummary")
            {
                dtTestExcel = _testDataService.GetTestDataSummary(IpdFeedParam);
                headerParam = "Test Summary Line Item";
            }
            else
            {
                dtTestExcel = _testDataService.GetTestData(IpdFeedParam, TestTypeName);
                headerParam = "Test Line Items";
            }

            if (dtTestExcel != null)
            {
                var TestSummarydata = Utils.ConvertDataTable<TestDataEntity>(dtTestExcel);
                var Hierarchy = GetChildLineItems(TestSummarydata, null);
                IXLWorksheet worksheet = workbook.Worksheets.Add(TestTypeName);
                var IpdDates = TestSummarydata.OrderByDescending(x => x.IpdDate).Select(x => x.IpdDate).Distinct().ToList();
                int RowNumber = 1;
                int DepthLevel = 0;
                HeaderExcelGenerator(headerParam, IpdDates, ref worksheet, ref RowNumber);
                RecursiveExcelGenerator(Hierarchy, ref worksheet, ref RowNumber, DepthLevel);
                worksheet.Columns().AdjustToContents();
            }

            return workbook;
        }

        public void HeaderExcelGenerator(string FirstCellName, List<DateTime> IpdDates, ref IXLWorksheet worksheet, ref int RowNumber)
        {
            worksheet.Row(RowNumber).FirstCell().Value = FirstCellName;
            for (int i = 0; i < IpdDates.Count(); i++)
            {
                worksheet.Row(RowNumber).Cell(i + 2).Value = IpdDates.ElementAt(i);
            }
            worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
            worksheet.Row(RowNumber).Cells().Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
            worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
            RowNumber++;
        }

        public void RecursiveExcelGenerator(List<TestDataEntity> Hierarchy, ref IXLWorksheet worksheet, ref int RowNumber, int DepthLevel)
        {
            for (int i = 0; i < Hierarchy.Count(); i++)
            {
                var TestDataEntityObj = Hierarchy.ElementAt(i);
                string Spaces = new string(' ', DepthLevel * 2);
                worksheet.Row(RowNumber).FirstCell().Value = Spaces + TestDataEntityObj.DisplayName;

                // For parent columns value filling
                for (int j = 0; j < TestDataEntityObj.LineItemValues.Count(); j++)
                {
                    worksheet.Row(RowNumber).Cell(j + 2).Value = TestDataEntityObj.LineItemValues.ElementAt(j);
                }

                if (TestDataEntityObj.ChildLineItems != null && TestDataEntityObj.ChildLineItems.Count() > 0)
                {
                    worksheet.Row(RowNumber).Cells().Style.Font.Bold = true;
                    RowNumber++;
                    RecursiveExcelGenerator(TestDataEntityObj.ChildLineItems, ref worksheet, ref RowNumber, DepthLevel + 1);
                }
                else
                {
                    // For Child columns value filling
                    for (int j = 0; j < TestDataEntityObj.LineItemValues.Count(); j++)
                    {
                        worksheet.Row(RowNumber).Cell(j + 2).Value = TestDataEntityObj.LineItemValues.ElementAt(j);
                    }
                    worksheet.Row(RowNumber).Cells().Style.Fill.BackgroundColor = XLColor.FromHtml(RowNumber % 2 == 0 ? EvenRowColour : OddRowColour);
                    RowNumber++;
                }
            }
        }

    }
}
