﻿using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW.CB
{
    public class DealSwapService : IDealSwapService
    {
        private readonly IDealSwapDataService _dealSwapDataService;

        public DealSwapService(IDealSwapDataService dealSwapDataService)
        {
            _dealSwapDataService = dealSwapDataService;

        }

        public List<DealSwapEntity> GetDealSwapData(IPDFeedParam ipdFeedParam)
        {
            return _dealSwapDataService.GetDealSwapData(ipdFeedParam);
        }
    }
}
