﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class TriggerService : ITriggerService
    {
        private readonly IRatingTriggerDataService _ratingTriggerDataService;
        private readonly INonRatingTriggerDataService _nonRatingTriggerDataService;

        public TriggerService(IRatingTriggerDataService ratingTriggerDataService, INonRatingTriggerDataService nonRatingTriggerDataService)
        {
            _ratingTriggerDataService = ratingTriggerDataService;
            _nonRatingTriggerDataService = nonRatingTriggerDataService;
        }

        public List<NonRatingTriggerEntity> GetNonRatingTriggers(IPDFeedParam iPDFeedParam)
        {
            return _nonRatingTriggerDataService.GetNonRatingTriggers(iPDFeedParam);
        }

        public List<RatingTriggerEntity> GetRatingTriggers(IPDFeedParam ipdFeedParam)
        {
            return _ratingTriggerDataService.GetRatingTriggers(ipdFeedParam);
        }

        public int SaveNonRatingTrigger(NonRatingTriggerEntity nonRatingTriggerEntity)
        {
            return _nonRatingTriggerDataService.SaveNonRatingTrigger(nonRatingTriggerEntity);
        }


        public int ResetNontRatingTrigger(int dealId, int ipdRunId, string loggedInUser)
        {
            return _nonRatingTriggerDataService.ResetNontRatingTrigger(dealId, ipdRunId, loggedInUser);
        }


        public int ResetTriggersConditions(int ipdRunId, string loggedInUser)
        {
            return _nonRatingTriggerDataService.ResetTriggersConditions(ipdRunId, loggedInUser);
        }

        public List<RatingTriggerEntity> GetSwapRatingTriggers(IPDFeedParam ipdFeedParam)
        {
            return _ratingTriggerDataService.GetSwapRatingTriggers(ipdFeedParam);
        }
    }
}
