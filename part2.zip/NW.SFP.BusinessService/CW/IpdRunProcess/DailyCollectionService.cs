﻿using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Linq;
using System.Reflection;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class DailyCollectionService : IDailyCollectionService
    {
        private readonly IDailyCollectionDataService _dailyCollectionDataService;

        public DailyCollectionService(IDailyCollectionDataService dailyCollectionDataService)
        {
            this._dailyCollectionDataService = dailyCollectionDataService;
        }

        public DailyCollection GetDailyCollectionData(IPDFeedParam ipdFeedParam)
        {
            DailyCollection dailyCollection = new DailyCollection();
            var columnnameList = _dailyCollectionDataService.GetColumns(ipdFeedParam);
            foreach (var columnName in columnnameList)
            {
                dailyCollection.Columns.Add(new DailyCollectionGridConfiguration { Key = MakeColumnKey(columnName), DisplayKey = columnName, IsEditable = true });
            }

            dailyCollection.DailyCollectionList = _dailyCollectionDataService.GetDailyCollectionData(ipdFeedParam);
            dailyCollection.SourceDailyCollectionList = _dailyCollectionDataService.GetSourceCollectionData(ipdFeedParam);
            return dailyCollection;
        }

        public int SaveDailyCollectionData(DailyCollectionEntity dailyCollectionEntity, string user)
        {
            return _dailyCollectionDataService.SaveDailyCollectionData(dailyCollectionEntity, user);
        }

        private string MakeColumnKey(string s)
        {
            if (string.IsNullOrEmpty(s))
            {
                return string.Empty;
            }
            char[] a = s.ToCharArray();
            a[0] = char.ToLower(a[0]);
            return new string(a);
        }
    }
}
