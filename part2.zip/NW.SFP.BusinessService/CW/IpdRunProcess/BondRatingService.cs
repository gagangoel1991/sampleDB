﻿using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class BondRatingService : IBondRatingService
    {
        private readonly IBondRatingDataService _bondRatingDataService;
        private readonly ICreditRatingDataService _creditRatingDataService;

        public BondRatingService(IBondRatingDataService bondRatingDataService, ICreditRatingDataService creditRatingDataService)
        {
            this._bondRatingDataService = bondRatingDataService;
            this._creditRatingDataService = creditRatingDataService;
        }

        public BondRating GetBondRatingData(IPDFeedParam ipdFeedParam)
        {
            return _bondRatingDataService.GetBondRatingData(ipdFeedParam);
        }

        public IList<CreditRatingEntity> GetCreditRatings(string loggedInUserName)
        {
            return _creditRatingDataService.GetCreditRatings(loggedInUserName);
        }

        public int SaveBondRatingData(dynamic bondRatingEntity, string loggedInUser)
        {
            return _bondRatingDataService.SaveBondRatingData(bondRatingEntity, loggedInUser);
        }

        public int ResetBondRatingData(int ipdRunId, string loggedInUser)
        {
            return _bondRatingDataService.ResetBondRatingData(ipdRunId, loggedInUser);
        }

        public bool IsBondRatingEdited(int ipdRunId, string loggedInUser)
        {
            return _bondRatingDataService.IsBondRatingEdited(ipdRunId, loggedInUser);
        }
    }
}
