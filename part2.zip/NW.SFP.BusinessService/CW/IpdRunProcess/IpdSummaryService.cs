﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.BusinessService.CW
{
    public class IpdSummaryService : IIpdSummaryService
    {
        private readonly IIpdSummaryDataService _ipdSummaryDataService;

        public IpdSummaryService(IIpdSummaryDataService ipdSummaryDataService)
        {
            _ipdSummaryDataService = ipdSummaryDataService;

        }

        public List<IpdSummaryResultEntity> GetIpdSummaryData(int dealId, int ipdRunId, string loggedInUserName)
        {
            return _ipdSummaryDataService.GetIpdSummaryData(dealId, ipdRunId, loggedInUserName);
        }
    }
}