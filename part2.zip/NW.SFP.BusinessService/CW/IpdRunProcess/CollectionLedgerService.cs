﻿using NW.SFP.Interface.CW.DataService;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class CollectionLedgerService : ICollectionLedgerService
    {

        private readonly ICollectionLedgerDataService _collectionLedgerDataService;
        public CollectionLedgerService(ICollectionLedgerDataService collectionLedgerDataService)
        {
            this._collectionLedgerDataService = collectionLedgerDataService;
        }

        public CollectionLedger GetCollectionLedgerData(IPDFeedParam ipdFeedParam)
        {
            return this._collectionLedgerDataService.GetCollectionLedgerData(ipdFeedParam);
        }

        public int UpdateCollectionLedgerData(UpdateCollectionLedgerEntity objUpdateCollectionLedgerEntity, string loggedInUser)
        {
            return this._collectionLedgerDataService.UpdateCollectionLedgerData(objUpdateCollectionLedgerEntity, loggedInUser);
        }
    }
}
