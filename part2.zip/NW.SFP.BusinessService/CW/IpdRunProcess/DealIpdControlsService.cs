﻿using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.BusinessService.CW.IpdRunProcess
{
    public class DealIpdControlsService : IDealIpdControlsService
    {
        private readonly IDealIpdControlsDataService _dealIpdControlsDataService;

        public DealIpdControlsService(IDealIpdControlsDataService controlsDataService)
        {
            _dealIpdControlsDataService = controlsDataService;
        }

        public StormVsSfpEntity StormVsSfp(int dealId, int ipdRunId, string loggedInUser)
        {
            return _dealIpdControlsDataService.StormVsSfp(dealId, ipdRunId, loggedInUser);
        }

        public DataSet StormVsSfpExcelData(int dealId, int ipdRunId, string loggedInUser)
        {
            return _dealIpdControlsDataService.StormVsSfpExcelData(dealId, ipdRunId, loggedInUser);
        }
    }
}
