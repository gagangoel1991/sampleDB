﻿using ExcelDataReader;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW.IpdRunProcess;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Linq;
using System.Data;
using System.Globalization;
using Microsoft.AspNetCore.Http;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;

namespace NW.SFP.BusinessService.CW.IpdRunProcess
{
    public class RatingUploadService : IRatingUploadService
    {
        private readonly IRatingUploadDataService _ratingOverrideDataService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;
        public readonly string[] TypeArray = { "Counterparty", "Bond" };
        public readonly string[] ColumnsArray = { "Unique Identifier", "Type", "CRA", "Rating Type", "Rating Value" };

        public RatingUploadService(IRatingUploadDataService ratingOverrideDataService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._ratingOverrideDataService = ratingOverrideDataService;
            this._cwSettings = cwSettings;
        }

        public IList<DealIpdDateEntity> GetDealIpdDates()
        {
            return _ratingOverrideDataService.GetDealIpdDates();
        }

        public IList<RatingMasterData> GetRatingMasterData(int DealId)
        {
            return _ratingOverrideDataService.GetRatingMasterData(DealId);
        }



        public RatingFileParsedResult ParseRatingFile(IFormFile RatingFile, int DealId)
        {
            DataTable dt = new DataTable();
            int DiscardedRowsCount = 0;
            string ErrorMessage = "";

            using (var ratingFileStream = new MemoryStream())
            {
                RatingFile.CopyTo(ratingFileStream);


                IExcelDataReader reader;
                string FileExtension = Path.GetExtension(RatingFile.FileName);
                if (string.Equals(FileExtension, ".csv", StringComparison.OrdinalIgnoreCase))
                {
                    reader = ExcelReaderFactory.CreateCsvReader(ratingFileStream);
                }
                else
                {
                    reader = ExcelReaderFactory.CreateReader(ratingFileStream);
                }


                using (reader)
                {
                    var result = reader.AsDataSet(
                        new ExcelDataSetConfiguration()
                        {
                            ConfigureDataTable = (tableReader) => new ExcelDataTableConfiguration()
                            {
                                UseHeaderRow = true

                            }
                        });

                    //Exactly one data sheet check
                    if (result.Tables.Count == 1)
                    {
                        //Columns Name Check and Columns Count Check
                        if (result.Tables[0].Columns.Count == ColumnsArray.Count() && !ColumnsArray.Any(col => result.Tables[0].Columns.Contains(col) == false))
                        {

                            //Rows Count Check 
                            if (result.Tables[0].Rows.Count > 0)
                            {

                                IList<RatingMasterData> objRatingMasterData = GetRatingMasterData(DealId);

                                dt = result.Tables[0].Copy();
                                dt.Columns.Add("IsRowDiscarded", typeof(bool));
                                dt.Columns.Add("RowDiscardedMessage", typeof(string));

                                foreach (DataRow row in dt.Rows)
                                {
                                    CultureInfo enUS = new CultureInfo("en-US");

                                    string UniqueIdentifier = Convert.ToString(row["Unique Identifier"]);
                                    string Type = Convert.ToString(row["Type"]);
                                    string CRA = Convert.ToString(row["CRA"]);
                                    string RatingType = Convert.ToString(row["Rating Type"]);
                                    string Rating = Convert.ToString(row["Rating Value"]);

                                    //Rating combination Exist in master data check
                                    var ratingExistInMasterData = objRatingMasterData.
                                     Any(elem =>
                                                string.Equals(elem.RatingType, RatingType, StringComparison.OrdinalIgnoreCase)
                                                &&
                                                string.Equals(elem.CRA.Replace("'", ""), CRA.Replace("'", ""), StringComparison.OrdinalIgnoreCase)
                                                &&
                                                string.Equals(elem.Rating, Rating, StringComparison.OrdinalIgnoreCase)
                                                &&
                                                string.Equals(elem.UniqueIdentifier, UniqueIdentifier, StringComparison.OrdinalIgnoreCase)
                                                &&
                                                string.Equals(elem.Type, Type, StringComparison.OrdinalIgnoreCase)

                                     );
                                    string RowDiscardedMessage = ratingExistInMasterData ? "" : " 'CRA','RatingType' and 'Rating Value' combination do not exist in database.";



                                    //Type Check
                                    var isValidType = TypeArray.Contains(Type, StringComparer.OrdinalIgnoreCase);
                                    RowDiscardedMessage += isValidType ? "" : " Type must be Counterparty or Bond.";



                                    //Duplicate Row Check 
                                    var IsDuplicateRow = dt.AsEnumerable().Where(
                                           row => row.Field<string>("Unique Identifier") == UniqueIdentifier
                                                  && row.Field<string>("Type") == Type
                                                  && row.Field<string>("CRA") == CRA
                                                  && row.Field<string>("Rating Type") == RatingType
                                      ).Count() > 1;
                                    RowDiscardedMessage = RowDiscardedMessage + (IsDuplicateRow ?
                                        " Duplicate row found for combination of 'Unique Identifier','Type','CRA' and 'Rating Type'." : "");

                                    row["RowDiscardedMessage"] = RowDiscardedMessage;

                                    if (!String.IsNullOrWhiteSpace(RowDiscardedMessage))
                                    {
                                        row["IsRowDiscarded"] = true;
                                        DiscardedRowsCount++;
                                    }
                                    else
                                    {
                                        row["IsRowDiscarded"] = false;

                                    }
                                }
                            }
                            else
                            {
                                ErrorMessage = "No data rows found in worksheet.";
                            }
                        }

                        else
                        {
                            ErrorMessage = ColumnsArray.Length + " Columns required with column names as - " + string.Join(",", ColumnsArray) + ".";
                        }
                    }
                    else
                    {
                        ErrorMessage = "Exactly 1 datasheet required in workbook.";
                    }
                }



                return new RatingFileParsedResult()
                {

                    ErrorMessage = ErrorMessage,
                    ParsedTable = dt,
                    DiscardedRowsCount = DiscardedRowsCount,
                    TotalRowsCount = dt.Rows.Count
                };
            }
        }


        public int SaveUserRatingData(IFormFile RatingFile, RatingFileUpload ObjRatingFileUpload)
        {
            RatingFileParsedResult parsedResult = new RatingFileParsedResult();
            //Parse the rating file to get accepted and discarded rows
            parsedResult = ParseRatingFile(RatingFile, ObjRatingFileUpload.DealId);

            //Save the File to disk
            string CustomFileName = Guid.NewGuid().ToString() + Path.GetExtension(RatingFile.FileName);
            using (var fileStream = new FileStream(Path.Combine(_cwSettings.Value.RatingsFileLocation, CustomFileName), FileMode.Create))
            {
                RatingFile.CopyTo(fileStream);
            }

            ObjRatingFileUpload.UploadedFileName = CustomFileName;
            ObjRatingFileUpload.OriginalFileName = RatingFile.FileName;
            ObjRatingFileUpload.UploadedDate = DateTime.Now;

            //Remove the discarded rows
            List<DataRow> rowsToRemove = new List<DataRow>();
            foreach (DataRow row in parsedResult.ParsedTable.Rows)
            {
                if (Convert.ToBoolean(row["IsRowDiscarded"]) == true)
                {
                    rowsToRemove.Add(row);
                }
            }
            foreach (var dr in rowsToRemove)
            {
                parsedResult.ParsedTable.Rows.Remove(dr);
            }

            //Remove the extra columns which are appended during parsing of file
            List<DataColumn> colsToRemove = new List<DataColumn>();
            foreach (DataColumn Column in parsedResult.ParsedTable.Columns)
            {
                if (!ColumnsArray.Contains(Column.ColumnName))
                    colsToRemove.Add(Column);
            }
            foreach (var col in colsToRemove)
            {
                parsedResult.ParsedTable.Columns.Remove(col);
            }

            //Create structure of final table which will get save
            ObjRatingFileUpload.RatingData = new DataTable();
            foreach (var col in ColumnsArray)
            {
                ObjRatingFileUpload.RatingData.Columns.Add(col, typeof(string));
            }

            //Copy each row and column from parsed datatable to final data table
            foreach (DataRow row in parsedResult.ParsedTable.Rows)
            {
                DataRow dr = ObjRatingFileUpload.RatingData.NewRow();
                foreach (var col in ColumnsArray)
                {
                    dr[col] = Convert.ToString(row[col]).Trim();
                }
                ObjRatingFileUpload.RatingData.Rows.Add(dr);
            }

            return _ratingOverrideDataService.SaveUserRatingData(ObjRatingFileUpload);

        }

        public IList<RatingListingData> GetRatingListingData()
        {
            return _ratingOverrideDataService.GetRatingListingData();
        }

        public RatingSavedData GetUserRatingSavedData(int userRatingFileUploadDetailId)
        {
            return _ratingOverrideDataService.GetUserRatingSavedData(userRatingFileUploadDetailId);
        }

        public bool UploadRatingDataRecordExist(RatingFileUpload ratingFileUpload)
        {
            return _ratingOverrideDataService.UploadRatingDataRecordExist(ratingFileUpload);
        }

        public int DeleteRatingData(int userRatingFileUploadDetailId, string LoggedInUserNamed)
        {
            return _ratingOverrideDataService.DeleteRatingData(userRatingFileUploadDetailId, LoggedInUserNamed);
        }
    }
}
