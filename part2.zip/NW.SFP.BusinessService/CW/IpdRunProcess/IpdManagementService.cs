﻿using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class IpdManagementService : IIpdManagementService
    {

        private readonly IIpdManagementDataService _cashwaterfallDashboardDataService;
        //  IList<CashwaterfallDashboardEntity> GetCashwaterfallDashboardData();

        public IpdManagementService(IIpdManagementDataService cashwaterfallDashboardDataService)
        {
            this._cashwaterfallDashboardDataService = cashwaterfallDashboardDataService;
        }

        public IList<IpdManagementResultEntity> GetIpdMgmtDashboardData(string userName)
        {
            return _cashwaterfallDashboardDataService.GetIpdMgmtDashboardData(userName);
        }

    }
}
