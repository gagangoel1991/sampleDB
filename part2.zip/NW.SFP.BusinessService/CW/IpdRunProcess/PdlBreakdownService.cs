﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class PdlBreakdownService : IPdlBreakdownService
    {
        private readonly IPdlBreakdownDataService _pdlBreakDownDataService;

        public PdlBreakdownService(IPdlBreakdownDataService pdlBreakDownDataService)
        {
            _pdlBreakDownDataService = pdlBreakDownDataService;

        }

        public List<PdlBreakdownEntity> GetPDLBreakdownData(IPDFeedParam ipdFeedParam)
        {
            return _pdlBreakDownDataService.GetPDLBreakdownData(ipdFeedParam);
        }
    }
}
