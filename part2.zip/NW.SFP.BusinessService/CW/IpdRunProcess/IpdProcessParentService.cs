﻿using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class IpdProcessParentService : IIpdProcessParentService
    {

        private readonly IIpdProcessParentDataService _ipdProcessParentDataService;

        public IpdProcessParentService(IIpdProcessParentDataService ipdProcessParentDataService)
        {

            this._ipdProcessParentDataService = ipdProcessParentDataService;
        }

        public DealIpdBasicInfoEntity GetIpdProcessParentData(IPDFeedParam ipdFeedParam)
        {
            return _ipdProcessParentDataService.GetIpdProcessParentData(ipdFeedParam);
        }

        public int InitiateIPD(int dealId, DateTime ipdDate, string userName)
        {
            return _ipdProcessParentDataService.InitiateIPD(dealId, ipdDate, userName);
        }

        public int ResetIPD(int dealId, DateTime ipdDate, string userName)
        {
            return _ipdProcessParentDataService.ResetIPD(dealId, ipdDate, userName);
        }

        public int RunIPD(int dealIpdRunId, string userName)
        {
            return _ipdProcessParentDataService.RunIPD(dealIpdRunId, userName);
        }
        public int WithdrawIPD(IpdWorkflowEntity ipdWorkflowEntity, string userName)
        {
            return _ipdProcessParentDataService.WithdrawIPD(ipdWorkflowEntity, userName);
        }
        public int SaveOverridedIRFile(OverrideIrEntity overrideIREntity, string UserName)
        {
            return this._ipdProcessParentDataService.SaveOverridedIRFile(overrideIREntity, UserName);
        }
    }
}