﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;

namespace NW.SFP.BusinessService.CW
{
    public class SubloanService : ISubloanService
    {
        private readonly ISubloanDataService _subLoanDataService;

        public SubloanService(ISubloanDataService subLoanDataService)
        {
            _subLoanDataService = subLoanDataService;

        }

        public Subloan GetSubloan(IPDFeedParam iPDFeedParam)
        {
            return _subLoanDataService.GetSubloan(iPDFeedParam);
        }
    }
}
