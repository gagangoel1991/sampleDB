﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;

namespace NW.SFP.BusinessService.CW
{
    public class UpstreamDataAuthWorkflowService : IUpstreamDataAuthWorkflowService
    {
        private readonly IUpstreamDataAuthWorkflowDataService _upstreamDataAuthWorkflowDataService;


        public UpstreamDataAuthWorkflowService(IUpstreamDataAuthWorkflowDataService upstreamDataAuthWorkflowDataService)
        {
            _upstreamDataAuthWorkflowDataService = upstreamDataAuthWorkflowDataService;
        }

        public IPDFeedParam GetUpstreamDataAuthWorkflowStatus(IPDFeedParam upstreamDataWorkflowEntity)
        {
            return _upstreamDataAuthWorkflowDataService.GetUpstreamDataAuthWorkflowStatus(upstreamDataWorkflowEntity);
        }

        public int ManageUpstreamDataAuthWorkflow(IPDFeedParam upstreamDataWorkflowEntity)
        {
            return _upstreamDataAuthWorkflowDataService.ManageUpstreamDataAuthWorkflow(upstreamDataWorkflowEntity);
        }
    }
}
