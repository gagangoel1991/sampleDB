﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW.IpdRunProcess
{
    public class DealConditionTestService : IDealConditionTestService
    {
        private readonly IDealConditionTestDataService _dealConditionTestDataService;

        public DealConditionTestService(IDealConditionTestDataService dealConditionTestDataService)
        {
            _dealConditionTestDataService = dealConditionTestDataService;
            
        }

        public List<DealConditionTestEntity> GetDealConditionTestData(IPDFeedParam ipdFeedParam)
        {
            return _dealConditionTestDataService.GetDealConditionTestData(ipdFeedParam);
        }

        public int SaveDealConditionTestData(DealConditionTestEntity dealConditionTestEntity, string loggedInUser)
        {
            return _dealConditionTestDataService.SaveDealConditionTestData(dealConditionTestEntity, loggedInUser);
        }

    }
}
