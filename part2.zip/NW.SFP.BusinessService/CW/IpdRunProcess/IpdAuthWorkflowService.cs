﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;

namespace NW.SFP.BusinessService.CW
{
    public class IpdAuthWorkflowService : IIpdAuthWorkflowService
    {
        private readonly IIpdAuthWorkflowDataService _ipdAuthWorkflowDataService;
        public IpdAuthWorkflowService(IIpdAuthWorkflowDataService ipdAuthWorkflowDataService)
        {
            _ipdAuthWorkflowDataService = ipdAuthWorkflowDataService;
        }

        public IpdWorkflowEntity GetIpdAuthWorkflowStatus(IpdWorkflowEntity ipdWorkflowEntity)
        {
            return _ipdAuthWorkflowDataService.GetIpdAuthWorkflowStatus(ipdWorkflowEntity);
        }

        public int ManageIpdAuthWorkflow(IpdWorkflowEntity ipdWorkflowEntity)
        {
            return _ipdAuthWorkflowDataService.ManageIpdAuthWorkflow(ipdWorkflowEntity);
        }

        public int ValidateIPD(int dealIpdRunId, int workFlowStep, string userName)
        {
            return _ipdAuthWorkflowDataService.ValidateIPD(dealIpdRunId, workFlowStep, userName);
        }
    }
}
