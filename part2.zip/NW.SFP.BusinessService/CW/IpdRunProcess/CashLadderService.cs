﻿using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class CashLadderService : ICashLadderService
    {
        private readonly ICashLadderDataService _cashLadderDataService;

        public CashLadderService(ICashLadderDataService cashLadderDataService)
        {
            this._cashLadderDataService = cashLadderDataService;
        }

        /// <summary>
        /// this will return cash ladder data
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public CashLadder GetCashLadderData(IPDFeedParam ipdFeedParam)
        {
            return _cashLadderDataService.GetCashLadderData(ipdFeedParam);
        }

        public int SaveCashLadderData(UpdateCashLadderEntity objUpdateCashLadderEntity, string loggedInUser)
        {
            return _cashLadderDataService.SaveCashLadderData(objUpdateCashLadderEntity,loggedInUser);
        }
    }
}
