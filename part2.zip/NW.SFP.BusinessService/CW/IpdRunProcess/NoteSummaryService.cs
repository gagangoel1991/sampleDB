﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;

namespace NW.SFP.BusinessService.CW
{
    public class NoteSummaryService : INoteSummaryService
    {
        private readonly INoteSummaryDataService _noteSummaryDataService;

        public NoteSummaryService(INoteSummaryDataService noteSummaryDataService)
        {
            _noteSummaryDataService = noteSummaryDataService;

        }

        public DealNoteSummary GetDealNoteSummary(IPDFeedParam ipdFeedParam)
        {
            return _noteSummaryDataService.GetDealNoteSummary(ipdFeedParam);
        }
    }
}
