﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;

namespace NW.SFP.BusinessService.CW
{
    public class InterestRateService : IInterestRateService
    {
        private readonly IInterestRateDataService _interestRateDataService;

        public InterestRateService(IInterestRateDataService interestRateDataService)
        {
            _interestRateDataService = interestRateDataService;
        }
        public InterestRate GetInterestRateData(IPDFeedParam ipdFeedParam)
        {
            return _interestRateDataService.GetInterestRateData(ipdFeedParam);
        }

        public int SaveInterestRate(InterestRateEntity interestRateEntity, string loggedInUser)
        {
            return _interestRateDataService.SaveInterestRate(interestRateEntity, loggedInUser);
        }
    }
}
