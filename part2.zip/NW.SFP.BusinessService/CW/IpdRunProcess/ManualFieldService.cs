﻿using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class ManualFieldService : IManualFieldService
    {
        private readonly IManualFieldDataService _objManualFieldDataService;

        public ManualFieldService(IManualFieldDataService ObjManualFieldDataService)
        {
            _objManualFieldDataService = ObjManualFieldDataService;
        }


        public List<ManualFieldEntity> GetManualFieldData(int DealIpdRunId,int mfGrouptypeId, string UserName)
        {
            return _objManualFieldDataService.GetManualFieldData(DealIpdRunId, mfGrouptypeId, UserName);
        }

        public int ResetManualFieldData(int DealIpdRunId, int mfGrouptypeId, string UserName)
        {
            return _objManualFieldDataService.ResetManualFieldData(DealIpdRunId, mfGrouptypeId, UserName);
        }

        public int UpdateManualFieldData(List<ManualFieldKeyValue> ManualFieldKeyValue, int mfGrouptypeId, string UserName)
        {
            return _objManualFieldDataService.UpdateManualFieldData(ManualFieldKeyValue, mfGrouptypeId, UserName);
        }

        public int ResetManualFieldDealSwapData(int DealIpdRunId, int mfGrouptypeId, string UserName)
        {
            return _objManualFieldDataService.ResetManualFieldDealSwapData(DealIpdRunId, mfGrouptypeId, UserName);
        }
    }
}
