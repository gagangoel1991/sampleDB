﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using NW.SFP.Interface.CW;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class AdjustmentWaterfallService : IAdjustmentWaterfallService
    {
        private readonly IAdjustmentWaterfallDataService _adjustmentPrincipalWaterfallDataService;
        private readonly IAdjustmentWaterfallOutputDataService _adjustmentPrincipalWaterfalloutputDataService;
        public AdjustmentWaterfallService(IAdjustmentWaterfallDataService adjustmentPrincipalWaterfallDataService,
            IAdjustmentWaterfallOutputDataService adjustmentPrincipalWaterfalloutputDataService)
        {
            this._adjustmentPrincipalWaterfallDataService = adjustmentPrincipalWaterfallDataService;
            this._adjustmentPrincipalWaterfalloutputDataService = adjustmentPrincipalWaterfalloutputDataService;
        }

        public IList<AdjustmentOutputEntity> GetAdjustmentPppOutputData(IPDFeedParam ipdFeedParam)
        {
            return _adjustmentPrincipalWaterfalloutputDataService.GetAdjustmentPppOutputData(ipdFeedParam);
        }

        public IList<AdjustmentOutputEntity> GetAdjustmentRppOutputData(IPDFeedParam ipdFeedParam)
        {
            return _adjustmentPrincipalWaterfalloutputDataService.GetAdjustmentRppOutputData(ipdFeedParam);
        }

        /// <summary>
        /// this will return Adjustment Principal Waterfall data
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<AdjustmentWaterfallEntity> GetAdjustmentWaterfallData(IPDFeedParam ipdFeedParam)
        {
            return _adjustmentPrincipalWaterfallDataService.GetAdjustmentWaterfallData(ipdFeedParam);
        }

        public int SavePrincipalWaterfall(IEnumerable<AdjustmentWaterfallEntity> adjustmentPrincipalWaterfallEntity, string loggedInUser)
        {

            var isSave = _adjustmentPrincipalWaterfallDataService.SavePrincipalWaterfall(adjustmentPrincipalWaterfallEntity, loggedInUser);
            return isSave;
        }
    }
}
