﻿using NW.SFP.Interface.CW.DataService;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.CW
{
    public class WorkflowAuditService : IWorkflowAuditService
    {

        private readonly IWorkflowAuditDataService _workflowAuditDataService;
        public WorkflowAuditService(IWorkflowAuditDataService workflowAuditDataService)
        {
            this._workflowAuditDataService = workflowAuditDataService;
        }


        public IList<WorkflowAuditEntity> GetWorkflowAuditData(int workflowTypeId, int referenceId, string loggedInUser)
        {
            return this._workflowAuditDataService.GetWorkflowAuditData(workflowTypeId, referenceId, loggedInUser);
        }
    }
}
