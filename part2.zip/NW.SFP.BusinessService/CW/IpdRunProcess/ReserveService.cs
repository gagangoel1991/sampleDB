﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class ReserveService : IReserveService
    {
        private readonly IReserveDataService _reserveDataService;

        public ReserveService(IReserveDataService reserveDataService)
        {
            _reserveDataService = reserveDataService;
        }

        public List<ReserveEntity> GetReserve(IPDFeedParam ipdFeedParam)
        {
            return _reserveDataService.GetReserve(ipdFeedParam);
        }
    }
}
