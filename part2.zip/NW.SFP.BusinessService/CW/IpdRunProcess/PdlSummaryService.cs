﻿using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.BusinessService.CW
{
    public class PdlSummaryService : IPdlSummaryService
    {
        private readonly IPdlSummaryDataService _pdlSummaryDataService;

        public PdlSummaryService(IPdlSummaryDataService pdlSummaryDataService)
        {
            _pdlSummaryDataService = pdlSummaryDataService;

        }

        public DataTable GetPDLSummaryData(IPDFeedParam feedParms)
        {
            return _pdlSummaryDataService.GetPDLSummaryData(feedParms);
        }
    }
}
