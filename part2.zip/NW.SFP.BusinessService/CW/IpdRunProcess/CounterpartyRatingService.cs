﻿using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CW
{
    public class CounterpartyRatingService : ICounterpartyRatingService
    {
        private readonly ICounterpartyRatingDataService _cpRatingDataService;
        private readonly ICreditRatingDataService _creditRatingDataService;

        public CounterpartyRatingService(ICounterpartyRatingDataService cpRatingDataService, ICreditRatingDataService creditRatingDataService)
        {
            this._cpRatingDataService = cpRatingDataService;
            this._creditRatingDataService = creditRatingDataService;
        }

        public CounterpartyRatingEntity GetCounterpartyRatingData(IPDFeedParam ipdFeedParam)
        {
            return _cpRatingDataService.GetCounterpartyRatingData(ipdFeedParam);
        }

        public IList<CreditRatingEntity> GetCreditRatings(string loggedInUserName)
        {
            return _creditRatingDataService.GetCreditRatings(loggedInUserName);
        }

        public bool IsCPRatingEdited(int ipdRunId, string loggedInUser)
        {
            return _cpRatingDataService.IsCPRatingEdited(ipdRunId, loggedInUser);
        }

        public int ResetCounterpartyRatingData(int ipdRunId, string loggedInUser)
        {
            return _cpRatingDataService.ResetCounterpartyRatingData(ipdRunId, loggedInUser);
        }

        public int SaveCounterpartyRatingData(dynamic cpRatingEntity, string loggedInUser)
        {
            return _cpRatingDataService.SaveCounterpartyRatingData(cpRatingEntity, loggedInUser);
        }
    }
}
