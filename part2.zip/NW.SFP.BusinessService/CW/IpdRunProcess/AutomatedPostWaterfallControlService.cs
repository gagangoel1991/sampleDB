﻿namespace NW.SFP.BusinessService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Web;
    using System.Data;
    using System.Threading;
    using System.IO;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.CW;
    using NW.SFP.Interface.CW;
    using ClosedXML.Excel;
    using NW.SFP.Message.Core;
    using NW.SFP.Interface.Core;
    using Microsoft.Extensions.Options;
    using DocumentFormat.OpenXml.Bibliography;
    using NW.SFP.Message.CW.IR;
    using Newtonsoft.Json;
    using NW.SFP.Interface.CW.BusinessService;
    using NW.SFP.Interface.CW.DataService;

    public class AutomatedPostWaterfallControlService :  IAutomatedPostWaterfallControlService
    {
        private IIrReportDataService reportRepository;
        private IPostWaterfallDataService _postWaterfallDataService;
        private IExcelService _excelService;
        private readonly ILoggerService _loggerService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;
        private string SourcePath;
        private string TargetPath;
        private string ParentWorkSheet;
        string BackupTemplate;
        string GeneratedFileName;
        private LogInfoEntity logInfo;

        public AutomatedPostWaterfallControlService(IIrReportDataService reportRepository, IExcelService excelService, ILoggerService loggerService
            , IOptions<CashWaterfallSettings> cwSettings, IPostWaterfallDataService postWaterfallDataService)
        {
            this.reportRepository = reportRepository;
            this._excelService = excelService;
            this._loggerService = loggerService;
            this._cwSettings = cwSettings;
            this._postWaterfallDataService = postWaterfallDataService;

            SourcePath = _cwSettings.Value.IrConfigFileLocation;
            TargetPath = _cwSettings.Value.IRTargetFileLocation;
            ParentWorkSheet =  _cwSettings.Value.IrParentWorksheet;

        }

        public IEnumerable<ExcelUploadEntity> GetPostWfControlList(string DealName, string AsAtDate)
        {
                IEnumerable<ExcelUploadEntity> report = this.reportRepository.GetExcelPostWFControlList(DealName, AsAtDate);
                return report;
        }

        public DataTable GetStratData(string AsAtDate, string DealName, int FieldId, string StratName, string LoggedInUserName, string ReportTypeName)
        {
            DataTable data = this.reportRepository.GetIrStratData(AsAtDate, DealName, FieldId, StratName, LoggedInUserName, ReportTypeName);
            return data;
        }


        public bool GenerateAutomatedPostWaterfallFile(string DealName, string AsAtDate, string LoggedInUserName)
        {
            try
            {

                var _ExcelUploadEntity = GetPostWfControlList(DealName, AsAtDate);

                string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;
                string IRFileName = string.Concat(TargetPath,  _ExcelUploadEntity.First().DownloadIrFileName);

                string TemplatePath = string.Concat(SourcePath, TemplateFile);

                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                GeneratedFileName = string.Concat(TargetPath, OutPutFileName);

                logInfo = new LogInfoEntity() { LogDetail = "PW Control file writing started on  " + TemplateFile, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = 1, UserName = LoggedInUserName };
                this._loggerService.LogInfo(logInfo);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                using (var workbook = new XLWorkbook(BackupTemplate))
                {

                    logInfo = new LogInfoEntity() { LogDetail = "PW Control temp file started on  " + BackupTemplate, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = 1, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);

                    if (_excelService.IsWorksheetExist(workbook, ParentWorkSheet))
                        {

                            foreach (ExcelUploadEntity excelReport in _ExcelUploadEntity)
                            {

                                logInfo = new LogInfoEntity() { LogDetail = "PW Control data fetch started for strat  " + excelReport.StratName, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                                this._loggerService.LogInfo(logInfo);

                                //Populate Data table
                                var dtGetReportAssetData = this.reportRepository.GetIrStratData(AsAtDate, excelReport.DealName, excelReport.FieldId, excelReport.StratName, LoggedInUserName, "");
                                //Write into XL Object
                                /*
                                 * if worksheet name is missing then system will create
                                */
                                if (_excelService.IsWorksheetExist(workbook, excelReport.WorkSheetName) == false)
                                {
                                    workbook.Worksheets.Add(excelReport.WorkSheetName);
                                }

                                _excelService.WriteDataIntoExcel(dtGetReportAssetData, workbook.Worksheet(excelReport.WorkSheetName), excelReport.RowStartIndex, excelReport.ColumnStartIndex);

                                logInfo = new LogInfoEntity() { LogDetail = "PW Control data fetch completed for strat  " + excelReport.StratName, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                                this._loggerService.LogInfo(logInfo);
                            }


                            CopyInvestorReportTabData(IRFileName, workbook, ParentWorkSheet,  _ExcelUploadEntity.First().IrFormatColStartIndex, _ExcelUploadEntity.First().IrFormatColEndIndex, _ExcelUploadEntity.First().IrFormatRowStartIndex, _ExcelUploadEntity.First().IrFormatRowEndIndex);
                   
                            logInfo = new LogInfoEntity() { LogDetail = "PW Control save process started " + GeneratedFileName, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                            this._loggerService.LogInfo(logInfo);

                            workbook.SaveAs(GeneratedFileName);

                            System.IO.File.Delete(BackupTemplate);

                            logInfo = new LogInfoEntity() { LogDetail = "PW Control save process ended " + GeneratedFileName, ActionPerformed = "IrReportService.GenerateIRFile", ModuleId = 1, UserName = LoggedInUserName };
                            this._loggerService.LogInfo(logInfo);
                        }

                }

                return true;
            }
            catch (Exception ex)
            {
                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                throw ex;
            }
        }

        public void CopyInvestorReportTabData(string IRFileName, IXLWorkbook _toWb, string sheetName, int startColNo, int endColNo, int startRowNo, int endRowNo)
        {
            try
            {

                using (var wb = new XLWorkbook(IRFileName))
                {

                    for (var currentCol = startColNo; currentCol <= endColNo; currentCol++)
                    {
                        for (var currentRow = startRowNo; currentRow <= endRowNo; currentRow++)
                        {
                           
                            var isFormula = wb.Worksheet(sheetName).Cell(currentRow, currentCol).HasFormula;

                            if (!isFormula)
                            {
                                var value = wb.Worksheet(sheetName).Cell(currentRow, currentCol).Value;
                                _toWb.Worksheet(sheetName).Cell(currentRow, currentCol).Value = value;
                               
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logInfo = new LogInfoEntity() { LogDetail = "error while copy data from investor report " + ex.InnerException, ActionPerformed = "AutomatedPostWaterfallControlService.CopyInvestorReportTabData", ModuleId = 1, UserName = "system" };
                this._loggerService.LogInfo(logInfo);
            }
        }


        public List<PostWaterfallReconcileEntity> GetPostWaterfallTabData(string IRFileName,string sheetName)
        {
            try
            {
               

                List<PostWaterfallEntity> lstDeallookup = _postWaterfallDataService.PostWaterfallOutputFileData();

                List<PostWaterfallReconcileEntity> lstPostWaterfallReconcileEntity = new List<PostWaterfallReconcileEntity>();

                PostWaterfallReconcileEntity objPostWaterfallReconcileEntity;



                List<PostWaterfallEntity> lstWaterfallReconcil = lstDeallookup.Where(x => x.AttributeType.ToString() == "Waterfall Reconciliation Attribute").ToList();
                List<PostWaterfallEntity> lstassetStratReconcil = lstDeallookup.Where(x => x.AttributeType.ToString() == "Asset Strats Reconciliation Attribute").ToList();
                using (var wb = new XLWorkbook(IRFileName))
                {

                     foreach(PostWaterfallEntity post in lstWaterfallReconcil)
                     {
                        objPostWaterfallReconcileEntity = new PostWaterfallReconcileEntity();
                        objPostWaterfallReconcileEntity.AttributeName= post.AttributeName;
                        objPostWaterfallReconcileEntity.AttributeType = post.AttributeType;
                        objPostWaterfallReconcileEntity.AttributeValue = wb.Worksheet(sheetName).Cell(Convert.ToInt32(post.StartRowindex), Convert.ToInt32(post.StartColindex)).Value.ToString();
                        lstPostWaterfallReconcileEntity.Add(objPostWaterfallReconcileEntity);                                 
                     }

                    foreach (PostWaterfallEntity post in lstassetStratReconcil)
                    {
                        
                         for (var currentRow = Convert.ToInt32(post.StartRowindex); currentRow <= Convert.ToInt32(post.EndRowindex); currentRow++)
                         {
                            objPostWaterfallReconcileEntity = new PostWaterfallReconcileEntity();
                            objPostWaterfallReconcileEntity.AttributeName = wb.Worksheet(sheetName).Cell(currentRow, 1).Value.ToString();
                            objPostWaterfallReconcileEntity.AttributeType = post.AttributeType;
                            //Investor Report

                            string AttributeCount = wb.Worksheet(sheetName).Cell(currentRow, 2).Value.ToString();
                            if (AttributeCount == "Investor Report" || AttributeCount == "Loan Count")
                            {
                                objPostWaterfallReconcileEntity.AttributeCount = "";
                            }
                            else
                            {
                                objPostWaterfallReconcileEntity.AttributeCount = AttributeCount;
                            }

                            string AttributeValue = wb.Worksheet(sheetName).Cell(currentRow, 3).Value.ToString();

                            if (!(string.IsNullOrEmpty(AttributeValue)|| string.IsNullOrWhiteSpace(AttributeValue)) && AttributeValue != "Loan Balance")
                            {
                                decimal AttributeValues = Decimal.Round(Convert.ToDecimal(AttributeValue), 2);
                                objPostWaterfallReconcileEntity.AttributeValue = AttributeValues.ToString();
                            }
                            else
                            {                             
                                objPostWaterfallReconcileEntity.AttributeValue = "";
                            }

                            //SFP
                            string DailyCollectionCount = wb.Worksheet(sheetName).Cell(currentRow, 4).Value.ToString();
                            if (DailyCollectionCount == "SFP" || DailyCollectionCount == "Loan Count")
                            {
                                objPostWaterfallReconcileEntity.DailyCollectionCount = "";
                            }

                            else
                            {
                                objPostWaterfallReconcileEntity.DailyCollectionCount = DailyCollectionCount;
                            }

                            string DailyCollectionValue = wb.Worksheet(sheetName).Cell(currentRow, 5).Value.ToString();
                            if (!(string.IsNullOrEmpty(DailyCollectionValue) || string.IsNullOrWhiteSpace(DailyCollectionValue)) && DailyCollectionValue != "Loan Balance" && DailyCollectionValue != "SFP")
                            {
                                decimal DailyCollectionValues = Decimal.Round(Convert.ToDecimal(DailyCollectionValue), 2);
                                objPostWaterfallReconcileEntity.DailyCollectionValue = DailyCollectionValues.ToString();                                
                            }
                            else
                            {
                                objPostWaterfallReconcileEntity.DailyCollectionValue = "";
                            }
                            
                            objPostWaterfallReconcileEntity.VarianceCount = wb.Worksheet(sheetName).Cell(currentRow, 6).Value.ToString();
                            objPostWaterfallReconcileEntity.VarianceValue = wb.Worksheet(sheetName).Cell(currentRow, 7).Value.ToString();
                            lstPostWaterfallReconcileEntity.Add(objPostWaterfallReconcileEntity);

                               
                         }
                    }


                }

                return lstPostWaterfallReconcileEntity;
            }
            catch (Exception ex)
            {
                logInfo = new LogInfoEntity() { LogDetail = "error in PW Control save process  " + ex.InnerException, ActionPerformed = "AutomatedPostWaterfallControlService.CopyInvestorReportTabData", ModuleId = 1, UserName = "system" };
                this._loggerService.LogInfo(logInfo);
                return null;
            }
        }

        public List<PostWaterfallEntity> GetPostWaterfallOutputFileData()
        {
            return _postWaterfallDataService.PostWaterfallOutputFileData();
        }

    }
}
