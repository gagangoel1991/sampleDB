﻿using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.DataService.PS
{
    public class AssetClassService : IAssetClassService
    {
        #region Object Declarations and Constructor
        private readonly IAssetClassDataService _assetClassDataService;

        public AssetClassService(IAssetClassDataService assetclassDataService)
        {
            this._assetClassDataService = assetclassDataService;
        }
        #endregion

        #region Get AssetClass
        public IList<AssetClass> GetAssetClass()
        {
            return _assetClassDataService.GetAssetClass();
        }
        #endregion
    }
}