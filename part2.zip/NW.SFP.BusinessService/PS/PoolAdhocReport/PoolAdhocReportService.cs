﻿using NW.SFP.Interface.PS.BusinessService;
using NW.SFP.Interface.PS.DataService;
using NW.SFP.Message.PS;
using System.Collections.Generic;
using System.IO;

namespace NW.SFP.BusinessService.PS.PoolAdhocReport
{
    public class PoolAdhocReportService : IPoolAdhocReportService
    {
        private readonly IPoolAdhocReportDataService _poolAdhocReportDataService;
        public PoolAdhocReportService(IPoolAdhocReportDataService poolAdhocReportDataService)
        {
            _poolAdhocReportDataService = poolAdhocReportDataService;
        }

        public int DeleteReportTemplateData(int reportTemplateId, string loggedInUserName)
        {
            return _poolAdhocReportDataService.DeleteReportTemplateData(reportTemplateId, loggedInUserName);
        }

        public MemoryStream GenerateReportData(int reportTemplateId, int poolId, string loggedInUserName, ReportTemplateData reportTemplateData, bool isCsv)
        {
            return _poolAdhocReportDataService.GenerateReportData(reportTemplateId, poolId, loggedInUserName, reportTemplateData, isCsv);
        }

        public IList<PoolAdhocReportTemplateList> GetAdhocReports(string loggedInUserName, int assetClassId)
        {
            return _poolAdhocReportDataService.GetAdhocReports(loggedInUserName, assetClassId);
        }

        public IList<AdhocReportField> GetFieldsForReports(string loggedInUserName, int assetClassId)
        {
            return _poolAdhocReportDataService.GetFieldsForReports(loggedInUserName, assetClassId);
        }

        public AdhocReportRefData GetReportRefData(string loggedInUserName, int assetClassId = 1)
        {
            return _poolAdhocReportDataService.GetReportRefData(loggedInUserName, assetClassId);
        }

        public IDictionary<int, List<AdhocReportOperator>> GetDatatypeAggregationMap(string loggedInUserName)
        {
            return _poolAdhocReportDataService.GetDatatypeAggregationMap(loggedInUserName);
        }

        public ReportTemplateData GetReportTemplateData(int reportTemplateId, string loggedInUserName)
        {
            return _poolAdhocReportDataService.GetReportTemplateData(reportTemplateId, loggedInUserName);
        }

        public int SaveReportTemplateData(ReportTemplateData reportTemplateData, string loggedInUserName)
        {
            return _poolAdhocReportDataService.SaveReportTemplateData(reportTemplateData, loggedInUserName);
        }      

        public IList<AdhocReportTypeEntity> GetAdhocReportTypeList(string LoggedInUserName)
        {
            return _poolAdhocReportDataService.GetAdhocReportTypeList(LoggedInUserName);
        }
    }
}
