﻿using ClosedXML.Excel;
using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.IO;
using NW.SFP.DataService;
using System.Reflection;
using System.ComponentModel;
using System.Linq;
using System.ComponentModel.DataAnnotations;

namespace NW.SFP.BusinessService.PS
{
    public class ReplinseReportService : IReplinesReportService
    {
        private readonly IReplinesReportDataService _replinseReportDataService;

        public ReplinseReportService(IReplinesReportDataService replinceReportDataService)
        {
            this._replinseReportDataService = replinceReportDataService;
        }

        public MemoryStream GetReplinesReportData(DateTime inceptionDate, int dealKey, string userName)
        {
            return ExcelSheetForReplinesReport(this._replinseReportDataService.GetReplinesReportData(inceptionDate, dealKey, userName));
        }


        #region Excel Sheet Utility


        private MemoryStream ExcelSheetForReplinesReport(ReplinseReportData replinseReport)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet = workbook.Worksheets.Add($"ReplinesReportData");
                FillReplinesReportWorksheet(replinseReport, worksheet);
                workbook.SaveAs(stream);
                return stream;
            }
        }

        private void FillReplinesReportWorksheet(ReplinseReportData replinseReport, IXLWorksheet worksheet)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForReplinesReport())
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                columnNo++;
            }

            if (replinseReport != null)
            {
                foreach (var data in replinseReport.ReplinseReport)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.InterestType;
                    worksheet.Cell(currentRow, 2).Value = data.PaymentType;
                    worksheet.Cell(currentRow, 3).Style.NumberFormat.Format = "@";
                    worksheet.Cell(currentRow, 3).Value = data.SeasoningBucket;
                    
                    worksheet.Cell(currentRow, 4).Value = data.OriginalTermBucket;

                    worksheet.Cell(currentRow, 5).Style.NumberFormat.Format = "@";
                    worksheet.Cell(currentRow, 5).Value = data.MonthsToResetBucket;
                    worksheet.Cell(currentRow, 6).Value = data.LTVBucket;
                    worksheet.Cell(currentRow, 7).Value = data.TempIOPeriod;
                    worksheet.Cell(currentRow, 8).Value = data.FloorOnTrackerRate;
                    worksheet.Cell(currentRow, 9).Value = data.CountOfLoanId;
                    worksheet.Cell(currentRow, 9).Style.NumberFormat.Format = "#,###,##0";

                    worksheet.Cell(currentRow, 10).Value = $"{data.CutOffBalance}";
                    worksheet.Cell(currentRow, 10).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 11).Value = $"{data.OTermWAByBalance}";
                    worksheet.Cell(currentRow, 11).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 12).Value = $"{data.SeasoningWAByBalance}";
                    worksheet.Cell(currentRow, 12).Style.NumberFormat.Format = "#,###,##0.000000";

                    worksheet.Cell(currentRow, 13).Value = $"{data.CouponWAByBalance}";
                    worksheet.Cell(currentRow, 13).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 14).Value = $"{data.MarginWAByBalance}";
                    worksheet.Cell(currentRow, 14).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 15).Value = $"{data.TeaserDiscountWAByBalance}";
                    worksheet.Cell(currentRow, 15).Style.NumberFormat.Format = "#,###,##0.000000";

                    worksheet.Cell(currentRow, 16).Value = $"{data.MonthsToResetWAByBalance}";
                    worksheet.Cell(currentRow, 16).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 17).Value = $"{data.IOWAByBalance}";
                    worksheet.Cell(currentRow, 17).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 18).Value = $"{data.MonOfTempIORevWAByBalance}";
                    worksheet.Cell(currentRow, 18).Style.NumberFormat.Format = "#,###,##0";

                    worksheet.Cell(currentRow, 19).Value = $"{data.PercOfBalanceInDefault}";
                    worksheet.Cell(currentRow, 19).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 20).Value = $"{data.PercOfBalanceInDelinquency}";
                    worksheet.Cell(currentRow, 20).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 21).Value = $"{data.TrackerFloorWAByBalance}";
                    worksheet.Cell(currentRow, 21).Style.NumberFormat.Format = "#,###,##0";

                    worksheet.Cell(currentRow, 22).Value = $"{data.CombinedLTV}";
                    worksheet.Cell(currentRow, 22).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 23).Value = $"{data.CreditScoreWAByBalance}";
                    worksheet.Cell(currentRow, 23).Style.NumberFormat.Format = "#,###,##0";
                    worksheet.Cell(currentRow, 24).Value = $"{data.MIWAByBalance}";
                    worksheet.Cell(currentRow, 24).Style.NumberFormat.Format = "#,###,##0";

                    worksheet.Cell(currentRow, 25).Value = $"{data.PrimeWAByBalance}";
                    worksheet.Cell(currentRow, 25).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 26).Value = $"{data.UnVerifiedIncomeWAByBalance}";
                    worksheet.Cell(currentRow, 26).Style.NumberFormat.Format = "#,###,##0";
                    worksheet.Cell(currentRow, 27).Value = $"{data.SelfEmployedWAByBal}";
                    worksheet.Cell(currentRow, 27).Style.NumberFormat.Format = "#,###,##0.000000";

                    worksheet.Cell(currentRow, 28).Value = $"{data.BuyToLetWAByBalance}";
                    worksheet.Cell(currentRow, 28).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 29).Value = $"{data.PriorBankcruptcyWAByBalance}";
                    worksheet.Cell(currentRow, 29).Style.NumberFormat.Format = "#,###,##0";
                    worksheet.Cell(currentRow, 30).Value = $"{data.FlexLoanWAByBalance}";
                    worksheet.Cell(currentRow, 30).Style.NumberFormat.Format = "#,###,##0";

                    worksheet.Cell(currentRow, 31).Value = $"{data.SecondHomeWAByBalance}";
                    worksheet.Cell(currentRow, 31).Style.NumberFormat.Format = "#,###,##0";
                    worksheet.Cell(currentRow, 32).Value = $"{data.FirstLienWAByBalance}";
                    worksheet.Cell(currentRow, 32).Style.NumberFormat.Format = "#,###,##0.000000";
                    worksheet.Cell(currentRow, 33).Value = $"{data.ValuationAgeWAByBalance}";
                    worksheet.Cell(currentRow, 33).Style.NumberFormat.Format = "#,###,##0.000000";
                }
            }

        }

        #endregion

        #region Replines Property Display Utility

        private static String GetDisplayName(Type type, PropertyInfo info, bool hasMetaDataAttribute)
        {
            if (!hasMetaDataAttribute)
            {
                object[] attributes = info.GetCustomAttributes(typeof(DisplayAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var displayName = (DisplayAttribute)attributes[0];
                    return displayName.Name;
                }
                return info.Name;
            }
            PropertyDescriptor propDesc = TypeDescriptor.GetProperties(type).Find(info.Name, true);
            DisplayNameAttribute displayAttribute =
                propDesc.Attributes.OfType<DisplayNameAttribute>().FirstOrDefault();
            return displayAttribute != null ? displayAttribute.DisplayName : null;
        }

        private List<string> GetHeaderDisplayNameForReplinesReport()
        {
            var item = new ReplinesReport();
            Type type = item.GetType();
            PropertyInfo[] properties = type.GetProperties();
            List<string> replinesReportHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                replinesReportHeader.Add(GetDisplayName(type, info, false));
            }
            return replinesReportHeader;
        }


        #endregion





    }
}