﻿using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System.Collections.Generic;
using System;

namespace NW.SFP.BusinessService.PS
{
    public class DashboardPoolSelectionService : IDashboardPoolSelectionService
    {
        private readonly IDashboardPoolSelectionDataService _dashboardPoolSelectionDataService;

        public DashboardPoolSelectionService(IDashboardPoolSelectionDataService dashboardPoolSelectionDataService)
        {
            this._dashboardPoolSelectionDataService = dashboardPoolSelectionDataService;
        }

        public IList<DashboardSummary> GetDashboardSummary(string userName, int assetClassId)
        {
            return this._dashboardPoolSelectionDataService.GetDashboardSummary(userName, assetClassId);
        }
        public IList<DashboardSummary> GetPreviousWork(DateTime fromDate, DateTime toDate, string userName, int assetClassId)
        {
            return this._dashboardPoolSelectionDataService.GetPreviousWork(fromDate, toDate, userName, assetClassId);
        }
        public IList<DashBoardPoolData> GetDashBoardCompletedPoolData(DateTime fromDate, DateTime toDate, string userName, int assetClassId)
        {
            return this._dashboardPoolSelectionDataService.GetDashBoardCompletedPoolData(fromDate, toDate, userName, assetClassId);
        }
        public DealFlagDeFlagData GetDashBoardDealsData(DateTime analysisDate, string userName, bool IsInitial, int assetClassId)
        {
            return this._dashboardPoolSelectionDataService.GetDashBoardDealsData(analysisDate, userName, IsInitial, assetClassId);
        }

        public IList<DashBoardFailedPoolData> GetFailedPoolData(DateTime analysisDate, string userName, int assetClassId)
        {
            return this._dashboardPoolSelectionDataService.GetDashBoardFailedPoolData(analysisDate, userName, assetClassId);
        }
        
    }
}