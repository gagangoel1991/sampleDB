﻿using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.PS
{
    public class ExclusionService : IExclusionService
    {
        private readonly IExclusionDataService _exclusionDataService;

        public ExclusionService(IExclusionDataService exclusionDataService)
        {
            this._exclusionDataService = exclusionDataService;
        }

        public Exclusion GetExclusionByID(int exclusionId, string userName)
        {
            return this._exclusionDataService.GetExclusionById(exclusionId, userName);
        }

        public int CreateExclusion(Exclusion exclusion, string userName)
        {
            return this._exclusionDataService.CreateExclusion(exclusion, userName);
        }

        public IList<ExclusionValidationResult> ValidateExclusion(Exclusion exclusion, string userName)
        {
            return this._exclusionDataService.ValidateExclusion(exclusion, userName);
        }

        public ExclusionData GetExclusionManagementData(string userName)
        {
            return this._exclusionDataService.GetExclusionManagementData(userName);
        }
    }
}