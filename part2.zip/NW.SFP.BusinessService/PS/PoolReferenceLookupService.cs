﻿namespace NW.SFP.BusinessService.PS
{
    using NW.SFP.Interface.PS;
    using NW.SFP.Message.PS;

    public class PoolReferenceLookupService : IPoolReferenceLookupService
    {
        private readonly IPoolReferenceLookupDataService _poolReferenceLookupDataService;

        public PoolReferenceLookupService(IPoolReferenceLookupDataService poolReferenceLookupDataService)
        {
            this._poolReferenceLookupDataService = poolReferenceLookupDataService;
        }

        public PoolReferenceData GetPoolReferenceData(string userName, int assetId)
        {
            return this._poolReferenceLookupDataService.GetPoolReferenceData(userName, assetId);
        }
    }
}