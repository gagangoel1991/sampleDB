﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Linq;
using System.IO;
using ClosedXML.Excel;
using System.Reflection;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace NW.SFP.BusinessService.PS
{
    public class EligibilityService : IEligibilityService
    {
        #region Object Declarations and Constructor
        private readonly IEligibilityDataService _ecDataService;

        public EligibilityService(IEligibilityDataService ecDataService)
        {
            this._ecDataService = ecDataService;
        }
        #endregion

        #region Get Eligibility Custom Fileds
        public IDictionary<string, EligibilityCriteria.Field> GetEligibilityFields(int assetId)
        {
            return _ecDataService.GetEligibilityFields(assetId);
        }
        #endregion

        #region Get Eligibility Regulations
        public IList<EligibilityCriteria.ECRegulation> GetEligibilityRegulation()
        {
            return _ecDataService.GetEligibilityRegulation();
        }
        #endregion

        #region Get Eligibility Types
        public IList<EligibilityCriteria.ECType> GetEligibilityType(int assetId)
        {
            return _ecDataService.GetEligibilityType(assetId);
        }
        #endregion

        #region Get Eligibility FieldInfo
        public IList<EligibilityCriteria.FieldInfo> GetEligibilityFieldInfo(int fieldId)
        {
            return _ecDataService.GetEligibilityFieldInfo(fieldId);
        }
        #endregion

        #region Save Eligibility 
        public string SaveEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes, string userName)
        {
            return _ecDataService.SaveEligibilityCriteria(eligibilityCriteriaAttributes, userName);
        }
        #endregion

        #region Amend Eligibility 
        public int AmendEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes, string userName)
        {
            return _ecDataService.AmendEligibilityCriteria(eligibilityCriteriaAttributes, userName);
        }
        #endregion

        #region Get Eligibility; for Edit
        public IList<EligibilityCriteriaDetail> GetEligibilityCriteria(int eligibilityId, int assetId)
        {
            return _ecDataService.GetEligibilityCriteria(eligibilityId, assetId);
        }
        public IList<QueryExpressionDetail> GetEligibilityCriteriaExpression(int eligibilityId)
        {
            return _ecDataService.GetEligibilityCriteriaExpression(eligibilityId);
        }
        #endregion

        public IList<EligibilityCriteriaList> GetEligibilityCriterias(int assetId, string userName)
        {
            return this._ecDataService.GetEligibilityCriterias(assetId, userName);
        }

        public int DeleteEligibility(int ecId, string userName)
        {
            return this._ecDataService.DeleteEligibility(ecId, userName);
        }

        public bool ValidateEcFields(int eligibilityId)
        {
            return this._ecDataService.ValidateEcFields(eligibilityId);
        }

        public MemoryStream GetEcPoolsReportData(int poolId, string userName)
        {
            return ExcelSheetForEcPoolsReport(this._ecDataService.GetEcPoolsReportData(poolId, userName));
        }


        #region Excel Sheet Utility
        private MemoryStream ExcelSheetForEcPoolsReport(IList<EligibilityCriteriaPoolsList> EcPoolsReport)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet_EC = workbook.Worksheets.Add($"EC-Pools");
                FillPoolEcCtReportWorksheet(EcPoolsReport, worksheet_EC);

                workbook.SaveAs(stream);
                return stream;
            }
        }

        private void FillPoolEcCtReportWorksheet(IList<EligibilityCriteriaPoolsList> EcPoolsReport, IXLWorksheet worksheet)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForEcPoolsReport())
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                columnNo++;
            }
            if (EcPoolsReport != null)
            {
                foreach (var data in EcPoolsReport)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.PoolID;
                    worksheet.Cell(currentRow, 2).Value = data.Name;
                    worksheet.Cell(currentRow, 3).Value = data.Status;
                    worksheet.Cell(currentRow, 4).Value = data.BuildDate;
                    worksheet.Cell(currentRow, 5).Value = data.CreationDate;
                    worksheet.Cell(currentRow, 6).Value = data.CreatedBy;
                    worksheet.Cell(currentRow, 7).Value = data.AuthorisationDate;
                }
            }
        }

        private List<string> GetHeaderDisplayNameForEcPoolsReport()
        {
            var itemEcPool = new EligibilityCriteriaPoolsList();
            Type type = itemEcPool.GetType();
             
            PropertyInfo[] properties = type.GetProperties();
            List<string> EcPoolsReportHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                EcPoolsReportHeader.Add(GetDisplayName(type, info, false));
            }
            return EcPoolsReportHeader;
        }

        private static String GetDisplayName(Type type, PropertyInfo info, bool hasMetaDataAttribute)
        {
            if (!hasMetaDataAttribute)
            {
                object[] attributes = info.GetCustomAttributes(typeof(DisplayAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var displayName = (DisplayAttribute)attributes[0];
                    return displayName.Name;
                }
                return info.Name;
            }
            PropertyDescriptor propDesc = TypeDescriptor.GetProperties(type).Find(info.Name, true);
            DisplayNameAttribute displayAttribute =
                propDesc.Attributes.OfType<DisplayNameAttribute>().FirstOrDefault();
            return displayAttribute != null ? displayAttribute.DisplayName : null;
        }

        #endregion


    }
}
