﻿using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.PS
{    
    public class ConcentrationService : IConcentrationService
    {
        private readonly IConcentrationDataService _ctConcentrationDataService;

        public ConcentrationService(IConcentrationDataService ctConcentrationDataService)
        {
            this._ctConcentrationDataService = ctConcentrationDataService;
        }
        public string SaveConcentration(ConcentrationTest concentrationTest, string userName)
        {
            return this._ctConcentrationDataService.SaveConcentration(concentrationTest, userName);
        }

        public int AmendConcentration(ConcentrationTest concentrationTest, string userName)
        {
            return this._ctConcentrationDataService.AmendConcentration(concentrationTest, userName);
        }

        public IList<ConcentrationTestList> GetConcentrationTestList(int assetClassId, string userName)
        {
            return this._ctConcentrationDataService.GetConcentrationTestList(assetClassId, userName);
        }

        public int DeleteConcentrationTest(int concTestId, string userName)
        {
            return this._ctConcentrationDataService.DeleteConcentrationTest(concTestId, userName);
        }
        public ConcentrationTest GetConcentrationTestByID(int concentrationTestId)
        {
            return this._ctConcentrationDataService.GetConcentrationTestByID(concentrationTestId);
        }
    }
}