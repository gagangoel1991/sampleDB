﻿namespace NW.SFP.BusinessService.PS
{
    using NW.SFP.Interface.PS;
    using NW.SFP.Message.PS;
    using System.Collections.Generic;

    public class ConcentrationReferenceLookupService : IConcentrationReferenceLookupService
    {
        private readonly IConcentrationReferenceLookupDataService _ctReferenceLookupDataService;

        public ConcentrationReferenceLookupService(IConcentrationReferenceLookupDataService ctReferenceLookupDataService)
        {
            this._ctReferenceLookupDataService = ctReferenceLookupDataService;
        }
        public ConcentrationReferenceData GetConcentrationReferenceData(int assetClassId, string userName)
        {
            return this._ctReferenceLookupDataService.GetConcentrationReferenceData(assetClassId, userName);
        }
        public List<BasicLookUpData> GetConcentrationFieldsData(string type, int assetClassId, string userName)
        {
            return this._ctReferenceLookupDataService.GetConcentrationFieldsData(type, assetClassId, userName);
        }
        public ConcentrationFieldReferenceData GetConcentrationFieldReferenceData(int fieldId, string userName)
        {
            return this._ctReferenceLookupDataService.GetConcentrationFieldReferenceData(fieldId, userName);
        }
    }
}