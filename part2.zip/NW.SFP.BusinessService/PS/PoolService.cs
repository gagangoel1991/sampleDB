﻿using ClosedXML.Excel;
using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using NW.SFP.Queue.Enum;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.IO;
using System.Linq;
using System.Reflection;

namespace NW.SFP.BusinessService.PS
{
    public class PoolService : IPoolService
    {
        private readonly IPoolDataService _poolDataService;
        private readonly IQueueSubscriberService _queueSubscriberService;

        public PoolService(IPoolDataService poolDataService, IQueueSubscriberService queueSubscriberService)
        {
            this._poolDataService = poolDataService;
            this._queueSubscriberService = queueSubscriberService;
        }

        /// <summary>
        /// This will return the List of Hypo Pool
        /// </summary>
        /// <returns></returns>
        public IList<PoolList> GetPools(int assetId, string userName)
        {
            return this._poolDataService.GetPools(assetId, userName);
        }

        public int DeletePool(int poolId, string userName)
        {
            return this._poolDataService.DeletePool(poolId, userName);
        }

        public Pool GetPoolById(int poolId, string userName)
        {
            return this._poolDataService.GetPoolById(poolId, userName);
        }

        public IList<PoolSourceDealSummary> GetPoolSourceDealSummaryById(int poolId, string userName)
        {
            return this._poolDataService.GetPoolSourceDealSummaryById(poolId, userName);
        }

        public int CreatePool(Pool pool, string userName)
        {
            return this._poolDataService.CreatePool(pool, userName);
        }
       
        public int UpdatePool(Pool pool, string userName)
        {
            return this._poolDataService.UpdatePool(pool, userName);
        }

        public IList<Pool> BuildPool(int poolId, string loggedInUserName, int assetId)
        {
            return this._poolDataService.BuildPool(poolId, loggedInUserName, assetId);
        }

        public IList<ExportAdvanceSourceData> ExportAdvanceSourceData(int poolId, string loggedInUserName, int reportTypeId, int assetClassId)
        {
            if (assetClassId == 1)
            {
                return _poolDataService.ExportAdvanceSourceData(poolId, loggedInUserName, reportTypeId);
            }
            else if (assetClassId == 2)
            {
                return _poolDataService.GeneratePoolExtractReportCB(poolId, loggedInUserName, reportTypeId);
            }

            return null;
        }

        public UploadValidationResult ValidateUploadAssets(IList<long> assets, string vintageDate, string loggedInUserName, bool isRemoveDuplicates, int AssetClassId)
        {
            UploadValidationResult uploadValidationResult = new UploadValidationResult();
            if (isRemoveDuplicates)
                assets = assets.Distinct().ToArray();

            uploadValidationResult.UploadedAssets.AddRange(assets);
            uploadValidationResult.InvalidAssets.AddRange(_poolDataService.ValidateUploadAsset(assets, vintageDate, loggedInUserName, AssetClassId));
            
            return uploadValidationResult;
        }

        public MemoryStream GenerateDrillThroughReport(int poolId, string loggedInUserName)
        {
            return _poolDataService.GenerateDrillThroughReport(poolId, loggedInUserName);
        }

        public MemoryStream GenerateDetailedReport(int poolId, string loggedInUserName)
        {
            return _poolDataService.GenerateDetailedReport(poolId, loggedInUserName);
        }

        public MemoryStream GenerateEligibilityCriteriaReportsForCB(int poolId, int reportType, string loggedInUserName)
        {
            MemoryStream reportStream = null;
            switch (reportType)
            {
                case 1:
                    reportStream = _poolDataService.GenerateIneligibilityDetailedReportCB(poolId, loggedInUserName);
                    break;

                case 2:
                    reportStream = _poolDataService.GenerateECSummaryReportCB(poolId, loggedInUserName, true);
                    break;

                case 3:
                    reportStream = _poolDataService.GenerateEligibilityDetailedReportCB(poolId, loggedInUserName);
                    break;
            }


            return reportStream;
        }

        public int ValidateDrillThroughReport(int poolId, string loggedInUserName, int assetClassId)
        {
            if (assetClassId == 2)
            {
                return _poolDataService.ValidateDrillThroughReportCB(poolId, loggedInUserName);
            }
            else
            {
                return _poolDataService.ValidateDrillThroughReport(poolId, loggedInUserName);
            }
        }

        public int ValidateEligibilityReport(int poolId, string loggedInUserName, int assetClassId)
        {
            return _poolDataService.ValidateEligibilityReportCB(poolId, loggedInUserName);
        }

        public int ValidateSubmitAndUpdatePool(SubmittedPoolData submittedPoolData, string loggedInUserName)
        {
            int validationResult = _poolDataService.ValidateSubmitAndUpdatePool(submittedPoolData, loggedInUserName);
            _queueSubscriberService.SetQueueProcessItemStatus(QueueProcessEnum.PoolSubmission.ToString(), false);
            return validationResult;
        }

        public int UpdatePoolAuthorisationStatus(int poolId, bool isRejected, string comments, string userName, DateTime ModifiedDate)
        {
            return this._poolDataService.UpdatePoolAuthorisationStatus(poolId, isRejected, comments, userName, ModifiedDate);
        }

        public IList<int> GetDependentPools(int poolId, string userName)
        {
            return this._poolDataService.GetDependentPools(poolId, userName);
        }

        public PoolValidationSummary ValidateSubmittedLoans(int poolId, bool isQueueRequired, string userName)
        {
            if (isQueueRequired)
            {
                return this._queueSubscriberService.SendPoolSubmissionToQueue(poolId, userName);
            }
            else
            {
                return this._poolDataService.ValidateSubmittedLoans(poolId, userName);
            }
        }

        public IList<BrandList> GetBrandList()
        {
            return _poolDataService.GetBrandList();
        }

        public PoolExclusionChangeImpact ValidateExclusionChangeImpact(int poolId, string userName)
        {
            return this._poolDataService.ValidateExclusionChangeImpact(poolId, userName);
        }
        public IList<string> GetPoolRegionWithHoliday(int poolId, string effectiveDate, string userName)
        {
            return this._poolDataService.GetPoolRegionWithHoliday(poolId, effectiveDate, userName);
        }

        public MemoryStream GetPoolEcAndCtReportData(int poolId, string userName, int assetClassId)
        {
            MemoryStream reportStream = null;
            if (assetClassId == 1)
            {
                reportStream = ExcelSheetForEcAndCtReport(this._poolDataService.GetPoolEcAndCtReportData(poolId, userName));
            }
            else if (assetClassId == 2)
            {
                reportStream = ExcelSheetForEcAndCtReportCB(this._poolDataService.GetPoolEcAndCtReportDataCB(poolId, userName));
            }

            return reportStream;
        }

        public string GetPoolSourceDealsById(int poolId, string userName)
        {
            return this._poolDataService.GetPoolSourceDealsById(poolId, userName);
        }

        public IList<PoolAccount> GetPoolDetailsById(int poolId, string dealId, string vintageDate, string userName)
        {
            return this._poolDataService.GetPoolDetailsById(poolId, dealId, vintageDate, userName);
        }

        public IList<LoanInclusionReason> GetPoolInclusionReasons()
        {
            return this._poolDataService.GetPoolInclusionReasons();
        }

        public int UpdatePoolAccounts(IList<PoolAccount> accounts, int poolId, string userName)
        {
            return this._poolDataService.UpdatePoolAccounts(accounts, poolId, userName);
        }

        public bool IsCurrentPoolInSubmissionQueue(int poolId)
        {
            bool status = this._queueSubscriberService.IsCurrentPoolInSubmissionQueue(poolId);
            if (_queueSubscriberService.GetCurrentPoolId() == poolId)
            {
                _queueSubscriberService.SetQueueProcessItemStatus(QueueProcessEnum.PoolSubmission.ToString(), false);
            }
            return  status;
        }

        public string GetPoolLastFlagDateById(int poolId, string userName)
        {
            return this._poolDataService.GetPoolLastFlagDateById(poolId, userName);
        }

        #region Excel Sheet Utility
        private MemoryStream ExcelSheetForEcAndCtReport(PoolEcAndCtReportData PoolEcAndCtReport)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet_EC = workbook.Worksheets.Add($"PoolECs");
                FillPoolEcCtReportWorksheet(PoolEcAndCtReport, worksheet_EC, true);

                var worksheet_CT = workbook.Worksheets.Add($"PoolCTs");
                FillPoolEcCtReportWorksheet(PoolEcAndCtReport, worksheet_CT, false);

                workbook.SaveAs(stream);
                return stream;
            }
        }

        private MemoryStream ExcelSheetForEcAndCtReportCB(PoolEcAndCtReportDataCB PoolEcAndCtReport)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet_EC = workbook.Worksheets.Add($"PoolECs");
                FillPoolEcCtReportWorksheetCB(PoolEcAndCtReport, worksheet_EC, true);

                var worksheet_CT = workbook.Worksheets.Add($"PoolCTs");
                FillPoolEcCtReportWorksheetCB(PoolEcAndCtReport, worksheet_CT, false);

                workbook.SaveAs(stream);
                return stream;
            }
        }

        private void FillPoolEcCtReportWorksheet(PoolEcAndCtReportData PoolEcAndCtReport, IXLWorksheet worksheet, bool isPoolEC)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForpoolEcCtReport(isPoolEC))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                columnNo++;
            }

            if (isPoolEC) // FOR EC
            {
                if (PoolEcAndCtReport != null && PoolEcAndCtReport.PoolEcReport != null)
                {
                    foreach (var data in PoolEcAndCtReport.PoolEcReport)
                    {
                        currentRow++;
                        worksheet.Cell(currentRow, 1).Value = data.EcName;
                        worksheet.Cell(currentRow, 2).Value = data.EcDescription; 
                        worksheet.Cell(currentRow, 3).Value = data.EcEligibilityExpression; 
                        worksheet.Cell(currentRow, 4).Value = data.EcType; 
                        worksheet.Cell(currentRow, 5).Value = data.EcTypeDescription; 
                        worksheet.Cell(currentRow, 6).Value = data.EcStatus;
                    }
                }
            }
            else // FOR CT
            {
                if (PoolEcAndCtReport != null && PoolEcAndCtReport.PoolCtReport != null)
                {
                    foreach (var data in PoolEcAndCtReport.PoolCtReport)
                    {
                        currentRow++;
                        worksheet.Cell(currentRow, 1).Value = data.CtCriteriaName;
                        worksheet.Cell(currentRow, 2).Value = data.CtDescription;
                        worksheet.Cell(currentRow, 3).Value = data.CtExpression;
                        worksheet.Cell(currentRow, 4).Value = data.CtTestType;
                        worksheet.Cell(currentRow, 5).Value = data.CtTestTypeDescription;
                        worksheet.Cell(currentRow, 6).Value = data.CtStatus;
                    }
                }
            }
        }

        private void FillPoolEcCtReportWorksheetCB(PoolEcAndCtReportDataCB PoolEcAndCtReport, IXLWorksheet worksheet, bool isPoolEC)
        {
            var currentRow = 1;

            int columnNo = 1;
            foreach (string headerName in GetHeaderDisplayNameForpoolEcCtReportCB(isPoolEC))
            {
                worksheet.Cell(currentRow, columnNo).Value = headerName;
                columnNo++;
            }

            if (isPoolEC) // FOR EC
            {
                if (PoolEcAndCtReport != null && PoolEcAndCtReport.PoolEcReport != null)
                {
                    foreach (var data in PoolEcAndCtReport.PoolEcReport)
                    {
                        currentRow++;
                        worksheet.Cell(currentRow, 1).Value = data.EcName;
                        worksheet.Cell(currentRow, 2).Value = data.EcDescription;
                        worksheet.Cell(currentRow, 3).Value = data.EcEligibilityExpression;
                        worksheet.Cell(currentRow, 4).Value = data.EcType;
                        worksheet.Cell(currentRow, 5).Value = data.EcTypeDescription;
                        worksheet.Cell(currentRow, 6).Value = data.EcStatus;
                    }
                }
            }
            else // FOR CT
            {
                if (PoolEcAndCtReport != null && PoolEcAndCtReport.PoolCtReport != null)
                {
                    foreach (var data in PoolEcAndCtReport.PoolCtReport)
                    {
                        currentRow++;
                        worksheet.Cell(currentRow, 1).Value = data.CtCriteriaName;
                        worksheet.Cell(currentRow, 2).Value = data.CtDescription;
                        worksheet.Cell(currentRow, 3).Value = data.CtExpression;
                        worksheet.Cell(currentRow, 4).Value = data.CtSuperSetExpression;
                        worksheet.Cell(currentRow, 5).Value = data.CtTestType;
                        worksheet.Cell(currentRow, 6).Value = data.CtTestTypeDescription;
                        worksheet.Cell(currentRow, 7).Value = data.CtStatus;
                    }
                }
            }
        }

        private List<string> GetHeaderDisplayNameForpoolEcCtReport(bool isPoolEC)
        {
            var itemEC = new PoolEcReport();
            Type type = itemEC.GetType();

            if (!isPoolEC)
            {
               var itemCT = new PoolCtReport();
                type = itemCT.GetType();
            }
            
            PropertyInfo[] properties = type.GetProperties();
            List<string> EcCtReportHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                EcCtReportHeader.Add(GetDisplayName(type, info, false));
            }
            return EcCtReportHeader;
        }

        private List<string> GetHeaderDisplayNameForpoolEcCtReportCB(bool isPoolEC)
        {
            var itemEC = new PoolEcReportCB();
            Type type = itemEC.GetType();

            if (!isPoolEC)
            {
                var itemCT = new PoolCtReportCB();
                type = itemCT.GetType();
            }

            PropertyInfo[] properties = type.GetProperties();
            List<string> EcCtReportHeader = new List<string>();
            foreach (PropertyInfo info in properties)
            {
                EcCtReportHeader.Add(GetDisplayName(type, info, false));
            }
            return EcCtReportHeader;
        }

        private static String GetDisplayName(Type type, PropertyInfo info, bool hasMetaDataAttribute)
        {
            if (!hasMetaDataAttribute)
            {
                object[] attributes = info.GetCustomAttributes(typeof(DisplayAttribute), false);
                if (attributes != null && attributes.Length > 0)
                {
                    var displayName = (DisplayAttribute)attributes[0];
                    return displayName.Name;
                }
                return info.Name;
            }
            PropertyDescriptor propDesc = TypeDescriptor.GetProperties(type).Find(info.Name, true);
            DisplayNameAttribute displayAttribute =
                propDesc.Attributes.OfType<DisplayNameAttribute>().FirstOrDefault();
            return displayAttribute != null ? displayAttribute.DisplayName : null;
        }

        #endregion

    }   
}