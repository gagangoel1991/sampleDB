﻿using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.PS;
using NW.SFP.Message.PS;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.PS
{
    public class FieldManagementService : IFieldManagementService
    {
        #region Object Declarations and Constructor
        private readonly IFieldManagementDataService _fieldDataService;

        public FieldManagementService(IFieldManagementDataService fieldDataService)
        {
            this._fieldDataService = fieldDataService;
        }
        #endregion

        #region Get Fields Data
        public IDictionary<string, FieldManagement.FieldInfo> GetFieldsData(int assetId, string fieldType)
        {
            return _fieldDataService.GetFieldsData(assetId, fieldType);
        }
        #endregion

        #region Get Fields Data Type
        public IList<FieldManagement.FieldDataType> GetFieldsDataType()
        {
            return _fieldDataService.GetFieldsDataType();
        }
        public IList<BasicLookUpData> GetArithmeticOperators()
        {
            return _fieldDataService.GetArithmeticOperators();
        }
        public IList<FieldFunction> GetFunctions(string loggedInUserName)
        {
            return _fieldDataService.GetFunctions(loggedInUserName);
        }
        public FieldFunction GetFunctionDetail(int functionId, string loggedInUserName)
        {
            return _fieldDataService.GetFunctionDetail(functionId, loggedInUserName);
        }
        #endregion

        #region Save Custom Field data
        public string SaveCustomField(FieldManagement.CustomFieldAttribute customFieldDetail, string userName)
        {
            return _fieldDataService.SaveCustomField(customFieldDetail, userName);
        }
        #endregion

        #region Amend Custom Field 
        public int AmendCustomField(FieldManagement.CustomFieldAttribute customFieldAttribute, string userName)
        {
            return _fieldDataService.AmendCustomField(customFieldAttribute, userName);
        }
        #endregion

        #region Get Field Data
        public FieldManagement.CustomFieldDetail GetCustomFieldDetail(int fieldId)
        {
            return _fieldDataService.GetCustomFieldDetail(fieldId);
        }
        #endregion
        public IList<Field> GetFields(int assetId, string loggedInUserName)
        {
            return _fieldDataService.GetFields(assetId, loggedInUserName);
        }
        
        public int DeleteField(int fieldId, string loggedInUserName)
        {
            return _fieldDataService.DeleteField(fieldId, loggedInUserName);
        }

        public IList<EligibilityCriteriaAttributes> GetECByField(int fieldId, string loggedInUserName)
        {
            return _fieldDataService.GetECByField(fieldId, loggedInUserName);
        }

        public int UpdateECsOnFieldChange(FieldRename fieldNameChangeModel, string loggedInUserName)
        {
            return _fieldDataService.UpdateECsOnFieldChange(fieldNameChangeModel, loggedInUserName);
        }
    }
}
