﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using NW.SFP.Interface.CB;
using NW.SFP.Message.CB;
using NW.SFP.Message.Corp;
using System.Collections.Generic;
using System.IO;

namespace NW.SFP.BusinessService.CB
{
    public class DataCorrectionBusinessService : IDataCorrectionBusinessService
    {
        private readonly IDataCorrectionDataService _dataCorrectionDataService;
        public DataCorrectionBusinessService(IDataCorrectionDataService dataCorrectionDataService)
        {
            _dataCorrectionDataService = dataCorrectionDataService;
        }
        public IList<DataCorrectionAttribute> GetDataCorrectionAttribute(int entityId, string userName)
        {
            return _dataCorrectionDataService.GetDataCorrectionAttribute(entityId, userName);
        }
        public DataCorrectionDetail GetDataCorrectionDetail(DataCorrectionBasicInfo basicInfo, string userName)
        {
            return _dataCorrectionDataService.GetDataCorrectionDetail(basicInfo, userName);
        }
        public string SaveDataCorrection(DataCorrectionBasicInfo basicInfo, string userName)
        {
            return _dataCorrectionDataService.SaveDataCorrection(basicInfo, userName);
        }

        public IList<UpdateOverrideListEntity> GetUpdateOverrideList(string userName, int dealId, string AsAtDate)
        {
            return _dataCorrectionDataService.GetUpdateOverrideList(userName, dealId, AsAtDate);
        }

        public MemoryStream getLinkageAuditReportData(int dealId, string AsAtDate, string userName)
        {
            return _dataCorrectionDataService.getLinkageAuditReportData(dealId, AsAtDate, userName);
        }

        public MemoryStream getFacilityOverrideData(int dealId, string AsAtDate, string userName, int isTemplate)
        {
            return _dataCorrectionDataService.getFacilityOverrideData(dealId, AsAtDate,userName, isTemplate);
        }
        public MemoryStream getSecurityOverrideData(int dealId, string AsAtDate, string userNames, int isTemplate)
        {
            return _dataCorrectionDataService.getSecurityOverrideData(dealId, AsAtDate, userNames, isTemplate);
        }


        public int saveOverrideData(int dealId, string AsAtDate, string userName, IFormFileCollection files,
            List<FacilitySecurityLink> LinkList, string isListEdited, IFormCollection formCollection,
           out List<Dictionary<string, string>> ErrorExcel, out List<string> LstcolumnNames, out string ErrorEntity)
        {
            return _dataCorrectionDataService.saveOverrideData(dealId, AsAtDate, userName, files, LinkList, isListEdited,
                formCollection, out ErrorExcel, out LstcolumnNames, out ErrorEntity);
        }

        public MemoryStream GetOverrideAuditTrailData(int dealId, string entityType, string vintageDate, string userName)
        {
            return _dataCorrectionDataService.GetOverrideAuditTrailData(dealId, entityType, vintageDate, userName);
        }

        public IList<string> GetOverrideVintageDateList(int dealId, string userName)
        {
            return _dataCorrectionDataService.GetOverrideVintageDateList(dealId, userName);
        }

        public MemoryStream getFacilityComparisionData(int DealIrConfigId, int dealId, string AsAtDate,
            string PreviousReportingDate, int AnyDiffFlag, string userName)
        {
            return _dataCorrectionDataService.getFacilityComparisionData(DealIrConfigId,dealId, AsAtDate, 
                PreviousReportingDate, AnyDiffFlag, userName);
        }
        public MemoryStream getSecurityComparisionData(int DealIrConfigId, int dealId, string AsAtDate,
            string PreviousReportingDate, int AnyDiffFlag, string userName)
        {
            return _dataCorrectionDataService.getSecurityComparisionData(DealIrConfigId,dealId, AsAtDate, 
                PreviousReportingDate, AnyDiffFlag, userName);
        }

        public string validatePoolAndOverrideAuthorize(int callFromOverrideAuth, int id)
        {
            return _dataCorrectionDataService.validatePoolAndOverrideAuthorize(callFromOverrideAuth, id);
        }

        public IList<FacilitySecurityLinkEntity> getFacilitySecurityLinkStatus(string userName, string AsAtDate, string ComparisonDate, int dealId)
        {
            return _dataCorrectionDataService.getFacilitySecurityLinkStatus(userName, AsAtDate, ComparisonDate, dealId);
        }

        public string resetOverrideData(int DealOverrideParentId, string Entity)
        {
            return _dataCorrectionDataService.resetOverrideData(DealOverrideParentId, Entity);
        }

    }
}

