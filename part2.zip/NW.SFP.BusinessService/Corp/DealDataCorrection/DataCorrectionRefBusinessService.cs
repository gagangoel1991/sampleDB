﻿using NW.SFP.Interface.CB;
using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CB
{
    public class DataCorrectionRefBusinessService : IDataCorrectionRefBusinessService
    {
        private readonly IDataCorrectionRefDataService _dataCorrectionDataService;
        public DataCorrectionRefBusinessService(IDataCorrectionRefDataService dataCorrectionDataService)
        {
            _dataCorrectionDataService = dataCorrectionDataService;
        }
        public DataCorrectionReference GetDataCorrectionReferenceData(string userName)
        {
            return _dataCorrectionDataService.GetDataCorrectionReferenceData(userName);
        }
    }
}