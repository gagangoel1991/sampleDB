﻿using NW.SFP.Interface.CB;
using NW.SFP.Message.CB;
using System.Collections.Generic;

namespace NW.SFP.BusinessService.CB
{
    public class LossManagementService : ILossManagementService
    {
        private readonly ILossManagementDataService _lossManagementDataService;
        public LossManagementService(ILossManagementDataService lossManagementDataService)
        {
            _lossManagementDataService = lossManagementDataService;
        }

        public IList<LossManagementList> GetLossManagementList(string userName)
        {
            return _lossManagementDataService.GetLossManagementList(userName);
        }

        public LossManagementRefData GetLossManagementRefData(string userName)
        {
            return _lossManagementDataService.GetLossManagementRefData(userName);
        }

        public IList<LossManagementList> GetLossUpdatedData(string userName)
        {
            return _lossManagementDataService.GetLossUpdatedData(userName);
        }

        public int UploadWriteOffFile(IList<WriteOffData> writeOffData, string userName)
        {
            return _lossManagementDataService.UploadWriteOffFile(writeOffData, userName);
        }

        public DefaultDateData GetDefaultDateData(DefaultDateData defaultDateParam, string userName)
        {
            return _lossManagementDataService.GetDefaultDateData(defaultDateParam, userName);
        }

        public int UpdateLossDetails(LossManagementList lossManagementList, string userName)
        {
            return _lossManagementDataService.UpdateLossDetails(lossManagementList, userName);
        }

        public decimal? LoadAllocatedLoss(int lossManagementId, string userName)
        {
            return _lossManagementDataService.LoadAllocatedLoss(lossManagementId, userName);
        }
    }
}