﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using NW.SFP.Interface.Upload;
using NW.SFP.Message.Core;
using NW.SFP.Message.Upload;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace NW.SFP.BusinessService.Upload
{
    public class FileUploadInfoBusinessService : IFileUploadInfoBusinessService
    {
        private readonly IFileUploadInfoDataService _fileInfoDataService; 
        private readonly IOptions<AssetWiseFileCopyPaths> _assetWiseFileCopyPaths;
        public FileUploadInfoBusinessService(IFileUploadInfoDataService fileInfoDataService, IOptions<AssetWiseFileCopyPaths> assetWiseFileCopyPaths)
        {
            _fileInfoDataService = fileInfoDataService;
            _assetWiseFileCopyPaths = assetWiseFileCopyPaths;
        }

        public bool CheckFileExists(string fileName, string selectedAssetClassCode)
        {
            var sharedPath = GetCopyFileSharedPath(selectedAssetClassCode);
            return _fileInfoDataService.CheckFileExists(fileName, sharedPath);
        }

        public string GetCopyFileSharedPath(string selectedAssetClassCode)
        {
            var prop = _assetWiseFileCopyPaths.Value.GetType().GetProperty(selectedAssetClassCode);
            if (prop != null)
                return prop.GetValue(_assetWiseFileCopyPaths.Value, null).ToString();

            return string.Empty;
        }

        public IList<FileUploadInfo> GetFileUploadReferenceData(string userName, string userAdGroupName, int assetClassId)
        {
            return _fileInfoDataService.GetFileUploadReferenceData(userName, userAdGroupName, assetClassId);
        }

        public IList<UploadFileWorflowState> GetFileWorkflowState(int fileInfoId, string loggedInUserName)
        {
            return _fileInfoDataService.GetFileWorkflowState(fileInfoId, loggedInUserName);
        }

        public IList<UploadETLMessage> GetUploadETLMessages(int fileInfoId, string loggedInUserName)
        {
            return _fileInfoDataService.GetUploadETLMessages(fileInfoId, loggedInUserName);
        }

        public UploadFileStageData LoadStagingData(int fileInfoId, string loggedInUserName)
        {
            return _fileInfoDataService.LoadStagingData(fileInfoId, loggedInUserName);
        }

        public bool MoveFile(string filename, string selectedAssetClassCode)
        {
            var sharedPath = GetCopyFileSharedPath(selectedAssetClassCode);
            return _fileInfoDataService.MoveFile(filename, sharedPath);
        }

        public bool SetFileWorkflowState(int fileInfoId, string fileStatus, string loggedInUserName)
        {
            return _fileInfoDataService.SetFileWorkflowState(fileInfoId, fileStatus, loggedInUserName);
        }

        public Task<FileUploadResult> UploadFile(IFormFile file, int fileId, string userName)
        {
            return _fileInfoDataService.UploadFile(file, fileId, userName);
        }
    }
}