﻿using NW.SFP.Interface.Upload;
using NW.SFP.Interface.Upload.BusinessService;
using NW.SFP.Message.Upload;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.BusinessService.Upload
{
    public class FileUploadUtilityBusinessService : IFileUploadUtilityBusinessService
    {
        private readonly IFileUploadUtilityDataService _objFileUploadUtilityDataService;

        public FileUploadUtilityBusinessService(IFileUploadUtilityDataService objFileUploadUtilityDataService)
        {
            _objFileUploadUtilityDataService = objFileUploadUtilityDataService;

        }

        public int DeleteFileUploadUtilityDetails(int FileUploadUtilityDetailsId, string UserName)
        {
            return _objFileUploadUtilityDataService.DeleteFileUploadUtilityDetails(FileUploadUtilityDetailsId, UserName);
        }

        public FileUploadUtilityConfiguration GetFileUploadUtilityConfiguration(int FileUploadUtilityConfigurationId, string UserName)
        {
            return _objFileUploadUtilityDataService.GetFileUploadUtilityConfiguration(FileUploadUtilityConfigurationId, UserName);
        }

        public IList<FileUploadUtilityDetailsEntity> GetFileUploadUtilityDetails(int FileUploadUtilityConfigurationId, int ReferenceId, string UserName)
        {
            return _objFileUploadUtilityDataService.GetFileUploadUtilityDetails(FileUploadUtilityConfigurationId, ReferenceId, UserName);
        }

        public int SaveFileUploadUtilityDetails(FileUploadUtilityAddEntity objFileUploadUtilityAddEntity)
        {
            return _objFileUploadUtilityDataService.SaveFileUploadUtilityDetails(objFileUploadUtilityAddEntity);
        }
    }
}
