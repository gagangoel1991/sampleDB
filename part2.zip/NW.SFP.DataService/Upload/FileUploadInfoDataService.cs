﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Upload;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Message.Core;
using NW.SFP.Message.Upload;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.IO;
using System.Threading.Tasks;

namespace NW.SFP.DataService.Upload
{
    public class FileUploadInfoDataService : IFileUploadInfoDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;
        private readonly IOptions<UploadSettings> _uploadSettings;
        private readonly IOptions<DBConnectionSettings> _dbConnectionSettings;

        public FileUploadInfoDataService(IOptions<DataServiceSettings> settings, IOptions<UploadSettings> uploadSettings, IOptions<DBConnectionSettings> dbConnectionSettings)
        {
            _settings = settings;
            _uploadSettings = uploadSettings;
            _dbConnectionSettings = dbConnectionSettings;
        }

        public bool CheckFileExists(string fileName, string sharedPath)
        {
            var filePathSource = Path.Combine(sharedPath, fileName);
            return File.Exists(filePathSource);
        }

        public IList<FileUploadInfo> GetFileUploadReferenceData(string userName, string userAdGroupName, int assetClassId)
        {
            IList<FileUploadInfo> fileUploadInfoList = new List<FileUploadInfo>();
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_GetReferenceData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.AssetClassIdInput, assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    while (resultReader.Read())
                    {
                        if (resultReader.HasRows)
                        {
                            //Get FileInfo Data
                            fileUploadInfoList.Add
                            (
                                new FileUploadInfo()
                                {
                                    FileInfoId = Utility.GetInt(resultReader["FileInfoId"]),
                                    FileName = Utility.GetString(resultReader["FileName"]),
                                    FileNamePattern = Utility.GetString(resultReader["FileNamePattern"]),
                                    Description = Utility.GetString(resultReader["Description"]),
                                    FileType = Utility.GetString(resultReader["FileType"]),
                                    ColumnCount = Utility.GetInt(resultReader["ColumnCount"]),
                                    TabCount = Utility.GetInt(resultReader["TabCount"]),
                                    SizeLimit = Utility.GetInt(resultReader["SizeLimit"]),
                                    AuthWorkflowRequired = Utility.GetBool(resultReader["AuthWorkflowRequired"]),
                                    EnableCopyOption = Utility.GetBool(resultReader["EnableCopyOption"]),
                                    TemplateName = Utility.GetString(resultReader["TemplateName"])
                                }
                            );
                        }
                    }
                }
            }
            return fileUploadInfoList;
        }

        public IList<UploadFileWorflowState> GetFileWorkflowState(int fileInfoId, string loggedInUserName)
        {
            var uploadFileWorflowStates = new List<UploadFileWorflowState>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_GetUploadFileWorkflowState, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileInfoId, fileInfoId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    while (resultReader.Read())
                    {
                        if (resultReader.HasRows)
                        {
                            uploadFileWorflowStates.Add
                            (
                                new UploadFileWorflowState()
                                {
                                    Status = Utility.GetString(resultReader["Status"]),
                                    UploadedBy = Utility.GetString(resultReader["UploadedBy"]),
                                    UploadedDate = Utility.GetDateTime(resultReader["UploadedDate"]),
                                    RequestedBy = Utility.GetString(resultReader["RequestedBy"]),
                                    RequestedDate = Utility.GetDateTime(resultReader["RequestedDate"]),
                                    AuthorisedBy = Utility.GetString(resultReader["AuthorizedBy"]),
                                    AuthorisationDate = Utility.GetDateTime(resultReader["AuthorizedDate"]),
                                    InModelDate = Utility.GetDateTime(resultReader["InModelDate"]),
                                }
                            );
                        }
                    }
                }
            }
            return uploadFileWorflowStates;
        }

        public UploadFileStageData LoadStagingData(int fileInfoId, string loggedInUserName)
        {
            var resultSet = new UploadFileStageData();
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_LoadStaggingData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileInfoId, fileInfoId);
                SqlParameter cmdout = new SqlParameter
                {
                    ParameterName = DbConstants.DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdout);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    var isFirstRow = true;
                    while (resultReader.Read())
                    {
                        if (resultReader.HasRows)
                        {
                            //Construct Stage Date table.
                            dynamic stageData = new ExpandoObject();
                            for (int i = 0; i < resultReader.FieldCount; i++)
                            {
                                var columnName = resultReader.GetName(i);
                                if (isFirstRow)
                                    resultSet.ColumnInfo.Add(new StageDataColumnInfo()
                                    {
                                        ColumnName = columnName,
                                        ColumnType = resultReader.GetFieldType(i).FullName
                                    });

                                ((IDictionary<string, object>)stageData)[columnName] = resultReader.GetValue(i);
                            }
                            resultSet.StageData.Add(stageData);
                            isFirstRow = false;
                        }
                    }
                    if (cmdout != null && Convert.ToInt32(cmdout.Value) == -1)
                        return null;
                }
            }
            return resultSet;
        }

        public bool MoveFile(string filename, string sharedPath)
        {
            var decodedFilename = Uri.UnescapeDataString(filename);

            var filePathSource = Path.Combine(sharedPath, decodedFilename);

            var filePathDestination = Path.Combine(_uploadSettings.Value.UploadPath, decodedFilename);

            File.Move(filePathSource, filePathDestination);

            return true;
        }

        public bool SetFileWorkflowState(int fileInfoId, string fileStatus, string loggedInUserName)
        {
            if (fileStatus.ToLower().Equals("authorise"))
            {
                // update the status in the databse 
                SetFileUploadStatus(fileInfoId, fileStatus, loggedInUserName);

                var uploadFileWorkflowConfig = GetFileWorkflowConfig(fileInfoId, loggedInUserName);
                if (uploadFileWorkflowConfig != null && !string.IsNullOrEmpty(uploadFileWorkflowConfig.PublishFileName))
                {
                    var filePathSource = Path.Combine(_uploadSettings.Value.UploadPath, uploadFileWorkflowConfig.PublishFileName);
                    string Content = "Initiator=" + loggedInUserName + Environment.NewLine;
                    File.WriteAllText(filePathSource, Content);
                }
                else if (uploadFileWorkflowConfig != null && !string.IsNullOrEmpty(uploadFileWorkflowConfig.ModelProcName))
                {
                    WorkflowUploadBuildModel(fileInfoId, loggedInUserName);
                    SetFileUploadStatus(fileInfoId, "PUBLISH", loggedInUserName);
                }

            }
            else
            {
                SetFileUploadStatus(fileInfoId, fileStatus, loggedInUserName);
            }
            return true;
        }

        public async Task<FileUploadResult> UploadFile(IFormFile file, int fileId, string userName)
        {
            this.StageUploadedDataInstantly(file, fileId, userName);
            dynamic result = null;
            string filePath = _uploadSettings.Value.UploadPath;

            if (file.Length > 0)
            {
                using (var stream = new FileStream(Path.Combine(filePath, file.FileName), FileMode.Create))
                {
                    Task task = Task.Run(() => file.CopyToAsync(stream));

                    task.Wait();
                    result = new FileUploadResult() { Name = file.FileName, Size = file.Length, Path = filePath };
                }
            }
            // Here change the status of the file 
            SetFileUploadStatus(fileId, "QUEUE", userName);
            return result;
        }

        private void StageUploadedDataInstantly(IFormFile file, int fileId, string userName)
        {
            // Workaround -- This has just been done for NWM specific requirement for instant
            //staging of data and is a workaround for the time being. The data will be golden sourced
            // in SFP eventually. This approach is not the recommended processing approach. MPUI
            // is the right architectural upload processing approach, please stick to that.
            if (fileId == DbConstants.AssetRegisterFileInfoId)
            {
                var stream = file.OpenReadStream();
                var workbook = new XLWorkbook(stream);
                var nonEmptyDataRows = workbook.Worksheets.Worksheet("Asset_Register").RowsUsed();
                var nonEmptyDataColumns = workbook.Worksheets.Worksheet("Asset_Register").LastColumnUsed().ColumnNumber();

                DataTable dataTable = new DataTable();
                dataTable.Columns.Add(DbConstants.DbColumnPROrFCN, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCCY, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCIS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTradeAllocated, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnPercentAllocated, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSystemLoadDate, typeof(DateTime));
                dataTable.Columns.Add(DbConstants.DbColumnAsAtDate, typeof(string));
                dataTable.Columns[DbConstants.DbColumnSystemLoadDate].DefaultValue = DateTime.Now;
                dataTable.Columns[DbConstants.DbColumnAsAtDate].DefaultValue = DateTime.Now.ToString("yyyyMMdd");

                foreach (var dataRow in nonEmptyDataRows)
                {
                    // Ignore Header row
                    if (dataRow.RowNumber() >= 2)
                    {
                        DataRow row = dataTable.NewRow();
                        for (int cellCount = 1; cellCount <= nonEmptyDataColumns; cellCount++)
                        {
                            row[cellCount - 1] = dataRow.Cell(cellCount).Value;
                        }
                        dataTable.Rows.Add(row);
                    }
                }

                BulkCopyDataTable(dataTable, DbConstants.DbTableNWMStaticFileAssetRegister);

                // This is required because AssetRegister data updates also need to be captured in Securitisation
                // NWMStaticFile_AssetRegister table for instant data reflection in reporting requirement
                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_AssetRegisterMerge, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.ExecuteNonQuery();
                }
            }

            if (fileId == DbConstants.GearsStaticFileInfoId)
            {
                var stream = file.OpenReadStream();
                var workbook = new XLWorkbook(stream);
                var nonEmptyDataRows = workbook.Worksheets.Worksheet("Secured Liability Attributes").RowsUsed();
                var nonEmptyDataColumns = workbook.Worksheets.Worksheet("Secured Liability Attributes").LastColumnUsed().ColumnNumber();

                DataTable dataTable = new DataTable();
                dataTable.Columns.Add(DbConstants.DbColumnSECUREDLIABILITYNAME, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSERIES, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnISIN, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCOLLATERALASSETCOMPANYNUCLEUSID, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnFORMATColumn, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnMETHOD, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCOLLATERALISATIONTYPE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnLIABILITYCCY, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnISSUESIZENATIVECCY, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSCHEDULEDMATURITY, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCOLLATERALISATIONPERCENT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnINDICATIVEOVERCOLLPERCENT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnACTIVETRADE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTRADEGROUP, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnVANDRA, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRUBIXIDENTIFIER, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnMTASPV, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnMTANWM, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnREPORTINGTEMPLATE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSystemLoadDate, typeof(DateTime));
                dataTable.Columns.Add(DbConstants.DbColumnAsAtDate, typeof(string));
                dataTable.Columns[DbConstants.DbColumnSystemLoadDate].DefaultValue = DateTime.Now;
                dataTable.Columns[DbConstants.DbColumnAsAtDate].DefaultValue = DateTime.Now.ToString("yyyyMMdd");

                foreach (var dataRow in nonEmptyDataRows)
                {
                    if (dataRow.RowNumber() >= 2)
                    {
                        DataRow row = dataTable.NewRow();
                        for (int cellCount = 1; cellCount <= nonEmptyDataColumns; cellCount++)
                        {
                          row[cellCount - 1] = dataRow.Cell(cellCount).Value;
                        }
                        row[DbConstants.DbColumnSCHEDULEDMATURITY] = row[DbConstants.DbColumnSCHEDULEDMATURITY] == null ? row[DbConstants.DbColumnSCHEDULEDMATURITY] : 
                                                                     (Convert.ToDateTime(row[DbConstants.DbColumnSCHEDULEDMATURITY].ToString())).ToString("MM/dd/yyyy");
                        dataTable.Rows.Add(row);
                    }
                }

                BulkCopyDataTable(dataTable, DbConstants.DbTableNWMStaticFileSecuredLiabilityAttributes);

                // SP Statics Data Staging
                nonEmptyDataRows = workbook.Worksheets.Worksheet("SP Statics").RowsUsed();
                nonEmptyDataColumns = workbook.Worksheets.Worksheet("SP Statics").LastColumnUsed().ColumnNumber();

                dataTable = new DataTable();
                dataTable.Columns.Add(DbConstants.DbColumnPRISMID, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnPROJECTNAME, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCOUNTRYOFCOLLATERAL, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnASSETTYPEMB, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRATINGSOURCE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnISCONDUIT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnFORMAT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRATINGSP, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRATINGMD, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRATINGFT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRATINGDBRS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnRATINGARC, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnPRECLEAREDMEDIO, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnPRECLEARABLEMEDIO, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSystemLoadDate, typeof(DateTime));
                dataTable.Columns.Add(DbConstants.DbColumnAsAtDate, typeof(string));
                dataTable.Columns[DbConstants.DbColumnSystemLoadDate].DefaultValue = DateTime.Now;
                dataTable.Columns[DbConstants.DbColumnAsAtDate].DefaultValue = DateTime.Now.ToString("yyyyMMdd");

                foreach (var dataRow in nonEmptyDataRows)
                {
                    //for row number check
                    if (dataRow.RowNumber() >= 2)
                    {
                        DataRow row = dataTable.NewRow();
                        for (int cellCount = 1; cellCount <= nonEmptyDataColumns; cellCount++)
                        {
                            row[cellCount - 1] = dataRow.Cell(cellCount).Value;
                        }
                        dataTable.Rows.Add(row);
                    }
                }

                BulkCopyDataTable(dataTable, DbConstants.DbTableNWMStaticFileSPStatics);

                // Fund Financing & Other Statics Data Staging
                nonEmptyDataRows = workbook.Worksheets.Worksheet("Fund Financing & Other Statics").RowsUsed();
                nonEmptyDataColumns = workbook.Worksheets.Worksheet("Fund Financing & Other Statics").LastColumnUsed().ColumnNumber();

                dataTable = new DataTable();
                dataTable.Columns.Add(DbConstants.DbColumnPRISMID, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnLAW, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTYPE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSPONSOR, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSystemLoadDate, typeof(DateTime));
                dataTable.Columns.Add(DbConstants.DbColumnAsAtDate, typeof(string));
                dataTable.Columns[DbConstants.DbColumnSystemLoadDate].DefaultValue = DateTime.Now;
                dataTable.Columns[DbConstants.DbColumnAsAtDate].DefaultValue = DateTime.Now.ToString("yyyyMMdd");

                foreach (var dataRow in nonEmptyDataRows)
                {
                    if (dataRow.RowNumber() >= 2)
                    {
                        DataRow row = dataTable.NewRow();
                        for (int cellCount = 1; cellCount <= nonEmptyDataColumns; cellCount++)
                        {
                            row[cellCount - 1] = dataRow.Cell(cellCount).Value;
                        }
                        dataTable.Rows.Add(row);
                    }
                }

                BulkCopyDataTable(dataTable, DbConstants.DbTableNWMStaticFileFundFinancingAndOtherStatics);

                // FI Portfolio Statics Data staging
                nonEmptyDataRows = workbook.Worksheets.Worksheet("FI Portfolio Statics").RowsUsed();
                nonEmptyDataColumns = workbook.Worksheets.Worksheet("FI Portfolio Statics").LastColumnUsed().ColumnNumber();

                dataTable = new DataTable();
                dataTable.Columns.Add(DbConstants.DbColumnFACILITYID, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCLIENTCLASSIFICATION, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSENIORITYRANK, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnNORESTRICTIONCONFIDENTIALITY, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnGOVERNINGLAW, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSystemLoadDate, typeof(DateTime));
                dataTable.Columns.Add(DbConstants.DbColumnAsAtDate, typeof(string));
                dataTable.Columns[DbConstants.DbColumnSystemLoadDate].DefaultValue = DateTime.Now;
                dataTable.Columns[DbConstants.DbColumnAsAtDate].DefaultValue = DateTime.Now.ToString("yyyyMMdd");

                foreach (var dataRow in nonEmptyDataRows)
                {
                    //int totalCells = dataRow.CellCount();
                    //for row number check
                    if (dataRow.RowNumber() >= 2)
                    {
                        DataRow row = dataTable.NewRow();
                        for (int cellCount = 1; cellCount <= nonEmptyDataColumns; cellCount++)
                        {
                            row[cellCount - 1] = dataRow.Cell(cellCount).Value;
                        }
                        dataTable.Rows.Add(row);
                    }
                }

                BulkCopyDataTable(dataTable, DbConstants.DbTableNWMStaticFileFIPortfolioStatics);

                // Encumberance Method Statics sheet data staging
                nonEmptyDataRows = workbook.Worksheets.Worksheet("Encumberance Method Statics").RowsUsed();
                nonEmptyDataColumns = workbook.Worksheets.Worksheet("Encumberance Method Statics").LastColumnUsed().ColumnNumber();

                dataTable = new DataTable();
                dataTable.Columns.Add(DbConstants.DbColumnFACILITYID, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnDOTELIGIBLE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnDOTRECORDDATE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnDOTCONTACT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnDOTCOMMENTS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnECBELIGIBLE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnECBRECORDDATE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnECBCONTACT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnECBCOMMENTS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnNOBORROWERSETOFF, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnCONTRACTLAW, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnW8SENT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnW8SENTDATE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnW8SENDER, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTAXELIGIBILITYOVERRIDE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTAXRECORDDATE, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTAXCONTACT, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnTAXCOMMENTS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnFACILITYWARNINGS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnELIGIBILITYCOMMENTS1, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnELIGIBILITYCOMMENTS2, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnELIGIBILITYCOMMENTS3, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnFACILITYENCUMBEREDOUTSIDEPROCESS, typeof(string));
                dataTable.Columns.Add(DbConstants.DbColumnSystemLoadDate, typeof(DateTime));
                dataTable.Columns.Add(DbConstants.DbColumnAsAtDate, typeof(string));
                dataTable.Columns[DbConstants.DbColumnSystemLoadDate].DefaultValue = DateTime.Now;
                dataTable.Columns[DbConstants.DbColumnAsAtDate].DefaultValue = DateTime.Now.ToString("yyyyMMdd");

                foreach (var dataRow in nonEmptyDataRows)
                {
                    //int totalCells = dataRow.CellCount();
                    //for row number check
                    if (dataRow.RowNumber() >= 2)
                    {
                        DataRow row = dataTable.NewRow();
                        for (int cellCount = 1; cellCount <= nonEmptyDataColumns; cellCount++)
                        {
                            row[cellCount - 1] = dataRow.Cell(cellCount).Value;
                        }
                        dataTable.Rows.Add(row);
                    }
                }

                BulkCopyDataTable(dataTable, DbConstants.DbTableNWMStaticFileEncumberanceMethodStatics);
            }

        }

        private void BulkCopyDataTable(DataTable dt, string destinationTableName)
        {
            using (var conn = new SqlConnection(this._dbConnectionSettings.Value.ConnectionString_Staging))
            using (var bulkCopy = new SqlBulkCopy(conn))
            {
                conn.Open();

                //First, truncate table before BulkLoad
                using (SqlCommand command = new SqlCommand("DELETE FROM " + destinationTableName, conn))
                {
                    command.ExecuteNonQuery();
                }

                // my DataTable column names match my SQL Column names, so I simply made this loop. However if your column names don't match, just pass in which datatable name matches the SQL column name in Column Mappings
                foreach (DataColumn col in dt.Columns)
                {
                    bulkCopy.ColumnMappings.Add(col.ColumnName, col.ColumnName);
                }

                bulkCopy.BatchSize = 1000;
                bulkCopy.BulkCopyTimeout = 180;
                bulkCopy.NotifyAfter = 1000;
                bulkCopy.DestinationTableName = destinationTableName;
                bulkCopy.WriteToServer(dt);
            }
        }


        #region private actions
        private void SetFileUploadStatus(int fileInfoId, string fileStatus, string loggedInUserName)
        {
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_SetUploadFileWorkflowState, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileInfoId, fileInfoId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileStatus, fileStatus);
                cmd.CommandTimeout = 0;

                cmd.ExecuteNonQuery();
            }
        }
        private UploadFileWorkflowConfig GetFileWorkflowConfig(int fileInfoId, string loggedInUserName)
        {
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_GetFileWorkflowConfig, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileInfoId, fileInfoId);

                using (SqlDataReader resultReader = cmd.ExecuteReader())
                {
                    while (resultReader.Read())
                    {
                        if (resultReader.HasRows)
                        {
                            return new UploadFileWorkflowConfig()
                            {
                                ModelProcName = Utility.GetString(resultReader["ModelProcName"]),
                                PublishFileName = Utility.GetString(resultReader["PublishFileName"])
                            };
                        }
                    }
                }
            }
            return null;
        }
        #endregion

        private void WorkflowUploadBuildModel(int fileInfoId, string loggedInUserName)
        {
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_WorkflowUploadBuildModel, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileInfoId, fileInfoId);

                cmd.ExecuteNonQuery();
            }
        }

        public IList<UploadETLMessage> GetUploadETLMessages(int fileInfoId, string loggedInUserName)
        {
            var etlMessages = new List<UploadETLMessage>();
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FileUpload_GetUploadETLMessages, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCtUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamFileInfoId, fileInfoId);

                using (SqlDataReader resultReader = cmd.ExecuteReader())
                {
                    while (resultReader.Read())
                    {
                        if (resultReader.HasRows)
                        {
                            etlMessages.Add(new UploadETLMessage()
                            {
                                TaskName = Utility.GetString(resultReader["TaskName"]),
                                EventCode = Utility.GetIntNullable(resultReader["EventCode"]),
                                StartTime = Utility.GetDateTimeNullable(resultReader["StartTime"]),
                                EventDescription = Utility.GetString(resultReader["EventDescription"])
                            });
                        }
                    }
                }
            }
            return etlMessages;
        }
    }
}