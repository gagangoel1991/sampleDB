﻿using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.Upload;
using NW.SFP.Message.Core;
using NW.SFP.Message.Upload;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFP.DataService.Upload
{
    public class FileUploadUtilityDataService : Repository<FileUploadUtilityDetailsEntity>, IFileUploadUtilityDataService
    {
        private IUnitOfWork _unitOfWork;

        public FileUploadUtilityDataService()
        {

        }

        public FileUploadUtilityDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public IList<FileUploadUtilityDetailsEntity> GetFileUploadUtilityDetails(int FileUploadUtilityConfigurationId, int ReferenceId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = "sfp.spGetFileUploadUtilityDetails";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pFileUploadUtilityConfigurationId", FileUploadUtilityConfigurationId));
                command.Parameters.Add(command.CreateParameter("@pReferenceId", ReferenceId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));
                return this.Execute(command).ToList();
            }
        }

        public int SaveFileUploadUtilityDetails(FileUploadUtilityAddEntity objFileUploadUtilityAddEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = "sfp.spSaveFileUploadUtilityDetails";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pFileUploadUtilityConfigurationId", objFileUploadUtilityAddEntity.FileUploadUtilityConfigurationId));
                command.Parameters.Add(command.CreateParameter("@pUserName", objFileUploadUtilityAddEntity.UserName));
                command.Parameters.Add(command.CreateParameter("@pReferenceId", objFileUploadUtilityAddEntity.ReferenceId));
                command.Parameters.Add(new SqlParameter
                {
                    TypeName = "sfp.udtFileUploadInfoList",
                    Value = objFileUploadUtilityAddEntity.FileUploadInfoList.ToDataTable(),
                    ParameterName = "@pFileUploadInfoList"
                });

                //IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32);
                //command.Parameters.Add(returnCode);
                return this.ExecuteNonQuery(command);
                //return Convert.ToInt32(returnCode.Value);
            }

        }

        public FileUploadUtilityConfiguration GetFileUploadUtilityConfiguration(int FileUploadUtilityConfigurationId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = "sfp.spGetFileUploadUtilityConfiguration";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pFileUploadUtilityConfigurationId", FileUploadUtilityConfigurationId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));

                using (var record = command.ExecuteReader())
                {
                    FileUploadUtilityConfiguration items = new FileUploadUtilityConfiguration();
                    while (record.Read())
                    {
                        items = Map<FileUploadUtilityConfiguration>(record);
                    }

                    return items;
                }

            }

        }

        public int DeleteFileUploadUtilityDetails(int FileUploadUtilityDetailsId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = "sfp.spDeleteFileUploadUtilityDetails";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pFileUploadUtilityDetailsId", FileUploadUtilityDetailsId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));                                
                return this.ExecuteNonQuery(command);                
            }

        }
    }
}