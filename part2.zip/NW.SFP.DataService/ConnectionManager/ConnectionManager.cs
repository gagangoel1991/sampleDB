﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using Microsoft.Extensions.Options;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Interface.ConnectionManager;

namespace NW.SFP.DataService
{
    public class ConnectionManager : IConnectionManager
    {

        private bool disposed = false;

        #region private Properties

        private string ConnectionString { get; set; }
        
        #endregion


        #region Data Service Classes parameter 

        /// <summary>
        /// On which Database we want to execute the procedure / query
        /// </summary>
        public SQLSource ConnectionSource { get; set; }

        /// <summary>
        /// Stored Procedure / Query which one is required to be executed
        /// </summary>
        public CommandType CommandType{ get; set; }

        /// <summary>
        /// Name of Stored Procedure or query text
        /// </summary>
        public string CommandText { get; set; }

        /// <summary>
        /// Time-out duration if to be provided
        /// </summary>
        public int CommandTimeOut { get; set; }

        #endregion

        #region Input Output parameters

        /// <summary>
        /// the result of the output parameters
        /// </summary>
        public List<SqlParameter> ParameterListOutput { get; set; }
        
        /// <summary>
        /// Sets Input parameter for the procedure 
        /// </summary>
        public List<SqlParameter> ParameterListInput { get; set; }

        #endregion


        #region Connection Executables

        /// <summary>
        /// Sql Connection Object
        /// </summary>
        private SqlConnection SqlDataConnection { get; set; }

        /// <summary>
        /// SQL Command Object
        /// </summary>
        private SqlCommand SqlDataCommand { get; set; }

        #endregion

        #region Constructor Properties

        /// <summary>
        /// Connection String object that holds all connection strings
        /// </summary>
        private IOptions<DBConnectionSettings> Connections;

        /// <summary>
        /// Constructor with Connection String Object injected
        /// </summary>
        /// <param name="connections"></param>
        public ConnectionManager(IOptions<DBConnectionSettings> connections)
        {
            Connections = connections;
            this.ParameterListInput = new List<SqlParameter>();
        }
        #endregion


        #region Parameter Construction Functions

        /// <summary>
        /// Function that creates the list of input parameters 
        /// </summary>
        private void GetInputParameterList()
        {
            foreach (SqlParameter parameter in ParameterListInput)
            {
                SqlDataCommand.Parameters.Add(parameter);
            }
        }

        /// <summary>
        /// Function that will give the output parameters fetched from the procedure
        /// </summary>
        /// <returns></returns>
        public List<SqlParameter> GetOutputParameterList()
        {
            ParameterListOutput = new List<SqlParameter>();
            foreach (SqlParameter parameter in SqlDataCommand.Parameters)
            {
                if (this.isOutputParameter(parameter))
                {
                    ParameterListOutput.Add(parameter);
                }
            }
            return ParameterListOutput;
        }

        #endregion


        #region Connection String 

        /// <summary>
        /// Check which database we need to connect
        /// </summary>
        /// <returns></returns>
        private string GetConnectionString()
        {
            this.ConnectionString = string.Empty;

            switch (ConnectionSource)
            {
                case SQLSource.SFPModel:
                    this.ConnectionString = Connections.Value.ConnectionString_Model;
                    break;
                case SQLSource.SFPConfiguration:
                    this.ConnectionString = Connections.Value.ConnectionString_Configuration;
                    break;
                case SQLSource.SFPStaging:
                    this.ConnectionString = Connections.Value.ConnectionString_Staging;
                    break;
                case SQLSource.SFPSecuritisation:
                    this.ConnectionString = Connections.Value.ConnectionString_Securitisation;
                    break;
            }

            return this.ConnectionString;
        }

        #endregion

        #region Database Executions Methods


        /// <summary>
        /// Execute Data set
        /// </summary>
        /// <returns></returns>
        public DataSet ExecuteDataSet()
        {
            DataSet dataSet = new DataSet();
            this.CreateExecutionObjects();

            using (SqlDataConnection)
            {
                using (SqlDataCommand)
                {
                    SqlDataConnection.Open();
                    new SqlDataAdapter(SqlDataCommand).Fill(dataSet);
                    GetOutputParameterList();
                }
            }

            return dataSet;
        }

        /// <summary>
        /// Execute Non-Query
        /// </summary>
        public void ExecuteNonQuery()
        {
            this.CreateExecutionObjects();
            using (SqlDataConnection)
            {
                using (SqlDataCommand)
                {
                    SqlDataConnection.Open();
                    SqlDataCommand.ExecuteNonQuery();
                    GetOutputParameterList();
                }
            }
        }

        #endregion


        #region Utility Functions


        /// <summary>
        /// Create SQL Connection Object
        /// </summary>
        /// <returns></returns>
        private void CreateSQLConnection()
        {
            this.SqlDataConnection = new SqlConnection(GetConnectionString());
        }

        /// <summary>
        /// Create SQL Commend Object
        /// </summary>
        private void CreateSQLCommand()
        {
            this.SqlDataCommand = new SqlCommand(CommandText, this.SqlDataConnection);
            this.SqlDataCommand.CommandType = this.CommandType;
            this.GetInputParameterList();
            this.SqlDataCommand.CommandTimeout = this.CommandTimeOut;
        }

        /// <summary>
        /// Function that creates Connection and Command object simultaneously since it is required in all Database executions
        /// </summary>
        private void CreateExecutionObjects()
        {
            this.CreateSQLConnection();
            this.CreateSQLCommand();
        }

        /// <summary>
        /// Check if SQL parameter is Output parameter 
        /// </summary>
        /// <param name="parameter"></param>
        /// <returns></returns>
        private bool isOutputParameter(SqlParameter parameter)
        {
            return (parameter.Direction == ParameterDirection.Output || parameter.Direction == ParameterDirection.InputOutput);
        }

        #endregion


        public void Dispose()
        {
            Dispose(true);
            GC.SuppressFinalize(this);
        }

        public virtual void Dispose(bool disposing)
        {
            if (disposed)
            { return; }

            if (disposing)
            {
                //dispose managed resources
            }
            //dispose unmanaged resources

            disposed = true;
        }

        ~ConnectionManager()
        {
            Dispose(false);
        }

    }
}
