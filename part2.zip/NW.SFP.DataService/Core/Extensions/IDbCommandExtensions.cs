﻿namespace NW.SFP.DataService.Core
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;

    public static class IDbCommandExtensions
    {
        public static IDbDataParameter CreateParameter(this IDbCommand command, string name, object value)
        {
            var parameter = command.CreateParameter();
            parameter.ParameterName = name;
            parameter.Value = value;

            return parameter;
        }

        public static IDbDataParameter CreateOutputParameter(this IDbCommand command, string name, object value, DbType dbType =DbType.String, int size = 100)
        {
            var parameter = command.CreateParameter();
            parameter.ParameterName = name;
            parameter.Value = value;
            parameter.DbType = dbType;
            parameter.Size = size;
            parameter.Direction = ParameterDirection.Output;
            return parameter;
        }

        public static void AddInputParameters<T>(this IDbCommand cmd, T parameters) where T : class
        {
            foreach (var prop in parameters.GetType().GetProperties())
            {
                object val = prop.GetValue(parameters, null);
                var p = cmd.CreateParameter();
                p.ParameterName = prop.Name;
                p.Value = val ?? DBNull.Value;
                cmd.Parameters.Add(p);
            }
        }

        public static void AddOutputParameters<T>(this IDbCommand cmd, T parameters) where T : class
        {
            foreach (var prop in parameters.GetType().GetProperties())
            {
                object val = prop.GetValue(parameters, null);
                var p = cmd.CreateParameter();
                p.ParameterName = prop.Name;
                p.Direction = ParameterDirection.Output;
                p.DbType = DbType.Int32;
                cmd.Parameters.Add(p);
            }
        }

    }
}
