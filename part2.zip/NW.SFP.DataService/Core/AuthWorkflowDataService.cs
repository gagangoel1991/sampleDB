﻿using NW.SFP.Common;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Common;
using System;
using System.Data;
using System.Data.SqlClient;

namespace NW.SFP.DataService.Core
{
    public class AuthWorkflowDataService : Repository<AuthWorkflowEntity>, IAuthWorkflowDataService
    {
        private readonly IUnitOfWork _unitOfWork;

        public AuthWorkflowDataService()
        {

        }

        public AuthWorkflowDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public AuthWorkflowEntity GetAuthWorkflowStatus(AuthWorkflowEntity authWorkflowEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = DbConstants.SP_GetAuthWorkflowStatus;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamPsId, authWorkflowEntity.ProcessId));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamWorkflowtype, Enum.GetName(typeof(AuthWorkflowType), authWorkflowEntity.WorkflowType)));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamUserName, authWorkflowEntity.UserName));
                return this.ExecuteToEntity(command);
            }
        }

        public int ManageAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            AuthAuditEntity objAuthAuditEntity = GetEntityAuditDetails(authWorkflowEntity);
            if (objAuthAuditEntity != null && objAuthAuditEntity.ModifiedDate != null && authWorkflowEntity.ModifiedDate != null
                && objAuthAuditEntity.ModifiedDate != DateTime.MinValue && authWorkflowEntity.ModifiedDate != DateTime.MinValue
                && objAuthAuditEntity.ModifiedDate != authWorkflowEntity.ModifiedDate)
            {
                return -1;
            }

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = DbConstants.SP_ManageDataAuthWorkflow;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamWorkflowtype, Enum.GetName(typeof(AuthWorkflowType), authWorkflowEntity.WorkflowType)));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamStepName, Enum.GetName(typeof(AuthWorkflowStep), authWorkflowEntity.WorkflowStep)));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamStatus, authWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamComment, authWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamPsId, authWorkflowEntity.ProcessId));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbProcParamUserName, authWorkflowEntity.UserName));
                return this.ExecuteNonQuery(command);
            }
        }

        public AuthAuditEntity GetEntityAuditDetails(AuthWorkflowEntity authWorkflowEntity)
        {
            AuthAuditEntity objAuthAuditEntity = new AuthAuditEntity();
            try
            { 
                using (var cmd = this._unitOfWork.CreateCommand())
                { 
                    cmd.CommandText = DbConstants.SP_GetEntityAuditDetails;
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(cmd.CreateParameter(DbConstants.DbProcParamWorkflowtype, Enum.GetName(typeof(AuthWorkflowType), authWorkflowEntity.WorkflowType)));
                    cmd.Parameters.Add(cmd.CreateParameter(DbConstants.DbProcParamPsId, authWorkflowEntity.ProcessId));
                    cmd.Parameters.Add(cmd.CreateParameter(DbConstants.DbProcParamUserName, authWorkflowEntity.UserName));

                    SqlDataReader reader;
                    using (reader = cmd.ExecuteReader())
                    {
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                objAuthAuditEntity.CreatedBy = Utility.GetString(reader["CreatedBy"]);
                                objAuthAuditEntity.CreatedDate = Utility.GetDateTimeNullable(reader[DbConstants.DbFieldCreatedDate]); 

                                objAuthAuditEntity.ModifiedBy = Utility.GetString(reader["ModifiedBy"]);
                                objAuthAuditEntity.ModifiedDate = reader.GetDateTime(reader.GetOrdinal(DbConstants.DbFieldModifiedDate));

                                objAuthAuditEntity.AuthorizedBy = Utility.GetString(reader["AuthorizedBy"]);
                                objAuthAuditEntity.AuthorizedDate = Utility.GetDateTimeNullable(reader[DbConstants.DbFieldAuthorizedDate]);
                            }
                        }
                    }
                    return objAuthAuditEntity;
                }
            }
            catch
            {
                throw;
            }
        }


    }
}
