﻿namespace NW.SFP.DataService.Core
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Linq;
    using System.Text;
    using System.Threading.Tasks;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    

    public class Repository<TEntity> : IRepository<TEntity> where TEntity : new()
    {
        IUnitOfWork _UnitOfWork;

        public Repository()
        {

        }

        public Repository(IUnitOfWork uow)
        {
            this._UnitOfWork = uow;
        }

        public IEnumerable<TEntity> Execute(IDbCommand command)
        {
            using (var record = command.ExecuteReader())
            {
                List<TEntity> items = new List<TEntity>();
                while (record.Read())
                {
                    items.Add(Map<TEntity>(record));
                }

                return items;
            }
        }

        public TEntity ExecuteToEntity(IDbCommand command)
        {
            using (var record = command.ExecuteReader())
            {
                if (record.Read())
                {
                    return Map<TEntity>(record);
                }
                else
                {
                    return new TEntity();
                }
            }
        }

        public TEntity Map<TEntity>(IDataRecord record)
        {
            var objT = Activator.CreateInstance<TEntity>();
            foreach (var property in typeof(TEntity).GetProperties())
            {
                if (record.HasColumn(property.Name) && !record.IsDBNull(record.GetOrdinal(property.Name)))
                {
                    property.SetValue(objT, record[property.Name]);
                }
            }

            return objT;
        }

        public int ExecuteNonQuery(IDbCommand command)
        {
            return command.ExecuteNonQuery();
        }
    }
}
