﻿using NW.SFP.DataService.CW;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Core;
using NW.SFP.Message.Core.Token;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;

namespace NW.SFP.DataService.Core
{
    public class APITokenDataService : Repository<APITokenEntity>, IAPITokenDataService
    {
        private IUnitOfWork _unitOfWork;

        public APITokenDataService()
        {
        }

        public APITokenDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }



        public APITokenUpdateOutputEntity UpdateAPIToken(APITokenEntity objAPITokenEntity)
        {
            using (var Command = this._unitOfWork.CreateCommand())
            {
                Command.CommandText = DbConstants.SP_UpdateAPIToken;
                Command.CommandType = CommandType.StoredProcedure;

                Command.Parameters.Add(Command.CreateParameter(DbConstants.DbFieldAPITokenKey, objAPITokenEntity.Key));
                Command.Parameters.Add(Command.CreateParameter(DbConstants.DbFieldAPITokenToken, objAPITokenEntity.Token));
                Command.Parameters.Add(Command.CreateParameter(DbConstants.DbFieldFromIsProcessRunning, objAPITokenEntity.FromIsProcessRunning));
                Command.Parameters.Add(Command.CreateParameter(DbConstants.DbFieldToIsProcessRunning, objAPITokenEntity.ToIsProcessRunning));
                Command.Parameters.Add(Command.CreateParameter(DbConstants.DbFieldAPITokenUserName, objAPITokenEntity.UserName));

                IDbDataParameter ReturnCodeIsTokenUpdated = Command.CreateOutputParameter(DbConstants.DbFieldOutIsTokenUpdated, 0, DbType.Boolean, -1);
                IDbDataParameter ReturnCodeUpdatedToken = Command.CreateOutputParameter(DbConstants.DbFieldOutUpdatedToken, 0, DbType.Guid, -1);
                IDbDataParameter ReturnCodeIsProcessRunning = Command.CreateOutputParameter(DbConstants.DbFieldOutIsProcessRunning, 0, DbType.Boolean, -1);

                Command.Parameters.Add(ReturnCodeIsTokenUpdated);
                Command.Parameters.Add(ReturnCodeUpdatedToken);
                Command.Parameters.Add(ReturnCodeIsProcessRunning);

                this.ExecuteNonQuery(Command);

                var ObjAPITokenUpdateOutputEntity = new APITokenUpdateOutputEntity()
                {
                    IsTokenUpdated = Convert.ToBoolean(ReturnCodeIsTokenUpdated.Value),
                    UpdatedToken = ReturnCodeUpdatedToken.Value as Guid?,
                    IsProcessRunning = Convert.ToBoolean(ReturnCodeIsProcessRunning.Value),
                };

                return ObjAPITokenUpdateOutputEntity;
            }
        }

        public Guid? GetAPITokenbyKey(APITokenEntity objAPITokenEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = DbConstants.SP_GetAPITokenbyKey;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbConstants.DbFieldAPITokenKey, objAPITokenEntity.Key));
                command.Parameters.Add(command.CreateParameter(DbConstants.DbFieldAPITokenUserName, objAPITokenEntity.UserName));


                IDbDataParameter returnCode = command.CreateOutputParameter(DbConstants.DbFieldAPITokenToken, 0, DbType.Guid, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return returnCode.Value as Guid?;
            }
        }

    }
}
