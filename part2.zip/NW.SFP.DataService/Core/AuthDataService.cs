﻿using Dapper;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Text;
using System.Linq;
using NW.SFP.Message;
using Microsoft.Extensions.Options;
using NW.SFP.Message.Core;
using NW.SFP.DataService.CW;
using NW.SFP.Message.PS;

namespace NW.SFP.DataService.Core
{
    public class AuthDataService : IAuthDataService
    {

        private readonly IOptions<DataServiceSettings> _settings;

        public AuthDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        /// <summary>
        /// This will return the user's default asset class
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="adGroupName"></param>
        /// <returns></returns>
        public string GetDefaultAssetClass(string userName, string adGroupName)
        {
            string selectedAssetClass;
            using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_User_GetDefaultAssetClass, con))
            {
                if (con.State == ConnectionState.Closed)
                    con.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamUserName, userName));
                cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamUser_AdGroupName, adGroupName));
                cmd.Parameters.Add(DbConstants.DbProcParamReturnValue, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamReturnValue].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                selectedAssetClass = Utility.GetString(cmd.Parameters[DbConstants.DbProcParamReturnValue].Value);
            }
            return selectedAssetClass;
        }

        /// <summary>
        /// This will return the user basic detail and all left menu items
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="adGroupName"></param>
        /// <returns></returns>
        public UserDetailEntity GetUserAndMenuData(string userName, string adGroupName , int selectedAssetId)
        {
            try
            {
                UserDetailEntity userDetail = new UserDetailEntity();
                using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_User_GetUserAndMenuData, con))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamUserName, userName));
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamUser_AdGroupName, adGroupName));
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamAssetId, selectedAssetId));
                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataSet dsUserMenu = new DataSet();
                        adapter.Fill(dsUserMenu);

                        userDetail = TransformDatasetToUserMenuData(dsUserMenu);
                    }
                }

                if (!string.IsNullOrEmpty(this._settings.Value.Environment))
                    userDetail.EnvironmentName = "| " + this._settings.Value.Environment;

                return userDetail;
            }
            catch
            {   
                throw;
            }
        }

        /// <summary>
        /// This will return the user basic detail and all left menu items
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="adGroupName"></param>
        /// <returns></returns>
        public IList<MenuItemEntity> GetDealIpdMenuData(int dealId, string userName)
        {
            try
            {
                IList<MenuItemEntity> menuItems = new List<MenuItemEntity>();
                using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(CWDBConstants.SP_GetDealIpdProcessMenuData, con))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamUserName, userName));
                    cmd.Parameters.Add(new SqlParameter(CWDBConstants.DbProcParamDealId, dealId));

                    using (SqlDataAdapter adapter = new SqlDataAdapter(cmd))
                    {
                        DataSet dsUserMenu = new DataSet();
                        adapter.Fill(dsUserMenu);

                        UserDetailEntity userDetail = new UserDetailEntity();
                        if (dsUserMenu.Tables.Count > 0)
                        {
                            //Populate Menuitems

                            foreach (DataRow dr in dsUserMenu.Tables[0].Rows)
                            {
                                int parentId = Utility.GetInt(dr["ParentMenuId"]);
                                MenuItemEntity menuItem = new MenuItemEntity()
                                {
                                    NavbarMenuId = Utility.GetInt(dr["NavbarMenuId"]),
                                    MenuName = Utility.GetString(dr["MenuName"]),
                                    RouterLink = Utility.GetString(dr["RouterLink"]),
                                    Icon = Utility.GetString(dr["Icon"]),
                                    Order = Utility.GetInt(dr["SeqOrder"]),
                                    IsAccessible = Utility.GetBool(dr["IsAccessible"]),
                                    Selected = Utility.GetBool(dr["Selected"]),
                                    Expanded = Utility.GetBool(dr["Expanded"]),
                                    ChildMenu = null
                                };

                                if (parentId == 0)
                                {
                                    menuItems.Add(menuItem);
                                }
                                else
                                {
                                    //Add the menu as child
                                    MenuItemEntity parentMenu = null;
                                    GetParentMenuItem(menuItems, parentId, ref parentMenu);
                                    if (parentMenu.ChildMenu == null)
                                        parentMenu.ChildMenu = new List<MenuItemEntity>();
                                    parentMenu.ChildMenu.Add(menuItem);

                                }
                            }
                        }
                    }
                }

                return menuItems;
            }
            catch
            {
                throw;
            }
        }

        /// <summary>
        /// This will transform the User Menu DataSet into UserDetail Entity 
        /// </summary>
        /// <param name="userMenuData"></param>
        /// <returns></returns>
        private UserDetailEntity TransformDatasetToUserMenuData(DataSet userMenuData)
        {
            UserDetailEntity userDetail = new UserDetailEntity();
            if (userMenuData.Tables.Count > 0)
            {
                //Populate the User Detail
                userDetail.RoleName = userMenuData.Tables[0].Rows[0]["RoleName"].ToString();
                userDetail.UserFullName = userMenuData.Tables[0].Rows[0]["UserFullName"].ToString();
                userDetail.UserName = userMenuData.Tables[0].Rows[0]["UserName"].ToString();
                userDetail.ProfileImage = userMenuData.Tables[0].Rows[0]["ProfileImage"].ToString();

                //Populate Menuitems
                IList<MenuItemEntity> menuItems = new List<MenuItemEntity>();
                foreach (DataRow dr in userMenuData.Tables[1].Rows)
                {
                    int parentId = Utility.GetInt(dr["ParentMenuId"]);
                    MenuItemEntity menuItem = new MenuItemEntity()
                    {
                        NavbarMenuId = Utility.GetInt(dr["NavbarMenuId"]),
                        MenuName = Utility.GetString(dr["MenuName"]),
                        RouterLink = Utility.GetString(dr["RouterLink"]),
                        PathPrefix = Utility.GetString(dr["PathPrefix"]),
                        Icon = Utility.GetString(dr["Icon"]),
                        Order = Utility.GetInt(dr["SeqOrder"]),
                        IsAccessible = Utility.GetBool(dr["IsAccessible"]),
                        Selected = Utility.GetBool(dr["Selected"]),
                        Expanded = Utility.GetBool(dr["Expanded"]),
                        ChildMenu = null
                    };

                    if (parentId == 0)
                    {
                        menuItem.RouterLink = menuItem.PathPrefix + menuItem.RouterLink;
                        menuItems.Add(menuItem);
                    }
                    else
                    {
                        //Add the menu as child
                        MenuItemEntity parentMenu = null;
                        GetParentMenuItem(menuItems, parentId, ref parentMenu);
                        if (parentMenu.ChildMenu == null)
                            parentMenu.ChildMenu = new List<MenuItemEntity>();
                        menuItem.PathPrefix = parentMenu.PathPrefix + menuItem.PathPrefix;
                        menuItem.RouterLink = menuItem.PathPrefix + menuItem.RouterLink;
                        parentMenu.ChildMenu.Add(menuItem);

                    }
                }

                //Finally add the menu items into the final user menu object
                userDetail.MenuItems = menuItems;

                userDetail.UserPermissions = GetUserPermissions(userMenuData);

                userDetail.SelectedAssetClass = Utility.GetInt(userMenuData.Tables[3].Rows[0]["SelectedAssetClass"]);

                userDetail.AssetClassList = GetAssetClasses(userMenuData);

            }

            return userDetail;
        }

        private IList<AssetClass> GetAssetClasses(DataSet userMenuData)
        {
            IList<AssetClass> assetClassList = new List<AssetClass>();
            foreach (DataRow dr in userMenuData.Tables[4].Rows)
            {
                assetClassList.Add(new AssetClass
                {
                    ClassId = Utility.GetString(dr[DbConstants.DbFieldUser_ClassId]),
                    ClassName = Utility.GetString(dr[DbConstants.DbFieldUser_ClassName]),
                    Description = Utility.GetString(dr[DbConstants.DbFieldUser_ClassDesc]),
                    Code = Utility.GetString(dr[DbConstants.DbFieldUser_ClassCode])
                });
            }
            return assetClassList;
        }

        private IList<UserPermissionEntity> GetUserPermissions(DataSet userMenuData)
        {
            IList<UserPermissionEntity> userPermissions = new List<UserPermissionEntity>();
            foreach (DataRow dr in userMenuData.Tables[2].Rows)
            {
                userPermissions.Add(new UserPermissionEntity()
                {
                    RoleId = Utility.GetInt(dr[DbConstants.DbFieldUser_RoleId]),
                    Permission = Utility.GetString(dr[DbConstants.DbFieldUser_Permission]),
                    PermissionAccessType = Utility.GetString(dr[DbConstants.DbFieldUser_PermissionAccessType])
                });
            }

            return userPermissions;
        }

        private void GetParentMenuItem(IList<MenuItemEntity> menuItems, int parentId, ref MenuItemEntity parentNode)
        {
            MenuItemEntity parentMenu = menuItems.Where(m => m.NavbarMenuId == parentId).FirstOrDefault();

            if (parentMenu != null)
            {
                parentNode = parentMenu;
                return;
            }
            foreach (MenuItemEntity menuItem in menuItems)
            {
                if (menuItem.ChildMenu != null)
                    GetParentMenuItem(menuItem.ChildMenu, parentId, ref parentNode);
            }
        }

        /// <summary>
        /// This will validate the user action based on the user role
        /// </summary>
        /// <param name="authParams"></param>
        /// <returns></returns>
        public bool IsUserActionAuthorized(UserAuthParams authParams)
        {
            try
            {
                bool isAccessible = false;
                UserDetailEntity userDetail = new UserDetailEntity();
                using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand("app.IsUserActionAuthorized", con))
                {
                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@userName", authParams.UserName));
                    cmd.Parameters.Add(new SqlParameter("@adGroupName", authParams.ADGroupName));
                    cmd.Parameters.Add(new SqlParameter("@permissionName", authParams.PermissionName));
                    cmd.Parameters.Add(new SqlParameter("@acessTypeId", authParams.AccessType));
                    cmd.Parameters.Add("@result", SqlDbType.Bit);
                    cmd.Parameters["@result"].Direction = ParameterDirection.Output;

                    cmd.ExecuteNonQuery();

                    isAccessible = Convert.ToBoolean(cmd.Parameters["@result"].Value.ToString());
                }
                return isAccessible;
            }
            catch
            {
                throw;
            }
        }


        /// <summary>
        /// This will return the AD Group Names
        /// </summary>
        /// <param name="currentUser"></param>
        /// <returns></returns>
        public IList<string> GetADGroup(string currentUser)
        {
            try
            {
                IList<string> adGroups = new List<string>();

                using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand("app.GetADGroup", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;

                    if (con.State == ConnectionState.Closed)
                        con.Open();
                    cmd.Parameters.Add(new SqlParameter("@userName", currentUser));
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        adGroups.Add(Utility.GetString(reader["GroupName"]));
                    }
                }
                return adGroups;
            }
            catch
            {
                throw;
            }
        }
    }
}
