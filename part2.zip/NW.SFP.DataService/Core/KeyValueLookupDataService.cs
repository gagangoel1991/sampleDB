﻿using NW.SFP.DataService.CW;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.Core
{
    public class KeyValueLookupDataService : Repository<KeyValueLookupEntity>, IKeyValueLookupDataService
    {
        private IUnitOfWork _unitOfWork;

        public KeyValueLookupDataService()
        {

        }

        public KeyValueLookupDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the key value lookup data based of type
        /// </summary>
        /// <param name="lookupTypeId"></param>
        ///<param name="loggedInUserName"></param>
        public IList<KeyValueLookupEntity> GetKeyValueLookupData(string lookupTypeId, string loggedInUserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SGetKeyValueLookupData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pKeyValueTypeIds", lookupTypeId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUserName));
                return this.Execute(command).ToList();
            }
        }
    }
}
