﻿using System;
using System.Data;
using System.Globalization;

namespace NW.SFP.DataService.Core
{
    public class Utility
    {

        private static string UTCTimeZone = "UTC";
        private static string GMTStandardTimeZone = "GMT Standard Time";

        public static string GetString(object str)
        {
            if (str == null || str is DBNull)
                return string.Empty;
            else
                return Convert.ToString(str);
        }

        public static decimal? GetDecimal(object obj)
        {
            if (obj == null || obj is DBNull || string.IsNullOrEmpty(Convert.ToString(obj)))
                return null;
            else
                return Convert.ToDecimal(obj);
        }

        public static int GetInt(object value)
        {
            if (value == null || value is DBNull)
                return 0;
            else
                return Convert.ToInt32(value);
        }

        public static int? GetIntNullable(object value)
        {
            if (value == null || value is DBNull)
                return null;
            else
                return Convert.ToInt32(value);
        }

        public static bool GetBool(object value)
        {
            if (value == null || value is DBNull)
                return false;
            else
            {
                Boolean val;
                return Boolean.TryParse(GetString(value), out val) ? val : false;
            }
        }

        public static string GetDateTime(object dt)
        {
            if (dt == null || dt is DBNull)
                return string.Empty;
            else
            {
                DateTime date;
                if (DateTime.TryParse(GetString(dt), out date))
                {
                    return date.ToString("yyyy'-'MM'-'dd' 'HH':'mm':'ss");
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string GetDate(object dt)
        {
            if (dt == null || dt is DBNull)
                return string.Empty;
            else
            {
                DateTime date;
                if (DateTime.TryParse(GetString(dt), out date))
                {
                    return date.ToString("yyyy'-'MM'-'dd");
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string GetShortDateTime(object dt)
        {
            if (dt == null || dt is DBNull)
                return string.Empty;
            else
            {
                DateTime date;
                if (DateTime.TryParse(GetString(dt), out date))
                {
                    return date.ToString("dd'-'MMM'-'yyyy");
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string GetUKFormattedDateTime(object dt)
        {
            if (dt == null || dt is DBNull)
                return string.Empty;
            else
            {
                DateTime date;
                if (DateTime.TryParse(GetString(dt), out date))
                {
                    return date.ToString("dd'-'MM'-'yyyy");
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static string GetUKFormattedDateWithTime(object dt)
        {
            if (dt == null || dt is DBNull)
                return string.Empty;
            else
            {
                DateTime date;
                if (DateTime.TryParse(GetString(dt), out date))
                {
                    return date.ToString("dd'-'MM'-'yyyy' 'HH':'mm':'ss");
                }
                else
                {
                    return string.Empty;
                }
            }
        }

        public static DateTime? GetDateTimeNullable(object dt)
        {
            if (dt == null || dt is DBNull)
                return null;
            else
            {
                DateTime date;
                if (DateTime.TryParse(GetString(dt), out date))
                {
                    return date;
                }
                else
                {
                    return null;
                }
            }
        }

        public static long GetLong(object value)
        {
            if (value == null || value is DBNull || String.IsNullOrEmpty(Convert.ToString(value)))
                return 0;
            else
                return Convert.ToInt64(value);
        }

        public static string ConvertUTCToUKTime(string dbDateTime)
        {
            return string.IsNullOrWhiteSpace(dbDateTime) ? string.Empty :
                                                           GetDateTime(TimeZoneInfo.ConvertTimeFromUtc(TimeZoneInfo.ConvertTimeFromUtc
                                                                      (Convert.ToDateTime(dbDateTime), TimeZoneInfo.FindSystemTimeZoneById(UTCTimeZone)),
                                                                       TimeZoneInfo.FindSystemTimeZoneById(GMTStandardTimeZone)).ToString());
        }


        public static DataTable ConvertColumnIntoRow(DataTable dt)
        {
            DataTable dtReturn = new DataTable();
            dtReturn.Columns.Add("Value", typeof(Object));
            for (int i = 0; i < dt.Columns.Count; i++)
            {
                dtReturn.Rows.Add();
                dtReturn.Rows[i][0] = dt.Rows[0][i];
            }

            return dtReturn;
        }

        public static DataTable GenerateTransposedTable(DataTable inputTable)
        {
            DataTable outputTable = new DataTable();
            for (int i = 0; i < inputTable.Rows.Count; i++)
            {
                outputTable.Columns.Add("Col"+i, typeof(Object));
            }
            
            for (int rCount = 0; rCount < inputTable.Columns.Count; rCount++)
            {
                DataRow newRow = outputTable.NewRow();

                for (int cCount = 0; cCount < inputTable.Rows.Count; cCount++)
                {
                    dynamic colValue;
                    if (inputTable.Rows[cCount][rCount].ToString() != null && inputTable.Rows[cCount][rCount].ToString() != "")
                    {
                        colValue =inputTable.Rows[cCount][rCount];
                    }
                    else
                        colValue = "N/A";

                    newRow[cCount] = colValue;
                }
                outputTable.Rows.Add(newRow);
            }

            return outputTable;
        }
    }
}
