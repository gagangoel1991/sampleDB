﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using Microsoft.Extensions.Options;
using NW.SFP.Interface.Core;
using NW.SFP.Message.core;
using NW.SFP.Message.Core;

namespace NW.SFP.DataService.Core
{
    public class DateListDataService : IDateListDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public DateListDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public IList<HolidayDate> GetHolidayList()
        {
            IList<HolidayDate> HolidayDateData = new List<HolidayDate>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetHolidayList, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    HolidayDateData.Add(new HolidayDate()
                    {
                        Date = Utility.GetShortDateTime(reader["Date"]),
                        IsUKHoliday = Convert.ToBoolean(reader["IsUKHoliday"]),
                        IsNIHoliday = Convert.ToBoolean(reader["IsNIHoliday"]),
                        IsROIHoliday = Convert.ToBoolean(reader["IsROIHoliday"])
                    });
                }
            }
            return HolidayDateData;
        }
    }
}
