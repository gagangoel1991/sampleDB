﻿namespace NW.SFP.DataService.Core
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.Core;
    using NW.SFP.Message.Core;
    using NW.SFP.DataService.Core;

    public class SelectLookupDataService : Repository<SelectLookupEntity>, ISelectLookupDataService
    {
        private IUnitOfWork _unitOfWork;

        public SelectLookupDataService()
        {

        }

        public SelectLookupDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public IEnumerable<SelectLookupEntity> GetParametrizedSelectList(DataTable ListId, string AssetClassId)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = "CW.spGetSelectLookupList";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("ListId", ListId));
                command.Parameters.Add(command.CreateParameter("@pAssetClassId", AssetClassId));
                return this.Execute(command).ToArray();
            }
        }

        public IEnumerable<SelectLookupEntity> GetParametrizedSelectListFilterBased(DataTable ListId, DataTable FilterId)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = "CW.spGetSelectLookupListFilterBased";
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("ListId", ListId));
                command.Parameters.Add(command.CreateParameter("FilterId", FilterId));
                return this.Execute(command).ToArray();
            }
        }

    }
}
