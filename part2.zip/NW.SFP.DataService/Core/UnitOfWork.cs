﻿namespace NW.SFP.DataService.Core
{
    using System;
    using System.Data;
    using System.Data.SqlClient;
    using NW.SFP.Interface.Core;

    public class UnitOfWork : IUnitOfWork
    {
        private SqlConnection _connection;
        
        private bool _ownsConnection;
        private SqlTransaction _transaction;

        public UnitOfWork(SqlConnection connection)
        {
            _connection = connection;

            if (_connection.State == ConnectionState.Closed)
            {
                _ownsConnection = true;
                _connection.Open();
            }
            
        }

        public SqlCommand CreateCommand(bool beginTransaction = true)
        {
            var command = _connection.CreateCommand();

            if (beginTransaction)
            {
                if (_transaction == null)
                    _transaction = _connection.BeginTransaction();
            }

            command.Transaction = _transaction;
            command.CommandTimeout = 0;
            return command;
        }

        public SqlCommand CreateCommand()
        {
            var command = _connection.CreateCommand();
            command.Transaction = _transaction;
            command.CommandTimeout = 0;
            return command;
        }

   

        public void Commit()
        {
            try
            {
                if (_transaction == null)
                    throw new InvalidOperationException("Transaction have already been commited. Check your transaction handling.");

                _transaction.Commit();
                //_transaction = null;
            }
            catch (Exception e)
            {
                //log error here
            }
            finally
            {
                _transaction = null;
            }
        }

        public void Dispose()
        {
            if (_transaction != null)
            {
                _transaction.Rollback();
                _transaction = null;
            }

            if (_connection != null && _ownsConnection)
            {
                if (_connection.State == ConnectionState.Open)
                {
                    _connection.Close();
                    _connection = null;
                }
            }
        }
    }
}
