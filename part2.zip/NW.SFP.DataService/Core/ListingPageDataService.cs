﻿using Microsoft.Extensions.Options;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Common;
using NW.SFP.Message.core;
using NW.SFP.Message.Core;
using System;
using System.Data;
using System.Data.SqlClient;

namespace NW.SFP.DataService.Core
{
    public class ListingPageDataService : Repository<AuthWorkflowEntity>, IListingPageDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public ListingPageDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        #region Get Listing Preference

        public ListingPreference GetUserListingPreference(string listingPageName, string userName)
        {
            int result;
            ListingPreference listingPreference = new ListingPreference();
            listingPreference.ListingPageName = listingPageName;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetUserListingPreference, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamListingPageName, listingPageName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.Add(DbConstants.DbProcParamReturnValue, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamReturnValue].Direction = ParameterDirection.Output;
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            listingPreference.HiddenColumns.Add(Utility.GetString(resultReader[DbConstants.DbFieldColumnName]));
                        }
                    }
                }
                result = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamReturnValue].Value);
                if (result > 0)
                {
                    listingPreference.ListingPreferenceExists = true;
                }
                else
                {
                    listingPreference.ListingPreferenceExists = false;
                }
            }
            return listingPreference;
        }
        #endregion

        #region Save Listing Preference

        public int SaveUserListingPreference(ListingPreference listingPreference, string userName)
        {
            int result;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_SaveUserListingPreference, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamListingPageName, listingPreference.ListingPageName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                var listingHiddenColumns = new DataTable();
                listingHiddenColumns.Columns.Add(DbConstants.DbFieldColumnName, typeof(string));
                foreach(var pHiddenColumn in listingPreference.HiddenColumns)
                {
                    listingHiddenColumns.Rows.Add(pHiddenColumn.ToString());
                }
                cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamHiddenColumnList, SqlDbType.Structured));
                cmd.Parameters[DbConstants.DbProcParamHiddenColumnList].Value = listingHiddenColumns;
                cmd.Parameters.Add(DbConstants.DbProcParamReturnValue, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamReturnValue].Direction = ParameterDirection.Output;
                cmd.ExecuteNonQuery();
                result = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamReturnValue].Value);
            }
            return result;
        }
        #endregion
    }
}
