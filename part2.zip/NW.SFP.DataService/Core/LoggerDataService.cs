﻿using System.Data;
using System.Data.SqlClient;
using NW.SFP.Message;
using Microsoft.Extensions.Options;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Core;
using System;

namespace NW.SFP.DataService.Core
{
    public class LoggerDataService : ILoggerDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public LoggerDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        /// <summary>
        /// For logging the info in the database/Txt file
        /// </summary>
        /// <param name="logInfo"></param>
        public void LogInfo(LogInfoEntity logInfo)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand("app.spSaveInfoLog", con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter("@pModuleId", logInfo.ModuleId));
                    cmd.Parameters.Add(new SqlParameter("@pActionPerformed", logInfo.ActionPerformed)); 
                    cmd.Parameters.Add(new SqlParameter("@pLogDetail", logInfo.LogDetail));
                    cmd.Parameters.Add(new SqlParameter("@pLogLevel", this._settings.Value.LogLevel));
                    cmd.Parameters.Add(new SqlParameter("@pUserName", logInfo.UserName));

                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    cmd.ExecuteNonQuery();
                }
            }
            catch
            {
                //Eat the error;
            }
        }

        /// <summary>
        /// For logging the error 
        /// </summary>
        /// <param name="logError"></param>
        public void LogError(LogErrorEntity logError)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_ErrorLog_Save, con))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamErrorLog_Save_ModuleId, logError.ModuleId));
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamErrorLog_Save_LogOriginTypeId, this._settings.Value.ErrorOriginType)); //It will always be 2
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamErrorLog_Save_ErrorProcedure, logError.ErrorMethod));
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamErrorLog_Save_ErrorMessage, logError.ErrorMessage));
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamErrorLog_Save_UserName, logError.UserName));
                    cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamErrorLog_Save_LogId, SqlDbType.Int));
                    cmd.Parameters[DbConstants.DbProcParamErrorLog_Save_LogId].Direction = ParameterDirection.Output;
                    if (con.State == ConnectionState.Closed)
                        con.Open();

                    var rowsAffected = cmd.ExecuteNonQuery();
                    logError.ErrorId = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamErrorLog_Save_LogId].Value);
                }
            }
            catch(Exception ex)
            {
                //Eat the error;
            }
        }
    }
}
