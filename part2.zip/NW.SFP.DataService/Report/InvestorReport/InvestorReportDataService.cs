﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.Report.ReportDBConstants;

namespace NW.SFP.DataService.Report
{
   public class InvestorReportDataService : Repository<InvestorReportResultEntity>, IInvestorReportDataService
    {
        private IUnitOfWork _unitOfWork;

        public InvestorReportDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public InvestorReportResultEntity GetInvestorReportFileName(int dealId, string ipdDate, string formatType)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetInvestorReportFileName;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pIpdDate", ipdDate));
                command.Parameters.Add(command.CreateParameter("@pFormatType", formatType));
                using (var record = command.ExecuteReader())
                {
                    InvestorReportResultEntity items = new InvestorReportResultEntity();
                    while (record.Read())
                    {
                        items = Map<InvestorReportResultEntity>(record);
                    }

                    return items;
                }

            }
        }

        public InvestorReportResultEntity Save(InvestorReportResultEntity reportEntity, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveInvestorReportFileName;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pDealIpdIrLocationId", reportEntity.DealIpdIrLocationId));
                command.Parameters.Add(command.CreateParameter("pDealipdRunId", reportEntity.DealipdRunId));
                command.Parameters.Add(command.CreateParameter("pDealId", reportEntity.DealId));
                command.Parameters.Add(command.CreateParameter("pFileName", reportEntity.FileName));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                reportEntity.DealIpdIrLocationId = Convert.ToInt32(ReturnCode.Value);

                return reportEntity;
            }
        }

    }
}
