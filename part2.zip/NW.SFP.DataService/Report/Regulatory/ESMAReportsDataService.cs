﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.Report
{
    public class ESMAReportsDataService : IESMAReportDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public ESMAReportsDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }


        /// <summary>
        ///
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public ESMA4 GetESMA4Data(string dealName, DateTime ipdDate, string userName, int poolId)
        {
            ESMA4 esma4 = new ESMA4();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_ESMA4Data, conn))
            {
                if(poolId == -1)
                {
                    FetchAnnex4Data(dealName, ipdDate, userName, esma4, conn, cmd, null);
                }
                else
                {
                    FetchAnnex4Data(dealName, ipdDate, userName, esma4, conn, cmd, poolId);
                }
                
            }
            return esma4;
        }

        public ESMA4 GetFCAAnnex4Data(string dealName, DateTime ipdDate, string userName, int poolId)
        {
            ESMA4 esma4 = new ESMA4();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FCA4Data, conn))
            {
                if (poolId == -1)
                {
                    FetchAnnex4Data(dealName, ipdDate, userName, esma4, conn, cmd, null);
                }
                else
                {
                    FetchAnnex4Data(dealName, ipdDate, userName, esma4, conn, cmd, poolId);
                }
            }
            return esma4;
        }

        private static void FetchAnnex4Data(string dealName, DateTime ipdDate, string userName, ESMA4 esma4, SqlConnection conn, SqlCommand cmd, int? poolId)
        {
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, ipdDate);
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamDealName, dealName);
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
            cmd.CommandTimeout = 0;
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    esma4.esma4Collateral.Add(new ESMA4Collateral()
                    {
                        UniqueIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralUniqueIdentifier]),
                        UnderlyingExposureIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralUnderlyingExposureIdentifier]),
                        OriginalCollateralIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralOriginalCollateralIdentifier]),
                        NewCollateralIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralNewCollateralIdentifier]),
                        GeographicRegionCollateral = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralGeographicRegionCollateral]),
                        SecurityType = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralSecurityType]),
                        ChargeType = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralChargeType]),
                        Lien = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralLien]),
                        CollateralType = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralCollateralType]),
                        CurrentValuationAmount = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralCurrentValuationAmount]),
                        CurrentValuationMethod = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralCurrentValuationMethod]),
                        CurrentValuationDate = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralCurrentValuationDate]),
                        OriginalValuationAmount = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralOriginalValuationAmount]),
                        OriginalValuationMethod = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralOriginalValuationMethod]),
                        OriginalValuationDate = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralOriginalValuationDate]),
                        DateOfSale = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralDateOfSale]),
                        SalePrice = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralSalePrice]),
                        CollateralCurrency = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralCollateralCurrency]),
                        GuarantorCountry = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralGuarantorCountry]),
                        GuarantorESASubsector = Utility.GetString(reader[DbConstants.DbFieldESMA4CollateralGuarantorESASubsector])
                    });
                }
            }
            reader.NextResult();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    esma4.esma4Exposure.Add(new ESMA4Exposure()
                    {
                        UniqueIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureUniqueIdentifier]),
                        OriginalUnderlyingExposureIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginalUnderlyingExposureIdentifier]),
                        NewUnderlyingExposureIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureNewUnderlyingExposureIdentifier]),
                        OriginalObligorIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginalObligorIdentifier]),
                        NewObligorIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureNewObligorIdentifier]),
                        DataCutOffDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDataCutOffDate]),
                        PoolAdditionDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePoolAdditionDate]),
                        DateOfRepurchase = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDateOfRepurchase]),
                        RedemptionDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRedemptionDate]),
                        GeographicRegionObligor = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureGeographicRegionObligor]),
                        GeographicRegionClassification = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureGeographicRegionClassification]),
                        CreditImpairedObligor = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCreditImpairedObligor]),
                        CustomerType = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCustomerType]),
                        NACEIndustryCode = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureNACEIndustryCode]),
                        ObligorBaselIIISegment = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureObligorBaselIIISegment]),
                        EnterpriseSize = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureEnterpriseSize]),
                        Revenue = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRevenue]),
                        TotalDebt = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureTotalDebt]),
                        EBITDA = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureEBITDA]),
                        EnterpriseValue = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureEnterpriseValue]),
                        FreeCashflow = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureFreeCashflow]),
                        DateOfFinancials = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDateOfFinancials]),
                        FinancialStatementCurrency = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureFinancialStatementCurrency]),
                        DebtType = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDebtType]),
                        SecuritisedReceivables = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureSecuritisedReceivables]),
                        InternationalSecuritiesIdentificationNumber = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInternationalSecuritiesIdentificationNumber]),
                        Seniority = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureSeniority]),
                        Syndicated = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureSyndicated]),
                        LeveragedTransaction = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureLeveragedTransaction]),
                        ManagedByCLO = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureManagedByCLO]),
                        PaymentInKind = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePaymentInKind]),
                        SpecialScheme = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureSpecialScheme]),
                        OriginationDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginationDate]),
                        MaturityDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureMaturityDate]),
                        OriginationChannel = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginationChannel]),
                        Purpose = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePurpose]),
                        CurrencyDenomination = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrencyDenomination]),
                        OriginalPrincipalBalance = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginalPrincipalBalance]),
                        CurrentPrincipalBalance = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrentPrincipalBalance]),
                        PriorPrincipalBalances = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePriorPrincipalBalances]),
                        MarketValue = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureMarketValue]),
                        TotalCreditLimit = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureTotalCreditLimit]),
                        PurchasePrice = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePurchasePrice]),
                        PutDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePutDate]),
                        PutStrike = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePutStrike]),
                        AmortisationType = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureAmortisationType]),
                        PrincipalGracePeriodEndDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePrincipalGracePeriodEndDate]),
                        ScheduledPrincipalPaymentFrequency = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureScheduledPrincipalPaymentFrequency]),
                        ScheduledInterestPaymentFrequency = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureScheduledInterestPaymentFrequency]),
                        PaymentDue = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePaymentDue]),
                        BalloonAmount = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureBalloonAmount]),
                        InterestRateType = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateType]),
                        CurrentInterestRate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrentInterestRate]),
                        CurrentInterestRateIndex = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrentInterestRateIndex]),
                        CurrentInterestRateIndexTenor = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrentInterestRateIndexTenor]),
                        CurrentInterestRateMargin = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrentInterestRateMargin]),
                        InterestRateResetInterval = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateResetInterval]),
                        InterestRateCap = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateCap]),
                        InterestRateFloor = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateFloor]),
                        RevisionMargin1 = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRevisionMargin1]),
                        InterestRevisionDate1 = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRevisionDate1]),
                        RevisionMargin2 = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRevisionMargin2]),
                        InterestRevisionDate2 = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRevisionDate2]),
                        RevisionMargin3 = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRevisionMargin3]),
                        InterestRevisionDate3 = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRevisionDate3]),
                        RevisedInterestRateIndex = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRevisedInterestRateIndex]),
                        RevisedInterestRateIndexTenor = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRevisedInterestRateIndexTenor]),
                        NumberOfPaymentsBeforeSecuritisation = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureNumberOfPaymentsBeforeSecuritisation]),
                        PercentageOfPrepaymentsAllowedPerYear = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePercentageOfPrepaymentsAllowedPerYear]),
                        PrepaymentLockOutEndDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePrepaymentLockOutEndDate]),
                        PrepaymentFee = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePrepaymentFee]),
                        PrepaymentFeeEndDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePrepaymentFeeEndDate]),
                        PrepaymentDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposurePrepaymentDate]),
                        CumulativePrepayments = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCumulativePrepayments]),
                        DateOfRestructuring = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDateOfRestructuring]),
                        DateLastInArrears = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDateLastInArrears]),
                        ArrearsBalance = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureArrearsBalance]),
                        NumberOfDaysInArrears = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureNumberOfDaysInArrears]),
                        AccountStatus = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureAccountStatus]),
                        ReasonForDefaultorForeclosure = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureReasonForDefaultorForeclosure]),
                        DefaultAmount = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDefaultAmount]),
                        DefaultDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDefaultDate]),
                        AllocatedLosses = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureAllocatedLosses]),
                        CumulativeRecoveries = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCumulativeRecoveries]),
                        RecoverySource = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRecoverySource]),
                        Recourse = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureRecourse]),
                        DepositAmount = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureDepositAmount]),
                        InterestRateSwapNotional = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateSwapNotional]),
                        InterestRateSwapProviderLegalEntityIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateSwapProviderLegalEntityIdentifier]),
                        InterestRateSwapProvider = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateSwapProvider]),
                        InterestRateSwapMaturityDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureInterestRateSwapMaturityDate]),
                        CurrencySwapNotional = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrencySwapNotional]),
                        CurrencySwapProviderLegalEntityIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrencySwapProviderLegalEntityIdentifier]),
                        CurrencySwapProvider = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrencySwapProvider]),
                        CurrencySwapMaturityDate = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureCurrencySwapMaturityDate]),
                        OriginalLenderName = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginalLenderName]),
                        OriginalLenderLegalEntityIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginalLenderLegalEntityIdentifier]),
                        OriginalLenderEstablishmentCountry = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginalLenderEstablishmentCountry]),
                        OriginatorName = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginatorName]),
                        OriginatorLegalEntityIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginatorLegalEntityIdentifier]),
                        OriginatorEstablishmentCountry = Utility.GetString(reader[DbConstants.DbFieldESMA4ExposureOriginatorEstablishmentCountry])
                    });
                }
            }
        }



        /// <summary>
        ///
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public ESMA9 GetESMA9Data(string dealName, DateTime ipdDate, string userName, int poolId)
        {
            ESMA9 esma9 = new ESMA9();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_ESMA9Data, conn))
            {
                if (poolId == -1)
                {
                    FetchAnnex9Data(dealName, ipdDate, userName, esma9, conn, cmd, null);
                }
                else
                {
                    FetchAnnex9Data(dealName, ipdDate, userName, esma9, conn, cmd, poolId);
                }
                    
            }
            return esma9;
        }

        public ESMA9 GetFCAAnnex9Data(string dealName, DateTime ipdDate, string userName, int poolId)
        {
            ESMA9 FCA9 = new ESMA9();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_FCA9Data, conn))
            {
                if (poolId == -1)
                {
                    FetchAnnex9Data(dealName, ipdDate, userName, FCA9, conn, cmd, null);
                }
                else
                {
                    FetchAnnex9Data(dealName, ipdDate, userName, FCA9, conn, cmd, poolId);
                }
                   
            }
            return FCA9;
        }

        private static void FetchAnnex9Data(string dealName, DateTime ipdDate, string userName, ESMA9 esma9, SqlConnection conn, SqlCommand cmd, int? poolId)
        {
            conn.Open();
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, ipdDate);
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamDealName, dealName);
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
            cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
            cmd.CommandTimeout = 0;
            SqlDataReader reader = cmd.ExecuteReader();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    esma9.esma9Collateral.Add(new ESMA9Collateral()
                    {
                        UniqueIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralUniqueIdentifier]),
                        OriginalUnderlyingExposureIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralUnderlyingExposureIdentifier]),
                        OriginalCollateralIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralOriginalCollateralIdentifier]),
                        NewCollateralIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralNewCollateralIdentifier]),
                        GeographicRegionCollateral = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralGeographicRegionCollateral]),
                        SecurityType = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralSecurityType]),
                        ChargeType = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralChargeType]),
                        Lien = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralLien]),
                        CollateralType = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralCollateralType]),
                        CurrentValuationAmount = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralCurrentValuationAmount]),
                        CurrentValuationMethod = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralCurrentValuationMethod]),
                        CurrentValuationDate = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralCurrentValuationDate]),
                        CurrentLoanToValue = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralCurrentLoanToValue]),
                        OriginalValuationAmount = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralOriginalValuationAmount]),
                        OriginalValuationMethod = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralOriginalValuationMethod]),
                        OriginalValuationDate = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralOriginalValuationDate]),
                        OriginalLoanToValue = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralOriginalLoanToValue]),
                        DateOfSale = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralDateOfSale]),
                        SalePrice = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralSalePrice]),
                        CollateralCurrency = Utility.GetString(reader[DbConstants.DbFieldESMA9CollateralCollateralCurrency])
                    });
                }
            }
            reader.NextResult();
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    esma9.esma9Exposure.Add(new ESMA9Exposure()
                    {
                        UniqueIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureUniqueIdentifier]),
                        OriginalUnderlyingExposureIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginalUnderlyingExposureIdentifier]),
                        NewUnderlyingExposureIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureNewUnderlyingExposureIdentifier]),
                        OriginalObligorIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginalObligorIdentifier]),
                        NewObligorIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureNewObligorIdentifier]),
                        DataCutOffDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDataCutOffDate]),
                        PoolAdditionDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePoolAdditionDate]),
                        DateOfRepurchase = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDateOfRepurchase]),
                        RedemptionDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureRedemptionDate]),
                        Description = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDescription]),
                        GeographicRegionObligor = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureGeographicRegionObligor]),
                        GeographicRegionClassification = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureGeographicRegionClassification]),
                        EmploymentStatus = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureEmploymentStatus]),
                        CreditImpairedObligor = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCreditImpairedObligor]),
                        ObligorLegalType = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureObligorLegalType]),
                        SICCode = Utility.GetString(reader[DbConstants.DbFieldESMA9SICCode]),
                        PrimaryIncome = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrimaryIncome]),
                        PrimaryIncomeType = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrimaryIncomeType]),
                        PrimaryIncomeCurrency = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrimaryIncomeCurrency]),
                        PrimaryIncomeVerification = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrimaryIncomeVerification]),
                        Revenue = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureRevenue]),
                        FinancialStatementCurrency = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureFinancialStatementCurrency]),
                        InternationalSecuritiesIdentificationNumber = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureInternationalSecuritiesIdentificationNumber]),
                        OriginationDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginationDate]),
                        MaturityDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureMaturityDate]),
                        CurrencyDenomination = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCurrencyDenomination]),
                        OriginalPrincipalBalance = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginalPrincipalBalance]),
                        CurrentPrincipalBalance = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCurrentPrincipalBalance]),
                        TotalCreditLimit = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureTotalCreditLimit]),
                        PurchasePrice = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePurchasePrice]),
                        AmortisationType = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureAmortisationType]),
                        PrincipalGracePeriodEndDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrincipalGracePeriodEndDate]),
                        ScheduledPrincipalPaymentFrequency = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureScheduledPrincipalPaymentFrequency]),
                        ScheduledInterestPaymentFrequency = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureScheduledInterestPaymentFrequency]),
                        PaymentDue = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePaymentDue]),
                        DebtToIncomeRatio = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDebtToIncomeRatio]),
                        BalloonAmount = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureBalloonAmount]),
                        InterestRateResetInterval = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureInterestRateResetInterval]),
                        CurrentInterestRate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCurrentInterestRate]),
                        CurrentInterestRateIndex = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCurrentInterestRateIndex]),
                        CurrentInterestRateIndexTenor = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCurrentInterestRateIndexTenor]),
                        CurrentInterestRateMargin = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCurrentInterestRateMargin]),
                        InterestRateCap = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureInterestRateCap]),
                        InterestRateFloor = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureInterestRateFloor]),
                        NumberOfPaymentsBeforeSecuritisation = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureNumberOfPaymentsBeforeSecuritisation]),
                        PercentageOfPrepaymentsAllowedPerYear = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePercentageOfPrepaymentsAllowedPerYear]),
                        PrepaymentLockOutEndDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrepaymentLockOutEndDate]),
                        PrepaymentFee = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrepaymentFee]),
                        PrepaymentFeeEndDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrepaymentFeeEndDate]),
                        PrepaymentDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposurePrepaymentDate]),
                        CumulativePrepayments = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCumulativePrepayments]),
                        DateLastInArrears = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDateLastInArrears]),
                        ArrearsBalance = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureArrearsBalance]),
                        NumberOfDaysInArrears = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureNumberOfDaysInArrears]),
                        AccountStatus = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureAccountStatus]),
                        ReasonForDefaultorForeclosure = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureReasoForDefaultorForeclosure]),
                        DefaultAmount = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDefaultAmount]),
                        DefaultDate = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureDefaultDate]),
                        AllocatedLosses = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureAllocatedLosses]),
                        CumulativeRecoveries = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureCumulativeRecoveries]),
                        OriginalLenderName = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginalLenderName]),
                        OriginalLenderLegalEntityIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginalLenderLegalEntityIdentifier]),
                        OriginalLenderEstablishmentCountry = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginalLenderEstablishmentCountry]),
                        OriginatorName = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginatorName]),
                        OriginatorLegalEntityIdentifier = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginatorLegalEntityIdentifier]),
                        OriginatorEstablishmentCountry = Utility.GetString(reader[DbConstants.DbFieldESMA9ExposureOriginatorEstablishmentCountry]),
                    });
                }
            }
        }

    }

}
