﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Report.DataService;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using NW.SFP.Message.SFP.Model;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.Message.Report.ReportConfigs;
using static NW.SFP.DataService.Report.ReportDBConstants;

namespace NW.SFP.DataService.Report
{
    public class ReportDataService : IReportDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;
        private readonly IOptions<ReportSettings> _reportSettings;
        public ReportDataService(IOptions<DataServiceSettings> setting, IOptions<ReportSettings> reportSettings)
        {
            _settings = setting;
            this._reportSettings = reportSettings;
        }
        public ReportConfigs GetReportConfig(string loggedInUserName)
        {
            var reportConfigs = new ReportConfigs();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetReports, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportConfigs.Reports.Add(new ReportDetail
                            {
                                ReportName = Utility.GetString(resultReader[DbFieldReportName]),
                                ReportId = Utility.GetInt(resultReader[DbFieldReportId]),
                                ValidationStoredProcedure = Utility.GetString(resultReader[DbFieldValidationStoredProc]),
                                ShortName = Utility.GetString(resultReader[DbFieldReportShortName]),
                                Category = Utility.GetString(resultReader[DbFieldReportCategory]),
                            });
                        }
                    }
                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportConfigs.Brands.Add(new Brand
                            {
                                BrandCode = Utility.GetString(resultReader[DbFieldBrandCode])
                            }); ;
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportConfigs.Deals.Add(new Deal
                            {
                                DealName = Utility.GetString(resultReader[DbFieldDealName]),
                                DealStatus = Utility.GetString(resultReader[DbFieldDealStatus])
                            }); ;
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportConfigs.DealTypes.Add(new DealType
                            {
                                Type = Utility.GetString(resultReader[DbFieldDealType])
                            }); ;
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportConfigs.Regions.Add(new Region() { RegionName = Utility.GetString(resultReader[DbFieldRegionCode]) });
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportConfigs.Tranches.Add(new Tranche() {TrancheName = Utility.GetString(resultReader[ReportDBConstants.DbFieldTrancheName]) });
                        }
                    }
                }
            }
            reportConfigs.OutputFolderUri = this._reportSettings.Value.DataOutputFolderPath;
            return reportConfigs;
        }

        public IList<HypoPool> GetHypoPools(string loggedInUserName, int assetClassId, int poolStatusId)
        {
            var pools = new List<HypoPool>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetHypoPools, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbFieldUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbFieldAssetClassId, assetClassId);
                cmd.Parameters.AddWithValue(DbFieldPoolStatusId, poolStatusId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            pools.Add(new HypoPool
                            {
                                PoolId = Utility.GetInt(resultReader[DbFieldPoolId]),
                                PoolDescription = Utility.GetString(resultReader[DbFieldPoolDescription])
                            }); 
                        }
                    }
                }
                return pools;
            }
        }

        public Message.Report.Report GetReports(string loggedInUserName, int id)
        {
            var report = new Message.Report.Report();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetReportAndParams, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbFieldUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbFieldReportIdInput, id);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            report.ReportName = Utility.GetString(resultReader[DbFieldReportName]);
                            report.ReportId = Utility.GetInt(resultReader[DbFieldReportId]);
                            report.ValidationStoredProcedure = Utility.GetString(resultReader[DbFieldValidationStoredProc]);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            report.Parameters.Add(new Message.Report.Report.ReportParameter
                            {
                                ParameterName = Utility.GetString(resultReader[DbFieldReportParamName]),
                                ReportId = Utility.GetInt(resultReader[DbFieldReportId]),
                                ReportParameterId = Utility.GetInt(resultReader[DbFieldReportParamId]),
                                IsParameterMandatory = Utility.GetString(resultReader[DbFieldReportIsParamMandatory]),
                                IsMultiValue = Utility.GetString(resultReader[DbFieldReportIsMultiValue]),
                                ParameterDataType = Utility.GetString(resultReader[DbFieldReportParamDataType]),
                                ParameterRegex = Utility.GetString(resultReader[DbFieldReportParamRegex]),
                                ParameterHelp = Utility.GetString(resultReader[DbFieldReportParamHelp]),
                                ParameterCamelCaseName = Utility.GetString(resultReader[DbFieldReportParameterCamelCaseName]),
                                DisplayOrder = Utility.GetInt(resultReader[DbFieldReportParamDisplayOrder]),
                                DisplayName = Utility.GetString(resultReader[DbFieldReportParamDisplayName])
                            });
                        }
                    }
                }
                return report;
            }
        }

        public SfpBatchDataModel SetReportForQueue(string loggedInUserName, Message.Report.Report report)
        {
            SfpBatchDataModel reportModel = new SfpBatchDataModel();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_SetReportForQueue, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();                

                var reportDateParameter = report.Parameters.Where(x => x.ParameterName.Equals("AsAtDate", StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                var hypoPoolParameter = report.Parameters.Where(x => x.ParameterName.Equals("HypoPool", StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();
                var dealNameParameter = report.Parameters.Where(x => x.ParameterName.Equals("DealName", StringComparison.InvariantCultureIgnoreCase)).FirstOrDefault();

                var poolName = (!string.IsNullOrWhiteSpace(dealNameParameter?.Value))
                        ? dealNameParameter.Value
                        : (!string.IsNullOrWhiteSpace(hypoPoolParameter?.Value)) ? hypoPoolParameter.Value : null;

                var reportDate = (!string.IsNullOrWhiteSpace(reportDateParameter.Value))
                    ? Convert.ToDateTime(reportDateParameter.Value).ToString("yyyy-MM-dd") : null;

                SetParametersForSP(loggedInUserName, report, cmd, poolName, reportDate);
                try
                {
                    cmd.ExecuteNonQuery();
                }
                catch (SqlException ex)
                {
                    if (ex.Class == 16)
                    {
                        reportModel.IsResultValid = false;
                        reportModel.ValidationErrorMessage = ex.Message;
                    }
                    else
                        throw;                   
                   
                }
                
                if (cmd.Parameters[DbFieldReportBatchId].Value != DBNull.Value && Utility.GetInt(cmd.Parameters[DbFieldReportBatchId].Value) > 0)
                {
                    reportModel.BatchId = Convert.ToInt32(cmd.Parameters[DbFieldReportBatchId].Value);
                    reportModel.IsResultValid = true;
                }
            }
            return reportModel;
        }

        public IList<ReportQueue> GetReportQueue(string loggedInUserName)
        {
            var reportQueues = new List<ReportQueue>();
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetReportQueue, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbFieldUserName, loggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportQueues.Add(new ReportQueue()
                            {
                                ReportName = Utility.GetString(resultReader["ReportName"]),
                                ReportStatus = Utility.GetString(resultReader["ReportStatus"]),
                                BatchReportId = Utility.GetInt(resultReader["BatchReportId"]),
                                GeneratedName = Utility.GetString(resultReader["GeneratedName"]),
                                StartDateTime = Utility.GetDateTimeNullable(resultReader["StartDateTime"]),
                                FinishDateTime = Utility.GetDateTimeNullable(resultReader["FinishDateTime"]),
                                ReportPath = Utility.GetString(resultReader["ReportPath"]),
                                BatchParameters = Utility.GetString(resultReader["BatchParameters"]),
                                ReportTemplateName = Utility.GetString(resultReader["ReportTemplateName"]),
                                UserName = Utility.GetString(resultReader["UserName"])
                            });
                        }
                    }
                }
                }

            return reportQueues;
        }

        #region Private Actions
        private void SetParametersForSP(string loggedInUserName, Message.Report.Report report, SqlCommand cmd, string poolName, string reportDate)
        {
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue(DbFieldUserName, loggedInUserName);

            SetReportParametersValues(report, cmd);

            cmd.Parameters.AddWithValue(DbFieldReportIdInput, report.ReportId);
            cmd.Parameters.AddWithValue(DbFieldReportDate, reportDate);
            cmd.Parameters.AddWithValue(DbFieldReportPoolName, poolName);
            cmd.Parameters.Add(DbFieldReportBatchId, SqlDbType.Int);
            cmd.Parameters[DbFieldReportBatchId].Direction = ParameterDirection.Output;
        }

        private void SetReportParametersValues(Message.Report.Report report, SqlCommand cmd)
        {
            var paramValues = new DataTable();
            paramValues.Columns.Add(DbTypeTableTypeId, typeof(Int32));
            paramValues.Columns.Add(DbTypeTableTypeValue, typeof(string));
            report.Parameters.ForEach(param =>
            {
                if (param.ParameterDataType.ToLower().Equals("date") && !string.IsNullOrEmpty(param.Value)) 
                {
                    param.Value = Convert.ToDateTime(param.Value).ToString("yyyy-MM-dd");
                }
                if (param.Value != null)
                {
                    paramValues.Rows.Add(param.ReportParameterId, param.Value);
                }
                
            });

            cmd.Parameters.Add(new SqlParameter(DbFieldParamList, SqlDbType.Structured)
            {
                TypeName = DbTypeIntVarTableType,
                Value = paramValues
            });
        }
        #endregion
    }
}
