﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.Report;
using NW.SFP.Interface.Report.BusinessService;
using NW.SFP.Interface.Report.DataService;
using NW.SFP.Message.Core;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.Report.NWMReport
{
   public class NWMReportsDataService: INWMReportsDataService  
    {
        private readonly IOptions<DataServiceSettings> _settings;
        
        public NWMReportsDataService(IOptions<DataServiceSettings> settings)
        {
            _settings = settings;
        }        

        public List<AssetRegisterReportEntity> GenerateAssestReportData(DateTime asAtDate, string userName)
        {           
            List <AssetRegisterReportEntity > nwmAsset = new List<AssetRegisterReportEntity>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GenerateAssetRegisterReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, Utility.GetShortDateTime(asAtDate));
                cmd.CommandTimeout = 0;
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nwmAsset.Add(new AssetRegisterReportEntity()
                        {
                            AsAtDate = Utility.GetString(reader[DbConstants.AssetDbFieldAsAtDate]),
                            FacilityCurrencyConcatenationString = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityCurrencyConcatenationString]),
                            FacilityCurrencyCISConcatenationString = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityCurrencyCISConcatenationString]),
                            DealName = Utility.GetString(reader[DbConstants.AssetDbFieldDealName]),
                            FacilityFCN = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityFCN]),
                            FacilityPrismId = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityPrismId]),
                            FacilityName = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityName]),
                            PrismIDorFCNid = Utility.GetString(reader[DbConstants.AssetDbFieldPrismIDorFCNid]),
                            FacilityCcy = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityCcy]),
                            OSTCcy = Utility.GetString(reader[DbConstants.AssetDbFieldOSTCcy]),
                            FacilityType = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityType]),
                            Book = Utility.GetString(reader[DbConstants.AssetDbFieldBook]),
                            HostBankNetCommitment = Utility.GetString(reader[DbConstants.AssetDbFieldHostBankNetCommitment]),
                            HostBankNetOutstanding = Utility.GetString(reader[DbConstants.AssetDbFieldHostBankNetOutstanding]),
                            DrawnEUR = Utility.GetString(reader[DbConstants.AssetDbFieldDrawnEUR]),
                            DrawnGBP = Utility.GetString(reader[DbConstants.AssetDbFieldDrawnGBP]),
                            DrawnUSD = Utility.GetString(reader[DbConstants.AssetDbFieldDrawnUSD]),
                            DrawnJPY = Utility.GetString(reader[DbConstants.AssetDbFieldDrawnJPY]),
                            RelationsPrimaryKey = Utility.GetString(reader[DbConstants.AssetDbFieldRelationsPrimaryKey]),
                            TradeAllocated = Utility.GetString(reader[DbConstants.AssetDbFieldTradeAllocated]),
                            FacilityCurrencyConcatenationString1 = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityCurrencyConcatenationString]),
                            PercentAllocatedToTrade = Utility.GetString(reader[DbConstants.AssetDbFieldPercentAllocatedToTrade]),
                            EncumberedIndicator = Utility.GetString(reader[DbConstants.AssetDbFieldEncumberedIndicator]),
                            EncumberedCCY = Utility.GetString(reader[DbConstants.AssetDbFieldEncumberedCCY]),
                            EncumberedGBP = Utility.GetString(reader[DbConstants.AssetDbFieldEncumberedGBP]),
                            EncumberedEUR = Utility.GetString(reader[DbConstants.AssetDbFieldEncumberedEUR]),
                            OSTHostBankNet = Utility.GetString(reader[DbConstants.AssetDbFieldOSTHostBankNet]),
                            EncumberedUSD = Utility.GetString(reader[DbConstants.AssetDbFieldEncumberedUSD]),
                            EncumberedJPY = Utility.GetString(reader[DbConstants.AssetDbFieldEncumberedJPY]),
                            AvailableCCY = Utility.GetString(reader[DbConstants.AssetDbFieldAvailableCCY]),
                            AgreementDate = Utility.GetString(reader[DbConstants.AssetDbFieldAgreementDate]),
                            AvailableGBP = Utility.GetString(reader[DbConstants.AssetDbFieldAvailableGBP]),
                            AvailableEUR = Utility.GetString(reader[DbConstants.AssetDbFieldAvailableEUR]),
                            FinalMaturityDate = Utility.GetString(reader[DbConstants.AssetDbFieldFinalMaturityDate]),
                            AvailableUSD = Utility.GetString(reader[DbConstants.AssetDbFieldAvailableUSD]),
                            AvailableJPY = Utility.GetString(reader[DbConstants.AssetDbFieldAvailableJPY]),
                            AllocationTimestamp = Utility.GetString(reader[DbConstants.AssetDbFieldAllocationTimestamp]),
                            AllocationUser = Utility.GetString(reader[DbConstants.AssetDbFieldAllocationUser]),
                            AllocatedTo = Utility.GetString(reader[DbConstants.AssetDbFieldAllocatedTo]),
                            ISIN = Utility.GetString(reader[DbConstants.AssetDbFieldISIN]),
                            CollateralAssetCompanyNucleusId = Utility.GetString(reader[DbConstants.AssetDbFieldCollateralAssetCompanyNucleusId]),
                            TradeGroup = Utility.GetString(reader[DbConstants.AssetDbFieldTradeGroup]),
                            VAndRA = Utility.GetString(reader[DbConstants.AssetDbFieldVAndRA]),
                            ScheduledMaturity = Utility.GetString(reader[DbConstants.AssetDbFieldScheduledMaturity]),
                            ReportingTemplate = Utility.GetString(reader[DbConstants.AssetDbFieldReportingTemplate]),
                            BorrowerCIS = Utility.GetString(reader[DbConstants.AssetDbFieldBorrowerCIS]),
                            BorrowerName = Utility.GetString(reader[DbConstants.AssetDbFieldBorrowerName]),
                            CountryOfResidence = Utility.GetString(reader[DbConstants.AssetDbFieldCountryOfResidence]),
                            CountryOfIncorporation = Utility.GetString(reader[DbConstants.AssetDbFieldCountryOfIncorporation]),
                            CountryOfRisk = Utility.GetString(reader[DbConstants.AssetDbFieldCountryOfRisk]),
                            Agent = Utility.GetString(reader[DbConstants.AssetDbFieldAgent]),
                            CompanyNumber = Utility.GetString(reader[DbConstants.AssetDbFieldCompanyNumber]),
                            Lev1 = Utility.GetString(reader[DbConstants.AssetDbFieldLev1]),
                            Lev2 = Utility.GetString(reader[DbConstants.AssetDbFieldLev2]),
                            Lev3 = Utility.GetString(reader[DbConstants.AssetDbFieldLev3]),
                            Sponsor = Utility.GetString(reader[DbConstants.AssetDbFieldSponsor]),
                            BorrowerInternalRating = Utility.GetString(reader[DbConstants.AssetDbFieldBorrowerInternalRating]),
                            BorrowerInternalRatingImplied = Utility.GetString(reader[DbConstants.AssetDbFieldBorrowerInternalRatingImplied]),
                            GradingScale = Utility.GetString(reader[DbConstants.AssetDbFieldGradingScale]),
                            GradingModel = Utility.GetString(reader[DbConstants.AssetDbFieldGradingModel]),
                            RatingApprovalDate = Utility.GetString(reader[DbConstants.AssetDbFieldRatingApprovalDate]),
                            IBCALongTermRating = Utility.GetString(reader[DbConstants.AssetDbFieldIBCALongTermRating]),
                            UltimateRiskParentCISCode = Utility.GetString(reader[DbConstants.AssetDbFieldUltimateRiskParentCISCode]),
                            MoodysLongTermCPRatingGrdm = Utility.GetString(reader[DbConstants.AssetDbFieldMoodysLongTermCPRatingGrdm]),
                            SPLongTermRatingGrdm = Utility.GetString(reader[DbConstants.AssetDbFieldSPLongTermRatingGrdm]),
                            DoTEligible = Utility.GetString(reader[DbConstants.AssetDbFieldDoTEligible]),
                            ECBEligible = Utility.GetString(reader[DbConstants.AssetDbFieldECBEligible]),
                            NoBorrowerSetOff = Utility.GetString(reader[DbConstants.AssetDbFieldNoBorrowerSetOff]),
                            ContractLaw = Utility.GetString(reader[DbConstants.AssetDbFieldContractLaw]),
                            W8Sent = Utility.GetString(reader[DbConstants.AssetDbFieldW8Sent]),
                            FacilityWarnings = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityWarnings]),
                            EligibilityComments1 = Utility.GetString(reader[DbConstants.AssetDbFieldEligibilityComments1]),
                            EligibilityComments2 = Utility.GetString(reader[DbConstants.AssetDbFieldEligibilityComments2]),
                            EligibilityComments3 = Utility.GetString(reader[DbConstants.AssetDbFieldEligibilityComments3]),
                            FacilityEncumberedOutsideProcess = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityEncumberedOutsideProcess]),
                            TimeToLegalMaturity = Utility.GetString(reader[DbConstants.AssetDbFieldTimeToLegalMaturity]),
                            TimeToLegalMaturityBucket = Utility.GetString(reader[DbConstants.AssetDbFieldTimeToLegalMaturityBucket]),
                            IneligibilityExceptions = Utility.GetString(reader[DbConstants.AssetDbFieldIneligibilityExceptions]),
                            Entity = Utility.GetString(reader[DbConstants.AssetDbFieldEntity]),
                            CountryOfTaxClassification = Utility.GetString(reader[DbConstants.AssetDbFieldCountryOfTaxClassification]),
                            CountryOfTaxNote = Utility.GetString(reader[DbConstants.AssetDbFieldCountryOfTaxNote]),
                            IneligibilityValidation = Utility.GetString(reader[DbConstants.AssetDbFieldIneligibilityValidation]),
                            AssessmentNeeded = Utility.GetString(reader[DbConstants.AssetDbFieldAssessmentNeeded]),
                            ConditionPrecedents = Utility.GetString(reader[DbConstants.AssetDbFieldConditionPrecedents]),
                            SNPEligibility = Utility.GetString(reader[DbConstants.AssetDbFieldSNPEligibility]),
                            RSFUnencumbered = Utility.GetString(reader[DbConstants.AssetDbFieldRSFUnencumbered]),
                            TopCoCISCodeEncrypted = Utility.GetString(reader[DbConstants.AssetDbFieldTopCoCISCodeEncrypted]),
                            LegalEntityCISCodeEncrypted = Utility.GetString(reader[DbConstants.AssetDbFieldLegalEntityCISCodeEncrypted]),
                            ClientClassification = Utility.GetString(reader[DbConstants.AssetDbFieldClientClassification]),
                            SeniorityRank = Utility.GetString(reader[DbConstants.AssetDbFieldSeniorityRank]),
                            FacilityInternalRating = Utility.GetString(reader[DbConstants.AssetDbFieldFacilityInternalRating]),
                            DeskDesc = Utility.GetString(reader[DbConstants.AssetDbFieldDeskDesc]),
                            SubDeskDesc = Utility.GetString(reader[DbConstants.AssetDbFieldSubDeskDesc]),
                            CostCentreName = Utility.GetString(reader[DbConstants.AssetDbFieldCostCentreName]),
                            CostCentreDesc = Utility.GetString(reader[DbConstants.AssetDbFieldCostCentreDesc]),
                            CountryOfBalanceSheetLocation = Utility.GetString(reader[DbConstants.AssetDbFieldCountryOfBalanceSheetLocation]),
                            TradingBankingIndicator = Utility.GetString(reader[DbConstants.AssetDbFieldTradingBankingIndicator]),
                            DivisionName = Utility.GetString(reader[DbConstants.AssetDbFieldDivisionName]),
                            BusinessConsolidation1Desc = Utility.GetString(reader[DbConstants.AssetDbFieldBusinessConsolidation1Desc]),
                            BusinessConsolidation2Desc = Utility.GetString(reader[DbConstants.AssetDbFieldBusinessConsolidation2Desc]),
                            BusinessConsolidation3Desc = Utility.GetString(reader[DbConstants.AssetDbFieldBusinessConsolidation3Desc]),
                            BusinessConsolidation4Desc = Utility.GetString(reader[DbConstants.AssetDbFieldBusinessConsolidation4Desc]),
                            BusinessConsolidation5Desc = Utility.GetString(reader[DbConstants.AssetDbFieldBusinessConsolidation5Desc]),
                            SicCode = Utility.GetString(reader[DbConstants.DbFieldSicCode]),
							ContractualSeniority = Utility.GetString(reader[DbConstants.AssetDbFieldContractualSeniority]),
                        });
                    }
                }                
                
            }
            return nwmAsset;
        }

        
        public List<LoansOutstandingReportEntity> GenerateLoansOutstandingReportData(DateTime asAtDate, string userName)
        {
            List<LoansOutstandingReportEntity> nwmout = new List<LoansOutstandingReportEntity>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GenerateLoansoutstandingReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, Utility.GetShortDateTime(asAtDate));
                cmd.CommandTimeout = 0;
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        nwmout.Add(new LoansOutstandingReportEntity()
                        {
                            FacilityCurrencyConcatenationString = Utility.GetString(reader[DbConstants.DbFieldFacilityCurrencyConcatenationString]),
                            AsAtDate = Utility.GetString(reader[DbConstants.DbFieldAsAtDate]),
                            PrimaryKey = Utility.GetString(reader[DbConstants.DbFieldPrimaryKey]),
                            FacilityCurrencyCISConcatenationString = Utility.GetString(reader[DbConstants.DbFieldFacilityCurrencyCISConcatenationString]),
                            DealName = Utility.GetString(reader[DbConstants.DbFieldDealName]),
                            FacilityFCN = Utility.GetString(reader[DbConstants.DbFieldFacilityFCN]),
                            FacilityName = Utility.GetString(reader[DbConstants.DbFieldFacilityName]),
                            PrismIDorFCNid = Utility.GetString(reader[DbConstants.DbFieldPrismIDorFCNid]),
                            FacilityPrismId = Utility.GetString(reader[DbConstants.DbFieldFacilityPrismId]),
                            FacilityStatus = Utility.GetString(reader[DbConstants.DbFieldFacilityStatus]),
                            FacilityType = Utility.GetString(reader[DbConstants.DbFieldFacilityType]),
                            FacilityANSIId = Utility.GetString(reader[DbConstants.DbFieldFacilityANSIId]),
                            LiqRiskBookCode = Utility.GetString(reader[DbConstants.DbFieldLiqRiskBookCode]),
                            AgreementDate = Utility.GetString(reader[DbConstants.DbFieldAgreementDate]),
                            EffectiveDate = Utility.GetString(reader[DbConstants.DbFieldEffectiveDate]),
                            ExpiryDate = Utility.GetString(reader[DbConstants.DbFieldExpiryDate]),
                            FinalMaturityDate = Utility.GetString(reader[DbConstants.DbFieldFinalMaturityDate]),
                            FacilityCcy = Utility.GetString(reader[DbConstants.DbFieldFacilityCcy]),
                            MidFactorOSTCcyEUR = Utility.GetString(reader[DbConstants.DbFieldMidFactorOSTCcyEUR]),
                            DrawnEUR = Utility.GetString(reader[DbConstants.DbFieldDrawnEUR]),
                            GlobalCurrentCommitment = Utility.GetString(reader[DbConstants.DbFieldGlobalCurrentCommitment]),
                            MidFactorOSTCcyGBP = Utility.GetString(reader[DbConstants.DbFieldMidFactorOSTCcyGBP]),
                            GlobalOutstandingCommitment = Utility.GetString(reader[DbConstants.DbFieldGlobalOutstandingCommitment]),
                            DrawnGBP = Utility.GetString(reader[DbConstants.DbFieldDrawnGBP]),
                            GlobalAvailabletoDraw = Utility.GetString(reader[DbConstants.DbFieldGlobalAvailabletoDraw]),
                            MidFactorOSTCcyUSD = Utility.GetString(reader[DbConstants.DbFieldMidFactorOSTCcyUSD]),
                            DrawnUSD = Utility.GetString(reader[DbConstants.DbFieldDrawnUSD]),
                            MidFactorOSTCcyJPY = Utility.GetString(reader[DbConstants.DbFieldMidFactorOSTCcyJPY]),
                            DrawnJPY = Utility.GetString(reader[DbConstants.DbFieldDrawnJPY]),
                            HostBankNetCommitment = Utility.GetString(reader[DbConstants.DbFieldHostBankNetCommitment]),
                            HostBankNetOutstanding = Utility.GetString(reader[DbConstants.DbFieldHostBankNetOutstanding]),
                            OSTAlias = Utility.GetString(reader[DbConstants.DbFieldOSTAlias]),
                            CurrentAmount = Utility.GetString(reader[DbConstants.DbFieldCurrentAmount]),
                            OSTInternalId = Utility.GetString(reader[DbConstants.DbFieldOSTInternalId]),
                            OriginalAmount = Utility.GetString(reader[DbConstants.DbFieldOriginalAmount]),
                            MatchedFundedAmount = Utility.GetString(reader[DbConstants.DbFieldMatchedFundedAmount]),
                            OSTType = Utility.GetString(reader[DbConstants.DbFieldOSTType]),
                            NonMatchFundedAmount = Utility.GetString(reader[DbConstants.DbFieldNonMatchFundedAmount]),
                            DiscountAmount = Utility.GetString(reader[DbConstants.DbFieldDiscountAmount]),
                            OSTPricingOption = Utility.GetString(reader[DbConstants.DbFieldOSTPricingOption]),
                            OSTSource = Utility.GetString(reader[DbConstants.DbFieldOSTSource]),
                            OSTEffectiveDate = Utility.GetString(reader[DbConstants.DbFieldOSTEffectiveDate]),
                            OSTRepricingDate = Utility.GetString(reader[DbConstants.DbFieldOSTRepricingDate]),
                            OSTRePricingFreq = Utility.GetString(reader[DbConstants.DbFieldOSTRePricingFreq]),
                            OSTBaseRate = Utility.GetString(reader[DbConstants.DbFieldOSTBaseRate]),
                            OSTSpread = Utility.GetString(reader[DbConstants.DbFieldOSTSpread]),
                            FxToFac = Utility.GetString(reader[DbConstants.DbFieldFxToFac]),
                            OSTAllInRate = Utility.GetString(reader[DbConstants.DbFieldOSTAllInRate]),
                            CSPLID = Utility.GetString(reader[DbConstants.DbFieldCSPLID]),
                            OSTSpreadStartDate = Utility.GetString(reader[DbConstants.DbFieldOSTSpreadStartDate]),
                            PerfStatusCode = Utility.GetString(reader[DbConstants.DbFieldPerfStatusCode]),
                            HolidayCalendars = Utility.GetString(reader[DbConstants.DbFieldHolidayCalendars]),
                            OSTCcy = Utility.GetString(reader[DbConstants.DbFieldOSTCcy]),
                            CycleFrequencyPeriod = Utility.GetString(reader[DbConstants.DbFieldCycleFrequencyPeriod]),
                            CycleFrequencyPeriodMultiplier = Utility.GetString(reader[DbConstants.DbFieldCycleFrequencyPeriodMultiplier]),
                            OSTHostBankNet = Utility.GetString(reader[DbConstants.DbFieldOSTHostBankNet]),
                            CurrentCycleStart = Utility.GetString(reader[DbConstants.DbFieldCurrentCycleStart]),
                            Book = Utility.GetString(reader[DbConstants.DbFieldBook]),
                            CurrentCycleEndDate = Utility.GetString(reader[DbConstants.DbFieldCurrentCycleEndDate]),
                            AdjustedDueDate = Utility.GetString(reader[DbConstants.DbFieldAdjustedDueDate]),
                            EndDateRuleDesc = Utility.GetString(reader[DbConstants.DbFieldEndDateRuleDesc]),
                            ActualDueDate = Utility.GetString(reader[DbConstants.DbFieldActualDueDate]),
                            RateBasis = Utility.GetString(reader[DbConstants.DbFieldRateBasis]),
                            BorrowerLinkingString = Utility.GetString(reader[DbConstants.DbFieldBorrowerLinkingString]),
                            BorrowerRID = Utility.GetString(reader[DbConstants.DbFieldBorrowerRID]),
                            BorrowerCIS = Utility.GetString(reader[DbConstants.DbFieldBorrowerCIS]),
                            BorrowerName = Utility.GetString(reader[DbConstants.DbFieldBorrowerName]),
                            CountryOfResidence = Utility.GetString(reader[DbConstants.DbFieldCountryOfResidence]),
                            CountryOfIncorporation = Utility.GetString(reader[DbConstants.DbFieldCountryOfIncorporation]),
                            CountryOfRisk = Utility.GetString(reader[DbConstants.DbFieldCountryOfRisk]),
                            Agent = Utility.GetString(reader[DbConstants.DbFieldAgent]),
                            CompanyNumber = Utility.GetString(reader[DbConstants.DbFieldCompanyNumber]),
                            Lev1 = Utility.GetString(reader[DbConstants.DbFieldLev1]),
                            Lev2 = Utility.GetString(reader[DbConstants.DbFieldLev2]),
                            Lev3 = Utility.GetString(reader[DbConstants.DbFieldLev3]),
                            CountryOfCollateral = Utility.GetString(reader[DbConstants.DbFieldCountryOfCollateral]),
                            AssetTypeMB = Utility.GetString(reader[DbConstants.DbFieldAssetTypeMB]),
                            RatingSource = Utility.GetString(reader[DbConstants.DbFieldRatingSource]),
                            IsConduit = Utility.GetString(reader[DbConstants.DbFieldIsConduit]),
                            Format = Utility.GetString(reader[DbConstants.DbFieldFormat]),
                            RatingSP = Utility.GetString(reader[DbConstants.DbFieldRatingSP]),
                            RatingMD = Utility.GetString(reader[DbConstants.DbFieldRatingMD]),
                            RatingFT = Utility.GetString(reader[DbConstants.DbFieldRatingFT]),
                            RatingDBRS = Utility.GetString(reader[DbConstants.DbFieldRatingDBRS]),
                            RatingARC = Utility.GetString(reader[DbConstants.DbFieldRatingARC]),
                            PreclearedMedio = Utility.GetString(reader[DbConstants.DbFieldPreclearedMedio]),
                            PreclearableMedio = Utility.GetString(reader[DbConstants.DbFieldPreclearableMedio]),
                            Sponsor = Utility.GetString(reader[DbConstants.DbFieldSponsor]),
                            BorrowerInternalRating = Utility.GetString(reader[DbConstants.DbFieldBorrowerInternalRating]),
                            BorrowerInternalRatingImplied = Utility.GetString(reader[DbConstants.DbFieldBorrowerInternalRatingImplied]),
                            GradingScaleCode = Utility.GetString(reader[DbConstants.DbFieldGradingScaleCode]),
                            GradingModelCode = Utility.GetString(reader[DbConstants.DbFieldGradingModelCode]),
                            GradingScale = Utility.GetString(reader[DbConstants.DbFieldGradingScale]),
                            GradingModel = Utility.GetString(reader[DbConstants.DbFieldGradingModel]),
                            RatingApprovalDate = Utility.GetString(reader[DbConstants.DbFieldRatingApprovalDate]),
                            IBCAShortTermRating = Utility.GetString(reader[DbConstants.DbFieldIBCAShortTermRating]),
                            IBCALongTermRating = Utility.GetString(reader[DbConstants.DbFieldIBCALongTermRating]),
                            UltimateRiskParentCISCode = Utility.GetString(reader[DbConstants.DbFieldUltimateRiskParentCISCode]),
                            MoodysLongTermCPRatingGrdm = Utility.GetString(reader[DbConstants.DbFieldMoodysLongTermCPRatingGrdm]),
                            MoodysSTCRatingGrdm = Utility.GetString(reader[DbConstants.DbFieldMoodysSTCRatingGrdm]),
                            SPShortTermRatingGrdm = Utility.GetString(reader[DbConstants.DbFieldSPShortTermRatingGrdm]),
                            SPLongTermRatingGrdm = Utility.GetString(reader[DbConstants.DbFieldSPLongTermRatingGrdm]),
                            OECDMarker = Utility.GetString(reader[DbConstants.DbFieldOECDMarker]),
                            DoTEligible = Utility.GetString(reader[DbConstants.DbFieldDoTEligible]),
                            DoTRecordDate = Utility.GetString(reader[DbConstants.DbFieldDoTRecordDate]),
                            DoTContact = Utility.GetString(reader[DbConstants.DbFieldDoTContact]),
                            DoTComments = Utility.GetString(reader[DbConstants.DbFieldDoTComments]),
                            ECBEligible = Utility.GetString(reader[DbConstants.DbFieldECBEligible]),
                            ECBRecordDate = Utility.GetString(reader[DbConstants.DbFieldECBRecordDate]),
                            ECBContact = Utility.GetString(reader[DbConstants.DbFieldECBContact]),
                            ECBComments = Utility.GetString(reader[DbConstants.DbFieldECBComments]),
                            NoBorrowerSetOff = Utility.GetString(reader[DbConstants.DbFieldNoBorrowerSetOff]),
                            ContractLaw = Utility.GetString(reader[DbConstants.DbFieldContractLaw]),
                            W8Sent = Utility.GetString(reader[DbConstants.DbFieldW8Sent]),
                            W8SentDate = Utility.GetString(reader[DbConstants.DbFieldW8SentDate]),
                            W8Sender = Utility.GetString(reader[DbConstants.DbFieldW8Sender]),
                            TaxEligibilityOverride = Utility.GetString(reader[DbConstants.DbFieldTaxEligibilityOverride]),
                            TaxRecordDate = Utility.GetString(reader[DbConstants.DbFieldTaxRecordDate]),
                            TaxContact = Utility.GetString(reader[DbConstants.DbFieldTaxContact]),
                            TaxComments = Utility.GetString(reader[DbConstants.DbFieldTaxComments]),
                            FacilityWarnings = Utility.GetString(reader[DbConstants.DbFieldFacilityWarnings]),
                            EligibilityComments1 = Utility.GetString(reader[DbConstants.DbFieldEligibilityComments1]),
                            EligibilityComments2 = Utility.GetString(reader[DbConstants.DbFieldEligibilityComments2]),
                            EligibilityComments3 = Utility.GetString(reader[DbConstants.DbFieldEligibilityComments3]),
                            FacilityEncumberedOutsideProcess = Utility.GetString(reader[DbConstants.DbFieldFacilityEncumberedOutsideProcess]),
                            TimeToLegalMaturity = Utility.GetString(reader[DbConstants.DbFieldTimeToLegalMaturity]),
                            TimeToLegalMaturityBucket = Utility.GetString(reader[DbConstants.DbFieldTimeToLegalMaturityBucket]),
                            ExpectedAmortisationTime = Utility.GetString(reader[DbConstants.DbFieldExpectedAmortisationTime]),
                            TimeToAmortisationMaturityBucket = Utility.GetString(reader[DbConstants.DbFieldTimeToAmortisationMaturityBucket]),
                            IneligibilityExceptions = Utility.GetString(reader[DbConstants.DbFieldIneligibilityExceptions]),
                            Entity = Utility.GetString(reader[DbConstants.DbFieldEntity]),
                            CountryOfTaxClassification = Utility.GetString(reader[DbConstants.DbFieldCountryOfTaxClassification]),
                            CountryOfTaxNote = Utility.GetString(reader[DbConstants.DbFieldCountryOfTaxNote]),
                            IneligibilityValidation = Utility.GetString(reader[DbConstants.DbFieldIneligibilityValidation]),
                            AssessmentNeeded = Utility.GetString(reader[DbConstants.DbFieldAssessmentNeeded]),
                            ConditionPrecedents = Utility.GetString(reader[DbConstants.DbFieldConditionPrecedents]),
                            SNPEligibility = Utility.GetString(reader[DbConstants.DbFieldSNPEligibility]),
                            RSFUnencumbered = Utility.GetString(reader[DbConstants.DbFieldRSFUnencumbered]),
                            TopCoCISCodeEncrypted = Utility.GetString(reader[DbConstants.DbFieldTopCoCISCodeEncrypted]),
                            LegalEntityCISCodeEncrypted = Utility.GetString(reader[DbConstants.DbFieldLegalEntityCISCodeEncrypted]),
                            ClientClassification = Utility.GetString(reader[DbConstants.DbFieldClientClassification]),
                            SeniorityRank = Utility.GetString(reader[DbConstants.DbFieldSeniorityRank]),
                            FacilityInternalRating = Utility.GetString(reader[DbConstants.DbFieldFacilityInternalRating]),
                            DeskId = Utility.GetString(reader[DbConstants.DbFieldDeskId]),
                            DeskDesc = Utility.GetString(reader[DbConstants.DbFieldDeskDesc]),
                            SubDeskDesc = Utility.GetString(reader[DbConstants.DbFieldSubDeskDesc]),
                            CostCentreName = Utility.GetString(reader[DbConstants.DbFieldCostCentreName]),
                            CostCentreDesc = Utility.GetString(reader[DbConstants.DbFieldCostCentreDesc]),
                            SeniorTraderName = Utility.GetString(reader[DbConstants.DbFieldSeniorTraderName]),
                            CountryOfBalanceSheetLocation = Utility.GetString(reader[DbConstants.DbFieldCountryOfBalanceSheetLocation]),
                            TradingBankingIndicator = Utility.GetString(reader[DbConstants.DbFieldTradingBankingIndicator]),
                            DivisionName = Utility.GetString(reader[DbConstants.DbFieldDivisionName]),
                            BusinessConsolidation1Desc = Utility.GetString(reader[DbConstants.DbFieldBusinessConsolidation1Desc]),
                            BusinessConsolidation2Desc = Utility.GetString(reader[DbConstants.DbFieldBusinessConsolidation2Desc]),
                            BusinessConsolidation3Desc = Utility.GetString(reader[DbConstants.DbFieldBusinessConsolidation3Desc]),
                            BusinessConsolidation4Desc = Utility.GetString(reader[DbConstants.DbFieldBusinessConsolidation4Desc]),
                            BusinessConsolidation5Desc = Utility.GetString(reader[DbConstants.DbFieldBusinessConsolidation5Desc]),
                            SicCode = Utility.GetString(reader[DbConstants.DbFieldSicCode]),

                        });
                    }
                }

            }
            return nwmout;
        }
    }



}

