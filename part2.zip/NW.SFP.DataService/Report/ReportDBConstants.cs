﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.DataService.Report
{
    public class ReportDBConstants
    {
       
        #region reports

        public const string SP_GetInvestorReportFileName = @"cw.spGetInvestorReportFileName";

        public const string SP_SaveInvestorReportFileName = @"cw.spSaveInvestorReportFileName";

        public const string SP_GetReports = @"app.spGetReportsConfig";
        
        public const string SP_GetHypoPools = @"app.spGetHypoPoolList";
        
        public const string SP_GetReportAndParams = @"app.spGetReportAndParamters";
        
        public const string SP_SetReportForQueue = @"app.spSetReportForQueue";
        
        public const string SP_GetReportQueue = @"app.spGetReportQueue";

        #endregion

        #region custom type
        public const string DbTypeIntVarTableType = "app.udtIntVarArray";
        public const string DbTypeTableTypeId = "Id";
        public const string DbTypeTableTypeValue = "Value";
        #endregion
        #region CW Parameters

        #endregion

        #region Report Parameters
        public const string DbFieldUserName = "@pUserName";
        public const string DbFieldReportIdInput = "@pReportId";
        public const string DbFieldParamList = "@pParamList";
        public const string DbFieldReportDate = "@pReportDate";
        public const string DbFieldReportPoolName = "@pPoolName";
        public const string DbFieldReportBatchId = "@pBatchReportId";
        public const string DbFieldAssetClassId = "@pAssetClassId";
        public const string DbFieldPoolStatusId = "@pPoolStatusId";
        public const string DbFieldReportName = "ReportName";
        public const string DbFieldReportId = "ReportId";
        public const string DbFieldReportShortName = "ShortName";
        public const string DbFieldValidationStoredProc = "ValidationStoredProcedure";
        public const string DbFieldReportCategory = "Category";
        public const string DbFieldBrandCode = "BrandCode";
        public const string DbFieldDealName = "DealName";
        public const string DbFieldDealType = "DealType";
        public const string DbFieldDealStatus = "DealStatus";
        public const string DbFieldRegionCode = "RegionCode";
        public const string DbFieldTrancheName = "TrancheName";
        public const string DbFieldPoolDescription = "PoolDescription";
        public const string DbFieldPoolId = "PoolId";
        public const string DbFieldReportParamName = "ParameterName";
        public const string DbFieldReportParamId = "ReportParameterId";
        public const string DbFieldReportIsParamMandatory = "IsParameterMandatory";
        public const string DbFieldReportIsMultiValue = "IsMultiValue";
        public const string DbFieldReportParamDataType = "ParameterDataType";
        public const string DbFieldReportParamRegex = "ParameterRegex";
        public const string DbFieldReportParamHelp = "ParameterHelp";
        public const string DbFieldReportParameterCamelCaseName = "ParameterCamelCaseName";
        public const string DbFieldReportParamDisplayOrder = "DisplayOrder";
        public const string DbFieldReportParamDisplayName = "DisplayName";

        #endregion
    }
}
