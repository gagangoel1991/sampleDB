﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Common;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW.IR;
using NW.SFP.Message.PS;
using NW.SFP.Message.Report;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.Report
{
    public class ReferenceRegistryReportDataService : Repository<IR_MappedFieldList>, IReferenceRegistryReportDataService
    {

        private IUnitOfWork _unitOfWork;
        private readonly IOptions<Message.Core.DataServiceSettings> _settings;

        public ReferenceRegistryReportDataService(IUnitOfWork uow, IOptions<Message.Core.DataServiceSettings> settings)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
            this._settings = settings;
        }

        /// <summary>
        /// To Manage Ref Reg Report Authentication Workflow
        /// </summary>
        /// <param name="authWorkflowEntity"></param>
        /// <returns></returns>
        public int ManageRRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            using (var cmd = this._unitOfWork.CreateCommand())
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = DbConstants.SP_ManageBuildRRWorkflowProcess;
                cmd.Parameters.AddWithValue("@pDealIrConfigId", authWorkflowEntity.ProcessId);
                cmd.Parameters.AddWithValue("@pWorkFlowStepId", authWorkflowEntity.WorkflowStep);
                cmd.Parameters.AddWithValue("@pAuthorizerComment", authWorkflowEntity.Comment);
                cmd.Parameters.AddWithValue("@pUserName", authWorkflowEntity.UserName);

                return cmd.ExecuteNonQuery();
            }
        }


        public int GetRRAuthorisedDealConfigId(int dealId, string AsAtDate, string loggedInUserName)
        {
            using (var cmd = this._unitOfWork.CreateCommand())
            {
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.CommandText = DbConstants.SP_GetRRAuthorisedDealConfig;
                cmd.Parameters.AddWithValue("@pDealId", dealId);
                cmd.Parameters.AddWithValue("@pAsAtdate", AsAtDate);
                cmd.Parameters.AddWithValue("@pUserName", loggedInUserName);
                cmd.Parameters.AddWithValue("@pDealIrConfigId", 0);

                cmd.Parameters["@pDealIrConfigId"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(cmd);

                return Utility.GetInt(cmd.Parameters["@pDealIrConfigId"].Value);


            }
        }

        public IList<RRReportField> GetFieldsForReports(string loggedInUserName, int assetClassId)
        {
            IList<RRReportField> reportFields = new List<RRReportField>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_RR_GetReportFieldList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.AssetClassId, assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportFields.Add(new RRReportField()
                            {
                                Value = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataValue]),
                                Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]),
                                FieldDescription = Utility.GetString(resultReader[DbConstants.DbFieldLookupDescription]),
                                FieldDataType = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataTypeId]),
                                CriteriaFieldTable = Utility.GetString(resultReader[DbConstants.DbTypeCriteriaFieldTable]),
                                FieldLevel = Utility.GetString(resultReader[DbConstants.DbTypeLevel])
                            });
                        }
                    }
                }
            }
            return reportFields;
        }

        public DataTable GetRrStratData(string StratName, int DealIrConfigId, string AsAtDate, int DealID, string UserName, 
            int poolId = 0, string ReportOutputType="")
        {
            using (SqlConnection sqlConn = new SqlConnection(this._settings.Value.ConnectionString))
            {
                SqlCommand cmd = new SqlCommand();
                cmd.Connection = sqlConn;
                cmd.CommandTimeout = 0;

                cmd.CommandText = "corp.spGetRegRegReportGenerationData";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pStratName", StratName);
                cmd.Parameters.AddWithValue("@pDealIrConfigId", DealIrConfigId);
                cmd.Parameters.AddWithValue("@pAsAtDate", AsAtDate);
                cmd.Parameters.AddWithValue("@pDealID", DealID);
                cmd.Parameters.AddWithValue("@pUserName", UserName);
                cmd.Parameters.AddWithValue("@pPoolID", poolId);
                cmd.Parameters.AddWithValue("@pOutputType", ReportOutputType);

                SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                return ds.Tables[0];
            }
        }



    }
}