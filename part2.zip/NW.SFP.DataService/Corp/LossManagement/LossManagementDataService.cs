﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.CB;
using NW.SFP.Message.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;

namespace NW.SFP.DataService.CB
{
    public class LossManagementDataService : ILossManagementDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;
        public LossManagementDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        public IList<LossManagementList> GetLossManagementList(string userName)
        {
            IList<LossManagementList> lossList = new List<LossManagementList>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[corp].[spGetLossManagementList]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.CommandTimeout = 0;
                    SqlDataReader reader;
                    using (reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (reader.HasRows)
                            {
                                lossList.Add(new LossManagementList()
                                {
                                    LossManagementId = Utility.GetInt(reader["LossManagementId"]),
                                    Deal = Utility.GetString(reader["Deal"]),
                                    Source = Utility.GetString(reader["Source"]),
                                    FacilityId = Utility.GetLong(reader["FacilityId"]),
                                    ReferenceEntityId = Utility.GetString(reader["ReferenceEntityId"]),
                                    SubSector = Utility.GetString(reader["SubSector"]),
                                    FacilityStartDate = Utility.GetDateTimeNullable(reader["FacilityStartDate"]),
                                    MaturityDate = Utility.GetDateTimeNullable(reader["MaturityDate"]),
                                    InitialRona = Utility.GetDecimal(reader["InitialRona"]),
                                    DefaultedNotional = Utility.GetDecimal(reader["DefaultedNotional"]),
                                    FacilitySharePercent = Utility.GetDecimal(reader["FacilitySharePercent"]),
                                    Originator = Utility.GetString(reader["Originator"]),
                                    CreditEventNoticeDate = Utility.GetDateTimeNullable(reader["CreditEventNoticeDate"]),
                                    EvidenceSentDate = Utility.GetDateTimeNullable(reader["EvidenceSentDate"]),
                                    CreditEventVerifiedDate = Utility.GetDateTimeNullable(reader["CreditEventVerifiedDate"]),
                                    WaterfallDateClaimed = Utility.GetDateTimeNullable(reader["WaterfallDateClaimed"]),
                                    FxRateDate = Utility.GetDateTimeNullable(reader["FxRateDate"]),
                                    DefaultDate = Utility.GetDateTimeNullable(reader["DefaultDate"]),
                                    CreditEventTypeId = Utility.GetInt(reader["CreditEventTypeId"]),
                                    ExposureAtDefault = Utility.GetDecimal(reader["ExposureAtDefault"]),
                                    CurrentExposure = Utility.GetDecimal(reader["CurrentExposure"]),
                                    InitialLossPercent = Utility.GetDecimal(reader["InitialLossPercent"]),
                                    InitialLossAmount = Utility.GetDecimal(reader["InitialLossAmount"]),
                                    FinalLossAmount = Utility.GetDecimal(reader["FinalLossAmount"]),
                                    InitialVerifiedLossAmount = Utility.GetDecimal(reader["InitialVerifiedLossAmount"]),
                                    RealisedRecoveries = Utility.GetDecimal(reader["RealisedRecoveries"]),
                                    AdjustedRecoveries = Utility.GetDecimal(reader["AdjustedRecoveries"]),
                                    FinalEstimatedRecoveries = Utility.GetDecimal(reader["FinalEstimatedRecoveries"]),
                                    TotalAdjustedRecoveries = Utility.GetDecimal(reader["TotalAdjustedRecoveries"]),
                                    TotalLossAmount = Utility.GetDecimal(reader["TotalLossAmount"]),
                                    FinalWaterfallCalculationNumber = Utility.GetDecimal(reader["FinalWaterfallCalculationNumber"]),
                                    CreditLossEventAmount = Utility.GetDecimal(reader["CreditLossEventAmount"]),
                                    RestructuredPrincipalAmount = Utility.GetDecimal(reader["RestructuredPrincipalAmount"]),
                                    FinalVerificationDate = Utility.GetDateTimeNullable(reader["FinalVerificationDate"]),
                                    WaterfallDate = Utility.GetDateTimeNullable(reader["WaterfallDate"]),
                                    CurrentLimit = Utility.GetDecimal(reader["CurrentLimit"]),
                                    DrawnAmount = Utility.GetDecimal(reader["DrawnAmount"]),
                                    MGS = Utility.GetString(reader["MGS"]),
                                    MGS27DefaultDate = Utility.GetDateTimeNullable(reader["MGS27DefaultDate"]),
                                    AllocatedLoss = Utility.GetDecimal(reader["AllocatedLosses"]),
                                    IsAllocatedLossLoaded = Utility.GetBool(reader["IsAllocatedLossLoaded"]),
                                    Status = Utility.GetInt(reader["Status"]),
                                    Comments = Utility.GetString(reader["Comments"]),
                                    ModifiedBy = Utility.GetString(reader["ModifiedBy"]),
                                    LastAuditComment = Utility.GetString(reader["LastAuditComment"]),
                                    LastUpdateTimestamp = Utility.GetDateTimeNullable(reader["LastUpdateTimestamp"]),
                                    AccountStatus = Utility.GetString(reader["AccountStatus"]),
                                    RecoverySource = Utility.GetInt(reader["RecoverySource"]),
                                    DefaultReason = Utility.GetString(reader["DefaultReason"]),
                                    MGS27DefaultAmount = Utility.GetDecimal(reader["MGS27DefaultAmount"])
                                });
                            }
                        }
                    }
                }
            }
            return lossList;
        }
        public IList<LossManagementList> GetLossUpdatedData(string userName)
        {
            IList<LossManagementList> lossUpdatedData = new List<LossManagementList>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[corp].[spGetLossUpdatedData]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    SqlDataReader reader;
                    using (reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (reader.HasRows)
                            {
                                lossUpdatedData.Add(new LossManagementList()
                                {
                                    LossManagementId = Utility.GetInt(reader["LossManagementId"]),
                                    DefaultedNotional = Utility.GetDecimal(reader["DefaultedNotional"]),
                                    FacilitySharePercent = Utility.GetDecimal(reader["FacilitySharePercent"]),
                                    CreditEventNoticeDate = Utility.GetDateTimeNullable(reader["CreditEventNoticeDate"]),
                                    EvidenceSentDate = Utility.GetDateTimeNullable(reader["EvidenceSentDate"]),
                                    CreditEventVerifiedDate = Utility.GetDateTimeNullable(reader["CreditEventVerifiedDate"]),
                                    WaterfallDateClaimed = Utility.GetDateTimeNullable(reader["WaterfallDateClaimed"]),
                                    FxRateDate = Utility.GetDateTimeNullable(reader["FxRateDate"]),
                                    DefaultDate = Utility.GetDateTimeNullable(reader["DefaultDate"]),
                                    CreditEventTypeId = Utility.GetInt(reader["CreditEventTypeId"]),
                                    ExposureAtDefault = Utility.GetDecimal(reader["ExposureAtDefault"]),
                                    CurrentExposure = Utility.GetDecimal(reader["CurrentExposure"]),
                                    InitialLossPercent = Utility.GetDecimal(reader["InitialLossPercent"]),
                                    InitialLossAmount = Utility.GetDecimal(reader["InitialLossAmount"]),
                                    FinalLossAmount = Utility.GetDecimal(reader["FinalLossAmount"]),
                                    InitialVerifiedLossAmount = Utility.GetDecimal(reader["InitialVerifiedLossAmount"]),
                                    RealisedRecoveries = Utility.GetDecimal(reader["RealisedRecoveries"]),
                                    AdjustedRecoveries = Utility.GetDecimal(reader["AdjustedRecoveries"]),
                                    FinalEstimatedRecoveries = Utility.GetDecimal(reader["FinalEstimatedRecoveries"]),
                                    TotalAdjustedRecoveries = Utility.GetDecimal(reader["TotalAdjustedRecoveries"]),
                                    TotalLossAmount = Utility.GetDecimal(reader["TotalLossAmount"]),
                                    FinalWaterfallCalculationNumber = Utility.GetDecimal(reader["FinalWaterfallCalculationNumber"]),
                                    CreditLossEventAmount = Utility.GetDecimal(reader["CreditLossEventAmount"]),
                                    RestructuredPrincipalAmount = Utility.GetDecimal(reader["RestructuredPrincipalAmount"]),
                                    FinalVerificationDate = Utility.GetDateTimeNullable(reader["FinalVerificationDate"]),
                                    WaterfallDate = Utility.GetDateTimeNullable(reader["WaterfallDate"]),
                                    Status = Utility.GetInt(reader["Status"]),
                                    Comments = Utility.GetString(reader["Comments"]),
                                    ModifiedBy = Utility.GetString(reader["ModifiedBy"]),
                                    LastAuditComment = Utility.GetString(reader["LastAuditComment"]),
                                    LastUpdateTimestamp = Utility.GetDateTimeNullable(reader["LastUpdateTimestamp"]),
                                    AccountStatus = Utility.GetString(reader["AccountStatus"]),
                                    DefaultReason = Utility.GetString(reader["DefaultReason"]),
                                    MGS27DefaultAmount = Utility.GetDecimal(reader["MGS27DefaultAmount"]),
                                    RecoverySource = Utility.GetInt(reader["RecoverySource"]),
                                    
                                });
                            }
                        }
                    }
                }
            }
            return lossUpdatedData;
        }

        public LossManagementRefData GetLossManagementRefData(string userName)
        {
            LossManagementRefData lossManagementRefData = new LossManagementRefData();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[corp].[spGetLossManagementRefData]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    SqlDataReader resultReader;
                    using (resultReader = cmd.ExecuteReader())
                    {
                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.LossStatusList.AddRange(GetBasicLookUpData(resultReader));
                        }

                        resultReader.NextResult();

                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.StatusToListingList.AddRange(GetBasicLookUpData(resultReader));
                        }

                        resultReader.NextResult();

                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.UnderReviewStatusDropdownList.AddRange(GetBasicLookUpData(resultReader));
                        }

                        resultReader.NextResult();

                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.CreditEventTypeList.AddRange(GetBasicLookUpData(resultReader));
                        }

                        resultReader.NextResult();

                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.AccountStatusList.AddRange(GetLossesRefData(resultReader));
                        }
                        resultReader.NextResult();  

                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.RecoverySourceList.AddRange(GetBasicLookUpData(resultReader));
                        }

                        resultReader.NextResult();

                        if (resultReader.HasRows)
                        {
                            lossManagementRefData.DefaultReasonList.AddRange(GetLossesRefData(resultReader));
                        }
                    }
                }
            }
            return lossManagementRefData;
        }

        public int UploadWriteOffFile(IList<WriteOffData> writeOffData, string userName)
        {
            int rowsAffected;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spUploadWriteOffFile]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(CreateParameterList(writeOffData, userName).ToArray<SqlParameter>());
                rowsAffected = cmd.ExecuteNonQuery();
            }
            return rowsAffected;
        }

        public DefaultDateData GetDefaultDateData(DefaultDateData defaultDateParam, string userName)
        {
            DefaultDateData defaultDateData = new DefaultDateData();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[corp].[spGetDefaultDateData]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@pFacilityId", defaultDateParam.FacilityId);
                    cmd.Parameters.AddWithValue("@pDealName", defaultDateParam.Deal);
                    cmd.Parameters.AddWithValue("@pSource", defaultDateParam.Source);
                    cmd.Parameters.AddWithValue("@pDefaultDate", defaultDateParam.DefaultDate);
                    cmd.Parameters.AddWithValue("@pFxRateDate", defaultDateParam.FxRateDate);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.CommandTimeout = 0;
                    SqlDataReader reader;
                    using (reader = cmd.ExecuteReader())
                    {
                        while (reader.Read())
                        {
                            if (reader.HasRows)
                            {
                                defaultDateData.FacilityId = defaultDateParam.FacilityId;
                                defaultDateData.Deal = defaultDateParam.Deal;
                                defaultDateData.Source = defaultDateParam.Source;
                                defaultDateData.DefaultDate = defaultDateParam.DefaultDate;
                                defaultDateData.ExposureAtDefault = Utility.GetDecimal(reader["ExposureAtDefault"]);
                                defaultDateData.EADRestructured = Utility.GetDecimal(reader["EADRestructured"]);
                                defaultDateData.CurrentExposure = Utility.GetDecimal(reader["CurrentExposure"]);
                                defaultDateData.CERestructured = Utility.GetDecimal(reader["CERestructured"]);
                                defaultDateData.InitialLossPercent = Utility.GetDecimal(reader["InitialLossPercent"]);
                                defaultDateData.DefaultedNotional = Utility.GetDecimal(reader["DefaultedNotional"]);
                                defaultDateData.FacilitySharePercent = Utility.GetDecimal(reader["FacilitySharePercent"]);

                            }
                        }
                    }
                }
            }
            return defaultDateData;
        }

        public int UpdateLossDetails(LossManagementList lossManagementList, string userName)
        {
            int rowsAffected;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[corp].[spUpdateLossDetails]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@pLossManagementId", lossManagementList.LossManagementId);
                    cmd.Parameters.AddWithValue("@pCreditEventNoticeDate", lossManagementList.CreditEventNoticeDate);
                    cmd.Parameters.AddWithValue("@pEvidenceSentDate", lossManagementList.EvidenceSentDate);
                    cmd.Parameters.AddWithValue("@pCreditEventVerifiedDate", lossManagementList.CreditEventVerifiedDate);
                    cmd.Parameters.AddWithValue("@pWaterfallDateClaimed", lossManagementList.WaterfallDateClaimed);
                    cmd.Parameters.AddWithValue("@pFxRateDate", lossManagementList.FxRateDate);
                    cmd.Parameters.AddWithValue("@pDefaultDate", lossManagementList.DefaultDate);
                    cmd.Parameters.AddWithValue("@pCreditEventTypeId", lossManagementList.CreditEventTypeId);
                    cmd.Parameters.AddWithValue("@pExposureAtDefault", lossManagementList.ExposureAtDefault);
                    cmd.Parameters.AddWithValue("@pCurrentExposure", lossManagementList.CurrentExposure);
                    cmd.Parameters.AddWithValue("@pInitialLossPercent", lossManagementList.InitialLossPercent);
                    cmd.Parameters.AddWithValue("@pInitialLossAmount", lossManagementList.InitialLossAmount);
                    cmd.Parameters.AddWithValue("@pFinalLossAmount", lossManagementList.FinalLossAmount);
                    cmd.Parameters.AddWithValue("@pInitialVerifiedLossAmount", lossManagementList.InitialVerifiedLossAmount);
                    cmd.Parameters.AddWithValue("@pRealisedRecoveries", lossManagementList.RealisedRecoveries);
                    cmd.Parameters.AddWithValue("@pAdjustedRecoveries", lossManagementList.AdjustedRecoveries);
                    cmd.Parameters.AddWithValue("@pFinalEstimatedRecoveries", lossManagementList.FinalEstimatedRecoveries);
                    cmd.Parameters.AddWithValue("@pTotalAdjustedRecoveries", lossManagementList.TotalAdjustedRecoveries);
                    cmd.Parameters.AddWithValue("@pTotalLossAmount", lossManagementList.TotalLossAmount);
                    cmd.Parameters.AddWithValue("@pFinalWaterfallCalculationNumber", lossManagementList.FinalWaterfallCalculationNumber);
                    cmd.Parameters.AddWithValue("@pCreditLossEventAmount", lossManagementList.CreditLossEventAmount);
                    cmd.Parameters.AddWithValue("@pRestructuredPrincipalAmount", lossManagementList.RestructuredPrincipalAmount);
                    cmd.Parameters.AddWithValue("@pFinalVerificationDate", lossManagementList.FinalVerificationDate);
                    cmd.Parameters.AddWithValue("@pWaterfallDate", lossManagementList.WaterfallDate);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.AddWithValue("@pComments", lossManagementList.Comments);
                    cmd.Parameters.AddWithValue("@pDefaultedNotional", lossManagementList.DefaultedNotional);
                    cmd.Parameters.AddWithValue("@pFacilitySharePercent", lossManagementList.FacilitySharePercent);
                    cmd.Parameters.AddWithValue("@pAccountStatus", lossManagementList.AccountStatus);
                    cmd.Parameters.AddWithValue("@pRecoverySource", lossManagementList.RecoverySource);
                    cmd.Parameters.AddWithValue("@pDefaultReason", lossManagementList.DefaultReason);
                    cmd.Parameters.AddWithValue("@pMGS27DefaultAmount", lossManagementList.MGS27DefaultAmount);
                    cmd.Parameters.AddWithValue("@pMGS27DefaultDate", lossManagementList.MGS27DefaultDate);
                    rowsAffected = cmd.ExecuteNonQuery();
                }
            }
            return rowsAffected;
        }

        public decimal? LoadAllocatedLoss(int lossManagementId, string userName)
        {
            decimal? AllocatedLoss;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand("[corp].[spLoadAllocatedLoss]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@pLossManagementId", lossManagementId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.Add("@pAllocatedLoss", SqlDbType.Float);
                    cmd.Parameters["@pAllocatedLoss"].Direction = ParameterDirection.Output;
                    cmd.CommandTimeout = 0;
                    cmd.ExecuteNonQuery();
                    AllocatedLoss = Utility.GetDecimal(cmd.Parameters["@pAllocatedLoss"].Value);
                }
            }
            return AllocatedLoss;
        }

        private List<SqlParameter> CreateParameterList(IList<WriteOffData> writeOffData, string userName)
        {
            List<SqlParameter> parameterCollection = new List<SqlParameter>
            {
                new SqlParameter("@pWriteOffItems",  SqlDbType.Structured),
                new SqlParameter(DbConstants.DbProcParamUserName, SqlDbType.VarChar)
            };

            var writeOffItems = new DataTable();
            writeOffItems.Columns.Add("Month", typeof(int));
            writeOffItems.Columns.Add("Year", typeof(int));
            writeOffItems.Columns.Add("Description", typeof(string)).MaxLength = 500;
            writeOffItems.Columns.Add("FacilityId", typeof(string)).MaxLength = 50;
            writeOffItems.Columns.Add("CisCode", typeof(string)).MaxLength = 50;
            writeOffItems.Columns.Add("CC", typeof(string)).MaxLength = 50;
            writeOffItems.Columns.Add("CCY", typeof(string)).MaxLength = 50;
            writeOffItems.Columns.Add("Amount", typeof(decimal));
            writeOffItems.Columns.Add("AssessmentType", typeof(string)).MaxLength = 50;
            writeOffItems.Columns.Add("Comments", typeof(string)).MaxLength = 500;

            foreach (var pWriteOffItem in writeOffData)
            {
                writeOffItems.Rows.Add(
                    Utility.GetInt(pWriteOffItem.Month), 
                    Utility.GetInt(pWriteOffItem.Year),
                    Utility.GetString(pWriteOffItem.Description),
                    Utility.GetString(pWriteOffItem.FacilityId),
                    Utility.GetString(pWriteOffItem.CisCode),
                    Utility.GetString(pWriteOffItem.CC),
                    Utility.GetString(pWriteOffItem.CCY),
                    Utility.GetDecimal(pWriteOffItem.Amount),
                    Utility.GetString(pWriteOffItem.AssessmentType),
                    Utility.GetString(pWriteOffItem.Comments)
                 );
            }
            parameterCollection[0].SqlValue = writeOffItems;
            parameterCollection[0].TypeName = "corp.WriteOffItem";
            parameterCollection[1].SqlValue = userName;
            return parameterCollection;
        }

        private IList<BasicLookUpData> GetBasicLookUpData(SqlDataReader resultReader)
        {
            var listBasicLookUpData = new List<BasicLookUpData>();
            while (resultReader.Read())
            {
                BasicLookUpData objBasicLookUpData = new BasicLookUpData
                {
                    Value = Convert.ToInt32(resultReader["Value"]),
                    Title = Utility.GetString(resultReader["Title"])
                };
                listBasicLookUpData.Add(objBasicLookUpData);
            }
            return listBasicLookUpData;
        }

        private IList<LossesLookUp> GetLossesRefData(SqlDataReader resultReader)
        {
            var listLossesRefLookUpData = new List<LossesLookUp>();
            while (resultReader.Read())
            {
                LossesLookUp objLossManagementRefLookUp = new LossesLookUp
                {
                    Value = Utility.GetString(resultReader["Value"]),
                    Title = Utility.GetString(resultReader["Title"])
                };
                listLossesRefLookUpData.Add(objLossManagementRefLookUp);
            }
            return listLossesRefLookUpData;
        }
    }
}

