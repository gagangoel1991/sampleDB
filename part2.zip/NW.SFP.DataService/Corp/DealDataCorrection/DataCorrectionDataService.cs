﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.CB;
using NW.SFP.Message.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.Corp;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Globalization;

namespace NW.SFP.DataService.CB
{
    public class DataCorrectionDataService : IDataCorrectionDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;
        public DataCorrectionDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        public DataCorrectionDetail GetDataCorrectionDetail(DataCorrectionBasicInfo basicInfo, string userName)
        {
            List<FacilityDataCorrectionList> facCorrectedList = null, facOrigionalList = null;
            List<SecurityDataCorrectionList> secCorrectedList = null, secOrigionalList = null;

            // Basic Info 
            DataCorrectionBasicInfo dataCorrectionBasicInfo = new DataCorrectionBasicInfo()
            {
                CorrectionDate = basicInfo.CorrectionDate,
                CorrectionId = basicInfo.CorrectionId,
                DealId = basicInfo.DealId,
                EntityId = basicInfo.EntityId,
                FsId = basicInfo.FsId
            };

            DataCorrectionBasicInfo objDataCorrectionBasicInfo = GetDeatDataCorrectionBasicData(basicInfo, userName);
            if (objDataCorrectionBasicInfo != null && objDataCorrectionBasicInfo.CorrectionId != null)
            {
                dataCorrectionBasicInfo.CorrectionId = objDataCorrectionBasicInfo.CorrectionId;
                dataCorrectionBasicInfo.Status = objDataCorrectionBasicInfo.Status;
                dataCorrectionBasicInfo.DealCorrectionStatusId = objDataCorrectionBasicInfo.DealCorrectionStatusId;
                dataCorrectionBasicInfo.CreatedBy = objDataCorrectionBasicInfo.CreatedBy;
                dataCorrectionBasicInfo.AuthorizedBy = objDataCorrectionBasicInfo.AuthorizedBy;
            }


            // Data Correction List's
            if (dataCorrectionBasicInfo.EntityId == 1)
            {
                CorrectionList<FacilityDataCorrectionList> correctionList = GetFacilityDataCorrectionList(basicInfo, userName);
                facCorrectedList = correctionList.CorrectedList;
                facOrigionalList = correctionList.OrigionalList;
            }
            else if (dataCorrectionBasicInfo.EntityId == 2)
            {
                CorrectionList<SecurityDataCorrectionList> correctionList = GetSecurityCorrectionList(basicInfo, userName);
                secCorrectedList = correctionList.CorrectedList;
                secOrigionalList = correctionList.OrigionalList;
            }
            DataCorrectionDetail dataCorrectionDetail = new DataCorrectionDetail()
            {
                CorrectionBasicInfo = dataCorrectionBasicInfo,
                FacilityCorrectedDataList = facCorrectedList,
                FacilityOrigionalDataList = facOrigionalList,
                SecurityCorrectedDataList = secCorrectedList,
                SecurityOrigionalDataList = secOrigionalList
            };

            return dataCorrectionDetail;
        }
        public IList<DataCorrectionAttribute> GetDataCorrectionAttribute(int entityId, string userName)
        {
            IList<DataCorrectionAttribute> attributeList = new List<DataCorrectionAttribute>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetDataCorrectionAttribute, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcEntityId, entityId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            attributeList.Add(new DataCorrectionAttribute()
                            {
                                AttributeId = Utility.GetInt(reader["AttributeId"]),
                                AttributeName = Utility.GetString(reader["AttributeName"]),
                                DisplayName = Utility.GetString(reader["DisplayName"]),
                                EntityType = Utility.GetString(reader["EntityName"]),
                                DataType = Utility.GetString(reader["DataType"]),
                                IsEditable = Convert.ToBoolean(reader["IsEditable"]),
                                IsChecked = Convert.ToBoolean(reader["IsChecked"]),
                                IsHideAllowed = Convert.ToBoolean(reader["IsHideAllowed"]),
                                FilterText = ""
                            });
                        }
                    }
                }
            }
            return attributeList;
        }

        public DataCorrectionBasicInfo GetDeatDataCorrectionBasicData(DataCorrectionBasicInfo basicInfo, string userName)
        {
            DataCorrectionBasicInfo objDataCorrectionBasicInfo = new DataCorrectionBasicInfo();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetDealDataCorrectionDetail, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(basicInfo.CorrectionDate).ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, basicInfo.DealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcEntityId, basicInfo.EntityId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.CommandTimeout = 0;

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            objDataCorrectionBasicInfo.CorrectionId = Utility.GetInt(reader["Id"]);
                            objDataCorrectionBasicInfo.Status = Utility.GetString(reader["Status"]);
                            objDataCorrectionBasicInfo.DealCorrectionStatusId = Utility.GetInt(reader["StatusId"]);
                            objDataCorrectionBasicInfo.CreatedBy = Utility.GetString(reader["CreatedBy"]);
                            objDataCorrectionBasicInfo.AuthorizedBy = Utility.GetString(reader["AuthorizedBy"]);
                            objDataCorrectionBasicInfo.AuthorizedDate = Utility.GetString(reader["AuthorizedDate"]);
                        }
                    }
                }
            }
            return objDataCorrectionBasicInfo;
        }

        public CorrectionList<FacilityDataCorrectionList> GetFacilityDataCorrectionList(DataCorrectionBasicInfo basicInfo, string userName)
        {
            IList<FacilityDataCorrectionList> correctedDataList = new List<FacilityDataCorrectionList>();
            IList<FacilityDataCorrectionList> origionalDataList = new List<FacilityDataCorrectionList>();
            CorrectionList<FacilityDataCorrectionList> correctionList = new CorrectionList<FacilityDataCorrectionList>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetFacilityDataCorrectionList, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(basicInfo.CorrectionDate).ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, basicInfo.DealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcEntityId, basicInfo.EntityId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcFsId, basicInfo.FsId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.CommandTimeout = 0;


                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            correctedDataList.Add(new FacilityDataCorrectionList()
                            {
                                FacilityId = Utility.GetLong(reader["FacilityId"]),
                                SecurityId = Utility.GetString(reader["SecurityId"]),
                                FirstInterestMargin = Utility.GetDecimal(reader["FirstInterestMargin"]),
                                InterestCharge = Utility.GetDecimal(reader["InterestCharge"]),
                                LtvOverride = Utility.GetDecimal(reader["LtvOverride"]),
                                DevelopmentLtcOverride = Utility.GetDecimal(reader["DevelopmentLtcOverride"]),
                                DevelopmentLtcValue = Utility.GetDecimal(reader["DevelopmentLtcValue"]),
                                FacilityTypeCode = Utility.GetString(reader["FacilityTypeCode"]),
                                InterestBasis = Utility.GetString(reader["InterestBasis"]),
                                InterestBasisCode = Utility.GetString(reader["InterestBasisCode"]),
                                CostCentre = Utility.GetString(reader["CostCentre"]),
                                FacilityCurrencyCode = Utility.GetString(reader["FacilityCurrencyCode"]),
                                FacilitySourceCode = Utility.GetString(reader["FacilitySourceCode"]),
                                CisCode = Utility.GetString(reader["CisCode"])
                            });
                        }
                        correctionList.CorrectedList = correctedDataList.ToList().OrderBy(x => x.FacilityId).ToList();
                    }
                    reader.NextResult();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            origionalDataList.Add(new FacilityDataCorrectionList()
                            {
                                FacilityId = Utility.GetLong(reader["FacilityId"]),
                                SecurityId = Utility.GetString(reader["SecurityId"]),
                                FirstInterestMargin = Utility.GetDecimal(reader["FirstInterestMargin"]),
                                InterestCharge = Utility.GetDecimal(reader["InterestCharge"]),
                                LtvOverride = Utility.GetDecimal(reader["LtvOverride"]),
                                DevelopmentLtcOverride = Utility.GetDecimal(reader["DevelopmentLtcOverride"]),
                                DevelopmentLtcValue = Utility.GetDecimal(reader["DevelopmentLtcValue"]),
                                FacilityTypeCode = Utility.GetString(reader["FacilityTypeCode"]),
                                InterestBasis = Utility.GetString(reader["InterestBasis"]),
                                InterestBasisCode = Utility.GetString(reader["InterestBasisCode"]),
                                CostCentre = Utility.GetString(reader["CostCentre"]),
                                FacilityCurrencyCode = Utility.GetString(reader["FacilityCurrencyCode"]),
                                FacilitySourceCode = Utility.GetString(reader["FacilitySourceCode"]),
                                CisCode = Utility.GetString(reader["CisCode"])

                            });
                        }
                        correctionList.OrigionalList = origionalDataList.ToList().OrderBy(x => x.FacilityId).ToList();
                    }
                }
            }
            return correctionList;
        }

        public CorrectionList<SecurityDataCorrectionList> GetSecurityCorrectionList(DataCorrectionBasicInfo basicInfo, string userName)
        {

            IList<SecurityDataCorrectionList> correctedDataList = new List<SecurityDataCorrectionList>();
            IList<SecurityDataCorrectionList> origionalDataList = new List<SecurityDataCorrectionList>();
            CorrectionList<SecurityDataCorrectionList> correctionList = new CorrectionList<SecurityDataCorrectionList>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetSecurityDataCorrectionList, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(basicInfo.CorrectionDate).ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, basicInfo.DealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcEntityId, basicInfo.EntityId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcFsId, basicInfo.FsId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.CommandTimeout = 0;


                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            correctedDataList.Add(new SecurityDataCorrectionList()
                            {
                                SecurityId = Utility.GetLong(reader["SecurityId"]),
                                FacilityId = Utility.GetString(reader["FacilityId"]),
                                ConnectionId = Utility.GetLong(reader["ConnectionId"]),
                                ValnSourceCode = Utility.GetString(reader["ValnSourceCode"]),
                                GrossValueAmt = Utility.GetDecimal(reader["GrossValueAmt"]),
                                PropertyNatureCode = Utility.GetString(reader["PropertyNatureCode"]),
                                PropertyPostcode = Utility.GetString(reader["PropertyPostcode"]),
                                CradleSecurityId = Utility.GetLong(reader["CradleSecurityId"]),
                                SecurityDescription = Utility.GetString(reader["SecurityDescription"])
                            });
                        }
                        correctionList.CorrectedList = correctedDataList.ToList().OrderBy(x => x.FacilityId).ToList();
                    }
                    reader.NextResult();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            origionalDataList.Add(new SecurityDataCorrectionList()
                            {
                                SecurityId = Utility.GetLong(reader["SecurityId"]),
                                FacilityId = Utility.GetString(reader["FacilityId"]),
                                ConnectionId = Utility.GetLong(reader["ConnectionId"]),
                                ValnSourceCode = Utility.GetString(reader["ValnSourceCode"]),
                                GrossValueAmt = Utility.GetDecimal(reader["GrossValueAmt"]),
                                PropertyNatureCode = Utility.GetString(reader["PropertyNatureCode"]),
                                PropertyPostcode = Utility.GetString(reader["PropertyPostcode"]),
                                CradleSecurityId = Utility.GetLong(reader["CradleSecurityId"]),
                                SecurityDescription = Utility.GetString(reader["SecurityDescription"])
                            });
                        }
                        correctionList.OrigionalList = origionalDataList.ToList().OrderBy(x => x.FacilityId).ToList();
                    }
                }
            }
            return correctionList;
        }
        public string SaveDataCorrection(DataCorrectionBasicInfo basicInfo, string userName)
        {
            try
            {
                int rowsInserted = 0;
                dynamic result = null;
                int InitialStatus = basicInfo.Status == "Draft" ? 1 : -1;

                DataTable dtDataCorrectionKeyValue = ConvertStructureToDatatable(basicInfo.CorrectedData);
                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_SaveDataCorrection, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(basicInfo.CorrectionDate).ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, basicInfo.DealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcEntityId, basicInfo.EntityId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcFsId, basicInfo.FsId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcStatusId, InitialStatus);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParampDataCorrectionList, dtDataCorrectionKeyValue);
                    //cmd.Parameters.AddWithValue(DbConstants.DbProcParamDealDataCorrectionId, basicInfo.CorrectionId);

                    SqlParameter cmdOutBasicRetVal = new SqlParameter();
                    cmdOutBasicRetVal.ParameterName = DbConstants.DbProcParamBasicInfoResult;
                    cmdOutBasicRetVal.Direction = ParameterDirection.Output;
                    cmdOutBasicRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutBasicRetVal);

                    SqlParameter cmdOutDataCorrectionRetVal = new SqlParameter();
                    cmdOutDataCorrectionRetVal.ParameterName = DbConstants.DbProcParamDataCorrectionResult;
                    cmdOutDataCorrectionRetVal.Direction = ParameterDirection.Output;
                    cmdOutDataCorrectionRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutDataCorrectionRetVal);

                    SqlParameter cmdOutDataCorrectionIdRetVal = new SqlParameter();
                    cmdOutDataCorrectionIdRetVal.ParameterName = DbConstants.DbProcParamDealDataCorrectionId;
                    cmdOutDataCorrectionIdRetVal.Direction = ParameterDirection.Output;
                    cmdOutDataCorrectionIdRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutDataCorrectionIdRetVal);


                    rowsInserted = cmd.ExecuteNonQuery();
                    result = new
                    {
                        dataCorrectionIdReturnCode = Convert.ToInt32(cmdOutDataCorrectionIdRetVal.Value),
                        basicReturnCode = Convert.ToInt32(cmdOutBasicRetVal.Value),
                        detailReturnCode = Convert.ToInt32(cmdOutDataCorrectionRetVal.Value)
                    };
                }
                return JsonConvert.SerializeObject(result);
            }
            catch
            {
                throw;
            }
        }
        private DataTable ConvertStructureToDatatable(string jsonString)
        {
            var jsonLinq = JArray.Parse(jsonString).ToObject<List<JObject>>();
            DataTable dt = new DataTable("DataCorrectionKeyValue");
            dt.Columns.Add(new DataColumn("facilitySecurityId"));
            dt.Columns.Add(new DataColumn("connectionId"));
            dt.Columns.Add(new DataColumn("attributeId"));
            dt.Columns.Add(new DataColumn("value"));

            for (int i = 0; i < jsonLinq.Count(); i++)
            {
                DataRow dr = dt.NewRow();
                dr["facilitySecurityId"] = jsonLinq[i]["facilitySecurityId"].ToString();
                dr["connectionId"] = jsonLinq[i]["connectionId"].ToString();
                dr["attributeId"] = jsonLinq[i]["attributeId"].ToString();
                dr["value"] = jsonLinq[i]["value"].ToString();
                dt.Rows.Add(dr);
            }
            return dt;
        }

        public IList<UpdateOverrideListEntity> GetUpdateOverrideList(string userName, int dealId, string AsAtDate)
        {
            IList<UpdateOverrideListEntity> objUpdateOverrideListEntity = new List<UpdateOverrideListEntity>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetUpdateOverrideList, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, AsAtDate);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            objUpdateOverrideListEntity.Add(new UpdateOverrideListEntity()
                            {
                                DealId = Utility.GetInt(reader["DealId"]),
                                DealName = Utility.GetString(reader["DealName"]),
                                Status = Utility.GetString(reader["Status"]),
                                StatusId = Utility.GetInt(reader["StatusId"]),
                                OverrideBy = Utility.GetString(reader["OverrideBy"]),
                                OverrideDate = Utility.GetDateTimeNullable(reader["OverrideDate"]),
                                AuthorisedBy = Utility.GetString(reader["AuthorisedBy"]),
                                AuthorisedDate = Utility.GetDateTimeNullable(reader["AuthorisedDate"]),
                                CurrentOverrideVintageDate = Utility.GetDateTimeNullable(reader["CurrentOverrideVintageDate"]),
                                LastOverrideVintageDate = Utility.GetDateTimeNullable(reader["LastOverrideVintageDate"]),
                                LastAuthVintageDate = Utility.GetDateTimeNullable(reader["LastAuthVintageDate"]),
                                DealOverrideParentId = Utility.GetInt(reader["DealOverrideParentId"]),
                                CreatedBy = Utility.GetString(reader["CreatedBy"]),
                                LastActionBy = Utility.GetString(reader["LastActionBy"]),
                                LastActionDate = Utility.GetDateTimeNullable(reader["LastActionDate"]),
                                IsFacilityDownloadAvailable = Utility.GetInt(reader["IsFacilityDownloadAvailable"]),
                                IsSecurityDownloadAvailable = Utility.GetInt(reader["IsSecurityDownloadAvailable"]),
                                IsLinkagesAvailable = Utility.GetInt(reader["IsLinkagesAvailable"]),
                                OtherDraftAvailableMonth = Utility.GetString(reader["OtherDraftAvailableMonth"])
                            });
                        }
                    }
                }
            }
            return objUpdateOverrideListEntity;
        }

        public MemoryStream getLinkageAuditReportData(int dealId, string AsAtDate, string userName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetFacilitySecurityLinkAudit, conn))
            { 
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, AsAtDate);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();

                var noOfColumns = 1;
                var noOfRows = 1;

                var worksheet = workbook.Worksheets.Add($"Facility Security Link Audit");
                if (reader.HasRows)
                {
                    prepareWorkSheet("Security", workbook, worksheet, reader, userName, true);
                }
                else
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                        worksheet.Cell(noOfRows, noOfColumns).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin);
                        noOfColumns++;
                    }
                }

                worksheet.Columns().AdjustToContents();

                reader.Close();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    workbook.Dispose();
                    return stream;
                }
            }
        }

        #region "Download Facility/Security list"
        public MemoryStream getFacilityOverrideData(int dealId, string AsAtDate, string userName, int isTemplate)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetFacilityDataForOverride, conn))
            {

                if(string.IsNullOrEmpty(AsAtDate))
                {
                    AsAtDate = System.DateTime.MinValue.ToShortDateString();
                }

                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, AsAtDate);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamIsTemplate, isTemplate);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();

                var noOfColumns = 1;
                var noOfRows = 1;

                var worksheet = workbook.Worksheets.Add($"Facility");
                if (reader.HasRows)
                {
                    prepareWorkSheet("Facility", workbook, worksheet, reader, userName);
                }
                else
                {
                    string ColName;
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        ColName = reader.GetName(i);
                        worksheet.Cell(noOfRows, noOfColumns).Value = ColName;
                        if (ColName.ToLower().Contains("maturitydate") || ColName.ToLower().Contains("expirydate") || ColName.ToLower().Contains("expiry date") || ColName.ToLower().Contains("rona"))
                        {
                            //125, 249, 255
                            worksheet.Cell(noOfRows, noOfColumns).Style.Fill.BackgroundColor = XLColor.FromArgb(173, 216, 230); 
                        }
                        noOfColumns++;
                    }
                }

                worksheet.Columns().AdjustToContents();

                reader.Close();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    workbook.Dispose();
                    return stream;
                }
            }
        }
        public MemoryStream getFacilityComparisionData(int DealIrConfigId, int dealId, string AsAtDate,
            string PreviousReportingDate, int AnyDiffFlag, string userName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetRefRegComparisionReport_Facility, conn))
            //using (SqlCommand cmd = new SqlCommand("[ps].[spGetRefRegComparisionReport_Facility_SAK]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pDealIrConfigId", 0);
                cmd.Parameters.AddWithValue("@pAsAtDate", AsAtDate);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                cmd.Parameters.AddWithValue("@pPreviousReportingDate", PreviousReportingDate);
                cmd.Parameters.AddWithValue("@pAnyDiffFlag", AnyDiffFlag);

                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();

                var noOfColumns = 1;
                var noOfRows = 1;

                var worksheet = workbook.Worksheets.Add($"Facility Comparision");
                if (reader.HasRows)
                {
                    prepareWorkSheet_ComparisionReport("Facility", workbook, worksheet, reader, userName);
                }
                else
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                        noOfColumns++;
                    }
                }

                reader.Close();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    workbook.Dispose();
                    return stream;
                }
            }
        }


        public MemoryStream getSecurityOverrideData(int dealId, string AsAtDate, string userName, int isTemplate)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetSecurityDataForOverride, conn))
            {

                if(string.IsNullOrEmpty(AsAtDate))
                {
                    AsAtDate = System.DateTime.MinValue.ToShortDateString();
                }

                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, AsAtDate);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamIsTemplate, isTemplate);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();

                var noOfColumns = 1;
                var noOfRows = 1;

                var worksheet = workbook.Worksheets.Add($"Security");
                if (reader.HasRows)
                {
                    prepareWorkSheet("Security", workbook, worksheet, reader, userName);
                }
                else
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                        noOfColumns++;
                    }
                }

                worksheet.Columns().AdjustToContents();

                reader.Close();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    workbook.Dispose();
                    return stream;
                }
            }
        }

        public MemoryStream getSecurityComparisionData(int DealIrConfigId, int dealId, string AsAtDate,
            string PreviousReportingDate, int AnyDiffFlag, string userName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[ps].[spGetRefRegComparisionReport_Security]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pDealIrConfigId", 0);
                cmd.Parameters.AddWithValue("@pAsAtDate", AsAtDate);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                cmd.Parameters.AddWithValue("@pPreviousReportingDate", PreviousReportingDate);
                cmd.Parameters.AddWithValue("@pAnyDiffFlag", AnyDiffFlag);

                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();

                var noOfColumns = 1;
                var noOfRows = 1;

                var worksheet = workbook.Worksheets.Add($"Security Comparision");
                if (reader.HasRows)
                {
                    prepareWorkSheet_ComparisionReport("Security", workbook, worksheet, reader, userName);
                }
                else
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                        noOfColumns++;
                    }
                }

                reader.Close();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    workbook.Dispose();
                    return stream;
                }
            }
        }

        private void prepareWorkSheet(string workSheetName, XLWorkbook workbook, IXLWorksheet worksheet,
            SqlDataReader reader, string loggedInUserName, bool isBorderRequired = false)
        {
            var noOfColumns = 1;
            var noOfRows = 1;

            List<int> AccountingFormatIndexes = new List<int>();
            List<string> AccountingDisplayFormats = new List<string>();
            List<int> UpdatedColumnsIndex = new List<int>();

            while (reader.Read())
            {
                if (noOfRows == 1)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        string ColName = reader.GetName(i);

                        worksheet.Cell(noOfRows, noOfColumns).Value = ColName;

                        if (workSheetName.ToLower() == "facility" &&
                            (ColName.ToLower().Contains("maturitydate") || ColName.ToLower().Contains("expirydate") || ColName.ToLower().Contains("expiry date") || ColName.ToLower().Contains("rona")))
                        {
                            //125, 249, 255
                            worksheet.Cell(noOfRows, noOfColumns).Style.Fill.BackgroundColor = XLColor.FromArgb(173, 216, 230);
                            //UpdatedColumnsIndex.Add(i + 1);
                        }
                        if (isBorderRequired)
                            worksheet.Cell(noOfRows, noOfColumns).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin);
                        noOfColumns++;
                    }
                    noOfRows++;
                    AddValuesToWorkSheet(reader, worksheet, noOfRows, AccountingFormatIndexes, AccountingDisplayFormats, UpdatedColumnsIndex, true);
                    noOfRows++;
                }
                else
                {
                    AddValuesToWorkSheet(reader, worksheet, noOfRows, AccountingFormatIndexes, AccountingDisplayFormats, UpdatedColumnsIndex, true);
                    noOfRows++;
                }
            }
            worksheet.Columns().AdjustToContents();
        }

        private void prepareWorkSheet_ComparisionReport(string workSheetName, XLWorkbook workbook, IXLWorksheet worksheet, SqlDataReader reader, string loggedInUserName)
        {
            var noOfColumns = 1;
            var noOfRows = 1;

            //string[] fieldAttributeList = GetAccountingFormatFields(loggedInUserName);
            List<ECFieldAttribute> lstFieldsAttribute = GetECFieldAttributeList(loggedInUserName);
            List<int> AccountingFormatIndexes = new List<int>();
            List<string> AccountingDisplayFormats = new List<string>();

            var tblHeaders = new DataTable();
            tblHeaders.Columns.Add("Header_1");
            tblHeaders.Columns.Add("Header_2");
            tblHeaders.Columns.Add("DisplayFormat");

            Dictionary<string, string> Headersdict = new Dictionary<string, string>(); 
            List<string> lstMainHeaders = new List<string>();
            List<int> lstDifferenceColNumber = new List<int>();

            while (reader.Read())
            {
                if (noOfRows == 1)
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        var DataRow = tblHeaders.NewRow();
                        string ColName = reader.GetName(i); 
                        string[] ColsAry = ColName.Split("#"); 
                        DataRow["Header_1"] = ColsAry[0].ToString();
                        DataRow["Header_2"] = ColsAry[0].ToString();
                        DataRow["DisplayFormat"] = "";
                        if (ColsAry.Length > 1)
                        {
                            DataRow["Header_2"] = ColsAry[1].ToString();
                            if (ColsAry[1].ToString().ToLower().Contains("difference"))
                                lstDifferenceColNumber.Add(i + 1);
                        }
                        lstMainHeaders.Add(ColsAry[0].ToString()); 

                        if(lstFieldsAttribute != null && lstFieldsAttribute.Count() > 0 && 
                            lstFieldsAttribute.Where(f=> f.FieldName.ToLower() == ColsAry[0].ToString().ToLower()).Count()> 0)
                        {
                            DataRow["DisplayFormat"] 
                                = lstFieldsAttribute.Where(f => f.FieldName.ToLower() == ColsAry[0].ToString().ToLower()).FirstOrDefault().DisplayFormat;
                        }

                        tblHeaders.Rows.Add(DataRow);
                    }

                    // CREATING 1st HEADER
                    foreach (string header1 in lstMainHeaders.Distinct())
                    {
                        DataRow[] dr = tblHeaders.Select("Header_1 = '" + header1 + "'");
                        worksheet.Cell(noOfRows, noOfColumns).Value = header1;

                        worksheet.Cell(noOfRows, noOfColumns).Style.Font.Bold = true;
                        worksheet.Cell(noOfRows, noOfColumns).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        if(header1.ToLower() == "maturity" || header1.ToLower().Contains("rona"))
                        worksheet.Cell(noOfRows, noOfColumns).Style.Fill.BackgroundColor = XLColor.FromArgb(173, 216, 230);
                        worksheet.Range(1, noOfColumns, 1, (noOfColumns+ dr.Count()-1) ).Merge();
                        worksheet.Range(1, noOfColumns, 1, (noOfColumns + dr.Count() - 1)).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin);

                        noOfColumns = noOfColumns+ dr.Count();
                    }
                    noOfRows++;

                    // CREATING 2nd HEADER
                    noOfColumns = 1;
                    foreach (DataRow dRow in tblHeaders.Rows)
                    { 
                        worksheet.Cell(noOfRows, noOfColumns).Value = dRow["Header_2"].ToString();
                        worksheet.Cell(noOfRows, noOfColumns).Style.Font.Bold = true;
                        worksheet.Cell(noOfRows, noOfColumns).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(noOfRows, noOfColumns).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin); 

                        noOfColumns++;
                    }
                    noOfRows++;

                    AddValuesToWorkSheetComparision(reader, worksheet, noOfRows, AccountingFormatIndexes,
                                                    AccountingDisplayFormats, lstDifferenceColNumber, tblHeaders);
                    noOfRows++;

                }
                else
                {
                    AddValuesToWorkSheetComparision(reader, worksheet, noOfRows, AccountingFormatIndexes, 
                                                    AccountingDisplayFormats, lstDifferenceColNumber, tblHeaders);
                    noOfRows++;
                }
            }
            worksheet.Columns().AdjustToContents();
            worksheet.Row(1).Height = 17;

        }

       
        private void AddValuesToWorkSheetComparision(SqlDataReader reader, IXLWorksheet worksheet, int noOfRows,
           List<int> accountingFormatIndexes, List<string> AccountingDisplayFormats, List<int> lstDifferenceColNumber, DataTable tblHeaders)
        {
            var noOfFields = reader.FieldCount;
            string DisplayFormat = "";
            for (int i = 1; i <= noOfFields; i++)
            {
                object _readerVal = reader.GetValue(i - 1);
                worksheet.Cell(noOfRows, i).Value = _readerVal;

                DisplayFormat = tblHeaders.Rows[i - 1]["DisplayFormat"].ToString();
                if (!string.IsNullOrEmpty(DisplayFormat))
                {
                    worksheet.Cell(noOfRows, i).Style.NumberFormat.Format = DisplayFormat;
                }
                else
                {
                    if (_readerVal != null && _readerVal.ToString().Length > 8)
                    {
                        DateTime? OutputDate = Utility.GetDateTimeNullable(_readerVal);
                        if (OutputDate != null)
                        {
                            //if (OutputDate.Value.Year == 1900 && OutputDate.Value.Month == 1 && OutputDate.Value.Day == 1)
                            //{
                            //    OutputDate = OutputDate.Value.AddDays(-1);
                            //    worksheet.Cell(noOfRows, i).Value = OutputDate;
                            //} 
                            worksheet.Cell(noOfRows, i).Style.DateFormat.Format = "ddmmmyyyy";
                        }
                    }
                }

                if (lstDifferenceColNumber.Contains(i))
                {
                    double intVal = getNumberValue(_readerVal.ToString());

                    if (_readerVal != null && _readerVal.ToString() != "" && (_readerVal.ToString().ToLower() == "false" || intVal != 0))
                    {
                        worksheet.Cell(noOfRows, i).Style.Fill.BackgroundColor = XLColor.FromArgb(255, 191, 0);
                    }
                }
            }
        }

        private double getNumberValue(string inputValue)
        {
            double dblVal = 0; 
            if(double.TryParse(inputValue, out dblVal))
            {
                return dblVal;
            } 
            return dblVal;
        }


        private void AddValuesToWorkSheet(SqlDataReader reader, IXLWorksheet worksheet, int noOfRows,
           List<int> accountingFormatIndexes, List<string> AccountingDisplayFormats, List<int> UpdatedColumnsIndex = null, bool isBorderRequired = false)
        {
            var noOfFields = reader.FieldCount;
            for (int i = 1; i <= noOfFields; i++)
            {
                object _readerVal = reader.GetValue(i - 1);
                worksheet.Cell(noOfRows, i).Value = _readerVal;

                if(UpdatedColumnsIndex != null && UpdatedColumnsIndex.Contains(i))
                {
                    worksheet.Cell(noOfRows, i).Style.Fill.BackgroundColor = XLColor.FromArgb(125, 249, 255);
                }
                if (isBorderRequired)
                    worksheet.Cell(noOfRows, i).Style.Border.SetOutsideBorder(XLBorderStyleValues.Thin);
            }
        }

        public MemoryStream GetOverrideAuditTrailData(int dealId, string entityType, string vintagedate, string userName)
        {
            CultureInfo.CurrentCulture = new CultureInfo("en-EN");
            IList<string> attributeList = new List<string>();       // Used for storing the order of the attributes that will be output for the whole sheet

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetOverrideAuditTrail, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@dealId", dealId);
                cmd.Parameters.AddWithValue("@pEntityName", entityType);
                cmd.Parameters.AddWithValue("@vintageDate", vintagedate);
                cmd.Parameters.AddWithValue("@pUserName", userName);

                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();

                var worksheet = workbook.Worksheets.Add($"{entityType} Override Audit Trail");
                worksheet.Cell(1, 1).Value = "Latest Overridden By";
                worksheet.Cell(2, 1).Value = "Latest Authorised By";
                worksheet.Cell(3, 1).Value = "Deal Name";
                worksheet.Cell(1, 3).Value = "Latest Override Date";
                worksheet.Cell(2, 3).Value = "Latest Authorisation Date";
                worksheet.Cell(3, 3).Value = "Vintage Date";

                var range1 = worksheet.Range("A1:D3");
                range1.Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                range1.Style.Border.InsideBorder = XLBorderStyleValues.Thin;

                // Just add the DealName to the Excel file. This ensures that we will have the DealName even if there is no override for that deal
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        worksheet.Cell(3, 2).Value = Utility.GetString(reader[0]);
                    }
                }

                reader.NextResult();

                // Create first table with meta data
                if (reader.HasRows)
                {
                    //int fieldCount = reader.FieldCount;
                    while (reader.Read())
                    {
                        worksheet.Cell(1, 2).Value = Utility.GetString(reader[0]);
                        worksheet.Cell(1, 4).Value = Utility.GetShortDateTime(reader[1]);
                        worksheet.Cell(2, 2).Value = Utility.GetString(reader[2]);
                        worksheet.Cell(2, 4).Value = Utility.GetShortDateTime(reader[3]);
                        worksheet.Cell(3, 4).Value = Utility.GetShortDateTime(reader[5]);
                    }
                }

                reader.NextResult();

                // Create the 2 row header for second table
                if (reader.HasRows)
                {
                    int columnIndex = 2;

                    worksheet.Cell(6, 1).Value = "Facility ID";
                    worksheet.Cell(6, 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;

                    while (reader.Read())
                    {
                        var attributeName = Utility.GetString(reader["AttributeName"]);
                        attributeList.Add(attributeName);
                        var attributeFieldName = Utility.GetString(reader["AttributeFieldName"]);
                        worksheet.Cell(5, columnIndex).Value = attributeFieldName;
                        worksheet.Cell(5, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Range(5, columnIndex, 5, columnIndex + 1).Row(1).Merge();
                        worksheet.Cell(6, columnIndex).Value = "System Value";
                        worksheet.Cell(6, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                        worksheet.Cell(6, columnIndex + 1).Value = "Overridden Value";

                        worksheet.Cell(5, columnIndex).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        worksheet.Cell(5, columnIndex + 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        worksheet.Cell(6, columnIndex).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        worksheet.Cell(6, columnIndex + 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;

                        columnIndex += 2;
                    }
                    worksheet.Cell(5, columnIndex).Value = "Audit Trail";
                    worksheet.Cell(5, columnIndex).Style.Alignment.Horizontal = XLAlignmentHorizontalValues.Center;
                    worksheet.Range(5, columnIndex, 5, columnIndex + 3).Row(1).Merge();
                    worksheet.Cell(5, columnIndex).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    worksheet.Cell(5, columnIndex + 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    worksheet.Cell(5, columnIndex + 2).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    worksheet.Cell(5, columnIndex + 3).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    worksheet.Cell(6, columnIndex).Value = "Override By";
                    worksheet.Cell(6, columnIndex + 1).Value = "Authorised By";
                    worksheet.Cell(6, columnIndex + 2).Value = "Override Date";
                    worksheet.Cell(6, columnIndex + 3).Value = "Authorisation Date";

                    worksheet.Range(6, columnIndex, 6, columnIndex + 3).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                    worksheet.Range(6, columnIndex, 6, columnIndex + 3).Style.Border.InsideBorder = XLBorderStyleValues.Thin;
                }
                else
                {
                    int rowIndex = 7;
                    worksheet.Cell(rowIndex, 1).Value = Utility.GetString("NO ATTRIBUTES AVAILABLE");

                    reader.Close();
                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        workbook.Dispose();
                        return stream;
                    }
                }

                reader.NextResult();

                // Output the details for populating second table
                if (reader.HasRows)
                {
                    int rowIndex = 7;
                    while (reader.Read())
                    {
                        int colIndex = 2;
                        worksheet.Cell(rowIndex, 1).Value = Utility.GetString(reader["FacilitySecurityId"]);
                        worksheet.Cell(rowIndex, 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        for (int i = 0; i < attributeList.Count(); i++)
                        {
                            string originalValueColumnName = attributeList[i];
                            string overriddenValueColumnName = attributeList[i] + "-OverrideValue";
                            worksheet.Cell(rowIndex, colIndex).Value = Utility.GetString(reader[originalValueColumnName]);
                            worksheet.Cell(rowIndex, colIndex).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                            worksheet.Cell(rowIndex, colIndex + 1).Value = Utility.GetString(reader[overriddenValueColumnName]);
                            worksheet.Cell(rowIndex, colIndex + 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                            colIndex += 2;
                        }
                        worksheet.Cell(rowIndex, colIndex).Value = Utility.GetString(reader["OverrideBy"]);
                        worksheet.Cell(rowIndex, colIndex).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        worksheet.Cell(rowIndex, colIndex + 1).Value = Utility.GetString(reader["AuthorizedBy"]);
                        worksheet.Cell(rowIndex, colIndex + 1).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        worksheet.Cell(rowIndex, colIndex + 2).Value = Utility.GetString(reader["OverrideDate"]);
                        worksheet.Cell(rowIndex, colIndex + 2).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        worksheet.Cell(rowIndex, colIndex + 3).Value = Utility.GetString(reader["AuthorizedDate"]);
                        worksheet.Cell(rowIndex, colIndex + 3).Style.Border.OutsideBorder = XLBorderStyleValues.Thin;
                        rowIndex++;
                    }
                }
                worksheet.Columns().AdjustToContents();
                reader.Close();
                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    workbook.Dispose();
                    return stream;
                }
            }
        }

        public IList<string> GetOverrideVintageDateList(int dealId, string userName)
        {
            IList<string> vintageDateList = new List<string>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetOverrideVintageDateList, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            vintageDateList.Add(Utility.GetShortDateTime(reader["VintageDate"]));
                        }
                    }
                }
            }
            return vintageDateList;
        }

        #endregion


        #region "Save Facility/Security upload"

        public int saveOverrideData(int dealId, string AsAtDate, string userName, IFormFileCollection _files, 
            List<FacilitySecurityLink> LinkList, string isListEdited, IFormCollection formCollection,
           out List<Dictionary<string, string>> ErrorExcel,
           out List<string> LstcolumnNames, out string ErrorEntity)
        {
            ErrorExcel = new List<Dictionary<string, string>>();
            LstcolumnNames = new List<string>();
            ErrorEntity = "";
            int validationResult = 0;

            if (_files.Count > 0)
            {
                // VALIDATE EACH ATTACHED FILES
                foreach (var file in _files)
                {
                    if (file.Length > 0)
                    {
                        string[][] UploadedData = null; 
                        if (file.Name.ToLower() == "facility")
                        {
                            if (!string.IsNullOrEmpty(formCollection["FacilityFileUploadData"]))
                            {
                                UploadedData = JsonConvert.DeserializeObject<string[][]>(formCollection["FacilityFileUploadData"].ToString());
                            }
                            ErrorEntity = "Facility";
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(formCollection["SecurityFileUploadData"]))
                            {
                                UploadedData = JsonConvert.DeserializeObject<string[][]>(formCollection["SecurityFileUploadData"].ToString());
                            }
                            ErrorEntity = "Security";
                        }
                        

                        validationResult = validateAndSaveUploadedExcel(dealId, AsAtDate, userName, file, file.Name, UploadedData,
                            out ErrorExcel, out LstcolumnNames, false);

                        if (validationResult != 0)
                        {
                            //ErrorEntity = file.Name.ToLower() == "facility" ? "Facility" : "Security";
                            return validationResult;
                        }
                    }
                }

                // SAVE EACH ATTACHED FILES, IF THERE IS NO VALIDATION ERROR FOUND
                foreach (var file in _files)
                {
                    if (file.Length > 0)
                    {
                        string[][] UploadedData = null;
                        if (file.Name.ToLower() == "facility")
                        {
                            if (!string.IsNullOrEmpty(formCollection["FacilityFileUploadData"]))
                            {
                                UploadedData = JsonConvert.DeserializeObject<string[][]>(formCollection["FacilityFileUploadData"].ToString());
                            }
                            ErrorEntity = "Facility";
                        }
                        else
                        {
                            if (!string.IsNullOrEmpty(formCollection["SecurityFileUploadData"]))
                            {
                                UploadedData = JsonConvert.DeserializeObject<string[][]>(formCollection["SecurityFileUploadData"].ToString());
                            }
                            ErrorEntity = "Security";
                        }

                        validationResult = validateAndSaveUploadedExcel(dealId, AsAtDate, userName, file, file.Name, UploadedData,
                            out ErrorExcel, out LstcolumnNames, true);

                        if (validationResult != 0)
                        {
                            //ErrorEntity = file.Name.ToLower() == "facility" ? "Facility" : "Security";
                            return validationResult;
                        }
                    }
                }
            }


            if (isListEdited == "1")
            {
                validationResult = SaveFacilitySecurityLinkData(dealId, AsAtDate, userName, LinkList, isListEdited);
                if (validationResult != 0)
                {
                    ErrorEntity = "Relinking";
                    return validationResult;
                }
            }
            return 0;
        }

        public int validateAndSaveUploadedExcel(int dealId, string AsAtDate, string userName, IFormFile _file,
            string EntityTypeName, string[][] UploadedData, out List<Dictionary<string, string>> ErrorExcel,
            out List<string> LstcolumnNames, bool isCalledForSave)
        {
            ErrorExcel = new List<Dictionary<string, string>>();
            LstcolumnNames = new List<string>();
            var ms = new MemoryStream();
            int Result = 0;

            try
            {
                //var files = _files; // HttpContext.Request.Form.Files;
                //if (files.Count > 0)
                {
                    //foreach (var file in files)
                    {
                        if (_file.Length > 0)
                        {
                            //using (var ms = new MemoryStream())
                            {
                                _file.CopyTo(ms);
                                ms.Seek(0, SeekOrigin.Begin);

                                var inputstream = _file.OpenReadStream();
                                XLWorkbook workbook = new XLWorkbook(inputstream);
                                List<string> HdrColumnsUploaded = new List<string>();
                                DataTable UploadedExcelTable = new DataTable();
                                List<DataCorrectionAttribute> LstOverrideDbFieldAttribute = GetOverrideFieldAttribute(EntityTypeName.ToLower());

                                bool isExist = workbook.Worksheets.Any(item => item.Name.ToLower() == EntityTypeName.ToLower());
                                if (isExist)
                                {
                                    IXLWorksheet ws = workbook.Worksheets.FirstOrDefault();
                                    IXLRange range = ws.RangeUsed();
                                    int rowRange = range.RowCount();
                                    int colRange = range.ColumnCount();

                                    //CHECK IF DATA STARTING AT FIRST CELL OF EXCEL 
                                    if (ws.Cell(1, 1) == null || ws.Cell(1, 1).Value == null || string.IsNullOrEmpty(ws.Cell(1, 1).Value.ToString().Trim()))
                                    {
                                        Result = -9; //Data not starting at first cell. Invalid file format.
                                        return Result;
                                    }

                                    //CHECK HEADER COUNT AGAINST UPLOADED DATA // 
                                    for (int Hdrcol = 1; Hdrcol <= colRange; Hdrcol++)
                                    {
                                        if (ws.Cell(1, Hdrcol) != null && ws.Cell(1, Hdrcol).Value != null && !string.IsNullOrEmpty(ws.Cell(1, Hdrcol).Value.ToString().Trim()))
                                        {
                                            HdrColumnsUploaded.Add(ws.Cell(1, Hdrcol).Value.ToString());
                                        }
                                    }
                                    if (HdrColumnsUploaded.Count != colRange)
                                    {
                                        Result = -2; // There are some columns in uploaded file without header
                                        return Result;
                                    }

                                    if (LstOverrideDbFieldAttribute == null || LstOverrideDbFieldAttribute.Count == 0)
                                    {
                                        Result = -3; //There is no attribute available for this entity to upload
                                        return Result;
                                    }

                                    // Check if the uploaded columns are available in attribute config table
                                    {
                                        foreach (string myStr in HdrColumnsUploaded)
                                        {
                                            if (LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.Trim().ToLower() == myStr.Trim().ToLower()).Count() == 0)
                                            {
                                                Result = -4; //The uploaded column is not available in attribute table (Header altered in uploaded file)
                                                return Result;
                                            }
                                        }
                                    }

                                    // LOAD ALL UPLOADED DATA INTO DATATABLE
                                    //bool firstRow = true;
                                    //string UploadedColumnName = "";
                                    ////int AttributeID;
                                    //for (int row = 1; row <= rowRange; row++)
                                    //{
                                    //    if (firstRow)
                                    //    {
                                    //        for (int col = 1; col <= colRange; col++)
                                    //        {
                                    //            //Keep attribute ID as ColumnName 
                                    //            UploadedColumnName = ws.Cell(row, col).Value.ToString();
                                    //            //AttributeID = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == UploadedColumnName).FirstOrDefault().AttributeId;
                                    //            UploadedExcelTable.Columns.Add(UploadedColumnName.ToString());
                                    //        }
                                    //        firstRow = false;
                                    //    }
                                    //    else
                                    //    {
                                    //        //Add rows to DataTable.
                                    //        UploadedExcelTable.Rows.Add();
                                    //        for (int col = 1; col <= colRange; col++)
                                    //        {
                                    //            string CurrentCellValue = ws.Cell(row, col).Value.ToString();
                                    //            DateTime tmpDateTime;
                                    //            int tmpInt; double tmpDbl;

                                    //            if (int.TryParse(CurrentCellValue, out tmpInt)) {}
                                    //            else if (double.TryParse(CurrentCellValue, out tmpDbl)) {}
                                    //            else if (DateTime.TryParse(CurrentCellValue, out tmpDateTime))
                                    //            {
                                    //                CurrentCellValue = tmpDateTime.ToString("dd-MM-yyyy"); //("yyyy-MM-dd");
                                    //            }

                                    //            UploadedExcelTable.Rows[UploadedExcelTable.Rows.Count - 1][col - 1] = CurrentCellValue;
                                    //        }
                                    //    }
                                    //}

                                    // LOAD ALL UPLOADED DATA INTO DATATABLE
                                    UploadedExcelTable = prepareTableFromUploadedData(UploadedData);
                                    UploadedExcelTable.Columns.Add("Error");


                                    // CHECK DATA TYPES OF UPLOADED VALUES
                                    int ValidationResult = 0;
                                    ValidationResult = checkUploadedFieldsDataTypes(UploadedExcelTable, LstOverrideDbFieldAttribute);
                                    if (ValidationResult != 0)
                                    {
                                        Result = ValidationResult; // -6 datatype error, -5 DataType not available in config table. 
                                        prepareErrorOutput(UploadedExcelTable, out ErrorExcel, out LstcolumnNames);
                                        return Result;
                                    }


                                    //VALIDATE DUPLICATE VALUES IN KEY COLUMN
                                    ValidationResult = checkDuplicateValueInKeyColumn(UploadedExcelTable, EntityTypeName.ToLower());
                                    if (ValidationResult != 0)
                                    {
                                        Result = ValidationResult; // -12 Duplicate values found in Key column 
                                        prepareErrorOutput(UploadedExcelTable, out ErrorExcel, out LstcolumnNames);
                                        return Result;
                                    }

                                    //VALIDATE IF ANY VALUES TO UPLOAD
                                    ValidationResult = checkEmptyRowInUploadFile(UploadedExcelTable, EntityTypeName.ToLower());
                                    if (ValidationResult != 0)
                                    {
                                        Result = ValidationResult; // -13 All empty values found 
                                        prepareErrorOutput(UploadedExcelTable, out ErrorExcel, out LstcolumnNames);
                                        return Result;
                                    }
 
                                    if (!isCalledForSave)
                                    {
                                        int isRonaOverrideAvailable = GetIsDataAvailableInUploadedFile("rona", UploadedExcelTable);

                                        // FILL COMMON SP, OUTPUT
                                        DataTable tblCommonSpData = GetFacilitySecurityIDsFromCommonSP(AsAtDate, dealId, userName, isRonaOverrideAvailable);

                                        // CHECK THE UPLOADED KEY VALUES AGAINST COMMON SP'S LIST
                                        if (!isCalledForSave)
                                        {
                                            ValidationResult = checkKeyColumnInCommonSP(UploadedExcelTable, tblCommonSpData, EntityTypeName.ToLower());
                                            if (ValidationResult != 0)
                                            {
                                                Result = ValidationResult; // -14 Invalid key data found. 
                                                prepareErrorOutput(UploadedExcelTable, out ErrorExcel, out LstcolumnNames);
                                                return Result;
                                            }
                                        }

                                        // CHECK EXPIRY DATE VALIDATION 
                                        if (LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == "expirydate" || ts.AttributeName.ToLower() == "maturitydate" || ts.AttributeName.ToLower() == "maturitydate@sec") != null &&
                                         LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == "expirydate"
                                         || ts.AttributeName.ToLower() == "maturitydate"
                                         || ts.AttributeName.ToLower() == "maturitydate@sec").Count() > 0)
                                        {
                                            ValidationResult = checkUploadedFieldsOtherValidations(UploadedExcelTable, tblCommonSpData, LstOverrideDbFieldAttribute,
                                              AsAtDate, dealId, EntityTypeName.ToLower());
                                            if (ValidationResult != 0)
                                            {
                                                Result = ValidationResult; // -10 Key column not configured, -11 Invalid expiry date. 
                                                prepareErrorOutput(UploadedExcelTable, out ErrorExcel, out LstcolumnNames);
                                                return Result;
                                            }
                                        }

                                        //VALIDATE RONA VALUES
                                        if (LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == "rona") != null &&
                                         LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == "rona").Count() > 0)
                                        {
                                            ValidationResult = ValidateRona("RONA", UploadedExcelTable, tblCommonSpData, LstOverrideDbFieldAttribute);
                                            if (ValidationResult != 0)
                                            {
                                                Result = ValidationResult; // -15 Invalid RONA uploaded 
                                                prepareErrorOutput(UploadedExcelTable, out ErrorExcel, out LstcolumnNames);
                                                return Result;
                                            }
                                        }

                                    }
                                    

                                    //VALIDATION SUCCESS // call save from parent function
                                    //TRANSPOSE THE TABLE AND CALL SP FOR INSERT
                                    if (isCalledForSave)
                                    {
                                        string EntityKeyColumn = EntityTypeName.ToLower() == "facility" ? "facilityId" : "securityId";
                                        DataTable tblTranspose = TransposeUploadedDatatable(UploadedExcelTable, EntityKeyColumn, LstOverrideDbFieldAttribute);
                                        // save data
                                        SaveFacilitySecurityCorrectionData(dealId, AsAtDate, EntityTypeName, tblTranspose, userName);
                                    }
                                }
                                else
                                {
                                    Result = -8;  // Excel sheet not available
                                }
                            }

                        }
                        else
                        {
                            Result = -1; //invalid file;
                        }
                    }
                }
                //else
                //{
                //    Result = -1; //invalid file;
                //}
            }
            catch (Exception ex)
            {
                throw ex;
            }

            return Result;
        }


        private DataTable prepareTableFromUploadedData(string[][] UploadedJsonData)
        {
            DataTable tblUploadedData = new DataTable();

            int NoOfRows = UploadedJsonData.Length;
            int NoOfColumns = 0;

            if (NoOfRows > 0)
            {
                NoOfColumns = UploadedJsonData[0].Length;
            }
            if(NoOfColumns > 0)
            {
                int isHeader = 1;
                foreach(string[] item_Row in UploadedJsonData)
                {
                    if (isHeader == 1) // create table columns
                    {
                        foreach (string itemVal in item_Row)
                        {
                            tblUploadedData.Columns.Add(itemVal);
                        }
                        isHeader = 0;
                    }
                    else
                    {
                        if (item_Row.Length > 0)
                        {
                            tblUploadedData.Rows.Add();
                            int colIndex = 0;
                            foreach (string itemVal in item_Row)
                            {
                                string CurrentCellValue = itemVal;
                                DateTime tmpDateTime;
                                int tmpInt; double tmpDbl;

                                if (int.TryParse(CurrentCellValue, out tmpInt)) { }
                                else if (double.TryParse(CurrentCellValue, out tmpDbl)) { }
                                else if (DateTime.TryParse(CurrentCellValue, out tmpDateTime))
                                {
                                    CurrentCellValue = tmpDateTime.ToString("yyyy-MM-dd");
                                }
                                tblUploadedData.Rows[tblUploadedData.Rows.Count - 1][colIndex] = CurrentCellValue;
                                colIndex++;
                            }
                        }
                    } 
                }
            }


            return tblUploadedData;
        }
        

        private void prepareErrorOutput(DataTable UploadedExcelTable,
            out List<Dictionary<string, string>> ErrorExcel,
            out List<string> LstcolumnNames)
        {
            ErrorExcel = new List<Dictionary<string, string>>();
            LstcolumnNames = new List<string>();

            List<Dictionary<string, string>> _ErrorDictRows = new List<Dictionary<string, string>>();
            Dictionary<string, string> _ErrorDict;
            int isFirstRow = 0;
            foreach (DataRow _drError in UploadedExcelTable.Rows)
            {
                _ErrorDict = new Dictionary<string, string>();
                foreach (DataColumn _Errorcol in UploadedExcelTable.Columns)
                {
                    _ErrorDict.Add(_Errorcol.ColumnName, _drError[_Errorcol].ToString());
                    if (isFirstRow == 0)
                    {
                        LstcolumnNames.Add(_Errorcol.ColumnName);
                    }
                }
                isFirstRow = 1;
                _ErrorDictRows.Add(_ErrorDict);
            }
            // return serializer.Serialize(_ErrorDictRows);
            //ErrorExcelJson = JsonConvert.SerializeObject(_ErrorDictRows);
            ErrorExcel = _ErrorDictRows;
        }

        public string SaveFacilitySecurityCorrectionData(int dealId, string AsAtDate, 
            string EntityTypeName, DataTable dtDataCorrectionKeyValue, string userName)
        {
            try
            {
                int rowsInserted = 0;
                dynamic result = null;
                int InitialStatus = 1; // basicInfo.Status == "Draft" ? 1 : -1; 
                //DataTable dtDataCorrectionKeyValue = ConvertStructureToDatatable(basicInfo.CorrectedData);

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_SaveDataCorrection, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(AsAtDate).ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcEntityName, EntityTypeName); 
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcStatusId, InitialStatus);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParampDataCorrectionList, dtDataCorrectionKeyValue); 

                    SqlParameter cmdOutBasicRetVal = new SqlParameter();
                    cmdOutBasicRetVal.ParameterName = DbConstants.DbProcParamBasicInfoResult;
                    cmdOutBasicRetVal.Direction = ParameterDirection.Output;
                    cmdOutBasicRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutBasicRetVal);

                    SqlParameter cmdOutDataCorrectionRetVal = new SqlParameter();
                    cmdOutDataCorrectionRetVal.ParameterName = DbConstants.DbProcParamDataCorrectionResult;
                    cmdOutDataCorrectionRetVal.Direction = ParameterDirection.Output;
                    cmdOutDataCorrectionRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutDataCorrectionRetVal);

                    SqlParameter cmdOutDataCorrectionIdRetVal = new SqlParameter();
                    cmdOutDataCorrectionIdRetVal.ParameterName = DbConstants.DbProcParamDealDataCorrectionId;
                    cmdOutDataCorrectionIdRetVal.Direction = ParameterDirection.Output;
                    cmdOutDataCorrectionIdRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutDataCorrectionIdRetVal);

                    rowsInserted = cmd.ExecuteNonQuery();
                    result = new
                    {
                        dataCorrectionIdReturnCode = Convert.ToInt32(cmdOutDataCorrectionIdRetVal.Value),
                        basicReturnCode = Convert.ToInt32(cmdOutBasicRetVal.Value),
                        detailReturnCode = Convert.ToInt32(cmdOutDataCorrectionRetVal.Value)
                    };
                }
                return JsonConvert.SerializeObject(result);
            }
            catch
            {
                throw;
            }
        }

        public int SaveFacilitySecurityLinkData(int dealId, string AsAtDate,  string userName, List<FacilitySecurityLink> LinkList, string isListEdited)
        {
            try
            {
                int rowsInserted = 0;
                int result = -1;
                int InitialStatus = 1;

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand("[corp].[spSaveOverrideLinkagesList]", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(AsAtDate).ToString("yyyy-MM-dd"));
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcStatusId, InitialStatus);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.AddWithValue("@pisListEdited", isListEdited);

                    /****/
                    var LinkItems = new DataTable();
                    LinkItems.Columns.Add("dealId", typeof(Int32));
                    LinkItems.Columns.Add("asAtDate", typeof(string));
                    LinkItems.Columns.Add("facilityId", typeof(string));
                    LinkItems.Columns.Add("securityId", typeof(string));
                    LinkItems.Columns.Add("cradleSecurityId", typeof(string));
                    LinkItems.Columns.Add("connectionId", typeof(string));
                    LinkItems.Columns.Add("securityKey", typeof(string));
                    LinkItems.Columns.Add("isLinked", typeof(string));
                    LinkItems.Columns.Add("isListEdited", typeof(string));
                    foreach (var linkItem in LinkList)
                    {

                        linkItem.isLinked = (linkItem.isLinked.ToLower() == "true" || linkItem.isLinked == "1") ? "1" : "0";

                        LinkItems.Rows.Add(dealId, Convert.ToDateTime(AsAtDate).ToString("yyyy-MM-dd"),
                           Utility.GetString(linkItem.facilityId), Utility.GetString(linkItem.securityId),
                           Utility.GetString(linkItem.cradleSecurityId), Utility.GetString(linkItem.connectionId),
                           Utility.GetString(linkItem.securityKey),Utility.GetString(linkItem.isLinked),
                           Utility.GetString(linkItem.isListEdited));
                    }

                    SqlParameter ListParam = new SqlParameter("@pLinkItems", SqlDbType.Structured);
                    ListParam.SqlValue = LinkItems;
                    ListParam.TypeName = "[corp].[FacilitySequrityLinkItem]";
                    cmd.Parameters.Add(ListParam); 

                    SqlParameter cmdOutLinkageRetVal = new SqlParameter();
                    cmdOutLinkageRetVal.ParameterName = "@pResult";
                    cmdOutLinkageRetVal.Direction = ParameterDirection.Output;
                    cmdOutLinkageRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutLinkageRetVal);

                    rowsInserted = cmd.ExecuteNonQuery();
                    result = Convert.ToInt32(cmdOutLinkageRetVal.Value);
                }
                return result;
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        private List<DataCorrectionAttribute> GetOverrideFieldAttribute(string EntityTypeName)
        {
            List<DataCorrectionAttribute> attributeList = new List<DataCorrectionAttribute>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetOverrideFieldAttributes, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();

                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamEntityTypeName, EntityTypeName);
                    cmd.CommandTimeout = 0;

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            attributeList.Add(new DataCorrectionAttribute()
                            {
                                AttributeId = Utility.GetInt(reader["AttributeId"]),
                                AttributeName = Utility.GetString(reader["AttributeName"]),
                                DisplayName = Utility.GetString(reader["DisplayName"]),
                                DataType = Utility.GetString(reader["DataType"]).ToLower(),
                                IsEditable = Convert.ToBoolean(reader["IsEditable"]),
                                IsHideAllowed = Utility.GetBool(reader["IsHideAllowed"]),
                                StageDataType = Utility.GetString(reader["StageDataType"]).ToLower(),
                                StageMaxAllowedDigits = Utility.GetInt(reader["StageMaxAllowedDigits"]),
                                StageMaxprecision = Utility.GetInt(reader["StageMaxprecision"])
                            });
                        }
                        attributeList = attributeList.ToList().OrderBy(x => x.AttributeId).ToList();
                    } 
                } 
            }
            return attributeList;
        }

        private DataTable TransposeUploadedDatatable(DataTable tblUploaded, string KeyAttribute, List<DataCorrectionAttribute> LstOverrideDbFieldAttribute)
        { 
            DataTable dt = new DataTable("DataCorrectionKeyValue");
            dt.Columns.Add(new DataColumn("facilitySecurityId"));
            dt.Columns.Add(new DataColumn("connectionId"));
            dt.Columns.Add(new DataColumn("attributeId"));
            dt.Columns.Add(new DataColumn("value"));
			dt.Columns.Add(new DataColumn("facilityId"));

            string KeyValue = "", FacilityID = "";
            foreach(DataRow _row in tblUploaded.Rows)
            {
                KeyValue = _row[KeyAttribute].ToString();
				FacilityID = _row["FacilityId"].ToString();
                foreach (DataColumn _col in tblUploaded.Columns)
                {
                    if(_col.ColumnName.ToLower() == KeyAttribute.ToLower() || _col.ColumnName.ToLower() == "error")
                    {
                        continue;
                    } 

                    DataRow dr = dt.NewRow();
                    dr["facilitySecurityId"] = KeyValue;
                    dr["attributeId"] = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().AttributeId;
                    dr["value"] = _row[_col].ToString();
					dr["facilityId"] = FacilityID;
                    if (!string.IsNullOrEmpty(_row[_col].ToString()))
                    {
                        dt.Rows.Add(dr);
                    }
                }
            } 
            return dt;
        }

        private int checkUploadedFieldsDataTypes(DataTable UploadedExcelTable, 
            List<DataCorrectionAttribute> LstOverrideDbFieldAttribute)
        {
            int UploadedCellValue_Int;
            decimal UploadedCellValue_Decimal;
            DateTime UploadedCellValue_Date;
            bool isDataTypeErrorFound = false;

            foreach (DataColumn _col in UploadedExcelTable.Columns)
            { 
                if (_col.ColumnName.ToLower() == "error")
                {
                    continue;
                }

                //if (LstOverrideDbFieldAttribute.Where(ts => ts.AttributeId.ToString() == _col.ColumnName).Count() > 0)
                if (LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == _col.ColumnName.ToLower()).Count() > 0)
                {
                    //string CurrentColumnDataType = LstOverrideDbFieldAttribute.Where(ts => ts.AttributeId.ToString() == _col.ColumnName).FirstOrDefault().DataType.ToLower();
                    //string CurrentFieldDisplayName = LstOverrideDbFieldAttribute.Where(ts => ts.AttributeId.ToString() == _col.ColumnName).FirstOrDefault().DisplayName;
                    //bool CurrentFieldIsEditable = LstOverrideDbFieldAttribute.Where(ts => ts.AttributeId.ToString() == _col.ColumnName).FirstOrDefault().IsEditable;

                    string CurrentColumnDataType = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().DataType.ToLower();
                    string CurrentFieldDisplayName = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().DisplayName;
                    bool CurrentFieldIsEditable = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower().ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().IsEditable;

                    string StageDataType = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower().ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().StageDataType;
                    int StageMaxAllowedDigits = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower().ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().StageMaxAllowedDigits;
                    int StageMaxprecision = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower().ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().StageMaxprecision;

                    string ErrorInColumn = "";
                    foreach (DataRow _row in UploadedExcelTable.Rows)
                    {
                        if(!CurrentFieldIsEditable)
                        {
                            if (string.IsNullOrEmpty(_row[_col.ColumnName].ToString()))
                            {
                                ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                _row["Error"] = ErrorInColumn + CurrentFieldDisplayName + " Cannot be empty";
                                isDataTypeErrorFound = true;
                                //return -7;
                            }
                        }

                        if (CurrentColumnDataType == "decimal"
                            || CurrentColumnDataType == "int" || CurrentColumnDataType == "bigint" || CurrentColumnDataType == "integer")
                        {
                            if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                              && decimal.TryParse(_row[_col.ColumnName].ToString(), out UploadedCellValue_Decimal))
                            {
                                if (UploadedCellValue_Decimal < 0)
                                {
                                    ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                    _row["Error"] = ErrorInColumn + "-ve value in " + CurrentFieldDisplayName;
                                    isDataTypeErrorFound = true;
                                }
                            }

                            if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                               && !decimal.TryParse(_row[_col.ColumnName].ToString(), out UploadedCellValue_Decimal))
                            {
                                ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                _row["Error"] = ErrorInColumn + "Incorrect datatype in " + CurrentFieldDisplayName;
                                isDataTypeErrorFound = true;
                            }
                            else // IF DATATYPE MATCHING THEN CHECK THE MAX ALLOWED VALUE AGAINST THE STAGING TABLE COLUMN SCHEMA
                            {
                                if(StageDataType == "decimal" 
                                    && decimal.TryParse(_row[_col.ColumnName].ToString(), out UploadedCellValue_Decimal))
                                {
                                    string[] DecimalValAry = UploadedCellValue_Decimal.ToString().Split("."); 
                                    string MaxAllowedValue = "";
                                    string MaxAllowerWholeNumber = "";
                                    for (int index = 1; index <= StageMaxAllowedDigits; index++)
                                    {
                                        MaxAllowerWholeNumber = MaxAllowerWholeNumber + "9";
                                    }
                                    string MaxAllowedPrecision = ""; int MaxAllowedPrecisionCount = 0;
                                    for (int index = 1; index <= StageMaxprecision; index++)
                                    {
                                        MaxAllowedPrecision = MaxAllowedPrecision + "9";
                                        MaxAllowedPrecisionCount++;
                                    }
                                    MaxAllowedValue = MaxAllowerWholeNumber + "." + MaxAllowedPrecision;

                                    if ((DecimalValAry.Length > 0 && DecimalValAry[0].Replace("-", "").Count() > StageMaxAllowedDigits)
                                       || (DecimalValAry.Length > 1 && DecimalValAry[1].Replace("-", "").Count() > StageMaxprecision))
                                    {
                                        ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                        _row["Error"] = ErrorInColumn + " Data overflow in " + CurrentFieldDisplayName + " (Max allowed Value : " + MaxAllowerWholeNumber + ", Precision : " + MaxAllowedPrecisionCount + ")";
                                        isDataTypeErrorFound = true;
                                    }
                                }
                            }
                        }

                        //if(CurrentColumnDataType == "int" || CurrentColumnDataType == "bigint" || CurrentColumnDataType == "integer")
                        //{
                        //    if(!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                        //        && !int.TryParse(_row[_col.ColumnName].ToString(), out UploadedCellValue_Int))
                        //    {
                        //        ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                        //        _row["Error"] = ErrorInColumn + "Incorrect datatype in " + CurrentFieldDisplayName;
                        //        isDataTypeErrorFound = true;
                        //    }
                        //}
                        //else if (CurrentColumnDataType == "decimal")
                        //{
                        //    if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                        //       && !decimal.TryParse(_row[_col.ColumnName].ToString(), out UploadedCellValue_Decimal))
                        //    {
                        //        ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                        //        _row["Error"] = ErrorInColumn + "Incorrect datatype in " + CurrentFieldDisplayName;
                        //        isDataTypeErrorFound = true;
                        //    }
                        //}
                        else if (CurrentColumnDataType == "date")
                        { 
                            if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                              && !DateTime.TryParse(_row[_col.ColumnName].ToString(), out UploadedCellValue_Date))
                            { 
                                ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                _row["Error"] = ErrorInColumn + "Incorrect date in " + CurrentFieldDisplayName.Replace("(dd-mm-yyyy)","") + ". Date should be in dd-MM-yyyy format";
                                isDataTypeErrorFound = true;
                            }
                        }
                    }
                }
                else
                {
                    return -5; // DataType not available for uploaded column
                }
            }

            if (isDataTypeErrorFound)
                return -6;

            return 0;
        }

        private int checkUploadedFieldsOtherValidations(DataTable UploadedExcelTable, DataTable tblCommonSpData,
            List<DataCorrectionAttribute> LstOverrideDbFieldAttribute, string AsAtDate, int dealId, string EntityTypeName)
        {
            string ErrorInColumn;
            bool isDateErrorFound = false;
            string EntityKeyColumn = EntityTypeName.ToLower() == "facility" ? "facilityId" : "securityId";
            EntityKeyColumn =LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == EntityKeyColumn.ToLower()).FirstOrDefault().DisplayName;

            DateTime Uploadedexpirydate;
            Dictionary<string, DateTime> _LstDictMaturityDate = GetOverrideSecurityMaturityDates(tblCommonSpData, EntityTypeName, AsAtDate, dealId);

            // CHECK THE KEY COLUMN AVAILABILITY 
            bool KeyColFound = false;
            foreach (DataColumn dc in UploadedExcelTable.Columns)
            {
                if (dc.ColumnName.ToString().ToLower() == EntityKeyColumn.ToLower())
                {
                    KeyColFound = true;
                }
            }
            if(!KeyColFound)
            {
                return -10;
            }


            // VALIDATE EXPIRY DATE AGAINST UPSTREAM VALUE
            if (LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == "expirydate"
                || ts.AttributeName.ToLower() == "maturitydate"
                || ts.AttributeName.ToLower() == "maturitydate@sec").Count() > 0)
            {
                foreach (DataColumn _col in UploadedExcelTable.Columns)
                {
                    if (_col.ColumnName.ToLower() == "error")
                    {
                        continue;
                    }

                    string FieldName = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().AttributeName;
                    if (FieldName.ToLower() == "expirydate" || FieldName.ToLower() == "maturitydate" || FieldName.ToLower() == "maturitydate@sec")
                    {
                        foreach (DataRow _row in UploadedExcelTable.Rows)
                        { 
                            if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                                && DateTime.TryParse(_row[_col.ColumnName].ToString(), out Uploadedexpirydate))
                            { 
                                //Expiry date entered by the user should be the same as it is there in the upstream
                                DateTime upstreamDate;
                                if (_LstDictMaturityDate != null &&
                                    _LstDictMaturityDate.TryGetValue(_row[EntityKeyColumn].ToString(), out upstreamDate))
                                { 
                                    if(upstreamDate.Year != Uploadedexpirydate.Year ||
                                       upstreamDate.Month != Uploadedexpirydate.Month ||
                                       upstreamDate.Day != Uploadedexpirydate.Day)
                                    {
                                        ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                        _row["Error"] = ErrorInColumn + " "+ FieldName + " should be same as upstream value (" + upstreamDate.ToString("dd-MM-yyyy") + ")";
                                        isDateErrorFound = true;
                                    }
                                }
                                else
                                {
                                    ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                    _row["Error"] = ErrorInColumn + " "+ FieldName + " is not available in upstream";
                                    isDateErrorFound = true;
                                }
                            } 
                        }

                        if(isDateErrorFound)
                        {
                            foreach (DataRow _row in UploadedExcelTable.Rows)
                            {
                                if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                                && DateTime.TryParse(_row[_col.ColumnName].ToString(), out Uploadedexpirydate))
                                {
                                    _row[_col.ColumnName] = Uploadedexpirydate.ToString("dd-MM-yyyy");
                                }
                            }
                        }
                    }
                } 
            }

            if (isDateErrorFound)
                return -11;

            return 0;
        }

        private int ValidateRona(string RonaColName, DataTable UploadedExcelTable, DataTable tblCommonSpData, List<DataCorrectionAttribute> LstOverrideDbFieldAttribute)
        {
            string ErrorInColumn;
            bool isRonaErrorFound = false;
            decimal UploadedRona;
            bool isFacilityIdFoundInUpload = false;
            bool isFacilityIdFoundCmnSp = false;
            string KeyColName_Upload = "FacilityId";
            string KeyColName_CmnSp = "FacilityId";

            foreach (DataColumn _col in UploadedExcelTable.Columns)
            {
                if (_col.ColumnName.ToLower() == "facilityid")
                {
                    isFacilityIdFoundInUpload = true;
                    KeyColName_Upload = _col.ColumnName;
                    break;
                }
            }

            foreach (DataColumn _col in tblCommonSpData.Columns)
            {
                if (_col.ColumnName.ToLower() == "facilityid")
                {
                    isFacilityIdFoundCmnSp = true;
                    KeyColName_CmnSp = _col.ColumnName;
                    break;
                }
            }

            // VALIDATE UPLOADED RONA AGAINST MAX ALLOWED RONA VALUE
            if (LstOverrideDbFieldAttribute.Where(ts => ts.AttributeName.ToLower() == RonaColName.ToLower()).Count() > 0
                && isFacilityIdFoundInUpload && isFacilityIdFoundCmnSp)
            {
                foreach (DataColumn _col in UploadedExcelTable.Columns)
                {
                    if (_col.ColumnName.ToLower() == "error")
                    {
                        continue;
                    }

                    string FieldName = LstOverrideDbFieldAttribute.Where(ts => ts.DisplayName.ToLower() == _col.ColumnName.ToLower()).FirstOrDefault().AttributeName;
                    if (FieldName.ToLower() == RonaColName.ToLower())
                    {
                        foreach (DataRow _row in UploadedExcelTable.Rows)
                        {
                            if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                                && decimal.TryParse(_row[_col.ColumnName].ToString(), out UploadedRona))
                            {
                                string KeyValue = _row[KeyColName_Upload].ToString();

                                // GET MAX ALLOWED RONA 
                                string keyFilterCondtn = KeyColName_CmnSp + "='" + KeyValue + "'";
                                DataRow[] RonaRowsFromCommonSp = tblCommonSpData.Select(keyFilterCondtn);

                                if (RonaRowsFromCommonSp != null && RonaRowsFromCommonSp.Count() > 0)
                                {
                                    decimal MaxAllowedRonaValue = 0;
                                    string strMaxRona = RonaRowsFromCommonSp[0]["RONA"].ToString();
                                    if (decimal.TryParse(strMaxRona, out MaxAllowedRonaValue))
                                    {
                                        if (UploadedRona > MaxAllowedRonaValue || UploadedRona < 0)
                                        {
                                            ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                            if (UploadedRona < 0)
                                                _row["Error"] = ErrorInColumn + " RONA value cannot be negative ";
                                            else
                                                _row["Error"] = ErrorInColumn + " Invalid RONA, Maximum allowed RONA :  " + MaxAllowedRonaValue.ToString() + "";
                                            isRonaErrorFound = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            if (isRonaErrorFound)
                return -15;

            return 0;
        }

        private DataTable GetFacilitySecurityIDsFromCommonSP(string AsAtDate, int dealId, string userName, int isRonaRequired)
        {
            DataTable dtCommonSPIds = new DataTable();
            dtCommonSPIds.Columns.Add("FacilityId");
            dtCommonSPIds.Columns.Add("SecurityKey");
            dtCommonSPIds.Columns.Add("CradleSecurityId");
            dtCommonSPIds.Columns.Add("ExpiryDate", typeof(DateTime)); // System.Type.GetType("System.DateTime"));
            dtCommonSPIds.Columns.Add("SecurityID");
            dtCommonSPIds.Columns.Add("ConnectionName");
            dtCommonSPIds.Columns.Add("FacilitySourceId");
            dtCommonSPIds.Columns.Add("RONA");

            try
            {
                using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetFacilitySecurityMaturityDates, conn))
                    {
                        if (conn.State == ConnectionState.Closed)
                            conn.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(AsAtDate).ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                        cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                        cmd.Parameters.AddWithValue(DbConstants.DbProcParamIsRonaRequired, isRonaRequired);
                        cmd.CommandTimeout = 0;

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {

                                DataRow drow = dtCommonSPIds.NewRow();
                                drow["FacilityId"] = Utility.GetString(reader["FacilityId"]);
                                drow["SecurityKey"] = Utility.GetString(reader["SecurityKey"]);
                                drow["CradleSecurityId"] = Utility.GetString(reader["CradleSecurityId"]);
                                drow["ExpiryDate"] = Utility.GetDate(reader["ExpiryDate"]);
                                drow["SecurityID"] = Utility.GetString(reader["SecurityID"]);
                                drow["ConnectionName"] = Utility.GetString(reader["ConnectionName"]);

                                drow["FacilitySourceId"] = Utility.GetInt(reader["FacilitySourceId"]);
                                drow["RONA"] = Utility.GetDecimal(reader["RONA"]);
                                dtCommonSPIds.Rows.Add(drow);
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return dtCommonSPIds;
        }

        private Dictionary<string, DateTime> GetOverrideSecurityMaturityDates(DataTable tblCommonSpData,string EntityTypeName, string AsAtDate, int dealId)
        {
            Dictionary<string, DateTime> _LstDictMaturityDate = new Dictionary<string, DateTime>();
            try
            {
                DateTime dtMaturityDate;
                string KeyValue;
                if(tblCommonSpData != null && tblCommonSpData.Rows.Count >0)
                {
                    foreach(DataRow row in tblCommonSpData.Rows)
                    {
                        if (DateTime.TryParse(Utility.GetDateTime(row["ExpiryDate"]), out dtMaturityDate)
                            && dtMaturityDate != DateTime.MinValue && dtMaturityDate != DateTime.MaxValue)
                        {
                            if (EntityTypeName.ToLower() == "facility")
                                KeyValue = Utility.GetString(row["FacilityId"]);
                            else
                                KeyValue = Utility.GetString(row["CradleSecurityId"]);

                            if (!_LstDictMaturityDate.ContainsKey(KeyValue))
                                _LstDictMaturityDate.Add(KeyValue, dtMaturityDate);
                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
            return _LstDictMaturityDate; //= _LstDictMaturityDate.Distinct();
        }

        private Dictionary<string, DateTime> GetOverrideSecurityMaturityDates(string EntityTypeName, string AsAtDate, int dealId)
        {
            Dictionary<string, DateTime> _LstDictMaturityDate = new Dictionary<string, DateTime>();

            try
            {
                using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetFacilitySecurityMaturityDates, conn))
                    {
                        if (conn.State == ConnectionState.Closed)
                            conn.Open();

                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcAsAtDate, Convert.ToDateTime(AsAtDate).ToString("yyyy-MM-dd"));
                        cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                        cmd.CommandTimeout = 0;

                        DateTime dtMaturityDate;

                        SqlDataReader reader = cmd.ExecuteReader();
                        string KeyValue;
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                if (DateTime.TryParse(Utility.GetDateTime(reader["ExpiryDate"]), out dtMaturityDate)
                                    && dtMaturityDate != DateTime.MinValue && dtMaturityDate != DateTime.MaxValue)
                                {
                                    if (EntityTypeName.ToLower() == "facility")
                                        KeyValue = Utility.GetString(reader["FacilityId"]);
                                    else
                                        KeyValue = Utility.GetString(reader["CradleSecurityId"]);

                                    if (!_LstDictMaturityDate.ContainsKey(KeyValue))
                                        _LstDictMaturityDate.Add(KeyValue, dtMaturityDate);
                                }
                            }

                        }
                    }
                }
            }
            catch (Exception ex)
            {

            }
            return _LstDictMaturityDate; //= _LstDictMaturityDate.Distinct();
        }

        private int checkDuplicateValueInKeyColumn(DataTable UploadedExcelTable, string EntityTypeName)
        {
            string ErrorInColumn;
            bool isDateErrorFound = false;
            string EntityKeyColumn = EntityTypeName.ToLower() == "facility" ? "facilityId" : "securityId";
			string DisplayColName = "FacilityId";
			
			if (EntityKeyColumn == "securityId") DisplayColName = "FacilityId + SecurityId";
 
            foreach (DataColumn _col in UploadedExcelTable.Columns)
            { 
                if (_col.ColumnName.ToLower() == EntityKeyColumn.ToLower())
                {
                    foreach (DataRow _row in UploadedExcelTable.Rows)
                    {
                        if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString()))
                        {
                            string keyFilterCondtn = _col.ColumnName + "='" + _row[_col.ColumnName].ToString() + "' AND FacilityId = '" + _row["FacilityId"].ToString() + "'";
                            DataRow[] rowsFilteredWithKey = UploadedExcelTable.Select(keyFilterCondtn);

                            if(rowsFilteredWithKey != null && rowsFilteredWithKey.Count() > 1 )
                            {
                                ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                _row["Error"] = ErrorInColumn + " Duplicate "+ DisplayColName + " found";
                                isDateErrorFound = true;
                            }
                        }
                    }
                }
            } 

            if (isDateErrorFound)
                return -12;

            return 0;
        }

        private int GetIsDataAvailableInUploadedFile(string chkColumnName, DataTable UploadedExcelTable)
        {
            bool isRonaFound = false;
            decimal uploadedRona = 0;

            foreach (DataColumn _col in UploadedExcelTable.Columns)
            {
                if (_col.ColumnName.ToLower() == chkColumnName.ToLower())
                {
                    foreach (DataRow _row in UploadedExcelTable.Rows)
                    {
                        if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString())
                            && decimal.TryParse(_row[_col.ColumnName].ToString(), out uploadedRona))
                        {
                            if (uploadedRona > 0)
                            {
                                isRonaFound = true;
                            }
                        }
                    }
                    break;
                }
            }
            if (isRonaFound)
                return 1;

            return 0;
        }

        private int checkKeyColumnInCommonSP(DataTable UploadedExcelTable, DataTable tblCommonSpData, string EntityTypeName)
        {
            string ErrorInColumn;
            bool isInvalidKeyFound = false;
            string EntityKeyColumn = EntityTypeName.ToLower() == "facility" ? "facilityId" : "securityId";
			string DisplayColName = "FacilityId";

            if (EntityKeyColumn == "securityId") DisplayColName = "FacilityId + SecurityId";


            foreach (DataColumn _col in UploadedExcelTable.Columns)
            {
                if (_col.ColumnName.ToLower() == EntityKeyColumn.ToLower())
                {
                    foreach (DataRow _row in UploadedExcelTable.Rows)
                    {
                        if (!string.IsNullOrEmpty(_row[_col.ColumnName].ToString()))
                        {
                            string keyFilterCondtn = _col.ColumnName + "='" + _row[_col.ColumnName].ToString() + "' AND FacilityId = '" + _row["FacilityId"].ToString() + "'";
                            DataRow[] rowsFilteredWithKey = tblCommonSpData.Select(keyFilterCondtn);

                            if (rowsFilteredWithKey == null || rowsFilteredWithKey.Count() == 0)
                            {
                                ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                                _row["Error"] = ErrorInColumn + " Invalid " + DisplayColName;
                                isInvalidKeyFound = true;
                            }
                        }
                    }
                }
            }

            if (isInvalidKeyFound)
                return -14;

            return 0;
        }

        private int checkEmptyRowInUploadFile(DataTable UploadedExcelTable, string EntityTypeName)
        {
            string ErrorInColumn;
            bool isDateErrorFound = false;
            string EntityKeyColumn = EntityTypeName.ToLower() == "facility" ? "facilityId" : "securityId";

            foreach (DataRow _row in UploadedExcelTable.Rows)
            {
                bool isDataAvailable = false;
                foreach (DataColumn _col in UploadedExcelTable.Columns)
                {
                    if (_col.ColumnName.ToLower() != EntityKeyColumn.ToLower() && _col.ColumnName.ToLower() != "facilityid"
                        && !string.IsNullOrEmpty(_row[_col.ColumnName].ToString()))
                    {
                        isDataAvailable = true;
                    }
                }

                if (!isDataAvailable)
                {
                    ErrorInColumn = (string.IsNullOrEmpty(_row["Error"].ToString())) ? "" : _row["Error"] + "; ";
                    _row["Error"] = ErrorInColumn + " No update/override data found for " + EntityKeyColumn;
                    isDateErrorFound = true;
                }
            }

            if (isDateErrorFound)
                return -13;

            return 0;
        }

        private string[] GetAccountingFormatFields(string pUserName)
        {

            List<ECFieldAttribute> ecFieldAttribute = GetECFieldAttributeList(pUserName);
            string[] strAttributeFields = new string[ecFieldAttribute.Count];

            for (int i = 0; i < ecFieldAttribute.Count; i++)
            {
                strAttributeFields[i] = ecFieldAttribute[i].FieldName;
            }

            return strAttributeFields;
        }

        private List<ECFieldAttribute> GetECFieldAttributeList(string loggedInUserName)
        {
            List<ECFieldAttribute> ecFieldsAttributes = new List<ECFieldAttribute>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetEC_FieldAttributes, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            ecFieldsAttributes.Add(new ECFieldAttribute()
                            {
                                EligibilityCriteriaFieldId = Utility.GetInt(resultReader[DbConstants.DbFieldEligibilityCriteriaFieldId]),
                                FieldName = Utility.GetString(resultReader[DbConstants.DbFieldCriteriaFieldName]),
                                RequiresAccountingFormat = Utility.GetBool(resultReader[DbConstants.DbFieldRequireAccountingFormat]),
                                DisplayFormat = Utility.GetString(resultReader[DbConstants.DbFieldDisplayFormat])
                            });
                        }
                    }
                    else
                    {
                        return ecFieldsAttributes;
                    }
                }
            }
            return ecFieldsAttributes;
        }

        public string validatePoolAndOverrideAuthorize(int callFromOverrideAuth, int id)
        {
            try
            {
                int rowsInserted = 0;
                dynamic result = null;
                 
                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand("corp.spGetPendingOverrideItems", conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue("@pCallFromOverrideAuth", callFromOverrideAuth);
                    cmd.Parameters.AddWithValue("@pId", id);

                    SqlParameter cmdOutReturnIds = cmd.Parameters.Add("@pReturnIds", SqlDbType.VarChar, 500);
                    cmdOutReturnIds.Direction = ParameterDirection.Output; 
					cmd.CommandTimeout = 0;

                    //resultObj = new
                    //{
                    //    canAllowAuthorize = string.IsNullOrEmpty(cmdOutReturnIds) ? 1 : 0 ,
                    //    errorExcelHeaderList = LstcolumnNames
                    //};
                    //return JsonConvert.SerializeObject(resultObj);

                    rowsInserted = cmd.ExecuteNonQuery();
                    result = new
                    {
                        canAllowAuthorize = string.IsNullOrEmpty(cmdOutReturnIds.Value.ToString()) ? 1 : 0,
                        ReturnIds = cmdOutReturnIds.Value.ToString()
                    };
                }
                return JsonConvert.SerializeObject(result);
            }
            catch(Exception ex)
            {
                throw;
            }
        }

        #endregion

        #region FACILITY-SECURITY-LINKAGES
        public IList<FacilitySecurityLinkEntity> getFacilitySecurityLinkStatus(string userName, string AsAtDate, string ComparisonDate, int dealId)
        {
            IList<FacilitySecurityLinkEntity> objFacilitySecurityLinkEntity = new List<FacilitySecurityLinkEntity>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            {
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetFacilitySecurityLinkStatus, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamAsAtDate, AsAtDate);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamPreviousAsAtDate, ComparisonDate);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamDcDealId, dealId);
                    cmd.CommandTimeout = 60;

                    SqlDataReader reader = cmd.ExecuteReader();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            objFacilitySecurityLinkEntity.Add(new FacilitySecurityLinkEntity()
                            {
                                DealId = dealId,
                                FacilityId = Utility.GetString(reader["FacilityId"]),
                                SecurityId = Utility.GetString(reader["SecurityId"]),
                                CradleSecurityId = Utility.GetString(reader["CradleSecurityId"]),
                                ConnectionId = Utility.GetString(reader["ConnectionId"]),
                                SecurityKey = Utility.GetString(reader["SecurityKey"]),
                                IsLinked = Utility.GetInt(reader["IsLinked"]),
                                isListEdited = 0
                            });
                        }
                    }
                }
            }
            return objFacilitySecurityLinkEntity;
        }

        #endregion


        public string resetOverrideData(int DealOverrideParentId, string Entity)
        {
            try
            {
                int rowsInserted = 0;
                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(DbConstants.SP_ResetOverrideData, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    cmd.Parameters.AddWithValue("@pDealOverrideParentId", DealOverrideParentId);
                    cmd.Parameters.AddWithValue("@pEntityName", Entity);

                    SqlParameter cmdOutBasicRetVal = new SqlParameter();
                    cmdOutBasicRetVal.ParameterName = "@pDataOverrideResult";
                    cmdOutBasicRetVal.Direction = ParameterDirection.Output;
                    cmdOutBasicRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutBasicRetVal);

                    rowsInserted = cmd.ExecuteNonQuery();
                    return JsonConvert.SerializeObject(cmdOutBasicRetVal.Value);
                }
            }
            catch(Exception ex)
            {
                throw;
            }
        }

    }
}

