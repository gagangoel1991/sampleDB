﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.CB;
using NW.SFP.Message.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace NW.SFP.DataService.CB
{
    public class DataCorrectionRefDataService: IDataCorrectionRefDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;
        public DataCorrectionRefDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        public DataCorrectionReference GetDataCorrectionReferenceData(string userName)
        {
            DataCorrectionReference dataCorrectionReference = new DataCorrectionReference();
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetDataCorrectionReferenceData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Get Deal Data
                        dataCorrectionReference.Deal.AddRange(GetFieldLookUpData(resultReader, "Deal"));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Get Entity Type
                        dataCorrectionReference.Entity.AddRange(GetFieldLookUpData(resultReader, "Entity"));
                    }
                }
            }
            return dataCorrectionReference;
        }

        private IList<BasicLookUpData> GetFieldLookUpData(SqlDataReader resultReader, string type)
        {
            var lookUpDataList = new List<BasicLookUpData>();
            BasicLookUpData basicLookUpData = null;

            while (resultReader.Read())
            {
                if (type == "Deal")
                {
                    basicLookUpData = new BasicLookUpData
                    {
                        Value = Convert.ToInt32(resultReader[DbConstants.DbRefLookupDealId]),
                        Title = Utility.GetString(resultReader[DbConstants.DbRefLookupDealName])
                    };
                }
                if (type == "Entity")
                {
                    basicLookUpData = new BasicLookUpData
                    {
                        Value = Convert.ToInt32(resultReader[DbConstants.DbRefLookupEntityId]),
                        Title = Utility.GetString(resultReader[DbConstants.DbRefLookupEntityName])
                    };
                }

                lookUpDataList.Add(basicLookUpData);
            }
            return lookUpDataList;
        }
    }
}
