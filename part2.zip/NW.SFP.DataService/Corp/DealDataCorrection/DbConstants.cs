﻿using System;

namespace NW.SFP.DataService.CB
{
    static partial class DbConstants
    {
        #region Deal Data Correction Procedures & Parameters
        public const string SP_GetDataCorrectionAttribute = "[corp].[GetDataCorrectionAttribute]";
        public const string SP_GetDataCorrectionReferenceData = "[corp].[GetDataCorrectionReferenceData]";
        public const string SP_GetFacilityDataCorrectionList = "[corp].[GetFacilityDataCorrectionList]";
        public const string SP_GetSecurityDataCorrectionList = "[corp].[GetSecurityDataCorrectionList]";
        public const string SP_SaveDataCorrection = "[corp].[SaveDataCorrection]";
        public const string SP_GetDealDataCorrectionDetail = "[ps].[spGetDealDataCorrectionDetail]";
        public const string SP_GetUpdateOverrideList = "[corp].[spGetUpdateOverrideList]";
		public const string SP_GetFacilityDataForOverride = "[corp].[spGetFacilityDataForOverride]";
        public const string SP_GetSecurityDataForOverride = "[corp].[spGetSecurityDataForOverride]";
        public const string SP_GetOverrideFieldAttributes = "[corp].[GetOverrideFieldAttributes]";
        public const string SP_GetFacilitySecurityMaturityDates = "[corp].[uspGetFacilitySecurityMaturityDates]";
		public const string SP_GetRefRegComparisionReport_Facility = "[ps].[spGetRefRegComparisionReport_Facility]";
        public const string SP_GetRefRegComparisionReport_Security = "[ps].[spGetRefRegComparisionReport_Security]";
        public const string SP_GetOverrideAuditTrail = "[corp].[spGetOverrideAuditTrail]";
        public const string SP_GetOverrideVintageDateList = "[corp].[spGetOverrideVintageDateList]";
        public const string SP_GetFacilitySecurityLinkStatus = "[corp].[spGetFacilitySecurityLinkStatus]";
        public const string SP_GetFacilitySecurityLinkAudit = "corp.spGetFacilitySecurityLinkAudit";
        public const string SP_ResetOverrideData = "corp.spResetOverrideData";

        #region Deal Data Correction Procedures & Parameters
        public const string DbProcParamUserName = "@pUserName";
        public const string DbProcParamDcAsAtDate = "@pDate";
        public const string DbProcParamDcDealId = "@pDealId";
        public const string DbProcParamDcEntityId = "@pEntityId";
        public const string DbProcParamDcEntityName = "@pEntityName";
        public const string DbProcParamDcFsId = "@pFsId";
        public const string DbProcParamDcStatusId = "@pStatusId";
        public const string DbProcParamBasicInfoResult = "@pBasicInfoResult";
        public const string DbProcParamDataCorrectionResult = "@pDataCorrectionResult";
        public const string DbProcParamDataCorrectionId = "@pDataCorrectionId";
        public const string DbProcParamDealDataCorrectionId = "@pDealDataCorrectionId";        
        public const string DbProcParampDataCorrectionList = "@pDataCorrectionList";
        public const string DbProcParamDMLType = "@pDMLType";
        public const string DbProcParamEntityTypeName = "@pEntityTypeName";
        public const string DbProcParamIsTemplate = "@pIsTemplate";
        public const string DbProcParamAsAtDate = "@pAsAtDate";
        public const string DbProcParamPreviousAsAtDate = "@pPreviousReportingDate";
        public const string DbProcParamIsRonaRequired = "@pIsRonaRequired";

        public const string SP_GetEC_FieldAttributes = "[ps].[spGetECFieldAttributes]"; 
        public const string DbFieldEligibilityCriteriaFieldId = "EligibilityCriteriaFieldId";
        public const string DbFieldCriteriaFieldName = "CriteriaFieldName";
        public const string DbFieldRequireAccountingFormat = "RequireAccountingFormat";
        public const string DbFieldDisplayFormat = "DisplayFormat";

        #endregion Deal Data Correction Procedures & Parameters
        #endregion

        #region Lookup value
        public const string DbRefLookupDataValue = "Value";
        public const string DbRefLookupDataTitle = "Title";

        public const string DbRefLookupDealId = "DealId";
        public const string DbRefLookupDealName = "DealName";

        public const string DbRefLookupEntityId = "EntityId";
        public const string DbRefLookupEntityName = "EntityName";
        #endregion
    }
    public enum DMLType
    {
        Insert = 1,
        Update = 2,
        Delete = 3
    }
}
