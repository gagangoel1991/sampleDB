﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using Microsoft.Extensions.Options;
using NW.SFP.Message.Core;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class DealDateDataService : IDealDateDataService
    {
        #region Object Declarations and Constructor
        private readonly IOptions<DataServiceSettings> _settings;
        public DealDateDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        #endregion

        /// <summary>
        /// This will return the next IPDs of a deal
        /// </summary>
        /// <param name="dealId"></param>
        /// <param name="loggedInUserName"></param>
        /// <returns></returns>
        public IList<DealIpdEntity> GetDealNextIpd(int dealId, string loggedInUserName)
        {
            IList<DealIpdEntity> ipdList = new List<DealIpdEntity>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetDealNextIpd, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pDealId", dealId);
                cmd.Parameters.AddWithValue("@pUserName", loggedInUserName);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ipdList.Add(new DealIpdEntity()
                    {
                        IpdDate = Utility.GetShortDateTime(reader["IpdDate"]),
                        DealId = Utility.GetInt(reader["DealId"])
                    });
                }
            }
            return ipdList;
        }
    }
}
