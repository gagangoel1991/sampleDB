﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Common;
using NW.SFP.Message.Common;

namespace NW.SFP.DataService.CW
{
    public class DealDataService : Repository<DealEntity>, IDealDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealDataService()
        {

        }

        public DealDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        /// <summary>
        /// This will return the active deals details
        /// </summary
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealEntity> GetDealList(string loggedInUser, int assetClassId)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealList;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
				command.Parameters.Add(command.CreateParameter("@pAssetClassId", assetClassId));
                return this.Execute(command).ToList();
            }
        }

        public int SaveDeal(DealEntity dealEntity, int assetClassId )
        {
            if (dealEntity.IsMinorAmendment)
            {
                return SaveMinorAmendment(dealEntity);
            }
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDeal;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealEntity.DealId));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealEntity.DealName));
                command.Parameters.Add(command.CreateParameter("@pDealPublicName", dealEntity.DealPublicName));
                command.Parameters.Add(command.CreateParameter("@pInternalDealName", dealEntity.InternalDealName));
                command.Parameters.Add(command.CreateParameter("@pDescription", dealEntity.Description));
                command.Parameters.Add(command.CreateParameter("@pOwnerName", dealEntity.OwnerName));
                command.Parameters.Add(command.CreateParameter("@pBusinessAreaId", dealEntity.BusinessAreaId));
                command.Parameters.Add(command.CreateParameter("@pDealTypeId", dealEntity.DealTypeId));
                command.Parameters.Add(command.CreateParameter("@pDealStatusID", dealEntity.DealStatusId));
                command.Parameters.Add(command.CreateParameter("@pClosingDate", dealEntity.ClosingDate));
                command.Parameters.Add(command.CreateParameter("@pDealMaturityDate", dealEntity.DealMaturityDate.HasValue ? dealEntity.DealMaturityDate : new DateTime(9999, 12, 31)));
                command.Parameters.Add(command.CreateParameter("@pFirstIpdDate", dealEntity.FirstIpdDate));
                command.Parameters.Add(command.CreateParameter("@pCashCollectionStartDate", dealEntity.CashCollectionStartDate));
                command.Parameters.Add(command.CreateParameter("@pIpdFrequencyId", dealEntity.IpdFrequencyId));
                command.Parameters.Add(command.CreateParameter("@pDealCurrencyId", dealEntity.DealCurrencyId));
                command.Parameters.Add(command.CreateParameter("@pJurisdictionMarkerId", dealEntity.JurisdictionMarkerId));
                command.Parameters.Add(command.CreateParameter("@pFurtherAdvancesAutoTopUpFlagId", dealEntity.FurtherAdvancesAutoTopUpFlagId));
                command.Parameters.Add(command.CreateParameter("@pBalanceTransferAutoTopUpFlagId", dealEntity.BalanceTransferAutoTopUpFlagId));
                command.Parameters.Add(command.CreateParameter("@pMortgageAutoTopUpFlagId", dealEntity.MortgageAutoTopUpFlagId));
                command.Parameters.Add(command.CreateParameter("@pDealAccountingTypeId", dealEntity.DealAccountingTypeId));
                command.Parameters.Add(command.CreateParameter("@pUserName", dealEntity.UserName));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", dealEntity.AuthorizerComment));
                command.Parameters.Add(command.CreateParameter("@pRedactedFacilityIds", dealEntity.RedactedFacilityIds));
				
				command.Parameters.Add(command.CreateParameter("@pCashReportingFlagId", dealEntity.CashReportingFlagId)); 
                command.Parameters.Add(command.CreateParameter("@pDealInitialSize", dealEntity.DealInitialSize));
                command.Parameters.Add(command.CreateParameter("@pTopupEndDate", dealEntity.TopupEndDate));
                command.Parameters.Add(command.CreateParameter("@pTopupFlagId", dealEntity.TopupFlagId));
                command.Parameters.Add(command.CreateParameter("@pRiskRetentionPercent", dealEntity.RiskRetentionPercent));
                command.Parameters.Add(command.CreateParameter("@pRiskRetentionMethodId", dealEntity.RiskRetentionMethodId));
                command.Parameters.Add(command.CreateParameter("@pRiskRetentionHolderId", dealEntity.RiskRetentionHolderId));
                command.Parameters.Add(command.CreateParameter("@pRonaCalculatedBasedOnId", dealEntity.RonaCalculatedBasedOnId));
                command.Parameters.Add(command.CreateParameter("@pFxRateDate", dealEntity.FxRateDate));
                command.Parameters.Add(command.CreateParameter("@pFacilitySharingAllowedId", dealEntity.FacilitySharingAllowedId));
                command.Parameters.Add(command.CreateParameter("@pEnableHistoricFlaggingId", dealEntity.EnableHistoricFlaggingId));
                command.Parameters.Add(command.CreateParameter("@pFacilityPercentChangeAllowedId", dealEntity.FacilityPercentChangeAllowedId));
                command.Parameters.Add(command.CreateParameter("@pLegalRetentionPercent", dealEntity.LegalRetentionPercent));

                command.Parameters.Add(command.CreateParameter("@pAssetClassId", assetClassId));

                command.Parameters.Add(command.CreateParameter("@pDealSecurityConfigItems", GetDealSecurityConfigTable(dealEntity)));

                command.Parameters.Add(command.CreateParameter("@pReportingContactTelephone", dealEntity.ReportingEntityContactTelephone));
                command.Parameters.Add(command.CreateParameter("@pReportingContactPerson", dealEntity.ReportingEntityContactPerson));
                command.Parameters.Add(command.CreateParameter("@pReportingContactEmail", dealEntity.ReportingEntityContactEmail));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }

        private DataTable GetDealSecurityConfigTable(DealEntity dealEntity)
        {
            DataTable dt = new DataTable("DealSecurityConfigItems");
            dt.Columns.Add(new DataColumn("PageLookUpValueMapId"));
            dt.Columns.Add(new DataColumn("DealId"));
            dt.Columns.Add(new DataColumn("Val"));
            dt.Columns.Add(new DataColumn("Name"));
            dt.Columns.Add(new DataColumn("IsSelected"));
            dt.Columns.Add(new DataColumn("TypeId"));

            if (dealEntity.DealSecurityItemsList != null && dealEntity.DealSecurityItemsList.Count() > 0) 
            {
                foreach (DealSecurityItemsList item in dealEntity.DealSecurityItemsList.Where(ts=> ts.IsSelected ))
                {
                    DataRow dr = dt.NewRow();
                    dr["PageLookUpValueMapId"] = item.PageLookUpValueMapId;
                    dr["DealId"] = item.DealId;
                    dr["Val"] = item.Val;
                    dr["Name"] = item.Name;
                    dr["IsSelected"] = item.IsSelected ? 1 : 0;
                    dr["TypeId"] = item.TypeId;
                    dt.Rows.Add(dr); 
                }
            }
            return dt;
        }

        public int DeleteDeal(int dealId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_spDeleteDeal;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                return this.ExecuteNonQuery(command);
            }
        }

        public DealEntity GetDeal(int dealId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_spGetDealForEdit;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                return this.ExecuteToEntity(command);
            }
        }

        public int ManageDealAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Authorise)
            {
                authWorkflowEntity.WorkflowStep = (int)DealAuthorisation.Authorise;
            }
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Reject)
            {
                authWorkflowEntity.WorkflowStep = (int)DealAuthorisation.Reject;
            }
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_ManageDealWorkflowProcess;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", authWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", authWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, authWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, authWorkflowEntity.UserName));
                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }


        public int DealCollapseSentforAuthorization(DealEntity dealEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_DealCollapseSentforAuthorization;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, dealEntity.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealName, dealEntity.DealName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealPublicName, dealEntity.DealPublicName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamInternalDealName, dealEntity.InternalDealName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDescription, dealEntity.Description));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamOwnerName, dealEntity.OwnerName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamBusinessAreaId, dealEntity.BusinessAreaId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealTypeId, dealEntity.DealTypeId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealStatusID, dealEntity.DealStatusId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamClosingDate, dealEntity.ClosingDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealMaturityDate, dealEntity.DealMaturityDate.HasValue ? dealEntity.DealMaturityDate : new DateTime(9999, 12, 31)));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamFirstIpdDate, dealEntity.FirstIpdDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamCashCollectionStartDate, dealEntity.CashCollectionStartDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIpdFrequencyId, dealEntity.IpdFrequencyId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealCurrencyId, dealEntity.DealCurrencyId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamJurisdictionMarkerId, dealEntity.JurisdictionMarkerId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamFurtherAdvancesAutoTopUpFlagId, dealEntity.FurtherAdvancesAutoTopUpFlagId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamBalanceTransferAutoTopUpFlagId, dealEntity.BalanceTransferAutoTopUpFlagId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamMortgageAutoTopUpFlagId, dealEntity.MortgageAutoTopUpFlagId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealAccountingTypeId, dealEntity.DealAccountingTypeId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, dealEntity.UserName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamAuthorizerComment, dealEntity.AuthorizerComment));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamEarlyRedemptionDate, dealEntity.EarlyRedemptionDate));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }


        public int GetValidateCollapseDeal(int dealId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetValidCollapseDeal;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, dealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, userName));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);

            }
        }

        public string GetDealLatestAuthorisedIpdDate(int dealId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealLatestAuthorisedIpdDate;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, dealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, userName));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnIPDDate", 0, DbType.String, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return returnCode.Value.ToString();

            }
        }


        public List<DealSecurityItemsList> getDealSecurityListItems(int dealId, string loggedInUser)
        {
            List<DealSecurityItemsList> ItemsList = new List<DealSecurityItemsList>(); 

            using (var command = this._unitOfWork.CreateCommand()) 
            {
                using (SqlConnection conn = new SqlConnection(command.Connection.ConnectionString))
                {
                    using (SqlCommand cmd = new SqlCommand(CWDBConstants.SP_GetDealSecurityListItems, conn))
                    {
                        if (conn.State == ConnectionState.Closed)
                            conn.Open();
                        cmd.CommandType = CommandType.StoredProcedure;
                        cmd.Parameters.AddWithValue("@pDealId", dealId);
                        cmd.Parameters.AddWithValue("@pUserName", loggedInUser);

                        SqlDataReader reader = cmd.ExecuteReader();
                        if (reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                ItemsList.Add(new DealSecurityItemsList()
                                {
                                    PageLookUpValueMapId = Utility.GetInt(reader["PageLookUpValueMapId"]),
                                    DealId = Utility.GetInt(reader["DealId"]),
                                    Val = Utility.GetString(reader["Val"]),
                                    Name = Utility.GetString(reader["Name"]),
                                    IsSelected = Convert.ToBoolean(reader["IsSelected"]),
                                    IsExcluded = Convert.ToBoolean(reader["IsExcluded"]),
                                    TypeId = Utility.GetInt(reader["TypeId"]),
                                    IsSaved = Utility.GetInt(reader["IsSaved"])
                                });
                            }
                        }
                    }
                }
            }

            return ItemsList;

        }


        #region private methods
        private int SaveMinorAmendment(DealEntity dealEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveMinorAmendment;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, dealEntity.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, dealEntity.UserName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDescription, dealEntity.Description));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamOwnerName, dealEntity.OwnerName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealPublicName, dealEntity.DealPublicName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamRedactedFacilityIds, dealEntity.RedactedFacilityIds));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamFxRateDate, dealEntity.FxRateDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParampEnableHistoricFlaggingId, dealEntity.EnableHistoricFlaggingId));

                command.Parameters.Add(command.CreateParameter("@pDealSecurityConfigItems", GetDealSecurityConfigTable(dealEntity)));

                command.Parameters.Add(command.CreateParameter("@pReportingContactTelephone", dealEntity.ReportingEntityContactTelephone));
                command.Parameters.Add(command.CreateParameter("@pReportingContactPerson", dealEntity.ReportingEntityContactPerson));
                command.Parameters.Add(command.CreateParameter("@pReportingContactEmail", dealEntity.ReportingEntityContactEmail));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);

            }
        }
        #endregion
    }
}
