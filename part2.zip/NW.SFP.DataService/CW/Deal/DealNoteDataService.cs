﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.CW
{
   public class DealNoteDataService : Repository<DealNoteInfoEntity>, IDealNoteDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealNoteDataService()
        {

        }

        public DealNoteDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the active deals details
        /// </summary
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealNoteInfoEntity> GetDealNoteList(IPDFeedParam ipdFeedParam, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealNoteList;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).ToList();
            }
        }

        public int SaveDealNoteData(DealNoteInfoEntity dealNoteInfoEntity)
        {
            
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDealNoteInformation;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealNoteId", dealNoteInfoEntity.DealNoteId));
                command.Parameters.Add(command.CreateParameter("@pDealId", dealNoteInfoEntity.DealId));
                command.Parameters.Add(command.CreateParameter("@pName", dealNoteInfoEntity.Name));
                command.Parameters.Add(command.CreateParameter("@pISIN", dealNoteInfoEntity.ISIN));
                command.Parameters.Add(command.CreateParameter("@pValidFrom", dealNoteInfoEntity.ValidFrom));
                command.Parameters.Add(command.CreateParameter("@pValidTo", dealNoteInfoEntity.ValidTo));
                command.Parameters.Add(command.CreateParameter("@pNewRedemptionDate", dealNoteInfoEntity.EarlyRedemptionDate));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", dealNoteInfoEntity.AuthorizerComment));
                command.Parameters.Add(command.CreateParameter("@pDealStatusId", dealNoteInfoEntity.DealStatusId));
                command.Parameters.Add(command.CreateParameter("@pUserName", dealNoteInfoEntity.UserName));

                var result = this.ExecuteNonQuery(command);
                return result;
            }
        }

        public int ManageDealNoteAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Authorise)
            {
                authWorkflowEntity.WorkflowStep = (int)DealNoteAuthorisation.Authorise;
            }
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Reject)
            {
                authWorkflowEntity.WorkflowStep = (int)DealNoteAuthorisation.Reject;
            }
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_ManageDealNoteWorkflowProcess;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", authWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", authWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, authWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, authWorkflowEntity.UserName));
                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }

        public int DealNoteSentforAuthorization(DealNoteInfoEntity dealNoteInfoEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_DealNoteWorkflowProcess;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealStatusId", dealNoteInfoEntity.DealStatusId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, dealNoteInfoEntity.UserName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamAuthorizerComment, dealNoteInfoEntity.AuthorizerComment));
                

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }





    }
}
