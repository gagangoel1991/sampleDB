﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class DealCounterpartyDataService : Repository<DealCounterpartyEntity>, IDealCounterpartyDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealCounterpartyDataService()
        {

        }

        public DealCounterpartyDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the deal counter party
        /// </summary>
        /// <param name="dealId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<DealCounterpartyEntity> GetDealCounterparty(int dealId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDealCounterparty;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).ToList();
            }
        }
    }
}
