﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class StratDealTypeDataService : Repository<StratDealType>, IStratDealTypeDataService
    {
        private IUnitOfWork _unitOfWork;

        public StratDealTypeDataService()
        {

        }

        public StratDealTypeDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public IEnumerable<StratDealType> GetDealTypeList(int StratId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetStratDealTypes;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pStratId", StratId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));

                return  this.Execute(command).ToArray(); 
            }
        }



    }

}
