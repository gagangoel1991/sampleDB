﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Message.CW.IR;
    using NW.SFP.Common;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class StratDataService : Repository<StratEntity>, IStratDataService
    {
        private IUnitOfWork _unitOfWork;

        public StratDataService()
        {

        }

        public StratDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public IEnumerable<StratEntity> GetAssetStratList(int stratType, int AssetClassId, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetAssetStratDetail;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pStratType", stratType));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("pAssetClassId", AssetClassId));
                return this.Execute(command).ToArray();
            }
        }

        public StratEntity GetAssetStratDetail(int StratId, string UserName, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetAssetStratDetail;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pStratId", StratId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                return this.ExecuteToEntity(command);
            }
        }

        public StratEntity GetBeSpokeAssetStratDetail(int StratId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetAssetStratDetail;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pStratId", StratId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));
                command.Parameters.Add(command.CreateParameter("pStratType", StratType.BespokeStrat));
                return this.ExecuteToEntity(command);
            }
        }

        public StratEntity Save(StratEntity assetStrat, string UserName, int AssetClassId, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveAssetStrat;
                command.CommandType = CommandType.StoredProcedure;

                

                command.Parameters.Add(command.CreateParameter("pStratId", assetStrat.StratId));
                command.Parameters.Add(command.CreateParameter("pFieldId", assetStrat.FieldId));
                command.Parameters.Add(command.CreateParameter("pName", assetStrat.Name));
                command.Parameters.Add(command.CreateParameter("pDescription", assetStrat.Description));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));
                command.Parameters.Add(command.CreateParameter("pDealTypeList", Utils.SetSelectListTableValues(assetStrat.StratDealTypeList)));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("pAssetClassId", AssetClassId));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                assetStrat.StratId = Convert.ToInt32(ReturnCode.Value);

                return assetStrat;
            }
        }

        public StratEntity Update(StratEntity assetStrat, string UserName)
        {
            return null;
        }

        public int Delete(int StratId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_DeleteAssetStrat;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pStratId", StratId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToInt32(ReturnCode.Value);
            }
        }

       

        public DataTable GetStratPreviewData(string StratName, string AsAtDate, string DealName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetStratProcessedData;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pAsAtDate", AsAtDate));
                command.Parameters.Add(command.CreateParameter("pDealName", DealName));
                command.Parameters.Add(command.CreateParameter("pStratInternalName", StratName));


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }

                return dt;
            }
        }


        public BespokeStratPreviewEntity GetStratPreviewData(StratPreviewSearchEntity stratPreviewSearchEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetStratProcessedData;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pAsAtDate", stratPreviewSearchEntity.IpdDate));
                command.Parameters.Add(command.CreateParameter("pDealName", stratPreviewSearchEntity.DealName));
                command.Parameters.Add(command.CreateParameter("pFieldId", stratPreviewSearchEntity.FieldId));
                command.Parameters.Add(command.CreateParameter("@pHeader", stratPreviewSearchEntity.Header));
                command.Parameters.Add(command.CreateParameter("@pStratName", stratPreviewSearchEntity.StratName));
                command.Parameters.Add(command.CreateParameter("pStratRangeData", stratPreviewSearchEntity.StratCriteriaList.ToDataTable()));
                command.Parameters.Add(command.CreateParameter("@pAssetId", stratPreviewSearchEntity.AssetId));


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                BespokeStratPreviewEntity objBespokeStratPreviewEntity = new BespokeStratPreviewEntity();

                DataTable dt = new DataTable();

                if (ds.Tables.Count == 1 || ds.Tables.Count == 2)
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        objBespokeStratPreviewEntity.Data = ds.Tables[0];
                    else
                        objBespokeStratPreviewEntity.Data = null;
                }
                if (ds.Tables.Count == 2)
                {
                    if (ds != null && ds.Tables[1] != null && ds.Tables[1].Rows.Count > 0)
                        objBespokeStratPreviewEntity.Header = ds.Tables[1];
                    else
                        objBespokeStratPreviewEntity.Header = null;
                }

                return objBespokeStratPreviewEntity;
            }
        }
    }
}
