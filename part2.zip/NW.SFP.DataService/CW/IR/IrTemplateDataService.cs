﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class IrTemplateDataService : Repository<IrTemplateEntity>, IIrTemplateDataService
    {
        private IUnitOfWork _unitOfWork;

        public IrTemplateDataService()
        {

        }

        public IrTemplateDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public IList<IrTemplateEntity> GetTemplateList(int assetClassId, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetIrTemplateDetail;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("pAssetClassID", assetClassId));
                return this.Execute(command).ToArray();
            }
        }

        public IrTemplateEntity GetTemplateDetail(int templateId, string UserName, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetIrTemplateDetail;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pTemplateId", templateId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                return this.ExecuteToEntity(command);
            }
        }

        public int Save(IrTemplateEntity templateEntity, string UserName, int assetClassId, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveIrTemplate;
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Add(command.CreateParameter("pTemplateId", templateEntity.TemplateId));
                command.Parameters.Add(command.CreateParameter("pName", templateEntity.Name));
                command.Parameters.Add(command.CreateParameter("pDescription", templateEntity.Description));
                command.Parameters.Add(command.CreateParameter("pOriginalFileName", templateEntity.OriginalFileName));
                command.Parameters.Add(command.CreateParameter("pUploadedFileName", templateEntity.UploadedFileName));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));
                command.Parameters.Add(command.CreateParameter("pDealTypeId", templateEntity.DealTypeId));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("pAssetClassId", assetClassId));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToInt32(ReturnCode.Value);
            }
        }

        public int Delete(int templateId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_DeleteIrTemplate;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pTemplateId", templateId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToInt32(ReturnCode.Value);
            }
        }




    }
}