﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Message.CW.IR;
    using NW.SFP.Message.Common;    
    using NW.SFP.Message.PS;

    public class DealIrConfigDataService : Repository<DealIrConfigListEntity>, IDealIrConfigDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealIrConfigDataService()
        {

        }

        public DealIrConfigDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the Deal IR Config List
        /// </summary>
        /// <param name="userName"></param>
        /// <returns></returns>
        public IList<DealIrConfigListEntity> GetDealIrConfigList(string userName, string ReportTypeName, int AssetClassId)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealIrConfigList;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("@pAssetClassId", AssetClassId));
                return this.Execute(command).ToList();
            }
        }

        /// <summary>
        /// This will return the single Deal IR Config record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public DealIrConfigEntity GetDealIrConfig(int dealIrConfigId, string loggedInUser, string ReportTypeName, int AssetClassId = 1)
        {
            var obj = new DealIrConfigEntity();

            obj.IR_Config = GetIrConfig(dealIrConfigId, loggedInUser, ReportTypeName);
            obj.IR_ConfigDetailList = GetIRConfDealList(dealIrConfigId, loggedInUser, ReportTypeName, AssetClassId);
            obj.IR_ConfigLayoutList = GetIRConfLayoutList(dealIrConfigId, obj.IR_Config.DealId, loggedInUser, ReportTypeName, AssetClassId);
            obj.IR_ConfigStartList = GetIrConfStartList(dealIrConfigId, obj.IR_Config.DealId, loggedInUser, ReportTypeName, AssetClassId);
            obj.IR_MappedFieldList = GetBuildCongfigMappedFields(dealIrConfigId, loggedInUser);

            return obj;

        }

        private IR_Config GetIrConfig(int dealIrConfigId, string loggedInUser, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealIrConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", dealIrConfigId));
                command.Parameters.Add(command.CreateParameter("@pTypeId", Types.IR_Config));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                using (var record = command.ExecuteReader())
                {
                    IR_Config items = new IR_Config();
                    while (record.Read())
                    {
                        items = Map<IR_Config>(record);
                    }

                    return items;
                }

            }
        }
        private List<IR_ConfigDealList> GetIRConfDealList(int dealIrConfigId, string loggedInUser, string ReportTypeName, int AssetClassID = 1)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealIrConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", dealIrConfigId));
                command.Parameters.Add(command.CreateParameter("@pTypeId", Types.IR_ConfigDetailList));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("@pAssetClassID", AssetClassID));
                using (var record = command.ExecuteReader())
                {
                    List<IR_ConfigDealList> items = new List<IR_ConfigDealList>();
                    while (record.Read())
                    {
                        items.Add(Map<IR_ConfigDealList>(record));
                    }

                    return items;
                }
            }
        }

        private List<IR_ConfigLayoutList> GetIRConfLayoutList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassId = 1)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealIrConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", dealIrConfigId));
                command.Parameters.Add(command.CreateParameter("@pTypeId", Types.IR_ConfigLayoutList));
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("@pAssetClassID", AssetClassId));
                using (var record = command.ExecuteReader())
                {
                    List<IR_ConfigLayoutList> items = new List<IR_ConfigLayoutList>();
                    while (record.Read())
                    {
                        items.Add(Map<IR_ConfigLayoutList>(record));
                    }

                    return items;
                }
            }
        }

        public List<IR_ConfigStartList> GetIrConfStartList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassId = 1)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealIrConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", dealIrConfigId));
                command.Parameters.Add(command.CreateParameter("@pTypeId", Types.IR_ConfigStartList));
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("@pAssetClassID", AssetClassId));
                using (var record = command.ExecuteReader())
                {
                    List<IR_ConfigStartList> items = new List<IR_ConfigStartList>();
                    while (record.Read())
                    {
                        items.Add(Map<IR_ConfigStartList>(record));
                    }

                    return items;
                }
            }
        }

        public List<IR_MappedFieldList> GetBuildCongfigMappedFields(int dealIrConfigId, string UserName)
        {
            using (var cmd = this._unitOfWork.CreateCommand())
            {
                cmd.CommandText = CWDBConstants.SP_GetDealIrConfig;
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.Add(cmd.CreateParameter("@pDealIrConfigId", dealIrConfigId));                
                cmd.Parameters.Add(cmd.CreateParameter("@pUserName", UserName));
                cmd.Parameters.Add(cmd.CreateParameter("@pTypeId", Types.IR_ConfigFieldsList));
                using (var record = cmd.ExecuteReader())
                {
                    List<IR_MappedFieldList> items = new List<IR_MappedFieldList>();
                    while (record.Read())
                    {
                        items.Add(Map<IR_MappedFieldList>(record));
                    }

                    return items;
                }
            }
        }

        /// <summary>
        /// Delete Deal Ir Config Record
        /// </summary>
        /// <param name="dealIrConfigId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public int DeleteDealIrConfig(int dealIrConfigId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_DeleteDealIrConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", dealIrConfigId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pResult", 0));
                command.Parameters["@pResult"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);

                return Utility.GetInt(command.Parameters["@pResult"].Value);
            }
        }

        /// <summary>
        /// This will save the Deal Ir Config record.
        /// </summary>
        /// <param name="dealIrConfigData"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public int SaveDealIrConfig(DealIrConfigAddEditEntity dealIrConfigData, string loggedInUser, string ReportTypeName, int AssetClassId)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDealIrConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", dealIrConfigData.DealIrConfigId));
                command.Parameters.Add(command.CreateParameter("@pName", dealIrConfigData.Name));
                command.Parameters.Add(command.CreateParameter("@pDescription", dealIrConfigData.Description));
                command.Parameters.Add(command.CreateParameter("@pDealId", dealIrConfigData.DealId));
                command.Parameters.Add(command.CreateParameter("@pTemplateId", (object)dealIrConfigData.TemplateId ?? (object)DBNull.Value));
                command.Parameters.Add(command.CreateParameter("@pOriginalFileName", dealIrConfigData.OriginalFileName));
                command.Parameters.Add(command.CreateParameter("@pUploadedFileName", dealIrConfigData.UploadedFileName));
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", dealIrConfigData.WorkFlowStepId));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", dealIrConfigData.AuthorizerComment));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                command.Parameters.Add(command.CreateParameter("@pAssetClassId", AssetClassId));
                command.Parameters.Add(command.CreateParameter("@CanShowSecurity", dealIrConfigData.CanShowSecurity));

                if (dealIrConfigData.DealIrStratMapList != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        TypeName = "cfgCW.DealIrStratMapList",
                        Value = dealIrConfigData.DealIrStratMapList.ToDataTable(),
                        ParameterName = "@pDealIrStratMapList"
                    });
                }

                if (dealIrConfigData.StratMappedFieldList != null)
                {

                    command.Parameters.Add(new SqlParameter
                    {
                        TypeName = "[ps].[AdhocReportFieldDetail]",
                        Value = dealIrConfigData.StratMappedFieldList.ToDataTable(),
                        ParameterName = "@pStratMappedFieldList"
                    });
                }

                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pAction", dealIrConfigData.Action));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }

        public List<IR_ConfigDealList> getIrConfigDealList(int dealIrConfigId, string loggedInUser, string ReportTypeName)
        {
            return GetIRConfDealList(dealIrConfigId, loggedInUser, ReportTypeName);
        }

        public List<IR_ConfigLayoutList> getIrConfigLayoutList(int dealIrConfigId, int dealId, string loggedInUser, string ReportTypeName, int AssetClassID)
        {
            return GetIRConfLayoutList(dealIrConfigId, dealId, loggedInUser, ReportTypeName, AssetClassID);
        }

        public int ManageDealIRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_ManageDealIRWorkflowProcess;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIrConfigId", authWorkflowEntity.ProcessId));
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", authWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", authWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, authWorkflowEntity.UserName));
                return this.ExecuteNonQuery(command);
            }
        }
    }
}
