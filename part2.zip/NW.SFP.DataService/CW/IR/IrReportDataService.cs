﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Message.CW.IR;
    using System.Threading.Tasks;
    using Microsoft.Extensions.Options;
    using NW.SFP.Common;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class IrReportDataService : Repository<ExcelUploadEntity>, IIrReportDataService
    {
        private IUnitOfWork _unitOfWork;
        private readonly IOptions<Message.Core.DataServiceSettings> _settings;

        public IrReportDataService()
        {   
        }

        public IrReportDataService(IUnitOfWork uow, IOptions<Message.Core.DataServiceSettings> settings)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;

            this._settings = settings;
        }

       
        public IEnumerable<ExcelUploadEntity> GetExcelReportList(string DealName, string AsAtDate)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetExcelSchemaForReport;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("DealName", DealName));
                command.Parameters.Add(command.CreateParameter("AsAtDate", AsAtDate));
                return this.Execute(command).ToArray();
            }
        }

        public IEnumerable<ExcelUploadEntity> GetExcelReportList(int dealIrConfigId, string AsAtDate, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetExcelSchemaForDealIRConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pDealIrConfigId", dealIrConfigId));
                command.Parameters.Add(command.CreateParameter("pAsAtDate", AsAtDate));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                return this.Execute(command).ToArray();
            }
        }

        

        public DataTable GetIrStratData(string AsAtDate, string DealName, int FieldId, string StratName, string loggedInUserName, string ReportTypeName, int AssetId) 
        { 
            using (SqlConnection sqlConn = new SqlConnection(this._settings.Value.ConnectionString))
            {
                SqlCommand command = new SqlCommand();
                command.Connection = sqlConn;
                command.CommandTimeout = 0;

                DataTable dt = new DataTable();
                try
                {
                    command.CommandText = SP_GetStratProcessedData;
                    command.CommandType = CommandType.StoredProcedure;

                    command.Parameters.Add(command.CreateParameter("pAsAtDate", AsAtDate));
                    command.Parameters.Add(command.CreateParameter("pDealName", DealName));
                    command.Parameters.Add(command.CreateParameter("pFieldId", FieldId));
                    command.Parameters.Add(command.CreateParameter("pStratName", StratName));
                    command.Parameters.Add(command.CreateParameter("pUserName", loggedInUserName));
                    command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                    command.Parameters.Add(command.CreateParameter("pAssetId", AssetId));

                    SqlDataAdapter adapter = new SqlDataAdapter(command);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds); 

                    if (ds.Tables.Count < 1)
                        dt = null;
                    else
                    {
                        if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        {
                            dt = ds.Tables[0];

                            dt = PrepareAggregateReportData(dt, AsAtDate, DealName, StratName, ReportTypeName); 
                        }
                        else
                            dt = null;
                    }
                }
                catch(Exception ex)
                {
                    dt = null;
                } 

                return dt;
            }
        }

        public DataTable PrepareAggregateReportData(DataTable dt, string AsAtDate, string DealName, string StratName, string ReportTypeName)
        { 
            if (ReportTypeName.ToLower() == "moodys" )
            {
                DataColumnCollection columnss = dt.Columns;
                if (columnss != null && columnss.Contains("ColumnName"))
                    dt.Columns.Remove("ColumnName");
                if (columnss != null && columnss.Contains("SortOrder"))
                    dt.Columns.Remove("SortOrder");
            }

            return dt;
        }
       
        private DataTable UpdateAccountsLedgersdata(DataTable dtAccount)
        {      
            DataTable dtReturn = new DataTable();
            for (int i = 0; i < dtAccount.Columns.Count; i++)
            {
                dtReturn.Columns.Add("Co1"+i, typeof(Object));
            }
            for(int r = 0; r<dtAccount.Rows.Count; r++)
            {               
                dtReturn.Rows.Add();
                for (int i = 0; i < dtAccount.Columns.Count; i++)
                {
                    var a = dtAccount.Rows[r][i].ToString();
                    if (dtAccount.Rows[r][i].ToString() != null && dtAccount.Rows[r][i].ToString() != "")
                    {
                        dtReturn.Rows[r][i] =dtAccount.Rows[r][i];
                    }
                    else
                        dtReturn.Rows[r][i] = "N/A";

                }
            }
            return dtReturn;
        }
        
        private DataTable UpdateLoanRedemptionsData(DataTable CalcLoanRedemtion, string AsAtDate, string DealName, string ReportTypeName)
        {
            DataTable LoanRedemtionAsset = new DataTable();
            DataTable LoanRedemtionLiability = new DataTable();

            var _tasks = new List<Task<DataTable>>(); 
            _tasks.Add(Task.Run(() => LoanRedemtionAsset = GetReportDataBySpName(SP_GetLoanRedemptionAndReplishment, AsAtDate, DealName, ReportTypeName, "model")));
            _tasks.Add(Task.Run(() => LoanRedemtionLiability = GetReportDataBySpName(SP_GetLoanRedemtionLiability, AsAtDate, DealName, ReportTypeName, "securitisation")));
            Task.WaitAll(_tasks.ToArray());


            if (LoanRedemtionAsset.Rows.Count > 0 && LoanRedemtionLiability.Rows.Count > 3)
            {
                CalcLoanRedemtion = LoanRedemtionAsset.Copy();

                //Remove Column
                CalcLoanRedemtion.Columns.Remove("totalCount");
                CalcLoanRedemtion.Columns.Remove("totalOutsatndingCapitalBalance");
                //Get Values for calculations now
                int _totalSubAccountCount = (int)LoanRedemtionAsset.Rows[0]["totalCount"];
                double _totalOutstandingCapitalBalance = (double)(decimal)LoanRedemtionAsset.Rows[0]["totalOutsatndingCapitalBalance"];

                double _perTotalNonPerformingLoansNum = 0;
                _perTotalNonPerformingLoansNum = (double)(decimal)LoanRedemtionLiability.Rows[0][0] / (double)_totalSubAccountCount;

                double _perTotalNonPerformingLoansAmount = 0;
                _perTotalNonPerformingLoansAmount = (double)(decimal)LoanRedemtionLiability.Rows[1][0] / (double)_totalOutstandingCapitalBalance;

                double _perTotalbreachedLoansNum = 0;
                _perTotalbreachedLoansNum = (double)(decimal)LoanRedemtionLiability.Rows[2][0] / (double)_totalSubAccountCount;

                double _perTotalbreachedLoansAmount = 0;
                _perTotalbreachedLoansAmount = (double)(decimal)LoanRedemtionLiability.Rows[3][0] / (double)_totalOutstandingCapitalBalance;

                //Prepare the Datatable now
                DataRow _row = CalcLoanRedemtion.NewRow();
                _row[0] = 3;
                _row[1] = LoanRedemtionLiability.Rows[0][0];
                _row[2] = _perTotalNonPerformingLoansNum;
                _row[3] = LoanRedemtionLiability.Rows[1][0];
                _row[4] = _perTotalNonPerformingLoansAmount;
                CalcLoanRedemtion.Rows.InsertAt(_row, 2);

                DataRow _row1 = CalcLoanRedemtion.NewRow();
                _row1[0] = 4;
                _row1[1] = LoanRedemtionLiability.Rows[2][0];
                _row1[2] = _perTotalbreachedLoansNum;
                _row1[3] = LoanRedemtionLiability.Rows[3][0];
                _row1[4] = _perTotalbreachedLoansAmount;
                CalcLoanRedemtion.Rows.InsertAt(_row1, 3); 
                CalcLoanRedemtion.AcceptChanges(); 
            }

            return CalcLoanRedemtion;
        }

        private DataTable UpdateProgramLevelCharData(DataTable ProgramLevelCharactersticsAsset,string AsAtDate, string DealName, string ReportTypeName)
        {
            try
            {
                
                DataTable ProgramLevelCharacterstics_Liability = new DataTable();
                DataTable CPR1 = new DataTable();
                DataTable CPR2 = new DataTable();
                DataTable CPR3 = new DataTable();

                var _tasks = new List<Task<DataTable>>();
                _tasks.Add(Task.Run(() => ProgramLevelCharacterstics_Liability = GetReportDataBySpName(SP_GetProgramLevelCharacterstics, AsAtDate, DealName, ReportTypeName, "securitisation")));
                _tasks.Add(Task.Run(() => CPR1 = GetReportDataBySpName(SP_GetCPR1_V1, AsAtDate, DealName, ReportTypeName, "model")));
                _tasks.Add(Task.Run(() => CPR2 = GetReportDataBySpName(SP_GetCPR2_V1, AsAtDate, DealName, ReportTypeName, "model")));
                _tasks.Add(Task.Run(() => CPR3 = GetReportDataBySpName(SP_GetCPR3_V1, AsAtDate, DealName, ReportTypeName, "model")));
                Task.WaitAll(_tasks.ToArray());


                //Update combined value
                if (ProgramLevelCharactersticsAsset != null && ProgramLevelCharactersticsAsset.Rows.Count > 0 && ProgramLevelCharacterstics_Liability != null && ProgramLevelCharacterstics_Liability.Rows.Count > 0)
                {
                    //Last minute change as stated by Zhen
                    Double _totalOutstandingBalance = (Double)Convert.ToDecimal(ProgramLevelCharactersticsAsset.Rows[1]["Value"]);
                    Double _numOfLoans = (Double)Convert.ToDecimal(ProgramLevelCharactersticsAsset.Rows[0]["Value"]);
                    Double _finalVal = _totalOutstandingBalance / _numOfLoans;
                    //Finally change value
                    ProgramLevelCharactersticsAsset.Rows[1]["Value"] = _finalVal;
                    //Update Liability Data Value
                    ProgramLevelCharacterstics_Liability.Rows[3]["Value"] = _totalOutstandingBalance;
                    ProgramLevelCharacterstics_Liability.AcceptChanges();

                    //Last minute changes again pathetic fed up of ti
                    Decimal _aggregateDeposit_8 = 0;
                    decimal.TryParse(ProgramLevelCharacterstics_Liability.Rows[8]["Value"].ToString(), out _aggregateDeposit_8); 
                    Double _aggregateDepositattToCoverPool = (Double)_aggregateDeposit_8; 
                    ProgramLevelCharacterstics_Liability.Rows[8]["Value"] = ((Double)_totalOutstandingBalance * _aggregateDepositattToCoverPool) / 100;

                    Decimal _aggregateDeposit_10 = 0;
                    decimal.TryParse(ProgramLevelCharacterstics_Liability.Rows[10]["Value"].ToString(), out _aggregateDeposit_10); 
                    Double _nominalLevelOfOverCollatralizationGBP = (Double)_aggregateDeposit_10; 
                    ProgramLevelCharacterstics_Liability.Rows[10]["Value"] = (Double)_totalOutstandingBalance - _nominalLevelOfOverCollatralizationGBP;
                    ProgramLevelCharacterstics_Liability.AcceptChanges();

                    Decimal _aggregateDeposit_11 = 0;
                    decimal.TryParse(ProgramLevelCharacterstics_Liability.Rows[11]["Value"].ToString(), out _aggregateDeposit_11); 
                    Double _nominalLevelOfOverCollatralizationPercntage = (Double)_aggregateDeposit_11;

                    _aggregateDeposit_10 = 0;
                    decimal.TryParse(ProgramLevelCharacterstics_Liability.Rows[10]["Value"].ToString(), out _aggregateDeposit_10);
                    ProgramLevelCharacterstics_Liability.Rows[11]["Value"] = (Double)_aggregateDeposit_10 / (Double)_nominalLevelOfOverCollatralizationGBP;
                    ProgramLevelCharacterstics_Liability.AcceptChanges();

                    
                    ProgramLevelCharacterstics_Liability.Rows.RemoveAt(28);
                    ProgramLevelCharactersticsAsset.AcceptChanges();

                    if (ProgramLevelCharacterstics_Liability.Rows.Count > 28)
                    {
                        ProgramLevelCharacterstics_Liability.Rows.RemoveAt(28);
                        ProgramLevelCharactersticsAsset.AcceptChanges();
                    }
                }
                //Update CPR column Value
                if (CPR1 != null && CPR1.Rows.Count > 0)
                {
                    Double CPR1Value = 0;
                    Double CPR2Value = 0;
                    Double CPR3Value = 0;

                    CPR1Value = ((Math.Round(
                                       (
                                            1 - (
                                                 Math.Pow(
                                                           (
                                                               1 - (
                                                                   (
                                                                       (Double)((Decimal)CPR1.Rows[0]["TotalPrincipleReceipts"])
                                                                          /
                                                                       (Double)((Decimal)CPR1.Rows[0]["TotalOutStandingBalance"])
                                                                   ) * 100
                                                                 ) / 100
                                                            ), 12
                                                           )
                                                )
                                       ) * 100
                                     , 2
                                     )) / 100);

                    //Set Value in Dataset
                    ProgramLevelCharactersticsAsset.Rows[8]["Value"] = CPR1Value;
                    ProgramLevelCharactersticsAsset.AcceptChanges();

                    if (CPR2 != null && CPR2.Rows.Count > 0 && CPR3 != null && CPR3.Rows.Count > 0)
                    {
                        CPR2Value = ((Math.Round(
                                      (
                                           1 - (
                                                Math.Pow(
                                                          (
                                                              1 - (
                                                                  (
                                                                       (Double)((Decimal)CPR2.Rows[0]["TotalPrincipleReceipts"])
                                                                          /
                                                                       (Double)((Decimal)CPR2.Rows[0]["TotalOutStandingBalance"])
                                                                  ) * 100
                                                                ) / 100
                                                           ), 12
                                                          )
                                               )
                                      ) * 100
                                    , 2
                                    )) / 100);

                        CPR3Value = ((Math.Round(
                                      (
                                           1 - (
                                                Math.Pow(
                                                          (
                                                              1 - (
                                                                  (
                                                                       (Double)((Decimal)CPR3.Rows[0]["TotalPrincipleReceipts"])
                                                                          /
                                                                       (Double)((Decimal)CPR3.Rows[0]["TotalOutStandingBalance"])
                                                                  ) * 100
                                                                ) / 100
                                                           ), 12
                                                          )
                                               )
                                      ) * 100
                                    , 2
                                    )) / 100);

                        //Set Value in Dataset
                        ProgramLevelCharactersticsAsset.Rows[9]["Value"] = (CPR1Value + CPR2Value + CPR3Value) / 3;
                        ProgramLevelCharactersticsAsset.AcceptChanges();

                    }
                }

                return ProgramLevelCharactersticsAsset;
            }
            catch (Exception ex)
            {
                return ProgramLevelCharactersticsAsset;
            }
        }

        public DataTable UpdateAnnex2dACTdata(DataTable ACT, string AsAtDate, string DealName, string ReportTypeName)
        {
            try
            {
                DataTable ACTAssetCalc = new DataTable();
                DataTable ACTCalc1 = new DataTable();
                DataTable ACTCalc2 = new DataTable();
                DataTable ACTCalc3 = new DataTable();

                var _tasks = new List<Task<DataTable>>();
                _tasks.Add(Task.Run(() => ACTAssetCalc = GetReportDataBySpName(SP_GetAsset_Coverage_Test, AsAtDate, DealName, ReportTypeName, "model")));
                _tasks.Add(Task.Run(() => ACTCalc1 = GetReportDataBySpName(SP_GetACTCalc1, AsAtDate, DealName, ReportTypeName, "securitisation")));
                _tasks.Add(Task.Run(() => ACTCalc2 = GetReportDataBySpName(SP_GetACTCalc2, AsAtDate, DealName, ReportTypeName, "securitisation")));
                _tasks.Add(Task.Run(() => ACTCalc3 = GetReportDataBySpName(SP_GetACTCalc3, AsAtDate, DealName, ReportTypeName, "securitisation")));
                Task.WaitAll(_tasks.ToArray());


                ACT = new DataTable();

                if (ACTCalc1.Rows.Count > 0 && ACTCalc2.Rows.Count > 0 && ACTCalc3.Rows.Count > 0 && ACTAssetCalc.Rows.Count > 0)
                {
                    //As per Line 43 of shared calculation in excel
                    Double AdjustedOutstandingBalanceAFterRepsAndWarrenties = 0;
                    AdjustedOutstandingBalanceAFterRepsAndWarrenties = (Double)(Decimal)ACTAssetCalc.Rows[0]["AdjustedOutstandingCapitalBalance"] - (Double)(Decimal)ACTCalc1.Rows[0]["Value2"] - (Double)(Decimal)ACTCalc1.Rows[0]["Value3"];

                    //As per Line 49 of shared calculation in excel
                    Double ArrearsDjustedTrueBalance = 0;
                    ArrearsDjustedTrueBalance = (Double)(Decimal)ACTAssetCalc.Rows[0]["ArrearsAdjustedOutstandingCapitalBalance"] - (Double)(Decimal)ACTCalc1.Rows[0]["Value2"] - (Double)(Decimal)ACTCalc1.Rows[0]["Value3"];

                    //As per Line 51 of shared calculation in excel
                    Double AssetPercentage = 0;
                    Double MoodysCollatralizationmPercentage = (Double)(Decimal)ACTCalc1.Rows[0]["Value6"];
                    AssetPercentage = Math.Min(Math.Min((Double)(Decimal)ACTCalc1.Rows[0]["Value4"], MoodysCollatralizationmPercentage), (Double)(Decimal)ACTCalc1.Rows[0]["Value6"]);

                    //As per Line 53 of shared calculation in excel
                    Double ArrearsAdjustedTotalOutstandingCapitalBalance = 0;
                    ArrearsAdjustedTotalOutstandingCapitalBalance = (ArrearsDjustedTrueBalance * AssetPercentage) / 100;

                    //Now Calculation for the information that is required to be displayed in Investor report is done
                    Double ActComponentA = 0;
                    ActComponentA = Math.Min(AdjustedOutstandingBalanceAFterRepsAndWarrenties, ArrearsAdjustedTotalOutstandingCapitalBalance);

                    Double ActComponentB = 0;
                    ActComponentB = (Double)(Decimal)ACTCalc2.Rows[0]["AppliedAmount"];

                    Double ActComponentC = 0;
                    ActComponentC = (Double)(Decimal)ACTCalc1.Rows[0]["Value15"];

                    Double ActComponentD = 0;
                    ActComponentD = (Double)(Decimal)ACTCalc1.Rows[0]["Value16"];

                    Double ActComponentE = 0;
                    ActComponentE = (Double)(Decimal)ACTCalc1.Rows[0]["Value17"];

                    Double ActComponentX = 0;
                    ActComponentX = ((Double)(Decimal)ACTCalc1.Rows[0]["Value9"] * 8 / 100) * 3;

                    Double ActComponentY = 0;
                    ActComponentY = (((Double)(Decimal)ACTCalc1.Rows[0]["Value10"]) * ((Double)(Decimal)ACTAssetCalc.Rows[0]["TotalOutStandingBalance"])) / 100;

                    Double SterlingEquivalentOfAggregatePrincipleAmount = 0;
                    SterlingEquivalentOfAggregatePrincipleAmount = (Double)(Decimal)ACTCalc3.Rows[0]["Value11"];

                    Double WeightedAverageRemainingMaturityOfBond = 0;
                    WeightedAverageRemainingMaturityOfBond = (Double)(Decimal)ACTCalc3.Rows[0]["Value12"];

                    Double WeightedAverageMarginOfBond = 0;
                    WeightedAverageMarginOfBond = (Double)(Decimal)ACTCalc3.Rows[0]["Value13"];

                    Double NegativeCarryFactor = 0;
                    NegativeCarryFactor = (WeightedAverageMarginOfBond < 0.1) ? 0.5 : 0.5 + WeightedAverageMarginOfBond - 0.1;

                    Double ActComponentZ = 0;
                    ActComponentZ = Math.Round((SterlingEquivalentOfAggregatePrincipleAmount * WeightedAverageRemainingMaturityOfBond * NegativeCarryFactor), 3) / 100;

                    Double AggregateAdjustedAmount = 0;
                    AggregateAdjustedAmount = (ActComponentA + ActComponentB + ActComponentC + ActComponentD + ActComponentE) - (ActComponentX + ActComponentY + ActComponentZ);

                    string ActTestResult = "";
                    ActTestResult = (AggregateAdjustedAmount >= SterlingEquivalentOfAggregatePrincipleAmount) ? "PASS" : "NO";

                    Double ActHeadRoom = 0;
                    ActHeadRoom = AggregateAdjustedAmount - SterlingEquivalentOfAggregatePrincipleAmount;

                    Double CreditSupportDerived = 0;
                    CreditSupportDerived = (ActHeadRoom / SterlingEquivalentOfAggregatePrincipleAmount) * 100;

                    String MethodUsedCalc = (ArrearsAdjustedTotalOutstandingCapitalBalance < AdjustedOutstandingBalanceAFterRepsAndWarrenties) ? "A(ii)" : "A(i)";
                    //Prepare DataTable now

                    //Add columns First
                    ACT.Columns.Add("ColumnName", typeof(Object));
                    ACT.Columns.Add("Value", typeof(Object));

                    //Add Rows Now
                    ACT.Rows.Add("A", ActComponentA);
                    ACT.Rows.Add("B", ActComponentB);
                    ACT.Rows.Add("C", ActComponentC);
                    ACT.Rows.Add("D", ActComponentD);
                    ACT.Rows.Add("E", ActComponentE);
                    ACT.Rows.Add("V", "N/A");
                    ACT.Rows.Add("W", "N/A");
                    ACT.Rows.Add("X", ActComponentX);
                    ACT.Rows.Add("Y", ActComponentY);
                    ACT.Rows.Add("Z", ActComponentZ);
                    ACT.Rows.Add("Total", AggregateAdjustedAmount);
                    //Still to be calculated
                    ACT.Rows.Add("Method used for calculating component A", MethodUsedCalc);
                    ACT.Rows.Add("Asset percentage", AssetPercentage / 100);
                    ACT.Rows.Add("Maximum asset percentage from Fitch", (Double)(Decimal)ACTCalc1.Rows[0]["Value4"] / 100);
                    ACT.Rows.Add("Maximum asset percentage from Moodys", MoodysCollatralizationmPercentage / 100);
                    ACT.Rows.Add("Maximum asset percentage from S&P", "N/A");
                    ACT.Rows.Add("Maximum asset percentage from DBRS", "N/A");
                    ACT.Rows.Add("Credit support as derived from ACTGBP", ActHeadRoom);
                    ACT.Rows.Add("Credit support as derived from ACT", CreditSupportDerived / 100);
                    //ACT.AcceptChanges();
                }

                ACT.AcceptChanges(); 
                return ACT;
            }
            catch (Exception ex)
            {
                return ACT;
            }
        }

        private DataTable GetReportDataBySpName(string SpName, string AsAtDate, string DealName, string ReportTypeName, string DBCode)
        {
            DataTable dt = new DataTable(); 

            try
            {
                using (SqlConnection sqlConn = new SqlConnection(this._settings.Value.ConnectionString))
                { 
                    SqlCommand command = new SqlCommand();  
                    {
                        command.Connection = sqlConn;
                        command.CommandTimeout = 0; 

                        command.CommandText = SP_GetReportProcessedData;
                        command.CommandType = CommandType.StoredProcedure;
                        command.Parameters.Add(command.CreateParameter("@storedProcName", SpName));
                        command.Parameters.Add(command.CreateParameter("@pAsAtDate", AsAtDate));
                        command.Parameters.Add(command.CreateParameter("@pDealName", DealName));
                        command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                        command.Parameters.Add(command.CreateParameter("@DBCode", DBCode));

                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataSet ds = new DataSet();
                        adapter.Fill(ds);

                        if (ds.Tables.Count > 0)
                        {
                            if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                            {
                                dt = ds.Tables[0];
                            }
                        }
                    } 
                }
            }
            catch(Exception ex)
            { 
                throw ex;
            }
            return dt;
        }

        public IEnumerable<ExcelUploadEntity> GetExcelPostWFControlList(string DealName, string AsAtDate)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetExcelSchemaForPostWFControl;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealName", DealName));
                command.Parameters.Add(command.CreateParameter("@pAsAtdate", AsAtDate));
                return this.Execute(command).ToArray();
            }
        }

        public IR_Config GetDealIRConfigByDealId(int DealId, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDealIrConfigByDealId;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", DealId));
                command.Parameters.Add(command.CreateParameter("@pReportTypeName", ReportTypeName));
                using (var record = command.ExecuteReader())
                {
                    IR_Config items = new IR_Config();
                    while (record.Read())
                    {
                        items = Map<IR_Config>(record);
                    }

                    return items;
                }

            }
        }
        public void CheckAndLoadMortgageFieldData(string DealName, string AsAtDate)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_CheckAndLoadMortgageFieldData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pAsAtDate", AsAtDate));
                command.Parameters.Add(command.CreateParameter("pDealName", DealName));
                this.ExecuteNonQuery(command);
            }
        }
    }
}
