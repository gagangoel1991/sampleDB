﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class StratConfigtDataService : Repository<StratCriteriaEntity>, IStratConfigtDataService
    {
        private IUnitOfWork _unitOfWork;

        public StratConfigtDataService()
        {

        }

        public StratConfigtDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public IEnumerable<StratCriteriaEntity> GetAssetStratCriteriaList(int StratId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetAssetStratConfigDetail;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("pStratId", StratId));
                command.Parameters.Add(command.CreateParameter("pUserName", UserName));
                return this.Execute(command).ToArray();
            }
        }

        public StratCriteriaEntity Save(StratCriteriaEntity assetStratConfig, string UserName, string ReportTypeName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_InsertAssetStratConfig;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("pStratId", assetStratConfig.StratId));
                command.Parameters.Add(command.CreateParameter("pFromOperatorId", assetStratConfig.FromOperatorId));
                command.Parameters.Add(command.CreateParameter("pFromValue", assetStratConfig.FromValue));
                command.Parameters.Add(command.CreateParameter("pToOperatorId", assetStratConfig.ToOperatorId));
                command.Parameters.Add(command.CreateParameter("pToValue", assetStratConfig.ToValue));
                command.Parameters.Add(command.CreateParameter("pSortOrder", assetStratConfig.SortOrder));
                command.Parameters.Add(command.CreateParameter("pCreatedBy", UserName));
                command.Parameters.Add(command.CreateParameter("pReportTypeName", ReportTypeName));
                this.ExecuteNonQuery(command);

                return assetStratConfig;
            }
        }

        public StratCriteriaEntity Update(StratCriteriaEntity assetStratConfig, string UserName)
        {
            return null;
        }

        public bool Delete(int StratId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_DeleteAssetStratConfig;
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Add(command.CreateParameter("pStratId", StratId));
                command.Parameters.Add(command.CreateParameter("pModifiedBy", UserName));


                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToBoolean(ReturnCode.Value);
            }
        }

    }

}
