﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Message.Core;
    using Microsoft.Extensions.Options;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class IrLookupDataService : IIrLookupDataService
    {
        #region Object Declarations and Constructor
        private readonly IOptions<DataServiceSettings> _settings;
        public IrLookupDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        #endregion

        /// <summary>
        /// This will return the starts master list based on type
        /// </summary>
        /// <param name="stratTypeId"></param>
        /// <param name="loggedInUserName"></param>
        /// <returns></returns>
        public IList<StratLookup> GetStratLookup(int stratTypeId, string loggedInUserName)
        {
            IList<StratLookup> stratList = new List<StratLookup>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetStratMasterByType, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@pStratTypeId", stratTypeId);
                cmd.Parameters.AddWithValue("@pUserName", loggedInUserName);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    stratList.Add(new StratLookup()
                    {
                        StratId = Utility.GetInt(reader["StratId"]),
                        Name = Utility.GetString(reader["Name"]),
                        Description = Utility.GetString(reader["Description"])
                    });
                }
            }
            return stratList;
        }
    }
}
