﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.CW.DailyCashCollections
{
  public  class DailyCollectionDealDataSummary : Repository<DailyCollectionDealSummaryModel>, IDailyCollectionDealDataSummary
    {

        private IUnitOfWork _unitOfWork;

        public DailyCollectionDealDataSummary()
        {

        }

        public DailyCollectionDealDataSummary(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the active deals details
        /// </summary
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public DailyCollectionDealSummaryModel GetDailyCollectionDealSummary(DateTime? adviceDate, string dealName, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDailyCollectionDealSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", adviceDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).FirstOrDefault();
            }
        }


    }
}
