﻿using DocumentFormat.OpenXml.Spreadsheet;
using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.CW
{
    public class  DeflagAdjustmentDataService : Repository<PoolCashCollectionAdjustmentDataEntity>,IDeflagAdjustmentDataService
    {
        private IUnitOfWork _unitOfWork;
        public DeflagAdjustmentDataService()
        {
        }

        public DeflagAdjustmentDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        /// <summary>
        /// This will return the active deals details
        /// </summary
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
       
        public DataTable GetRepurchasePoolAdjustmentData()
       {
            DataTable dt = new DataTable();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDeflagPoolData;
                command.CommandType = CommandType.StoredProcedure;
                
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dt);
            }
            return dt;
        }

        
        public DataTable GetAdjustmentPoolData(int poolAdjustmentId)
        {
            DataTable dt = new DataTable();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDeflagAdjustmentPoolList;
                command.Parameters.Add(command.CreateParameter("@poolAdjustmentId", poolAdjustmentId));
                command.CommandType = CommandType.StoredProcedure;
               
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dt);
            }
            return dt;
        }
      

        public DataTable GetDeflagAdjustmentExcelData(int poolAdjustmentId, string userName)
        {
          
            DataTable dt = new DataTable();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDeflagAdjustmentData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pType", "DeFlag Data Breakup"));
                command.Parameters.Add(command.CreateParameter("@pPoolCashCollectionAdjustmentId", poolAdjustmentId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
              
                adapter.Fill(dt);
               
            }
         
            return dt;
        }

       
        public DataTable GetControlCheckData(int poolAdjustmentId, string userName)
        {
            DataTable dt = new DataTable();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDeflagAdjustmentData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pType", "Control Check"));
                command.Parameters.Add(command.CreateParameter("@pPoolCashCollectionAdjustmentId", poolAdjustmentId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                adapter.Fill(dt);
            }
            return dt;
        }

 public int ManageDeflagAdjustmentAuditAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Authorise)
            {
                authWorkflowEntity.WorkflowStep = (int)DeflagAdjustmentAuthorisation.Authorise;
            }
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Reject)
            {
                authWorkflowEntity.WorkflowStep = (int)DeflagAdjustmentAuthorisation.Reject;
            }
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDeflagAdjustment;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDailyCollectionSummaryId", authWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", authWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", authWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter("@pUserName", authWorkflowEntity.UserName));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }

        public int DeflagAdjustmentSentforAuthorization(DefalgAdjustmentEntity DefalgAdjustmentEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDeflagAdjustment;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pPoolCashCollectionAdjustmentId", DefalgAdjustmentEntity.PoolCashCollectionAdjustmentId));
                command.Parameters.Add(command.CreateParameter("@pAdjustmentProcessDate", DefalgAdjustmentEntity.AdjustmentProcessDate));                
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", DefalgAdjustmentEntity.WorkFlowStatusId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamAuthorizerComment, DefalgAdjustmentEntity.AuthorizerComment));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, DefalgAdjustmentEntity.UserName));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }
}
}



