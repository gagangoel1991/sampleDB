﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;

namespace NW.SFP.DataService.CW
{
   public class DealSummaryOutputDataService : Repository<DealSummaryDataEntity>, IDealSummaryOutputDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealSummaryOutputDataService()
        {

        }

        public DealSummaryOutputDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the active deals details
        /// </summary
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public List<DealSummaryDataEntity> GetDealSummaryOutputData(DataTable ListCollDate, string dealName, string dealCategoryName,string viewType, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealSummaryOutputData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pCollectionDates", ListCollDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealName, dealName));
                if (dealCategoryName.Length > 0)
                {
                    command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDailyCollectionCategory, dealCategoryName));
                }
                if(viewType.Length>0)
                {
                    command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamViewType, viewType));
                }
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, loggedInUser));
                return this.Execute(command).ToList();
            }
        }

        public int SaveDealSummayAdjustment(List<DealSummarySaveAdjustmentModel> dealSummarySaveAdjustmentModel, string loggedInUser)
        {
            
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDealSummayAdjustment;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAdjustmentLineItem", dealSummarySaveAdjustmentModel.ToDataTable()));                
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }


        /// <summary>
        /// This will return the active deals details
        /// </summary
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public List<DealSummaryDataEntity> GetDealSummaryAuditData(DataTable ListCollDate, string dealName,string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealSummaryAuditData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pCollectionDates", ListCollDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).ToList();
            }
        }


        public int SaveDealSummayAudit(DealSummarySaveAuditModel dealSummarySaveAuditModel, string loggedInUser)
        {

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDealSummayAudit;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDailyCollectionSummaryId", dealSummarySaveAuditModel.DailyCollectionSummaryId));
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", dealSummarySaveAuditModel.WorkFlowStepId));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", dealSummarySaveAuditModel.Comments));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }


        public int ManageDealSummaryAuditAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Authorise)
            {
                authWorkflowEntity.WorkflowStep = (int)DealDailyCollectionAuditAuthorisation.Authorise;
            }
            if (authWorkflowEntity.WorkflowStep == (int)AuthWorkflowStep.Reject)
            {
                authWorkflowEntity.WorkflowStep = (int)DealDailyCollectionAuditAuthorisation.Reject;
            }
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveDealSummayAudit;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDailyCollectionSummaryId", authWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pWorkFlowStepId", authWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter("@pAuthorizerComment", authWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter("@pUserName", authWorkflowEntity.UserName));

                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }

        public List<DateTime> GetCollectionDateList(DateTime? asAtDate, string dealName,string dateType, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                
                command.CommandText = CWDBConstants.SP_GetDealSummaryBusinessDateList;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", asAtDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealName, dealName));
                command.Parameters.Add(command.CreateParameter("@pDateType", dateType));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, UserName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }

                var collectionDateList = Utils.ConvertDataTable<DateTime>(dt);

                List<DateTime> testCollDateList = new List<DateTime>();

                foreach (DataRow row in dt.Rows)
                {
                    DateTime testDate = DateTime.Parse(row["AsAtDate"].ToString());
                    testCollDateList.Add(testDate);
                }
                return testCollDateList;
               
            }
        }


        public int GetLoadDailyEstimationDealSummary(string adviceDate, string dealName, bool isEstimationData,string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetLoadDailyEstimationDealSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", adviceDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pIsEstimationData", isEstimationData));
                
                IDbDataParameter returnCode = command.CreateOutputParameter("@pRetunCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
                
            }
        }

        public int GetLoadDeflagAdjustmentDealSummary(string adviceDate, string dealName, int isDeFlagAdjustment, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetLoadDailyEstimationDealSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", adviceDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pIsDeFlagAdjustment", isDeFlagAdjustment));


                IDbDataParameter returnCode = command.CreateOutputParameter("@pRetunCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);

            }
        }
        public List<bool> GetDealSummaryLoadDataEstimation(DataTable ListCollDate, string dealName, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealSummaryLoadDataEstimation;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pCollectionDates", ListCollDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));


                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }

                var collectionDateList = Utils.ConvertDataTable<DateTime>(dt);

                List<bool> testCollDateList = new List<bool>();

                foreach (DataRow row in dt.Rows)
                {
                    bool isEstimatedData =  Convert.ToBoolean( row["IsEstimationData"]);
                    testCollDateList.Add(isEstimatedData);
                }
                return testCollDateList;
            }
        }


        public int IsActualGMSDataAvaliable(string adviceDate, string dealName, bool isEstimationData, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_IsActualGMSDataAvaliable;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", adviceDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter("@pIsEstimationData", isEstimationData));


                IDbDataParameter returnCode = command.CreateOutputParameter("@pRetunCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);

            }
        }



    }
}
