﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.core;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using NW.SFP.Common;

namespace NW.SFP.DataService.CW
{
    public class DailyCashCollectionsDataService : Repository<DailyCashEstimationDataEntity>, IDailyCashCollectionsDataService
    {
        private IUnitOfWork _unitOfWork;

        public DailyCashCollectionsDataService()
        {

        }
        public DailyCashCollectionsDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public DataTable GetDailyCashEstimationData(string dealName, string asAtDate, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDailyCashEstimationData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", asAtDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DateTime GetCollectionDate(string asAtDate, string dealName, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBusinessDate;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamAsAtCollectionDate, asAtDate));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealName, dealName));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, UserName));
                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnBusinessDate", 0, DbType.Date, -1);
                command.Parameters.Add(returnCode);
                return this.ExecuteToEntity(command).CollectionDate;
                
            }
        }

        public DataTable GetDealCollectionHistoryData(DailyCollectionHistoryParam dailyCollectionHistParam, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                // Get value for User-defined table type
                var brandListParam = Utils.SetSelectListTableValues(dailyCollectionHistParam.BrandList);

                command.CommandText = CWDBConstants.SP_GetDailyCollectionHistory;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", dailyCollectionHistParam.AsAtDate));
                command.Parameters.Add(command.CreateParameter("@pAsAtToDate", dailyCollectionHistParam.AsAtToDate));
                command.Parameters.Add(command.CreateParameter("@pDealName", dailyCollectionHistParam.DealName));
                command.Parameters.Add(command.CreateParameter("@pBrandList", brandListParam));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetPNRSplitData(string asAtDate, string adviceDate, string dealName, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDailyCollectionPnRSplit;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", asAtDate));
                command.Parameters.Add(command.CreateParameter("@pAdviceDate", adviceDate));
                command.Parameters.Add(command.CreateParameter("@pdealName", dealName));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetDealDailyCollectionData(string asAtDate, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetDealDailyCollections;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", asAtDate));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetCBOutputData(DailyCollectionHistoryParam cbOutputParam, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetCBOutput;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAsStartDate", cbOutputParam.AsAtDate));
                command.Parameters.Add(command.CreateParameter("@pAsAtDate", cbOutputParam.AsAtToDate));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));

                 SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetEmailDataForCollectionOutput(string emailType, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetEmailDataForCollectionOutput;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pEmailTypeId", Convert.ToInt32(emailType)));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }
    }
}
