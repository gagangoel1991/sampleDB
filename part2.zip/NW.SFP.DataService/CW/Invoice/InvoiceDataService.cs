﻿namespace NW.SFP.DataService.CW
{
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using static NW.SFP.DataService.CW.CWDBConstants;

    public class InvoiceDataService : Repository<InvoiceDataEntity>, IInvoiceDataService
    {
        private IUnitOfWork _unitOfWork;

        public InvoiceDataService()
        {

        }

        public InvoiceDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// This will return the invoice data
        /// </summary>
        /// <param name="invoiceParams"></param>
        /// <param name="userName"></param>
        /// <returns></returns>
        public IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetInvoiceList;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", invoiceParams.DealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", invoiceParams.IPDRunId));
                if (invoiceParams.PaidStartDate.HasValue)
                    command.Parameters.Add(command.CreateParameter("@pPaidStartDate", invoiceParams.PaidStartDate.Value));
                else
                    command.Parameters.Add(command.CreateParameter("@pPaidStartDate", DBNull.Value));

                if (invoiceParams.PaidEndDate.HasValue)
                    command.Parameters.Add(command.CreateParameter("@pPaidEndDate", invoiceParams.PaidEndDate.Value));
                else
                    command.Parameters.Add(command.CreateParameter("@pPaidEndDate", DBNull.Value));

                if (invoiceParams.IPDDate.HasValue)
                    command.Parameters.Add(command.CreateParameter("@pIPDDate", invoiceParams.IPDDate.Value));
                else
                    command.Parameters.Add(command.CreateParameter("@pIPDDate", DBNull.Value));

                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                return this.Execute(command).ToList();
            }
        }

        /// <summary>
        /// This will return the single invoice record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public InvoiceDataEntity GetInvoice(int invoiceId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetInvoice;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pInvoiceId", invoiceId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).FirstOrDefault();
            }
        }

        /// <summary>
        /// Delete Invoice Record
        /// </summary>
        /// <param name="invoiceId"></param>
        /// <returns></returns>
        public int DeleteInvoiceData(int invoiceId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_DeleteInvoiceData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pInvoiceId", invoiceId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                return this.ExecuteNonQuery(command);
            }
        }

        /// <summary>
        /// Save Invoice Record
        /// </summary>
        /// <param name="invoiceData"></param>
        /// <returns></returns>
        public int SaveInvoiceData(InvoiceDataEntity invoiceData, string loggedInUserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveInvoiceData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pInvoiceId", invoiceData.InvoiceId));
                command.Parameters.Add(command.CreateParameter("@pDealId", invoiceData.DealId));
                command.Parameters.Add(command.CreateParameter("@pName", invoiceData.Name));
                command.Parameters.Add(command.CreateParameter("@pInvoiceCategoryTypeId", invoiceData.InvoiceCategoryTypeId));
                command.Parameters.Add(command.CreateParameter("@pInvoiceCategoryId", invoiceData.InvoiceCategoryId));
                command.Parameters.Add(command.CreateParameter("@pDealCounterpartyId", invoiceData.DealCounterpartyId));
                command.Parameters.Add(command.CreateParameter("@pDescription", invoiceData.Description ?? string.Empty));
                command.Parameters.Add(command.CreateParameter("@pAmount", invoiceData.Amount));
                command.Parameters.Add(command.CreateParameter("@pPaidDate", invoiceData.PaidDate));
                command.Parameters.Add(command.CreateParameter("@pDealIpdDate", invoiceData.DealIpdDate));
                command.Parameters.Add(command.CreateParameter("@pUploadedFileName", invoiceData.UploadedFileName));
                command.Parameters.Add(command.CreateParameter("@pOriginalFileName", invoiceData.OriginalFileName));
                command.Parameters.Add(command.CreateParameter("@pReferenceNumber", invoiceData.ReferenceNumber));
                command.Parameters.Add(command.CreateParameter("@pSourceSpotRate", invoiceData.SourceSpotRate));
                command.Parameters.Add(command.CreateParameter("@pSpotRate", invoiceData.SpotRate));
                command.Parameters.Add(command.CreateParameter("@pInvoicePaidAmount", invoiceData.InvoicePaidAmount));
                command.Parameters.Add(command.CreateParameter("@pInvoiceDate", invoiceData.InvoiceDate));
                command.Parameters.Add(command.CreateParameter("@pInvoiceCurrencyId", invoiceData.InvoiceCurrencyId));
                command.Parameters.Add(command.CreateParameter("@pSpotRateDate", invoiceData.SpotRateDate));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUserName));
                command.Parameters.Add(command.CreateParameter("@pResult", 0));
                command.Parameters["@pResult"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);

                return Utility.GetInt(command.Parameters["@pResult"].Value);
            }
        }

        public IList<InvoiceDataEntity> GetInvoiceIpdData(IPDFeedParam iPDFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetInvoiceIpdData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, iPDFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, iPDFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, iPDFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSpotRate;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, dealId));
                command.Parameters.Add(command.CreateParameter("@pInvoiceCurrencyId", invoiceCurrencyId));
                command.Parameters.Add(command.CreateParameter("@pSpotRateDate", spotRateDate));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));

                var spotparameter = command.CreateParameter();
                spotparameter.ParameterName = "@pSpotRate";
                spotparameter.DbType = DbType.Decimal;
                spotparameter.Precision = 18;
                spotparameter.Scale = 4;
                spotparameter.Direction = ParameterDirection.Output;

                command.Parameters.Add(spotparameter);
                this.ExecuteNonQuery(command);
                if (spotparameter.Value == DBNull.Value)
                {
                    return null;
                }
                else
                {
                    return Convert.ToDecimal(spotparameter.Value);
                }
               
                
            }
        }
    }
}
