﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.DataService.CW.CB
{
    public class BookingIPDDataService : Repository<BookingEntity>, IBookingIPDDataService
    {
        private IUnitOfWork _unitOfWork;

        public BookingIPDDataService()
        {

        }

        public BookingIPDDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<BookingEntity> GetBookingsIPDData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingsIPDData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public DataTable GetBookingNwbFoFeesData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingsNWBFoFeeData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetBookingNwbFoLdData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingsNWBFoLdData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetBookingLLPMoFeesData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingsLLPMoFeeData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetBookingLoansAndDepositsData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingLoanAndDepositsData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetBookingSwapSummaryData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingsSwapSummaryData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetBookingReconData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingsReconLineItemData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }

        public DataTable GetBookingReconAnalysisTabData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingReconAnalysisTabData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pPreviewAnalysisData", "Yes"));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }
                return dt;
            }
        }


        public bool ProcessBookingData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_ReProcessBookingsData;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));

                IDbDataParameter ReturnCode = command.CreateOutputParameter(CWDBConstants.DbProcParamResultCode, 0, DbType.Int32, 0);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToBoolean(ReturnCode.Value);
                
            }
        }

    }
}
