﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.DataService.CW.CB
{
    public class BondSwapDataService : Repository<BondSwapEntity>, IBondSwapDataService
    {
        private IUnitOfWork _unitOfWork;

        public BondSwapDataService()
        {

        }

        public BondSwapDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<BondSwapEntity> GetBondSwapData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBondSwapData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }
    }
}
