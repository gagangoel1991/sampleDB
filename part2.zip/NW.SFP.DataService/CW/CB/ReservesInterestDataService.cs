﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.CB
{
    public class ReservesInterestDataService : Repository<ReservesEntity>, IReservesInterestDataService
    {

        private IUnitOfWork _unitOfWork;

        public ReservesInterestDataService()
        {

        }

        public ReservesInterestDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<ReservesEntity> GetReservesData(int DealIpdRunId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetReservesData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", DealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));
                return this.Execute(command).ToList();
            }
        }
        public Decimal GetReserveFinalRequiredAmount(int DealIpdRunId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetReserveFinalRequiredAmount;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", DealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));                

                var parameter = command.CreateParameter();
                parameter.ParameterName = "@pFinalRequiredAmount";
                parameter.DbType = DbType.Decimal;
                parameter.Precision = 38;
                parameter.Scale = 16;
                parameter.Direction = ParameterDirection.Output;

                command.Parameters.Add(parameter);
                this.ExecuteNonQuery(command);
                return Convert.ToDecimal(parameter.Value);

            }
        }
    }
}
