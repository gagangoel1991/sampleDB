﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.DataService.CW.CB
{
    public class BookingDataService : Repository<BookingTradesEntity>, IBookingDataService
    {

        private IUnitOfWork _unitOfWork;

        public BookingDataService()
        {

        }

        public BookingDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<BookingTradesEntity> GetBookingTabData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetBookingTradesData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(CWDBConstants.DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

    }
}
