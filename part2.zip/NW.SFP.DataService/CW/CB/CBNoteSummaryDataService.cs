﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.CB
{
    public class CBNoteSummaryDataService : Repository<CBNoteEntity>, ICBNoteSummaryDataService
    {

        private IUnitOfWork _unitOfWork;

        public CBNoteSummaryDataService()
        {

        }

        public CBNoteSummaryDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public CBNoteSummary GetNoteSummary(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCBNoteSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                CBNoteSummary noteSummary = new CBNoteSummary();
                noteSummary.CBNoteList = this.Execute(command).ToList();
                noteSummary.CBNoteStaticAttributeList = GetCBNoteStaticAttributes(ipdFeedParam);
                return noteSummary;
            }
        }


        private List<CBNoteStaticAttribute> GetCBNoteStaticAttributes(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCBNoteStaticAttributes;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                adapter.Fill(ds);
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                    {
                        dt = null;
                        return new List<CBNoteStaticAttribute>();
                    }
                }

                var noteStaticAttributes = dt.AsEnumerable().Select(row =>
                 new CBNoteStaticAttribute
                 {
                     IPDDate = row.Field<string>("IPDDate"),
                     DealNoteId = row.Field<int?>("DealNoteId"),
                     DealNote = row.Field<string>("DealNote"),
                     ISIN = row.Field<string>("ISIN"),
                     IssuanceAmount = row.Field<decimal?>("IssuanceAmount"),
                     IssuanceAmount_GBP = row.Field<decimal?>("IssuanceAmount_GBP"),
                     MaturityDate = row.Field<DateTime>("MaturityDate"),
                     Margin = row.Field<decimal?>("Margin"),
                     RateType = row.Field<string>("RateType"),
                     ExtendedMaturitySeries = row.Field<string>("ExtendedCoveredBond"),
                     HardBulletSeries = row.Field<string>("HardBulletSeries"),
                     IsSwapLinked = row.Field<string>("IsSwapLinked"),
                     Currency = row.Field<string>("Currency")
                 }).ToList();

                return noteStaticAttributes;
            }
        }
    }
}
