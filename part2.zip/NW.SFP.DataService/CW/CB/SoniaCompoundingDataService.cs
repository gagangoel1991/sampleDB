﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core; 
using NW.SFP.Interface.CW.CB; 
using NW.SFP.Message.CB; 
using System;
using System.Collections.Generic;
using System.Data;
using System.Dynamic;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.CB
{
    public class SoniaCompoundingDataService : Repository<SoniaCompoundingSummaryEntity>, ISoniaCompoundingDataService
    {

        private IUnitOfWork _unitOfWork;

        public SoniaCompoundingDataService()
        {

        }

        public SoniaCompoundingDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<SoniaCompoundingSummaryEntity> GetSoniaCompoundingSummary(int dealId, int ipdRunId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSoniaCompoundingSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, dealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, UserName));
                return this.Execute(command).ToList();
            }   
        }

        public List<dynamic> GetSoniaCompoundingData(DateTime accrualStartDate, DateTime accrualEndDate, string UserName)
        {
            DataTable dt = new DataTable();
            var dynamicDt = new List<dynamic>();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSoniaCompoundingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamAccrualStartDate, accrualStartDate));
                command.Parameters.Add(command.CreateParameter(DbProcParamAccrualEndDate, accrualEndDate));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, UserName));
                dt.Load(command.ExecuteReader());

                foreach (DataRow row in dt.Rows)
                {
                    dynamic dyn = new ExpandoObject();
                    dynamicDt.Add(dyn);
                    foreach (DataColumn column in dt.Columns)
                    {
                        var dic = (IDictionary<string, object>)dyn;
                        var col = column.ColumnName;
                        dic.Add(col, row[column]);
                    }
                }
                return dynamicDt;
            }
        }
    }
}
