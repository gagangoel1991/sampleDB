﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class CashLadderDataService : Repository<CashLadderEntity>, ICashLadderDataService
    {

        private IUnitOfWork _unitOfWork;

        public CashLadderDataService()
        {

        }

        public CashLadderDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        /// this will return cash ladder data
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public CashLadder GetCashLadderData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCashLadderData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                CashLadder cashLadder = new CashLadder();
                cashLadder.CashLadderList = this.Execute(command).ToList();
                cashLadder.WipCashLadderList = GetWIPWipCashLadderList(ipdFeedParam);

                return cashLadder;
            }
        }

        private List<CashLadderEntity> GetWIPWipCashLadderList(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetWIPCashLadderData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public int SaveCashLadderData(UpdateCashLadderEntity objUpdateCashLadderEntity, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveCashLadderData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamCashLadderId, objUpdateCashLadderEntity.CashLadderId));
                command.Parameters.Add(command.CreateParameter(DbProcParamCashRate, objUpdateCashLadderEntity.Rate));                
                command.Parameters.Add(command.CreateParameter(DbProcParamInflowAmount, objUpdateCashLadderEntity.InflowAmount));
                command.Parameters.Add(command.CreateParameter(DbProcParamOutflowAmount, objUpdateCashLadderEntity.OutflowAmount));
                command.Parameters.Add(command.CreateParameter(DbProcParamFlowSubTotal, objUpdateCashLadderEntity.FlowSubTotal));
                command.Parameters.Add(command.CreateParameter(DbProcParamReason, objUpdateCashLadderEntity.Reason));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, objUpdateCashLadderEntity.DealIpdRunId));
                return this.ExecuteNonQuery(command);
            }
        }
    }
}
