﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class CounterpartyRatingDataService : Repository<CounterpartyRatingEntity>, ICounterpartyRatingDataService
    {

        private IUnitOfWork _unitOfWork;

        public CounterpartyRatingDataService()
        {

        }

        public CounterpartyRatingDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public CounterpartyRatingEntity GetCounterpartyRatingData(IPDFeedParam ipdFeedParam)
        {
            CounterpartyRatingEntity cpRatingList = new CounterpartyRatingEntity();
            DataTable dt = new DataTable();
            var dynamicDt = new List<dynamic>();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCounterPartyRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                using (var reader = command.ExecuteReader())
                {
                    dt.Load(reader);
                }
                foreach (DataRow row in dt.Rows)
                {
                    dynamic dyn = new ExpandoObject();
                    dynamicDt.Add(dyn);
                    foreach (DataColumn column in dt.Columns)
                    {
                        var dic = (IDictionary<string, object>)dyn;
                        var col = column.ColumnName;
                        dic.Add(col, row[column]);
                    }
                }
            }
            cpRatingList.CounterpartyRatingData = dynamicDt;
            cpRatingList.SourceCounterpartyRatingData = GetSourceCounterpartyRating(ipdFeedParam);
            cpRatingList.CisCodes = GetCisCodes(ipdFeedParam);
            return cpRatingList;
        }

        public int SaveCounterpartyRatingData(dynamic cpRatingEntity, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                var dt = ConvertToDataTable(cpRatingEntity);
                SqlParameter parameter = command.Parameters.AddWithValue(DbProcParamSourceBondRatingKeyValue, dt);
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.TypeName = Type_KeyValueArray;
                command.CommandText = SP_SaveCPRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                return this.ExecuteNonQuery(command);
            }
        }

        public int ResetCounterpartyRatingData(int ipdRunId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetModifiedAutomatedData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkflowType", Enum.GetName(typeof(Rating), Rating.Automated_Data_CPRating)));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                return this.ExecuteNonQuery(command);
            }
        }

        private static DataTable ConvertToDataTable(dynamic dict)
        {
            var dt = new DataTable();
            dt.Columns.Add("Key", typeof(string));
            dt.Columns.Add("Value", typeof(string));
            foreach (var pair in dict)
            {
                var row = dt.NewRow();
                row["Key"] = pair.Name;
                row["Value"] = pair.Value;
                dt.Rows.Add(row);
            }
            return dt;
        }

        private List<string> GetCisCodes(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCisCodes;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).Select(x => x.CisCode).ToList();
            }
        }


        private List<dynamic> GetSourceCounterpartyRating(IPDFeedParam ipdFeedParam)
        {
            DataTable dt = new DataTable();
            var sourceCounterpartyRating = new List<dynamic>();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSourceCounterPartyRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                using (var reader = command.ExecuteReader())
                {
                    dt.Load(reader);
                }

                foreach (DataRow row in dt.Rows)
                {
                    dynamic dyn = new ExpandoObject();
                    sourceCounterpartyRating.Add(dyn);
                    foreach (DataColumn column in dt.Columns)
                    {
                        var dic = (IDictionary<string, object>)dyn;
                        var col = column.ColumnName;
                        dic.Add(col, row[column]);
                    }
                }
            }
            return sourceCounterpartyRating;
        }

        public bool IsCPRatingEdited(int ipdRunId, string loggedInUser)
        {
            var isEdited = false;
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetRatingsStatus;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdRunId));
                command.Parameters.Add(command.CreateParameter("@pRatingType", "CPRating"));
                command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                var result = Utility.GetInt(command.Parameters["@pResultCode"].Value);
                if (result == 1)
                {
                    isEdited = true;
                }
                return isEdited;
            }
        }
    }
}
