﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class ManualFieldDataService : Repository<ManualFieldEntity>, IManualFieldDataService
    {

        private IUnitOfWork _unitOfWork;

        public ManualFieldDataService()
        {

        }

        public ManualFieldDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<ManualFieldEntity> GetManualFieldData(int DealIpdRunId, int mfGrouptypeId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetManualFieldData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", DealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pManualFieldGroupTypeId", mfGrouptypeId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));
                return this.Execute(command).ToList();
            }
        }


        public int UpdateManualFieldData(List<ManualFieldKeyValue> ManualFieldKeyValue,int mfGrouptypeId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                //var dt = ConvertToDataTable(manualFieldsEntity);

                SqlParameter parameter = command.Parameters.AddWithValue("@pManualFieldsKeyValue", ManualFieldKeyValue.ToDataTable());
           //     SqlParameter parameter = command.Parameters.AddWithValue("@pManualFieldsKeyValue", ManualFieldKeyValue.ToDataTable());
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.TypeName = Type_KeyValueArray;

                command.Parameters.Add(command.CreateParameter("@pManualFieldGroupTypeId", mfGrouptypeId));

                command.CommandText = SP_UpdateManualFieldData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, UserName));
                return this.ExecuteNonQuery(command);
            }
        }

        public int ResetManualFieldData(int DealIpdRunId, int mfGrouptypeId, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetManualFieldData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", DealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pManualFieldGroupTypeId", mfGrouptypeId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));
                return this.ExecuteNonQuery(command);
            }
        }

        public int ResetManualFieldDealSwapData(int DealIpdRunId,int mfGrouptypeId ,string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetManualFieldDealSwapData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", DealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pManualFieldGroupTypeId", mfGrouptypeId));
                command.Parameters.Add(command.CreateParameter("@pUserName", UserName));
                return this.ExecuteNonQuery(command);
            }
        }
    }
}
