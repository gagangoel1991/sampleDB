﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Dynamic;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class BondRatingDataService : Repository<BondRatingEntity>, IBondRatingDataService
    {

        private IUnitOfWork _unitOfWork;

        public BondRatingDataService()
        {

        }

        public BondRatingDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public BondRating GetBondRatingData(IPDFeedParam ipdFeedParam)
        {
            BondRating bondRatingList = new BondRating();
            DataTable dt = new DataTable();
            var dynamicDt = new List<dynamic>();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ParentGetBondRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                dt.Load(command.ExecuteReader());

                foreach (DataRow row in dt.Rows)
                {
                    dynamic dyn = new ExpandoObject();
                    dynamicDt.Add(dyn);
                    foreach (DataColumn column in dt.Columns)
                    {
                        var dic = (IDictionary<string, object>)dyn;
                        var col = column.ColumnName;
                        dic.Add(col, row[column]);
                    }
                }
            }
            bondRatingList.BondRatingData = dynamicDt;
            bondRatingList.SourceBondRatingData = GetSourceBondRating(ipdFeedParam);
            bondRatingList.ISINs = GetISINs(ipdFeedParam);
            return bondRatingList;
        }

        public int SaveBondRatingData(dynamic bondRatingEntity, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                var dt = ConvertToDataTable(bondRatingEntity);


                SqlParameter parameter = command.Parameters.AddWithValue(DbProcParamSourceBondRatingKeyValue, dt);
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.TypeName = Type_KeyValueArray;

                command.CommandText = SP_SaveBondRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                return this.ExecuteNonQuery(command);
            }
        }

        public int ResetBondRatingData(int ipdRunId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetModifiedAutomatedData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkflowType", Enum.GetName(typeof(Rating), Rating.Automated_Data_Bond_Rating)));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                return this.ExecuteNonQuery(command);
            }
        }

        private static DataTable ConvertToDataTable(dynamic dict)
        {
            var dt = new DataTable();
            dt.Columns.Add("Key", typeof(string));
            dt.Columns.Add("Value", typeof(string));
            foreach (var pair in dict)
            {
                var row = dt.NewRow();
                row["Key"] = pair.Name;
                row["Value"] = pair.Value;
                dt.Rows.Add(row);
            }
            return dt;
        }

        private List<string> GetISINs(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetISINs;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).Select(x => x.ISIN).ToList();
            }
        }

        private List<dynamic> GetSourceBondRating(IPDFeedParam ipdFeedParam)
        {
            DataTable dt = new DataTable();
            var sourceBondRating = new List<dynamic>();
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ParentGetSourceBondRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                dt.Load(command.ExecuteReader());

                foreach (DataRow row in dt.Rows)
                {
                    dynamic dyn = new ExpandoObject();
                    sourceBondRating.Add(dyn);
                    foreach (DataColumn column in dt.Columns)
                    {
                        var dic = (IDictionary<string, object>)dyn;
                        var col = column.ColumnName;
                        dic.Add(col, row[column]);
                    }
                }
            }
            return sourceBondRating;
        }

        public bool IsBondRatingEdited(int ipdRunId, string loggedInUser)
        {
            var isEdited = false;
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetRatingsStatus;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdRunId));
                command.Parameters.Add(command.CreateParameter("@pRatingType", "BondRating"));
                command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                var result = Utility.GetInt(command.Parameters["@pResultCode"].Value);
                if (result == 1)
                {
                    isEdited = true;
                }
                return isEdited;
            }
        }
    }
}
