﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Data;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class IpdAuthWorkflowDataService : Repository<IpdWorkflowEntity>, IIpdAuthWorkflowDataService
    {
        private IUnitOfWork _unitOfWork;

        public IpdAuthWorkflowDataService()
        {

        }

        public IpdAuthWorkflowDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IpdWorkflowEntity GetIpdAuthWorkflowStatus(IpdWorkflowEntity ipdWorkflowEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetIpdAuthWorkflowStatus;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdWorkflowEntity.UserName));
                return this.ExecuteToEntity(command);
            }
        }

        public int ManageIpdAuthWorkflow(IpdWorkflowEntity ipdWorkflowEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ManageIpdAuthWorkflow;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pStepName", Enum.GetName(typeof(AuthWorkflowStep), ipdWorkflowEntity.WorkflowStep)));
                command.Parameters.Add(command.CreateParameter("@pComment", ipdWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter("@pOutput", 0));
                command.Parameters["@pOutput"].Direction = ParameterDirection.Output;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdWorkflowEntity.UserName));
                this.ExecuteNonQuery(command);
                return Utility.GetInt(command.Parameters["@pOutput"].Value);
            }
        }

        public int ValidateIPD(int dealIpdRunId, int workFlowStep, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ValidateIPD;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", dealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pStepName", Enum.GetName(typeof(AuthWorkflowStep), workFlowStep)));
                command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));
                command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                return Utility.GetInt(command.Parameters["@pResultCode"].Value);
            }
        }
    }
}
