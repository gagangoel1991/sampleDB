﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
   public class DealConditionTestDataService : Repository<DealConditionTestEntity>, IDealConditionTestDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealConditionTestDataService()
        {

        }

        public DealConditionTestDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<DealConditionTestEntity> GetDealConditionTestData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDealConditionTestData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                var result = this.Execute(command).ToList();
                return result;
            }
        }

        public int SaveDealConditionTestData(DealConditionTestEntity dealConditionTestEntity, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveDealConditionTestData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdConditionTestId", dealConditionTestEntity.Id));
                command.Parameters.Add(command.CreateParameter("@pLoanAmount", dealConditionTestEntity.Amount));
                command.Parameters.Add(command.CreateParameter("@pRepurchaseAmount", dealConditionTestEntity.RepurchaseAmount));
                command.Parameters.Add(command.CreateParameter("@pComment", dealConditionTestEntity.Comment));
                command.Parameters.Add(command.CreateParameter("@pNumber", dealConditionTestEntity.Number));
                command.Parameters.Add(command.CreateParameter("@pPreviousRepurchaseDate", dealConditionTestEntity.PreviousRepurchaseDate));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));

                var result = this.ExecuteNonQuery(command);
                return result;
            }
        }

    }
}
