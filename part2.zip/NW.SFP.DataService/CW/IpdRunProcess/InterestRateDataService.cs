﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class InterestRateDataService : Repository<InterestRateEntity>, IInterestRateDataService
    {
        private IUnitOfWork _unitOfWork;

        public InterestRateDataService()
        {

        }

        public InterestRateDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public InterestRate GetInterestRateData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetInterestRateData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                InterestRate interestRate = new InterestRate();
                interestRate.InterestRateList = this.Execute(command).ToList();
                interestRate.SourceInterestRateList = GeSourceInterestRateData(ipdFeedParam);
                return interestRate;
            }
        }

        public int SaveInterestRate(InterestRateEntity interestRateEntity, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveInterestRate;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamInterestRateId, interestRateEntity.InterestRateId));
                command.Parameters.Add(command.CreateParameter(DbProcParamInterestRate, interestRateEntity.InterestRate));
                command.Parameters.Add(command.CreateParameter(DbProcParamReason, interestRateEntity.Reason));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, interestRateEntity.DealIpdRunId));
                return this.ExecuteNonQuery(command);
            }
        }

        private List<InterestRateEntity> GeSourceInterestRateData(IPDFeedParam ipdFeedParam)

        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSourceInterestRateData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }
    }
}
