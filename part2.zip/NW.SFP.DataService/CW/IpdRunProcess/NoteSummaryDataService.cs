﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class NoteSummaryDataService : Repository<DealNoteEntity>, INoteSummaryDataService
    {

        private IUnitOfWork _unitOfWork;

        public NoteSummaryDataService()
        {

        }

        public NoteSummaryDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public DealNoteSummary GetDealNoteSummary(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetNoteSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                DealNoteSummary dealNoteSummary = new DealNoteSummary();
                dealNoteSummary.DealNoteList = this.Execute(command).ToList();
                dealNoteSummary.DealNoteStaticAttributeList = GetDealNoteStaticAttributes(ipdFeedParam);
                return dealNoteSummary;
            }
        }


        private List<DealNoteStaticAttribute> GetDealNoteStaticAttributes(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetNoteStaticAttributes;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                adapter.Fill(ds);
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                    {
                        dt = null;
                        return new List<DealNoteStaticAttribute>();
                    }
                }

                var dealNoteStaticAttributes = dt.AsEnumerable().Select(row =>
                 new DealNoteStaticAttribute
                 {
                     DealNoteId = row.Field<int?>("DealNoteId"),
                     DealNote = row.Field<string>("DealNote"),
                     ISIN = row.Field<string>("ISIN"),
                     IssuanceAmount = row.Field<decimal?>("IssuanceAmount"),
                     MaturityDate = row.Field<DateTime?>("MaturityDate"),
                     Margin = row.Field<decimal?>("Margin"),
                     RateType = row.Field<string>("RateType"),
                     CouponFloor = row.Field<decimal?>("CouponFloor")
                 }).ToList();

                return dealNoteStaticAttributes;
            }
        }
    }
}
