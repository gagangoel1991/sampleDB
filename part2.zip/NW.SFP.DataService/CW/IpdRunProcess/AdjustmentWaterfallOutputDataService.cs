﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class AdjustmentWaterfallOutputDataService : Repository<AdjustmentOutputEntity>, IAdjustmentWaterfallOutputDataService
    {
        private IUnitOfWork _unitOfWork;

        public AdjustmentWaterfallOutputDataService()
        {

        }

        public AdjustmentWaterfallOutputDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IList<AdjustmentOutputEntity> GetAdjustmentPppOutputData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetPrincipalWaterfall;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public IList<AdjustmentOutputEntity> GetAdjustmentRppOutputData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetRevenueWaterfall;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }
    }
}
