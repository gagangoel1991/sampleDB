﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.IpdRunProcess
{
    public class IpdProcessParentDataService : Repository<DealIpdBasicInfoEntity>, IIpdProcessParentDataService
    {
        private IUnitOfWork _unitOfWork;

        public IpdProcessParentDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public DealIpdBasicInfoEntity GetIpdProcessParentData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetIpdProcessParentData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdFeedParam.IPDRunId));
                return this.ExecuteToEntity(command);
            }
        }

        public int RunIPD(int dealIpdRunId, string userName)
        {
            var result = this.Validate(dealIpdRunId, userName);
            if (result == (int)IPDValidationEnum.Success)
            {
                using (var command = this._unitOfWork.CreateCommand())
                {
                    command.CommandText = SP_RunCashWaterfall;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", dealIpdRunId));
                    command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                    command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));
                    command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                    this.ExecuteNonQuery(command);
                    return Utility.GetInt(command.Parameters["@pResultCode"].Value);
                }
            }
            else
                return result;
        }

        private int Validate(int dealIpdRunId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_RunIPDValidatation;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", dealIpdRunId));
                command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));
                command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                return Utility.GetInt(command.Parameters["@pResultCode"].Value);
            }
        }

        public int InitiateIPD(int dealId, DateTime ipdDate, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_InitiateIpd;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pIpdDate", ipdDate));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));
                command.Parameters.Add(command.CreateParameter("@pAuthStepName", "Initiate"));
                command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                return Utility.GetInt(command.Parameters["@pResultCode"].Value);
            }
        }

        public int ResetIPD(int dealId, DateTime ipdDate, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetDealIpd;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pIpdDate", ipdDate));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));
                command.Parameters.Add(command.CreateParameter("@pResultCode", 0));
                command.Parameters["@pResultCode"].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                return Utility.GetInt(command.Parameters["@pResultCode"].Value);
            }
        }

        public int WithdrawIPD(IpdWorkflowEntity ipdWorkflowEntity, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_WithdrawIpd;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamComment, ipdWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, userName));
                command.Parameters.Add(command.CreateParameter(DbProcParamResultCode, 0));
                command.Parameters[DbProcParamResultCode].Direction = ParameterDirection.Output;
                this.ExecuteNonQuery(command);
                return Utility.GetInt(command.Parameters[DbProcParamResultCode].Value);
            }
        }

        public int SaveOverridedIRFile(OverrideIrEntity overrideIREntity, string UserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveOverridedIRFile;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, overrideIREntity.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, overrideIREntity.IpdRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamComment, overrideIREntity.Comment));

                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, UserName));

                IDbDataParameter ReturnCode = command.CreateOutputParameter(DbProcParamResultCode, 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToInt32(ReturnCode.Value);
            }
        }
    }
}