﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class CreditRatingDataService : Repository<CreditRatingEntity>, ICreditRatingDataService
    {
        private IUnitOfWork _unitOfWork;

        public CreditRatingDataService()
        {

        }

        public CreditRatingDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IList<CreditRatingEntity> GetCreditRatings(string loggedInUserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCreditRating;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUserName));
                return this.Execute(command).ToList();
            }
        }
    }
}
