﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.IpdRunProcess
{
   public class PostWaterfallDataService : Repository<PostWaterfallEntity>, IPostWaterfallDataService
    {

        private IUnitOfWork _unitOfWork;

        public PostWaterfallDataService()
        {

        }

        public PostWaterfallDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<PostWaterfallEntity> PostWaterfallOutputFileData()
        {
            List<PostWaterfallEntity> objPostWaterfallOutputFileDataEntity = new List<PostWaterfallEntity>();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_PostWaterfallOutPutFileData;
                command.CommandType = CommandType.StoredProcedure;



                objPostWaterfallOutputFileDataEntity = this.Execute(command).ToList();

                return objPostWaterfallOutputFileDataEntity;
            }
        }

    }
}
