﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class CollectionLedgerDataService : Repository<CollectionLedgerEntity>, ICollectionLedgerDataService
    {
        private IUnitOfWork _unitOfWork;

        public CollectionLedgerDataService()
        {

        }

        public CollectionLedgerDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public CollectionLedger GetCollectionLedgerData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetCollectionLedgerData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                CollectionLedger collectionLedger = new CollectionLedger();
                collectionLedger.CollectionLedgerList = this.Execute(command).ToList();
                collectionLedger.WipCollectionLedgerList = GetWIPCollectionLedgerData(ipdFeedParam);
                return collectionLedger;
            }
        }

        private List<CollectionLedgerEntity> GetWIPCollectionLedgerData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetWIPCollectionLedgerData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public int UpdateCollectionLedgerData(UpdateCollectionLedgerEntity objUpdateCollectionLedgerEntity, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveCollectionLedgerData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pCollectionLedgerId", objUpdateCollectionLedgerEntity.CollectionLedgerId));
                command.Parameters.Add(command.CreateParameter("@pNetPrincipalCollections", objUpdateCollectionLedgerEntity.NetPrincipalCollections));
                command.Parameters.Add(command.CreateParameter("@pFinanceCollections", objUpdateCollectionLedgerEntity.FinanceCollections));
                command.Parameters.Add(command.CreateParameter("@pOtherCollections", objUpdateCollectionLedgerEntity.OtherCollections));
                command.Parameters.Add(command.CreateParameter("@pTotalDailyCashAmount", objUpdateCollectionLedgerEntity.TotalDailyCashAmount));
                command.Parameters.Add(command.CreateParameter("@pReason", objUpdateCollectionLedgerEntity.Reason));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, objUpdateCollectionLedgerEntity.DealIpdRunId));
                return this.ExecuteNonQuery(command);
            }
        }
    }
}
