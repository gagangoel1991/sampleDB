﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class NonRatingTriggerDataService : Repository<NonRatingTriggerEntity>, INonRatingTriggerDataService
    {
        private IUnitOfWork _unitOfWork;

        public NonRatingTriggerDataService()
        {

        }

        public NonRatingTriggerDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<NonRatingTriggerEntity> GetNonRatingTriggers(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetNonRatingTriggers;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                var result = this.Execute(command).ToList();
                return result;
            }
        }



        public int SaveNonRatingTrigger(NonRatingTriggerEntity nonRatingTriggerEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveNonRatingTrigger;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealIpdTriggerResultId", nonRatingTriggerEntity.Id));
                command.Parameters.Add(command.CreateParameter("@pIsBreached", nonRatingTriggerEntity.IsBreached));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, nonRatingTriggerEntity.UserName));
                var result = this.ExecuteNonQuery(command);
                return result;
            }
        }

        public int ResetNontRatingTrigger(int dealId, int ipdRunId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetNonRatingTrigger;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, dealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                var result = this.ExecuteNonQuery(command);
                return result;
            }
        }

        public int ResetTriggersConditions(int ipdRunId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ResetTriggersConditions;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, loggedInUser));
                var result = this.ExecuteNonQuery(command);
                return result;
            }
        }
    }
}
