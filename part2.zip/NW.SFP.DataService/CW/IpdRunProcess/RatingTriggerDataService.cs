﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class RatingTriggerDataService : Repository<RatingTriggerEntity>, IRatingTriggerDataService
    {
        private IUnitOfWork _unitOfWork;

        public RatingTriggerDataService()
        {

        }

        public RatingTriggerDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public List<RatingTriggerEntity> GetRatingTriggers(IPDFeedParam ipdFeedParam)
        {

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetRatingTriggers;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                var result = this.Execute(command).ToList();
                return result;
            }
        }

        public List<RatingTriggerEntity> GetSwapRatingTriggers(IPDFeedParam ipdFeedParam)
        {

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSwapRatingTriggers;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                var result = this.Execute(command).ToList();
                return result;
            }
        }
    }
}
