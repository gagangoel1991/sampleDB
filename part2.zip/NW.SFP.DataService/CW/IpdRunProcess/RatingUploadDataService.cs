﻿using NW.SFP.DataService.Core;
using NW.SFP.Message.CW.IpdRunProcess;
using NW.SFP.Interface.CW.DataService;
using System;
using System.Collections.Generic;
using System.Text;
using NW.SFP.Interface.Core;
using System.Data;
using System.Linq;
using System.Data.SqlClient;
using System.Data.Common;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.IpdRunProcess
{
    public class RatingUploadDataService : Repository<RatingUploadEntity>, IRatingUploadDataService
    {
        private IUnitOfWork _unitOfWork;

        public RatingUploadDataService()
        {

        }

        public RatingUploadDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IList<DealIpdDateEntity> GetDealIpdDates()
        {
            IList<DealIpdDateEntity> objDealIpdDateEntity = new List<DealIpdDateEntity>();
            DataTable dt = new DataTable();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDealNextColEndDate;
                command.CommandType = CommandType.StoredProcedure;
                dt.Load(command.ExecuteReader());

                objDealIpdDateEntity = dt.AsEnumerable().Select(row => new DealIpdDateEntity
                {
                    DealId = Convert.ToInt32(row.Field<Int16>(0)),
                    DealName = row.Field<string>(1),
                    IpdDate = row.Field<DateTime>(2)
                }).ToList();

            }
            return objDealIpdDateEntity;
        }

        public IList<RatingMasterData> GetRatingMasterData(int DealId)
        {
            IList<RatingMasterData> objRatingMasterDataList = new List<RatingMasterData>();
            DataTable dt = new DataTable();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetRatingMasterData;
                command.CommandType = CommandType.StoredProcedure;


                command.Parameters.Add(command.CreateParameter("@DealId", DealId));

                dt.Load(command.ExecuteReader());
                objRatingMasterDataList = dt.AsEnumerable().Select(row => new RatingMasterData
                {
                    UniqueIdentifier = Convert.ToString(row["UniqueIdentifier"]),
                    Type = Convert.ToString(row["Type"]),
                    CRA = Convert.ToString(row["CRA"]),
                    Rating = Convert.ToString(row["Rating"]),
                    RatingType = Convert.ToString(row["RatingType"])
                }).ToList();

            }
            return objRatingMasterDataList;
        }

        public int SaveUserRatingData(RatingFileUpload ratingFileUpload)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveUploadedRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@DealId", ratingFileUpload.DealId));
                command.Parameters.Add(command.CreateParameter("@CollectionDate", ratingFileUpload.CollectionDate));
                command.Parameters.Add(command.CreateParameter("@Comment", ratingFileUpload.Comment));
                command.Parameters.Add(command.CreateParameter("@OriginalFileName", ratingFileUpload.OriginalFileName));
                command.Parameters.Add(command.CreateParameter("@UploadedFileName", ratingFileUpload.UploadedFileName));
                command.Parameters.Add(command.CreateParameter("@UploadedBy", ratingFileUpload.UploadedBy));
                command.Parameters.Add(command.CreateParameter("@UploadedDate", ratingFileUpload.UploadedDate));

                if (ratingFileUpload.RatingData != null)
                {
                    command.Parameters.Add(new SqlParameter
                    {
                        TypeName = "cw.RatingUploadData",
                        Value = ratingFileUpload.RatingData,
                        ParameterName = "@RatingUploadData"
                    });
                }
                return this.ExecuteNonQuery(command);
            }
        }

        public IList<RatingListingData> GetRatingListingData()
        {
            IList<RatingListingData> objRatingListingData = new List<RatingListingData>();
            DataTable dt = new DataTable();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetUploadedRatingList;
                command.CommandType = CommandType.StoredProcedure;
                dt.Load(command.ExecuteReader());
                objRatingListingData = dt.AsEnumerable().Select(row => new RatingListingData
                {
                    RatingUploadDetailId = Convert.ToInt32(row["RatingUploadDetailId"]),
                    DealName = Convert.ToString(row["DealName"]),
                    CollectionDate = Convert.ToDateTime(row["CollectionDate"]),
                    OriginalFileName = Convert.ToString(row["OriginalFileName"]),
                    UploadedFileName = Convert.ToString(row["UploadedFileName"]),
                    UploadedBy = Convert.ToString(row["UploadedBy"]),
                    UploadedDate = Convert.ToDateTime(row["UploadedDate"])
                }).ToList();
            }
            return objRatingListingData;
        }


        public RatingSavedData GetUserRatingSavedData(int userRatingFileUploadDetailId)
        {
            RatingSavedData ObjRatingFileUpload = new RatingSavedData();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetUploadedRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@RatingUploadDetailId", userRatingFileUploadDetailId));

                using (DbDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        //Only 1 Row
                        ObjRatingFileUpload.DealName = reader.GetString("DealName");
                        ObjRatingFileUpload.CollectionDate = reader.GetDateTime("CollectionDate");
                        ObjRatingFileUpload.OriginalFileName = reader.GetString("OriginalFileName");
                        ObjRatingFileUpload.UploadedFileName = reader.GetString("UploadedFileName");
                        ObjRatingFileUpload.Comment = reader.IsDBNull("Comment") ? "" : reader.GetString("Comment");
                        ObjRatingFileUpload.UploadedBy = reader.GetString("UploadedBy");
                        ObjRatingFileUpload.UploadedDate = reader.GetDateTime("UploadedDate");

                    }

                    reader.NextResult();
                    DataTable dtRatingData = new DataTable();
                    dtRatingData.Load(reader);
                    ObjRatingFileUpload.RatingData = dtRatingData.Copy();

                }

            }
            return ObjRatingFileUpload;
        }

        public bool UploadRatingDataRecordExist(RatingFileUpload ratingFileUpload)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_UploadRatingDataRecordExist;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@DealId", ratingFileUpload.DealId));
                command.Parameters.Add(command.CreateParameter("@CollectionDate", ratingFileUpload.CollectionDate));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("RecordAlreadyExist", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToBoolean(ReturnCode.Value);

            }
        }

        public int DeleteRatingData(int userRatingFileUploadDetailId, string LoggedInUserNamed)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_DeleteUploadedRatingData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@RatingUploadDetailId", userRatingFileUploadDetailId));
                command.Parameters.Add(command.CreateParameter("@UserName", LoggedInUserNamed));
                return this.ExecuteNonQuery(command);
            }
        }
    }
}
