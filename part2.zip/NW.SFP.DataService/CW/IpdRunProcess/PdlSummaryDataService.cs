﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class PdlSummaryDataService : IPdlSummaryDataService
    {
        private IUnitOfWork _unitOfWork;

        public PdlSummaryDataService()
        {

        }

        public PdlSummaryDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }



        public DataTable GetPDLSummaryData(IPDFeedParam feedParms)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetIpdPdlSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, feedParms.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, feedParms.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, feedParms.UserName));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                return ds.Tables[0];
            }
        }
    }
}
