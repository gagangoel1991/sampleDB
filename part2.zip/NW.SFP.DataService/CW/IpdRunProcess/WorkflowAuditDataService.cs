﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;


namespace NW.SFP.DataService.CW
{
    public class WorkflowAuditDataService : Repository<WorkflowAuditEntity>, IWorkflowAuditDataService
    {

        private IUnitOfWork _unitOfWork;

        public WorkflowAuditDataService()
        {

        }

        public WorkflowAuditDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }
        public IList<WorkflowAuditEntity> GetWorkflowAuditData(int workflowTypeId, int referenceId, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetWorkflowAuditData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkflowType", Enum.GetName(typeof(AuthWorkflowType), workflowTypeId)));
                command.Parameters.Add(command.CreateParameter("@pReferenceId", referenceId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).ToList();
            }
        }
       

    }
}
