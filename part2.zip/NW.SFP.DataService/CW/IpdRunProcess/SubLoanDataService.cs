﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;


namespace NW.SFP.DataService.CW
{
    public class SubloanDataService : Repository<SubloanEntity>, ISubloanDataService
    {
        private IUnitOfWork _unitOfWork;

        public SubloanDataService()
        {

        }

        public SubloanDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public Subloan GetSubloan(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSubloanDetails;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                Subloan subLoan = new Subloan();
                subLoan.SubLoanList = this.Execute(command).ToList();
                subLoan.SubLoanStaticAttributeList = GeSubloanStaticAttributes(ipdFeedParam);
                return subLoan;
            }
        }

        private List<SubloanStaticAttribute> GeSubloanStaticAttributes(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSubloanStaticAttributes;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, ipdFeedParam.UserName));
                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                DataTable dt = new DataTable();
                adapter.Fill(ds);
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }

                var subLoanStaticAttributes = dt.AsEnumerable().Select(row =>
                 new SubloanStaticAttribute
                 {
                     SubloanTypeId = row.Field<byte>("SubloanTypeId"),
                     ApplicableSubLoan = row.Field<string>("ApplicableSubLoan"),
                     InitialAmount = row.Field<decimal?>("InitialAmount"),
                     LimitAmount = row.Field<decimal?>("LimitAmount"),
                     Margin = row.Field<string>("Margin"),
                     RateType = row.Field<string>("RateType")
                 }).ToList();

                return subLoanStaticAttributes;
            }
        }
    }
}
