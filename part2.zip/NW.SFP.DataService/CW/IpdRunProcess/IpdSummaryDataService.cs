﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class IpdSummaryDataService : Repository<IpdSummaryResultEntity>, IIpdSummaryDataService
    {
        private IUnitOfWork _unitOfWork;

        public IpdSummaryDataService()
        {

        }

        public IpdSummaryDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public List<IpdSummaryResultEntity> GetIpdSummaryData(int dealId, int ipdRunId, string loggedInUserName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDealIpdSummary;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pIpdRunId", ipdRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUserName));
                return this.Execute(command).ToList();
            }
        }
    }
}