﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class AdjustmentWaterfallDataService : Repository<AdjustmentWaterfallEntity>, IAdjustmentWaterfallDataService
    {

        private IUnitOfWork _unitOfWork;

        public AdjustmentWaterfallDataService()
        {

        }

        public AdjustmentWaterfallDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        /// <summary>
        ///
        /// </summary>
        /// <param name="loggedInUser"></param>
        /// <returns></returns>
        public IList<AdjustmentWaterfallEntity> GetAdjustmentWaterfallData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetIpdAdjustmentPrincipleWaterfall;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pDealIpdRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pWaterfallCategoryName", ipdFeedParam.WaterfallCategoryName));
                return this.Execute(command).ToArray();
            }
        }

        public int SavePrincipalWaterfall(IEnumerable<AdjustmentWaterfallTypeEntity> adjustmentLineItem, string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveIpdLineItemAdjustment;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pAdjustmentLineItem", adjustmentLineItem.ToDataTable()));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));

                IDbDataParameter ReturnCode = command.CreateOutputParameter("pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(ReturnCode);

                this.ExecuteNonQuery(command);

                return Convert.ToInt32(ReturnCode.Value);
            }
        }
    }
}
