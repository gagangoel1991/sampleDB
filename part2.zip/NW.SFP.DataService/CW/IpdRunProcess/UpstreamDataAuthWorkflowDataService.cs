﻿using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using System;
using System.Data;
using static NW.SFP.DataService.CW.CWDBConstants;


namespace NW.SFP.DataService.CW
{
    public class UpstreamDataAuthWorkflowDataService : Repository<IPDFeedParam>, IUpstreamDataAuthWorkflowDataService
    {
        private IUnitOfWork _unitOfWork;

        public UpstreamDataAuthWorkflowDataService()
        {

        }

        public UpstreamDataAuthWorkflowDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IPDFeedParam GetUpstreamDataAuthWorkflowStatus(IPDFeedParam upstreamDataWorkflowEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetUpstreamDataAuthWorkflowStatus;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkflowType", Enum.GetName(typeof(AuthWorkflowType), upstreamDataWorkflowEntity.WorkflowType)));
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, upstreamDataWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, upstreamDataWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, upstreamDataWorkflowEntity.UserName));
                return this.ExecuteToEntity(command);
            }
        }

        public int ManageUpstreamDataAuthWorkflow(IPDFeedParam upstreamDataWorkflowEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_ManageUpstreamDataAuthWorkflow;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pWorkflowType", Enum.GetName(typeof(AuthWorkflowType), upstreamDataWorkflowEntity.WorkflowType)));
                command.Parameters.Add(command.CreateParameter("@pStepName", Enum.GetName(typeof(AuthWorkflowStep), upstreamDataWorkflowEntity.WorkflowStep)));
                command.Parameters.Add(command.CreateParameter("@pStatus", upstreamDataWorkflowEntity.WorkflowStep));
                command.Parameters.Add(command.CreateParameter("@pComment", upstreamDataWorkflowEntity.Comment));
                command.Parameters.Add(command.CreateParameter(DbProcParamDealId, upstreamDataWorkflowEntity.DealId));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, upstreamDataWorkflowEntity.IPDRunId));
                command.Parameters.Add(command.CreateParameter(DbProcParamUserName, upstreamDataWorkflowEntity.UserName));
                return this.ExecuteNonQuery(command);
            }
        }
    }
}
