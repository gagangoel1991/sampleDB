﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW.IR;
using System;
using System.Collections.Generic;
using System.Data;
using System.Text;
using System.Linq;
using System.Data.SqlClient;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW.IpdRunProcess
{
    public class DealIpdControlsDataService : Repository<StormVsSfpEntity>, IDealIpdControlsDataService
    {
        private IUnitOfWork _unitOfWork;

        public DealIpdControlsDataService()
        {

        }

        public DealIpdControlsDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public StormVsSfpEntity StormVsSfp(int dealId, int ipdRunId, string loggedInUser)
        {
            StormVsSfpEntity objStormVsSfpEntity = new StormVsSfpEntity();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetAutomatedStormVsSfpData;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", ipdRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));

                objStormVsSfpEntity = this.Execute(command).FirstOrDefault();

                return objStormVsSfpEntity;
            }
        }

        public DataSet StormVsSfpExcelData(int dealId, int ipdRunId, string loggedInUser)
        {
            DataSet ds = new DataSet();

            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetAutomatedStormVsSfpExcelData;
                command.CommandType = CommandType.StoredProcedure;

                command.Parameters.Add(command.CreateParameter("@pDealId", dealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", ipdRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));

                SqlDataAdapter adapter = new SqlDataAdapter(command);
              
                DataTable dt = new DataTable();
                adapter.Fill(ds);
            }

            return ds;
        }




    }
}
