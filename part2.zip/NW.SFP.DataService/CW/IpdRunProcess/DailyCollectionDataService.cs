﻿using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.DataService;
using NW.SFP.Message.CW;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using static NW.SFP.DataService.CW.CWDBConstants;

namespace NW.SFP.DataService.CW
{
    public class DailyCollectionDataService : Repository<DailyCollectionEntity>, IDailyCollectionDataService
    {
        private IUnitOfWork _unitOfWork;

        public DailyCollectionDataService()
        {

        }

        public DailyCollectionDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IList<DailyCollectionEntity> GetDailyCollectionData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDailyCollectionData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public IList<DailyCollectionEntity> GetSourceCollectionData(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetSourceDailyCollectionData;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pIPDRunId", ipdFeedParam.IPDRunId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                return this.Execute(command).ToList();
            }
        }

        public IList<string> GetColumns(IPDFeedParam ipdFeedParam)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_GetDailyCollectionFields;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pDealId", ipdFeedParam.DealId));
                command.Parameters.Add(command.CreateParameter("@pUserName", ipdFeedParam.UserName));
                return this.Execute(command).Select(x => x.ColumnName).ToList();
            }
        }

        public int SaveDailyCollectionData(DailyCollectionEntity dailyCollectionEntity, string user)
        {
            Dictionary<string, object> result = new Dictionary<string, object>();
            foreach (var property in dailyCollectionEntity.GetType().GetProperties())
            {
                result.Add(property.Name, property.GetValue(dailyCollectionEntity));
            }
            var dt = ConvertToDataTable(result);
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_SaveDailyCollectionData;
                SqlParameter parameter = command.Parameters.AddWithValue("@pDailyCollectionKeyValue", dt);
                parameter.SqlDbType = SqlDbType.Structured;
                parameter.TypeName = Type_KeyValueArray;


                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pUserName", user));
                command.Parameters.Add(command.CreateParameter("@pCollectionDate", dailyCollectionEntity.CollectionDate));
                command.Parameters.Add(command.CreateParameter("@pBrand", dailyCollectionEntity.Brand));
                command.Parameters.Add(command.CreateParameter("@pDealId", dailyCollectionEntity.DealId));
                command.Parameters.Add(command.CreateParameter("@pChangeReason", dailyCollectionEntity.ChangeReason));
                command.Parameters.Add(command.CreateParameter(DbProcParamIPDRunId, dailyCollectionEntity.DealIpdRunId));
                return this.ExecuteNonQuery(command);
            }
        }

        private static DataTable ConvertToDataTable(Dictionary<string, object> dict)
        {
            var dt = new DataTable();
            dt.Columns.Add("Key", typeof(string));
            dt.Columns.Add("Value", typeof(string));
            foreach (var pair in dict)
            {
                var row = dt.NewRow();
                row["Key"] = pair.Key;
                row["Value"] = pair.Value;
                dt.Rows.Add(row);
            }
            return dt;
        }
    }
}
