﻿namespace NW.SFP.DataService.CW
{
    using System;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Linq;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using NW.SFP.DataService.Core;
    using NW.SFP.Interface.Core;
    using static NW.SFP.DataService.CW.CWDBConstants;


    using NW.SFP.Common;

    public class DataLoadDataService : Repository<StratEntity>, IDataLoadDataService
    {

        private IUnitOfWork _unitOfWork;

        public DataLoadDataService()
        {

        }

        public DataLoadDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }


        public bool ProcessDataLoad(string loadType, string asAtDate, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_AdhocDataLoad;
                command.CommandType = CommandType.StoredProcedure;



                command.Parameters.Add(command.CreateParameter("ploadType", loadType));
                command.Parameters.Add(command.CreateParameter("pLoadDate", asAtDate));
                command.Parameters.Add(command.CreateParameter("UserName", userName));

                this.ExecuteNonQuery(command);

                return true;
            }

        }

        public DataTable GetDataLoadDates()
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = SP_AdhocDataDates;
                command.CommandType = CommandType.StoredProcedure;

                SqlDataAdapter adapter = new SqlDataAdapter(command);
                DataSet ds = new DataSet();
                adapter.Fill(ds);

                DataTable dt = new DataTable();
                if (ds.Tables.Count < 1)
                    dt = null;
                else
                {
                    if (ds != null && ds.Tables[0] != null && ds.Tables[0].Rows.Count > 0)
                        dt = ds.Tables[0];
                    else
                        dt = null;
                }



                return dt;
            }
        }


    }
}
