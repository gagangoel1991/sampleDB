using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.DataService.CW
{
    public class CWDBConstants
    {
        #region Auth 
        public const string SP_IsUserActionAuthorized = @"app.IsUserActionAuthorized";

        public const string SP_GetADGroup = @"app.GetADGroup";
        #endregion

        #region Logger 
        public const string SP_SaveInfoLog = @"app.SaveInfoLog";

        public const string SP_SaveErrorLog = @"app.SaveErrorLog";
        #endregion

        #region CW 
        public const string SP_GetDealIpdProcessMenuData = "[cw].[spGetDealIpdProcessMenuData]";

        public const string SP_GetUserAndMenuData = @"app.GetUserAndMenuData";

        public const string SP_CheckUserActionAuthorization = @"app.CheckUserActionAuthorization";

        public const string SP_GetInvoiceList = @"cw.spGetInvoiceList";

        public const string SP_GetInvoiceIpdData = @"cw.spGetInvoiceIpdData";

        public const string SP_GetInvoice = @"cw.spGetInvoice";

        public const string SP_GetInvoiceCategoryType = @"cw.spGetInvoiceCategoryType";

        public const string SP_GetInvoiceCategory = @"cw.spGetInvoiceCategory";

        public const string SP_DeleteInvoiceData = @"cw.spDeleteInvoice";

        public const string SP_SaveInvoiceData = @"cw.spSaveInvoice";

        public const string SP_GetDealNames = @"cw.spGetDealNames";

        public const string SP_SaveDeal = @"cw.spSaveDeal";

        public const string SP_spGetDealForEdit = @"cw.spGetDealById";

        public const string SP_spDeleteDeal = @"cw.spDeleteDeal";

        public const string SP_GetDealCounterparty = @"cw.spGetDealCounterparty";

        public const string SP_GetDealList = @"cw.spGetDealList";

        public const string SP_GetDealNextIpd = @"cw.spGetDealNextIpd";

        public const string SP_GetAssetStratConfigDetail = @"cw.spGetAssetStratCriteriaDetail";

        public const string SP_InsertAssetStratConfig = @"cw.spInsertAssetStratCriteria";

        public const string SP_DeleteAssetStratConfig = @"cw.spDeleteAssetStratCriteria";

        public const string SP_GetAssetStratDetail = @"cw.spGetAssetStratDetail";

        public const string SP_SaveAssetStrat = @"cw.spSaveAssetStrat";

        public const string SP_DeleteAssetStrat = @"cw.spDeleteAssetStrat";

        public const string SP_GetStratDealTypes = @"cw.spGetStratDealTypes";
        public const string SP_GetDealSecurityListItems = @"corp.getDealSecurityListItems";

       
        public const string SP_GetStratProcessedData = @"rpt.spGetStratProcessedData";

        public const string SP_GetCBStratProcessedData = @"corp.spGetCBStratProcessedData";

        public const string SP_GetExcelSchemaForReport = @"cfgCW.GetExcelSchemaForReport";

        public const string SP_GetExcelSchemaForPostWFControl = @"CW.spIR_GenerateExcelAuotomatedPostWFData";

        public const string SP_GetStratMasterByType = @"cw.spGetStratMasterByType";



        public const string SP_GetIrTemplateDetail = @"cw.spGetTemplatetDetail";

        public const string SP_DeleteIrTemplate = @"cw.spDeleteIrTemplate";

        public const string SP_SaveIrTemplate = @"cw.spSaveIrTemplate";

        public const string SP_GetDealIrConfigList = @"cw.spGetDealIrConfigList";

        public const string SP_GetDealIrConfig = @"cw.spGetDealIrConfig";

        public const string SP_DeleteDealIrConfig = @"cw.spDeleteDealIrConfig";

        public const string SP_SaveDealIrConfig = @"cw.spSaveDealIrConfig";

        public const string SP_SGetKeyValueLookupData = @"cw.spGetKeyValueLookupData";

        public const string SP_GetExcelSchemaForDealIRConfig = @"cw.spIR_GenerateExcelViewDealIRConfig";

        public const string SP_CheckAndLoadMortgageFieldData = @"cw.spCheckAndLoadMortgageFieldData";

        public const string SP_GetCashLadderData = @"cb.spGetCashLadderData";

        public const string SP_GetWIPCashLadderData = @"cb.spGetWIPCashLadder";

        public const string SP_SaveCashLadderData = @"cb.spSaveCashLadderData";

        public const string SP_GetCollectionLedgerData = @"cw.spGetCollectionLedger";

        public const string SP_GetWIPCollectionLedgerData = @"cw.spGetWIPCollectionLedger";

        public const string SP_SaveCollectionLedgerData = @"cw.spSaveWIPCollectionLedger";

        public const string SP_GetDailyCollectionData = @"cw.spGetDailyCollectionData";

        public const string SP_GetDailyCollectionFields = @"cw.spGetDailyCollectionField";

        public const string SP_GetSourceDailyCollectionData = @"cw.spGetWIPDailyCollectionData";

        public const string SP_SaveDailyCollectionData = @"cw.spSaveWIPDailyCollectionData";

        public const string Type_KeyValueArray = @"[cw].[udtKeyValueArray]";

        public const string SP_ParentGetBondRatingData = @"cw.spParentGetRatingData";

        public const string SP_SaveBondRatingData = @"cw.spSaveBondRatingData";

        public const string SP_GetISINs = @"[cw].[spGetISINs]";

        public const string SP_ParentGetSourceBondRatingData = @"cw.spParentGetSourceBondRatingData";

        public const string SP_GetCounterPartyRatingData = @"cw.spGetCounterPartyRatingData";

        public const string SP_SaveCPRatingData = @"cw.spSaveCPRatingData";

        public const string SP_GetSourceCounterPartyRatingData = @"cw.spGetSourceCounterPartyRatingData";

        public const string SP_GetCisCodes = @"[cw].[spGetCisCodes]";

        public const string SP_GetCreditRating = @"cw.spGetCreditRating";

        public const string SP_GetInterestRateData = @"cw.spGetInterestRate";

        public const string SP_SaveInterestRate = @"cw.spSaveWIPInterestRate";

        public const string SP_GetRatingMasterData = @"cw.spGetRatingMasterData";

        public const string SP_GetUploadedRatingList = @"cw.spGetUploadedRatingList";

        public const string SP_SaveUploadedRatingData = @"cw.spSaveUploadedRatingData";

        public const string SP_GetUploadedRatingData = @"cw.spGetUploadedRatingData";

        public const string SP_GetDealNextIpdDates = @"cw.spGetDealNextIpdDates";

        public const string SP_UploadRatingDataRecordExist = @"cw.spUploadRatingDataRecordExist";

        public const string SP_DeleteUploadedRatingData = @"cw.spDeleteUploadedRatingData";

        public const string SP_GetSourceInterestRateData = @"cw.spGetSourceInterestRate";

        public const string SP_GetIpdAdjustmentPrincipleWaterfall = @"cw.GetIpdAdjustmentPrincipleWaterfall";

        public const string SP_SaveIpdAdjustmentPrincipleWaterfall = @"cw.spSaveIpdLineItemAdjustment";

        public const string SP_GetSubloanDetails = @"cw.spGetSubloanDetails";

        public const string SP_GetSubloanStaticAttributes = @"cw.spGetSubloanStaticAttributes";

        public const string SP_GetReserveDetails = @"cw.spGetReserveDetails";

        public const string SP_GetPdlBreakdownDetails = @"cw.spGetPdlBreakdownDetails";

        public const string SP_SaveIpdLineItemAdjustment = @"cw.spSaveIpdLineItemAdjustment";

        public const string SP_GetIpdProcessParentData = @"cw.spGetDealIpdBasicInfoData";

        public const string SP_GetIpdPdlSummary = @"cw.spGetIpdPdlSummary";

        public const string SP_GetNoteSummary = @"cw.spGetNoteSummary";

        public const string SP_GetNoteStaticAttributes = @"cw.spGetNoteStaticAttributes";

        public const string SP_GetAllDealIPDsData = @"cw.spGetAllDealIPDsData";

        public const string SP_GetRatingTriggers = @"cw.spGetRatingTriggers";

        public const string SP_GetNonRatingTriggers = @"cw.spGetNonRatingTriggers";

        public const string SP_SaveNonRatingTrigger = @"cw.spSaveNonRatingTrigger";

        public const string SP_GetRevenueWaterfall = @"[cw].[spGetIPDRevenueWaterfall]";

        public const string SP_GetPrincipalWaterfall = @"[cw].[spGetPrincipalWaterfall]";

        public const string SP_ManageUpstreamDataAuthWorkflow = @"cw.spManageUpstreamDataAuthWorkflow";

        public const string SP_GetUpstreamDataAuthWorkflowStatus = @"cw.spGetUpstreamDataAuthWorkflowStatus";

        public const string SP_GetDealConditionTestData = @"cw.spGetDealConditionTestData";

        public const string SP_GetAutomatedStormVsSfpData = @"cw.spGetAutomatedStormVsSfpData";

        public const string SP_GetAutomatedStormVsSfpExcelData = @"cw.spGetAutomatedStormVsSfpExcelData";

        public const string SP_ValidateIPD = @"cw.spValidateIPD";

        public const string SP_ManageIpdAuthWorkflow = @"cw.spManageIpdAuthWorkflow";

        public const string SP_GetIpdAuthWorkflowStatus = @"cw.spGetIpdAuthWorkflowStatus";

        public const string SP_InitiateIpd = @"cw.spInitiateIpd";

        public const string SP_ResetModifiedAutomatedData = @"cw.spResetModifiedAutomatedData";

        public const string SP_GetDealIpdSummary = @"cw.spGetDealIpdSummary";

        public const string SP_GetWorkflowAuditData = @"cw.spGetWorkflowAuditData";

        public const string SP_RunCashWaterfall = @"cw.spRunCashWaterfall";

        public const string SP_GetRatingsStatus = @"cw.spGetRatingsStatus";

        public const string SP_GetDealNextColEndDate = @"cw.spGetDealNextColEndDate";

        public const string SP_ResetDealIpd = @"cw.spResetDealIpd";

        public const string SP_RunIPDValidatation = @"cw.spRunIPDValidatation";

        public const string SP_WithdrawIpd = @"cw.spWithdrawIpd";

        public const string SP_ManageDealWorkflowProcess = @"[cw].[spManageDealWorkflowProcess]";

        public const string SP_ManageDealIRWorkflowProcess = @"[cw].[spManageBuildIrWorkflowProcess]";

        public const string SP_SaveDealConditionTestData = @"cw.spSaveDealConditions";

        public const string SP_ResetNonRatingTrigger = @"cw.spResetNonratingTriggers";

        public const string SP_ResetTriggersConditions = @"cw.spResetTriggersConditions";

        public const string SP_PostWaterfallOutPutFileData = @"cw.spGetPostwaterfallDeallookupData";

        public const string SP_DealCollapseSentforAuthorization = @"cw.spSaveWIPDeal";

        public const string SP_GetValidCollapseDeal = @"cw.spValidateDealBeforeCollapse";

        public const string SP_SaveOverridedIRFile = @"cw.spSaveOverridedIRFile";

        public const string SP_GetDealLatestAuthorisedIpdDate = @"cw.spGetDealLatestAuthorisedIpdDate";

        public const string SP_GetSpotRate = @"[cw].[spGetSpotRate]";
        
        public const string SP_SaveMinorAmendment = @"[cw].[spMinorAmendmentOnDeal]";

        public const string SP_GetManualFieldData = @"cb.spGetManualFieldData";

        public const string SP_UpdateManualFieldData = @"cb.spUpdateManualFieldData";

        public const string SP_ResetManualFieldData = @"cb.spResetManualFieldData";

        public const string SP_GetDealSwapData = @"[cb].[spGetDealSwap]";

        public const string SP_GetSwapCollateral = @"[cb].[spGetSwapCollateral]";

        public const string SP_GetReserveFund = @"[cb].[spGetReserveFund]";

        public const string SP_GetPreMaturityLiquidityFund = @"[cb].[spGetPreMaturityLiquidityFund]";

        public const string SP_GetCouponPaymentFund = @"[cb].[spGetCouponPaymentFund]";

        public const string SP_GetRevenueFund = @"[cb].[spGetRevenueLedger]";

        public const string SP_GetPaymentFund = @"[cb].[spGetPaymentLedger]";

        public const string SP_GetPrincipalFund = @"[cb].[spGetPrincipalLedger]";

        public const string SP_GetMaturingLoansFund = @"[cb].[spGetMaturingProceedsLoanLedger]";

        public const string SP_GetCapitalAccountLedger = @"[cb].[spGetCapitalAccountLedger]";

        public const string SP_GetSwapRatingTriggers = @"cb.spGetSwapRatingTriggers";  
        
        public const string SP_GetCollectionData = @"cb.spGetCollectionInterestData";

        public const string SP_GetReservesData = @"cb.spGetReservesInterestData";

        public const string SP_GetBondSwapData = @"[cb].[spGetBondSwap]";

        public const string SP_GetReserveFinalRequiredAmount = @"cb.spGetReserveFinalRequiredAmount";

        public const string SP_GetCBNoteSummary = @"cb.spGetCBNoteSummary";

        public const string SP_GetCBNoteStaticAttributes = @"cb.spGetCBNoteStaticAttributes";

        public const string SP_GetSoniaCompoundingSummary = @"cb.spGetSoniaCompoundingSummary";
        
        public const string SP_GetSoniaCompoundingData = @"cb.spGetSoniaCompoundingData";

        public const string SP_GetTestDataSummary = @"[cb].[spGetTestDataSummary]";

        public const string SP_GetTestData = @"[cb].[spGetTestData]";

        public const string SP_AdhocDataLoad = @"[cw].[spAdhocDataLoad]";

        public const string SP_AdhocDataDates = @"[cw].[spGetAdhocDataDates]";

        public const string SP_GetDealIrConfigByDealId = "[cw].spGetDealIrConfigByDealId";

        public const string SP_GetDealNoteList = @"cb.spGetDealNoteInformation";

        public const string SP_SaveDealNoteInformation = @"cb.spSaveWIPDealNoteInformation";

        public const string SP_ManageDealNoteWorkflowProcess = @"[cb].[spManageDealWorkflowProcess]";

        public const string SP_DealNoteWorkflowProcess = @"cb.spDealNoteWorkflowProcess";

        public const string SP_GetReportProcessedData = "sfp.spGetReportProcessedData";
        public const string SP_GetLoanRedemptionAndReplishment = "rpt.spLoanRedemptionAndReplishment_V1";
        public const string SP_GetLoanRedemtionLiability = "rpt.spLoanRedemtionLiability";
        public const string SP_GetProgramLevelCharacterstics = "rpt.spProgramLevelCharacterstics";
        public const string SP_GetCPR1_V1 = "rpt.spCPR1_V1";
        public const string SP_GetCPR2_V1 = "rpt.spCPR2_V1";
        public const string SP_GetCPR3_V1 = "rpt.spCPR3_V1";
        public const string SP_GetAsset_Coverage_Test = "rpt.spAsset_Coverage_Test_V1";
        public const string SP_GetACTCalc1 = "rpt.spACTCalc1";
        public const string SP_GetACTCalc2 = "rpt.spACTCalc2";
        public const string SP_GetACTCalc3 = "rpt.spACTCalc3";
        public const string SP_ResetManualFieldDealSwapData = @"cb.spResetManualFieldData";
		public const string SP_GetBusinessDate = @"cw.spGetBusinessDate";        
		public const string SP_GetDealSummaryOutputData = @"[CW].[spGetDailyCollectionLineItemValue]";

        
        public const string SP_GetDailyCashEstimationData = "[cw].spGetDailyCashEstimationData";
         
        
        public const string SP_SaveDealSummayAdjustment = @"cw.spSaveDailyCollectionLineItemAdjustment";
		public const string SP_GetDailyCollectionHistory = @"cw.spGetDailyCollectionHistory";

        public const string SP_GetEmailConfigList = @"cfg.spGetEmailConfigList";
        public const string SP_spGetEmailConfigById = @"cfg.spGetEmailConfigById";
        public const string SP_SaveEmailConfig = @"cfg.spSaveEmailConfig";
        public const string SP_DeleteEmailConfig = @"cfg.spDeleteEmailConfig";
        public const string SP_GetDailyCollectionPnRSplit = @"cw.spGetDailyCollectionPnRSplit";
		public const string SP_GetDealDailyCollections = @"cw.spGetDealDailyCollectionSummary";
        public const string SP_GetCBOutput = @"cb.spDailyCollectionOutput";
        public const string SP_GetDealSummaryAuditData = @"cw.spGetDailyCollectionWorkflowDetails";

        public const string SP_SaveDealSummayAudit = @"cw.spManageDailyCollectionWorkflowProcess";

        public const string SP_GetDealSummaryBusinessDateList = @"cw.spGetDailyCollectionDateList";

        public const string SP_GetDailyCollectionDealSummary = @"CW.spGetDailyCollectionSummary";		       
        public const string SP_GetEmailDataForCollectionOutput = @"CW.spGetEmailDataByType";
        public const string SP_GetLoadDailyEstimationDealSummary = @"[CW].[spProcessDealDailyCollectionSummary]";

        public const string SP_GetDealSummaryLoadDataEstimation = @"[CW].[spGetDailyCollectionDateListEstimation]";

        public const string SP_IsActualGMSDataAvaliable = @"[CW].[spValidateActualGMSData]";

        public const string SP_GetDeflagPoolData = @"[CW].[spGetDeflagPoolList]";

        public const string SP_GetDeflagAdjustmentPoolList = @"[CW].[spGetDeflagAdjustmentPoolList]";
        public const string SP_GetDeflagAdjustmentData = @"cb.spCalculateDeflagCashCollectionAdjustment";

        public const string SP_GetBookingTradesData = @"[cb].[spGetBookingTradesInformation]";

        public const string SP_GetBookingsIPDData = @"[cb].[spGetBookingsIPDData]";

        public const string SP_GetBookingsNWBFoFeeData = @"[cb].[spGetBookingsNWBFoFeeData]";

        public const string SP_GetBookingsNWBFoLdData = @"[cb].[spGetBookingsNWBFoLDData]";

        public const string SP_GetBookingsLLPMoFeeData = @"[cb].[spGetBookingsLLPMoFeeData]";

        public const string SP_GetBookingLoanAndDepositsData = @"[cb].[spGetBookingLoansAndDepositsData]";

        public const string SP_GetBookingsSwapSummaryData = @"[cb].[spGetBookingSwapsData]";

        public const string SP_GetBookingsReconLineItemData = @"[cb].[spGetBookingsReconLineItemData]";

        public const string SP_GetBookingReconAnalysisTabData = @"[cb].[spProcessBookingsReconData]";

        public const string SP_SaveDeflagAdjustment = @"cw.spManageDeflagAdjustmentWorkflowProcess";

        public const string SP_ReProcessBookingsData = @"cb.spReProcessBookingsIPDData";


        #endregion

        #region CW Parameters
        public const string DbProcParamDealId = "@pDealId";
        public const string DbProcParamIPDRunId = "@pIPDRunId";
        public const string DbProcParamUserName = "@pUserName";
        public const string DbProcParamSourceBondRatingKeyValue = "@pSourceBondRatingKeyValue";
        public const string DbProcParamInterestRateId = "@pInterestRateId";
        public const string DbProcParamInterestRate = "@pInterestRate";
        public const string DbProcParamReason = "@pReason";
        public const string DbProcParamComment = "@pComment";
        public const string DbProcParamAuthorizerComment = "@pAuthorizerComment";
        public const string DbProcParamResultCode = "@pResultCode";
        public const string DbProcParamDealName = "@pDealName";
        public const string DbProcParamDealPublicName = "@pDealPublicName";
        public const string DbProcParamInternalDealName = "@pInternalDealName";
        public const string DbProcParamDescription = "@pDescription";
        public const string DbProcParamOwnerName = "@pOwnerName";
        public const string DbProcParamBusinessAreaId = "@pBusinessAreaId";
        public const string DbProcParamDealTypeId = "@pDealTypeId";
        public const string DbProcParamDealStatusID = "@pDealStatusID";
        public const string DbProcParamClosingDate = "@pClosingDate";
        public const string DbProcParamDealMaturityDate = "@pDealMaturityDate";
        public const string DbProcParamFirstIpdDate = "@pFirstIpdDate";
        public const string DbProcParamCashCollectionStartDate = "@pCashCollectionStartDate";
        public const string DbProcParamIpdFrequencyId = "@pIpdFrequencyId";
        public const string DbProcParamDealCurrencyId = "@pDealCurrencyId";
        public const string DbProcParamJurisdictionMarkerId = "@pJurisdictionMarkerId";
        public const string DbProcParamFurtherAdvancesAutoTopUpFlagId = "@pFurtherAdvancesAutoTopUpFlagId";
        public const string DbProcParamBalanceTransferAutoTopUpFlagId = "@pBalanceTransferAutoTopUpFlagId";
        public const string DbProcParamMortgageAutoTopUpFlagId = "@pMortgageAutoTopUpFlagId";
        public const string DbProcParamDealAccountingTypeId = "@pDealAccountingTypeId";
        public const string DbProcParamEarlyRedemptionDate = "@pEarlyRedemptionDate";
        public const string DbProcParamCashLadderId = "@pCashLadderId";
        public const string DbProcParamCashRate = "@pRate";
        public const string DbProcParamInflowAmount = "@pInflowAmount";
        public const string DbProcParamOutflowAmount = "@pOutflowAmount";
        public const string DbProcParamFlowSubTotal = "@pFlowSubTotal";
        public const string DbProcParamAccrualStartDate = "@pAccrualStartDate";
        public const string DbProcParamAccrualEndDate = "@pAccrualEndDate";
        public const string DbProcParamTestTypeName = "@pTestTypeName";
        public const string DbProcParamRedactedFacilityIds = "@pRedactedFacilityIds";
        public const string DbProcParamAsAtCollectionDate = "@pAsAtCollectionDate";
        public const string DbProcParamFxRateDate = "@pFxRateDate";
        public const string DbProcParampEnableHistoricFlaggingId = "@pEnableHistoricFlaggingId";
        public const string DbProcParamDailyCollectionCategory = "@pDailyCollectionCategory";
        public const string DbProcParamViewType = "@pViewType";



        #endregion
    }
}