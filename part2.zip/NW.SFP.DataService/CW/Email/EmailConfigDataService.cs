﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.Core;
using NW.SFP.Common;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW.Email;

namespace NW.SFP.DataService.CW
{
    public class EmailConfigDataService : Repository<EmailConfigEntity>, IEmailConfigDataService
    {
        private IUnitOfWork _unitOfWork;

        public EmailConfigDataService()
        {

        }

        public EmailConfigDataService(IUnitOfWork uow)
        {
            if (uow == null)
                throw new ArgumentNullException("uow");

            _unitOfWork = uow as UnitOfWork;
        }

        public IList<EmailConfigEntity> GetEmailConfigList(string loggedInUser)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetEmailConfigList;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pUserName", loggedInUser));
                return this.Execute(command).ToList();
            }
        }

        public int SaveEmailConfig(EmailConfigEntity dealEntity)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_SaveEmailConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pEmailConfigId", dealEntity.EmailConfigId));
                command.Parameters.Add(command.CreateParameter("@pEmailTypeId", dealEntity.EmailTypeId));
                command.Parameters.Add(command.CreateParameter("@pInternalName", dealEntity.InternalName));
                command.Parameters.Add(command.CreateParameter("@pDisplayName", dealEntity.DisplayName));
                command.Parameters.Add(command.CreateParameter("@pFrom", dealEntity.EmailFrom));
                command.Parameters.Add(command.CreateParameter("@pTo", dealEntity.EmailTo));
                command.Parameters.Add(command.CreateParameter("@pCC", dealEntity.EmailCC));
                command.Parameters.Add(command.CreateParameter("@pBCC", dealEntity.EmailBCC));
                command.Parameters.Add(command.CreateParameter("@pSubject", dealEntity.EmailSubject));
                command.Parameters.Add(command.CreateParameter("@pBody", dealEntity.EmailBody));
                command.Parameters.Add(command.CreateParameter("@pImportance", dealEntity.EmailImportance));
                command.Parameters.Add(command.CreateParameter("@pEmailFormat", dealEntity.EmailFormat));
                command.Parameters.Add(command.CreateParameter("@pAttachment", dealEntity.Attachment));
                command.Parameters.Add(command.CreateParameter("@pIsActive", dealEntity.IsActive)); 
                command.Parameters.Add(command.CreateParameter("@pUserName", dealEntity.UserName)); 
                IDbDataParameter returnCode = command.CreateOutputParameter("@pReturnCode", 0, DbType.Int32, -1);
                command.Parameters.Add(returnCode);
                this.ExecuteNonQuery(command);
                return Convert.ToInt32(returnCode.Value);
            }
        }

         
        public EmailConfigEntity GetEmailConfig(int emailConfigId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_GetEmailConfigList;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pEmailConfigId", emailConfigId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                return this.ExecuteToEntity(command);
            }
        }


        public int DeleteEmailConfig(int emailConfigId, string userName)
        {
            using (var command = this._unitOfWork.CreateCommand())
            {
                command.CommandText = CWDBConstants.SP_DeleteEmailConfig;
                command.CommandType = CommandType.StoredProcedure;
                command.Parameters.Add(command.CreateParameter("@pEmailConfigId", emailConfigId));
                command.Parameters.Add(command.CreateParameter("@pUserName", userName));
                return this.ExecuteNonQuery(command);
            }
        }

    }
}
