﻿using NW.SFP.DataService.Core;
using System.Data;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Interface.ConnectionManager;
using static NW.SFP.DataService.SFP.SfpDBConstants;
using NW.SFP.Message.SFP.DataQuality;
using System.Collections.Generic;

namespace NW.SFP.DataService.SFP
{
    public class EnforcementDataQualityReportDataService : IEnforcementDataQualityReportDataService
    {
        private readonly IConnectionManager _connectionManager;

        public EnforcementDataQualityReportDataService(IConnectionManager connectionManager)
        {
            this._connectionManager = connectionManager;
        }

        /// <summary>
        /// Get Enforcement Data Quality Detail Report
        /// </summary>
        /// <returns></returns>
        public List<EnforcementDetail> GetEnforcementDataQualityDetailReport()
        {
            DataSet _enforcementDetailDataset;
            List<EnforcementDetail> lstEnforcementDetail = new List<EnforcementDetail>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_Enforcement_Data_Quality_Detail_Report;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _enforcementDetailDataset = _connectionManager.ExecuteDataSet();
            }
            if (_enforcementDetailDataset != null && _enforcementDetailDataset.Tables.Count > 0 && _enforcementDetailDataset.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drEncumbranceSummary in _enforcementDetailDataset.Tables[0].Rows)
                {
                    lstEnforcementDetail.Add(new EnforcementDetail()
                    {
                        RuleId = Utility.GetInt(drEncumbranceSummary[DbFieldDataQualityReportRuleId]),
                        LoanId = Utility.GetString(drEncumbranceSummary[DbFieldDataQualityLoanId])
                    });
                }
            }

            return lstEnforcementDetail;
        }

        /// <summary>
        /// Get Enforcement Data Quality Summary Report
        /// </summary>
        /// <returns></returns>
        public List<EnforcementSummary> GetEnforcementDataQualitySummaryReport()
        {
            DataSet _enforcementSummaryDataset;
            List<EnforcementSummary> lstEnforcementSummary = new List<EnforcementSummary>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_Enforcement_Data_Quality_Summary_Report;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _enforcementSummaryDataset = _connectionManager.ExecuteDataSet();
            }
            if (_enforcementSummaryDataset != null && _enforcementSummaryDataset.Tables.Count > 0  && _enforcementSummaryDataset.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drEnforcementSummary in _enforcementSummaryDataset.Tables[0].Rows)
                {
                    lstEnforcementSummary.Add(new EnforcementSummary()
                    {
                        RuleId = Utility.GetInt(drEnforcementSummary[DbFieldDataQualityReportRuleId]),
                        LoanCount = Utility.GetInt(drEnforcementSummary[DbFieldDataQualityLoanCount]),
                        RuleDescription = Utility.GetString(drEnforcementSummary[DbFieldDataQualityRuleDescription]),
                        SuccessIndicator = Utility.GetString(drEnforcementSummary[DbFieldDataQualitySuccessIndicator]),
                        Comment = Utility.GetString(drEnforcementSummary[DbFieldDataQualityComment])
                    });
                }
            }

            return lstEnforcementSummary;
        }

        /// <summary>
        /// Get Enforcement DataValidation Status
        /// </summary>
        /// <returns></returns>
        public int GetEnforcementDataValidationStatus()
        {
            DataSet _enforcementvalidationData;
            int ValidationResult =0;

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_Get_Enforcement_Data_ValidationStatus;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _enforcementvalidationData = _connectionManager.ExecuteDataSet();
            }
            if (_enforcementvalidationData != null && _enforcementvalidationData.Tables.Count > 0 && _enforcementvalidationData.Tables[0].Rows.Count > 0)
            {
                ValidationResult = Utility.GetInt(_enforcementvalidationData.Tables[0].Rows[0][0]);
            }

            return ValidationResult;
        }

    }
}
