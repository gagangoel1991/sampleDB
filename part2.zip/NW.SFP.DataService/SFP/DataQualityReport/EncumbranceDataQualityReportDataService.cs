﻿using NW.SFP.DataService.Core;
using System.Data;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Interface.ConnectionManager;
using static NW.SFP.DataService.SFP.SfpDBConstants;
using NW.SFP.Message.SFP.DataQuality;
using System.Collections.Generic;

namespace NW.SFP.DataService.SFP
{
    public class EncumbranceDataQualityReportDataService : IEncumbranceDataQualityReportDataService
    {
        private readonly IConnectionManager _connectionManager;

        public EncumbranceDataQualityReportDataService(IConnectionManager connectionManager)
        {
            this._connectionManager = connectionManager;
        }

        /// <summary>
        /// Get SFP batch Status Information
        /// </summary>
        /// <returns></returns>
        public List<EncumbranceSummary> GetEncumbranceDataQualitySummaryReport()
        {
            DataSet _encumbranceSummaryDataset;
            List<EncumbranceSummary> lstEncumbranceSummary = new List<EncumbranceSummary>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_Encumbrance_Data_Quality_Summary_Report;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _encumbranceSummaryDataset = _connectionManager.ExecuteDataSet();
            }
            if (_encumbranceSummaryDataset != null && _encumbranceSummaryDataset.Tables.Count > 0 && _encumbranceSummaryDataset.Tables[0] != null && _encumbranceSummaryDataset.Tables[0].Rows.Count > 0)
            {
               foreach(DataRow drEncumbranceSummary in _encumbranceSummaryDataset.Tables[0].Rows)
                {
                    lstEncumbranceSummary.Add(new EncumbranceSummary()
                    {
                        RuleId = Utility.GetInt(drEncumbranceSummary[DbFieldDataQualityReportRuleId]),
                        PoolCount = Utility.GetInt(drEncumbranceSummary[DbFieldDataQualityReportPoolCount]),
                        RuleDescription = Utility.GetString(drEncumbranceSummary[DbFieldDataQualityRuleDescription]),
                        SuccessIndicator = Utility.GetString(drEncumbranceSummary[DbFieldDataQualitySuccessIndicator]),
                        Comment = Utility.GetString(drEncumbranceSummary[DbFieldDataQualityComment])
                    });
                }
            }

            return lstEncumbranceSummary;
        }

        /// <summary>
        /// Get SFP batch Status Information
        /// </summary>
        /// <returns></returns>
        public List<EncumbranceDetail> GetEncumbranceDataQualityDetailReport()
        {
            DataSet _encumbranceDetailDataset;
            List<EncumbranceDetail> lstEncumbranceDetail = new List<EncumbranceDetail>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_Encumbrance_Data_Quality_Detail_Report;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _encumbranceDetailDataset = _connectionManager.ExecuteDataSet();
            }
            if (_encumbranceDetailDataset != null && _encumbranceDetailDataset.Tables.Count > 0 && _encumbranceDetailDataset.Tables[0] != null && _encumbranceDetailDataset.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drEncumbranceSummary in _encumbranceDetailDataset.Tables[0].Rows)
                {
                    lstEncumbranceDetail.Add(new EncumbranceDetail()
                    {
                        Pool = Utility.GetString(drEncumbranceSummary[DbFieldDataQualityReportPoolText]),
                        RuleId = Utility.GetInt(drEncumbranceSummary[DbFieldDataQualityReportRuleId])
                    });
                }
            }

            return lstEncumbranceDetail;
        }


        /// <summary>
        /// Get Enforcement DataValidation Status
        /// </summary>
        /// <returns></returns>
        public int GetEncumbranceDataValidationStatus()
        {
            DataSet _encumbrancevalidationData;
            int ValidationResult = 0;

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_Get_Encumbrance_Data_ValidationStatus;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _encumbrancevalidationData = _connectionManager.ExecuteDataSet();
            }
            if (_encumbrancevalidationData != null && _encumbrancevalidationData.Tables.Count > 0 && _encumbrancevalidationData.Tables[0].Rows.Count > 0)
            {
                ValidationResult = Utility.GetInt(_encumbrancevalidationData.Tables[0].Rows[0][0]);
            }

            return ValidationResult;
        }
    }
}
