﻿namespace NW.SFP.DataService.SFP
{
    public static partial class SfpDBConstants
    {
        #region SFP

        #region Procedure Name Constant

        public const string SP_GET_SFP_DashBoard_Data = "[app].[GetSFPDashBoardData]";
        public const string SP_GET_SFP_Batch_Data = "[app].[spGetSFPBatchStatus]";

        public const string SP_Encumbrance_Data_Quality_Summary_Report = "rpt.spEncumbranceDataQualitySummaryReport";
        public const string SP_Encumbrance_Data_Quality_Detail_Report = "rpt.spEncumbranceDataQualityDetailsReport";
        public const string SP_Enforcement_Data_Quality_Summary_Report = "rpt.spBuild_EnforcementDataQualityReport";
        public const string SP_Enforcement_Data_Quality_Detail_Report = "rpt.spBuild_EnforcementDetailListLoanReport";
        public const string SP_Get_Enforcement_Data_ValidationStatus = "[rpt].[GetEnforcementDataValidationStatus]";
        public const string SP_Get_Encumbrance_Data_ValidationStatus = "[rpt].[GetEncumbranceDataValidationStatus]";

        public const string SP_GET_SFP_LOOKUP_DATA = "[app].[GetWorkpad_ReportLookUpData]";
        public const string SP_INSERT_LOOKUP_REPORT_DATA = "[app].[spInsertWorkpad_ReportLookUpData]";
        public const string SP_DELETE_LOOKUP_REPORT_DATA = "[app].[spDelete_ReportLookUpData]";
        public const string SP_SUPPORT_INSERT_LOOKUP_REPORT_DATA = "[app].[spSupportInsertReportLookUpData]";
        public const string SP_UPDATE_WORKPAD_LOOKUP_REPORT_DATA = "[app].[spUpdateWorkpad_ReportLookUpData]";
        public const string SP_GET_ALL_LOOKUP_REFERENCE_DATA = "[app].[GetReportLookUpReferenceData]";
        public const string SP_GET_ALL_LOOKUP_ACTION_WORKFLOW = "[app].[spWorkpad_ActionWorkflow]";

        #endregion

        #region Procedure DB Fields

        #region SFP DashBoard

        public const string DbFieldSFPDashboardDealName = "DealName";
        public const string DbFieldSFPDashboardBrandCode = "BrandCode";
        public const string DbFieldSFPDashboardCapitalBalance = "CapitalBalance";
        public const string DbFieldSFPDashboardTrueBalance = "TrueBalance";
        public const string DbFieldSFPDashboardLoanCount = "LoanCount";
        public const string DbFieldSFPDashboardLoanCountPrevious = "LoanCountPrevious";
        public const string DbFieldSFPDashboardLoanCountVariance = "LoanCountVariance";
        public const string DbFieldSFPDashboardSubAccountCount = "SubAccountCount";
        public const string DbFieldSFPDashboardSubAccountCountPrevious = "SubAccountCountPrevious";
        public const string DbFieldSFPDashboardSubAccountCountVariance = "SubAccountCountVariance";
        public const string DbFieldSFPDashboardAsAtDate = "AsAtDate";

        #endregion

        #region SFP Batch

        public const string DbFieldSFPBatchRelatesToDate = "RelatesToDate";
        public const string DbFieldSFPRefreshedAt = "RefreshedAt";

        public const string DbFieldSSASTabularState = "SSASTabularState";
        public const string DbFieldIsSSASTabularBatchComplete = "IsSSASTabularBatchComplete";
        public const string DbFieldSSASTabularStateChangedDatetime = "SSASTabularStateChangedDatetime";

        public const string DbFieldReportState = "ReportState";
        public const string DbFieldIsReportBatchComplete = "IsReportBatchComplete";
        public const string DbFieldReportStateChangedDatetime = "ReportStateChangedDatetime";


        #endregion


        #region Quality Data Report

        public const string DbFieldDataQualityLoanId = "LoanId";
        public const string DbFieldDataQualityComment = "Comment";
        public const string DbFieldDataQualityLoanCount = "LoanCount";
        public const string DbFieldDataQualityReportRuleId = "RuleId";
        public const string DbFieldDataQualityReportPoolText = "Pool";
        public const string DbFieldDataQualityReportPoolCount = "PoolCount";
        public const string DbFieldDataQualityRuleDescription = "RuleDescription";
        public const string DbFieldDataQualitySuccessIndicator = "SuccessIndicator";
        
        
        


        #region SFP Lookup Data

        #region "Pool SP Param"

        public const string DbProcParamChanger = "@pChanger";
        public const string DbProcParamReportTemplateName = "@pReportTemplateName";
        public const string DbProcParamLookUpName = "@pLookUpName";
        public const string DbProcParampLookUpValue = "@pLookUpValue";
        public const string DbProcParamLookUpValueDescription = "@pLookUpValueDescription";
        public const string DbProcParamReportValue = "@pReportValue";
        public const string DbProcParampIds = "@lookUpId";
        public const string DbProcParampModifiedBy = "@pModifiedBy";
        public const string DbProcParampRowId = "@pRowID";
        public const string DbProcParampInsertStatus = "@insertStatus";
        public const string DbProcParampUpdateStatus = "@updateStatus";
        public const string DbProcParampLookupId = "@lookUpId";
        public const string DbProcParampAction = "@pAction";
        public const string DbProcParampEntity = "@pEntity";
        public const string DbProcParampActionStatus = "@actionStatus";
        public const string DbProcParampResetStatus = "@resetStatus";

        #endregion

        public const string DbFieldSFPLoopupDataReportLookUpId = "id";
        public const string DbFieldSFPLoopupDataReportTemplateName = "ReportTemplateName";
        public const string DbFieldSFPLoopupDataLookUpName = "LookUpName";
        public const string DbFieldSFPLoopupDataLookUpValue = "LookUpValue";
        public const string DbFieldSFPLoopupDataLookUpValueDescription = "LookUpValueDescription";
        public const string DbFieldSFPLoopupDataReportValue = "ReportValue";
        public const string DbFieldSFPLoopupDataAsAtDateFrom = "AsAtDateFrom";
        public const string DbFieldSFPLoopupDataAsAtDateTo = "AsAtDateTo";
        public const string DbFieldSFPLoopupDataCreateDateTime = "CreateDateTime";
        public const string DbFieldSFPLoopupDataCurrentRecord = "CurrentRecord";
        public const string DbFieldSFPLoopupDataChanger = "Changer";
        public const string DbFieldSFPLoopupDataRequester = "Requester";
        public const string DbFieldSFPLoopupDataRequestedDateTime = "RequestedDateTime";
        public const string DbFieldSFPLoopupDataAuthoriser = "Authoriser";
        public const string DbFieldSFPLoopupDataAuthorisationDateTime = "AuthorisationDateTime";
        public const string DbFieldSFPLoopupDataModifiedBy = "ModifiedBy";
        public const string DbFieldSFPLoopupDataModifiedDateTime = "ModifiedDateTime";
        public const string DbFieldSFPLoopupDataWorkPadId = "WorkPadId";
        public const string DbFieldSFPLoopupDataStatus = "LookUpStatus";
        public const string DbFieldSFPLoopupDataRef_LookUpValueDescription = "Ref_LookUpValueDescription";
        public const string DbFieldSFPLoopupDataRef_ReportValue = "Ref_ReportValue";


        //  Report Lookup Reference Data

        public const string DbFieldSFPLoopupRefDataFieldName = "FieldName";
        public const string DbFieldSFPLoopupRefDataId = "Id";
        public const string DbFieldSFPLoopupRefDataValue = "Value";

        #endregion

        #endregion

        #endregion

        #endregion
    }

}