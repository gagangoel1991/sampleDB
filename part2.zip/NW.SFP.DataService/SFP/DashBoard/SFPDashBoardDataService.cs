﻿using NW.SFP.DataService.Core;
using System.Data;
using NW.SFP.Message.SFP;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Interface.ConnectionManager;
using System.Collections.Generic;
using System.Data.SqlClient;
using static NW.SFP.DataService.SFP.SfpDBConstants;

namespace NW.SFP.DataService.SFP
{
    public class SfpDashBoardDataService : ISfpDashboardDataService
    {
        private readonly IConnectionManager _connectionManager;
        private readonly SfpDashBoardDataList _dashBoardDataList;

        public SfpDashBoardDataService(IConnectionManager connectionManager, SfpDashBoardDataList dashBoardDataList)
        {
            this._connectionManager = connectionManager;
            this._dashBoardDataList = dashBoardDataList;
        }

        public SfpDashBoardDataList GetSFPDashBoardData(string userName)
        {
            DataSet _dashBoardDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_GET_SFP_DashBoard_Data;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;
                _connectionManager.CommandTimeOut = 0;

                // add parameters for this procedure
                sqlParameters.Add(new SqlParameter(){
                                                        ParameterName = DbConstants.DbProcParamUserName,
                                                        Value = userName
                                                     });

                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _dashBoardDataset = _connectionManager.ExecuteDataSet();
            }
                
           if (_dashBoardDataset.Tables[0] != null && _dashBoardDataset.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drDashBoardData in _dashBoardDataset.Tables[0].Rows)
                {
                    _dashBoardDataList.dashBoardDataList.Add(new SFPDashBoardData()
                    {
                        DealName = Utility.GetString(drDashBoardData[DbFieldSFPDashboardDealName]),
                        BrandCode = Utility.GetString(drDashBoardData[DbFieldSFPDashboardBrandCode]),
                        CapitalBalance = Utility.GetDecimal(drDashBoardData[DbFieldSFPDashboardCapitalBalance]),
                        TrueBalance = Utility.GetDecimal(drDashBoardData[DbFieldSFPDashboardTrueBalance]),
                        LoanCount = Utility.GetInt(drDashBoardData[DbFieldSFPDashboardLoanCount]),
                        LoanCountPrevious = Utility.GetInt(drDashBoardData[DbFieldSFPDashboardLoanCountPrevious]),
                        LoanCountVariance = Utility.GetInt(drDashBoardData[DbFieldSFPDashboardLoanCountVariance]),
                        SubAccountCount = Utility.GetInt(drDashBoardData[DbFieldSFPDashboardSubAccountCount]),
                        SubAccountCountPrevious = Utility.GetInt(drDashBoardData[DbFieldSFPDashboardSubAccountCountPrevious]),
                        SubAccountCountVariance = Utility.GetInt(drDashBoardData[DbFieldSFPDashboardSubAccountCountVariance])
                    });
                }
            }

            if (_dashBoardDataset.Tables[1] != null && _dashBoardDataset.Tables[1].Rows.Count > 0)
            {
               _dashBoardDataList.AsAtDate = Utility.GetShortDateTime(_dashBoardDataset.Tables[1].Rows[0][DbFieldSFPDashboardAsAtDate]);
            }

            return this._dashBoardDataList;
        }
    }
}
