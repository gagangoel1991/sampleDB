﻿using NW.SFP.DataService.Core;
using System.Data;
using NW.SFP.Message.SFP;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Interface.ConnectionManager;
using System.Collections.Generic;
using System.Data.SqlClient;
using NW.SFP.Message.SFP.Model;
using System.Linq;

namespace NW.SFP.DataService.SFP
{
    public class ReportLookUpDataService : IReportLookUpDataService
    {
        private readonly IConnectionManager _connectionManager;

        public ReportLookUpDataService(IConnectionManager connectionManager)
        {
            this._connectionManager = connectionManager;
        }

        /// <summary>
        /// This function gives the report lookup data list to be displayed for Lookup List 
        /// </summary>
        /// <returns></returns>
        public List<ReportLookupModel> GetReportLookupData()
        {
            DataSet _reportLookUpDataset;
            List<ReportLookupModel> _lstLookupData = new List<ReportLookupModel>(); 

            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_GET_SFP_LOOKUP_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _reportLookUpDataset = _connectionManager.ExecuteDataSet();
            }
                
           if (_reportLookUpDataset.Tables[0] != null && _reportLookUpDataset.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drLookUpdataData in _reportLookUpDataset.Tables[0].Rows)
                {
                    _lstLookupData.Add(new ReportLookupModel()
                    {
                        ReportLookUpWorkPadId = Utility.GetInt(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataReportLookUpId]),
                        Status = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataStatus]),
                        Requester = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataRequester]),
                        Authoriser = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataAuthoriser]),
                        ReportTemplateName = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataReportTemplateName]),
                        LookUpName = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataLookUpName]),
                        LookUpValue = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataLookUpValue]),
                        LookUpValueDescription = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataLookUpValueDescription]),
                        ReportValue = Utility.GetString(drLookUpdataData[SfpDBConstants.DbFieldSFPLoopupDataReportValue])
                    });
                }
            }

            return _lstLookupData;
        }

        /// <summary>
        /// /// This function gives the report lookup data list to be displayed for Lookup Record on the basis of ID
        /// </summary>
        /// <param name="reportLookUWorkPadpId"></param>
        /// <returns></returns>
        public ReportLookupModel GetReportLookupDataById(int reportLookUWorkPadpId)
        {
            DataSet _reportLookUpDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            ReportLookupModel _lookupData = new ReportLookupModel();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_GET_SFP_LOOKUP_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampLookupId,
                    Value = reportLookUWorkPadpId
                });
                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _reportLookUpDataset = _connectionManager.ExecuteDataSet();
            }
            if(_reportLookUpDataset.Tables[0].Rows.Count > 0)
            {
                _lookupData = (new ReportLookupModel()
                {
                    ReportLookUpWorkPadId = Utility.GetInt(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataReportLookUpId]),
                    Status = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataStatus]),
                    Requester = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataRequester]),
                    Authoriser = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataAuthoriser]),
                    ReportTemplateName = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataReportTemplateName]),
                    LookUpName = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataLookUpName]),
                    LookUpValue = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataLookUpValue]),
                    LookUpValueDescription = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataLookUpValueDescription]),
                    ReportValue = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataReportValue]),
                    Changer = Utility.GetString(_reportLookUpDataset.Tables[0].Rows[0][SfpDBConstants.DbFieldSFPLoopupDataChanger])
                });
            }
            return _lookupData;
        }

        /// <summary>
        /// /// This function is used to insert new record for Report Lookup table
        /// </summary>
        /// <param name="reportLookUpData"></param>
        /// <returns></returns>
        public ReportLookupModel InsertReportLookUpData(ReportLookupModel reportLookUpData)
        {
            DataSet _reportLookUpDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            
            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_INSERT_LOOKUP_REPORT_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamChanger,
                    Value = reportLookUpData.Changer
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamReportTemplateName,
                    Value = reportLookUpData.ReportTemplateName
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamLookUpName,
                    Value = reportLookUpData.LookUpName
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampLookUpValue,
                    Value = reportLookUpData.LookUpValue
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamLookUpValueDescription,
                    Value = reportLookUpData.LookUpValueDescription
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamReportValue,
                    Value = reportLookUpData.ReportValue
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampInsertStatus,
                    Value = 0,
                    Direction = ParameterDirection.Output
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampLookupId,
                    Value = 0,
                    Direction = ParameterDirection.Output
                });

                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _connectionManager.ExecuteNonQuery();

            }
            return new ReportLookupModel()
            {
                ReportLookUpWorkPadId = Utility.GetInt(_connectionManager.GetOutputParameterList().ElementAt(1).Value),
                ValidationStatus = Utility.GetInt(_connectionManager.GetOutputParameterList().ElementAt(0).Value),
            };
       }

        /// <summary>
        /// This function is used to delete the existing unauthorised data
        /// </summary>
        /// <param name="reportLookUpIds"></param>
        public int DeleteReportLookUpData(int lookupId)
        {
            DataSet _reportLookUpDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            
            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_DELETE_LOOKUP_REPORT_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampIds,
                    Value = lookupId
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampResetStatus,
                    Value = 0,
                    Direction = ParameterDirection.Output
                });
                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _connectionManager.ExecuteNonQuery();
            }
            return Utility.GetInt(_connectionManager.GetOutputParameterList().ElementAt(0).Value);
       }


        /// <summary>
        /// This function Supports Insert Report Look Up Data
        /// </summary>
        /// <param name="reportLookUpData"></param>
        public void SupportInsertReportLookUpData(ReportLookupModel reportLookUpData)
        {
            DataSet _reportLookUpDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_SUPPORT_INSERT_LOOKUP_REPORT_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamReportTemplateName,
                    Value = reportLookUpData.ReportTemplateName
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamLookUpName,
                    Value = reportLookUpData.LookUpName
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampLookUpValue,
                    Value = reportLookUpData.LookUpValue
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamLookUpValueDescription,
                    Value = reportLookUpData.LookUpValueDescription
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamReportValue,
                    Value = reportLookUpData.ReportValue
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampModifiedBy,
                    Value = reportLookUpData.Changer
                });

                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _connectionManager.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Update Report Look up workpad data
        /// </summary>
        /// <param name="reportLookUpData"></param>
        /// <returns></returns>
        public ReportLookupModel UpdateWorkpadReportLookUpData(ReportLookupModel reportLookUpData)
        {
            DataSet _reportLookUpDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            ReportLookupModel reportLookupData = new ReportLookupModel();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_UPDATE_WORKPAD_LOOKUP_REPORT_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampLookupId,
                    Value = reportLookUpData.ReportLookUpWorkPadId
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamChanger,
                    Value = reportLookUpData.Changer
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamLookUpValueDescription,
                    Value = reportLookUpData.LookUpValueDescription
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamReportValue,
                    Value = reportLookUpData.ReportValue
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampUpdateStatus,
                    Value = 0,
                    Direction = ParameterDirection.Output
                });
                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _connectionManager.ExecuteNonQuery();
            }

            return new ReportLookupModel()
            {
                ValidationStatus = Utility.GetInt(_connectionManager.GetOutputParameterList().ElementAt(0).Value),
                ReportLookUpWorkPadId = reportLookUpData.ReportLookUpWorkPadId
            };
        }


        /// <summary>
        /// Update report lookup data items
        /// </summary>
        /// <param name="userName"></param>
        /// <param name="action"></param>
        /// <param name="lookupIds"></param>
        /// <returns></returns>
        public int UpdateLookUpActionWorkFlow(string userName, string  action, int lookupIds)
        {
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            
            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_GET_ALL_LOOKUP_ACTION_WORKFLOW;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParamChanger,
                    Value = userName
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampAction,
                    Value = action
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampEntity,
                    Value = "ReportLookUpData"
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampIds,
                    Value = lookupIds
                });
                sqlParameters.Add(new SqlParameter()
                {
                    ParameterName = SfpDBConstants.DbProcParampActionStatus,
                    Value = 0,
                    Direction = ParameterDirection.Output
                });

                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _connectionManager.ExecuteNonQuery();
            }

            return Utility.GetInt(_connectionManager.GetOutputParameterList().ElementAt(0).Value);
           
        }

        /// <summary>
        /// This function is used to get Reference data for Report Look up data
        /// </summary>
        /// <param name="reportLookUpData"></param>
        /// <returns></returns>
        public List<ReportLookupReferenceModel> GetReportLookUpReferenceData()
        {
            DataSet _reportLookUpReferenceDataset;
            List<SqlParameter> sqlParameters = new List<SqlParameter>();
            List<ReportLookupReferenceModel> _lstLookupReferenceData = new List<ReportLookupReferenceModel>();

            using (_connectionManager)
            {
                _connectionManager.CommandText = SfpDBConstants.SP_GET_ALL_LOOKUP_REFERENCE_DATA;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                _connectionManager.ParameterListInput = sqlParameters;

                // get Dataset for DashBoard List
                _reportLookUpReferenceDataset = _connectionManager.ExecuteDataSet();
            }

            if (_reportLookUpReferenceDataset.Tables[0] != null && _reportLookUpReferenceDataset.Tables[0].Rows.Count > 0)
            {
                foreach (DataRow drLookUpdataReferenceData in _reportLookUpReferenceDataset.Tables[0].Rows)
                {
                    _lstLookupReferenceData.Add(new ReportLookupReferenceModel()
                    {
                        FieldName = Utility.GetString(drLookUpdataReferenceData[SfpDBConstants.DbFieldSFPLoopupRefDataFieldName]),
                        Id = Utility.GetString(drLookUpdataReferenceData[SfpDBConstants.DbFieldSFPLoopupRefDataId]),
                        Value = Utility.GetString(drLookUpdataReferenceData[SfpDBConstants.DbFieldSFPLoopupRefDataValue])
                    });
                }
            }

            return _lstLookupReferenceData;
        }
    }
}
