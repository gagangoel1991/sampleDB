﻿using NW.SFP.DataService.Core;
using System.Data;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Interface.ConnectionManager;
using NW.SFP.Message.SFP.Model;
using static NW.SFP.DataService.SFP.SfpDBConstants;

namespace NW.SFP.DataService.SFP
{
    public class SfpBatchStatusDataService : ISfpBatchStatusDataService
    {
        private readonly IConnectionManager _connectionManager;
        private readonly BatchStatusDetailModel _batchStatusData;

        public SfpBatchStatusDataService(IConnectionManager connectionManager, BatchStatusDetailModel batchStatusData)
        {
            this._connectionManager = connectionManager;
            this._batchStatusData = batchStatusData;
        }

        /// <summary>
        /// Get SFP batch Status Information
        /// </summary>
        /// <returns></returns>
        public BatchStatusDetailModel GetSFPBatchStatusData()
        {
            DataSet _batchDataset;
            
            using (_connectionManager)
            {
                _connectionManager.CommandText = SP_GET_SFP_Batch_Data;
                _connectionManager.CommandType = CommandType.StoredProcedure;
                _connectionManager.ConnectionSource = SQLSource.SFPModel;

                // get Dataset for DashBoard List
                _batchDataset = _connectionManager.ExecuteDataSet();
            }

            if (_batchDataset.Tables[0] != null && _batchDataset.Tables[0].Rows.Count > 0)
            {
                DataRow drBatchStatus = _batchDataset.Tables[0].Rows[0];

                _batchStatusData.RelatesToDate = Utility.GetString(drBatchStatus[SfpDBConstants.DbFieldSFPBatchRelatesToDate]);
                _batchStatusData.RefreshedAt = Utility.GetString(drBatchStatus[SfpDBConstants.DbFieldSFPRefreshedAt]);

                _batchStatusData.SSASTabularState = Utility.GetString(drBatchStatus[SfpDBConstants.DbFieldSSASTabularState]);
                _batchStatusData.IsSSASTabularBatchComplete = Utility.GetBool(drBatchStatus[SfpDBConstants.DbFieldIsSSASTabularBatchComplete]);
                _batchStatusData.SSASTabularStateChangedDatetime = Utility.GetString(drBatchStatus[SfpDBConstants.DbFieldSSASTabularStateChangedDatetime]);

                _batchStatusData.ReportState = Utility.GetString(drBatchStatus[SfpDBConstants.DbFieldReportState]);
                _batchStatusData.IsReportBatchComplete = Utility.GetBool(drBatchStatus[SfpDBConstants.DbFieldIsReportBatchComplete]);
                _batchStatusData.ReportStateChangedDatetime = Utility.GetString(drBatchStatus[SfpDBConstants.DbFieldReportStateChangedDatetime]);
            }
            return this._batchStatusData;
        }
    }
}
