﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Reflection;
using System.Text.RegularExpressions;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class FieldManagementDataService : IFieldManagementDataService
    {
        #region Object Declarations and Constructor
        private readonly IOptions<DataServiceSettings> _settings;
        //Variable declaration - for rule JSON Parsing while inserting Field
        IList<QueryExpressionRule> lstRules = new List<QueryExpressionRule>();
        int parentIndex = 0, groupIndex = 1, ruleIndex = 1;
        //Variable pPlaceholderIndex = groupIndex
        int pPlaceholderIndex = 1, gPlaceholderIndex = 1, groupCounter = 1;
        string rulesetCondition;

        public FieldManagementDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        #endregion

        #region Get Fields Data
        public IDictionary<string, FieldManagement.FieldInfo> GetFieldsData(int assetId, string fieldType)
        {
            try
            {
                IDictionary<string, FieldManagement.FieldInfo> fieldDataList = new Dictionary<string, FieldManagement.FieldInfo>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetFieldsData, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    // If fieldType is NULL we will get all Fields else only field based on a particular type
                    cmd.Parameters.AddWithValue(DbProcParamFieldType, fieldType);
                    cmd.Parameters.AddWithValue(DbProcParamAssetId, assetId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            FieldManagement.FieldInfo field = new FieldManagement.FieldInfo()
                            {
                                FieldId = Utility.GetInt(reader["FieldId"]),
                                Name = Utility.GetString(reader["FieldName"]),
                                Type = Utility.GetString(reader["DataType"]),
                                Description = Utility.GetString(reader["FieldDescription"])
                            };

                            fieldDataList.Add(Utility.GetString(reader["FieldName"]), field);
                        }
                    }
                    return fieldDataList;
                }
            }
            catch
            {
                throw;
            }
        }
        public IList<FieldFunction> GetFunctions(string loggedInUserName)
        {
            IDictionary<int, FieldFunction> functionsById = new Dictionary<int, FieldFunction>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetCustomFieldFunctionDetail, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamUserName, loggedInUserName);
                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        FieldFunction field = new FieldFunction()
                        {
                            Id = Utility.GetInt(reader["FunctionId"]),
                            Name = Utility.GetString(reader["FunctionName"]),
                            DisplayName = Utility.GetString(reader["FunctionDisplayName"]),
                            NoOfParameter = Utility.GetString(reader["NoOfParameter"]),
                            Formula = Utility.GetString(reader["Formula"]),
                            Description = Utility.GetString(reader["Description"]),
                            DataType = Utility.GetInt(reader["DataTypeId"])
                        };
                        functionsById.Add(field.Id, field);
                    }
                    reader.NextResult();
                }
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        int functionId = Utility.GetInt(reader["FunctionId"]);
                        FieldFunctionParameter param = new FieldFunctionParameter()
                        {
                            ParameterId = Utility.GetInt(reader["FunctionParamMapId"]),
                            ParameterName = Utility.GetString(reader["ParameterName"]),
                            Position = Utility.GetInt(reader["Position"]),
                            DataTypes = Utility.GetString(reader["DataTypes"]),
                            Description = Utility.GetString(reader["Description"]),
                            Entity = Utility.GetInt(reader["EntityRuleTypeId"])
                        };
                        functionsById[functionId].ParamInfo.Add(param);
                    }
                }
                return functionsById.Values.ToList();
            }
        }

        public FieldFunction GetFunctionDetail(int functionId, string loggedInUserName)
        {
            List<FieldFunctionParameter> paramList = new List<FieldFunctionParameter>();
            List<BasicLookUpData> paramRefList = new List<BasicLookUpData>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetCustomFieldFunctionDetail, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamFieldType, functionId);
                cmd.Parameters.AddWithValue(DbProcParamUserName, loggedInUserName);
                SqlDataReader reader = cmd.ExecuteReader();
                ReadFunctionParams(paramList, paramRefList, reader);
                FieldFunction field = new FieldFunction()
                {
                    Id = functionId,
                    ParamInfo = paramList
                };

                return field;
            }
        }

        private static void ReadFunctionParams(List<FieldFunctionParameter> paramList, List<BasicLookUpData> paramRefList, SqlDataReader reader)
        {
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    FieldFunctionParameter param = new FieldFunctionParameter()
                    {
                        ParameterId = Utility.GetInt(reader["FunctionParamMapId"]),
                        ParameterName = Utility.GetString(reader["ParameterName"]),
                        Position = Utility.GetInt(reader["Position"])
                    };
                    paramList.Add(param);
                }
            }
        }

        #endregion

        #region Get Fields Data Type
        public IList<FieldManagement.FieldDataType> GetFieldsDataType()
        {
            try
            {
                IList<FieldManagement.FieldDataType> fieldTypeList = new List<FieldManagement.FieldDataType>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetFieldsDataType, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        fieldTypeList.Add(new FieldManagement.FieldDataType()
                        {
                            TypeId = Utility.GetInt(reader["TypeId"]),
                            Name = Utility.GetString(reader["TypeName"])                            
                        });
                    }
                    return fieldTypeList;
                }
            }
            catch
            {
                throw;
            }
        }
        public IList<BasicLookUpData> GetArithmeticOperators()
        {
            try
            {
                IList<BasicLookUpData> arithOprList= new List<BasicLookUpData>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetArithmeticOperators, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;                    
                    SqlDataReader reader = cmd.ExecuteReader();
                                        
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            BasicLookUpData opr = new BasicLookUpData()
                            {
                                Value = Utility.GetInt(reader["OperatorId"]),
                                Title = Utility.GetString(reader["Operator"])
                            };
                            arithOprList.Add(opr);
                        }                        
                    }
                    return arithOprList;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Save Custom Fields
        public string SaveCustomField(FieldManagement.CustomFieldAttribute customFieldDetail, string userName)
        {
            try
            {
                int rowsInserted = 0;
                dynamic result = null;
                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_SaveCustomField, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(CustomFieldID, customFieldDetail.FieldId);
                    cmd.Parameters.AddWithValue(CustomFieldName, customFieldDetail.Name);
                    cmd.Parameters.AddWithValue(CustomFieldDescription, customFieldDetail.Description);
                    cmd.Parameters.AddWithValue(CustomFieldDataType, customFieldDetail.DataType);
                    cmd.Parameters.AddWithValue(CustomFieldType, customFieldDetail.FieldType);
                    cmd.Parameters.AddWithValue(FieldSubType, customFieldDetail.FieldCustomType);
                    cmd.Parameters.AddWithValue(FieldsUsed, customFieldDetail.FieldsUsed);
                    cmd.Parameters.AddWithValue(CalculatedExpression, customFieldDetail.CalculatedExpression);
                    cmd.Parameters.AddWithValue(CreatedBy, userName);
                    cmd.Parameters.AddWithValue(ModifiedBy, userName);
                    cmd.Parameters.AddWithValue(AssetClassId, customFieldDetail.AssetClass);
                    if (customFieldDetail.FieldId == 0)
                    {
                        cmd.Parameters.AddWithValue(DbConstants.DMLType, DMLType.Insert);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue(DbConstants.DMLType, DMLType.Update);
                    }

                    SqlParameter cmdOutRetVal = new SqlParameter();
                    cmdOutRetVal.ParameterName = ReturnValue;
                    cmdOutRetVal.Direction = ParameterDirection.Output;
                    cmdOutRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutRetVal);

                    SqlParameter cmdOutRetMsg = new SqlParameter();
                    cmdOutRetMsg.ParameterName = ReturnMessage;
                    cmdOutRetMsg.Direction = ParameterDirection.Output;
                    cmdOutRetMsg.SqlDbType = SqlDbType.VarChar;
                    cmdOutRetMsg.Size = 100;
                    cmd.Parameters.Add(cmdOutRetMsg);

                    SqlParameter cmdOutRetCreatedBy = new SqlParameter
                    {
                        ParameterName = ReturnCreatedBy,
                        Direction = ParameterDirection.Output,
                        SqlDbType = SqlDbType.VarChar,
                        Size = 50
                    };
                    cmd.Parameters.Add(cmdOutRetCreatedBy);

                    rowsInserted = cmd.ExecuteNonQuery();
                    result = new
                    {
                        returnCode = Convert.ToInt32(cmdOutRetVal.Value),
                        returnMessage = Convert.ToString(cmdOutRetMsg.Value),
                        returnCreatedBy = Convert.ToString(cmdOutRetCreatedBy.Value)
                    };
                }
                if (result.returnCode > 0 && customFieldDetail.FieldCustomType == 1)
                {
                    SaveBasicArithmeticCondition(customFieldDetail, userName, result);
                }
                else if (result.returnCode > 0 && customFieldDetail.FieldCustomType == 2)
                {
                    SaveBasicFunctionDetails(customFieldDetail, userName, result);

                }
                return JsonConvert.SerializeObject(result);
            }
            catch
            {
                throw;
            }
        }

        private void SaveBasicFunctionDetails(FieldManagement.CustomFieldAttribute customFieldDetail, string userName, dynamic result)
        {
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_SaveBasicFieldFunctionDetails, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                var functionParams = new DataTable();
                functionParams.Columns.Add("key", typeof(string));
                functionParams.Columns.Add("Value", typeof(string));
                foreach (var param in customFieldDetail.BasicFunctionValues.Parameters)
                {
                    functionParams.Rows.Add(param.Name.ToString(), param.Value.ToString());
                }
                cmd.Parameters.AddWithValue(CustomFieldID, result.returnCode);
                cmd.Parameters.AddWithValue(CreatedBy, userName);
                cmd.Parameters.AddWithValue(ModifiedBy, userName);
                cmd.Parameters.AddWithValue("@FunctionName", customFieldDetail.BasicFunctionValues.FunctionName);
                cmd.Parameters.AddWithValue("@ParamList", functionParams);
                cmd.ExecuteNonQuery();
            }
        }

        private void SaveBasicArithmeticCondition(FieldManagement.CustomFieldAttribute customFieldDetail, string userName, dynamic result)
        {
            IList<QueryExpressionRule> fieldRules = ConvertStructureToDatatable(customFieldDetail.ArithmeticQueryStructure);
            DataTable dtRules = ToDataTable<QueryExpressionRule>(fieldRules);
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetSaveBasicArithmeticCondition, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue(CustomFieldID, result.returnCode);
                cmd.Parameters.AddWithValue(CreatedBy, userName);
                cmd.Parameters.AddWithValue(ModifiedBy, userName);
                cmd.Parameters.AddWithValue(RuleList, dtRules);
                cmd.ExecuteNonQuery();
            }
        }

        private IList<QueryExpressionRule> ConvertStructureToDatatable(string jsonText)
        {
            JObject json = JObject.Parse(jsonText);
            //Get first(root) condition value
            rulesetCondition = (string)json.First;

            var resultObjects = AllChildren(JObject.Parse(jsonText))
           .First(c => c.Type == JTokenType.Array && c.Path.Contains("rules"))
           .Children<JObject>();

            //Calling ParseJs function for main iteration
            ParseJs(resultObjects, 0, 1, rulesetCondition, 1);
            return lstRules;
        }
        public void ParseJs(dynamic resultObjects, int counterPlaceHolder, int preGIndex = 1, string rsCondition = "", int isFirstIteration = 0)
        {
            foreach (JObject result in resultObjects)
            {
                QueryExpressionRule rule = null;

                //Insert ruleset condition in case of previous groups, to comply with recurion calls backtracking
                if (rsCondition != "") rulesetCondition = rsCondition;

                //If Ruleset(RG) added first in root, then add invisible rule(R) with condition 
                if (isFirstIteration == 1 && result.ContainsKey("condition") == true)
                {
                    InsertRuleObjectIntoList(rule);
                }
                //Only applicable for first iteration(in case of RG added first in root)
                isFirstIteration = 0;

                //Not applicable if added result(R) First, applicable in case of further rulesets to set 'condition' value in both cases i.e. blank RG or RG with rules
                if (result.ContainsKey("condition") == true)
                {
                    result.TryGetValue("condition", out JToken jToken);
                    rulesetCondition = jToken.ToString();
                }
                else
                    rule = new QueryExpressionRule();

                foreach (JProperty property in result.Properties())
                {
                    if (property.Name == "id") rule.FieldId = Convert.ToInt32(property.Value);
                    if (property.Name == "field") rule.FieldName = Convert.ToString(property.Value);
                    if (property.Name == "operator") rule.Operator = Convert.ToString(property.Value);
                    if (property.Name == "entity") rule.RuleType = Convert.ToInt16(property.Value);
                    if (property.Name == "value") rule.RuleValue = FormatValueIfArray(rule.Operator, Convert.ToString(property.Value));

                    if (property.Name == "rules")
                    {
                        var resultObjects1 = AllChildren(JObject.Parse(result.ToString()))
                                            .First(c => c.Type == JTokenType.Array && c.Path.Contains("rules"))
                                            .Children<JObject>();

                        counterPlaceHolder = counterPlaceHolder + 1;
                        parentIndex = pPlaceholderIndex;
                        groupIndex = gPlaceholderIndex + 1;

                        groupCounter = groupCounter + 1;
                        pPlaceholderIndex = groupCounter;
                        gPlaceholderIndex = groupCounter;

                        //To add invisible rules with condition & indexes, if blank rulesets added -in all cases i.e. (RG) or (R)
                        foreach (JObject result1 in resultObjects1)
                        {
                            if (result1.ContainsKey("condition") == true)
                            {
                                InsertRuleObjectIntoList(rule);
                                break;
                            }
                            else
                                break;
                        }

                        ParseJs(resultObjects1, counterPlaceHolder, groupIndex, rulesetCondition);

                        pPlaceholderIndex = preGIndex;
                        //This should only be in case of rule added last(out of order)
                        parentIndex = pPlaceholderIndex - 1;
                        groupIndex = preGIndex;

                    }
                }
                if (rule != null)
                {
                    rule.Condition = rulesetCondition;
                    rule.ParentIndex = parentIndex;
                    rule.GroupIndex = groupIndex;
                    rule.RuleIndex = ruleIndex;
                    lstRules.Add(rule);

                    rule = null;
                }

                if (result.Next == null)
                {
                    break;
                }
                ruleIndex++;
            }
        }
        //Insert Field object into List
        private void InsertRuleObjectIntoList(QueryExpressionRule rule)
        {
            rule = new QueryExpressionRule
            {
                Condition = rulesetCondition,
                ParentIndex = parentIndex,
                GroupIndex = groupIndex,
                RuleIndex = ruleIndex

            };
            lstRules.Add(rule);
            rule = null;
        }
        //Recursively yield all children of json body
        private IEnumerable<JToken> AllChildren(JToken json)
        {
            foreach (var child in json.Children())
            {
                yield return child;
                foreach (var nestedChild in AllChildren(child))
                {
                    yield return nestedChild;
                }
            }
        }
        private string FormatValueIfArray(string entityOperator, string value)
        {
            if (entityOperator != null && (entityOperator.ToLower() == "in" || entityOperator.ToLower() == "not in" || entityOperator.ToLower() == "between"))
            {
                value = Regex.Replace(Convert.ToString(value).Replace(System.Environment.NewLine, string.Empty), @"\s+", " ");
            }
            return value;
        }
        private DataTable ToDataTable<T>(IList<T> ecRules)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the Properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in ecRules)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
        #endregion

        #region Amend Custom Field
        public int AmendCustomField(FieldManagement.CustomFieldAttribute customFieldAttribute, string userName)
        {
            int returnCode;
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_AmendCustomField, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(CustomFieldID, customFieldAttribute.FieldId);               
                cmd.Parameters.AddWithValue(CustomFieldDescription, customFieldAttribute.Description);
                cmd.Parameters.AddWithValue(DbProcParamComment, customFieldAttribute.SaveComment);
                cmd.Parameters.AddWithValue(ModifiedBy, userName);
                cmd.Parameters.AddWithValue(ModifiedDate, customFieldAttribute.ModifiedDate);
                

                SqlParameter cmdOutRetVal = new SqlParameter
                {
                    ParameterName = DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutRetVal);
                cmd.ExecuteNonQuery();
                returnCode = Convert.ToInt32(cmdOutRetVal.Value);
                return returnCode;
            }
        }
        #endregion

        #region Get Custom Field Detail
        public FieldManagement.CustomFieldDetail GetCustomFieldDetail(int fieldId)
        {
            try
            {
                FieldManagement.CustomFieldDetail objCustomFieldDetail = new FieldManagement.CustomFieldDetail();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetCustomFieldDetail, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(CustomFieldID, fieldId);

                    SqlDataReader reader;
                    using (reader = cmd.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                objCustomFieldDetail.Name = Utility.GetString(reader["Name"]);
                                objCustomFieldDetail.Description = Utility.GetString(reader["Description"]);
                                objCustomFieldDetail.DataType = Utility.GetInt(reader["DataType"]);
                                objCustomFieldDetail.FieldType = Utility.GetInt(reader["FieldType"]);
                                objCustomFieldDetail.FieldCustomType = Utility.GetInt(reader["FieldCustomType"]);
                                objCustomFieldDetail.FieldsUsed = Utility.GetString(reader["FieldsUsed"]);
                                objCustomFieldDetail.CalculatedExpression = Utility.GetString(reader["CalculatedExpression"]);
                                objCustomFieldDetail.CreatedBy = Utility.GetString(reader["CreatedBy"]);
                                objCustomFieldDetail.FieldStatusId = Utility.GetInt(reader["FieldStatusId"]);
                                objCustomFieldDetail.FieldStatus = Utility.GetString(reader["Status"]);
                                objCustomFieldDetail.CommentsBySubmitter = Utility.GetString(reader[DbFieldCommentsBySubmitter]);
                                objCustomFieldDetail.CommentsByAuthoriser = Utility.GetString(reader[DbFieldCommentsByAuthoriser]);

                            }
                            if (objCustomFieldDetail.FieldCustomType == 1)
                            {
                                objCustomFieldDetail.FieldExpressionDetails = GetBasicArithmeticExpression(fieldId).ToList();
                            } 
                            else if (objCustomFieldDetail.FieldCustomType == 2)
                            {
                                objCustomFieldDetail.BasicFunctionValues = GetBasicFunctionDetail(fieldId);

                            }
                        }
                        else
                        {
                            return objCustomFieldDetail;
                        }

                        reader.NextResult();

                        if (reader.HasRows)
                        {
                            //Populate comments history with date and action
                            while (reader.Read())
                            {
                                CommentsHistory objCommentsHistory = new CommentsHistory();
                                objCommentsHistory.CommentsDate = Utility.ConvertUTCToUKTime(Convert.ToString(reader[DbFieldCommentsDate]));
                                objCommentsHistory.CommentsAction = Convert.ToString(reader[DbFieldCommentAction]);
                                objCommentsHistory.Comments = Convert.ToString(reader[DbFieldComments]);
                                objCustomFieldDetail.CommentsHistory.Add(objCommentsHistory);
                            }
                        }

                    }
                    return objCustomFieldDetail;
                }
            }
            catch
            {
                throw;
            }
        }

        private FunctionValue GetBasicFunctionDetail(int fieldId)
        {
            FunctionValue functionValue = new FunctionValue();
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetBasicFieldFunctionDetail, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(CustomFieldID, fieldId);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    functionValue.FunctionName = Utility.GetString(reader["FunctionName"]);
                }
                reader.NextResult();
                while (reader.Read())
                {
                    functionValue.Parameters.Add(new ParameterValue()
                    {
                        Name = Utility.GetString(reader["Name"]),
                        Value = Utility.GetString(reader["Value"])
                    });
                }
                return functionValue;
            }
        }

        public IList<QueryExpressionDetail> GetBasicArithmeticExpression(int fieldId)
        {
            IList<QueryExpressionDetail> basicFieldExpressionList = new List<QueryExpressionDetail>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetBasicArithmeticExpressionDetail, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(CustomFieldID,fieldId);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {

                    basicFieldExpressionList.Add(new QueryExpressionDetail()
                    {
                        Id = Utility.GetInt(reader["Id"]),
                        RuleIndex = Utility.GetInt(reader["RuleIndex"]),
                        GroupIndex = Utility.GetInt(reader["GroupIndex"]),
                        ParentIndex = Utility.GetInt(reader["ParentIndex"]),
                        Operator = Utility.GetString(reader["Operator"]),
                        Entity = Utility.GetInt(reader["Entity"]),
                        Condition = Utility.GetString(reader["Condition"]),
                        Value = Utility.GetString(reader["Value"])
                    });
                }
                return basicFieldExpressionList;
            }
        }

        #endregion
        public IList<Field> GetFields(int assetId, string loggedInUserName)
        {
            IList<Field> fields = new List<Field>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetAllFields, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(UserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbProcParamAssetId, assetId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    fields.Add(new Field()
                    {
                        FieldID = Utility.GetInt(reader[DbField_FieldId]),
                        FieldMapping = Utility.GetString(reader[DbField_FieldMapping]),
                        Name = Utility.GetString(reader[DbField_FieldName]),
                        Description = Utility.GetString(reader[DbField_FieldDescription]),
                        Source = Utility.GetString(reader[DbField_FieldSource]),
                        Status = Utility.GetString(reader[DbField_FieldStatus]),
                        FieldType = Utility.GetString(reader[DBField_FieldType]),
                        CreatedBy = Utility.GetString(reader[DbField_FieldCreatedBy]),
                        CreatedDate = Utility.GetDateTimeNullable(reader[DbFieldCreatedDate]),
                        ModifiedDate = Utility.GetDateTimeNullable(reader[DbFieldModifiedDate])
                    });
                }
            }
            return fields;
        }


        public int DeleteField(int fieldId, string loggedInUserName)
        {
            int rowsAffected = 0;

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_DeleteField, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(FieldId, fieldId);
                cmd.Parameters.AddWithValue(UserName, loggedInUserName);                                
                rowsAffected = cmd.ExecuteNonQuery();
            }
            return rowsAffected;
        }

        public IList<EligibilityCriteriaAttributes> GetECByField(int fieldId, string loggedInUserName)
        {
            IList<EligibilityCriteriaAttributes> elibilityCriterias = new List<EligibilityCriteriaAttributes>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetFieldECList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamRefFieldId, fieldId);
                cmd.Parameters.AddWithValue(DbProcParamUserName, loggedInUserName);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    elibilityCriterias.Add(new EligibilityCriteriaAttributes()
                    {
                        ECID = Utility.GetInt(reader["EligibilityCriteriaId"]),
                        Name = Utility.GetString(reader["Name"])
                    });
                }
            }
            return elibilityCriterias;
        }

        public int UpdateECsOnFieldChange(FieldRename fieldNameChangeModel, string loggedInUserName)
        {
            int rowsAffected = 0;
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_SupportCriteriaFieldRename, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamFromName, string.IsNullOrEmpty(fieldNameChangeModel.CurrentName) ? string.Empty : fieldNameChangeModel.CurrentName);
                cmd.Parameters.AddWithValue(DbProcParamToName, string.IsNullOrEmpty(fieldNameChangeModel.NewName) ? string.Empty : fieldNameChangeModel.NewName);
                cmd.Parameters.AddWithValue(DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbProcParamFromCriteriaFieldDescription, string.Empty);
                cmd.Parameters.AddWithValue(DbProcParamToCriteriaFieldDescription, string.Empty);
                rowsAffected = cmd.ExecuteNonQuery();
            }
            return rowsAffected;
        }

    }
}