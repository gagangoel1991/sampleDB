﻿namespace NW.SFP.DataService
{
    public static partial class DbConstants
    {
        #region "DB Stored Procedures and Parameters"

        #region "Pool SP"
        public const string SP_Pool_GetList = "[ps].[spGetPoolList]";
        public const string SP_Pool_Delete = "[ps].[spDeletePool]";
        public const string SP_Pool_GetById = "[ps].[spGetPoolById]";
        public const string SP_Pool_GetAccountsById = "[ps].[spGetPoolAccountsById]";
        public const string SP_Pool_GetPoolAccountDates = "[ps].[spGetPoolAccountDates]";
        public const string SP_Pool_GetInclusionReasons = "[corp].[spGetCherryPickInclusionReasons]";
        public const string SP_Pool_GetSourceDealSummaryById = "[ps].[spGetPoolSourceDealSummaryById]";
        public const string SP_Pool_CreatePool = "[ps].[spCreatePool]";
        public const string SP_Pool_UpdatePoolAccounts = "[ps].[spUpdatePoolAccounts]";
        public const string SP_Pool_InsertPoolStandardSourcing = "[ps].[spInsertPoolStandardSourcing]";
        public const string SP_Pool_UpdatePool = "[ps].[spUpdatePool]";
        public const string SP_Pool_GetPoolReferenceData = "[ps].[spGetPoolReferenceData]";
        public const string SP_Pool_BuildPool = "ps.[spBuildPool]";
        public const string SP_Corporate_Pool_BuildPool = "[corp].[spBuildPoolCorporate]";
        public const string SP_Pool_GetPoolDataForExport = "[ps].[spGetPoolDataForExport]";
        public const string SP_Pool_ValidateUploadAssets = "[ps].[spValidateUploadAssets]";
        public const string SP_Pool_ValidateDrillThroughReport = "[ps].[spValidateDrillThroughReport]";
        public const string SP_Pool_ValidateSubmitAndUpdatePool = "[ps].[spValidateSubmitAndUpdatePool]";
        public const string SP_Pool_GetBrandList = "[ps].[spGetBrandList]";
        public const string SP_Pool_Reject = "[ps].[spRejectPool]";
        public const string SP_Pool_Authorise = "[ps].[spAuthorisePool]";
        public const string SP_Pool_GetDependentPools = "[ps].[spGetDependentPools]";
        public const string SP_Pool_ValidateSubmittedLoans = "[ps].[spValidateSubmittedLoans]";
        public const string SP_Pool_ValidateExclusionChangeImpact = "[ps].[spValidateExclusionChangeImpact]";
        public const string SP_Pool_GetPoolRegionWithHoliday = "[ps].[spGetPoolRegionWithHoliday]";
        public const string SP_Pool_GetPoolSourceDeals = "[ps].[spGetPoolSourceDeals]";
		public const string SP_Pool_ValidateSubmittedEntities = "[ps].[spValidateSubmittedEntities]";
        #endregion

        #region "Pool SP Param"
        public const string DbProcParamPoolId = "@pPoolId";
        public const string DbProcParamPDealId = "@pDealID";
        public const string DbProcParamReturnSourceDealsOnly = "@pReturnSourceDealsOnly";
        public const string DbProcParamUserName = "@pUserName";
        public const string DbProcParamAssetId = "@pAssetId";
        public const string DbProcParamVintageDate = "@vintageDate";
        public const string DbProcParamPrevExpoDate = "@prevDate";
        public const string DbProcParamForTopupDisplayPurpose = "@ForTopupDisplayPurpose";

        public const string DbProcParamPBPoolId = "@PoolId";
        public const string DbProcParamPBUserName = "@UserName";
        public const string DbProcParamPBReturnValue = "@ReturnValue";

        public const string DbProcParamDuplicateReturnCode = "@pDuplicateReturnCode";
        public const string DbProcParamPoolName = "@pName";
        public const string DbProcParamPoolDescription = "@pDescription";
        public const string DbProcParamPoolLimit = "@pLimit";
        public const string DbProcParamPoolVintageDate = "@pVintageDate";
        public const string DbProcParamPoolPurposeId = "@pPoolPurposeId";
        public const string DbProcParamPoolApplyExclusion = "@pPoolApplyExclusion";
        public const string DbProcParamPoolTargetPoolId = "@pTargetPoolId";
        public const string DbProcParamPoolReasonId = "@pPoolReasonId";
        public const string DbProcParamPoolLimitAnalysisFieldId = "@pPoolLimitAnalysisFieldId";
        public const string DbProcParamPoolRandomSelectionId = "@pRandomSelectionId";
        public const string DbProcParamPoolStatusId = "@pPoolStatusId";
        public const string DbProcParamPoolAssetClassId = "@pAssetClassId";
        public const string DbProcParamPoolSourcePool = "@pSourcePool";
        public const string DbProcParamPoolLinkedEC = "@pLinkedEC";
        public const string DbProcParamPoolAdvanceSourcePool1 = "@pAdvanceSourcePool1";
        public const string DbProcParamPoolAdvanceSourcePool2 = "@pAdvanceSourcePool2";
        public const string DbProcParamPoolSourcingType = "@pSourcingType";
        public const string DbProcParamPoolUploadAssets = "@pUploadAssets";
        public const string DbProcParamPoolUploadFileName = "@pUploadFileName";
        public const string DbProcParamPoolBrands = "@pBrands";
        public const string DbProcParamPoolInclusionList = "@pInclusionList";
        public const string DbProcParamPoolInclusionFileName = "@pInclusionFileName";
        public const string DbProcParamReturnCode = "@pReturnCode";
        public const string DbProcParamEffectiveDate = "@pEffectiveDate";
        public const string DbProcParamNoticeDate = "@pNoticeDate";
        public const string DbProcParamIsPoolStateNeedsChange = "@pIsPoolStateNeedsChange";
        public const string DbProcParamPoolDealTypeId = "@pDealTypeId";
        public const string DbProcParamPoolIpdFrequencyId = "@pIpdFrequencyTypeId";
        public const string DbProcParamPoolLinkedCT = "@pLinkedCT";
        public const string DbProcParamPoolModifiedDate = "@pModifiedDate";
        public const string DbProcParamPoolInclusionOption = "@poolInclusionOption";
        public const string DbProcParamPoolIncludedExclusions = "@poolExclusionException";
        public const string DbProcParamApplicableECMethod = "@pApplicableECMethod";
        public const string DbProcParamIsBalanceUploaded = "@pIsBalanceUploaded";
        public const string DbProcParamUploadedAssetsData = "@pUploadedAssetsData";
        #endregion


        #endregion

        #region "DB Custom Types"

        public const string DbTypeIntList = "[ps].[IntList]";
        public const string DbTypeBigIntList = "[ps].[BigIntList]";
        public const string DbTypeIntListIntValue = "intValue";
        public const string DbTypeLookupTitleValue = "[ps].[LookupTitleValue]";
        public const string DbTypeLookupTitleValue_Title = "Title";
        public const string DbTypeLookupTitleValue_Value = "Value";
        public const string DbTypeAdhochReportField = "[ps].[AdhocReportFieldDetail]";
        public const string DbTypeAdhochReportField_Id = "FieldId";
        public const string DbTypeAdhochReportField_OrderId = "FieldOrderId";
        public const string DbTypeAdhochReportField_DisplayName = "DisplayFieldName";
        public const string DbTypeCriteriaFieldTable = "CriteriaFieldTable";
        public const string DbTypeLevel = "FieldLevel";
        public const string DbTypeCherryPickFacilityList = "corp.CherryPickFacilityList";
        public const string DbTypeAdhocReportTypeId = "AdhocReportTypeId";
        public const string DbTypeAdhocReportTypeName = "ReportTypeName";
        public const string DbTypeAdhocReportTypeDescription = "Description";
        public const string DbTypeLoanNumber = "LoanNumber";
        public const string DbTypeLoanBalance = "LoanBalance";

        #endregion

        #region "Pool Fields"

        public const string DbFieldPoolListId = "PoolId";
        public const string DbFieldPoolListName = "PoolName";
        public const string DbFieldPoolListLimit = "PoolLimit";
        public const string DbFieldPoolListStatus = "PoolStatus";
        public const string DbFieldPoolListPurpose = "PoolPurpose";
        public const string DbFieldPoolListVintageDate = "PoolVintageDate";
        public const string DbFieldPoolListCreatedBy = "PoolCreatedBy";
        public const string DbFieldPoolListAuthorizedBy = "PoolAuthorizedBy";

        #endregion

        #region "Pool Field Constants"

        public const string DbFieldPoolId = "Id";
        public const string DbFieldPoolName = "Name";
        public const string DbFieldPoolDescription = "Description";
        public const string DbFieldPoolLimit = "Limit";
        public const string DbFieldPoolVintageDate = "VintageDate";
        public const string DbFieldPoolPurposeId = "PurposeId";
        public const string DbFieldPoolApplyExclusion = "ApplyExclusion";
        public const string DbFieldPoolTargetPoolId = "TargetPoolId";
        public const string DbFieldPoolReasonId = "PoolReasonId";
        public const string DbFieldPoolLimitAnalysisFieldId = "PoolLimitAnalysisFieldId";

        public const string DbFieldPoolStatusId = "StatusId";
        public const string DbFieldPoolStatus = "Status";
        public const string DbFieldPoolPurpose = "Purpose";

        public const string DbFieldPoolTrueBalance = "TrueBalance";
        public const string DbFieldPoolCapitalBalance = "CapitalBalance";
        public const string DbFieldBalance = "Balance";
        public const string DbFieldPoolBuiltDate = "BuiltDate";
        public const string DbFieldPoolBuiltBy = "BuiltBy";

        public const string DbFieldPoolNumberOfAccount = "NumberOfAccount";
        public const string DbFieldPoolNumberOfSubAccount = "NumberOfSubAccount";
        public const string DbFieldPoolSelectedLoanPercentage = "SelectedLoanPercentage";
        public const string DbFieldPoolPrincipleBalancePercentage = "PrincipleBalancePercentage";
        public const string DbFieldPoolRefreshDate = "RefreshDate";
        public const string DbFieldPoolCurrentPoolAmount = "CurrentPoolAmount";
        public const string DbFieldPoolRandomSelection = "RandomSelection";
        public const string DbFieldPoolCreatedDate = "CreatedDate";
        public const string DbFieldPoolCreatedBy = "CreatedBy";
        public const string DbFieldPoolAuthorizedDate = "AuthorizedDate";
        public const string DbFieldPoolAuthorizedBy = "AuthorizedBy";

        public const string DbFieldPoolModifiedBy = "ModifiedBy";
        public const string DbFieldPool_LinkedSourcePoolId = "SourcePoolId";
        public const string DbFieldPool_LinkedEcId = "EligibilityId";

        public const string DbFieldPoolSourcingType = "SourcingType";
        public const string DbFieldPoolUploadedFileName = "UploadedFileName";

        public const string DbFieldPoolInclusionLoanNumber = "LoanNumber";
        public const string DbFieldPoolInclusionFileName = "InclusionFileName";
        public const string DbFieldPoolDependentPoolId = "DependentPoolId";
        public const string DbFieldPoolIsRebuildRequired = "IsRebuildRequired";
        public const string DbFieldPoolIsPoolBuildInProgress = "IsPoolBuildInProgress";
        public const string DbFieldPoolMatchedLoanId = "MatchedLoanId";
        public const string DbFieldPoolInvalidLoanId = "LoanId";
        public const string DbFieldPoolNoDealLoanCount = "NodealLoanCount";
        public const string DbFieldPoolInvalidReason = "Reason";
        public const string DbFieldPoolSourceDeals = "SourceDeals";
        public const string DbFieldPoolEffectiveDate = "EffectiveDate";
        public const string DbFieldPoolNoticeDate = "NoticeDate";
        public const string DbFieldPoolDealTypeId = "DealTypeId";
        public const string DbFieldPoolIpdFrequencyId = "IpdFrequencyId";

        public const string DbFieldPoolAccountFacilityId = "FacilityId";
        public const string DbFieldPoolAccountEligibilityCriteria = "EligibilityCriteria";
        public const string DbFieldPoolAccountDealId = "DealId";
        public const string DbFieldPoolAccountFacilityType = "FacilityType";
        public const string DbFieldPoolAccountCis = "CIS";
        public const string DbFieldPoolAccountMgs = "MasterGradingScore";
        public const string DbFieldPoolAccountCommittedExposure = "CommittedExposure";
        public const string DbFieldPoolAccountPreviousExposure = "PreviousExposure";
        public const string DbFieldPoolAccountFacilityStartDate = "FacilityStartDate";
        public const string DbFieldPoolAccountExpiryDate = "ExpiryDate";
        public const string DbFieldPoolAccountPrevExpiryDate = "PreviousExpiryDate";
        public const string DbFieldPoolAccountPrevMgs = "PreviousMasterGradingScore";
        public const string DbFieldPoolAccountMaturityDate = "MaturityDate";
        public const string DbFieldPoolAccountPDMidPoint = "PDMidPoint";
        public const string DbFieldUtilisationGBP = "UtilisationGBP";
        public const string DbFieldPoolAccountNumberOfDaysInArrears = "NumberOfDaysInArrears";
        public const string DbFieldPoolAccountPreviousReasonId = "PreviousReasonId";
        public const string DbFieldPoolAccountCurrentReasonId = "CurrentReasonId";
        public const string DbFieldPoolAccountPreviousValue = "PreviousReasonValue";
        public const string DbFieldPoolAccountCurrentValue = "CurrentReasonValue";
        public const string DbFieldPoolAccountPreviousId = "PreviousReasonId";
        public const string DbFieldPoolAccountCurrentId = "CurrentReasonId";
        public const string DbFieldPoolAccountIsActive = "IsActive";
        public const string DbFieldPoolAccountInclusionId = "InclusionId";
        public const string DbFieldPoolAccountInclusionValue = "InclusionValue";
        public const string DbFieldPoolAccountPrevExpoDate = "PreviousExposureDate";

        public const string DbFieldPoolExclusionChangeIsImpacted = "IsImpacted";
        public const string DbFieldPoolExclusionChangeImpactedLoanId = "LoanId";
        public const string DbFieldPoolRegion = "Region";

        public const string DbFieldPoolAssetClassId = "AssetClassId";
        public const string DbFieldPoolAssetClassName = "AssetClassName";

        public const string DbFieldApplicableECMethod = "ApplicableECMethod";
		public const string DbFieldPoolLastFlagDeFlagDate = "LastFlagDeFlagDate";

        public const string DbFieldPoolIsBalanceUploadeded = "IsBalanceUploaded";
        #endregion

        #region Pool Source Deal Summary
        public const string DbFieldPoolSummaryDealName = "DealName";
        public const string DbFieldPoolSummaryNumberOfAccounts = "NumberOfAccounts";
        public const string DbFieldPoolSummaryNumberOfSubAccounts = "NumberOfSubAccounts";
        public const string DbFieldPoolSummaryBalance = "Balance";
        #endregion

        #region Comments History
        public const string DbFieldCommentsBySubmitter = "CommentsBySubmitter";
        public const string DbFieldCommentsByAuthoriser = "CommentsByAuthoriser";

        public const string DbProcParamCommentsBySubmitter = "@pCommentsBySubmitter";
        public const string DbProcParamPoolCommentsByAuthoriser = "@pCommentsByAuthoriser";

        public const string DbFieldCommentsDate = "CommentsDate";
        public const string DbFieldCommentAction = "CommentsAction";
        public const string DbFieldComments = "Comments";
        #endregion

        #region Ref Data

        public const string DbFieldRefDataId = "Id";
        public const string DbFieldRefDataName = "Name";


        #endregion

        #region Lookup Data

        public const string DbFieldLookupDataValue = "Value";
        public const string DbFieldLookupDataBalance = "Balance";
        public const string DbFieldLookupDataTitle = "Title";
        public const string DbFieldLookupDataAuthorised = "Authorised";
        public const string DbFieldLookupDescription = "FieldDescription";
        public const string DbFieldLookupDataTypeId = "FieldDataType";


        #endregion

        #region Advance Source Data

        public const string DbFieldAdvanceSourceId = "Id";
        public const string DbFieldAdvanceSourceType = "SourcePoolType";


        #endregion

        #region Deal Lookup Data

        public const string DbFieldDeal_MortgageDealKey = "MortgageDealKey";
        public const string DbFieldDeal_Deal_DealName = "DealName";
        public const string DbFieldDeal_DealPublicName = "DealPublicName";
        public const string DbFieldDeal_DealType = "DealType";
        public const string DbFieldDeal_DealStatus = "DealStatus";
        public const string DbFieldDeal_DealKey = "DealKey";
        public const string DbFieldDeal_DealCaluclatedBasedOn = "DealCalculatedBasedOn";

        #endregion

        #region Pool Inclusion Options

        public const string DbFieldPoolOptionDescription = "Description";
        public const string DbFieldPoolInclusionOption = "PoolInclusionOptionId";
        public const string DbFieldPoolIncludedExclusions = "PoolExclusionException";

        #endregion

        #region Eligibility Crteria
        #region Stored Procedures
        public const string SP_GetEligibilityFields = "ps.spGetEligibilityFields";
        public const string SP_GetEntityRuleType = "ps.spGetEntityRuleType";
        public const string SP_GetEntityRuleFieldOption = "ps.spEntityRuleFieldOption";
        public const string SP_GetEntityRuleOperators = "ps.spGetEntityRuleOperators";
        public const string SP_GetEligibilityRegulation = "ps.spGetEligibilityRegulation";
        public const string SP_GetEligibilityType = "ps.spGetEligibilityType";
        public const string SP_GetAssetClass = "ps.spGetAssetClass";
        public const string SP_SaveEligibilityCriteria = "ps.spSaveEligibilityCriteria";
        public const string SP_AmendEligibilityCriteria = "ps.spAmendEligibilityCriteria";
        public const string SP_GetFieldLookupData = "ps.spGetFieldLookupData";
        public const string SP_GetEligibilityCriteriaDetail = "ps.spGetEligibilityCriteriaDetail";
        public const string SP_GetEligibilityCriteriaExpressionDetail = "ps.spGetEligibilityCriteriaExpressionDetail";
        public const string SP_GetEligibilityFieldInfo = "ps.spGetEligibilityFieldInfo";
        public const string SP_EligibilityCriteria_GetList = "ps.spGetEligibilityCriteriaList";
        public const string SP_EligibilityCriteria_Delete = "[ps].[spDeleteEligibility]";
        public const string SP_ValidateEcFields = "[ps].[spValidateEcFields]";
        #endregion

        #region Stored Procedure Parameters
        public const string ECID = "@ECID";
        public const string ECName = "@Name";
        public const string ECDescription = "@Description";
        public const string ECTypeId = "@TypeId";
        public const string ApplicableAt = "@ApplicableAt";
        public const string AssetClassId = "@AssetClassId";
        public const string AssetClassIdInput = "@pAssetId";
        public const string RuleList = "@RuleList";
        public const string EligibilityExpression = "@ECExpression";
        public const string ECStatus = "@ECStatus";

        public const string FieldId = "@FieldId";

        public const string TemplateName = "@TemplateName";
        public const string FieldName = "@FieldName";
        public const string DbProcParamEcId = "@pEligibilityCriteriaId";
        public const string DbProcParamLinkedReturnCode = "@pLinkedReturnCode";
        public const string DbProcParamReportTypeId = "@pReportType";
        public const string DbProcParamEligibilityCriteriaId = "@pEligibilityCriteriaId";
        public const string DbProcParamEligibilityCriteriaIdIsReject = "@pIsReject";

        public const string DbProcParamEcName = "@pName";
        public const string DbProcParamEcDescription = "@pDescription";
        public const string DbProcParamEcTypeId = "@pTypeId";
        public const string DbProcParamEcModifiedBy = "@pModifiedBy";
        public const string DbProcParamEcModifiedDate = "@pModifiedDate";
        public const string DealId = "@DealId";
        public const string DbProcParamDealKey = "@dealKey";

        #endregion

        #region Generic Stored Procedure Parameters
        public const string DMLType = "@DMLType";
        public const string ReturnValue = "@ReturnValue";
        public const string ReturnCreatedBy = "@ReturnCreatedBy";
        public const string ReturnMessage = "@ReturnMessage";
        public const string CreatedBy = "@CreatedBy";
        public const string ModifiedBy = "@ModifiedBy";
        public const string ModifiedDate = "@ModifiedDate";
        #endregion

        #region "EC List Fields"

        public const string DbFieldEcListId = "Id";
        public const string DbFieldEcListName = "Name";
        public const string DbFieldEcListExpression = "Expression";
        public const string DbFieldEcListTag = "Tag";
        public const string DbFieldEcListPassCriteria = "PassCriteria";
        public const string DbFieldEcListStatus = "Status";
        public const string DbFieldEcListCreatedBy = "CreatedBy";
        public const string DbFieldEcListIsLinked = "IsLinked";
        public const string DbFieldEcListPoolCount = "PoolCount";
        #endregion

        #endregion

        #region Concentration Management
        #region Stored Procedures
        public const string SP_CT_GetConcentrationReferenceData = "[ps].[spGetConcentrationReferenceData]";
        public const string SP_CT_GetConcentrationFields = "[ps].[spGetConcentrationFields]";
        public const string SP_CT_GetConcentrationFieldRefData = "[ps].[spGetConcentrationFieldReferenceData]";
        public const string SP_CT_SaveConcentration = "[ps].[spSaveConcentration]";
        public const string SP_AmendConcentration = "[ps].[spAmendConcentration]";
        public const string SP_GetConcentrationTestList = "[ps].[spGetConcentrationTestList]";
        public const string SP_DeleteConcentrationTestList = "[ps].[spDeleteConcentrationTest]";
        public const string SP_GetConcentrationTestDetail = "[ps].[spGetConcentrationTestDetail]";
        #endregion

        #region Stored Procedure Parameters
        public const string DBProcParamConcTestId = "@pConcentrationTestId";
        public const string DbProcParamType = "@pType";
        public const string DbProcParamRefFieldId = "@pFieldId";
        public const string DbProcParamCtId = "@pCtId";
        public const string DbProcParamCtName = "@pCtName";
        public const string DbProcParamCtDescription = "@pCtDescription";
        public const string DbProcParamCtType = "@pCtType";
        public const string DbProcParamCtTag = "@pCtTag";
        public const string DbProcParamCtStatus = "@pCtStatus";
        public const string DbProcParamCtAssetType = "@pCtAssetType";
        public const string DbProcParamCtConditionalOperator = "@pCtCriteriaFieldOperator";
        public const string DbProcParamCtConditionalValue = "@pCtExpectedValue";
        public const string DbProcParamCtLimitOperator = "@pCtLimitOperator";
        public const string DbProcParamCtLimitPercentage = "@pCtLimitPercentage";
        public const string DbProcParamCtExpression = "@pCtExpression";
        public const string DbProcParamCtExpressionSuperset = "@pCtExpressionSuperSet";
        public const string DbProcParamCtDMLType = "@pDMLType";
        public const string DbProcParamCtUserName = "@pUserName";
        public const string DbProcParamCtReturnValue = "@pReturnValue";
        public const string DbProcParamCtReturnMessage = "@pReturnMessage";
        public const string DbProcParamFromName = "@pFromCriteriaFieldName";
        public const string DbProcParamToName = "@pToCriteriaFieldName";
        public const string DbProcParamFromCriteriaFieldDescription = "@pFromCriteriaFieldDescription";
        public const string DbProcParamToCriteriaFieldDescription = "@pToCriteriaFieldDescription";
        public const string DbProcParamCtModifiedDate = "@pModifiedDate";
        public const string DbProcParamCTConditionsSuperset = "@pCTConditionsSuperset";
        public const string DbProcParamCTConditionsSubset = "@pCTConditionsSubset";
        public const string DbProcParamCTpIsSubSetReq = "@pIsSubSetReq";

        #endregion

        #region "Concentration Test List Fields"

        public const string DbFieldConcTestListId = "Id";
        public const string DbFieldConcTestListName = "Name";
        public const string DbFieldConcTestListDescription = "Description";
        public const string DbFieldConcTestListAssetClass = "AssetClass";
        public const string DbFieldConcTestListFieldId = "FieldId";
        public const string DbFieldConcTestListConditionalOperator = "ConditionalOperator";
        public const string DbFieldConcTestListConditionalValue = "ConditionalValue";
        public const string DbFieldConcTestListLimitOperator = "LimitOperator";
        public const string DbFieldConcTestListLimitValue = "LimitValue";
        public const string DbFieldConcTestListConcentrationExpression = "ConcentrationExpression";
        public const string DbFieldConcTestListCTExpressionSuperSet = "CTExpressionSuperset";
        public const string DbFieldConcTestListCreatedDate = "CreatedDate";
        public const string DbFieldConcTestListType = "Type";
        public const string DbFieldConcTestListTag = "Tag";
        public const string DbFieldConcTestListStatus = "Status";
        public const string DbFieldConcTestListExpression = "Expression";
        public const string DbFieldConcTestListCreatedBy = "CreatedBy";
        public const string DbFieldConcTestListModifiedDate = "ModifiedDate";
        public const string DbFieldConcTestListIsSubsetRequired = "IsSubsetRequired";
        #endregion

        #endregion

        #region Concentration Management
        #region Stored Procedures

        public const string SP_GetAuthWorkflowStatus = "[ps].[spGetAuthWorkflowStatus]";
        public const string SP_GetHolidayList = "[app].[spGetHolidayList]";
        public const string SP_ManageDataAuthWorkflow = "[ps].[spManageAuthWorkflow]";
        public const string SP_GetEntityAuditDetails = "[ps].[spGetEntityAuditDetails]";

        #endregion

        #region Stored Procedure Parameters

        public const string DbProcParamPsId = "@pPsId";
        public const string DbProcParamWorkflowtype = "@pWorkflowType";
        public const string DbProcParamStepName = "@pStepName";
        public const string DbProcParamStatus = "@pStatus";
        public const string DbProcParamComment = "@pComment";


        #endregion

        #endregion

        #region FieldLookup
        public const string DbFieldLookupDataType = "Type";
        public const string DbFieldLookupDataDescription = "Description";
        public const string DbFieldLookupDataReferenceLookup = "ReferenceLookup";
        public const string DbFieldLookupDataIsAuthorised = "IsAuthorised";
        #endregion

        #region OperatorLookup
        public const string DbOperatorLookupDataType = "OperatorType";
        public const string DbOperatorLookupDataText = "OperatorText";
        #endregion

        #region OperatorLookup
        public const string DbFieldRefLookupDataValue = "Value";
        public const string DbFieldRefLookupDataTitle = "Options";
        #endregion

        #region Custom Field
        #region Stored Procedures
        public const string SP_GetFieldsDataType = "ps.spGetFieldsDataType";
        public const string SP_GetFieldsData = "ps.spGetFieldsData";
        public const string SP_SaveCustomField = "ps.spSaveCustomField";
        public const string SP_AmendCustomField = "ps.spAmendCustomField";
        public const string SP_GetCustomFieldDetail = "ps.spGetCustomFieldDetail";
        public const string SP_GetCustomFieldFunctionDetail = "ps.spGetCustomFieldFunctionDetail";
        public const string SP_GetArithmeticOperators = "ps.spGetArithmeticOperators";
        public const string SP_SaveBasicFieldFunctionDetails = "ps.spSaveBasicFieldFunctionDetails";
        public const string SP_GetSaveBasicArithmeticCondition = "ps.spSaveBasicArithmeticCondition";
        public const string SP_GetBasicArithmeticExpressionDetail = "ps.spGetBasicArithmeticExpressionDetail";
        public const string SP_GetBasicFieldFunctionDetail = "ps.spGetBasicFieldFunctionDetail";

        #endregion

        #region Stored Procedure Parameters
        public const string CustomFieldID = "@FieldID";
        public const string CustomFieldName = "@Name";
        public const string CustomFieldDescription = "@Description";
        public const string CustomFieldDataType = "@FieldDataType";
        public const string CustomFieldType = "@FieldType";
        public const string FieldSubType = "@FieldSubType";
        public const string FieldsUsed = "@FieldsUsed";
        public const string CalculatedExpression = "@Expression";
        public const string FieldStatus = "@FieldStatus";
        public const string DbProcParamFieldId = "@pEligibilityCriteriaFieldId";
        public const string DbProcParamFieldIsReject = "@pIsReject";
        public const string DbProcParamFieldType = "@pFieldType";
        #endregion
        #endregion

        #region Field List Stored Proc And Paramters
        #region Stored Proc details
        public const string SP_GetAllFields = "[ps].[spGetFields]";
        public const string SP_DeleteField = "[ps].[spDeleteField]";
        public const string SP_GetFieldECList = "[ps].[spGetFieldECList]";
        public const string SP_SupportCriteriaFieldRename = "[ps].[spSupportCriteriaFieldRename]";
        #endregion

        #region Parameter Name Input/Output        
        public const string UserName = "@UserName";
        public const string DbField_FieldId = "Id";
        public const string DbField_FieldName = "Name";
        public const string DbField_FieldDescription = "Description";
        public const string DbField_FieldMapping = "FieldMapping";
        public const string DbField_FieldSource = "Source";
        public const string DBField_FieldType = "FieldType";
        public const string DbField_FieldCreatedBy = "CreatedBy";
        public const string DbField_FieldStatus = "Status";
        #endregion
        #endregion

        #region Exclusion

        #region "Exclusion SP"
        public const string SP_Exclusion_GetList = "[ps].[spGetPoolList]";
        public const string SP_Exclusion_Delete = "[ps].[spDeleteExclusion]";
        public const string SP_Exclusion_GetExclusionById = "[ps].[spGetExclusionById]";
        public const string SP_Exclusion_Create = "[ps].[spCreateExclusion]";
        public const string SP_Exclusion_Update = "[ps].[spUpdateExclusion]";
        public const string SP_Exclusion_ValidateUpload = "[ps].[spValidateExclusionUpload]";
        public const string SP_Exclusion_ExportLatest = "[ps].[spGetExclusion]";
        public const string SP_Exclusion_ManagementData = "[ps].[spGetExclusionData]";
        #endregion

        #region "Exclusion Fields"
        public const string DbFieldExclusionLoanCount = "LoanCount";
        public const string DbFieldExclusionModifiedDate = "ModifiedDate";
        public const string DbFieldExclusionUploadedFileName = "UploadedFileName";

        public const string DbFieldExclusionItemLoanNumber = "LoanNumber";
        public const string DbFieldExclusionItemReason = "Reason";
        public const string DbFieldExclusionItemReasonId = "ReasonId";

        public const string DbFieldExclusionIsValid = "IsValid";
        public const string DbFieldExclusionErrorType = "ErrorType";
        public const string DbFieldExclusionErrorDetails = "ErrorDetails";
        public const string DbFieldExclusionExclusionId = "ExclusionId";
        public const string DbFieldExclusionGlobalStatus = "GlobalStatus";
        public const string DbFieldExclusionActiveStatus = "ActiveStatus";
        public const string DbFieldExclusionCreatedBy = "CreatedBy";
        public const string DbFieldExclusionCreatedDate = "CreatedDate";

        #endregion

        #region "Exclusion SP Param"
        public const string DbProcParamExclusionId = "@pExclusionId";
        public const string DbProcParamExclusionUploadedFileName = "@pUploadedFileName";
        public const string DbProcParamExclusionItems = "@pExclusionItems";
        #endregion

        #region "Exclusion DB Type"
        public const string DbTypeExclusionItem = "[ps].[ExclusionItem]";
        #endregion

        #endregion

        #region Drill Through Report And Parameters
        public const string SP_Pool_GetECWiseReport = "[ps].[spGetECWiseDrillThroughReport]";
        public const string SP_Pool_GetDetailedReport = "[ps].[spGetDetailDrillThroughReport]";

        public const string DbProcParamSourcePoolCount = "NumberOfAccount";
        public const string DbProcParamSourcePoolBalance = "Balance";
        public const string DbProcParamTotalPoolCount = "TotalAccount";
        public const string DbProcParamTotalPoolBalance = "TotalBalance";

        public const string DbProcParamReturnValue = "@pReturnValue";
        public const string DbProcParamPassedLoansCount = "@pPassLoansCount";
        public const string DbProcParamFailLoansCount = "@pFailLoansCount";

        #endregion

        #region Replines Report

        public const string SP_GenerateReplinesReport = "[ps].[spGenerateReplineReport]";

        public const string DbProcParamDealId = "@DealId";
        public const string DbProcParamAsAtDate = "@AsAtDate";

        public const string DbProcParamInterestType = "Interest Type";
        public const string DbProcParamPaymentType = "Pmt Type";
        public const string DbProcParamSeasoningBucket = "Seasoning Bucket";
        public const string DbProcParamOriginalTermBucket = "Original Term Bucket";
        public const string DbProcParamMonthsToResetBucket = "Months to Reset Bucket";
        public const string DbProcParamLTVBucket = "LTV Bucket";
        public const string DbProcParamTempIOPeriod = "Temp IO period?";
        public const string DbProcParamFloorOnTrackerRate = "Floor on tracker Rate?";
        public const string DbProcParamCountOfLoanId = "Count of Loan ID";
        public const string DbProcParamCutOffBalance = "Cutoff Balance";
        public const string DbProcParamOTermWAByBalance = "Oterm WA by Bal";
        public const string DbProcParamSeasoningWAByBalance = "Seasoning WA by Bal";
        public const string DbProcParamCouponWAByBalance = "Coupon WA by Bal";
        public const string DbProcParamMarginWAByBalance = "Margin WA by Bal";
        public const string DbProcParamTeaserDiscountWAByBalance = "Teaser Discount WA by Bal";
        public const string DbProcParamMonthsToResetWAByBalance = "Months to Reset WA by Bal";
        public const string DbProcParamIOWAByBalance = "IO WA by Bal";
        public const string DbProcParamMonOfTempIORevWAByBalance = "Months for Temp IO reversion WA by balance";
        public const string DbProcParamPercOfBalanceInDefault = "Perc of balance in default";
        public const string DbProcParamPercOfBalanceInDelinquency = "Perc of balance in delinquency";
        public const string DbProcParamTrackerFloorWAByBalance = "Tracker Floor WA By Balance";
        public const string DbProcParamCombinedLTV = "Combined LTV";
        public const string DbProcParamCreditScoreWAByBalance = "Credit Score WA by Bal";
        public const string DbProcParamMIWAByBalance = "MI WA by Bal";
        public const string DbProcParamPrimeWAbyBal = "Prime WA by Bal";
        public const string DbProcParamUnVerifiedIncomeWAByBalance = "Unverified Income WA by Bal";
        public const string DbProcParamSelfEmployedWAByBal = "Self Employed WA by Bal";
        public const string DbProcParamBuyToLetWAByBalance = "Buy-to-let WA by Bal";
        public const string DbProcParamPriorBankcruptcyWAByBalance = "Prior Bnkrptcy WA by Bal";
        public const string DbProcParamFlexLoanWAByBalance = "Flex Loan WA by Bal";
        public const string DbProcParamSecondHomeWAByBalance = "Second Home WA by Bal";
        public const string DbProcParamFirstLienWAByBalance = "First Lien WA by Bal";
        public const string DbProcParamValuationAgeWAByBalance = "Valuation Age WA by Bal";

        public const string DbProcParamPercOfBalanceInDefault_dis = "% of balance in default (>=6m in arrears)";
        public const string DbProcParamPercOfBalanceInDelinquency_dis = "% of balance in delinquency(1<=arrears<6m)";
        public const string DbProcParamSelfEmployedWAByBal_dis = "Self-employed WA by Bal";
        #endregion

        #region Validate And Update Submission Parameter
        public const string DbProcParamIsSubmitted = "@pIsSubmitted";
        #endregion

        #region Dashboard

        #region "Dashboard SP"
        public const string SP_Dashboard_GetSummary = "[ps].[spGetDashboardSummaryAsset]";
        public const string SP_Dashboard_GetPreviousWork = "[ps].[spGetDashboardSummaryPreviousWorkAsset]";
        public const string SP_GetSFPPlusDashBoardCompletedPools = "[ps].[spGetSFPPlusDashBoardCompletedPools]";
        public const string SP_GetSFPPlusDashBoardFutureDate = "[ps].[spGetSFPPlusDashBoardFutureDate]";
        public const string SP_GetSFPPlusDashBoardDeals = "[ps].[spGetSFPPlusDashBoardDeals]";
        public const string SP_GetSFPPlusDashBoardFailedPools = "[ps].[spGetSFPPlusDashBoardFailedPools]";
        #endregion

        #region "Dashboard Fields"
        public const string DbFieldDashboardRecordCount = "RecordCount";
        public const string DbFieldDashboardEntity = "Entity";
        public const string DbFieldDashboardPurpose = "Purpose";

        public const string DbFieldDashboardPoolId = "PoolId";
        public const string DbFieldDashboardPoolName = "PoolName";
        public const string DbFieldDashboardSourceDeal = "SourceDeal";
        public const string DbFieldDashboardTargetDeal = "TargetDeal";
        public const string DbFieldDashboardNumberOfLoans = "NumberOfLoans";
        public const string DbFieldDashboardNumberOfSubAccounts = "NumberOfSubAccounts";
        public const string DbFieldDashboardPoolStatus = "PoolStatus";
        public const string DbFieldDashboardEffectiveDate = "EffectiveDate";
        public const string DbFieldDashboardClosedAccountCount = "ClosedLoanCount";
        public const string DbFieldDashboardClosedSubAccountCount = "ClosedSubAccountCount";


        public const string DbFieldDashboardDealName = "DealName";
        public const string DbFieldDashboardBrandCode = "BrandCode";
        public const string DbFieldDashboardTrueBalance = "TrueBalance";
        public const string DbFieldDashboardCapitalBalance = "CapitalBalance";
        public const string DbFieldDashboardCurrentAccountCount = "CurrentAccountCount";
        public const string DbFieldDashboardCurrentSubAccountCount = "CurrentSubAccountCount";
        public const string DbFieldDashboardLoanVariance = "LoanVariance";
        public const string DbFieldDashboardPreviousAccountCount = "PreviousAccountCount";
        public const string DbFieldDashboardPreviousSubAccountCount = "PreviousSubAccountCount";
        public const string DbFieldDashboardSubAccountVariance = "SubAccountVariance";


        public const string DbFieldDashboardCurrentDate = "CurrentDate";
        public const string DbFieldDashboardPreviousdate = "Previousdate";


        public const string DbFieldDashboardFailedReason = "FailedReason";
        #endregion
        #region "Dashboard SP Param"
        public const string DbProcParamDashboardFromDate = "@pFromDate";
        public const string DbProcParamDashboardToDate = "@pToDate";
        public const string DbProcParamDashboardAsAtDate = "@pAsAtDate";
        public const string DbProcParamDashboardisInitial = "@pIsInitial";

        #endregion

        #endregion

        #region Common DB Fields

        public const string DbFieldCreatedDate = "CreatedDate";
        public const string DbFieldModifiedDate = "ModifiedDate";
        public const string DbFieldAuthorizedDate = "AuthorizedDate";

        #endregion

        #region Menu And User Roles
        #region Stored Proc
        public const string SP_User_GetDefaultAssetClass = "app.GetDefaultAssetClass";
        public const string SP_User_GetUserAndMenuData = "app.GetUserAndMenuData";
        #endregion
        #region Fields
        public const string DbFieldUser_RoleId = "RoleId";
        public const string DbFieldUser_Permission = "Permission";
        public const string DbFieldUser_PermissionAccessType = "PermissionAccessType";
        public const string DbFieldUser_ClassId = "ClassId";
        public const string DbFieldUser_ClassName = "ClassName";
        public const string DbFieldUser_ClassDesc = "Description";
        public const string DbFieldUser_ClassCode = "Code";
        #endregion
        public const string DbProcParamUser_AdGroupName = "@pAdGroupName";
        #endregion

        #region Adhoc Pool Reports 
        #region Adhoc Pool reports stored proc
        public const string SP_Adhoc_GetAdhocReportList = "[ps].[spGetAdhocReportTemplates]";
        public const string SP_Adhoc_SaveAdhochReportTemplate = "[ps].[spSaveAdhocReportTemplate]";
        public const string SP_Adhoc_GetReportFieldList = "[ps].[spGetFieldsForReport]";
        public const string SP_Adhoc_GetDatatypeAggregationMap = "[ps].[spGetDatatypeAggregationMap]";
        public const string SP_Adhoc_GetReportTemplateById = "[ps].[spGetReportTemplateById]";
        public const string SP_Adhoc_DeleteReportTemplate = "[ps].[spDeleteReportTemplateData]";
        public const string SP_Adhoc_GetReportRefData = "[ps].[spGetReportRefData]";
        public const string SP_Adhoc_GenerateReport = "[ps].[spGenerateAdhocReports]";
        public const string SP_GetEC_FieldAttributes = "[ps].[spGetECFieldAttributes]";
        public const string SP_ManageBuildRRWorkflowProcess = "[ps].spManageBuildRRWorkflowProcess";
        public const string SP_Adhoc_GetAdhocReportType = "[ps].[spGetAdhocReportType]";
        public const string SP_GetRRAuthorisedDealConfig = "rpt.spGetRRAuthorisedDealConfig";
        

        #endregion

        #region Reference Registry Reports 
        public const string DbProcParamReffRegReportAsAtDate = "@pAsAtDate";
        public const string DbProcParamReffRegReportTemplateId = "@pReportTemplateId";
        public const string DbProcParamReffRegReportDealID = "@pDealID";
        public const string SP_GenerateReferenceRegistryReport = "[ps].[spGenerateReferenceRegistryReports]";
        public const string SP_RR_GetReportFieldList = "[ps].[spGetFieldsForRRReport]";
        #endregion

        #region Params
        #region Params
        public const string DbProcParamAdhochPoolAdhocReportTemplateId = "@pPoolAdhocReportTemplateId";
        public const string DbProcParamAdhocReportTemplateName = "@pReportTemplateName";
        public const string DbProcParamAdhocReportTypeId = "@pReportTypeId";
        public const string DbProcParamAdhocIsPublic = "@pIsPublic";
        public const string DbProcParamAdhocLinkedFieldList = "@pLinkedFieldList";
        public const string DbProcParamAdhocDMLType = "@pDMLType";
        public const string DbProcParamAdhocColumns = "@pColumns";
        #endregion
        #endregion

        #region "Adhoc Report Fields"
        public const string DbFieldAdhocReportId = "ReportTemplateId";
        public const string DbFieldAdhocReportName = "ReportName";
        public const string DbFieldAdhocReportTemplateType = "ReportTemplateType";
        public const string DbFieldAdhocReportType = "ReportType";
        public const string DbFieldAdhocIsPublic = "IsPublic";
        public const string DbFieldAdhocCreatedBy = "CreatedBy";
        public const string DbFieldAdhocReportTypeId = "ReportTypeId";
        public const string DbFieldAdhocFieldOrderId = "FieldOrderId";
        public const string DbFieldAdhocAggregationTypeId = "AggregationTypeId";
        public const string DbFieldAdhocFieldLevel = "FieldLevel";
        public const string DbFieldAdhocAggregationId = "AggregationId";
        public const string DbFieldAdhocAggregationName = "AggregationName";
        public const string DbFieldAdhocAggregationDescription = "Description";
        public const string DbFieldAdhocLoanCount = "AssetCount";
        public const string DbFieldAdhocDataTypeId = "DataTypeId";

        public const string DbFieldEligibilityCriteriaFieldId = "EligibilityCriteriaFieldId";
        public const string DbFieldCriteriaFieldName = "CriteriaFieldName";
        public const string DbFieldRequireAccountingFormat = "RequireAccountingFormat";
        public const string DbFieldDisplayFormat = "DisplayFormat";

        public const string DbFieldAdhocAssetClassId = "AssetClassId";
        public const string DbFieldAdhocDealId = "DealId";

        public const string DbFieldAdhocModifiedBy = "ModifiedBy";
        public const string DbFieldAdhocModifiedDate = "ModifiedDate";
        public const string DbFieldAdhocWorkflowStepId = "WorkflowStepId";
        public const string DbFieldAdhocCurrentStatus = "CurrentStatus";
        public const string DbFieldAdhocComment = "Comment";


        #endregion
        #endregion

        #region ESMA Region 

        public const string SP_ESMA4Data = "[corp].[spGetESMA4ReportData]";
        public const string SP_FCA4Data = "[corp].[spGetFCA4ReportData]";
        public const string SP_ESMA9Data = "[corp].[spGetESMA9ReportData]";
        public const string SP_FCA9Data = "[corp].[spGetFCA9ReportData]";

        public const string DbProcParamDealName = "@DealName";

        public const string DbFieldESMA4CollateralUniqueIdentifier = "Unique Identifier";
        public const string DbFieldESMA4CollateralUnderlyingExposureIdentifier = "Underlying Exposure Identifier";
        public const string DbFieldESMA4CollateralOriginalCollateralIdentifier = "Original Collateral Identifier";
        public const string DbFieldESMA4CollateralNewCollateralIdentifier = "New Collateral Identifier";
        public const string DbFieldESMA4CollateralGeographicRegionCollateral = "Geographic Region - Collateral";
        public const string DbFieldESMA4CollateralSecurityType = "Security Type";
        public const string DbFieldESMA4CollateralChargeType = "Charge Type";
        public const string DbFieldESMA4CollateralLien = "Lien";
        public const string DbFieldESMA4CollateralCollateralType = "Collateral Type";
        public const string DbFieldESMA4CollateralCurrentValuationAmount = "Current Valuation Amount";
        public const string DbFieldESMA4CollateralCurrentValuationMethod = "Current Valuation Method";
        public const string DbFieldESMA4CollateralCurrentValuationDate = "Current Valuation Date";
        public const string DbFieldESMA4CollateralOriginalValuationAmount = "Original Valuation Amount";
        public const string DbFieldESMA4CollateralOriginalValuationMethod = "Original Valuation Method";
        public const string DbFieldESMA4CollateralOriginalValuationDate = "Original Valuation Date";
        public const string DbFieldESMA4CollateralDateOfSale = "Date Of Sale";
        public const string DbFieldESMA4CollateralSalePrice = "Sale Price";
        public const string DbFieldESMA4CollateralCollateralCurrency = "Collateral Currency";
        public const string DbFieldESMA4CollateralGuarantorCountry = "Guarantor Country";
        public const string DbFieldESMA4CollateralGuarantorESASubsector = "Guarantor ESA Subsector";




        public const string DbFieldESMA4ExposureUniqueIdentifier = "Unique Identifier";
        public const string DbFieldESMA4ExposureOriginalUnderlyingExposureIdentifier = "Original Underlying Exposure Identifier";
        public const string DbFieldESMA4ExposureNewUnderlyingExposureIdentifier = "New Underlying Exposure Identifier";
        public const string DbFieldESMA4ExposureOriginalObligorIdentifier = "Original Obligor Identifier";
        public const string DbFieldESMA4ExposureNewObligorIdentifier = "New Obligor Identifier";
        public const string DbFieldESMA4ExposureDataCutOffDate = "Data Cut-Off Date";
        public const string DbFieldESMA4ExposurePoolAdditionDate = "Pool Addition Date";
        public const string DbFieldESMA4ExposureDateOfRepurchase = "Date Of Repurchase";
        public const string DbFieldESMA4ExposureRedemptionDate = "Redemption Date";
        public const string DbFieldESMA4ExposureGeographicRegionObligor = "Geographic Region - Obligor";
        public const string DbFieldESMA4ExposureGeographicRegionClassification = "Geographic Region Classification";
        public const string DbFieldESMA4ExposureCreditImpairedObligor = "Credit Impaired Obligor";
        public const string DbFieldESMA4ExposureCustomerType = "Customer Type";
        public const string DbFieldESMA4ExposureNACEIndustryCode = "NACE Industry Code";
        public const string DbFieldESMA4ExposureObligorBaselIIISegment = "Obligor Basel III Segment";
        public const string DbFieldESMA4ExposureEnterpriseSize = "Enterprise Size";
        public const string DbFieldESMA4ExposureRevenue = "Revenue";
        public const string DbFieldESMA4ExposureTotalDebt = "Total Debt";
        public const string DbFieldESMA4ExposureEBITDA = "EBITDA";
        public const string DbFieldESMA4ExposureEnterpriseValue = "Enterprise Value";
        public const string DbFieldESMA4ExposureFreeCashflow = "Free Cashflow";
        public const string DbFieldESMA4ExposureDateOfFinancials = "Date Of Financials";
        public const string DbFieldESMA4ExposureFinancialStatementCurrency = "Financial Statement Currency";
        public const string DbFieldESMA4ExposureDebtType = "Debt Type";
        public const string DbFieldESMA4ExposureSecuritisedReceivables = "Securitised Receivables";
        public const string DbFieldESMA4ExposureInternationalSecuritiesIdentificationNumber = "International Securities Identification Number";
        public const string DbFieldESMA4ExposureSeniority = "Seniority";
        public const string DbFieldESMA4ExposureSyndicated = "Syndicated";
        public const string DbFieldESMA4ExposureLeveragedTransaction = "Leveraged Transaction";
        public const string DbFieldESMA4ExposureManagedByCLO = "Managed By CLO";
        public const string DbFieldESMA4ExposurePaymentInKind = "Payment In Kind";
        public const string DbFieldESMA4ExposureSpecialScheme = "Special Scheme";
        public const string DbFieldESMA4ExposureOriginationDate = "Origination Date";
        public const string DbFieldESMA4ExposureMaturityDate = "Maturity Date";
        public const string DbFieldESMA4ExposureOriginationChannel = "Origination Channel";
        public const string DbFieldESMA4ExposurePurpose = "Purpose";
        public const string DbFieldESMA4ExposureCurrencyDenomination = "Currency Denomination";
        public const string DbFieldESMA4ExposureOriginalPrincipalBalance = "Original Principal Balance";
        public const string DbFieldESMA4ExposureCurrentPrincipalBalance = "Current Principal Balance";
        public const string DbFieldESMA4ExposurePriorPrincipalBalances = "Prior Principal Balances";
        public const string DbFieldESMA4ExposureMarketValue = "Market Value";
        public const string DbFieldESMA4ExposureTotalCreditLimit = "Total Credit Limit";
        public const string DbFieldESMA4ExposurePurchasePrice = "Purchase Price";
        public const string DbFieldESMA4ExposurePutDate = "Put Date";
        public const string DbFieldESMA4ExposurePutStrike = "Put Strike";
        public const string DbFieldESMA4ExposureAmortisationType = "Amortisation Type";
        public const string DbFieldESMA4ExposurePrincipalGracePeriodEndDate = "Principal Grace Period End Date";
        public const string DbFieldESMA4ExposureScheduledPrincipalPaymentFrequency = "Scheduled Principal Payment Frequency";
        public const string DbFieldESMA4ExposureScheduledInterestPaymentFrequency = "Scheduled Interest Payment Frequency";
        public const string DbFieldESMA4ExposurePaymentDue = "Payment Due";
        public const string DbFieldESMA4ExposureBalloonAmount = "Balloon Amount";
        public const string DbFieldESMA4ExposureInterestRateType = "Interest Rate Type";
        public const string DbFieldESMA4ExposureCurrentInterestRate = "Current Interest Rate";
        public const string DbFieldESMA4ExposureCurrentInterestRateIndex = "Current Interest Rate Index";
        public const string DbFieldESMA4ExposureCurrentInterestRateIndexTenor = "Current Interest Rate Index Tenor";
        public const string DbFieldESMA4ExposureCurrentInterestRateMargin = "Current Interest Rate Margin";
        public const string DbFieldESMA4ExposureInterestRateResetInterval = "Interest Rate Reset Interval";
        public const string DbFieldESMA4ExposureInterestRateCap = "Interest Rate Cap";
        public const string DbFieldESMA4ExposureInterestRateFloor = "Interest Rate Floor";
        public const string DbFieldESMA4ExposureRevisionMargin1 = "Revision Margin 1";
        public const string DbFieldESMA4ExposureInterestRevisionDate1 = "Interest Revision Date 1";
        public const string DbFieldESMA4ExposureRevisionMargin2 = "Revision Margin 2";
        public const string DbFieldESMA4ExposureInterestRevisionDate2 = "Interest Revision Date 2";
        public const string DbFieldESMA4ExposureRevisionMargin3 = "Revision Margin 3";
        public const string DbFieldESMA4ExposureInterestRevisionDate3 = "Interest Revision Date 3";
        public const string DbFieldESMA4ExposureRevisedInterestRateIndex = "Revised Interest Rate Index";
        public const string DbFieldESMA4ExposureRevisedInterestRateIndexTenor = "Revised Interest Rate Index Tenor";
        public const string DbFieldESMA4ExposureNumberOfPaymentsBeforeSecuritisation = "Number Of Payments Before Securitisation";
        public const string DbFieldESMA4ExposurePercentageOfPrepaymentsAllowedPerYear = "Percentage Of Prepayments Allowed Per Year";
        public const string DbFieldESMA4ExposurePrepaymentLockOutEndDate = "Prepayment Lock-Out End Date";
        public const string DbFieldESMA4ExposurePrepaymentFee = "Prepayment Fee";
        public const string DbFieldESMA4ExposurePrepaymentFeeEndDate = "Prepayment Fee End Date";
        public const string DbFieldESMA4ExposurePrepaymentDate = "Prepayment Date";
        public const string DbFieldESMA4ExposureCumulativePrepayments = "Cumulative Prepayments";
        public const string DbFieldESMA4ExposureDateOfRestructuring = "Date Of Restructuring";
        public const string DbFieldESMA4ExposureDateLastInArrears = "Date Last In Arrears";
        public const string DbFieldESMA4ExposureArrearsBalance = "Arrears Balance";
        public const string DbFieldESMA4ExposureNumberOfDaysInArrears = "Number Of Days In Arrears";
        public const string DbFieldESMA4ExposureAccountStatus = "Account Status";
        public const string DbFieldESMA4ExposureReasonForDefaultorForeclosure = "Reason For Default or Foreclosure";
        public const string DbFieldESMA4ExposureDefaultAmount = "Default Amount";
        public const string DbFieldESMA4ExposureDefaultDate = "Default Date";
        public const string DbFieldESMA4ExposureAllocatedLosses = "Allocated Losses";
        public const string DbFieldESMA4ExposureCumulativeRecoveries = "Cumulative Recoveries";
        public const string DbFieldESMA4ExposureRecoverySource = "Recovery Source";
        public const string DbFieldESMA4ExposureRecourse = "Recourse";
        public const string DbFieldESMA4ExposureDepositAmount = "Deposit Amount";
        public const string DbFieldESMA4ExposureInterestRateSwapNotional = "Interest Rate Swap Notional";
        public const string DbFieldESMA4ExposureInterestRateSwapProviderLegalEntityIdentifier = "Interest Rate Swap Provider Legal Entity Identifier";
        public const string DbFieldESMA4ExposureInterestRateSwapProvider = "Interest Rate Swap Provider";
        public const string DbFieldESMA4ExposureInterestRateSwapMaturityDate = "Interest Rate Swap Maturity Date";
        public const string DbFieldESMA4ExposureCurrencySwapNotional = "Currency Swap Notional";
        public const string DbFieldESMA4ExposureCurrencySwapProviderLegalEntityIdentifier = "Currency Swap Provider Legal Entity Identifier";
        public const string DbFieldESMA4ExposureCurrencySwapProvider = "Currency Swap Provider";
        public const string DbFieldESMA4ExposureCurrencySwapMaturityDate = "Currency Swap Maturity Date";
        public const string DbFieldESMA4ExposureOriginalLenderName = "Original Lender Name";
        public const string DbFieldESMA4ExposureOriginalLenderLegalEntityIdentifier = "Original Lender Legal Entity Identifier";
        public const string DbFieldESMA4ExposureOriginalLenderEstablishmentCountry = "Original Lender Establishment Country";
        public const string DbFieldESMA4ExposureOriginatorName = "Originator Name";
        public const string DbFieldESMA4ExposureOriginatorLegalEntityIdentifier = "Originator Legal Entity Identifier";
        public const string DbFieldESMA4ExposureOriginatorEstablishmentCountry = "Originator Establishment Country";



        public const string DbFieldESMA9CollateralUniqueIdentifier = "Unique Identifier";
        public const string DbFieldESMA9CollateralUnderlyingExposureIdentifier = "Original Underlying Exposure Identifier";
        public const string DbFieldESMA9CollateralOriginalCollateralIdentifier = "Original Collateral Identifier";
        public const string DbFieldESMA9CollateralNewCollateralIdentifier = "New Collateral Identifier";
        public const string DbFieldESMA9CollateralGeographicRegionCollateral = "Geographic Region - Collateral";
        public const string DbFieldESMA9CollateralSecurityType = "Security Type";
        public const string DbFieldESMA9CollateralChargeType = "Charge Type";
        public const string DbFieldESMA9CollateralLien = "Lien";
        public const string DbFieldESMA9CollateralCollateralType = "Collateral Type";
        public const string DbFieldESMA9CollateralCurrentValuationAmount = "Current Valuation Amount";
        public const string DbFieldESMA9CollateralCurrentValuationMethod = "Current Valuation Method";
        public const string DbFieldESMA9CollateralCurrentValuationDate = "Current Valuation Date";
        public const string DbFieldESMA9CollateralCurrentLoanToValue = "Current Loan-To-Value";
        public const string DbFieldESMA9CollateralOriginalValuationAmount = "Original Valuation Amount";
        public const string DbFieldESMA9CollateralOriginalValuationMethod = "Original Valuation Method";
        public const string DbFieldESMA9CollateralOriginalValuationDate = "Original Valuation Date";
        public const string DbFieldESMA9CollateralOriginalLoanToValue = "Original Loan-To-Value";
        public const string DbFieldESMA9CollateralDateOfSale = "Date Of Sale";
        public const string DbFieldESMA9CollateralSalePrice = "Sale Price";
        public const string DbFieldESMA9CollateralCollateralCurrency = "Collateral Currency";


        public const string DbFieldESMA9ExposureUniqueIdentifier = "Unique Identifier";
        public const string DbFieldESMA9ExposureOriginalUnderlyingExposureIdentifier = "Original Underlying Exposure Identifier";
        public const string DbFieldESMA9ExposureNewUnderlyingExposureIdentifier = "New Underlying Exposure Identifier";
        public const string DbFieldESMA9ExposureOriginalObligorIdentifier = "Original Obligor Identifier";
        public const string DbFieldESMA9ExposureNewObligorIdentifier = "New Obligor Identifier";
        public const string DbFieldESMA9ExposureDataCutOffDate = "Data Cut-Off Date";
        public const string DbFieldESMA9ExposurePoolAdditionDate = "Pool Addition Date";
        public const string DbFieldESMA9ExposureDateOfRepurchase = "Date Of Repurchase";
        public const string DbFieldESMA9ExposureRedemptionDate = "Redemption Date";
        public const string DbFieldESMA9ExposureDescription = "Description";
        public const string DbFieldESMA9ExposureGeographicRegionObligor = "Geographic Region - Obligor";
        public const string DbFieldESMA9ExposureGeographicRegionClassification = "Geographic Region Classification";
        public const string DbFieldESMA9ExposureEmploymentStatus = "Employment Status";
        public const string DbFieldESMA9ExposureCreditImpairedObligor = "Credit Impaired Obligor";
        public const string DbFieldESMA9ExposureObligorLegalType = "Obligor Legal Type";
        public const string DbFieldESMA9SICCode = "SIC Code";
        public const string DbFieldESMA9ExposurePrimaryIncome = "Primary Income";
        public const string DbFieldESMA9ExposurePrimaryIncomeType = "Primary Income Type";
        public const string DbFieldESMA9ExposurePrimaryIncomeCurrency = "Primary Income Currency";
        public const string DbFieldESMA9ExposurePrimaryIncomeVerification = "Primary Income Verification";
        public const string DbFieldESMA9ExposureRevenue = "Revenue";
        public const string DbFieldESMA9ExposureFinancialStatementCurrency = "Financial Statement Currency";
        public const string DbFieldESMA9ExposureInternationalSecuritiesIdentificationNumber = "International Securities Identification Number";
        public const string DbFieldESMA9ExposureOriginationDate = "Origination Date";
        public const string DbFieldESMA9ExposureMaturityDate = "Maturity Date";
        public const string DbFieldESMA9ExposureCurrencyDenomination = "Currency Denomination";
        public const string DbFieldESMA9ExposureOriginalPrincipalBalance = "Original Principal Balance";
        public const string DbFieldESMA9ExposureCurrentPrincipalBalance = "Current Principal Balance";
        public const string DbFieldESMA9ExposureTotalCreditLimit = "Total Credit Limit";
        public const string DbFieldESMA9ExposurePurchasePrice = "Purchase Price";
        public const string DbFieldESMA9ExposureAmortisationType = "Amortisation Type";
        public const string DbFieldESMA9ExposurePrincipalGracePeriodEndDate = "Principal Grace Period End Date";
        public const string DbFieldESMA9ExposureScheduledPrincipalPaymentFrequency = "Scheduled Principal Payment Frequency";
        public const string DbFieldESMA9ExposureScheduledInterestPaymentFrequency = "Scheduled Interest Payment Frequency";
        public const string DbFieldESMA9ExposurePaymentDue = "Payment Due";
        public const string DbFieldESMA9ExposureDebtToIncomeRatio = "Debt To Income Ratio";
        public const string DbFieldESMA9ExposureBalloonAmount = "Balloon Amount";
        public const string DbFieldESMA9ExposureInterestRateResetInterval = "Interest Rate Reset Interval";
        public const string DbFieldESMA9ExposureCurrentInterestRate = "Current Interest Rate";
        public const string DbFieldESMA9ExposureCurrentInterestRateIndex = "Current Interest Rate Index";
        public const string DbFieldESMA9ExposureCurrentInterestRateIndexTenor = "Current Interest Rate Index Tenor";
        public const string DbFieldESMA9ExposureCurrentInterestRateMargin = "Current Interest Rate Margin";
        public const string DbFieldESMA9ExposureInterestRateCap = "Interest Rate Cap";
        public const string DbFieldESMA9ExposureInterestRateFloor = "Interest Rate Floor";
        public const string DbFieldESMA9ExposureNumberOfPaymentsBeforeSecuritisation = "Number Of Payments Before Securitisation";
        public const string DbFieldESMA9ExposurePercentageOfPrepaymentsAllowedPerYear = "Percentage Of Prepayments Allowed Per Year";
        public const string DbFieldESMA9ExposurePrepaymentLockOutEndDate = "Prepayment Lock-Out End Date";
        public const string DbFieldESMA9ExposurePrepaymentFee = "Prepayment Fee";
        public const string DbFieldESMA9ExposurePrepaymentFeeEndDate = "Prepayment Fee End Date";
        public const string DbFieldESMA9ExposurePrepaymentDate = "Prepayment Date";
        public const string DbFieldESMA9ExposureCumulativePrepayments = "Cumulative Prepayments";
        public const string DbFieldESMA9ExposureDateLastInArrears = "Date Last In Arrears";
        public const string DbFieldESMA9ExposureArrearsBalance = "Arrears Balance";
        public const string DbFieldESMA9ExposureNumberOfDaysInArrears = "Number Of Days In Arrears";
        public const string DbFieldESMA9ExposureAccountStatus = "Account Status";
        public const string DbFieldESMA9ExposureReasoForDefaultorForeclosure = "Reason For Default or Foreclosure";
        public const string DbFieldESMA9ExposureDefaultAmount = "Default Amount";
        public const string DbFieldESMA9ExposureDefaultDate = "Default Date";
        public const string DbFieldESMA9ExposureAllocatedLosses = "Allocated Losses";
        public const string DbFieldESMA9ExposureCumulativeRecoveries = "Cumulative Recoveries";
        public const string DbFieldESMA9ExposureOriginatorName = "Originator Name";
        public const string DbFieldESMA9ExposureOriginatorLegalEntityIdentifier = "Originator Legal Entity Identifier";
        public const string DbFieldESMA9ExposureOriginatorEstablishmentCountry = "Originator Establishment Country";
        public const string DbFieldESMA9ExposureOriginalLenderName = "Original Lender Name";
        public const string DbFieldESMA9ExposureOriginalLenderLegalEntityIdentifier = "Original Lender Legal Entity Identifier";
        public const string DbFieldESMA9ExposureOriginalLenderEstablishmentCountry = "Original Lender Establishment Country";




        #endregion


        #region Error Logging
        public const string SP_ErrorLog_Save = "[app].[SaveErrorLog]";

        public const string DbProcParamErrorLog_Save_ModuleId = "@moduleId";
        public const string DbProcParamErrorLog_Save_LogOriginTypeId = "@logOriginTypeId";
        public const string DbProcParamErrorLog_Save_ErrorProcedure = "@errorProcedure";
        public const string DbProcParamErrorLog_Save_ErrorMessage = "@errorMsg";
        public const string DbProcParamErrorLog_Save_UserName = "@userName";
        public const string DbProcParamErrorLog_Save_LogId = "@pLogId";

        #endregion

        #region PoolEcCt Report

        public const string SP_GeneratePoolAppliedEcCtReport = "[ps].[spGeneratePoolAppliedEcCtReport]";

        public const string DbProcEcCtParamPoolId = "@pPoolId";

        public const string DbFieldEcName = "EcName";
        public const string DbFieldEcDescription = "EcDescription";
        public const string DbFieldEcEligibilityExpression = "EcEligibilityExpression";
        public const string DbFieldEcType = "EcType";
        public const string DbFieldEcTypeDescription = "EcTypeDescription";
        public const string DbFieldEcStatus = "EcStatus";

        public const string DbFieldCtCriteriaName = "CtCriteriaName";
        public const string DbFieldCtDescription = "CtDescription";
        public const string DbFieldCtExpression = "CtExpression";
        public const string DbFieldCtTestType = "CtTestType";
        public const string DbFieldCtTestTypeDescription = "CtTestTypeDescription";
        public const string DbFieldCtStatus = "CtStatus";

        #endregion

        #region "EC Pools List Fields" 
        public const string SP_GetEcPoolsFields = "[ps].[spGetPoolListByEligibility]";
        public const string DbProcEcPoolsParamPoolId = "@pEcId";

        public const string DbFieldEcPoolListPoolID = "PoolId";
        public const string DbFieldEcPoolListName = "Name";
        public const string DbFieldEcPoolListStatus = "Status";
        public const string DbFieldEcPoolListBuildDate = "BuiltDate";
        public const string DbFieldEcPoolListCreationDate = "CreationDate";
        public const string DbFieldEcPoolListCreatedBy = "CreatedBy";
        public const string DbFieldEcPoolListAuthDate = "AuthorisationDate";
        #endregion

        #region Listing Page
        #region Stored Procedures
        public const string SP_GetUserListingPreference = "[app].[spGetUserListingPreference]";
        public const string SP_SaveUserListingPreference = "[app].[spSaveUserListingPreference]";
        #endregion

        #region Stored Procedure Parameters
        public const string DbFieldColumnName = "ColumnName";
        public const string DbProcParamListingPageName = "@pListingPageName";
        public const string DbProcParamHiddenColumnList = "@pHiddenColumnList";
        #endregion
        #endregion

        #region Upload Functionality
        public const string SP_FileUpload_GetReferenceData = "[app].[spGetFileUploadReferenceData]";
        public const string SP_FileUpload_GetUploadFileWorkflowState = "[app].[spGetFileWorkflowState]";
        public const string SP_FileUpload_SetUploadFileWorkflowState = "[app].[spSetFileWorkflowState]";
		public const string SP_FileUpload_LoadStaggingData = "[app].[spLoadStagingData]";
		public const string SP_FileUpload_GetFileWorkflowConfig = "[app].[spGetFileWorkflowConfig]";
		public const string SP_FileUpload_WorkflowUploadBuildModel = "[app].[spWorkflowUploadBuildModel]";
		public const string SP_FileUpload_GetUploadETLMessages = "[app].[spGetUploadETLMessages]";
        public const string SP_FileUpload_AssetRegisterMerge = "[nwm].[spAssetRegister_Merge]";

        #region Model Tokens
        #region Stored Procedures
        public const string SP_GetAPITokenbyKey = "app.spGetAPITokenbyKey";
        public const string SP_UpdateAPIToken = "app.spUpdateAPIToken";
        #endregion

        #region Stored Procedure Parameters
        public const string DbFieldAPITokenKey = "@pKey";
        public const string DbFieldAPITokenToken = "@pToken";
        public const string DbFieldFromIsProcessRunning = "@pFromIsProcessRunning";
        public const string DbFieldToIsProcessRunning = "@pToIsProcessRunning";
        public const string DbFieldAPITokenUserName = "@pUserName";
        //-----
        public const string DbFieldOutIsTokenUpdated = "@pOutIsTokenUpdated";
        public const string DbFieldOutUpdatedToken = "@pOutUpdatedToken";
        public const string DbFieldOutIsProcessRunning = "@pOutIsProcessRunning";
        #endregion
        #endregion

        public const string DbProcParamUserRoleId = "@pUserRoleId";
        public const string DbProcParamFileInfoId = "@pFileInfoId";
        public const string DbProcParamFileStatus = "@pFileStaus";
        #endregion

        #region Reference Registry        


        public const string SP_RefReg_DealId = "DealId";
        public const string SP_RefReg_DealName = "DealName";
        #endregion

        public const string DbFieldAuthWorkFlowDisplayName = "DisplayName";
        public const string DbFieldAuthWorkFlowComment = "Comment";
        public const string DbFieldAuthWorkFlowActionedBy = "ActionedBy";
        public const string DbFieldAuthWorkFlowActionedDate = "ActionedDate";

        #region NWM Reports Region 

        public const string SP_GenerateAssetRegisterReport = "[nwm].[syn_uspGenerateAssetRegisterReport]";
        public const string SP_GenerateLoansoutstandingReport = "[nwm].[syn_uspGenerateLoansoutstandingReport]";



        //Asset register register
        #region Asset register register
        public const string AssetDbFieldAsAtDate = "AsAtDate";
        public const string AssetDbFieldFacilityCurrencyConcatenationString = "FacilityCurrencyConcatenationString";
        public const string AssetDbFieldFacilityCurrencyCISConcatenationString = "FacilityCurrencyCISConcatenationString";
        public const string AssetDbFieldDealName = "DealName";
        public const string AssetDbFieldFacilityFCN = "FacilityFCN";
        public const string AssetDbFieldFacilityPrismId = "FacilityPrismId";
        public const string AssetDbFieldFacilityName = "FacilityName";
        public const string AssetDbFieldPrismIDorFCNid = "PrismIDorFCNid";
        public const string AssetDbFieldFacilityCcy = "FacilityCcy";
        public const string AssetDbFieldOSTCcy = "OSTCcy";
        public const string AssetDbFieldFacilityType = "FacilityType";
        public const string AssetDbFieldBook = "Book";
        public const string AssetDbFieldHostBankNetCommitment = "HostBankNetCommitment";
        public const string AssetDbFieldHostBankNetOutstanding = "HostBankNetOutstanding";
        public const string AssetDbFieldDrawnEUR = "DrawnEUR";
        public const string AssetDbFieldDrawnGBP = "DrawnGBP";
        public const string AssetDbFieldDrawnUSD = "DrawnUSD";
        public const string AssetDbFieldDrawnJPY = "DrawnJPY";
        public const string AssetDbFieldRelationsPrimaryKey = "RelationsPrimaryKey";
        public const string AssetDbFieldTradeAllocated = "TradeAllocated";
        public const string AssetDbFieldFacilityCurrencyConcatenationString1 = "FacilityCurrencyConcatenationString";
        public const string AssetDbFieldPercentAllocatedToTrade = "PercentAllocatedToTrade";
        public const string AssetDbFieldEncumberedIndicator = "EncumberedIndicator";
        public const string AssetDbFieldEncumberedCCY = "EncumberedCCY";
        public const string AssetDbFieldEncumberedGBP = "EncumberedGBP";
        public const string AssetDbFieldEncumberedEUR = "EncumberedEUR";
        public const string AssetDbFieldOSTHostBankNet = "OSTHostBankNet";
        public const string AssetDbFieldEncumberedUSD = "EncumberedUSD";
        public const string AssetDbFieldEncumberedJPY = "EncumberedJPY";
        public const string AssetDbFieldAvailableCCY = "AvailableCCY";
        public const string AssetDbFieldAgreementDate = "AgreementDate";
        public const string AssetDbFieldAvailableGBP = "AvailableGBP";
        public const string AssetDbFieldAvailableEUR = "AvailableEUR";
        public const string AssetDbFieldFinalMaturityDate = "FinalMaturityDate";
        public const string AssetDbFieldAvailableUSD = "AvailableUSD";
        public const string AssetDbFieldAvailableJPY = "AvailableJPY";
        public const string AssetDbFieldAllocationTimestamp = "AllocationTimestamp";
        public const string AssetDbFieldAllocationUser = "AllocationUser";
        public const string AssetDbFieldAllocatedTo = "AllocatedTo";
        public const string AssetDbFieldISIN = "ISIN";
        public const string AssetDbFieldCollateralAssetCompanyNucleusId = "CollateralAssetCompanyNucleusId";
        public const string AssetDbFieldTradeGroup = "TradeGroup";
        public const string AssetDbFieldVAndRA = "VAndRA";
        public const string AssetDbFieldScheduledMaturity = "ScheduledMaturity";
        public const string AssetDbFieldReportingTemplate = "ReportingTemplate";
        public const string AssetDbFieldBorrowerCIS = "BorrowerCIS";
        public const string AssetDbFieldBorrowerName = "BorrowerName";
        public const string AssetDbFieldCountryOfResidence = "CountryOfResidence";
        public const string AssetDbFieldCountryOfIncorporation = "CountryOfIncorporation";
        public const string AssetDbFieldCountryOfRisk = "CountryOfRisk";
        public const string AssetDbFieldAgent = "Agent";
        public const string AssetDbFieldCompanyNumber = "CompanyNumber";
        public const string AssetDbFieldLev1 = "Lev1";
        public const string AssetDbFieldLev2 = "Lev2";
        public const string AssetDbFieldLev3 = "Lev3";
        public const string AssetDbFieldSponsor = "Sponsor";
        public const string AssetDbFieldBorrowerInternalRating = "BorrowerInternalRating";
        public const string AssetDbFieldBorrowerInternalRatingImplied = "BorrowerInternalRatingImplied";
        public const string AssetDbFieldGradingScale = "GradingScale";
        public const string AssetDbFieldGradingModel = "GradingModel";
        public const string AssetDbFieldRatingApprovalDate = "RatingApprovalDate";
        public const string AssetDbFieldIBCALongTermRating = "IBCALongTermRating";
        public const string AssetDbFieldUltimateRiskParentCISCode = "UltimateRiskParentCISCode";
        public const string AssetDbFieldMoodysLongTermCPRatingGrdm = "MoodysLongTermCPRatingGrdm";
        public const string AssetDbFieldSPLongTermRatingGrdm = "SPLongTermRatingGrdm";
        public const string AssetDbFieldDoTEligible = "DoTEligible";
        public const string AssetDbFieldECBEligible = "ECBEligible";
        public const string AssetDbFieldNoBorrowerSetOff = "NoBorrowerSetOff";
        public const string AssetDbFieldContractLaw = "ContractLaw";
        public const string AssetDbFieldW8Sent = "W8Sent";
        public const string AssetDbFieldFacilityWarnings = "FacilityWarnings";
        public const string AssetDbFieldEligibilityComments1 = "EligibilityComments1";
        public const string AssetDbFieldEligibilityComments2 = "EligibilityComments2";
        public const string AssetDbFieldEligibilityComments3 = "EligibilityComments3";
        public const string AssetDbFieldFacilityEncumberedOutsideProcess = "FacilityEncumberedOutsideProcess";
        public const string AssetDbFieldTimeToLegalMaturity = "TimeToLegalMaturity";
        public const string AssetDbFieldTimeToLegalMaturityBucket = "TimeToLegalMaturityBucket";
        public const string AssetDbFieldIneligibilityExceptions = "IneligibilityExceptions";
        public const string AssetDbFieldEntity = "Entity";
        public const string AssetDbFieldCountryOfTaxClassification = "CountryOfTaxClassification";
        public const string AssetDbFieldCountryOfTaxNote = "CountryOfTaxNote";
        public const string AssetDbFieldIneligibilityValidation = "IneligibilityValidation";
        public const string AssetDbFieldAssessmentNeeded = "AssessmentNeeded";
        public const string AssetDbFieldConditionPrecedents = "ConditionPrecedents";
        public const string AssetDbFieldSNPEligibility = "SNPEligibility";
        public const string AssetDbFieldRSFUnencumbered = "RSFUnencumbered";
        public const string AssetDbFieldTopCoCISCodeEncrypted = "TopCoCISCodeEncrypted";
        public const string AssetDbFieldLegalEntityCISCodeEncrypted = "LegalEntityCISCodeEncrypted";
        public const string AssetDbFieldClientClassification = "ClientClassification";
        public const string AssetDbFieldSeniorityRank = "SeniorityRank";
        public const string AssetDbFieldFacilityInternalRating = "FacilityInternalRating";
        public const string AssetDbFieldDeskDesc = "DeskDesc";
        public const string AssetDbFieldSubDeskDesc = "SubDeskDesc";
        public const string AssetDbFieldCostCentreName = "CostCentreName";
        public const string AssetDbFieldCostCentreDesc = "CostCentreDesc";
        public const string AssetDbFieldCountryOfBalanceSheetLocation = "CountryOfBalanceSheetLocation";
        public const string AssetDbFieldTradingBankingIndicator = "TradingBankingIndicator";
        public const string AssetDbFieldDivisionName = "DivisionName";
        public const string AssetDbFieldBusinessConsolidation1Desc = "BusinessConsolidation1Desc";
        public const string AssetDbFieldBusinessConsolidation2Desc = "BusinessConsolidation2Desc";
        public const string AssetDbFieldBusinessConsolidation3Desc = "BusinessConsolidation3Desc";
        public const string AssetDbFieldBusinessConsolidation4Desc = "BusinessConsolidation4Desc";
        public const string AssetDbFieldBusinessConsolidation5Desc = "BusinessConsolidation5Desc";
        public const string AssetSicCode = "SicCode";
		public const string AssetDbFieldContractualSeniority = "ContractualSeniority";
        #endregion

        #region LoanOutsatnding Report
        public const string DbFieldFacilityCurrencyConcatenationString = "FacilityCurrencyConcatenationString";
        public const string DbFieldAsAtDate = "AsAtDate";
        public const string DbFieldPrimaryKey = "PrimaryKey";
        public const string DbFieldFacilityCurrencyCISConcatenationString = "FacilityCurrencyCISConcatenationString";
        public const string DbFieldDealName = "DealName";
        public const string DbFieldFacilityFCN = "FacilityFCN";
        public const string DbFieldFacilityName = "FacilityName";
        public const string DbFieldPrismIDorFCNid = "PrismIDorFCNid";
        public const string DbFieldFacilityPrismId = "FacilityPrismId";
        public const string DbFieldFacilityStatus = "FacilityStatus";
        public const string DbFieldFacilityType = "FacilityType";
        public const string DbFieldFacilityANSIId = "FacilityANSIId";
        public const string DbFieldLiqRiskBookCode = "LiqRiskBookCode";
        public const string DbFieldAgreementDate = "AgreementDate";
        public const string DbFieldEffectiveDate = "EffectiveDate";
        public const string DbFieldExpiryDate = "ExpiryDate";
        public const string DbFieldFinalMaturityDate = "FinalMaturityDate";
        public const string DbFieldFacilityCcy = "FacilityCcy";
        public const string DbFieldMidFactorOSTCcyEUR = "MidFactorOSTCcyEUR";
        public const string DbFieldDrawnEUR = "DrawnEUR";
        public const string DbFieldGlobalCurrentCommitment = "GlobalCurrentCommitment";
        public const string DbFieldMidFactorOSTCcyGBP = "MidFactorOSTCcyGBP";
        public const string DbFieldGlobalOutstandingCommitment = "GlobalOutstandingCommitment";
        public const string DbFieldDrawnGBP = "DrawnGBP";
        public const string DbFieldGlobalAvailabletoDraw = "GlobalAvailabletoDraw";
        public const string DbFieldMidFactorOSTCcyUSD = "MidFactorOSTCcyUSD";
        public const string DbFieldDrawnUSD = "DrawnUSD";
        public const string DbFieldMidFactorOSTCcyJPY = "MidFactorOSTCcyJPY";
        public const string DbFieldDrawnJPY = "DrawnJPY";
        public const string DbFieldHostBankNetCommitment = "HostBankNetCommitment";
        public const string DbFieldHostBankNetOutstanding = "HostBankNetOutstanding";
        public const string DbFieldOSTAlias = "OSTAlias";
        public const string DbFieldCurrentAmount = "CurrentAmount";
        public const string DbFieldOSTInternalId = "OSTInternalId";
        public const string DbFieldOriginalAmount = "OriginalAmount";
        public const string DbFieldMatchedFundedAmount = "MatchedFundedAmount";
        public const string DbFieldOSTType = "OSTType";
        public const string DbFieldNonMatchFundedAmount = "NonMatchFundedAmount";
        public const string DbFieldDiscountAmount = "DiscountAmount";
        public const string DbFieldOSTPricingOption = "OSTPricingOption";
        public const string DbFieldOSTSource = "OSTSource";
        public const string DbFieldOSTEffectiveDate = "OSTEffectiveDate";
        public const string DbFieldOSTRepricingDate = "OSTRepricingDate";
        public const string DbFieldOSTRePricingFreq = "OSTRePricingFreq";
        public const string DbFieldOSTBaseRate = "OSTBaseRate";
        public const string DbFieldOSTSpread = "OSTSpread";
        public const string DbFieldFxToFac = "FxToFac";
        public const string DbFieldOSTAllInRate = "OSTAllInRate";
        public const string DbFieldCSPLID = "CSPLID";
        public const string DbFieldOSTSpreadStartDate = "OSTSpreadStartDate";
        public const string DbFieldPerfStatusCode = "PerfStatusCode";
        public const string DbFieldHolidayCalendars = "HolidayCalendars";
        public const string DbFieldOSTCcy = "OSTCcy";
        public const string DbFieldCycleFrequencyPeriod = "CycleFrequencyPeriod";
        public const string DbFieldCycleFrequencyPeriodMultiplier = "CycleFrequencyPeriodMultiplier";
        public const string DbFieldOSTHostBankNet = "OSTHostBankNet";
        public const string DbFieldCurrentCycleStart = "CurrentCycleStart";
        public const string DbFieldBook = "Book";
        public const string DbFieldCurrentCycleEndDate = "CurrentCycleEndDate";
        public const string DbFieldAdjustedDueDate = "AdjustedDueDate";
        public const string DbFieldEndDateRuleDesc = "EndDateRuleDesc";
        public const string DbFieldActualDueDate = "ActualDueDate";
        public const string DbFieldRateBasis = "RateBasis";
        public const string DbFieldBorrowerLinkingString = "BorrowerLinkingString";
        public const string DbFieldBorrowerRID = "BorrowerRID";
        public const string DbFieldBorrowerCIS = "BorrowerCIS";
        public const string DbFieldBorrowerName = "BorrowerName";
        public const string DbFieldCountryOfResidence = "CountryOfResidence";
        public const string DbFieldCountryOfIncorporation = "CountryOfIncorporation";
        public const string DbFieldCountryOfRisk = "CountryOfRisk";
        public const string DbFieldAgent = "Agent";
        public const string DbFieldCompanyNumber = "CompanyNumber";
        public const string DbFieldLev1 = "Lev1";
        public const string DbFieldLev2 = "Lev2";
        public const string DbFieldLev3 = "Lev3";
        public const string DbFieldCountryOfCollateral = "CountryOfCollateral";
        public const string DbFieldAssetTypeMB = "AssetTypeMB";
        public const string DbFieldRatingSource = "RatingSource";
        public const string DbFieldIsConduit = "IsConduit";
        public const string DbFieldFormat = "Format";
        public const string DbFieldRatingSP = "RatingSP";
        public const string DbFieldRatingMD = "RatingMD";
        public const string DbFieldRatingFT = "RatingFT";
        public const string DbFieldRatingDBRS = "RatingDBRS";
        public const string DbFieldRatingARC = "RatingARC";
        public const string DbFieldPreclearedMedio = "PreclearedMedio";
        public const string DbFieldPreclearableMedio = "PreclearableMedio";
        public const string DbFieldSponsor = "Sponsor";
        public const string DbFieldBorrowerInternalRating = "BorrowerInternalRating";
        public const string DbFieldBorrowerInternalRatingImplied = "BorrowerInternalRatingImplied";
        public const string DbFieldGradingScaleCode = "GradingScaleCode";
        public const string DbFieldGradingModelCode = "GradingModelCode";
        public const string DbFieldGradingScale = "GradingScale";
        public const string DbFieldGradingModel = "GradingModel";
        public const string DbFieldRatingApprovalDate = "RatingApprovalDate";
        public const string DbFieldIBCAShortTermRating = "IBCAShortTermRating";
        public const string DbFieldIBCALongTermRating = "IBCALongTermRating";
        public const string DbFieldUltimateRiskParentCISCode = "UltimateRiskParentCISCode";
        public const string DbFieldMoodysLongTermCPRatingGrdm = "MoodysLongTermCPRatingGrdm";
        public const string DbFieldMoodysSTCRatingGrdm = "MoodysSTCRatingGrdm";
        public const string DbFieldSPShortTermRatingGrdm = "SPShortTermRatingGrdm";
        public const string DbFieldSPLongTermRatingGrdm = "SPLongTermRatingGrdm";
        public const string DbFieldOECDMarker = "OECDMarker";
        public const string DbFieldDoTEligible = "DoTEligible";
        public const string DbFieldDoTRecordDate = "DoTRecordDate";
        public const string DbFieldDoTContact = "DoTContact";
        public const string DbFieldDoTComments = "DoTComments";
        public const string DbFieldECBEligible = "ECBEligible";
        public const string DbFieldECBRecordDate = "ECBRecordDate";
        public const string DbFieldECBContact = "ECBContact";
        public const string DbFieldECBComments = "ECBComments";
        public const string DbFieldNoBorrowerSetOff = "NoBorrowerSetOff";
        public const string DbFieldContractLaw = "ContractLaw";
        public const string DbFieldW8Sent = "W8Sent";
        public const string DbFieldW8SentDate = "W8SentDate";
        public const string DbFieldW8Sender = "W8Sender";
        public const string DbFieldTaxEligibilityOverride = "TaxEligibilityOverride";
        public const string DbFieldTaxRecordDate = "TaxRecordDate";
        public const string DbFieldTaxContact = "TaxContact";
        public const string DbFieldTaxComments = "TaxComments";
        public const string DbFieldFacilityWarnings = "FacilityWarnings";
        public const string DbFieldEligibilityComments1 = "EligibilityComments1";
        public const string DbFieldEligibilityComments2 = "EligibilityComments2";
        public const string DbFieldEligibilityComments3 = "EligibilityComments3";
        public const string DbFieldFacilityEncumberedOutsideProcess = "FacilityEncumberedOutsideProcess";
        public const string DbFieldTimeToLegalMaturity = "TimeToLegalMaturity";
        public const string DbFieldTimeToLegalMaturityBucket = "TimeToLegalMaturityBucket";
        public const string DbFieldExpectedAmortisationTime = "ExpectedAmortisationTime";
        public const string DbFieldTimeToAmortisationMaturityBucket = "TimeToAmortisationMaturityBucket";
        public const string DbFieldIneligibilityExceptions = "IneligibilityExceptions";
        public const string DbFieldEntity = "Entity";
        public const string DbFieldCountryOfTaxClassification = "CountryOfTaxClassification";
        public const string DbFieldCountryOfTaxNote = "CountryOfTaxNote";
        public const string DbFieldIneligibilityValidation = "IneligibilityValidation";
        public const string DbFieldAssessmentNeeded = "AssessmentNeeded";
        public const string DbFieldConditionPrecedents = "ConditionPrecedents";
        public const string DbFieldSNPEligibility = "SNPEligibility";
        public const string DbFieldRSFUnencumbered = "RSFUnencumbered";
        public const string DbFieldTopCoCISCodeEncrypted = "TopCoCISCodeEncrypted";
        public const string DbFieldLegalEntityCISCodeEncrypted = "LegalEntityCISCodeEncrypted";
        public const string DbFieldClientClassification = "ClientClassification";
        public const string DbFieldSeniorityRank = "SeniorityRank";
        public const string DbFieldFacilityInternalRating = "FacilityInternalRating";
        public const string DbFieldDeskId = "DeskId";
        public const string DbFieldDeskDesc = "DeskDesc";
        public const string DbFieldSubDeskDesc = "SubDeskDesc";
        public const string DbFieldCostCentreName = "CostCentreName";
        public const string DbFieldCostCentreDesc = "CostCentreDesc";
        public const string DbFieldSeniorTraderName = "SeniorTraderName";
        public const string DbFieldCountryOfBalanceSheetLocation = "CountryOfBalanceSheetLocation";
        public const string DbFieldTradingBankingIndicator = "TradingBankingIndicator";
        public const string DbFieldDivisionName = "DivisionName";
        public const string DbFieldBusinessConsolidation1Desc = "BusinessConsolidation1Desc";
        public const string DbFieldBusinessConsolidation2Desc = "BusinessConsolidation2Desc";
        public const string DbFieldBusinessConsolidation3Desc = "BusinessConsolidation3Desc";
        public const string DbFieldBusinessConsolidation4Desc = "BusinessConsolidation4Desc";
        public const string DbFieldBusinessConsolidation5Desc = "BusinessConsolidation5Desc";
        public const string DbFieldSicCode = "SicCode";

        #endregion

        #endregion


        #region NWM Staging Table Columns 

        public const string DbColumnPROrFCN = "PROrFCN";
        public const string DbColumnCCY = "CCY";
        public const string DbColumnCIS = "CIS";
        public const string DbColumnTradeAllocated = "TradeAllocated";
        public const string DbColumnPercentAllocated = "PercentAllocated";
        public const string DbColumnSystemLoadDate = "SYSTEM_LOAD_DATE";
        public const string DbColumnAsAtDate = "AS_AT_DATE";

        public const string DbColumnSECUREDLIABILITYNAME = "SECUREDLIABILITYNAME";
        public const string DbColumnSERIES = "SERIES";
        public const string DbColumnISIN = "ISIN";
        public const string DbColumnCOLLATERALASSETCOMPANYNUCLEUSID = "COLLATERALASSETCOMPANYNUCLEUSID";
        public const string DbColumnFORMATColumn = "FORMAT";
        public const string DbColumnMETHOD = "METHOD";
        public const string DbColumnCOLLATERALISATIONTYPE = "COLLATERALISATIONTYPE";
        public const string DbColumnLIABILITYCCY = "LIABILITYCCY";
        public const string DbColumnISSUESIZENATIVECCY = "ISSUESIZENATIVECCY";
        public const string DbColumnSCHEDULEDMATURITY = "SCHEDULEDMATURITY";
        public const string DbColumnCOLLATERALISATIONPERCENT = "COLLATERALISATIONPERCENT";
        public const string DbColumnINDICATIVEOVERCOLLPERCENT = "INDICATIVEOVERCOLLPERCENT";
        public const string DbColumnACTIVETRADE = "ACTIVETRADE";
        public const string DbColumnTRADEGROUP = "TRADEGROUP";
        public const string DbColumnVANDRA = "VANDRA";
        public const string DbColumnRUBIXIDENTIFIER = "RUBIXIDENTIFIER";
        public const string DbColumnMTASPV = "MTASPV";
        public const string DbColumnMTANWM = "MTANWM";
        public const string DbColumnREPORTINGTEMPLATE = "REPORTINGTEMPLATE";

        public const string DbColumnPRISMID = "PRISMID";
        public const string DbColumnPROJECTNAME = "PROJECTNAME";
        public const string DbColumnCOUNTRYOFCOLLATERAL = "COUNTRYOFCOLLATERAL";
        public const string DbColumnASSETTYPEMB = "ASSETTYPEMB";
        public const string DbColumnRATINGSOURCE = "RATINGSOURCE";
        public const string DbColumnISCONDUIT = "ISCONDUIT";
        public const string DbColumnFORMAT = "FORMAT";
        public const string DbColumnRATINGSP = "RATINGSP";
        public const string DbColumnRATINGMD = "RATINGMD";
        public const string DbColumnRATINGFT = "RATINGFT";
        public const string DbColumnRATINGDBRS = "RATINGDBRS";
        public const string DbColumnRATINGARC = "RATINGARC";
        public const string DbColumnPRECLEAREDMEDIO = "PRECLEAREDMEDIO";
        public const string DbColumnPRECLEARABLEMEDIO = "PRECLEARABLEMEDIO";

        public const string DbColumnLAW = "LAW";
        public const string DbColumnTYPE = "TYPE";
        public const string DbColumnSPONSOR = "SPONSOR";

        public const string DbColumnFACILITYID = "FACILITYID";
        public const string DbColumnCLIENTCLASSIFICATION = "CLIENTCLASSIFICATION";
        public const string DbColumnSENIORITYRANK = "SENIORITYRANK";
        public const string DbColumnNORESTRICTIONCONFIDENTIALITY = "NORESTRICTIONCONFIDENTIALITY";
        public const string DbColumnGOVERNINGLAW = "GOVERNINGLAW";

        public const string DbColumnDOTELIGIBLE = "DOTELIGIBLE";
        public const string DbColumnDOTRECORDDATE = "DOTRECORDDATE";
        public const string DbColumnDOTCONTACT = "DOTCONTACT";
        public const string DbColumnDOTCOMMENTS = "DOTCOMMENTS";
        public const string DbColumnECBELIGIBLE = "ECBELIGIBLE";
        public const string DbColumnECBRECORDDATE = "ECBRECORDDATE";
        public const string DbColumnECBCONTACT = "ECBCONTACT";
        public const string DbColumnECBCOMMENTS = "ECBCOMMENTS";
        public const string DbColumnNOBORROWERSETOFF = "NOBORROWERSETOFF";
        public const string DbColumnCONTRACTLAW = "CONTRACTLAW";
        public const string DbColumnW8SENT = "W8SENT";
        public const string DbColumnW8SENTDATE = "W8SENTDATE";
        public const string DbColumnW8SENDER = "W8SENDER";
        public const string DbColumnTAXELIGIBILITYOVERRIDE = "TAXELIGIBILITYOVERRIDE";
        public const string DbColumnTAXRECORDDATE = "TAXRECORDDATE";
        public const string DbColumnTAXCONTACT = "TAXCONTACT";
        public const string DbColumnTAXCOMMENTS = "TAXCOMMENTS";
        public const string DbColumnFACILITYWARNINGS = "FACILITYWARNINGS";
        public const string DbColumnELIGIBILITYCOMMENTS1 = "ELIGIBILITYCOMMENTS1";
        public const string DbColumnELIGIBILITYCOMMENTS2 = "ELIGIBILITYCOMMENTS2";
        public const string DbColumnELIGIBILITYCOMMENTS3 = "ELIGIBILITYCOMMENTS3";
        public const string DbColumnFACILITYENCUMBEREDOUTSIDEPROCESS = "FACILITYENCUMBEREDOUTSIDEPROCESS";
        #endregion

        #region NWM Staging Tables  

        public const int AssetRegisterFileInfoId = 6;
        public const int GearsStaticFileInfoId = 5;


        public const string DbTableNWMStaticFileAssetRegister = "stage.NWMStaticFile_AssetRegister";
        public const string DbTableNWMStaticFileSecuredLiabilityAttributes = "stage.NWMStaticFile_SecuredLiabilityAttributes";
        public const string DbTableNWMStaticFileSPStatics = "stage.NWMStaticFile_SPStatics";
        public const string DbTableNWMStaticFileFundFinancingAndOtherStatics = "stage.NWMStaticFile_FundFinancingAndOtherStatics";
        public const string DbTableNWMStaticFileFIPortfolioStatics = "stage.NWMStaticFile_FIPortfolioStatics";
        public const string DbTableNWMStaticFileEncumberanceMethodStatics = "stage.NWMStaticFile_EncumberanceMethodStatics";
        #endregion
    }


    #region DML Type Enum
    public enum DMLType
    {
        Insert = 1,
        Update = 2,
        Delete = 3
    }
    #endregion
}