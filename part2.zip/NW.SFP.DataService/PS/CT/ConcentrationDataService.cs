﻿using Microsoft.Extensions.Options;
using Newtonsoft.Json;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class ConcentrationDataService : IConcentrationDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public ConcentrationDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        #region Save Concentration Test
        public string SaveConcentration(ConcentrationTest concentrationTest, string userName)
        {
            try
            {
                int rowsInserted = 0;
                dynamic result = null;
                int InitialStatus = concentrationTest.Status == "Draft" ? 1 : -1;

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_CT_SaveConcentration, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(DbProcParamCtId, concentrationTest.Id);
                    cmd.Parameters.AddWithValue(DbProcParamCtName, concentrationTest.Name);
                    cmd.Parameters.AddWithValue(DbProcParamCtDescription, concentrationTest.Description);
                    cmd.Parameters.AddWithValue(DbProcParamCtType, concentrationTest.Type);
                    cmd.Parameters.AddWithValue(DbProcParamCtTag, concentrationTest.TagList);
                    cmd.Parameters.AddWithValue(DbProcParamCtStatus, InitialStatus);
                    cmd.Parameters.AddWithValue(DbProcParamCtAssetType, concentrationTest.AssetClass);
                    if (concentrationTest.IsMultiConditionReq)
                    {
                        if (concentrationTest.Type == 1 || concentrationTest.Type == 3)
                        {
                            cmd.Parameters.AddWithValue(DbProcParamRefFieldId, concentrationTest.CTConditionsSubSet[0].FieldId);
                        }
                        else
                        {
                            cmd.Parameters.AddWithValue(DbProcParamRefFieldId, DBNull.Value);
                        }
                        cmd.Parameters.AddWithValue(DbProcParamCtConditionalOperator, DBNull.Value);
                        cmd.Parameters.AddWithValue(DbProcParamCtConditionalValue, DBNull.Value);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue(DbProcParamRefFieldId, concentrationTest.CTConditionsSubSet[0].FieldId);
                        cmd.Parameters.AddWithValue(DbProcParamCtConditionalOperator, concentrationTest.CTConditionsSubSet[0].ConditionalOperator);
                        cmd.Parameters.AddWithValue(DbProcParamCtConditionalValue, concentrationTest.CTConditionsSubSet[0].ConditionalValue);
                        concentrationTest.CTConditionsSubSet.Clear();

                    }
                    cmd.Parameters.AddWithValue(DbProcParamCtLimitOperator, concentrationTest.LimitOperator);
                    cmd.Parameters.AddWithValue(DbProcParamCtLimitPercentage, concentrationTest.LimitValue);
                    cmd.Parameters.AddWithValue(DbProcParamCtExpression, concentrationTest.ConcentrationExpression);
                    cmd.Parameters.AddWithValue(DbProcParamCtExpressionSuperset, concentrationTest.CTExpressionSuperSet);
                    cmd.Parameters.AddWithValue(DbProcParamCtUserName, userName);
                    cmd.Parameters.AddWithValue(DbProcParamCTConditionsSuperset, FillConditionTable(concentrationTest.CTConditionsSuperSet));
                    cmd.Parameters.AddWithValue(DbProcParamCTConditionsSubset, FillConditionTable(concentrationTest.CTConditionsSubSet));

                    if (concentrationTest.Id == 0)
                    {
                        cmd.Parameters.AddWithValue(DbProcParamCtDMLType, DMLType.Insert);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue(DbProcParamCtDMLType, DMLType.Update);
                    }
                    cmd.Parameters.AddWithValue(DbProcParamCTpIsSubSetReq, concentrationTest.IsSubSetReq);
                    SqlParameter cmdOutRetVal = new SqlParameter();
                    cmdOutRetVal.ParameterName = DbProcParamCtReturnValue;
                    cmdOutRetVal.Direction = ParameterDirection.Output;
                    cmdOutRetVal.SqlDbType = SqlDbType.Int;
                    cmd.Parameters.Add(cmdOutRetVal);

                    SqlParameter cmdOutRetMsg = new SqlParameter();
                    cmdOutRetMsg.ParameterName = DbProcParamCtReturnMessage;
                    cmdOutRetMsg.Direction = ParameterDirection.Output;
                    cmdOutRetMsg.SqlDbType = SqlDbType.VarChar;
                    cmdOutRetMsg.Size = 100;
                    cmd.Parameters.Add(cmdOutRetMsg);

                    rowsInserted = cmd.ExecuteNonQuery();
                    result = new
                    {
                        returnCode = Convert.ToInt32(cmdOutRetVal.Value),
                        returnMessage = Convert.ToString(cmdOutRetMsg.Value)
                    };
                }
                return JsonConvert.SerializeObject(result);
            }
            catch
            {
                throw;
            }        
        }
        #endregion

        #region Amend Concentration Test
        public int AmendConcentration(ConcentrationTest concentrationTest, string userName)
        {
            int returnCode;
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_AmendConcentration, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamCtId, concentrationTest.Id);
                cmd.Parameters.AddWithValue(DbProcParamCtDescription, concentrationTest.Description);
                cmd.Parameters.AddWithValue(DbProcParamCtTag, concentrationTest.TagList);
                cmd.Parameters.AddWithValue(DbProcParamComment, concentrationTest.SaveComment);
                cmd.Parameters.AddWithValue(DbProcParamCtUserName, userName);
                cmd.Parameters.AddWithValue(DbProcParamCtModifiedDate, concentrationTest.ModifiedDate);

                SqlParameter cmdOutRetVal = new SqlParameter
                {
                    ParameterName = DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutRetVal);
                cmd.ExecuteNonQuery();
                returnCode = Convert.ToInt32(cmdOutRetVal.Value);
                return returnCode;
            }
        }
        #endregion

        #region Get Concentration Test List 
        public IList<ConcentrationTestList> GetConcentrationTestList(int assseClassId, string userName)
        {
            IList<ConcentrationTestList> concTestList = new List<ConcentrationTestList>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetConcentrationTestList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbProcParamPoolAssetClassId, assseClassId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    concTestList.Add(new ConcentrationTestList()
                    {
                        CTId = Utility.GetInt(reader[DbFieldConcTestListId]),
                        Name = Utility.GetString(reader[DbFieldConcTestListName]),
                        Type = Utility.GetString(reader[DbFieldConcTestListType]),
                        Tag = Utility.GetString(reader[DbFieldConcTestListTag]),
                        Status = Utility.GetString(reader[DbFieldConcTestListStatus]),
                        Expression = Utility.GetString(reader[DbFieldConcTestListExpression]),
                        CreatedBy = Utility.GetString(reader[DbFieldConcTestListCreatedBy]),
                        CreatedDate = Utility.GetDateTimeNullable(reader[DbFieldCreatedDate]),
                        ModifiedDate = Utility.GetDateTimeNullable(reader[DbFieldModifiedDate])
                    });
                }
            }
            return concTestList;
        }
        #endregion


        #region Delete Concentration Test
        public int DeleteConcentrationTest(int concTestId, string userName)
        {
            int returnCode;

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_DeleteConcentrationTestList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DBProcParamConcTestId, concTestId);
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.Add(DbProcParamLinkedReturnCode, SqlDbType.Int);
                cmd.Parameters[DbProcParamLinkedReturnCode].Direction = ParameterDirection.Output;
                int rowsAffected = cmd.ExecuteNonQuery();

                int linkedReturnCode = Convert.ToInt32(cmd.Parameters[DbProcParamLinkedReturnCode].Value);
                returnCode = (linkedReturnCode == -2) ? linkedReturnCode : rowsAffected;
            }
            return returnCode;
        }
        #endregion

        #region Get Concentration Test By ID

        public ConcentrationTest GetConcentrationTestByID(int concentrationTestId)
        {
            ConcentrationTest concDetailList = new ConcentrationTest();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetConcentrationTestDetail, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DBProcParamConcTestId, concentrationTestId);

                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    concDetailList = new ConcentrationTest()
                    {
                        Id = Utility.GetInt(reader[DbFieldConcTestListId]),
                        Name = Utility.GetString(reader[DbFieldConcTestListName]),
                        Description = Utility.GetString(reader[DbFieldConcTestListDescription]),
                        Type = Utility.GetInt(reader[DbFieldConcTestListType]),
                        TagList = Utility.GetString(reader[DbFieldConcTestListTag]),
                        AssetClass = Utility.GetInt(reader[DbFieldConcTestListAssetClass]),
                        Status = Utility.GetString(reader[DbFieldConcTestListStatus]),
                        FieldId = Utility.GetInt(reader[DbFieldConcTestListFieldId]),
                        ConditionalOperator = Utility.GetInt(reader[DbFieldConcTestListConditionalOperator]),
                        ConditionalValue = Utility.GetString(reader[DbFieldConcTestListConditionalValue]),
                        LimitOperator = Utility.GetInt(reader[DbFieldConcTestListLimitOperator]),
                        LimitValue = Utility.GetDecimal(reader[DbFieldConcTestListLimitValue]),
                        ConcentrationExpression = Utility.GetString(reader[DbFieldConcTestListConcentrationExpression]),
                        CTExpressionSuperSet = Utility.GetString(reader[DbFieldConcTestListCTExpressionSuperSet]),
                        CreatedBy = Utility.GetString(reader[DbFieldConcTestListCreatedBy]),
                        IsSubSetReq = Utility.GetBool(reader[DbFieldConcTestListIsSubsetRequired])
                    };
                    reader.NextResult();
                    if (reader.HasRows)
                    {
                        concDetailList.CTConditionsSuperSet.AddRange(GetCTCondtionData(reader));
                    }
                    reader.NextResult();
                    if (reader.HasRows)
                    {
                        concDetailList.CTConditionsSubSet.AddRange(GetCTCondtionData(reader));
                    }

                }
                return concDetailList;
            }

        }
        #endregion

        #region Private Methods
        private static DataTable FillConditionTable(IList<ConcentrationTestCondition> conditionList)
        {
            var conditionItemsList = new DataTable();
            conditionItemsList.Columns.Add("Id", typeof(int));
            conditionItemsList.Columns.Add("FieldId", typeof(int));
            conditionItemsList.Columns.Add("Condition", typeof(string)).MaxLength = 20;
            conditionItemsList.Columns.Add("ConditionalOperator", typeof(int));
            conditionItemsList.Columns.Add("ConditionalValue", typeof(string));

            foreach (var pConditionItem in conditionList)
            {
                conditionItemsList.Rows.Add(
                    Utility.GetIntNullable(pConditionItem.Id),
                    Utility.GetIntNullable(pConditionItem.FieldId),
                    Utility.GetString(pConditionItem.Condition),
                    Utility.GetIntNullable(pConditionItem.ConditionalOperator),
                    Utility.GetString(pConditionItem.ConditionalValue)
                 );
            }

            return conditionItemsList;
        }

        private List<ConcentrationTestCondition> GetCTCondtionData(SqlDataReader reader)
        {
            var listBasicLookUpData = new List<ConcentrationTestCondition>();
            while (reader.Read())
            {
                ConcentrationTestCondition objBasicLookUpData = new ConcentrationTestCondition
                {
                    Id = Utility.GetInt(reader["Id"]),
                    FieldId = Utility.GetInt(reader["EligibilityCriteriaFieldId"]),
                    Condition = Utility.GetString(reader["Condition"]),
                    ConditionalOperator = Utility.GetInt(reader["OperatorId"]),
                    ConditionalValue = Utility.GetString(reader["ExpectedValue"])
                };
                listBasicLookUpData.Add(objBasicLookUpData);
            }
            return listBasicLookUpData;
        }
        #endregion

    }
}
