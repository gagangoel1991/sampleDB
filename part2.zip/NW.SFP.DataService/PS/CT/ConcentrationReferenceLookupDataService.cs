﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;

namespace NW.SFP.DataService.PS
{
    public class ConcentrationReferenceLookupDataService : IConcentrationReferenceLookupDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public ConcentrationReferenceLookupDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public ConcentrationReferenceData GetConcentrationReferenceData(int assetClassId, string userName)
        {
            ConcentrationReferenceData objCTReferenceData = new ConcentrationReferenceData();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_CT_GetConcentrationReferenceData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolAssetClassId, assetClassId);

                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Get Field Data
                        objCTReferenceData.Fields.AddRange(GetFieldLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Get Concentration Type
                        objCTReferenceData.ConcentrationType.AddRange(GetBasicLookUpData(resultReader));
                    }
                    
                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Get Asset Data
                        objCTReferenceData.AssetType.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Get Operators Data
                        objCTReferenceData.Operators.AddRange(GetOperatorLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Get Concentration Tag
                        objCTReferenceData.ConcentrationTag.AddRange(GetBasicLookUpData(resultReader));
                    }
                }
            }
            return objCTReferenceData;
        }

        public List<BasicLookUpData> GetConcentrationFieldsData(string type, int assetClassId, string userName)
        {
            List<BasicLookUpData> lstFieldData = new List<BasicLookUpData>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_CT_GetConcentrationFields, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamType, type);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolAssetClassId, assetClassId);

                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Get Field List Data
                        lstFieldData.AddRange(GetFieldLookUpData(resultReader));
                    }
                }
            }
            return lstFieldData;
        }
        public ConcentrationFieldReferenceData GetConcentrationFieldReferenceData(int fieldId, string userName)
        {
            ConcentrationFieldReferenceData concentrationFieldReferenceData = new ConcentrationFieldReferenceData();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_CT_GetConcentrationFieldRefData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();

                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamRefFieldId, fieldId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Get Operator List Data
                        concentrationFieldReferenceData.Operators.AddRange(GetOperatorLookUpData(resultReader));
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        //Get Field Reference Lookup Data
                        concentrationFieldReferenceData.FieldLookupValue.AddRange(GetFieldRefLookUpData(resultReader));
                    }
                }
            }
            return concentrationFieldReferenceData;
        }
        private IList<BasicLookUpData> GetBasicLookUpData(SqlDataReader resultReader)
        {
            var listBasicLookUpData = new List<BasicLookUpData>();
            while (resultReader.Read())
            {
                BasicLookUpData objBasicLookUpData = new BasicLookUpData
                {
                    Value = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]),
                    Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle])
                };
                listBasicLookUpData.Add(objBasicLookUpData);
            }
            return listBasicLookUpData;
        }
        private IList<BasicLookUpData> GetFieldLookUpData(SqlDataReader resultReader)
        {
            var listFieldLookUpData = new List<BasicLookUpData>();
            while (resultReader.Read())
            {
                FieldLookUp objFieldLookUpData = new FieldLookUp
                {
                    Value = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]),
                    Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]),
                    Type = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataType]),
                    Description = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataDescription]),
                    ReferenceLookup = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataReferenceLookup]),
                    IsAuthorised = Utility.GetBool(resultReader[DbConstants.DbFieldLookupDataIsAuthorised])

                };
                listFieldLookUpData.Add(objFieldLookUpData);
            }
            return listFieldLookUpData;
        }
        private IList<BasicLookUpData> GetOperatorLookUpData(SqlDataReader resultReader)
        {
            var listOperatorLookUpData = new List<BasicLookUpData>();
            while (resultReader.Read())
            {
                OperatorLookup objOperatorLookUpData = new OperatorLookup
                {
                    Value = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]),
                    Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]),
                    Type = Utility.GetString(resultReader[DbConstants.DbOperatorLookupDataType]),
                    Text = Utility.GetString(resultReader[DbConstants.DbOperatorLookupDataText]),
                };
                listOperatorLookUpData.Add(objOperatorLookUpData);
            }
            return listOperatorLookUpData;
        }
        private IList<BasicLookUpData> GetFieldRefLookUpData(SqlDataReader resultReader)
        {
            var listFieldRefLookUpData = new List<BasicLookUpData>();
            while (resultReader.Read())
            {
                FieldRefLookUp objFieldRefLookUpData = new FieldRefLookUp
                {
                    Value = Utility.GetString(resultReader[DbConstants.DbFieldRefLookupDataValue]),
                    Title = Utility.GetString(resultReader[DbConstants.DbFieldRefLookupDataTitle]),
                };
                listFieldRefLookUpData.Add(objFieldRefLookUpData);
            }
            return listFieldRefLookUpData;
        }
    }
}
