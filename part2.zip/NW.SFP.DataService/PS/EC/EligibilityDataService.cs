﻿using Microsoft.Extensions.Options;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.DataService.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Reflection;
using Newtonsoft.Json;
using System.Linq;
using Newtonsoft.Json.Linq;
using System.Text.RegularExpressions;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class EligibilityDataService : IEligibilityDataService
    {
        #region Object Declarations and Constructor
        private readonly IOptions<DataServiceSettings> _settings;
        
        //Variable declaration - for rule JSON Parsing while inserting eligibility
        IList<QueryExpressionRule> lstRules = new List<QueryExpressionRule>();
        int parentIndex = 0, groupIndex = 1, ruleIndex = 1;
        //Variable pPlaceholderIndex = groupIndex
        int pPlaceholderIndex = 1, gPlaceholderIndex = 1, groupCounter = 1;
        string rulesetCondition;
        
        public EligibilityDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        #endregion

        #region Get Eligibility Custom Fields
        public IDictionary<string, EligibilityCriteria.Field> GetEligibilityFields(int assetId)
        {
            try
            {
                IDictionary<string, EligibilityCriteria.Field> fieldList = new Dictionary<string, EligibilityCriteria.Field>();

                // Entity Rule Type(Entities), Field Options and Operators
                IList<EligibilityCriteria.EntityRuleType> entityRuleTypes = GetEntityRuleType();
                IList<EligibilityCriteria.EntityRuleFieldOption> entityRuleFieldOptions = GetEntityRuleFieldOptions();
                DataTable entityRuleOperators = GetEntityRuleOperators();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEligibilityFields, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(AssetClassIdInput, assetId);
                    
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        EligibilityCriteria.Field field = new EligibilityCriteria.Field()
                        {
                            Id = Utility.GetString(reader["Id"]),
                            Name = Utility.GetString(reader["Name"]),
                            Type = Utility.GetString(reader["Type"]),
                            Description = Utility.GetString(reader["Description"]),
                            Source = Utility.GetString(reader["Source"]),
                            EntityExpression = Utility.GetString(reader["EntityExpression"]),
                            ReferenceLookup = Utility.GetString(reader["ReferenceLookup"]),
                            Operators = entityRuleOperators.AsEnumerable()
                                        .Where(x => x.Field<string>("TypeName").ToLower() == Utility.GetString(reader["Type"]))
                                        .Select(x=> x.Field<string>("Operator")).ToList<string>(),
                            Entity = Utility.GetString(reader["EntityRule"]),
                            Entities = entityRuleTypes,
                            EntityRuleFieldOption = entityRuleFieldOptions
                                                    .Where(x => x.MasterId == Utility.GetString(reader["Id"]))
                                                    .ToList(),
                            //Validator = reader["Validator"]
                            Authorised = Utility.GetInt(reader["IsAuthorised"])
                        };
                        IList<EligibilityCriteria.ReferenceOption> reference = GetFieldLookupData("SFP+", field.ReferenceLookup.ToString());
                        field.Options = reference;

                        fieldList.Add(Utility.GetString(reader["Name"]), field);
                    }
                    return fieldList;
                }
            }
            catch
            {
                throw;
            }
        }

        #region Get Eligibility Fields Lookup Data
        public IList<EligibilityCriteria.ReferenceOption> GetFieldLookupData(string tempName, string fieldName)
        {
            try
            {
                IList<EligibilityCriteria.ReferenceOption> fieldOptionList = new List<EligibilityCriteria.ReferenceOption>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetFieldLookupData, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(TemplateName, tempName);
                    cmd.Parameters.AddWithValue(FieldName, fieldName);
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        fieldOptionList.Add(new EligibilityCriteria.ReferenceOption()
                        {
                            Name = Utility.GetString(reader["Options"]),
                            Value = Utility.GetString(reader["Value"]),
                        });
                    }
                    return fieldOptionList;
                }
            }

            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Entity RuleType/Entities and Field Options
        public IList<EligibilityCriteria.EntityRuleType> GetEntityRuleType()
        {
            try
            {
                IList<EligibilityCriteria.EntityRuleType> entityRuleType = new List<EligibilityCriteria.EntityRuleType>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEntityRuleType, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    
                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        entityRuleType.Add(new EligibilityCriteria.EntityRuleType()
                        {
                            Value = Utility.GetString(reader["Id"]),
                            Name = Utility.GetString(reader["Name"])
                        });
                    }
                    return entityRuleType;
                }
            }

            catch
            {
                throw;
            }
        }
        public IList<EligibilityCriteria.EntityRuleFieldOption> GetEntityRuleFieldOptions()
        {
            try
            {
                IList<EligibilityCriteria.EntityRuleFieldOption> entityRuleFieldOption = new List<EligibilityCriteria.EntityRuleFieldOption>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEntityRuleFieldOption, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        entityRuleFieldOption.Add(new EligibilityCriteria.EntityRuleFieldOption()
                        {
                            MasterId = Utility.GetString(reader["MasterFieldId"]),
                            FieldId = Utility.GetString(reader["FieldOptionId"]),
                            Name = Utility.GetString(reader["FieldName"]),
                            Authorised = Utility.GetInt(reader["IsAuthorised"])
                        });
                    }
                    return entityRuleFieldOption;
                }
            }

            catch
            {
                throw;
            }
        }
        public DataTable GetEntityRuleOperators()
        {
            try
            {
                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEntityRuleOperators, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlDataReader reader = cmd.ExecuteReader();
                    DataTable dt = new DataTable();
                    dt.Load(reader);
                    return dt;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion
        #endregion

        #region Get Eligibility Regulation
        public IList<EligibilityCriteria.ECRegulation> GetEligibilityRegulation()
        {
            try
            {
                IList<EligibilityCriteria.ECRegulation> ecRegulationList = new List<EligibilityCriteria.ECRegulation>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEligibilityRegulation, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ecRegulationList.Add(new EligibilityCriteria.ECRegulation()
                        {
                            RegulationId = Utility.GetString(reader["RegulationId"]),
                            Name = Utility.GetString(reader["Name"]),
                            Description = Utility.GetString(reader["Description"]),
                            AssetClassId = Utility.GetString(reader["AssetClassId"]),
                        });
                    }
                    return ecRegulationList;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Eligibility Type
        public IList<EligibilityCriteria.ECType> GetEligibilityType(int assetId)
        {
            try
            {
                IList<EligibilityCriteria.ECType> ecTypeList = new List<EligibilityCriteria.ECType>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEligibilityType, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(AssetClassIdInput, assetId);
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        ecTypeList.Add(new EligibilityCriteria.ECType()
                        {
                            TypeId = Utility.GetString(reader["TypeId"]),
                            Name = Utility.GetString(reader["Name"]),
                            Description = Utility.GetString(reader["Description"]),
                        });
                    }
                    return ecTypeList;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Eligibility FieldInfo
        public IList<EligibilityCriteria.FieldInfo> GetEligibilityFieldInfo(int fieldId)
        {
            try
            {
                IList<EligibilityCriteria.FieldInfo> ecTypeList = new List<EligibilityCriteria.FieldInfo>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEligibilityFieldInfo, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(FieldId, fieldId);

                    SqlDataReader reader = cmd.ExecuteReader();
                    while (reader.Read())
                    {
                        ecTypeList.Add(new EligibilityCriteria.FieldInfo()
                        {
                            Id = Utility.GetString(reader["Id"]),
                            Name = Utility.GetString(reader["Name"]),
                            Entity = Utility.GetString(reader["Entity"]),
                            Description = Utility.GetString(reader["Description"]),
                            Source = Utility.GetString(reader["Source"])
                        });

                    }
                    return ecTypeList;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Save Eligibility
        public string SaveEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes, string userName)
        {
            try
            {
                int rowsInserted = 0;
                dynamic result = null;

                IList<QueryExpressionRule> ecRules = ConvertStructureToDatatable(eligibilityCriteriaAttributes.EligibilityStructure);                
                DataTable dtRules = ToDataTable<QueryExpressionRule>(ecRules);

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_SaveEligibilityCriteria, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;

                    cmd.Parameters.AddWithValue(ECID, eligibilityCriteriaAttributes.ECID);
                    cmd.Parameters.AddWithValue(ECName, eligibilityCriteriaAttributes.Name);
                    cmd.Parameters.AddWithValue(ECDescription, eligibilityCriteriaAttributes.Description);
                    cmd.Parameters.AddWithValue(ECTypeId, eligibilityCriteriaAttributes.Type);
                    cmd.Parameters.AddWithValue(ApplicableAt, eligibilityCriteriaAttributes.ApplicableAt);
                    cmd.Parameters.AddWithValue(AssetClassId, eligibilityCriteriaAttributes.AssetClass);                    
                    cmd.Parameters.AddWithValue(EligibilityExpression, eligibilityCriteriaAttributes.EligibilityExpression);                    
                    cmd.Parameters.AddWithValue(RuleList, dtRules);
                    cmd.Parameters.AddWithValue(CreatedBy, userName);
                    cmd.Parameters.AddWithValue(ModifiedBy, userName);
                    if (eligibilityCriteriaAttributes.ECID == 0)
                    {
                        cmd.Parameters.AddWithValue(DbConstants.DMLType, DMLType.Insert);
                    }
                    else
                    {
                        cmd.Parameters.AddWithValue(DbConstants.DMLType, DMLType.Update);
                    }

                    SqlParameter cmdOutRetVal = new SqlParameter();
                    cmdOutRetVal.ParameterName = ReturnValue;
                    cmdOutRetVal.Direction = ParameterDirection.Output;
                    cmdOutRetVal.SqlDbType = SqlDbType.Int;                    
                    cmd.Parameters.Add(cmdOutRetVal);

                    SqlParameter cmdOutRetMsg = new SqlParameter();
                    cmdOutRetMsg.ParameterName = ReturnMessage;
                    cmdOutRetMsg.Direction = ParameterDirection.Output;
                    cmdOutRetMsg.SqlDbType = SqlDbType.VarChar;
                    cmdOutRetMsg.Size = 100;
                    cmd.Parameters.Add(cmdOutRetMsg);

                    SqlParameter cmdOutRetCreatedBy = new SqlParameter
                    {
                        ParameterName = ReturnCreatedBy,
                        Direction = ParameterDirection.Output,
                        SqlDbType = SqlDbType.VarChar,
                        Size = 50
                    };
                    cmd.Parameters.Add(cmdOutRetCreatedBy);

                    rowsInserted = cmd.ExecuteNonQuery();
                    result = new
                    {
                        returnCode = Convert.ToInt32(cmdOutRetVal.Value),
                        returnMessage = Convert.ToString(cmdOutRetMsg.Value),
                        returnCreatedBy = Convert.ToString(cmdOutRetCreatedBy.Value)
                    };
                }
                return JsonConvert.SerializeObject(result);
            }
            catch
            {
                throw;
            }
        }
        
        private IList<QueryExpressionRule> ConvertStructureToDatatable(string jsonText)
        {
            JObject json = JObject.Parse(jsonText);
            //Get first(root) condition value
            rulesetCondition = (string)json.First;

            var resultObjects = AllChildren(JObject.Parse(jsonText))
           .First(c => c.Type == JTokenType.Array && c.Path.Contains("rules"))
           .Children<JObject>();

            //Calling ParseJs function for main iteration
            ParseJs(resultObjects, 0, 1, rulesetCondition, 1);
            return lstRules;
        }
        public void ParseJs(dynamic resultObjects, int counterPlaceHolder, int preGIndex = 1, string rsCondition = "", int isFirstIteration = 0)
        {
            foreach (JObject result in resultObjects)
            {
                QueryExpressionRule rule = null;

                //Insert ruleset condition in case of previous groups, to comply with recurion calls backtracking
                if (rsCondition != "") rulesetCondition = rsCondition;

                //If Ruleset(RG) added first in root, then add invisible rule(R) with condition 
                if (isFirstIteration == 1 && result.ContainsKey("condition") == true)
                {
                    InsertRuleObjectIntoList(rule);
                }
                //Only applicable for first iteration(in case of RG added first in root)
                isFirstIteration = 0;

                //Not applicable if added result(R) First, applicable in case of further rulesets to set 'condition' value in both cases i.e. blank RG or RG with rules
                if (result.ContainsKey("condition") == true)
                {
                    result.TryGetValue("condition", out JToken jToken);
                    rulesetCondition = jToken.ToString();
                }
                else
                    rule = new QueryExpressionRule();

                foreach (JProperty property in result.Properties())
                {   
                    if (property.Name == "id") rule.FieldId = Convert.ToInt32(property.Value);
                    if (property.Name == "field") rule.FieldName = Convert.ToString(property.Value);
                    if (property.Name == "operator") rule.Operator = Convert.ToString(property.Value);
                    if (property.Name == "entity") rule.RuleType = Convert.ToInt16(property.Value);
                    if (property.Name == "value") rule.RuleValue = FormatValueIfArray(rule.Operator, Convert.ToString(property.Value));

                    if (property.Name == "rules")
                    {
                        var resultObjects1 = AllChildren(JObject.Parse(result.ToString()))
                                            .First(c => c.Type == JTokenType.Array && c.Path.Contains("rules"))
                                            .Children<JObject>();

                        counterPlaceHolder = counterPlaceHolder + 1;
                        parentIndex = pPlaceholderIndex;
                        groupIndex = gPlaceholderIndex + 1;

                        groupCounter = groupCounter + 1;
                        pPlaceholderIndex = groupCounter;
                        gPlaceholderIndex = groupCounter;

                        //To add invisible rules with condition & indexes, if blank rulesets added -in all cases i.e. (RG) or (R)
                        foreach (JObject result1 in resultObjects1)
                        {
                            if (result1.ContainsKey("condition") == true)
                            {
                                InsertRuleObjectIntoList(rule);
                                break;
                            }
                            else
                                break;
                        }

                        ParseJs(resultObjects1, counterPlaceHolder, groupIndex, rulesetCondition);
                        
                        pPlaceholderIndex = preGIndex;
                        //This should only be in case of rule added last(out of order)
                        parentIndex = pPlaceholderIndex - 1;
                        groupIndex = preGIndex;

                    }
                }
                if (rule != null)
                {
                    rule.Condition = rulesetCondition;
                    rule.ParentIndex = parentIndex;
                    rule.GroupIndex = groupIndex;
                    rule.RuleIndex = ruleIndex;
                    lstRules.Add(rule);

                    rule = null;
                }

                if (result.Next == null)
                {
                    break;
                }
                ruleIndex++;
            }
        }
        //Insert EligibilityRule object into List
        private void InsertRuleObjectIntoList(QueryExpressionRule rule)
        {
            rule = new QueryExpressionRule
            {
                Condition = rulesetCondition,
                ParentIndex = parentIndex,
                GroupIndex = groupIndex,
                RuleIndex = ruleIndex

            };
            lstRules.Add(rule);
            rule = null;
        }
        //Recursively yield all children of json body
        private IEnumerable<JToken> AllChildren(JToken json)
        {
            foreach (var child in json.Children())
            {
                yield return child;
                foreach (var nestedChild in AllChildren(child))
                {
                    yield return nestedChild;
                }
            }
        }
        private string FormatValueIfArray(string entityOperator, string value)
        {   
            if (entityOperator.ToLower() == "in" || entityOperator.ToLower() == "not in" || entityOperator.ToLower() == "between")
            {
                value = Regex.Replace(Convert.ToString(value).Replace(System.Environment.NewLine, string.Empty), @"\s+", " ");
            }
            return value;
        }
        private DataTable ToDataTable<T>(IList<T> ecRules)
        {
            DataTable dataTable = new DataTable(typeof(T).Name);

            //Get all the Properties
            PropertyInfo[] Props = typeof(T).GetProperties(BindingFlags.Public | BindingFlags.Instance);
            foreach (PropertyInfo prop in Props)
            {
                //Defining type of data column gives proper data table 
                var type = (prop.PropertyType.IsGenericType && prop.PropertyType.GetGenericTypeDefinition() == typeof(Nullable<>) ? Nullable.GetUnderlyingType(prop.PropertyType) : prop.PropertyType);
                //Setting column names as Property names
                dataTable.Columns.Add(prop.Name, type);
            }
            foreach (T item in ecRules)
            {
                var values = new object[Props.Length];
                for (int i = 0; i < Props.Length; i++)
                {
                    //inserting property values to datatable rows
                    values[i] = Props[i].GetValue(item, null);
                }
                dataTable.Rows.Add(values);
            }
            //put a breakpoint here and check datatable
            return dataTable;
        }
        #endregion

        #region Amend Eligibility
        public int AmendEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes, string userName)
        {
            int returnCode;
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_AmendEligibilityCriteria, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamEcId, eligibilityCriteriaAttributes.ECID);
                cmd.Parameters.AddWithValue(DbProcParamEcName, eligibilityCriteriaAttributes.Name);
                cmd.Parameters.AddWithValue(DbProcParamEcTypeId, eligibilityCriteriaAttributes.Type);
                cmd.Parameters.AddWithValue(DbProcParamEcDescription, eligibilityCriteriaAttributes.Description);
                cmd.Parameters.AddWithValue(DbProcParamComment, eligibilityCriteriaAttributes.SaveComment);
                cmd.Parameters.AddWithValue(DbProcParamEcModifiedBy, userName);
                cmd.Parameters.AddWithValue(DbProcParamEcModifiedDate, eligibilityCriteriaAttributes.ModifiedDate);

                SqlParameter cmdOutRetVal = new SqlParameter
                {
                    ParameterName = DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutRetVal);
                cmd.ExecuteNonQuery();
                returnCode = Convert.ToInt32(cmdOutRetVal.Value);
                return returnCode; 
            }
        }
        #endregion
        #region Get Eligibility; for Edit
        public IList<EligibilityCriteriaDetail> GetEligibilityCriteria(int eligibilityId, int assetId)
        {
            try
            {
                IList<EligibilityCriteriaDetail> ecDetailList = new List<EligibilityCriteriaDetail>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEligibilityCriteriaDetail, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(ECID, eligibilityId);
                    cmd.Parameters.AddWithValue(AssetClassIdInput, assetId);
                    SqlDataReader reader;
                    using (reader = cmd.ExecuteReader())
                    {
                        if(reader.HasRows)
                        {
                            while (reader.Read())
                            {
                                ecDetailList.Add(new EligibilityCriteriaDetail()
                                {
                                    Id = Utility.GetInt(reader["Id"]),
                                    Name = Utility.GetString(reader["Name"]),
                                    Description = Utility.GetString(reader["Description"]),
                                    TypeId = Utility.GetString(reader["TypeId"]),
                                    // TypeName = Utility.GetString(reader["TypeName"]),
                                    RegulationId = Utility.GetInt(reader["RegulationId"]),
                                    RegulationName = Utility.GetString(reader["RegulationName"]),
                                    AssetId = Utility.GetInt(reader["AssetId"]),
                                    AssetName = Utility.GetString(reader["AssetName"]),
                                    EligibilityExpression = Utility.GetString(reader["EligibilityExpression"]),
                                    Status = Utility.GetString(reader["Status"]),
                                    StatusId = Utility.GetInt(reader["StatusId"]),
                                    CreatedBy = Utility.GetString(reader["CreatedBy"]),
                                    CommentsBySubmitter = Utility.GetString(reader[DbFieldCommentsBySubmitter]),
                                    CommentsByAuthoriser = Utility.GetString(reader[DbFieldCommentsByAuthoriser]),
                                });
                            }
                        }
                        else
                        {
                            return ecDetailList;
                        }

                        reader.NextResult();

                        if (reader.HasRows)
                        {
                            //Populate comments history with date and action
                            while (reader.Read())
                            {
                                CommentsHistory objCommentsHistory = new CommentsHistory();
                                objCommentsHistory.CommentsDate = Utility.ConvertUTCToUKTime(Convert.ToString(reader[DbFieldCommentsDate]));
                                objCommentsHistory.CommentsAction = Convert.ToString(reader[DbFieldCommentAction]);
                                objCommentsHistory.Comments = Convert.ToString(reader[DbFieldComments]);
                                ecDetailList[0].CommentsHistory.Add(objCommentsHistory);
                            }
                        }
                    }

                    return ecDetailList;
                }
            }
            catch
            {
                throw;
            }
        }
        public IList<QueryExpressionDetail> GetEligibilityCriteriaExpression(int eligibilityId)
        {
            try
            {
                IList<QueryExpressionDetail> ecExpressionList = new List<QueryExpressionDetail>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetEligibilityCriteriaExpressionDetail, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue(ECID, eligibilityId);

                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {

                        ecExpressionList.Add(new QueryExpressionDetail()
                        {
                            Id = Utility.GetInt(reader["Id"]),
                            RuleIndex = Utility.GetInt(reader["RuleIndex"]),
                            GroupIndex = Utility.GetInt(reader["GroupIndex"]),
                            ParentIndex = Utility.GetInt(reader["ParentIndex"]),
                            FieldName = Utility.GetString(reader["FieldName"]),
                            Operator = Utility.GetString(reader["Operator"]),
                            Entity = Utility.GetInt(reader["Entity"]),
                            Condition = Utility.GetString(reader["Condition"]),
                            Value = Utility.GetString(reader["Value"])
                        });
                    }
                    return ecExpressionList;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion

        #region Get Eligibility Criteria List 
        public IList<EligibilityCriteriaList> GetEligibilityCriterias(int assetId, string userName)
        {
            IList<EligibilityCriteriaList> ecList = new List<EligibilityCriteriaList>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_EligibilityCriteria_GetList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbProcParamAssetId, assetId);
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    ecList.Add(new EligibilityCriteriaList()
                    {
                        EcId = Utility.GetInt(reader[DbFieldEcListId]),
                        Name = Utility.GetString(reader[DbFieldEcListName]),
                        Expression = Utility.GetString(reader[DbFieldEcListExpression]),
                        Tag = Utility.GetString(reader[DbFieldEcListTag]),
                        PassCriteria = Utility.GetString(reader[DbFieldEcListPassCriteria]),
                        Status = Utility.GetString(reader[DbFieldEcListStatus]),
                        CreatedBy = Utility.GetString(reader[DbFieldEcListCreatedBy]),                        
                        IsLinked = Convert.ToBoolean(reader[DbFieldEcListIsLinked]),
                        CreatedDate = Utility.GetDateTimeNullable(reader[DbFieldCreatedDate]),
                        ModifiedDate = Utility.GetDateTimeNullable(reader[DbFieldModifiedDate]),
                        PoolCount = Utility.GetInt(reader[DbFieldEcListPoolCount])
                    });
                }
            }
            return this.FormatEligibilityCriteriaDateValue(ecList);
        }
        #endregion

        #region Delete Eligibility
        public int DeleteEligibility(int ecId, string userName)
        {
            int returnCode;

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_EligibilityCriteria_Delete, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamEcId, ecId);
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.Add(DbProcParamLinkedReturnCode, SqlDbType.Int);
                cmd.Parameters[DbProcParamLinkedReturnCode].Direction = ParameterDirection.Output;
                int rowsAffected = cmd.ExecuteNonQuery();

                int linkedReturnCode = Convert.ToInt32(cmd.Parameters[DbProcParamLinkedReturnCode].Value);
                returnCode = (linkedReturnCode == -2) ? linkedReturnCode : rowsAffected;
            }
            return returnCode;
        }

        public bool ValidateEcFields(int eligibilityId)
        {
            bool validation;
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_ValidateEcFields, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamEcId, eligibilityId);

                SqlParameter validationStatus = new SqlParameter
                {
                    ParameterName = DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Bit
                };
                cmd.Parameters.Add(validationStatus);
                cmd.ExecuteNonQuery();
                validation = Convert.ToBoolean(validationStatus.Value);
            }
            return validation;
        }

        public IList<EligibilityCriteriaPoolsList> GetEcPoolsReportData(int EcID, string userName)
        { 
            IList<EligibilityCriteriaPoolsList> result = new List<EligibilityCriteriaPoolsList>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetEcPoolsFields, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcEcPoolsParamPoolId, EcID);
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.Add(new EligibilityCriteriaPoolsList()
                        {
                            PoolID = Utility.GetInt(reader[DbFieldEcPoolListPoolID]),
                            Name = Utility.GetString(reader[DbFieldEcPoolListName]),
                            Status = Utility.GetString(reader[DbFieldEcPoolListStatus]),
                            BuildDate = Utility.GetDateTimeNullable(reader[DbFieldEcPoolListBuildDate]),
                            CreationDate = Utility.GetDateTimeNullable(reader[DbFieldEcPoolListCreationDate]),
                            CreatedBy = Utility.GetString(reader[DbFieldEcPoolListCreatedBy]),
                            AuthorisationDate = Utility.GetDateTimeNullable(reader[DbFieldEcPoolListAuthDate])
                        });
                    }
                }

                return result;
            }
        }
        #endregion

        # region Date Format for EC Expression

        private IList<EligibilityCriteriaList> FormatEligibilityCriteriaDateValue(IList<EligibilityCriteriaList> eligibilityCriteriaList)
        {
            foreach (EligibilityCriteriaList eligibilityCriteria in eligibilityCriteriaList)
            {
                eligibilityCriteria.Expression = ModifyDateFormatforExpression(eligibilityCriteria.Expression);
            }
            return eligibilityCriteriaList;
        }

        private string ModifyDateFormatforExpression(string expression)
        {
            string[] ArrExpression = expression.Split("'");
            DateTime dateValue;
            for (int i = 0; i < ArrExpression.Length; i++)
            {
                if (DateTime.TryParse(ArrExpression[i], out dateValue))
                {
                    ArrExpression[i] = Utility.GetUKFormattedDateTime(dateValue);
                }
            }
            return string.Join("'", ArrExpression);
        }

        #endregion
    }
}
