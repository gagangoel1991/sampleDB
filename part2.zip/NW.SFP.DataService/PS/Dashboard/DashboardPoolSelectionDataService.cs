﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class DashboardPoolSelectionDataService : IDashboardPoolSelectionDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public DashboardPoolSelectionDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public IList<DashboardSummary> GetDashboardSummary(string userName, int assetClassId)
        {
            IList<DashboardSummary> listDashboardSummary = new List<DashboardSummary>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Dashboard_GetSummary, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue("@pAssetClassID", assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            listDashboardSummary.Add(GetDashboardSummary(resultReader));
                        }
                    }
                }

            }
            return listDashboardSummary;
        }
        public IList<DashboardSummary> GetPreviousWork(DateTime fromDate, DateTime toDate, string userName, int assetClassId)
        {
            IList<DashboardSummary> listDashboardSummary = new List<DashboardSummary>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Dashboard_GetPreviousWork, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamDashboardFromDate, fromDate);
                cmd.Parameters.AddWithValue(DbProcParamDashboardToDate, toDate);
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue("@pAssetClassID", assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            listDashboardSummary.Add(GetDashboardSummary(resultReader));
                        }
                    }
                }

            }
            return listDashboardSummary;
        }

        private DashboardSummary GetDashboardSummary(SqlDataReader resultReader)
        {
            var objDashboardSummary = new DashboardSummary();

            if (resultReader[DbFieldDashboardRecordCount] != DBNull.Value)
                objDashboardSummary.RecordCount = Utility.GetInt(resultReader[DbFieldDashboardRecordCount]);

            objDashboardSummary.Entity = Utility.GetString(resultReader[DbFieldDashboardEntity]);
            objDashboardSummary.Purpose = Utility.GetString(resultReader[DbFieldDashboardPurpose]);

            return objDashboardSummary;
        }

        public IList<DashBoardPoolData> GetDashBoardCompletedPoolData(DateTime fromDate, DateTime toDate, string userName, int assetClassId)
        {
            IList<DashBoardPoolData> dashBoardPoolData = new List<DashBoardPoolData>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetSFPPlusDashBoardCompletedPools, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamDashboardFromDate, fromDate);
                cmd.Parameters.AddWithValue(DbProcParamDashboardToDate, toDate);
                cmd.Parameters.AddWithValue(DbProcParamCtUserName, userName);
                cmd.Parameters.AddWithValue("@pAssetClassID", assetClassId);
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            dashBoardPoolData.Add(new DashBoardPoolData()
                            {
                                PoolId = Utility.GetInt(resultReader[DbFieldDashboardPoolId]),
                                PoolName = Utility.GetString(resultReader[DbFieldDashboardPoolName]),
                                PoolPurpose = Utility.GetString(resultReader[DbFieldDashboardPurpose]),
                                SourceDeal = Utility.GetString(resultReader[DbFieldDashboardSourceDeal]),
                                TargetDeal = Utility.GetString(resultReader[DbFieldDashboardTargetDeal]),
                                LoanCount = Utility.GetInt(resultReader[DbFieldDashboardNumberOfLoans]),
                                SubAccountCount = Utility.GetInt(resultReader[DbFieldDashboardNumberOfSubAccounts]),
                                PoolStatus = Utility.GetString(resultReader[DbFieldDashboardPoolStatus]),
                                EffectiveDate = Utility.GetUKFormattedDateTime(resultReader[DbFieldDashboardEffectiveDate]),
                                ClosedLoanCount = Utility.GetInt(resultReader[DbFieldDashboardClosedAccountCount]),
                                VintageDate = Utility.GetUKFormattedDateTime(resultReader["VintageDate"]),
                                CashReportingFlag = Utility.GetString(resultReader["CashReportingFlag"])
                            });
                        }
                    }
                }

            }
            return dashBoardPoolData;
        }


        public DealFlagDeFlagData GetDashBoardDealsData(DateTime analysisDate, string userName, bool IsInitial, int assetClassId)
        {
            DealFlagDeFlagData dashBoardDealData = new DealFlagDeFlagData();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetSFPPlusDashBoardDeals, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamDashboardAsAtDate, analysisDate);
                cmd.Parameters.AddWithValue(DbProcParamDashboardisInitial, IsInitial);
                cmd.Parameters.AddWithValue(DbProcParamCtUserName, userName);
                cmd.Parameters.AddWithValue("@pAssetClassID", assetClassId); 
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            dashBoardDealData.CurrentDate = Utility.GetShortDateTime(resultReader[DbFieldDashboardCurrentDate]);
                            dashBoardDealData.PreviousDate = Utility.GetShortDateTime(resultReader[DbFieldDashboardPreviousdate]);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            dashBoardDealData.dashBoardDealList.Add(new DashBoardDealData()
                            {
                                DealName = Utility.GetString(resultReader[DbFieldDashboardDealName]),
                                Brand = Utility.GetString(resultReader[DbFieldDashboardBrandCode]),
                                TrueBalance = Utility.GetDecimal(resultReader[DbFieldDashboardTrueBalance]),
                                CapitalBalance = Utility.GetDecimal(resultReader[DbFieldDashboardCapitalBalance]),
                                CurrentDayLoanCount = Utility.GetInt(resultReader[DbFieldDashboardCurrentAccountCount]),
                                CurrentDaySubAccountCount = Utility.GetInt(resultReader[DbFieldDashboardCurrentSubAccountCount]),
                                LoanVariance = Utility.GetInt(resultReader[DbFieldDashboardLoanVariance]),
                                PreviousDayLoanCount = Utility.GetInt(resultReader[DbFieldDashboardPreviousAccountCount]),
                                PreviousDaySubAccountCount = Utility.GetInt(resultReader[DbFieldDashboardPreviousSubAccountCount]),
                                SubAccountVariance = Utility.GetInt(resultReader[DbFieldDashboardSubAccountVariance]),
                                Rona = Utility.GetDecimal(resultReader["Rona"])
                            });
                        }
                    }

                }

            }
            return dashBoardDealData;
        }


        public IList<DashBoardFailedPoolData> GetDashBoardFailedPoolData(DateTime analysisDate, string userName, int assetClassId)
        {
            IList<DashBoardFailedPoolData> dashBoardPoolData = new List<DashBoardFailedPoolData>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GetSFPPlusDashBoardFailedPools, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamDashboardAsAtDate, analysisDate);
                cmd.Parameters.AddWithValue(DbProcParamCtUserName, userName);
                cmd.Parameters.AddWithValue("@pAssetClassID", assetClassId);
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            dashBoardPoolData.Add(new DashBoardFailedPoolData()
                            {
                                PoolName = Utility.GetString(resultReader[DbFieldDashboardPoolName]),
                                FailedReason = Utility.GetString(resultReader[DbFieldDashboardFailedReason]),
                            });
                        }
                    }
                }

            }
            return dashBoardPoolData;
        }
    }


}
