﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class AssetClassDataService : IAssetClassDataService
    {
        #region Object Declaration and Constructor
        private readonly IOptions<DataServiceSettings> _settings;

        public AssetClassDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }
        #endregion

        #region Get AssetClass
        public IList<AssetClass> GetAssetClass()
        {
            try
            {
                IList<AssetClass> assetClassList = new List<AssetClass>();

                using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
                using (SqlCommand cmd = new SqlCommand(SP_GetAssetClass, conn))
                {
                    if (conn.State == ConnectionState.Closed)
                        conn.Open();
                    cmd.CommandType = CommandType.StoredProcedure;
                    SqlDataReader reader = cmd.ExecuteReader();

                    while (reader.Read())
                    {
                        AssetClass field = new AssetClass
                        {
                            ClassId = Utility.GetString(reader["ClassId"]),
                            ClassName = Utility.GetString(reader["ClassName"]),
                            Description = Utility.GetString(reader["Description"]),
                            Code = Utility.GetString(reader["Code"])
                        };

                        assetClassList.Add(field);

                    }
                    return assetClassList;
                }
            }
            catch
            {
                throw;
            }
        }
        #endregion
    }
}