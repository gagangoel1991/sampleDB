﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class ExclusionDataService : IExclusionDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public ExclusionDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public Exclusion GetExclusionById(int exclusionId, string userName)
        {
            Exclusion objExclusion = new Exclusion();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Exclusion_GetExclusionById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamExclusionId, exclusionId);
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Populate Exclusion Details
                        while (resultReader.Read())
                        {
                            objExclusion.LoanCount = Utility.GetIntNullable(resultReader[DbFieldExclusionLoanCount]);
                            objExclusion.ModifiedDate = Utility.GetDateTimeNullable(resultReader[DbFieldExclusionModifiedDate]);
                            objExclusion.UploadedFileName = Utility.GetString(resultReader[DbFieldExclusionUploadedFileName]);
                        }
                        
                    }
                    else
                    {
                        return objExclusion;
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Exclusion Items
                        while (resultReader.Read())
                        {
                            var objExclusionItem = new ExclusionItem();

                            if (resultReader[DbFieldExclusionItemLoanNumber] != DBNull.Value)
                                objExclusionItem.LoanNumber = Utility.GetLong(resultReader[DbFieldExclusionItemLoanNumber]);

                            objExclusionItem.Reason = Utility.GetString(resultReader[DbFieldExclusionItemReason]);

                            objExclusion.ExclusionItems.Add(objExclusionItem);
                        }
                    }
                }
            }
            return objExclusion;
        }

        public int CreateExclusion(Exclusion exclusion, string userName)
        {
            int returnCode;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Exclusion_Create, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(CreateParameterList(exclusion, userName).ToArray<SqlParameter>());

                cmd.Parameters.Add(DbProcParamExclusionId, SqlDbType.Int);
                cmd.Parameters[DbProcParamExclusionId].Direction = ParameterDirection.Output;

                var rowsAffected = cmd.ExecuteNonQuery();
                var exclusionId = Convert.ToInt32(cmd.Parameters[DbProcParamExclusionId].Value);
                returnCode = (rowsAffected > 0) ? exclusionId : rowsAffected;
            }
            return returnCode;
        }

        public IList<ExclusionValidationResult> ValidateExclusion(Exclusion exclusion, string userName)
        {
            IList<ExclusionValidationResult> exclusionValidationResults = new List<ExclusionValidationResult>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Exclusion_ValidateUpload, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(CreateParameterList(exclusion, userName).ToArray<SqlParameter>());
                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            var exclusionValidationResult = new ExclusionValidationResult();
                            exclusionValidationResult.ExclusionRecord.LoanNumber = Utility.GetLong(resultReader[DbFieldExclusionItemLoanNumber]);
                            exclusionValidationResult.ExclusionRecord.Reason = Utility.GetString(resultReader[DbFieldExclusionItemReason]);
                            exclusionValidationResult.isValid = Utility.GetBool(resultReader[DbFieldExclusionIsValid]);
                            exclusionValidationResult.ErrorType = Utility.GetString(resultReader[DbFieldExclusionErrorType]);
                            exclusionValidationResult.ErrorDetails = Utility.GetString(resultReader[DbFieldExclusionErrorDetails]);

                            exclusionValidationResults.Add(exclusionValidationResult);
                        }
                    }
                }
            }
            return exclusionValidationResults;
        }

        private List<SqlParameter> CreateParameterList(Exclusion objExclusion, string userName)
        {
            List<SqlParameter> parameterCollection = new List<SqlParameter>
            {
                new SqlParameter(DbProcParamExclusionUploadedFileName, SqlDbType.VarChar),
                new SqlParameter(DbProcParamUserName, SqlDbType.VarChar),
                new SqlParameter(DbProcParamExclusionItems, SqlDbType.Structured)                        
            };

            parameterCollection[0].SqlValue = Utility.GetString(objExclusion.UploadedFileName);
            parameterCollection[1].SqlValue = userName;

            var exclusionItems = new DataTable();
            exclusionItems.Columns.Add(DbFieldExclusionItemLoanNumber, typeof(Int64));
            exclusionItems.Columns.Add(DbFieldExclusionItemReason, typeof(string));

            foreach (var pExclusionItem in objExclusion.ExclusionItems)
            {
                exclusionItems.Rows.Add(Utility.GetLong(pExclusionItem.LoanNumber), Utility.GetString(pExclusionItem.Reason));
            }

            parameterCollection[2].SqlValue = exclusionItems;
            parameterCollection[2].TypeName = DbTypeExclusionItem;

            return parameterCollection;
        }

        public ExclusionData GetExclusionManagementData(string userName)
        {
            ExclusionData exclusionData = new ExclusionData();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Exclusion_ManagementData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        exclusionData.Exclusion.ExclusionId = Utility.GetInt(reader[DbFieldExclusionExclusionId]);
                        exclusionData.Exclusion.UploadedFileName = Utility.GetString(reader[DbFieldExclusionUploadedFileName]);
                        exclusionData.Exclusion.LoanCount = Utility.GetInt(reader[DbFieldExclusionLoanCount]);
                        exclusionData.Exclusion.CreatedBy = Utility.GetString(reader[DbFieldExclusionCreatedBy]);
                        exclusionData.Exclusion.CreatedOn = Utility.GetUKFormattedDateWithTime(Utility.ConvertUTCToUKTime(Utility.GetString(reader[DbFieldExclusionCreatedDate])));
                    }
                }


                reader.NextResult();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        exclusionData.ExclusionHistory.Add(new Exclusion()
                        {
                            ExclusionId = Utility.GetInt(reader[DbFieldExclusionExclusionId]),
                            UploadedFileName = Utility.GetString(reader[DbFieldExclusionUploadedFileName]),
                            LoanCount = Utility.GetInt(reader[DbFieldExclusionLoanCount]),
                            CreatedBy = Utility.GetString(reader[DbFieldExclusionCreatedBy]),
                            CreatedOn = Utility.GetUKFormattedDateWithTime(Utility.ConvertUTCToUKTime(Utility.GetString(reader[DbFieldExclusionCreatedDate])))
                        });
                    }
                }
                

                reader.NextResult();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        exclusionData.ExclusionSummary.Add(new ExclusionSummaryItem()
                        {
                            Reason = Utility.GetString(reader[DbFieldExclusionItemReason]),
                            LoanCount = Utility.GetInt(reader[DbFieldExclusionLoanCount]),
                            ReasonId = Utility.GetString(reader[DbFieldExclusionItemReasonId])
                        });
                    }
                }

            }
            return exclusionData;
        }


    }

}