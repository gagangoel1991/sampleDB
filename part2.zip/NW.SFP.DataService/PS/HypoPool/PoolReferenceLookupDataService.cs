﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class PoolReferenceLookupDataService : IPoolReferenceLookupDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public PoolReferenceLookupDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public PoolReferenceData GetPoolReferenceData(string userName, int AssetId)
        {
            PoolReferenceData objPoolReferenceData = new PoolReferenceData();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_Pool_GetPoolReferenceData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbProcParamAssetId, AssetId);

                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Populate Pool Purpose
                        objPoolReferenceData.PoolPurpose.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Asset Class
                        objPoolReferenceData.AssetClass.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Source Hypo Pool 
                        objPoolReferenceData.SourceHypoPool.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate DealLookUp 
                        while (resultReader.Read())
                        {
                            DealLookUp objDealLookUp = new DealLookUp
                            {
                                DealKey = Convert.ToInt32(resultReader[DbFieldDeal_DealKey]),
                                DealName = Utility.GetString(resultReader[DbFieldDeal_Deal_DealName]),
                                DealPublicName = Utility.GetString(resultReader[DbFieldDeal_DealPublicName]),
                                DealType = Utility.GetString(resultReader[DbFieldDeal_DealType]),
                                DealStatus = Utility.GetString(resultReader[DbFieldDeal_DealStatus]),
                                DealCalculatedBasedOn = Utility.GetString(resultReader[DbFieldDeal_DealCaluclatedBasedOn])
                            };
                            objPoolReferenceData.DealLookUp.Add(objDealLookUp);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Eligibility Criteria 
                        while (resultReader.Read())
                        {
                            EligibilityLookUp objBasicLookUpData = new EligibilityLookUp
                            {
                                Value = Convert.ToInt32(resultReader[DbFieldLookupDataValue]),
                                Title = Utility.GetString(resultReader[DbFieldLookupDataTitle]),
                                IsAuthorised = Convert.ToInt32(resultReader[DbFieldLookupDataAuthorised]) == 1 ? true : false
                            };
                            objPoolReferenceData.EligibilityCriteria.Add(objBasicLookUpData);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Pool Reason 
                        objPoolReferenceData.PoolReason.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Pool Limit Analysis Field 
                        objPoolReferenceData.PoolLimitAnalysisField.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        // Populate Deal types 
                        objPoolReferenceData.DealTypes.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        // Populate Ipd Frequencies
                        objPoolReferenceData.IpdFrequencies.AddRange(GetBasicLookUpData(resultReader));
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Eligibility Criteria 
                        while (resultReader.Read())
                        {
                            ConcentrationLookUp objBasicLookUpData = new ConcentrationLookUp
                            {
                                Value = Convert.ToInt32(resultReader[DbFieldLookupDataValue]),
                                Title = Utility.GetString(resultReader[DbFieldLookupDataTitle]),
                                IsAuthorised = Convert.ToInt32(resultReader[DbFieldLookupDataAuthorised]) == 1
                            };
                            objPoolReferenceData.ConcentrationTest.Add(objBasicLookUpData);
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        //Populate Live Deals
                        while (resultReader.Read())
                        {
                            DealLookUp objLiveDealLookUp = new DealLookUp
                            {
                                DealKey = Convert.ToInt32(resultReader[DbFieldDeal_DealKey]),
                                DealName = Utility.GetString(resultReader[DbFieldDeal_Deal_DealName]),
                                DealPublicName = Utility.GetString(resultReader[DbFieldDeal_DealPublicName]),
                                DealType = Utility.GetString(resultReader[DbFieldDeal_DealType]),
                                DealStatus = Utility.GetString(resultReader[DbFieldDeal_DealStatus]),
                                DealCalculatedBasedOn = Utility.GetString(resultReader[DbFieldDeal_DealCaluclatedBasedOn])
                            };                            
                            objPoolReferenceData.LiveDealLookUp.Add(objLiveDealLookUp);
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        //Populate Pool Inclusion Options

                        objPoolReferenceData.PoolInclusionListOption.Add(new BasicLookUpData() { Title = " ", Value = 0 });
                        while (resultReader.Read())
                        {
                            BasicLookUpData objInclusionOption = new BasicLookUpData
                            {
                                Value = Convert.ToInt32(resultReader[DbFieldPoolInclusionOption]),
                                Title = Utility.GetString(resultReader[DbFieldPoolOptionDescription]),
                            };
                            objPoolReferenceData.PoolInclusionListOption.Add(objInclusionOption);
                        }
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        //Populate Live Deals
                        while (resultReader.Read())
                        {
                            DealLookUp objLiveDealLookUp = new DealLookUp
                            {
                                DealKey = Convert.ToInt32(resultReader[DbFieldDeal_DealKey]),
                                DealName = Utility.GetString(resultReader[DbFieldDeal_Deal_DealName]),
                                DealPublicName = Utility.GetString(resultReader[DbFieldDeal_DealPublicName]),
                                DealType = Utility.GetString(resultReader[DbFieldDeal_DealType]),
                                DealStatus = Utility.GetString(resultReader[DbFieldDeal_DealStatus]),
                                DealCalculatedBasedOn = Utility.GetString(resultReader[DbFieldDeal_DealCaluclatedBasedOn])
                            };
                            objPoolReferenceData.TopupTargetDealLookUp.Add(objLiveDealLookUp);
                        }
                    }
                }
            }
            return objPoolReferenceData;
        }

        private IList<BasicLookUpData> GetBasicLookUpData(SqlDataReader resultReader)
        {
            var listBasicLookUpData = new List<BasicLookUpData>();
            while (resultReader.Read())
            {
                BasicLookUpData objBasicLookUpData = new BasicLookUpData
                {
                    Value = Convert.ToInt32(resultReader[DbFieldLookupDataValue]),
                    Title = Utility.GetString(resultReader[DbFieldLookupDataTitle])
                };
                listBasicLookUpData.Add(objBasicLookUpData);
            }
            return listBasicLookUpData;
        }
    }


}
