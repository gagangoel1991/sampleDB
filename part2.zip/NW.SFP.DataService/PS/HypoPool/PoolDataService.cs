﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace NW.SFP.DataService.PS
{
    public class PoolDataService : IPoolDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;

        public PoolDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public int DeletePool(int poolId, string userName)
        {
            int result = 0;

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_Delete, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                result = cmd.ExecuteNonQuery();
            }
            return result;
        }

        public Pool GetPoolById(int poolId, string userName)
        {
            Pool objPool = new Pool();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        //Populate Pool Details
                        while (resultReader.Read())
                        {
                            objPool.Id = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolId]);
                            objPool.Name = Utility.GetString(resultReader[DbConstants.DbFieldPoolName]);
                            objPool.Description = Utility.GetString(resultReader[DbConstants.DbFieldPoolDescription]);
                            objPool.Limit = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolLimit]);
                            objPool.VintageDate = Utility.GetDateTime(resultReader[DbConstants.DbFieldPoolVintageDate]);

                            objPool.PurposeId = Utility.GetInt(resultReader[DbConstants.DbFieldPoolPurposeId]);
                            objPool.ApplyExclusion = Utility.GetBool(resultReader[DbConstants.DbFieldPoolApplyExclusion]);
                            objPool.TargetPoolId = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolTargetPoolId]);
                            objPool.PoolReasonId = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolReasonId]);
                            objPool.PoolLimitAnalysisFieldId = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolLimitAnalysisFieldId]);

                            objPool.StatusId = Utility.GetInt(resultReader[DbConstants.DbFieldPoolStatusId]);
                            objPool.Status = Utility.GetString(resultReader[DbConstants.DbFieldPoolStatus]);
                            objPool.TrueBalance = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolTrueBalance]);
                            objPool.CapitalBalance = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolCapitalBalance]);
                            objPool.BuiltDate = Utility.ConvertUTCToUKTime(Convert.ToString(resultReader[DbConstants.DbFieldPoolBuiltDate]));

                            objPool.NumberOfAccount = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolNumberOfAccount]);
                            objPool.NumberOfSubAccount = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolNumberOfSubAccount]);
                            objPool.SelectedLoanPercentage = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolSelectedLoanPercentage]);
                            objPool.PrincipleBalancePercentage = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolPrincipleBalancePercentage]);
                            objPool.RefreshDate = Utility.GetDateTime(resultReader[DbConstants.DbFieldPoolRefreshDate]);
                            objPool.CurrentPoolAmount = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolCurrentPoolAmount]);
                            objPool.RandomSelection = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolRandomSelection]);

                            objPool.CreatedDate = Utility.ConvertUTCToUKTime(Convert.ToString(resultReader[DbConstants.DbFieldPoolCreatedDate]));
                            objPool.CreatedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolCreatedBy]);
                            objPool.AuthorizedDate = Utility.ConvertUTCToUKTime(Convert.ToString(resultReader[DbConstants.DbFieldPoolAuthorizedDate]));
                            objPool.AuthorizedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolAuthorizedBy]);
                            objPool.ModifiedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolModifiedBy]);

                            objPool.SourcingType = Utility.GetString(resultReader[DbConstants.DbFieldPoolSourcingType]);
                            objPool.UploadedFileName = Utility.GetString(resultReader[DbConstants.DbFieldPoolUploadedFileName]);

                            objPool.InclusionFileName = Utility.GetString(resultReader[DbConstants.DbFieldPoolInclusionFileName]);
                            objPool.IsRebuildRequired = Utility.GetBool(resultReader[DbConstants.DbFieldPoolIsRebuildRequired]);
                            objPool.IsPoolBuildInProgress = Utility.GetBool(resultReader[DbConstants.DbFieldPoolIsPoolBuildInProgress]);

                            objPool.EffectiveDate = Utility.GetDateTime(resultReader[DbConstants.DbFieldPoolEffectiveDate]);
                            objPool.NoticeDate = Utility.GetDateTime(resultReader[DbConstants.DbFieldPoolNoticeDate]);

                            objPool.DealTypeId = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolDealTypeId]);
                            objPool.IpdFrequencyId = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolIpdFrequencyId]);

                            objPool.CommentsBySubmitter = Utility.GetString(resultReader[DbConstants.DbFieldCommentsBySubmitter]);
                            objPool.CommentsByAuthoriser = Utility.GetString(resultReader[DbConstants.DbFieldCommentsByAuthoriser]);
                            objPool.PoolInclusionOption = Utility.GetInt(resultReader[DbConstants.DbFieldPoolInclusionOption]);
                            objPool.PoolIncludedExclusions = Utility.GetString(resultReader[DbConstants.DbFieldPoolIncludedExclusions]);

                            objPool.AssetClassId = Utility.GetString(resultReader[DbConstants.DbFieldPoolAssetClassId]);
                            objPool.AssetClassName = Utility.GetString(resultReader[DbConstants.DbFieldPoolAssetClassName]);

                            objPool.ApplicableECMethod = Utility.GetInt(resultReader[DbConstants.DbFieldApplicableECMethod]);
							objPool.LastFlagDeFlagDate = Utility.GetDateTime(resultReader[DbConstants.DbFieldPoolLastFlagDeFlagDate]);
                            objPool.IsBalanceUploaded = Utility.GetBool(resultReader[DbConstants.DbFieldPoolIsBalanceUploadeded]);
                        }
                    }
                    else
                    {
                        return objPool;
                    }

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            objPool.SourceDeals = Utility.GetString(resultReader[DbConstants.DbFieldPoolSourceDeals]);
                        }
                    }

                    resultReader.NextResult();

                    PopulateSourcingBasedOnSourcingType(objPool, resultReader);

                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        //Populate Linked Eligibility Criteria
                        while (resultReader.Read())
                        {
                            EligibilityLookUp objEligibilityLookUpData = new EligibilityLookUp();
                            if (resultReader[DbConstants.DbFieldLookupDataValue] != DBNull.Value)
                                objEligibilityLookUpData.Value = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]);

                            objEligibilityLookUpData.Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]);
                            objEligibilityLookUpData.IsAuthorised = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataAuthorised]) == 1 ? true : false;
                            objPool.LinkedEC.Add(objEligibilityLookUpData);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Linked Brands
                        while (resultReader.Read())
                        {
                            if (resultReader[DbConstants.DbFieldLookupDataValue] != DBNull.Value)
                                objPool.BrandSelectionList.Add(Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]));
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Inclusion List
                        while (resultReader.Read())
                        {
                            if (resultReader[DbConstants.DbFieldPoolInclusionLoanNumber] != DBNull.Value)
                                objPool.InclusionList.Add(Convert.ToInt32(resultReader[DbConstants.DbFieldPoolInclusionLoanNumber]));
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate Linked Eligibility Criteria
                        while (resultReader.Read())
                        {
                            ConcentrationLookUp objConcentrationLookUpData = new ConcentrationLookUp();
                            if (resultReader[DbConstants.DbFieldLookupDataValue] != DBNull.Value)
                                objConcentrationLookUpData.Value = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]);

                            objConcentrationLookUpData.Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]);
                            objConcentrationLookUpData.IsAuthorised = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataAuthorised]) == 1 ? true : false;
                            objPool.LinkedCT.Add(objConcentrationLookUpData);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Populate comments history with date and action
                        while (resultReader.Read())
                        {
                            CommentsHistory objCommentsHistory = new CommentsHistory();
                            objCommentsHistory.CommentsDate = Utility.ConvertUTCToUKTime(Convert.ToString(resultReader[DbConstants.DbFieldCommentsDate]));
                            objCommentsHistory.CommentsAction = Convert.ToString(resultReader[DbConstants.DbFieldCommentAction]);
                            objCommentsHistory.Comments = Convert.ToString(resultReader[DbConstants.DbFieldComments]);
                            objPool.CommentsHistory.Add(objCommentsHistory);
                        }
                    }
                }
            }
            return objPool;
        }

        public IList<PoolSourceDealSummary> GetPoolSourceDealSummaryById(int poolId, string userName)
        {
            IList<PoolSourceDealSummary> poolSourceDealSummaryList = new List<PoolSourceDealSummary>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetSourceDealSummaryById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamForTopupDisplayPurpose, 1);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            poolSourceDealSummaryList.Add(new PoolSourceDealSummary()
                            {
                                DealName = Utility.GetString(resultReader[DbConstants.DbFieldPoolSummaryDealName]),
                                NumberOfAccounts = Utility.GetInt(resultReader[DbConstants.DbFieldPoolSummaryNumberOfAccounts]),
                                NumberOfSubAccounts = Utility.GetInt(resultReader[DbConstants.DbFieldPoolSummaryNumberOfSubAccounts]),
                                Balance = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolSummaryBalance])
                            });
                        }
                    }
                }

            }
            return poolSourceDealSummaryList;
        }

        public IList<PoolList> GetPools(int assetId, string userName)
        {
            IList<PoolList> poolList = new List<PoolList>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAssetId, assetId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            poolList.Add(new PoolList()
                            {
                                PoolId = Utility.GetInt(resultReader[DbConstants.DbFieldPoolId]),
                                Name = Utility.GetString(resultReader[DbConstants.DbFieldPoolName]),
                                Description = Utility.GetString(resultReader[DbConstants.DbFieldPoolDescription]),
                                PoolLimit = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolLimit]),
                                NumberOfAccount = Utility.GetIntNullable(resultReader[DbConstants.DbFieldPoolNumberOfAccount]),
                                VintageDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldPoolVintageDate]),
                                TrueBalance = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolTrueBalance]),
                                CapitalBalance = Utility.GetDecimal(resultReader[DbConstants.DbFieldPoolCapitalBalance]),
                                Balance = Utility.GetDecimal(resultReader[DbConstants.DbFieldBalance]),
                                CreatedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolCreatedBy]),
                                Status = Utility.GetString(resultReader[DbConstants.DbFieldPoolStatus]),
                                Purpose = Utility.GetString(resultReader[DbConstants.DbFieldPoolPurpose]),
                                AuthorizedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolAuthorizedBy]),
                                BuiltBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolBuiltBy]),
                                BuiltDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldPoolBuiltDate]),
                                CreatedDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldCreatedDate]),
                                ModifiedDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldModifiedDate])
                            });
                        }
                    }
                }

            }
            return poolList;
        }

        public int CreatePool(Pool pool, string userName)
        {
            int poolId;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_CreatePool, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(CreateStandardSourcingParameterList(pool, SavePurpose.Insert, userName).ToArray<SqlParameter>());

                cmd.Parameters.Add(DbConstants.DbProcParamPoolId, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamPoolId].Direction = ParameterDirection.Output;

                var rowsAffected = cmd.ExecuteNonQuery();

                poolId = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamPoolId].Value);
            }
            return poolId;
        }

        public int UpdatePool(Pool pool, string userName)
        {
            int returnCode;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_UpdatePool, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddRange(CreateStandardSourcingParameterList(pool, SavePurpose.Update, userName).ToArray<SqlParameter>());

                cmd.Parameters.Add(DbConstants.DbProcParamDuplicateReturnCode, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamDuplicateReturnCode].Direction = ParameterDirection.Output;
                int rowsAffected = cmd.ExecuteNonQuery();

                int duplicateReturnCode = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamDuplicateReturnCode].Value);
                returnCode = (duplicateReturnCode == -2) ? duplicateReturnCode : rowsAffected;
            }
            return returnCode;
        }

        public IList<Pool> BuildPool(int poolId, string loggedInUserName, int assetId)
        {
            string SP_PoolBuild = GetPoolBuildSpNameByAsset((AssetType)assetId);

            IList<Pool> poolDetailList = new List<Pool>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_PoolBuild, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPBPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPBUserName, loggedInUserName);

                SqlParameter cmdout = new SqlParameter();
                cmdout.ParameterName = DbConstants.DbProcParamPBReturnValue;
                cmdout.Direction = ParameterDirection.Output;
                cmdout.SqlDbType = SqlDbType.Int;
                cmd.Parameters.Add(cmdout);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        poolDetailList.Add(new Pool()
                        {
                            Id = Utility.GetInt(reader[DbConstants.DbFieldPoolId]),
                            Status = Utility.GetString(reader[DbConstants.DbFieldPoolStatus]),
                            TrueBalance = Utility.GetDecimal(reader[DbConstants.DbFieldPoolTrueBalance]),
                            CapitalBalance = Utility.GetDecimal(reader[DbConstants.DbFieldPoolCapitalBalance]),
                            NumberOfAccount = Utility.GetInt(reader[DbConstants.DbFieldPoolNumberOfAccount]),
                            NumberOfSubAccount = Utility.GetInt(reader[DbConstants.DbFieldPoolNumberOfSubAccount]),
                            SelectedLoanPercentage = Utility.GetDecimal(reader[DbConstants.DbFieldPoolSelectedLoanPercentage]),
                            PrincipleBalancePercentage = Utility.GetDecimal(reader[DbConstants.DbFieldPoolPrincipleBalancePercentage]),
                            CreatedDate = Utility.GetDateTime(reader[DbConstants.DbFieldPoolCreatedDate]),
                            CreatedBy = Utility.GetString(reader[DbConstants.DbFieldPoolCreatedBy]),
                            BuiltDate = Utility.GetDateTime(reader[DbConstants.DbFieldPoolBuiltDate]),
                            AuthorizedDate = Utility.GetDateTime(reader[DbConstants.DbFieldPoolAuthorizedDate]),
                            AuthorizedBy = Utility.GetString(reader[DbConstants.DbFieldPoolAuthorizedBy]),
                            CurrentPoolAmount = Utility.GetDecimal(reader[DbConstants.DbFieldPoolCurrentPoolAmount]),
                            PoolBuildExecutionStatus = string.Empty,
                            PurposeId = Utility.GetInt(reader[DbConstants.DbFieldPoolPurposeId]),
                            TargetPoolId = Utility.GetInt(reader[DbConstants.DbFieldPoolTargetPoolId]),
                            ApplyExclusion = Utility.GetBool(reader[DbConstants.DbFieldPoolApplyExclusion])
                        });
                    }
                }

                GetSourceDeals(poolDetailList, reader);

                if (poolDetailList.Any())
                    poolDetailList.First().PoolBuildExecutionStatus = cmdout.Value != null ? Convert.ToString(cmdout.Value) : "0";
                else
                    poolDetailList.Add(new Pool()
                    {
                        PoolBuildExecutionStatus = cmdout.Value != null ? Convert.ToString(cmdout.Value) : "0"
                    });
                return poolDetailList;
            }
        } 

        public IList<ExportAdvanceSourceData> ExportAdvanceSourceData(int poolId, string loggedInUserName, int reportTypeId)
        {
            IList<ExportAdvanceSourceData> exportAdvanceSourceData = new List<ExportAdvanceSourceData>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetPoolDataForExport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamReportTypeId, reportTypeId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlDataReader reader = cmd.ExecuteReader();
                if (reportTypeId == 3)
                {
                    while (reader.Read())
                    {
                        exportAdvanceSourceData.Add(new ExportAdvanceSourceData()
                        {
                            LoanId = Utility.GetInt(reader["LoanId"]),
                            BrandID = Utility.GetString(reader["BrandId"]),
                            DealName = Utility.GetString(reader["DealName"]),
                            VintageDate = Utility.GetDateTime(reader["VintageDate"]),
                            PoolID = Utility.GetInt(reader["PoolID"]),
                            OutstandingCapitalBalance = Utility.GetDecimal(reader["OutstandingCapitalBalance"]),
                            TrueBalance = Utility.GetDecimal(reader["TrueBalance"])
                        });
                    }
                }
                else
                {
                    while (reader.Read())
                    {
                        exportAdvanceSourceData.Add(new ExportAdvanceSourceData()
                        {
                            LoanId = Utility.GetInt(reader["LoanId"]),
                            BrandID = Utility.GetString(reader["BrandId"]),
                            DealName = Utility.GetString(reader["DealName"]),
                            VintageDate = Utility.GetDateTime(reader["VintageDate"]),
                            PoolID = Utility.GetInt(reader["PoolID"]),
                            SubAccountId = Utility.GetInt(reader["SubAccountId"]),
                            OutstandingCapitalBalance = Utility.GetDecimal(reader["OutstandingCapitalBalance"]),
                            TrueBalance = Utility.GetDecimal(reader["TrueBalance"])
                        });
                    }
                }
                return exportAdvanceSourceData;
            }
        }

        public IList<ExportAdvanceSourceData> GeneratePoolExtractReportCB(int poolId, string loggedInUserName, int reportTypeId)
        {
            IList<ExportAdvanceSourceData> exportAdvanceSourceData = new List<ExportAdvanceSourceData>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spGetPoolDataForExportCB]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamReportTypeId, reportTypeId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.CommandTimeout = 0;
                SqlDataReader reader = cmd.ExecuteReader();
                if (reportTypeId == 4)
                {
                    while (reader.Read())
                    {
                        exportAdvanceSourceData.Add(new ExportAdvanceSourceData()
                        {
                            LoanId = Utility.GetInt(reader["FacilityId"]),
                            DealName = Utility.GetString(reader["DealName"]),
                            VintageDate = Utility.GetDateTime(reader["VintageDate"]),
                            PoolID = Utility.GetInt(reader["PoolID"]),
                            OutstandingCapitalBalance = Utility.GetDecimal(reader["OutstandingCapitalBalance"]),
                            TrueBalance = Utility.GetDecimal(reader["TrueBalance"]),
                            Rona = Utility.GetDecimal(reader["Rona"]),
                            CisCode = Utility.GetString(reader["CIS"])
                        });
                    }
                }
                //else
                //{
                //    while (reader.Read())
                //    {
                //        exportAdvanceSourceData.Add(new ExportAdvanceSourceData()
                //        {
                //            LoanId = Utility.GetInt(reader["LoanId"]),
                //            BrandID = Utility.GetString(reader["BrandId"]),
                //            DealName = Utility.GetString(reader["DealName"]),
                //            VintageDate = Utility.GetDateTime(reader["VintageDate"]),
                //            PoolID = Utility.GetInt(reader["PoolID"]),
                //            SubAccountId = Utility.GetInt(reader["SubAccountId"]),
                //            OutstandingCapitalBalance = Utility.GetDecimal(reader["OutstandingCapitalBalance"]),
                //            TrueBalance = Utility.GetDecimal(reader["TrueBalance"])
                //        });
                //    }
                //}
                return exportAdvanceSourceData;
            }
        }

        public IList<long> ValidateUploadAsset(IList<long> assets, string Vintagedate, string loggedInUserName, int AssetClassId)
        {
            var invalidAssets = new List<long>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_ValidateUploadAssets, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter param = GetUploadedAssetParam(assets);

                cmd.Parameters.Add(param);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolVintageDate, Convert.ToDateTime(Vintagedate));
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.AssetClassId, AssetClassId);

                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    invalidAssets.Add(Utility.GetLong(reader["LoanId"]));
                }
            }
            return invalidAssets;
        }

        public int ValidateDrillThroughReport(int poolId, string loggedInUserName)
        {
            var validationStatus = 0;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_ValidateDrillThroughReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlParameter cmdOutReturnValue = new SqlParameter
                {
                    ParameterName = DbConstants.DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutReturnValue);

                cmd.ExecuteNonQuery();
                validationStatus = cmdOutReturnValue.Value == DBNull.Value || cmdOutReturnValue.Value == null ? 0
                                    : Convert.ToInt32(cmdOutReturnValue.Value);
            }
            return validationStatus;
        }

        public int ValidateDrillThroughReportCB(int poolId, string loggedInUserName)
        {
            var validationStatus = 0;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spValidateDrillThroughReportCB]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlParameter cmdOutReturnValue = new SqlParameter
                {
                    ParameterName = DbConstants.DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutReturnValue);

                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
                validationStatus = cmdOutReturnValue.Value == DBNull.Value || cmdOutReturnValue.Value == null ? 0
                                    : Convert.ToInt32(cmdOutReturnValue.Value);
            }
            return validationStatus;
        }

        public int ValidateEligibilityReportCB(int poolId, string loggedInUserName)
        {
            var validationStatus = 0;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spValidateEligibilityReportCB]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlParameter cmdOutReturnValue = new SqlParameter
                {
                    ParameterName = DbConstants.DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutReturnValue);

                cmd.CommandTimeout = 0;
                cmd.ExecuteNonQuery();
                validationStatus = cmdOutReturnValue.Value == DBNull.Value || cmdOutReturnValue.Value == null ? 0
                                    : Convert.ToInt32(cmdOutReturnValue.Value);
            }
            return validationStatus;
        }

        public MemoryStream GenerateDrillThroughReport(int poolId, string loggedInUserName)
        {
            var ecAndCtReportData = GetEcWiseReportData(poolId, loggedInUserName);
            if (ecAndCtReportData.ECReport.ECWiseReports.Any() || ecAndCtReportData.CTReport.Any())
            {
                return ExcelSheetForDrillThroughReport(ecAndCtReportData.ECReport, ecAndCtReportData.CTReport);
            }
            return null;
        }

        public ECAndCtReportData GetEcWiseReportData(int poolId, string loggedInUserName)
        {
            var ecANdCtReportResult = new ECAndCtReportData();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetECWiseReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    SetEcResult(ecANdCtReportResult.ECReport, reader);
                }
                reader.NextResult();
                SetPoolBalanceCount(ecANdCtReportResult.ECReport, reader);
                reader.NextResult();
                if (reader.HasRows)
                {
                    SetCtResult(ecANdCtReportResult.CTReport, reader);
                }
                return ecANdCtReportResult;
            }
        }

        public MemoryStream GenerateDetailedReport(int poolId, string loggedInUserName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetDetailedReport, conn))
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    var worksheet = workbook.Worksheets.Add($"Report - Loan Level");
                    var noOfColumns = 0;
                    var noOfRows = 1;
                    while (reader.Read())
                    {
                        if (noOfRows == 1)
                        {
                            worksheet.Cell(noOfRows, 1).Value = "LoanIdentifier";
                            worksheet.Cell(noOfRows, 2).Value = "Exclusion";
                            // after exclusion this will be change and random selection as well
                            noOfColumns = 2;
                            for (int i = 1; i < reader.FieldCount - 2; i++)
                            {
                                noOfColumns++;
                                worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                            }
                            worksheet.Cell(noOfRows, noOfColumns + 1).Value = "Total";
                            worksheet.Cell(noOfRows, noOfColumns + 2).Value = "Random Selection";

                            noOfRows++;
                            AddValuesToWorkSheet(reader, worksheet, noOfColumns, noOfRows);
                            noOfRows++;
                        }
                        else
                        {
                            AddValuesToWorkSheet(reader, worksheet, noOfColumns, noOfRows);
                            noOfRows++;
                        }
                    }

                    worksheet.Cell(noOfRows, 1).Value = "Total";
                    for (int i = 1; i < noOfColumns; i++)
                    {
                        var column = GetExcelColumnName(i + 1);
                        worksheet.Cell(noOfRows, i + 1).FormulaA1 = $"=SUM({column}2:{column}{noOfRows - 1})";
                    }

                    reader.Close();
                    worksheet.Cell(1, noOfColumns + 5).Value = "0 - Pass";
                    worksheet.Cell(2, noOfColumns + 5).Value = "1 - Fail";

                    workbook.CalculateMode = XLCalculateMode.Auto;
                    workbook.CalculationOnSave = true;
                }
                return GetAndSetSummaryReportData(poolId, loggedInUserName, workbook, stream);
            }
        }

        public MemoryStream GenerateECSummaryReportCB(int poolId, string loggedInUserName, bool isStandAlone = true, XLWorkbook workbook = null, MemoryStream stream = null)
        {
            var ecAndCtReportResult = new ECAndCtReportData();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spGetECWiseDrillThroughReportCB]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    SetEcResult(ecAndCtReportResult.ECReport, reader);
                }
                
                reader.NextResult();
                while (reader.Read())
                {
                    ecAndCtReportResult.ECReport.SourcePoolCount = Utility.GetInt(reader[DbConstants.DbProcParamSourcePoolCount]);
                    ecAndCtReportResult.ECReport.SourcePoolBalance = Utility.GetDecimal(reader[DbConstants.DbProcParamSourcePoolBalance]);
                    ecAndCtReportResult.ECReport.TotalPoolCount = Utility.GetInt(reader[DbConstants.DbProcParamTotalPoolCount]);
                    ecAndCtReportResult.ECReport.TotalPoolBalance = Utility.GetDecimal(reader[DbConstants.DbProcParamTotalPoolBalance]);
                    ecAndCtReportResult.ECReport.LoanSelectionCriteria = Utility.GetInt(reader["FacilitySelectionCriteria"]);
                }

                reader.NextResult();
                if (reader.HasRows)
                {
                    SetCtResult(ecAndCtReportResult.CTReport, reader);
                }

                if (ecAndCtReportResult.ECReport.ECWiseReports.Any() || ecAndCtReportResult.CTReport.Any())
                {
                    if (isStandAlone)
                    {
                        using (var workbook1 = new XLWorkbook())
                        using (var stream1 = new MemoryStream())
                        {
                            var worksheet = workbook1.Worksheets.Add($"EC Summary");
                            FillSummaryReportWorksheetCB(ecAndCtReportResult.ECReport, ecAndCtReportResult.CTReport, worksheet);
                            workbook1.SaveAs(stream1);
                            return stream1;
                        }
                    }
                    else
                    {
                        var ecWorksheet = workbook.Worksheets.Add($"EC Summary");
                        FillSummaryReportWorksheetCB(ecAndCtReportResult.ECReport, ecAndCtReportResult.CTReport, ecWorksheet);
                        workbook.SaveAs(stream);
                        return stream;
                    }
                }
                return null;
            }
        }

        private void FillSummaryReportWorksheetCB(ECWiseReportData eCWiseReportData, List<CTWiseReport> ctWiseReportData, IXLWorksheet worksheet)
        {
            var currentRow = 1;
            if (eCWiseReportData.ECWiseReports.Any() || ctWiseReportData.Any())
            {
                currentRow = PoolCountBalanceReportCB(eCWiseReportData, worksheet, currentRow);
            }
            if (eCWiseReportData.ECWiseReports.Any())
            {
                currentRow = FillEcReportsData(eCWiseReportData, worksheet, currentRow);

                currentRow += 3;
            }
            if (ctWiseReportData.Any())
            {
                FillCtReportData(ctWiseReportData, worksheet, currentRow);
            }
        }

        public MemoryStream GenerateIneligibilityDetailedReportCB(int poolId, string loggedInUserName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spGetDetailDrillThroughReportCB]", conn))
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue("@pEcReportType", "ineligible");
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    var worksheet = workbook.Worksheets.Add($"Report - Facility Level");
                    var noOfColumns = 0;
                    var noOfRows = 1;
                    while (reader.Read())
                    {
                        if (noOfRows == 1)
                        {
                            worksheet.Cell(noOfRows, 1).Value = "FacilityIdentifier";
                            //worksheet.Cell(noOfRows, 2).Value = "Exclusion";
                            // after exclusion this will be change and random selection as well
                            noOfColumns = 1;
                            for (int i = 1; i < reader.FieldCount - 2; i++)
                            {
                                noOfColumns++;
                                worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                            }
                            worksheet.Cell(noOfRows, noOfColumns + 1).Value = "Total";
                            worksheet.Cell(noOfRows, noOfColumns + 2).Value = "Random Selection";

                            noOfRows++;
                            AddValuesToWorkSheetCB(reader, worksheet, noOfColumns, noOfRows);
                            noOfRows++;
                        }
                        else
                        {
                            AddValuesToWorkSheetCB(reader, worksheet, noOfColumns, noOfRows);
                            noOfRows++;
                        }
                    }

                    worksheet.Cell(noOfRows, 1).Value = "Total";
                    for (int i = 1; i < noOfColumns; i++)
                    {
                        var column = GetExcelColumnName(i + 1);
                        worksheet.Cell(noOfRows, i + 1).FormulaA1 = $"=SUM({column}2:{column}{noOfRows - 1})";
                    }

                    reader.Close();
                    worksheet.Cell(1, noOfColumns + 5).Value = "0 - Pass";
                    worksheet.Cell(2, noOfColumns + 5).Value = "1 - Fail";

                    workbook.CalculateMode = XLCalculateMode.Auto;
                    workbook.CalculationOnSave = true;
                }
                
                return GenerateECSummaryReportCB(poolId, loggedInUserName, false, workbook, stream);
            }
        }

        public MemoryStream GenerateEligibilityDetailedReportCB(int poolId, string loggedInUserName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spGetDetailDrillThroughReportCB]", conn))
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue("@pEcReportType", "eligible");
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();

                if (reader.HasRows)
                {
                    var worksheet = workbook.Worksheets.Add($"Report - Facility Level");
                    var noOfColumns = 0;
                    var noOfRows = 1;
                    var showRandomSelectionColumn = false;
                    while (reader.Read())
                    {
                        if (noOfRows == 1)
                        {
                            worksheet.Cell(noOfRows, 1).Value = "FacilityIdentifier";
                            //worksheet.Cell(noOfRows, 2).Value = "Exclusion";
                            // after exclusion this will be change and random selection as well
                            noOfColumns = 1;
                            for (int i = 1; i < reader.FieldCount - 2; i++)
                            {
                                noOfColumns++;
                                worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                            }
                            worksheet.Cell(noOfRows, noOfColumns + 1).Value = "Total";
                            //worksheet.Cell(noOfRows, noOfColumns + 2).Value = "Random Selection";

                            noOfRows++;
                            AddValuesToWorkSheetCB(reader, worksheet, noOfColumns, noOfRows, showRandomSelectionColumn);
                            noOfRows++;
                        }
                        else
                        {
                            AddValuesToWorkSheetCB(reader, worksheet, noOfColumns, noOfRows, showRandomSelectionColumn);
                            noOfRows++;
                        }
                    }

                    worksheet.Cell(noOfRows, 1).Value = "Total";
                    for (int i = 1; i < noOfColumns; i++)
                    {
                        var column = GetExcelColumnName(i + 1);
                        worksheet.Cell(noOfRows, i + 1).FormulaA1 = $"=SUM({column}2:{column}{noOfRows - 1})";
                    }

                    reader.Close();
                    worksheet.Cell(1, noOfColumns + 5).Value = "1 - Pass";
                    worksheet.Cell(2, noOfColumns + 5).Value = "0 - Fail";

                    workbook.CalculateMode = XLCalculateMode.Auto;
                    workbook.CalculationOnSave = true;
                }
                
                return GenerateECSummaryReportCB(poolId, loggedInUserName, false, workbook, stream);
            }
        }

        public IList<BrandList> GetBrandList()
        {
            //try
            //{
            IList<BrandList> bList = new List<BrandList>();

            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetBrandList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                SqlDataReader reader = cmd.ExecuteReader();

                while (reader.Read())
                {
                    bList.Add(new BrandList()
                    {
                        BrandKey = Utility.GetString(reader["BrandKey"]),
                        BrandCode = Utility.GetString(reader["BrandCode"]),
                        RegionCode = Utility.GetString(reader["RegionCode"]),
                    });
                }
                return bList;
            }
            //}
            //catch
            //{
            //    throw;
            //}
        }
        public int ValidateSubmitAndUpdatePool(SubmittedPoolData submittedPoolData, string loggedInUserName)
        {
            var validationStatus = 0;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_ValidateSubmitAndUpdatePool, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, submittedPoolData.PoolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolDescription, submittedPoolData.Description);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamIsSubmitted, submittedPoolData.IsSubmitted ? 1 : 0);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamEffectiveDate, Convert.ToDateTime(submittedPoolData.EffectiveDate));
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolModifiedDate, submittedPoolData.ModifiedDate);
                if (string.IsNullOrEmpty(submittedPoolData.NoticeDate))
                {
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamNoticeDate, DBNull.Value);
                }
                else
                {
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamNoticeDate, Convert.ToDateTime(submittedPoolData.NoticeDate));
                }
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamCommentsBySubmitter, submittedPoolData.CommentsBySubmitter);
                SqlParameter cmdOutReturnValue = new SqlParameter
                {
                    ParameterName = DbConstants.DbProcParamReturnValue,
                    Direction = ParameterDirection.Output,
                    SqlDbType = SqlDbType.Int
                };
                cmd.Parameters.Add(cmdOutReturnValue);
				cmd.CommandTimeout = 0;

                cmd.ExecuteNonQuery();
                validationStatus = cmdOutReturnValue.Value == DBNull.Value || cmdOutReturnValue.Value == null ? 0
                                    : Convert.ToInt32(cmdOutReturnValue.Value);
            }
            return validationStatus;
        }

        public int UpdatePoolAuthorisationStatus(int poolId, bool isRejected, string comments, string userName, DateTime ModifiedDate)
        {
            int returnCode;
            string cmdText = (isRejected) ? DbConstants.SP_Pool_Reject : DbConstants.SP_Pool_Authorise;
            using (SqlConnection conn = new SqlConnection(this._settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(cmdText, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolCommentsByAuthoriser, comments);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolModifiedDate, ModifiedDate);
                cmd.Parameters.Add(DbConstants.DbProcParamReturnCode, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamReturnCode].Direction = ParameterDirection.Output;
                returnCode = cmd.ExecuteNonQuery();

                if (cmd.Parameters[DbConstants.DbProcParamReturnCode].Value != DBNull.Value)
                {
                    returnCode = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamReturnCode].Value);
                }
            }
            return returnCode;
        }

        public IList<int> GetDependentPools(int poolId, string userName)
        {
            IList<int> dependentPools = new List<int>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetDependentPools, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            if (resultReader[DbConstants.DbFieldPoolDependentPoolId] != DBNull.Value)
                                dependentPools.Add(Convert.ToInt32(resultReader[DbConstants.DbFieldPoolDependentPoolId]));
                        }
                    }
                }
            }
            return dependentPools;
        }

        public PoolValidationSummary ValidateSubmittedLoans(int poolId, string userName)
        {
            PoolValidationSummary objPoolValidationSummary = new PoolValidationSummary();
            List<MatchedLoans> matchedLoansList = new List<MatchedLoans>();
            List<InvalidLoans> invalidLoansList = new List<InvalidLoans>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_ValidateSubmittedEntities, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        // Matched Loans
                        while (resultReader.Read())
                        {
                            MatchedLoans objMatchedLoans = new MatchedLoans
                            {
                                PoolName = Utility.GetString(resultReader[DbConstants.DbFieldPoolName]),
                                PoolStatus = Utility.GetString(resultReader[DbConstants.DbFieldPoolStatus]),
                                MatchedLoanId = Utility.GetLong(resultReader[DbConstants.DbFieldPoolMatchedLoanId]),
                            };
                            matchedLoansList.Add(objMatchedLoans);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        //Invalid Loans
                        while (resultReader.Read())
                        {
                            InvalidLoans objInvalidLoans = new InvalidLoans
                            {
                                LoanId = Utility.GetLong(resultReader[DbConstants.DbFieldPoolInvalidLoanId]),
                                Reason = Utility.GetString(resultReader[DbConstants.DbFieldPoolInvalidReason])
                            };
                            invalidLoansList.Add(objInvalidLoans);
                        }
                    }
                }

                objPoolValidationSummary.MatchedLoanSummary = PopulateMatchedLoanSummary(matchedLoansList);
                objPoolValidationSummary.InvalidLoanSummary = PopulateInvalidLoanSummary(invalidLoansList);

            }
            return objPoolValidationSummary;
        }

        public PoolExclusionChangeImpact ValidateExclusionChangeImpact(int poolId, string userName)
        {
            PoolExclusionChangeImpact objPoolExclusionChangeImpact = new PoolExclusionChangeImpact();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_ValidateExclusionChangeImpact, conn)) // SP Name
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                SqlDataReader resultReader;

                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            objPoolExclusionChangeImpact.IsImpacted = Utility.GetBool(resultReader[DbConstants.DbFieldPoolExclusionChangeIsImpacted]);
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            objPoolExclusionChangeImpact.ImpactedLoans.Add(Utility.GetLong(resultReader[DbConstants.DbFieldPoolExclusionChangeImpactedLoanId])); // FIELD NAME
                        }
                    }
                }

            }
            return objPoolExclusionChangeImpact;
        }

        public IList<string> GetPoolRegionWithHoliday(int poolId, string effectiveDate, string userName)
        {
            List<string> regionList = new List<string>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetPoolRegionWithHoliday, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamEffectiveDate, Convert.ToDateTime(effectiveDate));
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            regionList.Add(Utility.GetString(resultReader[DbConstants.DbFieldPoolRegion]));
                        }
                    }
                }

            }
            return regionList;
        }

        public PoolEcAndCtReportData GetPoolEcAndCtReportData(int poolId, string userName)
        {
            var result = new PoolEcAndCtReportData();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GeneratePoolAppliedEcCtReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure; 
                cmd.Parameters.AddWithValue(DbConstants.DbProcEcCtParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName); 

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.PoolEcReport.Add(new PoolEcReport()
                        {
                            EcName = Utility.GetString(reader[DbConstants.DbFieldEcName]),
                            EcDescription = Utility.GetString(reader[DbConstants.DbFieldEcDescription]),
                            EcEligibilityExpression = Utility.GetString(reader[DbConstants.DbFieldEcEligibilityExpression]),
                            EcType = Utility.GetString(reader[DbConstants.DbFieldEcType]),
                            EcTypeDescription = Utility.GetString(reader[DbConstants.DbFieldEcTypeDescription]),
                            EcStatus = Utility.GetString(reader[DbConstants.DbFieldEcStatus])
                        });
                    } 
                }

                reader.NextResult();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.PoolCtReport.Add(new PoolCtReport()
                        {
                            CtCriteriaName = Utility.GetString(reader[DbConstants.DbFieldCtCriteriaName]),
                            CtDescription = Utility.GetString(reader[DbConstants.DbFieldCtDescription]),
                            CtExpression = Utility.GetString(reader[DbConstants.DbFieldCtExpression]),
                            CtTestType = Utility.GetString(reader[DbConstants.DbFieldCtTestType]),
                            CtTestTypeDescription = Utility.GetString(reader[DbConstants.DbFieldCtTestTypeDescription]),
                            CtStatus = Utility.GetString(reader[DbConstants.DbFieldCtStatus])
                        });
                    }
                }

                return result; 
            }
        }

        public PoolEcAndCtReportDataCB GetPoolEcAndCtReportDataCB(int poolId, string userName)
        {
            var result = new PoolEcAndCtReportDataCB();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand("[corp].[spGeneratePoolAppliedEcCtReportCB]", conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcEcCtParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.PoolEcReport.Add(new PoolEcReportCB()
                        {
                            EcName = Utility.GetString(reader[DbConstants.DbFieldEcName]),
                            EcDescription = Utility.GetString(reader[DbConstants.DbFieldEcDescription]),
                            EcEligibilityExpression = Utility.GetString(reader[DbConstants.DbFieldEcEligibilityExpression]),
                            EcType = Utility.GetString(reader[DbConstants.DbFieldEcType]),
                            EcTypeDescription = Utility.GetString(reader[DbConstants.DbFieldEcTypeDescription]),
                            EcStatus = Utility.GetString(reader[DbConstants.DbFieldEcStatus])
                        });
                    }
                }

                reader.NextResult();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.PoolCtReport.Add(new PoolCtReportCB()
                        {
                            CtCriteriaName = Utility.GetString(reader[DbConstants.DbFieldCtCriteriaName]),
                            CtDescription = Utility.GetString(reader[DbConstants.DbFieldCtDescription]),
                            CtExpression = Utility.GetString(reader[DbConstants.DbFieldCtExpression]),
                            CtSuperSetExpression = Utility.GetString(reader["CtSuperSetExpression"]),
                            CtTestType = Utility.GetString(reader[DbConstants.DbFieldCtTestType]),
                            CtTestTypeDescription = Utility.GetString(reader[DbConstants.DbFieldCtTestTypeDescription]),
                            CtStatus = Utility.GetString(reader[DbConstants.DbFieldCtStatus])
                        });
                    }
                }

                return result;
            }
        }

        public string GetPoolSourceDealsById(int poolId, string userName)
        { 
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamReturnSourceDealsOnly, 1);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            return Utility.GetString(resultReader[DbConstants.DbFieldPoolSourceDeals]);
                        }
                    }
                }

            }
            return "";
        }

        public IList<PoolAccount> GetPoolDetailsById(int poolId, string dealId, string vintageDate, string userName)
        {
            IList<PoolAccount> poolDetailList = new List<PoolAccount>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetAccountsById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandTimeout = 0;
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPBPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamDealKey, dealId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamVintageDate, vintageDate.Substring(0, 10).Replace("-", string.Empty));
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        poolDetailList.Add(new PoolAccount()
                        {
                            FacilityId = Utility.GetIntNullable(reader[DbConstants.DbFieldPoolAccountFacilityId]),
                            EligibilityCriteria = Utility.GetString(reader[DbConstants.DbFieldPoolAccountEligibilityCriteria]),
                            DealName = Utility.GetString(reader[DbConstants.DbFieldDealName]),
                            DealId = Utility.GetIntNullable(reader[DbConstants.DbFieldPoolAccountDealId]),
                            Cis = Utility.GetString(reader[DbConstants.DbFieldPoolAccountCis]),
                            Mgs = Utility.GetString(reader[DbConstants.DbFieldPoolAccountMgs]),
                            LoanType = Utility.GetString(reader[DbConstants.DbFieldPoolAccountFacilityType]),
                            UtilisationGBP = Utility.GetDecimal(reader[DbConstants.DbFieldUtilisationGBP]),
                            CommittedExposure = Utility.GetDecimal(reader[DbConstants.DbFieldPoolAccountCommittedExposure]),
                            FacilityStartDate = Utility.GetDateTimeNullable(reader[DbConstants.DbFieldPoolAccountFacilityStartDate]),
                            ExpiryDate = Utility.GetDateTimeNullable(reader[DbConstants.DbFieldPoolAccountExpiryDate]),
                            PrevExpiryDate = Utility.GetDateTimeNullable(reader[DbConstants.DbFieldPoolAccountPrevExpiryDate]),
                            PrevMgs = Utility.GetString(reader[DbConstants.DbFieldPoolAccountPrevMgs]),
                            MaturityDate = Utility.GetDateTimeNullable(reader[DbConstants.DbFieldPoolAccountMaturityDate]),
                            PDMidPoint = Utility.GetDecimal(reader[DbConstants.DbFieldPoolAccountPDMidPoint]),
                            NumberOfDaysInArrears = Utility.GetIntNullable(reader[DbConstants.DbFieldPoolAccountNumberOfDaysInArrears]),
                            PreviousReasonValue = Utility.GetString(reader[DbConstants.DbFieldPoolAccountPreviousValue]),
                            PreviousReasonId = Utility.GetIntNullable(reader[DbConstants.DbFieldPoolAccountPreviousId]),
                            CurrentReasonValue = Utility.GetString(reader[DbConstants.DbFieldPoolAccountCurrentValue]),
                            CurrentReasonId = Utility.GetIntNullable(reader[DbConstants.DbFieldPoolAccountCurrentId]),
                            IsActive = Utility.GetInt(reader[DbConstants.DbFieldPoolAccountIsActive]) == 1
                        });
                    }
                }

                return poolDetailList;
            }
        }

        public string GetPoolLastFlagDateById(int poolId, string userName)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue("@pLastFlaggingDateOnly", 1);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);
                cmd.CommandTimeout = 0;
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            return Utility.GetDateTime(resultReader["LastFlagDeFlagDate"]);
                        }
                    }
                }

            }
            return "";
        }

        public IList<LoanInclusionReason> GetPoolInclusionReasons()
        {
            IList<LoanInclusionReason> loanInclusionReasonList = new List<LoanInclusionReason>();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_GetInclusionReasons, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                //cmd.Parameters.AddWithValue(DbConstants.DbProcParamPBPoolId, poolId);
                //cmd.Parameters.AddWithValue(DbConstants.DbProcParamDealKey, dealId);
                //cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        loanInclusionReasonList.Add(new LoanInclusionReason()
                        {
                            InclusionId = Utility.GetInt(reader[DbConstants.DbFieldPoolAccountInclusionId]),
                            InclusionValue = Utility.GetString(reader[DbConstants.DbFieldPoolAccountInclusionValue])
                        });
                    }
                }

                return loanInclusionReasonList;
            }
        }

        public int UpdatePoolAccounts(IList<PoolAccount> accounts, int poolId, string userName)
        {
            var rowsAffected = -1;
            
            //var inclusionReasonList = GetPoolInclusionReasons();
            //Dictionary<string, int> reasonMapper = new Dictionary<string, int>();
            //foreach (var i in inclusionReasonList)
            //{
            //    reasonMapper.Add(i.InclusionValue, i.InclusionId);
            //}
            
            var loansTable = new DataTable();
            loansTable.Columns.Add("DealID", typeof(long));
            loansTable.Columns.Add("FacilityID", typeof(long));
            loansTable.Columns.Add("CurrentReasonID", typeof(long));
            loansTable.Columns.Add("IsSelected", typeof(bool));
            foreach (var loan in accounts)
            {
                DataRow dr = loansTable.NewRow();
                dr["FacilityID"] = loan.FacilityId;
                if (!loan.CurrentReasonId.HasValue)
                    dr["CurrentReasonID"] = DBNull.Value;
                else
                    dr["CurrentReasonID"] = loan.CurrentReasonId;
                dr["DealID"] = loan.DealId;
                dr["IsSelected"] = loan.IsActive;
                loansTable.Rows.Add(dr);
            }

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Pool_UpdatePoolAccounts, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue("@pFacilityIdList", loansTable);

                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, userName);

                rowsAffected = cmd.ExecuteNonQuery();
            }
            return rowsAffected;
        }

        #region Private methods
        private List<MatchedLoanSummary> PopulateMatchedLoanSummary(List<MatchedLoans> matchedLoansList)
        {
            List<MatchedLoanSummary> matchedLoanSummaryList = new List<MatchedLoanSummary>();

            IEnumerable<MatchedLoans> MatchedPools = matchedLoansList.GroupBy(matchedLoan => matchedLoan.PoolName).Select(loanSummary => loanSummary.First());

            foreach (var pool in MatchedPools)
            {
                MatchedLoanSummary matchedLoanSummary = new MatchedLoanSummary
                {
                    Name = pool.PoolName,
                    Status = pool.PoolStatus,
                    MatchedLoanIds = matchedLoansList.FindAll(loan => loan.PoolName == pool.PoolName).Select(loan => loan.MatchedLoanId).ToList()
                };
                matchedLoanSummary.MatchedLoanCount = matchedLoanSummary.MatchedLoanIds.Count;
                matchedLoanSummaryList.Add(matchedLoanSummary);
            }

            return matchedLoanSummaryList;
        }

        private List<InvalidLoanSummary> PopulateInvalidLoanSummary(List<InvalidLoans> invalidLoansList)
        {
            List<InvalidLoanSummary> invalidLoanSummaryList = new List<InvalidLoanSummary>();

            IEnumerable<InvalidLoans> InvalidReasons = invalidLoansList.GroupBy(invalidLoan => invalidLoan.Reason).Select(invalidLoan => invalidLoan.First());

            foreach (var reason in InvalidReasons)
            {
                InvalidLoanSummary invalidLoanSummary = new InvalidLoanSummary
                {
                    Reason = reason.Reason,
                    InvalidLoanIds = invalidLoansList.FindAll(loan => loan.Reason == reason.Reason).Select(loan => loan.LoanId).ToList()
                };
                invalidLoanSummary.LoanCount = invalidLoanSummary.InvalidLoanIds.Count;
                invalidLoanSummaryList.Add(invalidLoanSummary);
            }

            return invalidLoanSummaryList;
        }

        private List<SqlParameter> CreateStandardSourcingParameterList(Pool objPool, SavePurpose purpose, string userName)
        {
            List<SqlParameter> parameterCollection = GetSourcingParameterList();

            parameterCollection[0].SqlValue = Utility.GetString(objPool.Name);
            parameterCollection[1].SqlValue = Utility.GetString(objPool.Description);

            if (objPool.Limit != null)
                parameterCollection[2].SqlValue = objPool.Limit;
            else
                parameterCollection[2].SqlValue = DBNull.Value;

            parameterCollection[3].SqlValue = Convert.ToDateTime(objPool.VintageDateString);
            parameterCollection[4].SqlValue = Convert.ToInt32(objPool.PurposeId);

            if (objPool.TargetPoolId != null)
                parameterCollection[5].SqlValue = Convert.ToInt32(objPool.TargetPoolId);
            else
                parameterCollection[5].SqlValue = DBNull.Value;

            if (objPool.RandomSelection != null)
                parameterCollection[6].SqlValue = Convert.ToInt32(objPool.RandomSelection);
            else
                parameterCollection[6].SqlValue = DBNull.Value;

            var linkedEcTable = new DataTable();

            linkedEcTable.Columns.Add(DbConstants.DbTypeIntListIntValue, typeof(Int32));
            foreach (var pLinkedEC in objPool.LinkedEC)
            {
                linkedEcTable.Rows.Add(Convert.ToInt32(pLinkedEC.Value));
            }

            parameterCollection[7].SqlValue = GetSelectedSourcePoolTable(objPool.SourcePoolList);
            parameterCollection[7].TypeName = DbConstants.DbTypeLookupTitleValue;

            parameterCollection[8].SqlValue = linkedEcTable;
            parameterCollection[8].TypeName = DbConstants.DbTypeIntList;

            parameterCollection[9].SqlValue = userName;

            parameterCollection[10].SqlValue = GetSelectedSourcePoolTable(objPool.AdvanceSourcePoolList1);
            parameterCollection[10].TypeName = DbConstants.DbTypeLookupTitleValue;

            parameterCollection[11].SqlValue = GetSelectedSourcePoolTable(objPool.AdvanceSourcePoolList2);
            parameterCollection[11].TypeName = DbConstants.DbTypeLookupTitleValue;

            parameterCollection[12].SqlValue = objPool.SourcingType;

            parameterCollection[13].SqlValue = objPool.UploadedFileName != null ? objPool.UploadedFileName : (object)DBNull.Value;

            var uploadedAssetDt = new DataTable();
            uploadedAssetDt.Columns.Add(DbConstants.DbTypeIntListIntValue, typeof(int));

            objPool.UploadedAssets.ForEach(asset =>
            {
                uploadedAssetDt.Rows.Add(asset);
            });

            parameterCollection[14].SqlValue = uploadedAssetDt;
            parameterCollection[14].TypeName = DbConstants.DbTypeIntList;

            parameterCollection[15].SqlValue = (objPool.PoolReasonId != null) ? Convert.ToInt32(objPool.PoolReasonId) : (object)DBNull.Value;

            if (objPool.PoolLimitAnalysisFieldId != null)
            {
                parameterCollection[16].SqlValue = Convert.ToInt32(objPool.PoolLimitAnalysisFieldId);
            }
            else
            {
                parameterCollection[16].SqlValue = DBNull.Value;
            }

            var brandDt = new DataTable();
            brandDt.Columns.Add(DbConstants.DbTypeIntListIntValue, typeof(int));

            objPool.BrandSelectionList.ForEach(bd =>
            {
                brandDt.Rows.Add(bd);
            });

            parameterCollection[17].SqlValue = brandDt;
            parameterCollection[17].TypeName = DbConstants.DbTypeIntList;

            var inclusionList = new DataTable();
            inclusionList.Columns.Add(DbConstants.DbTypeIntListIntValue, typeof(int));
            objPool.InclusionList.ForEach(loanNumber => { inclusionList.Rows.Add(loanNumber); });
            parameterCollection[18].SqlValue = inclusionList;
            parameterCollection[18].TypeName = DbConstants.DbTypeIntList;

            parameterCollection[19].SqlValue = objPool.InclusionFileName != null ? objPool.InclusionFileName : (object)DBNull.Value;

            parameterCollection[20].SqlValue = Convert.ToInt32(objPool.DealTypeId);
            parameterCollection[21].SqlValue = Convert.ToInt32(objPool.IpdFrequencyId);

            var linkedCTTable = new DataTable();
            linkedCTTable.Columns.Add(DbConstants.DbTypeIntListIntValue, typeof(Int32));
            foreach (var pLinkedCT in objPool.LinkedCT)
            {
                linkedCTTable.Rows.Add(Convert.ToInt32(pLinkedCT.Value));
            }
            parameterCollection[22].SqlValue = linkedCTTable;
            parameterCollection[22].TypeName = DbConstants.DbTypeIntList;

            parameterCollection[23].SqlValue = Convert.ToBoolean(objPool.ApplyExclusion);
            parameterCollection[24].SqlValue = objPool.PoolInclusionOption;
            parameterCollection[25].SqlValue = objPool.PoolIncludedExclusions;
            parameterCollection[26].SqlValue = Convert.ToInt32(objPool.ApplicableECMethod);
            parameterCollection[27].SqlValue = Convert.ToBoolean(objPool.IsBalanceUploaded);

            var uploadedAssetsData = new DataTable();
            uploadedAssetsData.Columns.Add(DbConstants.DbTypeLoanNumber, typeof(int));
            uploadedAssetsData.Columns.Add(DbConstants.DbTypeLoanBalance, typeof(decimal));

            objPool.UploadedAssetsData.ForEach(asset =>
            {
                uploadedAssetsData.Rows.Add(Utility.GetInt(asset.LoanNumber), 
                    Utility.GetDecimal(asset.LoanBalance));
            });

            parameterCollection[28].SqlValue = uploadedAssetsData;

            if (purpose == SavePurpose.Update)
            {
                parameterCollection.Add(new SqlParameter(DbConstants.DbProcParamPoolId, SqlDbType.Int));
                parameterCollection[29].SqlValue = Convert.ToInt32(objPool.Id);
                parameterCollection.Add(new SqlParameter(DbConstants.DbProcParamIsPoolStateNeedsChange, SqlDbType.Int));
                parameterCollection[30].SqlValue = objPool.IsPoolStateNeedsChange ? 1 : 0;
            }
            if (purpose == SavePurpose.Insert)
            {
                parameterCollection.Add(new SqlParameter(DbConstants.DbProcParamPoolAssetClassId, SqlDbType.Int));
                parameterCollection[29].SqlValue = Convert.ToInt32(objPool.AssetClassId);
            }
            
            return parameterCollection;
        }

        private static List<SqlParameter> GetSourcingParameterList()
        {
            return new List<SqlParameter>
                    {
                        new SqlParameter(DbConstants.DbProcParamPoolName, SqlDbType.VarChar),
                        new SqlParameter(DbConstants.DbProcParamPoolDescription, SqlDbType.VarChar),
                        new SqlParameter(DbConstants.DbProcParamPoolLimit, SqlDbType.Decimal),
                        new SqlParameter(DbConstants.DbProcParamPoolVintageDate, SqlDbType.DateTime),
                        new SqlParameter(DbConstants.DbProcParamPoolPurposeId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolTargetPoolId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolRandomSelectionId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolSourcePool, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolLinkedEC, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamUserName, SqlDbType.VarChar),
                        new SqlParameter(DbConstants.DbProcParamPoolAdvanceSourcePool1, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolAdvanceSourcePool2, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolSourcingType, SqlDbType.VarChar),
                        new SqlParameter(DbConstants.DbProcParamPoolUploadFileName, SqlDbType.VarChar),
                        new SqlParameter(DbConstants.DbProcParamPoolUploadAssets, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolReasonId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolLimitAnalysisFieldId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolBrands, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolInclusionList, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolInclusionFileName, SqlDbType.VarChar),
                        new SqlParameter(DbConstants.DbProcParamPoolDealTypeId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolIpdFrequencyId, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamPoolLinkedCT, SqlDbType.Structured),
                        new SqlParameter(DbConstants.DbProcParamPoolApplyExclusion, SqlDbType.Bit),
                        new SqlParameter(DbConstants.DbProcParamPoolInclusionOption, SqlDbType.SmallInt),
                        new SqlParameter(DbConstants.DbProcParamPoolIncludedExclusions, SqlDbType.NVarChar),
                        new SqlParameter(DbConstants.DbProcParamApplicableECMethod, SqlDbType.Int),
                        new SqlParameter(DbConstants.DbProcParamIsBalanceUploaded, SqlDbType.Bit),
                        new SqlParameter(DbConstants.DbProcParamUploadedAssetsData, SqlDbType.Structured)
                    };
        }

        private DataTable GetSelectedSourcePoolTable(List<BasicLookUpData> selectedSourcePoolList)
        {
            var sourcePoolTable = new DataTable();
            sourcePoolTable.Columns.Add(DbConstants.DbTypeLookupTitleValue_Title, typeof(string));
            sourcePoolTable.Columns.Add(DbConstants.DbTypeLookupTitleValue_Value, typeof(Int32));
            foreach (var pSourcePool in selectedSourcePoolList)
            {
                sourcePoolTable.Rows.Add(pSourcePool.Title.ToString(), Convert.ToInt32(pSourcePool.Value));
            }
            return sourcePoolTable;
        }

        private SqlParameter GetUploadedAssetParam(IList<long> assets)
        {
            var assetsDt = new DataTable();
            assetsDt.Columns.Add(DbConstants.DbTypeIntListIntValue, typeof(Int64));
            assets.ToList().ForEach(x => assetsDt.Rows.Add(x));
            var param = new SqlParameter(DbConstants.DbProcParamPoolUploadAssets, SqlDbType.Structured)
            {
                SqlValue = assetsDt,
                TypeName = DbConstants.DbTypeBigIntList
            };
            return param;
        }

        private void PopulateSourcingBasedOnSourcingType(Pool objPool, SqlDataReader resultReader)
        {
            if (resultReader.HasRows && objPool.SourcingType == nameof(SourcingType.Standard))
            {
                //Populate Source Pool
                while (resultReader.Read())
                {
                    var objBasicLookUpData = GetBasicLookUpData(resultReader);
                    objPool.SourcePoolList.Add(objBasicLookUpData);
                }
            }
            else if (resultReader.HasRows && (objPool.SourcingType == nameof(SourcingType.Intersection) || objPool.SourcingType == nameof(SourcingType.Disjoint)))
            {
                while (resultReader.Read())
                {
                    var objBasicLookUpData = GetBasicLookUpData(resultReader);
                    objPool.AdvanceSourcePoolList1.Add(objBasicLookUpData);
                }

                resultReader.NextResult();
                if (resultReader.HasRows)
                {
                    while (resultReader.Read())
                    {
                        var objBasicLookUpData = GetBasicLookUpData(resultReader);
                        objPool.AdvanceSourcePoolList2.Add(objBasicLookUpData);
                    }
                }
            }
            else if (resultReader.HasRows)
            {
                while (resultReader.Read())
                {
                    if (resultReader[DbConstants.DbFieldLookupDataValue] != DBNull.Value)
                        objPool.UploadedAssets.Add(Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]));
                    if (objPool.IsBalanceUploaded)
                    {
                        objPool.UploadedAssetsData.Add(new UploadedAssetData()
                        {
                            LoanNumber = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]),
                            LoanBalance = Convert.ToDecimal(resultReader[DbConstants.DbFieldLookupDataBalance])
                        });
                    }
                }
            }
        }

        private BasicLookUpData GetBasicLookUpData(SqlDataReader resultReader)
        {
            var objBasicLookUpData = new BasicLookUpData();

            if (resultReader[DbConstants.DbFieldLookupDataValue] != DBNull.Value)
                objBasicLookUpData.Value = Convert.ToInt32(resultReader[DbConstants.DbFieldLookupDataValue]);

            objBasicLookUpData.Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]);
            return objBasicLookUpData;
        }

        private void AddValuesToWorkSheet(SqlDataReader reader, IXLWorksheet worksheet, int noOfColumns, int noOfRows)
        {
            var noOfFields = reader.FieldCount;
            for (int i = 0; i < noOfFields - 2; i++)
            {
                if (i == 0)
                    worksheet.Cell(noOfRows, i + 1).Value = reader.GetValue(i);
                else
                    worksheet.Cell(noOfRows, i + 2).Value = reader.GetValue(i) is DBNull || reader.GetValue(i) == null ? 0 : reader.GetValue(i);
            }

            var column = GetExcelColumnName(noOfColumns);
            worksheet.Cell(noOfRows, noOfColumns + 1).FormulaA1 = $"=SUM(C{noOfRows}:{column}{noOfRows})";

            worksheet.Cell(noOfRows, 2).Value = Convert.ToInt32(reader.GetValue(noOfFields - 2));
            worksheet.Cell(noOfRows, noOfColumns + 2).Value = reader.GetValue(noOfFields - 1);
        }

        private void AddValuesToWorkSheetCB(SqlDataReader reader, IXLWorksheet worksheet, int noOfColumns, int noOfRows, bool showRandomSelectionColumn = true)
        {
            var noOfFields = reader.FieldCount;
            for (int i = 0; i < noOfFields - 2; i++)
            {
                if (i == 0)
                    worksheet.Cell(noOfRows, i + 1).Value = reader.GetValue(i);
                else
                    worksheet.Cell(noOfRows, i + 1).Value = reader.GetValue(i) is DBNull || reader.GetValue(i) == null ? 0 : reader.GetValue(i);
            }

            var column = GetExcelColumnName(noOfColumns);
            worksheet.Cell(noOfRows, noOfColumns + 1).FormulaA1 = $"=SUM(B{noOfRows}:{column}{noOfRows})";

            //worksheet.Cell(noOfRows, 2).Value = Convert.ToInt32(reader.GetValue(noOfFields - 2));
            if (showRandomSelectionColumn)
            {
                worksheet.Cell(noOfRows, noOfColumns + 2).Value = reader.GetValue(noOfFields - 1);
            }
        }

        private string GetExcelColumnName(int columnNumber)
        {
            int dividend = columnNumber;
            string columnName = String.Empty;
            int modulo;

            while (dividend > 0)
            {
                modulo = (dividend - 1) % 26;
                columnName = Convert.ToChar(65 + modulo).ToString() + columnName;
                dividend = (int)((dividend - modulo) / 26);
            }

            return columnName;
        }
        private void GetSourceDeals(IList<Pool> poolDetailList, SqlDataReader reader)
        {
            reader.NextResult();

            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    poolDetailList.FirstOrDefault().SourceDeals = Utility.GetString(reader[DbConstants.DbFieldPoolSourceDeals]);
                }
            }
        }

        private MemoryStream ExcelSheetForDrillThroughReport(ECWiseReportData eCWiseReportData, List<CTWiseReport> ctWiseReportData)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet = workbook.Worksheets.Add($"EC Summary");
                FillSummaryReportWorksheet(eCWiseReportData, ctWiseReportData, worksheet);
                workbook.SaveAs(stream);
                return stream;
            }
        }

        private void FillSummaryReportWorksheet(ECWiseReportData eCWiseReportData, List<CTWiseReport> ctWiseReportData, IXLWorksheet worksheet)
        {
            var currentRow = 1;
            if(eCWiseReportData.ECWiseReports.Any() || ctWiseReportData.Any())
            {
                currentRow = PoolCountBalanceReport(eCWiseReportData, worksheet, currentRow);
            }
            if (eCWiseReportData.ECWiseReports.Any())
            {
                currentRow = FillEcReportsData(eCWiseReportData, worksheet, currentRow);

                currentRow += 3;
            }
            if (ctWiseReportData.Any())
            {
                FillCtReportData(ctWiseReportData, worksheet, currentRow);
            }
        }

        private void FillCtReportData(List<CTWiseReport> ctWiseReportData, IXLWorksheet worksheet, int currentRow)
        {
            worksheet.Cell(currentRow, 1).Value = "Concentration Criteria";
            worksheet.Cell(currentRow, 2).Value = "Threshhold Value";
            worksheet.Cell(currentRow, 3).Value = "Pool Concentration Value";
            worksheet.Cell(currentRow, 4).Value = "Status";

            foreach (var data in ctWiseReportData)
            {
                currentRow++;
                worksheet.Cell(currentRow, 1).Value = data.ConcentrationCriteria;
                worksheet.Cell(currentRow, 2).Value = $"{data.ThreshholdValue}";
                worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0.00";
                worksheet.Cell(currentRow, 3).Value = $"{data.PoolConcentrationValue}";
                worksheet.Cell(currentRow, 3).Style.NumberFormat.Format = "#,###,##0.00";
                worksheet.Cell(currentRow, 4).Value = data.Status;
            }
        }

        private int FillEcReportsData(ECWiseReportData eCWiseReportData, IXLWorksheet worksheet, int currentRow)
        {
            worksheet.Cell(currentRow, 1).Value = "Eligibility Criteria";
            worksheet.Cell(currentRow, 2).Value = "Pass Count";
            worksheet.Cell(currentRow, 3).Value = "Fail Count";
            worksheet.Cell(currentRow, 4).Value = "Pass Balance";
            worksheet.Cell(currentRow, 5).Value = "Fail Balance";

            foreach (var data in eCWiseReportData.ECWiseReports)
            {
                currentRow++;
                worksheet.Cell(currentRow, 1).Value = data.EligibilityCriteria;
                worksheet.Cell(currentRow, 2).Value = data.PassCount;
                worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0";
                worksheet.Cell(currentRow, 3).Value = $"{data.FailCount}";
                worksheet.Cell(currentRow, 3).Style.NumberFormat.Format = "#,###,##0";
                worksheet.Cell(currentRow, 4).Value = $"{data.PassBalance}";
                worksheet.Cell(currentRow, 4).Style.NumberFormat.Format = "#,###,##0.00";
                worksheet.Cell(currentRow, 5).Value = $"{data.FailBalance}";
                worksheet.Cell(currentRow, 5).Style.NumberFormat.Format = "#,###,##0.00";
            }

            return currentRow;
        }

        private int PoolCountBalanceReport(ECWiseReportData eCWiseReportData, IXLWorksheet worksheet, int currentRow)
        {
            worksheet.Cell(currentRow, 1).Value = "Eligible Pool Count";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.SourcePoolCount}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Eligible Pool Balance";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.SourcePoolBalance}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0.00";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Total Source Pool Count";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.TotalPoolCount}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Total Source Pool Balance";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.TotalPoolBalance}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0.00";
            currentRow++;

            currentRow += 2;
            return currentRow;
        }

        private int PoolCountBalanceReportCB(ECWiseReportData eCWiseReportData, IXLWorksheet worksheet, int currentRow)
        {
            worksheet.Cell(currentRow, 1).Value = "Eligible Pool Count";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.SourcePoolCount}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Eligible Pool Balance";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.SourcePoolBalance}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0.00";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Total Source Pool Count";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.TotalPoolCount}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Total Source Pool Balance";
            worksheet.Cell(currentRow, 2).Value = $"{eCWiseReportData.TotalPoolBalance}";
            worksheet.Cell(currentRow, 2).Style.NumberFormat.Format = "#,###,##0.00";
            currentRow++;

            worksheet.Cell(currentRow, 1).Value = "Facility Selection Criteria";
            worksheet.Cell(currentRow, 2).Value = eCWiseReportData.LoanSelectionCriteria == 1 ? "ALL EC should Pass" : "ANY EC should Pass";
            currentRow++;

            currentRow += 2;
            return currentRow;
        }

        private void SetEcResult(ECWiseReportData ecReport, SqlDataReader reader)
        {
            while (reader.Read())
            {
                ecReport.ECWiseReports.Add(new ECWiseReport()
                {
                    EligibilityCriteria = Utility.GetString(reader["Name"]),
                    PassCount = Utility.GetInt(reader["TotalPassCount"]),
                    PassBalance = Utility.GetDecimal(reader["TotalPassBalance"]),
                    FailCount = Utility.GetInt(reader["TotalFailCount"]),
                    FailBalance = Utility.GetDecimal(reader["TotalFailBalance"])
                });
            }
        }

        private void SetPoolBalanceCount(ECWiseReportData ecReport, SqlDataReader reader)
        {
            while (reader.Read())
            {
                ecReport.SourcePoolCount = Utility.GetInt(reader[DbConstants.DbProcParamSourcePoolCount]);
                ecReport.SourcePoolBalance = Utility.GetDecimal(reader[DbConstants.DbProcParamSourcePoolBalance]);
                ecReport.TotalPoolCount = Utility.GetInt(reader[DbConstants.DbProcParamTotalPoolCount]);
                ecReport.TotalPoolBalance = Utility.GetDecimal(reader[DbConstants.DbProcParamTotalPoolBalance]);
            }
        }

        private void SetCtResult(List<CTWiseReport> ctReport, SqlDataReader reader)
        {
            while (reader.Read())
            {
                ctReport.Add(new CTWiseReport()
                {
                    ConcentrationCriteria = Utility.GetString(reader["ConcentrationCriteria"]),
                    ThreshholdValue = Utility.GetDecimal(reader["ThreshholdValue"]),
                    PoolConcentrationValue = Utility.GetDecimal(reader["PoolConcentrationValue"]),
                    Status = Utility.GetString(reader["Status"])
                });
            }
        }

        private MemoryStream GetAndSetSummaryReportData(int poolId, string loggedInUserName, XLWorkbook workbook, MemoryStream stream)
        {
            var ecAndCtReportData = GetEcWiseReportData(poolId, loggedInUserName);
            if (ecAndCtReportData.ECReport.ECWiseReports.Any() || ecAndCtReportData.CTReport.Any())
            {
                var ecWorksheet = workbook.Worksheets.Add($"EC Summary");
                FillSummaryReportWorksheet(ecAndCtReportData.ECReport, ecAndCtReportData.CTReport, ecWorksheet);
                workbook.SaveAs(stream);
                return stream;
            }
            return null;
        }

        private static string GetPoolBuildSpNameByAsset(AssetType assetId)
        {
            string poolBuildSPName;
            switch (assetId)
            {
                case AssetType.Retail:
                    poolBuildSPName = DbConstants.SP_Pool_BuildPool;
                    break;
                case AssetType.Corporate:
                    poolBuildSPName = DbConstants.SP_Corporate_Pool_BuildPool;
                    break;
                default:
                    poolBuildSPName = DbConstants.SP_Pool_BuildPool;
                    break;
            }
            return poolBuildSPName;
        }

        #endregion
    }
}