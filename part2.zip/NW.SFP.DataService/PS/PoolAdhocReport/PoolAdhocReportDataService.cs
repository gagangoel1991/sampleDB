﻿using ClosedXML.Excel;
using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS.DataService;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.IO;
using System.Linq;

namespace NW.SFP.DataService.PS.PoolAdhocReport
{
    public class PoolAdhocReportDataService : IPoolAdhocReportDataService
    {
        private readonly IOptions<DataServiceSettings> _settings;
        public PoolAdhocReportDataService(IOptions<DataServiceSettings> settings)
        {
            _settings = settings;
        }

        public int DeleteReportTemplateData(int reportTemplateId, string loggedInUserName)
        {
            var result = -1;

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_DeleteReportTemplate, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhochPoolAdhocReportTemplateId, reportTemplateId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                result = cmd.ExecuteNonQuery();
            }
            return result;
        }

        public MemoryStream GenerateReportData(int reportTemplateId, int poolId, string loggedInUserName, ReportTemplateData reportTemplateData, bool isCsv)
        {
            if (isCsv)
                return GenerateReportDataCsv(reportTemplateId, poolId, loggedInUserName, reportTemplateData);

            return GenerateReportInExcel(reportTemplateId, poolId, loggedInUserName, reportTemplateData);
        }

        public IList<PoolAdhocReportTemplateList> GetAdhocReports(string loggedInUserName, int assetClassId)
        {
            IList<PoolAdhocReportTemplateList> poolAdhocReports = new List<PoolAdhocReportTemplateList>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GetAdhocReportList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.AssetClassId, assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            poolAdhocReports.Add(new PoolAdhocReportTemplateList()
                            {
                                ReportTemplateId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocReportId]),
                                ReportName = Utility.GetString(resultReader[DbConstants.DbFieldAdhocReportName]),
                                ReportTemplateType = Utility.GetString(resultReader[DbConstants.DbFieldAdhocReportTemplateType]),
                                ReportType = Utility.GetString(resultReader[DbConstants.DbFieldAdhocReportType]),
                                CreatedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolCreatedBy]),
                                CreatedDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldCreatedDate]),
                                ModifiedBy = Utility.GetString(resultReader[DbConstants.DbFieldPoolModifiedBy]),
                                ModifiedDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldModifiedDate])
                            });
                        }
                    }
                }
            }
            return poolAdhocReports;
        }

        public IList<AdhocReportField> GetFieldsForReports(string loggedInUserName, int assetClassId)
        {
            IList<AdhocReportField> reportFields = new List<AdhocReportField>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GetReportFieldList, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.AssetClassId, assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportFields.Add(new AdhocReportField()
                            {
                                Value = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataValue]),
                                Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]),
                                FieldDescription = Utility.GetString(resultReader[DbConstants.DbFieldLookupDescription]),
                                FieldDataType = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataTypeId]),
                                CriteriaFieldTable = Utility.GetString(resultReader[DbConstants.DbTypeCriteriaFieldTable])
                            });
                        }
                    }
                }
            }
            return reportFields;
        }

        public AdhocReportRefData GetReportRefData(string loggedInUserName, int assetClassId)
        {
            AdhocReportRefData adhocReportRefs = new AdhocReportRefData();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GetReportRefData, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue("@pAssetClassId", assetClassId);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            adhocReportRefs.ReportTemplates.Add(GetBasicLookUpObj(resultReader));
                        }
                    }

                    resultReader.NextResult();

                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            adhocReportRefs.Pools.Add(new AdHodReportPoolList()
                            {
                                Value = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataValue]),
                                Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]),
                                LoanCount = Utility.GetString(resultReader[DbConstants.DbFieldAdhocLoanCount])
                            });
                        }
                    }

                }
            }
            return adhocReportRefs;
        }

        public ReportTemplateData GetReportTemplateData(int reportTemplateId, string loggedInUserName)
        {
            var reportTemplateData = new ReportTemplateData();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GetReportTemplateById, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhochPoolAdhocReportTemplateId, reportTemplateId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            reportTemplateData.ReportName = Utility.GetString(resultReader[DbConstants.DbFieldAdhocReportName]);
                            reportTemplateData.IsPublic = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocIsPublic]);
                            reportTemplateData.CreatedBy = Utility.GetString(resultReader[DbConstants.DbFieldAdhocCreatedBy]);
                            reportTemplateData.ReportTypeId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocReportTypeId]);
                            reportTemplateData.AssetClassId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocAssetClassId]);
                            reportTemplateData.DealId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocDealId]);
                            reportTemplateData.ModifiedBy = Utility.GetString(resultReader[DbConstants.DbFieldAdhocModifiedBy]);
                            reportTemplateData.ModifiedDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldAdhocModifiedDate]);
                            reportTemplateData.WorkflowStepId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocWorkflowStepId]);
                            reportTemplateData.CurrentStatus = Utility.GetString(resultReader[DbConstants.DbFieldAdhocCurrentStatus]);
                            reportTemplateData.Comment = Utility.GetString(resultReader[DbConstants.DbFieldAdhocComment]);
                        }
                    }
                    else
                    {
                        return reportTemplateData;
                    }
                    resultReader.NextResult();
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            var adhocReportField = new AdhocReportField();

                            if (resultReader[DbConstants.DbFieldLookupDataValue] != DBNull.Value)
                                adhocReportField.Value = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataValue]);

                            adhocReportField.Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle]);
                            adhocReportField.FieldOrderId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocFieldOrderId]);
                            adhocReportField.DisplayFieldName = Utility.GetString(resultReader[DbConstants.DbTypeAdhochReportField_DisplayName]);
                            adhocReportField.AggregationId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocAggregationTypeId]);
                            adhocReportField.FieldDescription = Utility.GetString(resultReader[DbConstants.DbFieldLookupDescription]);
                            adhocReportField.FieldDataType = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataTypeId]);
                            //adhocReportField.CriteriaFieldTable = Utility.GetString (resultReader[DbConstants.DbTypeCriteriaFieldTable]);
                            reportTemplateData.ReportFields.Add(adhocReportField);
                        }
                    }
                    //Authorisation Workflow History Dataset
                    //resultReader.NextResult();
                    //if (resultReader.HasRows)
                    //{
                    //    while (resultReader.Read())
                    //    {
                    //        var adhocAuthWorkflow = new AdhocAuthorisationWorkflow();

                    //        adhocAuthWorkflow.DisplayName = Utility.GetString(resultReader[DbConstants.DbFieldAuthWorkFlowDisplayName]);
                    //        adhocAuthWorkflow.Comment = Utility.GetString(resultReader[DbConstants.DbFieldAuthWorkFlowComment]);
                    //        adhocAuthWorkflow.ActionedBy = Utility.GetString(resultReader[DbConstants.DbFieldAuthWorkFlowActionedBy]);
                    //        adhocAuthWorkflow.ActionedDate = Utility.GetDateTimeNullable(resultReader[DbConstants.DbFieldAuthWorkFlowActionedDate]);
                    //        reportTemplateData.AuthorisationAuditHistory.Add(adhocAuthWorkflow);
                    //    }
                    //}
                }
            }
            return reportTemplateData;
        }


        public IDictionary<int, List<AdhocReportOperator>> GetDatatypeAggregationMap(string loggedInUserName)
        {
            IDictionary<int, List<AdhocReportOperator>> adhocReportRefOperators = new Dictionary<int, List<AdhocReportOperator>>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GetDatatypeAggregationMap, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            int operatorId = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocDataTypeId]);
                            if (!adhocReportRefOperators.ContainsKey(operatorId))
                            {
                                adhocReportRefOperators[operatorId] = new List<AdhocReportOperator>();
                            }
                            adhocReportRefOperators[operatorId].Add(new AdhocReportOperator()
                            {
                                Value = Utility.GetInt(resultReader[DbConstants.DbFieldAdhocAggregationId]),
                                Title = Utility.GetString(resultReader[DbConstants.DbFieldAdhocAggregationName]),
                                Description = Utility.GetString(resultReader[DbConstants.DbFieldAdhocAggregationDescription])
                            });
                        }
                    }
                    else
                    {
                        return adhocReportRefOperators;
                    }
                }
            }
            return adhocReportRefOperators;
        }

        private List<ECFieldAttribute> GetECFieldAttributeList(string loggedInUserName)
        {
            List<ECFieldAttribute> ecFieldsAttributes = new List<ECFieldAttribute>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_GetEC_FieldAttributes, conn))
            {
                if (conn.State == ConnectionState.Closed)
                    conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            ecFieldsAttributes.Add(new ECFieldAttribute()
                            {
                                EligibilityCriteriaFieldId = Utility.GetInt(resultReader[DbConstants.DbFieldEligibilityCriteriaFieldId]),
                                FieldName = Utility.GetString(resultReader[DbConstants.DbFieldCriteriaFieldName]),
                                RequiresAccountingFormat = Utility.GetBool(resultReader[DbConstants.DbFieldRequireAccountingFormat])
                            });
                        }
                    }
                    else
                    {
                        return ecFieldsAttributes;
                    }
                }
            }
            return ecFieldsAttributes;
        }


        public int SaveReportTemplateData(ReportTemplateData reportTemplateData, string loggedInUserName)
        {
            int result;
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_SaveAdhochReportTemplate, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhocReportTemplateName, reportTemplateData.ReportName);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhocIsPublic, reportTemplateData.IsPublic);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                cmd.Parameters.AddWithValue(DbConstants.AssetClassId, reportTemplateData.AssetClassId);
                cmd.Parameters.AddWithValue(DbConstants.DealId, reportTemplateData.DealId);

                var linkedFieldsTable = new DataTable();

                linkedFieldsTable.Columns.Add(DbConstants.DbTypeAdhochReportField_Id, typeof(Int32));
                linkedFieldsTable.Columns.Add(DbConstants.DbTypeAdhochReportField_OrderId, typeof(Int32));
                linkedFieldsTable.Columns.Add(DbConstants.DbTypeAdhochReportField_DisplayName, typeof(string));
                linkedFieldsTable.Columns.Add(DbConstants.DbFieldAdhocAggregationTypeId, typeof(Int32));
                linkedFieldsTable.Columns.Add(DbConstants.DbFieldAdhocFieldLevel, typeof(string));
                foreach (var pLinkedField in reportTemplateData.ReportFields)
                {
                    if (pLinkedField.AggregationId != null)
                    {
                        linkedFieldsTable.Rows.Add(Convert.ToInt32(pLinkedField.Value), Convert.ToInt32(pLinkedField.FieldOrderId),
                                               pLinkedField.DisplayFieldName.ToString(), Convert.ToInt32(pLinkedField.AggregationId), "");
                    }
                    else
                    {
                        linkedFieldsTable.Rows.Add(Convert.ToInt32(pLinkedField.Value), Convert.ToInt32(pLinkedField.FieldOrderId),
                                               pLinkedField.DisplayFieldName.ToString(), DBNull.Value, "");
                    }
                }
                cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamAdhocLinkedFieldList, SqlDbType.Structured));
                cmd.Parameters[DbConstants.DbProcParamAdhocLinkedFieldList].Value = linkedFieldsTable;

                if (reportTemplateData.Id == -1)
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhocDMLType, 1);
                else
                {
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhocDMLType, 2);
                    cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhochPoolAdhocReportTemplateId, reportTemplateData.Id);
                }

                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhocReportTypeId, reportTemplateData.ReportTypeId);
                cmd.Parameters.Add(DbConstants.DbProcParamReturnValue, SqlDbType.Int);
                cmd.Parameters[DbConstants.DbProcParamReturnValue].Direction = ParameterDirection.Output;

                var rowsAffected = cmd.ExecuteNonQuery();

                result = Convert.ToInt32(cmd.Parameters[DbConstants.DbProcParamReturnValue].Value);
            }
            return result;
        }

        public IList<AdhocReportTypeEntity> GetAdhocReportTypeList(string LoggedInUserName)
        {
            IList<AdhocReportTypeEntity> ObjAdhocReportTypeEntityList = new List<AdhocReportTypeEntity>();

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GetAdhocReportType, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, LoggedInUserName);
                SqlDataReader resultReader;
                using (resultReader = cmd.ExecuteReader())
                {
                    if (resultReader.HasRows)
                    {
                        while (resultReader.Read())
                        {
                            ObjAdhocReportTypeEntityList.Add(new AdhocReportTypeEntity()
                            {
                                AdhocReportTypeId = Utility.GetInt(resultReader[DbConstants.DbTypeAdhocReportTypeId]),
                                ReportTypeName = Utility.GetString(resultReader[DbConstants.DbTypeAdhocReportTypeName]),
                                Description = Utility.GetString(resultReader[DbConstants.DbTypeAdhocReportTypeDescription])
                            });
                        }
                    }
                }
            }

            return ObjAdhocReportTypeEntityList;
        }

        #region Private Methods
        private MemoryStream GenerateReportDataCsv(int reportTemplateId, int poolId, string loggedInUserName, ReportTemplateData reportTemplateData)
        {
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GenerateReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhochPoolAdhocReportTemplateId, reportTemplateId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);
                SetLinkedFieldsParamValues(reportTemplateData, cmd);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var coutOfRows = 1;
                if (reader.HasRows)
                {
                    using (var stream = new MemoryStream())
                    using (StreamWriter sw = new StreamWriter(stream))
                    {
                        while (reader.Read())
                        {
                            if (coutOfRows == 1)
                            {
                                WriteHeaderForCsv(reader, sw);
                                coutOfRows++;
                            }
                            else
                            {
                                AddDataIntoCsv(reader, sw);
                            }
                        }
                        reader.Close();
                        return stream;
                    }
                }
            }
            return null;
        }

        private MemoryStream GenerateReportInExcel(int reportTemplateId, int poolId, string loggedInUserName, ReportTemplateData reportTemplateData)
        {
            List<int> AccountingFormatIndexes = new List<int>();
            string[] fieldAttributeList = GetAccountingFormatFields(loggedInUserName);

            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(DbConstants.SP_Adhoc_GenerateReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamPoolId, poolId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamAdhochPoolAdhocReportTemplateId, reportTemplateId);
                cmd.Parameters.AddWithValue(DbConstants.DbProcParamUserName, loggedInUserName);

                if (reportTemplateData != null)
                {cmd.Parameters.AddWithValue("@AssetClassID", reportTemplateData.AssetClassId);}
                else { cmd.Parameters.AddWithValue("@AssetClassID", 1); }

                SetLinkedFieldsParamValues(reportTemplateData, cmd);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                var workbook = new XLWorkbook();
                var worksheet = workbook.Worksheets.Add($"Pool Adhoc Report");
                var noOfColumns = 1;
                var noOfRows = 1;
                var currentSheet = 1;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (noOfRows > 1048576)
                        {
                            currentSheet++;
                            worksheet = workbook.Worksheets.Add($"Pool Adhoc Report_{currentSheet}");
                            noOfRows = 1;
                            noOfColumns = 1;
                        }
                        if (noOfRows == 1)
                        {
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                if (i == 0 || i == 1)
                                    continue;
                                else
                                {
                                    worksheet.Cell(noOfRows, noOfColumns).Value = reader.GetName(i);
                                    if (RequiresAccountingFormat(reader.GetName(i), fieldAttributeList))
                                    {
                                        AccountingFormatIndexes.Add(i);
                                    }
                                    noOfColumns++;
                                }
                            }

                            noOfRows++;
                            AddValuesToWorkSheet(reader, worksheet, noOfRows, AccountingFormatIndexes);
                            noOfRows++;
                        }
                        else
                        {
                            AddValuesToWorkSheet(reader, worksheet, noOfRows, AccountingFormatIndexes);
                            noOfRows++;
                        }
                    }


                    reader.Close();

                    using (var stream = new MemoryStream())
                    {
                        workbook.SaveAs(stream);
                        workbook.Dispose();
                        return stream;
                    }
                }
                else
                {
                    return new MemoryStream();
                }
            }
        }
        private BasicLookUpData GetBasicLookUpObj(SqlDataReader resultReader)
        {
            return new BasicLookUpData()
            {
                Value = Utility.GetInt(resultReader[DbConstants.DbFieldLookupDataValue]),
                Title = Utility.GetString(resultReader[DbConstants.DbFieldLookupDataTitle])
            };
        }

        private void SetLinkedFieldsParamValues(ReportTemplateData reportTemplateData, SqlCommand cmd)
        {
            var linkedFieldsTable = new DataTable();
            linkedFieldsTable.Columns.Add(DbConstants.DbTypeAdhochReportField_Id, typeof(Int32));
            linkedFieldsTable.Columns.Add(DbConstants.DbTypeAdhochReportField_OrderId, typeof(Int32));
            if (reportTemplateData != null)
            {
                foreach (var pLinkedField in reportTemplateData.ReportFields)
                {
                    linkedFieldsTable.Rows.Add(Convert.ToInt32(pLinkedField.Value), Convert.ToInt32(pLinkedField.FieldOrderId));
                }
                cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamAdhocLinkedFieldList, SqlDbType.Structured));
                cmd.Parameters[DbConstants.DbProcParamAdhocLinkedFieldList].Value = linkedFieldsTable;
            }
            else
            {
                cmd.Parameters.Add(new SqlParameter(DbConstants.DbProcParamAdhocLinkedFieldList, SqlDbType.Structured));
                cmd.Parameters[DbConstants.DbProcParamAdhocLinkedFieldList].Value = linkedFieldsTable;
            }
        }

        private void AddValuesToWorkSheet(SqlDataReader reader, IXLWorksheet worksheet, int noOfRows, List<int> accountingFormatIndexes)
        {
            var noOfFields = reader.FieldCount;
            for (int i = 2; i < noOfFields; i++)
            {
                if (checkForAccountingFormatIndex(accountingFormatIndexes, i))
                {
                    worksheet.Cell(noOfRows, i - 1).Value = $"{reader.GetValue(i)}";
                    worksheet.Cell(noOfRows, i - 1).Style.NumberFormat.Format = "#,###,##0";
                }
                else
                {
                    worksheet.Cell(noOfRows, i - 1).Value = reader.GetValue(i);
                }
            }
        }

        #region Accounting Format Helper Methods

        private string[] GetAccountingFormatFields(string pUserName)
        {

            List<ECFieldAttribute> ecFieldAttribute = GetECFieldAttributeList(pUserName);
            string[] strAttributeFields = new string[ecFieldAttribute.Count];

            for (int i = 0; i < ecFieldAttribute.Count; i++)
            {
                strAttributeFields[i] = ecFieldAttribute[i].FieldName;
            }

            return strAttributeFields;
        }

        private bool RequiresAccountingFormat(string columnName, string[] FieldList)
        {
            return FieldList.Contains(columnName);
        }

        private bool checkForAccountingFormatIndex(List<int> accountingFormatIndexes, int index)
        {
            return accountingFormatIndexes.Contains(index);
        }

        #endregion

        #region Csv Helper Methods        
        private void AddDataIntoCsv(SqlDataReader reader, StreamWriter sw)
        {
            var noOfFields = reader.FieldCount;
            string[] s = new string[noOfFields - 2];
            for (int i = 2; i < noOfFields; i++)
            {
                s[i - 2] = reader.GetValue(i).ToString();
            }
            sw.WriteLine(string.Join(",", s));
        }

        private void WriteHeaderForCsv(SqlDataReader reader, StreamWriter sw)
        {
            var noOfFields = reader.FieldCount;
            string[] s = new string[noOfFields - 2];
            for (int i = 2; i < noOfFields; i++)
            {
                s[i - 2] = reader.GetName(i);
            }
            sw.WriteLine(string.Join(",", s));
        }
        #endregion
        #endregion
    }

}
