﻿using Microsoft.Extensions.Options;
using NW.SFP.DataService.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using static NW.SFP.DataService.DbConstants;

namespace NW.SFP.DataService.PS
{
    public class ReplinesReportDataService : IReplinesReportDataService
    {

        private readonly IOptions<DataServiceSettings> _settings;

        public ReplinesReportDataService(IOptions<DataServiceSettings> settings)
        {
            this._settings = settings;
        }

        public ReplinseReportData GetReplinesReportData(DateTime inceptionDate, int dealKey, string userName)
        {
            var result = new ReplinseReportData();
            using (SqlConnection conn = new SqlConnection(_settings.Value.ConnectionString))
            using (SqlCommand cmd = new SqlCommand(SP_GenerateReplinesReport, conn))
            {
                conn.Open();
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue(DbProcParamAsAtDate, inceptionDate);
                cmd.Parameters.AddWithValue(DbProcParamDealId, dealKey);
                cmd.Parameters.AddWithValue(DbProcParamUserName, userName);
                cmd.CommandTimeout = 0;

                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.ReplinseReport.Add(new ReplinesReport()
                        {
                            InterestType = Utility.GetString(reader[DbProcParamInterestType]),
                            PaymentType = Utility.GetString(reader[DbProcParamPaymentType]),
                            SeasoningBucket = Utility.GetString(reader[DbProcParamSeasoningBucket]),
                            OriginalTermBucket = Utility.GetString(reader[DbProcParamOriginalTermBucket]),
                            MonthsToResetBucket = Utility.GetString(reader[DbProcParamMonthsToResetBucket]),
                            LTVBucket = Utility.GetString(reader[DbProcParamLTVBucket]),
                            TempIOPeriod = Utility.GetString(reader[DbProcParamTempIOPeriod]),
                            FloorOnTrackerRate = Utility.GetString(reader[DbProcParamFloorOnTrackerRate]),
                            CountOfLoanId = Utility.GetInt(reader[DbProcParamCountOfLoanId]),
                            CutOffBalance = Utility.GetDecimal(reader[DbProcParamCutOffBalance]),
                            OTermWAByBalance = Utility.GetDecimal(reader[DbProcParamOTermWAByBalance]),
                            SeasoningWAByBalance = Utility.GetDecimal(reader[DbProcParamSeasoningWAByBalance]),
                            CouponWAByBalance = Utility.GetDecimal(reader[DbProcParamCouponWAByBalance]),
                            MarginWAByBalance = Utility.GetDecimal(reader[DbProcParamMarginWAByBalance]),
                            TeaserDiscountWAByBalance = Utility.GetDecimal(reader[DbProcParamTeaserDiscountWAByBalance]),
                            MonthsToResetWAByBalance = Utility.GetDecimal(reader[DbProcParamMonthsToResetWAByBalance]),
                            IOWAByBalance = Utility.GetDecimal(reader[DbProcParamIOWAByBalance]),
                            MonOfTempIORevWAByBalance = Utility.GetDecimal(reader[DbProcParamMonOfTempIORevWAByBalance]),
                            PercOfBalanceInDefault = Utility.GetDecimal(reader[DbProcParamPercOfBalanceInDefault]),
                            PercOfBalanceInDelinquency = Utility.GetDecimal(reader[DbProcParamPercOfBalanceInDelinquency]),
                            TrackerFloorWAByBalance = Utility.GetDecimal(reader[DbProcParamTrackerFloorWAByBalance]),
                            CombinedLTV = Utility.GetDecimal(reader[DbProcParamCombinedLTV]),
                            CreditScoreWAByBalance = Utility.GetDecimal(reader[DbProcParamCreditScoreWAByBalance]),
                            MIWAByBalance = Utility.GetDecimal(reader[DbProcParamMIWAByBalance]),
                            PrimeWAByBalance = Utility.GetDecimal(reader[DbProcParamPrimeWAbyBal]),
                            UnVerifiedIncomeWAByBalance = Utility.GetDecimal(reader[DbProcParamUnVerifiedIncomeWAByBalance]),
                            SelfEmployedWAByBal = Utility.GetDecimal(reader[DbProcParamSelfEmployedWAByBal]),
                            BuyToLetWAByBalance = Utility.GetDecimal(reader[DbProcParamBuyToLetWAByBalance]),
                            PriorBankcruptcyWAByBalance = Utility.GetDecimal(reader[DbProcParamPriorBankcruptcyWAByBalance]),
                            FlexLoanWAByBalance = Utility.GetDecimal(reader[DbProcParamFlexLoanWAByBalance]),
                            SecondHomeWAByBalance = Utility.GetDecimal(reader[DbProcParamSecondHomeWAByBalance]),
                            FirstLienWAByBalance = Utility.GetDecimal(reader[DbProcParamFirstLienWAByBalance]),
                            ValuationAgeWAByBalance = Utility.GetDecimal(reader[DbProcParamValuationAgeWAByBalance])
                        });
                    }
                    return result;
                }
                return null;
            }
        }

    }

}