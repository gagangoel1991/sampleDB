﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class DataServiceSettings
    {
        public string ConnectionString { get; set; }

        public string LogLevel { get; set; }

        public string ErrorOriginType { get; set; }

        public string Environment { get; set; }
    }
}
