﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class UserAuthParams
    {
        public string UserName { get; set; }

        public string ADGroupName { get; set; }

        public string PermissionName { get; set; }

        public int AccessType { get; set; }
    }
}
