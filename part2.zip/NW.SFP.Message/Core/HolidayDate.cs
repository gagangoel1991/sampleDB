﻿namespace NW.SFP.Message.core
{
    public class HolidayDate
    {
        public string Date { get; set; }
        public bool IsUKHoliday { get; set; }
        public bool IsNIHoliday { get; set; }
        public bool IsROIHoliday { get; set; }

    }
}
