﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class LogInfoEntity : BaseEntity
    {
        public int ModuleId { get; set; }

        public string ActionPerformed { get; set; }

        public string LogDetail { get; set; }

    }


    public class LogErrorEntity : BaseEntity
    {
        public int ModuleId { get; set; }

        public string ErrorMethod { get; set; }

        public string ErrorMessage { get; set; }

        public int ErrorId { get; set; }
    }


}
