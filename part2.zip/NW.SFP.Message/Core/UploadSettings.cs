﻿namespace NW.SFP.Message.Core
{
    public class UploadSettings
    {
        public string UploadPath { get; set; }
        public string TemplatePath { get; set; }
        public string SharedPath { get; set; }
    }
}
