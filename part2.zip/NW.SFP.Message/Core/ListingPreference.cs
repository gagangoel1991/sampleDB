﻿using System.Collections.Generic;

namespace NW.SFP.Message.core
{
    public class ListingPreference
    {
        public string ListingPageName { get; set; }
        public IList<string> HiddenColumns { get; set; }
        public bool ListingPreferenceExists { get; set; }
        
        public ListingPreference()
        {
            HiddenColumns = new List<string>();
        }
    }
}
