﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class UserInfoEntity
    {
        public string UserName { get; set; }

        public string Racf { get; set; }

        public string Domain { get; set; }

        public IList<string> Groups { get; set; }

        public string AppRole { get; set; }

        public IDictionary<string, bool> AccessPermission { get; set; }

    }
}
