﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class ReportSettings
    {
        public string InvestorReportLocation { get; set; }
        public string DataOutputFolderPath { get; set; }
        public string SFPReportingFrameworkPath { get; set; }
    }
}
