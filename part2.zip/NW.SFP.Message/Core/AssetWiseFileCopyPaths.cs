﻿namespace NW.SFP.Message.Core
{
    public class AssetWiseFileCopyPaths
    {
        public string RT { get; set; }
        public string CL { get; set; }
        public string CC { get; set; }
        public string PL { get; set; }
        public string NWM { get; set; }
    }
}
