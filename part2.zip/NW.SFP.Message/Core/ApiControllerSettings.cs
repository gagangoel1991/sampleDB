﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class ApiControllerSettings
    {
        public string WebHostUrl { get; set; }
    }
}
