﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class CashWaterfallSettings
    {
        public string IrConfigFileLocation { get; set; }

        public string InvoiceFileLocation { get; set; }

        public string IrTemplateFileLocation { get; set; }

        public string IrParentWorksheet { get; set; }

        public string IRTargetFileLocation { get; set; }

        public string RatingsFileLocation { get; set; }

        public string RatingsTemplateFileLocation { get; set; }
        public string IrProtectSheetKey { get; set; }


        public string LiablityFeatureTemplateLocation { get; set; }

        public string ControlsPreStormVsSfpTemplateName { get; set; }

        public string Annex2DParentWorksheet { get; set; }
        public string MoodysParentWorksheet { get; set; }
        public string HTTParentWorksheets { get; set; }
        public string EsmaAnnex12ParentWorksheets { get; set; }
        public string EsmaAnnex14ParentWorksheets { get; set; }
        public string CBIrParentWorksheets { get; set; }

        public string CollectionHistoryFileName { get; set; }

        public string CollectionHistoryTemplateFileLocation { get; set; }
        public string RrConfigFileLocation { get; set; }
        public string RrTemplateFileLocation { get; set; }

        public string EmailTemplateFileLocation { get; set; }

        public string CBAnnex12SecWorksheets { get; set; }
        public string BookingReconTemplateFileLocation { get; set; }
        public string BookingReconFileName { get; set; }

        public string DeflagAdjustmentTemplateFileLocation { get; set; }
        public string DeflagAdjustmentFileName { get; set; }

    }
}