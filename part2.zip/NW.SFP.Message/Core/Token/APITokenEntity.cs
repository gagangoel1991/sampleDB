﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core.Token
{
    public class APITokenEntity
    {        
        public string Key { get; set; }
        public Guid? Token { get; set; }
        public string UserName { get; set; }
        public bool FromIsProcessRunning { get; set; }
        public bool ToIsProcessRunning { get; set; }
    }

   
}
