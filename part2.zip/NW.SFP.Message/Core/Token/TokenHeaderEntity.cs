﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core.Token
{
    public class TokenHeaderEntity
    {
        public static readonly string TokenInfoKeyName = "SfpHeaderToken";
        public string Key { get; set; }
        public Guid? Token { get; set; }
    }
}
