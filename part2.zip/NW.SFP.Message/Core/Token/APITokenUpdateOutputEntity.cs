﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core.Token
{
    public class APITokenUpdateOutputEntity
    {
        public bool IsTokenUpdated { get; set; }
        public Guid? UpdatedToken { get; set; }
        public bool IsProcessRunning { get; set; }
    }
}
