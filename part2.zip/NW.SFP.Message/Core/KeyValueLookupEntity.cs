﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Core
{
    public class KeyValueLookupEntity
    {
        public int LookupTypeId { get; set; }

        public int Key { get; set; }

        public string Value { get; set; }
    }
}
