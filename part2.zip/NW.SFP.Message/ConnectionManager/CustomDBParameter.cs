﻿using System.Data;

namespace NW.SFP.Message.ConnectionManager
{
    public class CustomDBParameter
    {
        public string parameterName { get; set; }
        public object parameterValue { get; set; }
        public ParameterDirection parameterDirection { get; set; }
        public DbType parameterDataType { get; set; }
        public int size { get; set; }
    }
}
