﻿

namespace NW.SFP.Message.ConnectionManager
{
    public enum SQLSource
    {
        SFPModel,
        SFPConfiguration,
        SFPStaging,
        SFPSecuritisation
    }
}
