﻿
namespace NW.SFP.Message.ConnectionManager
{
    public class DBConnectionSettings
    {
        public string ConnectionString_Securitisation { get; set; }
        public string ConnectionString_Model { get; set; }
        public string ConnectionString_Staging { get; set; }
        public string ConnectionString_Configuration { get; set; }
    }
}
