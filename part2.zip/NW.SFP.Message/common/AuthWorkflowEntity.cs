﻿using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using System;

namespace NW.SFP.Message.Common
{
    public class AuthWorkflowEntity : BaseEntity
    {
        public int WorkflowType { get; set; }

        public int WorkflowStep { get; set; }

        public int Status { get; set; }

        public string StepName { get; set; }

        public string StepDescription { get; set; }

        public string Comment { get; set; }

        public string ActionBy { get; set; }

        public DateTime? ActionDate { get; set; }

        public int ProcessId { get; set; }
    }

    public class AuthAuditEntity
    {
        public string CreatedBy { get; set; }
        public DateTime? CreatedDate { get; set; }
        public string ModifiedBy { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public string AuthorizedBy { get; set; }
        public DateTime? AuthorizedDate { get; set; }
    }
}
