﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;

namespace NW.SFP.Message.Common
{
    public class MultiSelectLookUp 
    {
        public IEnumerable<int> ListId { get; set; }
        public string AssetClassId { get; set; }
    }
}
