﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CB
{
    public class TestSummaryEntity : BaseEntity
    {
        public int TestTypeId { get; set; }

        public string InternalName { get; set; }

        public string DisplayName { get; set; }

        public string Result { get; set; }

        public string RouterLink { get; set; }

        public DateTime IpdDate { get; set; }

        public int DealIpdRunId { get; set; }
    }

    public class TestDataEntity : BaseEntity
    {
        public int? ParentTestLineItemId { get; set; }

        public int TestLineItemId { get; set; }

        public string InternalName { get; set; }

        public string DisplayName { get; set; }

        public string InternalTestLineItem { get; set; }

        public string LineItemValue { get; set; }

        public string[] LineItemValues { get; set; }

        public List<TestDataEntity> ChildLineItems { get; set; }

        public DateTime IpdDate { get; set; }

        public String UITabName { get; set; }

    }

}
