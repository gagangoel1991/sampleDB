﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CB
{
    public class SoniaCompoundingSummaryEntity : BaseEntity
    {  
        public string SwapName { get; set; }
        public DateTime IpdDate { get; set; }
        public DateTime CouponPeriodStart { get; set; }
        public DateTime CouponPeriodEnd { get; set; }
        public decimal Coupon { get; set; }
        public string GroupType { get; set; }
        public string CollectionEndDate { get; set; }
        public string CollectionStartDate { get; set; }

    }

}
