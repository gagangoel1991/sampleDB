﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NW.SFP.Message.CW
{
    public class DefalgAdjustmentEntity : BaseEntity
    {
        public int  PoolCashCollectionAdjustmentId { get; set; }
        public string AdjustmentProcessDate { get; set; }
        public int WorkFlowStatusId { get; set; }
        public string AuthorizerComment { get; set; }
    }
}
