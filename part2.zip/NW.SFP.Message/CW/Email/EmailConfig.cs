﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW.Email
{
    public class EmailConfigEntity : BaseEntity
    {
        public int EmailConfigId { get; set; }
        public int EmailTypeId { get; set; }
        public string EmailType { get; set; }
        public string InternalName { get; set; }
        public string DisplayName { get; set; }
        public string EmailFrom { get; set; } 
        public string EmailTo { get; set; }
        public string EmailCC { get; set; }
        public string EmailBCC { get; set; }
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }
        public bool EmailImportance { get; set; }
        public string EmailImportanceText { get; set; }
        public string EmailFormat { get; set; }
        public bool Attachment { get; set; }
        public string AttachmentText { get; set; }
        public bool IsActive { get; set; }
        public string ActiveStatus { get; set; }


}
}
