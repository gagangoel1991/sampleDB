﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
    public class DealCounterpartyEntity : BaseEntity
    {
        public int DealCounterpartyId { get; set; }

        public int DealId { get; set; }

        public string CisCode { get; set; }

        public string CounterpartyName { get; set; }

        public string Description { get; set; }

    }
}
