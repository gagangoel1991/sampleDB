﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
   public class DealNoteInfoEntity : BaseEntity
    {
        public int DealNoteId { get; set; }
        public int DealId { get; set; }

        public string Name { get; set; }

        public string ISIN { get; set; }

        public DateTime? ValidFrom { get; set; }

        public DateTime? ValidTo { get; set; }

        public DateTime? MaturityDate { get; set; }

        public DateTime? EarlyRedemptionDate { get; set; }

        public string AuthorizerComment { get; set; }

        public int DealStatusId { get; set; }

        public bool isActive { get; set; }

        public DateTime? EarlyRedemptionDateNextIpd { get; set; }

        public DateTime? FinalMaturityDate { get; set; }
    }
}
