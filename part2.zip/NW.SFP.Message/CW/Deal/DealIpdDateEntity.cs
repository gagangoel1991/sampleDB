﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
    class DealIpdDateEntity
    {
    }
}
