﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
    public class DealDateEntity
    {

    }

    /// <summary>
    /// This entity will be used for showing the deal IPD list
    /// </summary>
    public class DealIpdEntity
    {
        public int DealId { get; set; }

        public int DealName { get; set; }

        public string IpdDate { get; set; }
    }
}
