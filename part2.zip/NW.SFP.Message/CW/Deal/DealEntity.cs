﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;

namespace NW.SFP.Message.CW
{
    [Serializable]
    public class DealEntity : BaseEntity
    {
        public int DealId { get; set; }

        public string DealName { get; set; }

        public string DealPublicName { get; set; }

        public string InternalDealName { get; set; }

        public string Description { get; set; }

        public string OwnerName { get; set; }

        public string BusinessArea { get; set; }

        public string DealType { get; set; }

        public string DealStatus { get; set; }

        public string DealCurrency { get; set; }

        public string JurisdictionMarker { get; set; }

        public string DealAccountingType { get; set; }

        public short BusinessAreaId { get; set; }

        public short DealTypeId { get; set; }

        public short DealStatusId { get; set; }

        public DateTime ClosingDate { get; set; }

        public DateTime? DealMaturityDate { get; set; }

        public DateTime? FirstIpdDate { get; set; }

        public DateTime? CashCollectionStartDate { get; set; }

        public short? IpdFrequencyId { get; set; }

        public short DealCurrencyId { get; set; }

        public short JurisdictionMarkerId { get; set; }

        public short FurtherAdvancesAutoTopUpFlagId { get; set; }

        public short BalanceTransferAutoTopUpFlagId { get; set; }

        public short MortgageAutoTopUpFlagId { get; set; }

        public short DealAccountingTypeId { get; set; }

        public string AuthorizerComment { get; set; }

        public DateTime? EarlyRedemptionDate { get; set; }

        public bool IsActive { get; set; }

        public string WorkflowActionedBy { get; set; }

        public DateTime? WorkflowActionedDate { get; set; }

        public bool IsMinorAmendment { get; set; } = false;

        public bool IsCwDeal { get; set; }

        public string RedactedFacilityIds { get; set; }
		
		public int? CashReportingFlagId { get; set; }
        public string CashReporting { get; set; }
        public decimal? DealInitialSize { get; set; }
        public DateTime? TopupEndDate { get; set; }
        public int? TopupFlagId { get; set; }
        public string TopupFlag { get; set; }
        public decimal? RiskRetentionPercent { get; set; }
        public int? RiskRetentionMethodId { get; set; }
        public string RiskRetentionMethod { get; set; }
        public int? RiskRetentionHolderId { get; set; }
        public string RiskRetentionHolder { get; set; }
        public int? RonaCalculatedBasedOnId { get; set; }
        public DateTime? FxRateDate { get; set; }
        public int? FacilitySharingAllowedId { get; set; }
        public int? EnableHistoricFlaggingId { get; set; }
        public int? FacilityPercentChangeAllowedId { get; set; }
        public decimal? LegalRetentionPercent { get; set; }

        public List<DealSecurityItemsList> DealSecurityItemsList { get; set; }

        public string ReportingEntityContactTelephone { get; set; }
        public string ReportingEntityContactPerson { get; set; }
        public string ReportingEntityContactEmail { get; set; }
    }

    [Serializable]
    public class DealSecurityItemsList
    {
        public int PageLookUpValueMapId { get; set; }
        public int DealId { get; set; }
        public string Val { get; set; }
        public string Name { get; set; }
        public bool IsSelected { get; set; }
        public bool IsExcluded { get; set; }
        public int TypeId { get; set; }
        public int IsSaved { get; set; }
    }
}
