﻿using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
    public class PoolCashCollectionAdjustmentDataEntity
    {
        public int PoolCashCollectionAdjustmentId { get; set; }

        public string DealName { get; set; }

        public DateTime VintageDate { get; set; }

        public DateTime EffectiveDate { get; set; }

        public string PoolPurpose { get; set; }

        public int NoOfPool { get; set; }

        public string Brand { get; set; }

        public decimal Balance { get; set; }

        public decimal TotalPrincipalAdjustment { get; set; }

        public decimal TotalReceiptAdjustment { get; set; }

        public DateTime AdjustmentProcessedDate { get; set; }

        public string ProcessState { get; set; }

        public string Comment { get; set; }

        public string CreatedBy { get; set; }

        public DateTime CreatedDate { get; set; }

        public int WorkFlowStatusId { get; set; }

        public DateTime ModifiedDate { get; set; }

        public string ModifiedBy { get; set; }

        public int PoolId { get; set; }

        public string PoolName { get; set; }

        public decimal PrincipalAdjustment { get; set; }

        public decimal ReceiptAdjustment { get; set; }

        public int Account { get; set; }
        public double ActualRepurchase { get; set; }

        public double BalanceasOnLastPartitionDate { get; set; }

        public double PostAdjustmentRepurchase { get; set; }

    }

    public class PoolCashCollectionAdjustmentDataEntity1
    {
        public string DealName { get; set; }
        public int RepurchasePoolAdjustmentId { get; set; }

        public int PoolId { get; set; }

        public string PoolName { get; set; }

        public DateTime VintageDate { get; set; }
        public string PoolPurpose { get; set; }

        public int NoOfPool { get; set; }
        public string Brand { get; set; }

        public string Accounts { get; set; }

        public decimal Balance { get; set; }

        public decimal TotalPrincipalAdjustment { get; set; }

        public decimal TotalReceiptAdjustment { get; set; }

        public decimal PrincipalAdjustment { get; set; }

        public decimal ReceiptAdjustment { get; set; }

        public DateTime AdjustmentProcessedDate { get; set; }

        public int WorkFlowStatusId { get; set; }

        public DateTime CreatedDate { get; set; }

        public string CreatedBy { get; set; }
        public DateTime ModifiedDate { get; set; }
        public string ModifiedBy { get; set; }

    }
}
