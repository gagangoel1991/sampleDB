﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
   public class DealSummaryDataEntity
    {
        public int DealId { get; set; }
        public DateTime CollectionDate { get; set; }
        public string LineItem { get; set; }
        public string Value { get; set; }

        public string comments { get; set; }

        public int isSubLineItems { get; set; }

        public int DailyCollectionSummaryId { get; set; }

        public int DailyCollectionLineItemId { get; set; }

        public int ParentDailyCollectionLineItemId { get; set; }
        public string ModifiedBy { get; set; }

        public DateTime? ModifiedDate { get; set; }

        public int WorkFlowStepId { get; set; }

        public string DailyCollectionCategory { get; set; }

    }

   public class DealSummaryDataModel
    {
        public string[] adviceDate { get; set; }
        public string dealName { get; set; }

        public string dealCategoryName { get; set; }

        public string viewType { get; set; }

    }


    public class DealSummarySaveAdjustmentModel
    {
        public int DailyCollectionSummaryId { get; set; }

        public int DailyCollectionLineItemId { get; set; }

        public string Value { get; set; }

        public string Comments { get; set; }

        public string ModifiedBy { get; set; }

    }


    public class DealSummarySaveAuditModel
    {
        public int DailyCollectionSummaryId { get; set; }

        public int WorkFlowStepId { get; set; }

        public string Comments { get; set; }

    }

    public class DailyCollectionDealSummaryModel
    {
        public int  dailyCollectionSummaryId { get; set; }
        public DateTime collectionDate { get; set; }

        public int WorkflowStepId { get; set; }
        public string StepName { get; set; }
        public string ModifiedBy { get; set; }
        public string NextIpd { get; set; }
        public string PreviousIpd { get; set; }
        public string CollectionAdvicestartDate { get; set; }
        public string CollectionAdviceEndDate { get; set; }
        public string RateReset { get; set; }
        public string CurrentEuribor { get; set; }

        public DateTime DealSummaryMaxCollectionDate { get; set; }
        public int IsDeflagProcessed { get; set; }

        public double DFlagTotalAdjustmentToBeProcess { get; set; }



    }

    public class DailyCollectionDates
    {
        public List<DateTime> AdviceDates { get; set; }
        public List<DateTime> CollectionDates { get; set; }
    }

    public class DailyCollectionDatesExcel
    {
        public string dealName { get; set; }

        public DateTime? adviceDate { get; set; }
        public List<DateTime> AdviceDates { get; set; }
        public List<DateTime> CollectionDates { get; set; }

        public bool isMultiDateList { get; set; }

        public string viewType { get; set; }

    }

}
