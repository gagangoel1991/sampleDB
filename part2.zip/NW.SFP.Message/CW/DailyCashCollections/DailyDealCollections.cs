﻿using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
    public class DailyDealCollectionsDataEntity : BaseEntity
    {
        
    }
    public class DailyCollectionHistoryParam
    {
        public DateTime AsAtDate { get; set; }

        public DateTime AsAtToDate { get; set; }

        public string DealName { get; set; }

        public IEnumerable<string> BrandList { get; set; }
    }
}