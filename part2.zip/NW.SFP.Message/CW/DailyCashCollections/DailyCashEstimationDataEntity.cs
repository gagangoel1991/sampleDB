﻿using NW.SFP.Message.Core;
using System;

namespace NW.SFP.Message.CW
{
    public class DailyCashEstimationDataEntity : BaseEntity
    {
        public int IsParent { get; set; }
        
        public string EstimationType { get; set; }

        public string LineItem { get; set; }

        public DateTime CollectionDate { get; set; }

        public string BrandName { get; set; }

        public decimal? Principal { get; set; }

        public decimal? Revenue { get; set; }

        public decimal? Total { get; set; }
    }
}
