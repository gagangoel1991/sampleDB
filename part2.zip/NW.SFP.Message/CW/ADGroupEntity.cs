﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CW
{
    public class ADGroupEntity
    {
        public string GroupName { get; set; }
    }
}
