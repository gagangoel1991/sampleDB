﻿using System.Collections.Generic;

namespace NW.SFP.Message.PS
{
    public class LossesLookUp : BasicLookUpData
    {
       new public string Value { get; set; }
    }
}
