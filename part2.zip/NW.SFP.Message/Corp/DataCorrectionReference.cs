﻿using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.CB
{
    public class DataCorrectionReference
    {
        public List<BasicLookUpData> Deal { get; set; }
        public List<BasicLookUpData> Entity { get; set; }

        public DataCorrectionReference()
        {
            Deal = new List<BasicLookUpData>();
            Entity = new List<BasicLookUpData>();
        }
    }
}
