﻿using System;
using System.Collections.Generic;

namespace NW.SFP.Message.CB
{


    public class LossManagementList
    {
        public int? LossManagementId { get; set; }
        public string Deal { get; set; }
        public long FacilityId { get; set; }
        public string Source { get; set; }
        public string ReferenceEntityId { get; set; }
        public string SubSector { get; set; }
        public DateTime? FacilityStartDate { get; set; }
        public DateTime? MaturityDate { get; set; }
        public decimal? InitialRona { get; set; }
        public decimal? DefaultedNotional { get; set; }
        public decimal? FacilitySharePercent { get; set; }
        public string Originator { get; set; }
        public DateTime? CreditEventNoticeDate { get; set; }
        public DateTime? EvidenceSentDate { get; set; }
        public DateTime? CreditEventVerifiedDate { get; set; }
        public DateTime? WaterfallDateClaimed { get; set; }
        public DateTime? FxRateDate { get; set; }
        public DateTime? DefaultDate { get; set; }
        public int? CreditEventTypeId { get; set; }
        public decimal? ExposureAtDefault { get; set; }
        public decimal? CurrentExposure { get; set; }
        public decimal? InitialLossPercent { get; set; }
        public decimal? InitialLossAmount { get; set; }
        public decimal? FinalLossAmount { get; set; }
        public decimal? InitialVerifiedLossAmount { get; set; }
        public decimal? RealisedRecoveries { get; set; }
        public decimal? AdjustedRecoveries { get; set; }
        public decimal? FinalEstimatedRecoveries { get; set; }
        public decimal? TotalAdjustedRecoveries { get; set; }
        public decimal? TotalLossAmount { get; set; }
        public decimal? FinalWaterfallCalculationNumber { get; set; }
        public decimal? CreditLossEventAmount { get; set; }
        public decimal? RestructuredPrincipalAmount { get; set; }
        public DateTime? FinalVerificationDate { get; set; }
        public DateTime? WaterfallDate { get; set; }   
        public decimal? CurrentLimit { get; set; }
        public decimal? DrawnAmount { get; set; }
        public string MGS { get; set; }
        public DateTime? MGS27DefaultDate { get; set; }
        public decimal? AllocatedLoss { get; set; }
        public bool? IsAllocatedLossLoaded { get; set;  }
        public string? AccountStatus { get; set; }
        public int? Status { get; set; }
        public string Comments { get; set; }
        public string ModifiedBy { get; set; }
        public string LastAuditComment { get; set; }
        public DateTime? LastUpdateTimestamp { get; set; }
        public int? RecoverySource { get; set; }
        public string? DefaultReason { get; set; }
        public decimal? MGS27DefaultAmount { get; set; }
    }
}
