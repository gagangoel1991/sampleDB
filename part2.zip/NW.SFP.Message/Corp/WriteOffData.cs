﻿namespace NW.SFP.Message.CB
{
    public class WriteOffData
    {
        public int? Month;
        public int? Year;
        public string Description;
        public string FacilityId;
        public string CisCode;
        public string CC;
        public string CCY;
        public decimal? Amount;
        public string AssessmentType;
        public string Comments;
    }
}
