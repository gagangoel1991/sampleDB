﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NW.SFP.Message.Corp
{
    public class UpdateOverrideListEntity
    {
        public int DealId { get; set; }
        public String DealName { get; set; }
        public String Status { get; set; }
        public String OverrideBy { get; set; }
        public DateTime? OverrideDate { get; set; }
        public String AuthorisedBy { get; set; }
        public DateTime? AuthorisedDate { get; set; }
        public DateTime? CurrentOverrideVintageDate { get; set; }
        public DateTime? LastOverrideVintageDate { get; set; }
        public DateTime? LastAuthVintageDate { get; set; }
        public int DealOverrideParentId { get; set; }
        public int StatusId { get; set; }
        public String CreatedBy { get; set; }

        public String LastActionBy { get; set; }
        public DateTime? LastActionDate { get; set; }
        public int IsFacilityDownloadAvailable { get; set; }
        public int IsSecurityDownloadAvailable { get; set; }
        public int IsLinkagesAvailable { get; set; }
        public String OtherDraftAvailableMonth { get; set; }
    }

    public class FacilitySecurityLinkEntity
    {
        public int DealId { get; set; }
        public String FacilityId { get; set; }
        public String SecurityId { get; set; }
        public String SecurityKey { get; set; }
        public String ConnectionId { get; set; }
        public String CradleSecurityId { get; set; }
        public int IsLinked { get; set; }
        public int isListEdited { get; set; }
    }
}