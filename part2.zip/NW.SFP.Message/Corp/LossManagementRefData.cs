﻿using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;

namespace NW.SFP.Message.CB
{
    public class LossManagementRefData
    {
        public List<BasicLookUpData> LossStatusList { get; set; }
        public List<BasicLookUpData> StatusToListingList { get; set; }
        public List<BasicLookUpData> UnderReviewStatusDropdownList { get; set; }
        public List<BasicLookUpData> CreditEventTypeList { get; set; }

        public List<LossesLookUp> AccountStatusList { get; set; }

        public List<BasicLookUpData> RecoverySourceList { get; set; }

        public List<LossesLookUp> DefaultReasonList { get; set; }

        public LossManagementRefData()
        {
            LossStatusList = new List<BasicLookUpData>();
            StatusToListingList = new List<BasicLookUpData>();
            UnderReviewStatusDropdownList = new List<BasicLookUpData>();
            CreditEventTypeList = new List<BasicLookUpData>();
            AccountStatusList = new List<LossesLookUp>();
            RecoverySourceList = new List<BasicLookUpData>();
            DefaultReasonList = new List<LossesLookUp>();
        }
    }
}
