﻿using System;
using System.Collections.Generic;

namespace NW.SFP.Message.CB
{
    public class DataCorrectionDetail
    {   
        public DataCorrectionBasicInfo CorrectionBasicInfo { get; set; }
        public List<FacilityDataCorrectionList> FacilityCorrectedDataList { get; set; }
        public List<FacilityDataCorrectionList> FacilityOrigionalDataList { get; set; }
        public List<SecurityDataCorrectionList> SecurityCorrectedDataList { get; set; }
        public List<SecurityDataCorrectionList> SecurityOrigionalDataList { get; set; }
        public DataCorrectionDetail()
        {   
            CorrectionBasicInfo = new DataCorrectionBasicInfo();            
            FacilityCorrectedDataList = new List<FacilityDataCorrectionList>();
            FacilityOrigionalDataList = new List<FacilityDataCorrectionList>();
            SecurityCorrectedDataList = new List<SecurityDataCorrectionList>();
            SecurityOrigionalDataList = new List<SecurityDataCorrectionList>();
        }
    }
    public class CorrectionList<T> where T : class
    {
        public List<T> CorrectedList { get; set; }
        public List<T> OrigionalList { get; set; }
    }

    public class DataCorrectionBasicInfo
    {
        public int? CorrectionId { get; set; }
        public DateTime CorrectionDate { get; set; }
        public int? DealId { get; set; }
        public int? EntityId { get; set; }
        public string FsId { get; set; }
        public string CorrectedData { get; set; }
        public string Status { get; set; }

        public int? DealCorrectionStatusId { get; set; }
        public string CreatedBy { get; set; }
        public string AuthorizedBy { get; set; }
        public string AuthorizedDate { get; set; }
    }
    public class DataCorrectedKeyValue 
    {
        public int AttributeId { get; set; }
        public string Value { get; set; }
    }
    public class DataCorrectionAttribute
    {
        public int AttributeId { get; set; }
        public string AttributeName { get; set; }
        public string DisplayName { get; set; }
        public string EntityType { get; set; }
        public string DataType { get; set; }
        public bool IsEditable { get; set; }
        public bool IsChecked { get; set; }
        public bool IsHideAllowed { get; set; }
        public string FilterText { get; set; }

        public string StageDataType { get; set; }
        public int StageMaxAllowedDigits { get; set; }
        public int StageMaxprecision { get; set; }

    }
    public class FacilityDataCorrectionList
    {
        public long FacilityId { get; set; }
        public string SecurityId { get; set; }
        public decimal? FirstInterestMargin { get; set; }
        public decimal? InterestCharge { get; set; }
        public decimal? LtvOverride { get; set; }
        public decimal? DevelopmentLtcOverride { get; set; }
        public decimal? DevelopmentLtcValue { get; set; }
        public string FacilityTypeCode { get; set; }
        public string InterestBasis { get; set; }
        public string InterestBasisCode { get; set; }
        public string CostCentre { get; set; }
        public string FacilityCurrencyCode { get; set; }
        public string FacilitySourceCode { get; set; }
        public string CisCode { get; set; }
    }
    public class SecurityDataCorrectionList
    {
        public long SecurityId { get; set; }
        public string FacilityId { get; set; }
        public long ConnectionId { get; set; }
        public long CradleSecurityId { get; set; }        
        public string ValnSourceCode { get; set; }
        public decimal? GrossValueAmt { get; set; }
        public string PropertyNatureCode { get; set; }
        public string PropertyPostcode { get; set; }
        public string SecurityDescription { get; set; }
    }

    public class FacilitySecurityLink
    {
        public string dealId { get; set; }
        public string facilityId { get; set; }
        public string securityId { get; set; }
        public string cradleSecurityId { get; set; }
        public string connectionId { get; set; }
        public string securityKey { get; set; }
        public string isLinked { get; set; }
        public string isListEdited { get; set; }
    }
}
