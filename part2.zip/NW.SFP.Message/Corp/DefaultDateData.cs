﻿using System;
using System.Collections.Generic;

namespace NW.SFP.Message.CB
{

    public class DefaultDateData
    {
        public string Deal { get; set; }
        public long FacilityId { get; set; }
        public string Source { get; set; }
        public DateTime? DefaultDate { get; set; }
        public DateTime? FxRateDate { get; set; }
        public decimal? ExposureAtDefault { get; set; }
        public decimal? EADRestructured { get; set; }
        public decimal? CurrentExposure { get; set; }
        public decimal? CERestructured { get; set; }
        public decimal? InitialLossPercent { get; set; }
        public decimal? InitialLossAmount { get; set; }
        public decimal? InitialVerifiedLossAmount { get; set; }
        public decimal? DefaultedNotional { get; set; }
        public decimal? FacilitySharePercent { get; set; }

    }
}
