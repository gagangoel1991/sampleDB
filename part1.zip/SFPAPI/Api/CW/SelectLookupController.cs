﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using Microsoft.AspNetCore.Cors;
using SFPAPI.Api;
using NW.SFP.Message;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Common;
using System.IO;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Options;
using System.Net.Http;
using NW.SFP.DataService.Core;
using DocumentFormat.OpenXml.Drawing.Charts;
using System.Data;
using NW.SFP.Message.Common;

namespace NW.SFP.API.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/selectLookup")]
    public class SelectLookupController : SFPControllerBase
    {

        #region Variables  declaration and Construction

        private readonly ISelectLookupService _SelectLookupService;
        private readonly ILoggerService _loggerService;


        public SelectLookupController(ISelectLookupService SelectLookupService, ILoggerService loggerService)
        {
            this._SelectLookupService = SelectLookupService;
            this._loggerService = loggerService;
        }
        #endregion

        #region Action Methods

        [HttpPost]
        public ActionResult GetSelectLookup(MultiSelectLookUp MultiSelectModel)
        {
            try
            {
                var selectList = _SelectLookupService.GetParametrizedSelectList(Utils.SetSelectListTableValues(MultiSelectModel.ListId), MultiSelectModel.AssetClassId);
                return Ok(selectList);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "SelectLookupController.GetSelectLookup", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [HttpPut("GetSelectLookupDealName")]
        public ActionResult GetSelectLookupDealName(IEnumerable<int> FilterId)
        {
            try
            {
                string DealNameListId = "1";
                var intList = DealNameListId.Select(x => Convert.ToInt32(x.ToString())).ToList();
                var selectList = _SelectLookupService.GetParametrizedSelectListFilterBased(Utils.SetSelectListTableValues(intList), Utils.SetSelectListTableValues(FilterId));
                return Ok(selectList);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "SelectLookupController.GetSelectLookupFilterBased", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }



        [HttpGet("selectList/{listId}")]
        public ActionResult GetSelectLookup(string ListId)
        {
            try
            {

                var intList = ListId.Select(x => Convert.ToInt32(x.ToString())).ToList();
                var selectList = _SelectLookupService.GetParametrizedSelectList(Utils.SetSelectListTableValues(intList));
                return Ok(selectList);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "SelectLookupController.GetSelectLookup", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }
        #endregion

    }
}