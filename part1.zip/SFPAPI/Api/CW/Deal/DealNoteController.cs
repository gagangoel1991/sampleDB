﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Common;
using SFPAPI.Api;

namespace NW.SFP.API.Api
{

    [ApiController]
    [Produces("application/json")]
    [Route("api/dealNote")]
    [Authorize]
    public class DealNoteController : SFPControllerBase
    {

        #region Variables  declaration and Construction

        private readonly ILoggerService _loggerService;
        private readonly IDealNoteService _dealNoteService;

        public DealNoteController(IDealNoteService dealNoteService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._dealNoteService = dealNoteService;
        }
        #endregion



        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("getDealNoteList/{dealId}")]
        public IList<DealNoteInfoEntity> GetDealNoteList(int dealId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            return this._dealNoteService.GetDealNoteList(feedParms,LoggedInUserName);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("saveDealNoteInformationData")]
        public int SaveDealNoteInformationData(DealNoteInfoEntity dealNoteInfoEntity)
        {
            dealNoteInfoEntity.UserName = LoggedInUserName;
            return this._dealNoteService.SaveDealNoteData(dealNoteInfoEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.ApproveReject)]
        [HttpPost("manageDealNoteAuthWorkflow")]
        public int ManageDealNoteAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealNoteService.ManageDealNoteAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("manageDealNoteAuthWorkflowByUser")]
        public int ManageDealNoteAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealNoteService.ManageDealNoteAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("dealNoteSentforAuthorization")]
        public int DealNoteSentforAuthorization(DealNoteInfoEntity dealNoteInfoEntity)
        {
            dealNoteInfoEntity.UserName = LoggedInUserName;
            return this._dealNoteService.DealNoteSentforAuthorization(dealNoteInfoEntity);
        }
    }
}
