﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;

namespace SFPAPI.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/dealcounterparty")]
    [Authorize]
    public class DealCounterpartyController : SFPControllerBase, IDealCounterpartyController
    {
        #region Variables  declaration and Construction

        private readonly IDealCounterpartyService _dealCounterpartyService;

        public DealCounterpartyController(IDealCounterpartyService dealCounterpartyService)
        {
            this._dealCounterpartyService = dealCounterpartyService;
        }
        #endregion

        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("getdealcp")]
        public IList<DealCounterpartyEntity> GetDealCounterparty(int dealId)
        {
            return this._dealCounterpartyService.GetDealCounterparty(dealId, LoggedInUserName);
        }
    }
}
