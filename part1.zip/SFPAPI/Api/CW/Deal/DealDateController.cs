﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;

namespace SFPAPI.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/dealdate")]
    [Authorize]
    public class DealDateController : SFPControllerBase, IDealDateController
    {
        #region Variables  declaration and Construction
        private readonly IDealDateService _dealDateService;

        public DealDateController(IDealDateService dealDateService)
        {
            this._dealDateService = dealDateService;
        }
        #endregion

        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("dealnextipd")]
        public IList<DealIpdEntity> GetDealNextIpd(int dealId)
        {
            return this._dealDateService.GetDealNextIpd(dealId, LoggedInUserName);
        }
    }
}
