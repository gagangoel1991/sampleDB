﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Common;

namespace SFPAPI.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/deal")]
    [Authorize]
    public class DealController : SFPControllerBase, IDealController
    {
        #region Variables  declaration and Construction

        private readonly IDealService _dealService;

        public DealController(IDealService dealService)
        {
            this._dealService = dealService;
        }
        #endregion

        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("getdeallist/{assetClassId}")]
        public IList<DealEntity> GetDealList(int assetClassId)
        {
            return this._dealService.GetDealList(LoggedInUserName, assetClassId);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("saveDeal/{AssetClassId}")]
        public int SaveDeal(DealEntity dealEntity, int assetClassId)
        {
            dealEntity.UserName = LoggedInUserName;
            return this._dealService.SaveDeal(dealEntity, assetClassId);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("getDeal/{dealId}")]
        public IActionResult GetDeal(int dealId)
        {
            var entity = this._dealService.GetDeal(dealId, LoggedInUserName);
            if (object.Equals(entity, null))
            {
                return NotFound();
            }
            else
            {
                return Ok(entity);
            }
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpGet("delete/{dealId}")]
        public IActionResult DeleteDeal(int dealId)
        {
            var entity = this._dealService.DeleteDeal(dealId, LoggedInUserName);
            return Ok(entity);
        }
		[SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("manageDealAuthWorkflowByUser")]
        public int ManageDealAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealService.ManageDealAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.ApproveReject)]
        [HttpPost("manageDealAuthWorkflow")]
        public int ManageDealAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealService.ManageDealAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("dealCollapseSentforAuthorization")]
        public int DealCollapseSentforAuthorization(DealEntity dealEntity)
        {
            dealEntity.UserName = LoggedInUserName;
            return this._dealService.DealCollapseSentforAuthorization(dealEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpGet("getValidateDealForCollapse/{dealId}")]
        public int ValidateDealForCollapse(int dealId)
        {
            
            return this._dealService.GetValidateCollapseDeal(dealId, LoggedInUserName);
        }


        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpGet("getDealLatestAuthorisedIpdDate/{dealId}")]
        public string GetDealLatestAuthorisedIpdDate(int dealId)
        {

            return this._dealService.GetDealLatestAuthorisedIpdDate(dealId, LoggedInUserName);
        }


        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpGet("getDealSecurityListItems/{dealId}")]
        public List<DealSecurityItemsList> getDealSecurityListItems(int dealId)
        {

            return this._dealService.getDealSecurityListItems(dealId, LoggedInUserName);
        }
    }
}
