﻿namespace NW.SFP.API.CW
{
    using ClosedXML.Excel;
    using global::SFPAPI.Api;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using NW.SFP.API.Core.Auth;
    using NW.SFP.API.Core.Constants;
    using NW.SFP.BusinessService.CW;
    using NW.SFP.Interface;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.Common;
    using NW.SFP.Message.Core;
    using NW.SFP.Message.CW;
    using NW.SFP.Message.CW.IR;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    [ApiController]
    [Produces("application/json")]
    [Route("api/adhoc/dataload/")]
    [Authorize]
    public class DataLoadController : SFPControllerBase
    {

        #region Variables  declaration and Construction
        private readonly IDataLoadService _loadDataService;

        private readonly ILoggerService _loggerService;





        public DataLoadController(IDataLoadService _loadDataService, ILoggerService loggerService)
        {
            this._loadDataService = _loadDataService;
            this._loggerService = loggerService;

        }
        #endregion






        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("monthlyBatch")]
        public ActionResult ProcessDataLoad(string loadType, string asAtDate)
        {
            try
            {
                var isLoaded = _loadDataService.ProcessDataLoad(loadType, asAtDate, LoggedInUserName);
                return Ok(isLoaded);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DataLoadController.monthlyBatch", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }

        }


        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("loaddates")]
        public ActionResult GetDataLoadDates()
        {
            try
            {

                return Ok(_loadDataService.GetDataLoadDates());

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DataLoadController.monthlyBatch", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }

        }

    }
}
