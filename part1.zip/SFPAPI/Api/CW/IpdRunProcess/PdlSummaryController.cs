﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Data;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/pdlSummary")]
    [Authorize]
    public class PdlSummaryController : SFPControllerBase, IPdlSummaryController
    {

        private readonly ILoggerService _loggerService;
        private readonly IPdlSummaryService _pdlSummaryService;

        public PdlSummaryController(IPdlSummaryService pdlSummaryService, ILoggerService loggerService)
        {
            _loggerService = loggerService;
            _pdlSummaryService = pdlSummaryService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("Get/{dealId}/{ipdRunId}")]
        public DataTable GetPDLSummaryData(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;

                var dt = _pdlSummaryService.GetPDLSummaryData(feedParms);              

                return dt;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "PdlSummaryController" };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }
    }
}
