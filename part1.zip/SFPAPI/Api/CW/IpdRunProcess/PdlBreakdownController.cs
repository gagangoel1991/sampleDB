﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/pdlBreakdown")]
    [Authorize]
    public class PdlBreakdownController : SFPControllerBase, IPdlBreakdownController
    {
        private readonly IPdlBreakdownService _pdlBreakDownService;

        public PdlBreakdownController(IPdlBreakdownService pdlBreakDownService)
        {
            this._pdlBreakDownService = pdlBreakDownService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getPdlBreakdownData/{dealId}/{ipdRunId}")]
        public List<PdlBreakdownEntity> GetPDLBreakdownData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _pdlBreakDownService.GetPDLBreakdownData(feedParms);
        }
    }
}
