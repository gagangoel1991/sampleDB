﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW
{

    [ApiController]
    [Produces("application/json")]
    [Route("api/adjustment")]
    [Authorize]
    public class AdjustmentWaterfallController : SFPControllerBase
    {
        #region Variables  declaration and Construction

        private readonly ILoggerService _loggerService;
        private readonly IAdjustmentWaterfallService _adjustmentWaterfallService;

        public AdjustmentWaterfallController(IAdjustmentWaterfallService adjustmentPrincipalWaterfallService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._adjustmentWaterfallService = adjustmentPrincipalWaterfallService;
        }
        #endregion

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("waterfall/{dealId}/{ipdRunId}/{waterfallCategoryName}")]
        public ActionResult GetPrincipalWaterfall(int dealId, int ipdRunId, string waterfallCategoryName)
        {
            try
            {
                IPDFeedParam ipdFeedParam = new IPDFeedParam();
                ipdFeedParam.DealId = dealId;
                ipdFeedParam.IPDRunId = ipdRunId;
                ipdFeedParam.WaterfallCategoryName = waterfallCategoryName;
                ipdFeedParam.UserName = LoggedInUserName;
                var data = _adjustmentWaterfallService.GetAdjustmentWaterfallData(ipdFeedParam);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "AdjustmentWaterfalltController.GetPrincipalWaterfall", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("savePrincipalWaterfall")]
        public int SaveAdjustmentPrincipalWaterfall(IEnumerable<AdjustmentWaterfallEntity> adjustmentPrincipalWaterfallEntity)
        {
            try
            {
                foreach (var item in adjustmentPrincipalWaterfallEntity)
                {
                    if (item.IsAdjustmentReset)
                    {
                        item.ModifiedBy = null;
                        item.ModifiedDate = null;
                    }
                    else if (item.IsAdjustmentEdited)
                    {
                        item.ModifiedBy = LoggedInUserName;
                        item.ModifiedDate = DateTime.Now;
                    }
                }
                return _adjustmentWaterfallService.SavePrincipalWaterfall(adjustmentPrincipalWaterfallEntity, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "AdjustmentWaterfalltController.savePrincipalWaterfall", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getPrincipalWaterfallOutput/{dealId}/{ipdRunId}")]
        public ActionResult GetPrincipalWaterfallOutput(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam ipdFeedParam = new IPDFeedParam();
                ipdFeedParam.DealId = dealId;
                ipdFeedParam.IPDRunId = ipdRunId;
                ipdFeedParam.UserName = LoggedInUserName;
                var data = _adjustmentWaterfallService.GetAdjustmentPppOutputData(ipdFeedParam);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "AdjustmentWaterfalltController.GetPrincipalWaterfalloutput", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getRvenueWaterfallOutput/{dealId}/{ipdRunId}")]
        public ActionResult GetRevenueWaterfallOutput(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam ipdFeedParam = new IPDFeedParam();
                ipdFeedParam.DealId = dealId;
                ipdFeedParam.IPDRunId = ipdRunId;
                ipdFeedParam.UserName = LoggedInUserName;
                var data = _adjustmentWaterfallService.GetAdjustmentRppOutputData(ipdFeedParam);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "AdjustmentWaterfalltController.GetRevenueWaterfallOutput", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }
    }
}
