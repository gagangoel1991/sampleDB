﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;


namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/interestRate")]
    [Authorize] 
    public class InterestRateController : SFPControllerBase, IInterestRateController
    {
        private readonly IInterestRateService _interestRateService;

        public InterestRateController(IInterestRateService interestRateService)
        {
            _interestRateService = interestRateService;
        }

        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.View)]
        [HttpGet("getInterestRateData/{dealId}/{ipdRunId}")]
        public InterestRate GetInterestRateData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _interestRateService.GetInterestRateData(feedParms);
        }

        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.AddEdit)]
        [HttpPost("saveInterestRate")]
        public int SaveInterestRate(InterestRateEntity interestRateEntity)
        {

            return _interestRateService.SaveInterestRate(interestRateEntity, LoggedInUserName);
        }
    }
}
