﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/reserve")]
    [Authorize]
    public class ReserveController : SFPControllerBase, IReserveController
    {
        private readonly IReserveService _reserveService;

        public ReserveController(IReserveService reserveService)
        {
            this._reserveService = reserveService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getReserveData/{dealId}/{ipdRunId}")]
        public List<ReserveEntity> GetReserve(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveService.GetReserve(feedParms);
        }
    }
}
