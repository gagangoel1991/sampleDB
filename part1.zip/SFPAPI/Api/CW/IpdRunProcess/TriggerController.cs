﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW
{
    [Route("api/triggers")]
    [ApiController]
    [Produces("application/json")]
    [Authorize]
    public class TriggerController : SFPControllerBase, ITriggerController
    {
        private readonly ITriggerService _triggerService;

        public TriggerController(ITriggerService triggerService)
        {
            this._triggerService = triggerService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getRatingTriggers/{dealId}/{ipdRunId}")]
        public List<RatingTriggerEntity> GetRatingTriggers(int dealId, int ipdRunId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _triggerService.GetRatingTriggers(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getNonRatingTriggers/{dealId}/{ipdRunId}")]
        public List<NonRatingTriggerEntity> GetNonRatingTriggers(int dealId, int ipdRunId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _triggerService.GetNonRatingTriggers(feedParms);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("saveNonRatingTrigger")]
        public int SaveNonRatingTrigger(NonRatingTriggerEntity nonRatingTriggerEntity)
        {
               if (nonRatingTriggerEntity.IsAdjustmentReset)
                {
                nonRatingTriggerEntity.ModifiedBy = null;
                nonRatingTriggerEntity.ModifiedDate = null;
                }
                else if (nonRatingTriggerEntity.IsAdjustmentEdited)
                {
                nonRatingTriggerEntity.ModifiedBy = LoggedInUserName;
                nonRatingTriggerEntity.ModifiedDate = DateTime.Now;
                }
            
            nonRatingTriggerEntity.UserName = LoggedInUserName;
            return _triggerService.SaveNonRatingTrigger(nonRatingTriggerEntity);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("resetNontRatingTrigger/{dealId}/{ipdRunId}")]
        public int ResetNontRatingTrigger(int dealId, int ipdRunId)
        {
            //  nonRatingTriggerEntity.UserName = LoggedInUserName;
            return _triggerService.ResetNontRatingTrigger(dealId, ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("resetTriggersConditions/{ipdRunId}")]
        public int ResetTriggersConditions(int ipdRunId)
        {
            //  nonRatingTriggerEntity.UserName = LoggedInUserName;
            return _triggerService.ResetTriggersConditions(ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getSwapRatingTriggers/{dealId}/{ipdRunId}")]
        public List<RatingTriggerEntity> GetSwapRatingTriggers(int dealId, int ipdRunId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _triggerService.GetSwapRatingTriggers(feedParms);
        }
    }
}
