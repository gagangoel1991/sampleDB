﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Common;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{

    [Produces("application/json")]
    [Authorize]
    [Route("api/upstreamDataAuthWorkflow")]
    [ApiController]
    public class UpstreamDataAuthWorkflowController : SFPControllerBase, IUpstreamDataAuthWorkflowController
    {
        private readonly IUpstreamDataAuthWorkflowService _upstreamDataAuthWorkflowService;

        public UpstreamDataAuthWorkflowController(IUpstreamDataAuthWorkflowService upstreamDataAuthWorkflowService)
        {
            this._upstreamDataAuthWorkflowService = upstreamDataAuthWorkflowService;
        }


        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.View)]
        [HttpPost("getUpstreamDataAuthWorkflowStatus")]
        public IPDFeedParam GetUpstreamDataAuthWorkflowStatus(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._upstreamDataAuthWorkflowService.GetUpstreamDataAuthWorkflowStatus(authWorkflowEntity);
        }

        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.ApproveReject)]
        [HttpPost("manageUpstreamDataAuthWorkflow")]
        public int ManageUpstreamDataAuthWorkflow(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._upstreamDataAuthWorkflowService.ManageUpstreamDataAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.AddEdit)]
        [HttpPost("manageUpstreamDataAuthWorkflowByUser")]
        public int ManageUpstreamDataAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._upstreamDataAuthWorkflowService.ManageUpstreamDataAuthWorkflow(authWorkflowEntity);
        }
    }
}
