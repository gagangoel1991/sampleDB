﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.ApiController;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/cashladder")]
    [Authorize]
    public class CashLadderController : SFPControllerBase, ICashLadderController
    {
        #region Variables  declaration and Construction

        private readonly ICashLadderService _cashLadderService;

        public CashLadderController(ICashLadderService cashLadderService)
        {
            this._cashLadderService = cashLadderService;
        }
        #endregion

        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.View)]
        [HttpGet("getCashLadderData/{dealId}/{ipdRunId}")]
        public CashLadder GetCashLadderData(int dealId, int ipdRunId)
        {
            IPDFeedParam cashLadderParams = new IPDFeedParam();
            cashLadderParams.DealId = dealId;
            cashLadderParams.IPDRunId = ipdRunId;
            cashLadderParams.UserName = LoggedInUserName;
            cashLadderParams.UserName = LoggedInUserName;
            return _cashLadderService.GetCashLadderData(cashLadderParams);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpPost("saveCashLadderData")]
        public int SaveCashLadderData([FromBody] UpdateCashLadderEntity objUpdateCashLadderEntity)
        {
           
            return this._cashLadderService.SaveCashLadderData(objUpdateCashLadderEntity, LoggedInUserName);
        }
    }
}
