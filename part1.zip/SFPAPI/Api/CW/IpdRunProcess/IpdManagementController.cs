﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.BusinessService.CW;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.Core;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace NW.SFP.API.Api.CW.Dashboard
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/cashwaterfall/ipdmgmt")]
    [Authorize]
    public class IpdManagementController : SFPControllerBase
    {

        #region Variables  declaration and Construction

        private readonly ILoggerService _loggerService;
        private readonly IIpdManagementService _ipdManagementService;

        public IpdManagementController(IIpdManagementService ipdManagementService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._ipdManagementService = ipdManagementService;
        }
        #endregion

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("dashboarddata")]
        public ActionResult GetIpdMgmtDashboardData()
        {
            try
            {
                
                var data = _ipdManagementService.GetIpdMgmtDashboardData(LoggedInUserName);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "AdjustmentWaterfalltController.GetPrincipalWaterfall", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }



        }


    }
}
