﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [Route("api/triggers")]
    [ApiController]
    [Produces("application/json")]
    [Authorize]

    public class DealConditionTestController : SFPControllerBase, IDealConditionTestController
    {
        private readonly IDealConditionTestService _dealConditionTestService;

        public DealConditionTestController(IDealConditionTestService dealConditionTestService)
        {
            this._dealConditionTestService = dealConditionTestService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getTriggersConditions/{dealId}/{ipdRunId}")]
        public List<DealConditionTestEntity> GetDealConditionTestData(int dealId, int ipdRunId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _dealConditionTestService.GetDealConditionTestData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("saveTriggersConditions")]
        public int SaveTriggersConditions(DealConditionTestEntity dealConditionTestEntity)
        {
            return _dealConditionTestService.SaveDealConditionTestData(dealConditionTestEntity, LoggedInUserName);
        }
    }
}
