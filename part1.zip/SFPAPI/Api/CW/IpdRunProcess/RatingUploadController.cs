﻿using System.Collections.Generic;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.ApiController;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.IpdRunProcess;
using SFPAPI.Api;
using Microsoft.AspNetCore.Authorization;
using System;
using System.IO;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Options;
using Microsoft.AspNetCore.Http;
using System.Net.Http;
using System.Net;
using System.Data;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/RatingUpload")]
    [Authorize]
    public class RatingUploadController : SFPControllerBase, IRatingUploadController
    {
        private readonly ILoggerService _loggerService;
        private readonly IRatingUploadService _ratingUploadService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        public RatingUploadController(IRatingUploadService ratingUploadService, ILoggerService loggerService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._loggerService = loggerService;
            this._ratingUploadService = ratingUploadService;
            this._cwSettings = cwSettings;
        }

        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpGet("GetDealIpdDates")]
        public IList<DealIpdDateEntity> GetDealIpdDates()
        {
            return this._ratingUploadService.GetDealIpdDates();
        }

        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpGet("GetRatingListingData")]
        public IList<RatingListingData> GetRatingListingData()
        {
            return this._ratingUploadService.GetRatingListingData();
        }


        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpGet("GetUserRatingSavedData/{userRatingFileUploadDetailId}")]
        public RatingSavedData GetUserRatingSavedData(int userRatingFileUploadDetailId)
        {
            return this._ratingUploadService.GetUserRatingSavedData(userRatingFileUploadDetailId);
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("parseRatingFile")]
        public RatingFileParsedResult ParseRatingFile([FromForm] RatingFileUpload ObjRatingFileUpload)
        {
            RatingFileParsedResult parsedResult = new RatingFileParsedResult();
            try
            {
                IFormFileCollection files = HttpContext.Request.Form.Files;

                if (files.Count == 1)
                {
                    if (files[0].Length > 1)
                    {

                        parsedResult = _ratingUploadService.ParseRatingFile(files[0], ObjRatingFileUpload.DealId);
                    }

                    else
                    {
                        parsedResult.ErrorMessage = "File length must be greater than 0 bytes.";
                    }
                }
                else
                {
                    parsedResult.ErrorMessage = "More than 1 file are not allowed.";
                }

                return parsedResult;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity()
                {
                    ErrorMessage = ex.Message,
                    ErrorMethod = "RatingUploadController.ProcessRating",
                    ModuleId = (int)AppModule.Cashwaterfall,
                    UserName = LoggedInUserName
                };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpPost("saveRating")]
        public int SaveRatingFile([FromForm] RatingFileUpload ObjRatingFileUpload)
        {
            RatingFileParsedResult parsedResult = new RatingFileParsedResult();

            try
            {
                IFormFileCollection files = HttpContext.Request.Form.Files;

                if (files.Count == 1)
                {
                    if (files[0].Length > 1)
                    {
                        ObjRatingFileUpload.UploadedBy = LoggedInUserName;
                        _ratingUploadService.SaveUserRatingData(files[0], ObjRatingFileUpload);

                    }
                    else
                    {
                        parsedResult.ErrorMessage = "File length must be greater than 0 bytes.";
                    }
                }
                else
                {
                    parsedResult.ErrorMessage = "More than 1 file are not allowed.";
                }

                return 1;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity()
                {
                    ErrorMessage = ex.Message,
                    ErrorMethod = "RatingUploadController.ProcessRating",
                    ModuleId = (int)AppModule.Cashwaterfall,
                    UserName = LoggedInUserName
                };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }



        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpGet("DownloadRatingFile/{OriginalFileName}/{UploadedFileName}")]
        public string DownloadRatingFile(string OriginalFileName, String UploadedFileName)
        {
          
            try
            {                
                byte[] bytes = System.IO.File.ReadAllBytes(Path.Combine(_cwSettings.Value.RatingsFileLocation, UploadedFileName));
                return Convert.ToBase64String(bytes);               
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity()
                {
                    ErrorMessage = ex.Message,
                    ErrorMethod = "RatingUploadController.ProcessRating",
                    ModuleId = (int)AppModule.Cashwaterfall,
                    UserName = LoggedInUserName
                };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }
        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpPost("UploadRatingDataRecordExist")]
        public bool UploadRatingDataRecordExist([FromForm] RatingFileUpload ObjRatingFileUpload)
        {
            return _ratingUploadService.UploadRatingDataRecordExist(ObjRatingFileUpload);
        }

        [SFPAuthorize("CW_RatingUpload", PermissionAccessType.AddEdit)]
        [HttpDelete("delete/{UserRatingFileUploadDetailId}")]
        public int DeleteRatingData(int UserRatingFileUploadDetailId)
        {
            return _ratingUploadService.DeleteRatingData(UserRatingFileUploadDetailId, LoggedInUserName);
        }

        
        [HttpGet("DownloadRatingSampleFile")]
        public IActionResult DownloadRatingSampleFile()
        {
            try
            {

                string templateFilePath = Path.Combine(_cwSettings.Value.RatingsTemplateFileLocation);
                var fileStream = new FileStream(_cwSettings.Value.RatingsTemplateFileLocation, FileMode.Open);

                return File(fileStream, "application/octet-stream");
            }
            catch (FileNotFoundException e)
            {
                return new NoContentResult();
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "RatingUploadController.DownloadRatingSampleFile", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

    }
}
