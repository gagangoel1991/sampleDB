﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{
    [Produces("application/json")]
    [Authorize]
    [Route("api/ipdAuthWorkflow")]
    [ApiController]
    public class IpdAuthWorkflowController : SFPControllerBase, IIpdAuthWorkflowController
    {

        private readonly IIpdAuthWorkflowService _ipdAuthWorkflowService;

        public IpdAuthWorkflowController(IIpdAuthWorkflowService ipdAuthWorkflowService)
        {
            this._ipdAuthWorkflowService = ipdAuthWorkflowService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("getIpdAuthWorkflowStatus")]
        public IpdWorkflowEntity GetIpdAuthWorkflowStatus(IpdWorkflowEntity ipdWorkflowEntity)
        {
            ipdWorkflowEntity.UserName = LoggedInUserName;
            return _ipdAuthWorkflowService.GetIpdAuthWorkflowStatus(ipdWorkflowEntity);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.ApproveReject)]
        [HttpPost("manageIpdAuthWorkflow")]
        public int ManageIpdAuthWorkflow(IpdWorkflowEntity ipdWorkflowEntity)
        {
            ipdWorkflowEntity.UserName = LoggedInUserName;
            return _ipdAuthWorkflowService.ManageIpdAuthWorkflow(ipdWorkflowEntity);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpPost("manageIpdAuthWorkflowByUser")]
        public int ManageIpdAuthWorkflowByUser(IpdWorkflowEntity ipdWorkflowEntity)
        {
            ipdWorkflowEntity.UserName = LoggedInUserName;
            return _ipdAuthWorkflowService.ManageIpdAuthWorkflow(ipdWorkflowEntity);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("validateIPD/{dealIpdRunId}/{workFlowStep}")]
        public int ValidateIPD(int dealIpdRunId, int workFlowStep)
        {
            return _ipdAuthWorkflowService.ValidateIPD(dealIpdRunId, workFlowStep, LoggedInUserName);
        }
    }
}
