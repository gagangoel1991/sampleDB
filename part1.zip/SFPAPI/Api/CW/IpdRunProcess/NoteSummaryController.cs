﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/noteSummary")]
    [Authorize]
    public class NoteSummaryController : SFPControllerBase, INoteSummaryController
    {
        private readonly INoteSummaryService _noteSummaryService;

        public NoteSummaryController(INoteSummaryService noteSummaryService)
        {
            this._noteSummaryService = noteSummaryService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getDealNoteSummary/{dealId}/{ipdRunId}")]
        public DealNoteSummary GetDealNoteSummary(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _noteSummaryService.GetDealNoteSummary(feedParms);
        }
    }
}
