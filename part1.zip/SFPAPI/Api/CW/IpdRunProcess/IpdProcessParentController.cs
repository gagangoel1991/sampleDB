﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.API.Core.Token;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using NW.SFP.Message.Report;
using SFPAPI.Api;
using System;
using System.IO;

namespace NW.SFP.API.Api.CW
{

    [ApiController]
    [Produces("application/json")]
    [Route("api/IpdProcess")]
    [Authorize]
    public class IpdProcessParentController : SFPControllerBase
    {

        #region Variables  declaration and Construction

        private readonly ILoggerService _loggerService;
        private readonly IIpdProcessParentService _ipdProcessParentService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;
        private readonly IInvestorReportService _investorReportService;
        private IExcelService _excelService;
        private string parentWorkSheet;

        public IpdProcessParentController(IIpdProcessParentService ipdProcessParentService, ILoggerService loggerService,
            IOptions<CashWaterfallSettings> cwSettings, IInvestorReportService investorReportService, IExcelService ExcelService)
        {
            this._loggerService = loggerService;
            this._ipdProcessParentService = ipdProcessParentService;
            this._cwSettings = cwSettings;
            _investorReportService = investorReportService;
            _excelService = ExcelService;
            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
        }
        #endregion
        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("Dealdetail/{dealId}/{ipdRunId}")]
        public ActionResult GetIpdProcessParentData(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                var data = _ipdProcessParentService.GetIpdProcessParentData(feedParms);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IpdProcessParentController.GetIpdProcessParentData", ModuleId = (int)AppModule.Cashwaterfall };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [ValidateToken]
        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpGet("runIpd/{dealId}/{ipdRunId}")]
        public IActionResult RunIpd(int dealId, int ipdRunId)
        {
            try
            {
                var data = _ipdProcessParentService.RunIPD(ipdRunId, LoggedInUserName);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IpdProcessParentController.RunIPD", ModuleId = (int)AppModule.Cashwaterfall };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpGet("initiateIpd/{dealId}/{ipdDate}")]
        public IActionResult InitiateIPD(int dealId, DateTime ipdDate)
        {
            try
            {
                var data = _ipdProcessParentService.InitiateIPD(dealId, ipdDate, LoggedInUserName);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IpdProcessParentController.InitiateIPD", ModuleId = (int)AppModule.Cashwaterfall };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpGet("resetIPD/{dealId}/{ipdDate}")]
        public IActionResult ResetIPD(int dealId, DateTime ipdDate)
        {
            try
            {
                var data = _ipdProcessParentService.ResetIPD(dealId, ipdDate, LoggedInUserName);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IpdProcessParentController.ResetIPD", ModuleId = (int)AppModule.Cashwaterfall };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.ApproveReject)]
        [HttpPost("withdrawIpd")]
        public int WithdrawIPD(IpdWorkflowEntity ipdWorkflowEntity)
        {
            try
            {
                return _ipdProcessParentService.WithdrawIPD(ipdWorkflowEntity, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IpdProcessParentController.WithdrawIPD", ModuleId = (int)AppModule.Cashwaterfall };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpPost("saveOverridedIRFile")]
        public int SaveOverridedIRFile([FromForm] OverrideIrEntity overrideIREntity)
        {
            try
            {
                InvestorReportResultEntity investorReportResultEntity = _investorReportService.GetInvestorReportFileName(overrideIREntity.DealId, overrideIREntity.IpdDate, overrideIREntity.FileType);

                var files = HttpContext.Request.Form.Files;



                if (files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {

                            string OverridedFileName = Path.Combine(_cwSettings.Value.IRTargetFileLocation, investorReportResultEntity.FileName.Contains("Overrided_") ? investorReportResultEntity.FileName : "Overrided_" + investorReportResultEntity.FileName);

                            using (var fileStream = new FileStream(OverridedFileName, FileMode.Create))
                            {
                                file.CopyTo(fileStream);
                            }
                            using (var workbook = new XLWorkbook(OverridedFileName))
                            {
                                var workSheet = workbook.Worksheet(parentWorkSheet);
                                if (workSheet.Name != parentWorkSheet)
                                {
                                    if (System.IO.File.Exists(OverridedFileName))
                                        System.IO.File.Delete(OverridedFileName);

                                    return -2;
                                }
                            }
                        }
                    }
                }


                return _ipdProcessParentService.SaveOverridedIRFile(overrideIREntity, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.SaveTemplate", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("DownloadIrReconciliationFile/{irFileName}")]
        public IActionResult DownloadIrReconciliationFile(string irFileName)
        {
            string reconcileFile = "";
            string filePath = "";

            try
            {
                reconcileFile = CreateIrReconciliationFile(irFileName);
                if (reconcileFile != null || reconcileFile != "")
                {
                    filePath = Path.Combine(_cwSettings.Value.IRTargetFileLocation, reconcileFile);

                    var fileStream = new FileStream(filePath, FileMode.Open);

                    return File(fileStream, "application/octet-stream", reconcileFile);
                }
                return new NoContentResult();
            }
            catch (FileNotFoundException e)
            {
                return new NoContentResult();
            }
            catch (Exception ex)
            {
                filePath = Path.Combine(_cwSettings.Value.IRTargetFileLocation, reconcileFile);
                if (System.IO.File.Exists(filePath))
                    System.IO.File.Delete(filePath);

                throw ex;
            }
        }

        private string CreateIrReconciliationFile(string irFileName)
        {
            int r1 = 0, c1 = 0, r2 = 0, c2 = 0, max_rows = 0, max_columns = 0;
            string systemGeneratedIR = "System generated IR";
            string overridenIR = "Overriden IR";
            //Space After Variance Intentionally added
            string variance = "Variance ";
            string targetPath = _cwSettings.Value.IRTargetFileLocation;
            string OrignalIrPath = string.Concat(targetPath, irFileName.Replace("Overrided_", ""));
            string ModifiedIrPath = string.Concat(targetPath, irFileName);
            string reconcileFileName = string.Concat("Reconcile_", irFileName.Replace("Overrided_", ""));
            string ComparisionWorkBookName = string.Concat(targetPath, reconcileFileName);
            try
            {
                if (System.IO.File.Exists(ComparisionWorkBookName))
                    System.IO.File.Delete(ComparisionWorkBookName);

                //New Workbook Creating
                XLWorkbook newWorkBook = new XLWorkbook();
                newWorkBook.AddWorksheet("temp");
                newWorkBook.SaveAs(ComparisionWorkBookName);

                //Copying Orignal IR Worksheet
                using (XLWorkbook bookFrom = new XLWorkbook(OrignalIrPath))
                {
                    using (MemoryStream streamTo = new MemoryStream())
                    {
                        using (XLWorkbook bookTo = new XLWorkbook(ComparisionWorkBookName))
                        {
                            foreach (IXLWorksheet sheetFrom in bookFrom.Worksheets)
                            {
                                if (sheetFrom.Name == parentWorkSheet)
                                {
                                    sheetFrom.CopyTo(bookTo, systemGeneratedIR);
                                    bookTo.Worksheet(systemGeneratedIR).SheetView.ZoomScale = sheetFrom.SheetView.ZoomScale;
                                    c1 = sheetFrom.LastColumnUsed().ColumnNumber();
                                    r1 = sheetFrom.LastRowUsed().RowNumber();
                                }
                            }
                            bookTo.Save(true, true);
                        }
                    }
                }

                //Copying Modified IR Worksheet
                using (XLWorkbook bookFrom = new XLWorkbook(ModifiedIrPath))
                {
                    using (MemoryStream streamTo = new MemoryStream())
                    {
                        using (XLWorkbook bookTo = new XLWorkbook(ComparisionWorkBookName))
                        {
                            foreach (IXLWorksheet sheetFrom in bookFrom.Worksheets)
                            {
                                if (sheetFrom.Name == parentWorkSheet)
                                {
                                    sheetFrom.CopyTo(bookTo, overridenIR);
                                    bookTo.Worksheet(overridenIR).SheetView.ZoomScale = sheetFrom.SheetView.ZoomScale;
                                    c2 = sheetFrom.LastColumnUsed().ColumnNumber();
                                    r2 = sheetFrom.LastRowUsed().RowNumber();
                                }
                            }
                            bookTo.Save(true, true);
                        }
                    }
                }

                max_rows = Math.Max(r1, r2);
                max_columns = Math.Max(c1, c2);

                //Creating Comparision worksheet
                using (XLWorkbook bookFrom = new XLWorkbook(OrignalIrPath))
                {
                    using (MemoryStream streamTo = new MemoryStream())
                    {
                        using (XLWorkbook bookTo = new XLWorkbook(ComparisionWorkBookName))
                        {
                            foreach (IXLWorksheet sheetFrom in bookFrom.Worksheets)
                            {
                                sheetFrom.CopyTo(bookTo, variance);

                                bookTo.Worksheet(variance).SheetView.ZoomScale = sheetFrom.SheetView.ZoomScale;
                                bookTo.Worksheet(variance).Cells().Clear(XLClearOptions.Contents);

                                c1 = sheetFrom.LastColumnUsed().ColumnNumber();
                                r1 = sheetFrom.LastRowUsed().RowNumber();
                            }
                            bookTo.Worksheet("temp").Delete();
                            bookTo.Save(true, true);
                        }
                    }

                }

                //Adding Formula & Conidtional Formatting to Comparision Sheet 
                using (XLWorkbook bookTo = new XLWorkbook(ComparisionWorkBookName))
                {
                    var ws_O = bookTo.Worksheet(systemGeneratedIR);
                    var ws_N = bookTo.Worksheet(overridenIR);
                    var ws_C = bookTo.Worksheet(variance);
                    // Loop each row
                    for (int irow = 1; irow <= max_rows; irow++)
                    {
                        for (int iCol = 1; iCol <= max_columns; iCol++)
                        {
                            if (!ws_O.Cell(irow, iCol).IsEmpty() || !ws_N.Cell(irow, iCol).IsEmpty())
                            {
                                var cellAdress = ws_C.Cell(irow, iCol).Address.ToString();
                                ws_C.Cell(irow, iCol).FormulaA1 = "=IF('" + systemGeneratedIR + "'!" + cellAdress + " = '" + overridenIR + "'!" + cellAdress + ",\"True\",\"False\")";
                                ws_C.Cell(irow, iCol).Style.Font.SetFontColor(XLColor.Black);
                                ws_C.Cell(irow, iCol).AddConditionalFormat().WhenEquals("False").Fill.SetBackgroundColor(XLColor.FromHtml("#f08080"));
                                ws_C.Cell(irow, iCol).AddConditionalFormat().WhenEquals("TRUE").Fill.SetBackgroundColor(XLColor.FromHtml("#8fbc8f"));
                            }
                        }
                    }

                    bookTo.Save(true, true);

                }

                return reconcileFileName;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.CreateIrReconciliationFile", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                if (System.IO.File.Exists(ComparisionWorkBookName))
                    System.IO.File.Delete(ComparisionWorkBookName);

                throw ex;
            }


        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("DeleteIrReconciliationFile/{fileName}")]
        public bool DeleteIrReconciliationFile(string fileName)
        {
            string templateFilePath = _cwSettings.Value.IRTargetFileLocation;
            string reconcileFile = string.Concat(templateFilePath, fileName);

            try
            {
                if (System.IO.File.Exists(reconcileFile))
                    System.IO.File.Delete(reconcileFile);
                return true;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.DeleteIrReconciliationFile", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                return false;
            }
        }
    }
}