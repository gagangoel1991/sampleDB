﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;


namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/ipdSummary")]
    [Authorize]
    public class IpdSummaryController : SFPControllerBase, IIpdSummaryController
    {

        private readonly ILoggerService _loggerService;
        private readonly IIpdSummaryService _ipdSummaryService;

        public IpdSummaryController(IIpdSummaryService ipdSummaryService, ILoggerService loggerService)
        {
            _loggerService = loggerService;
            _ipdSummaryService = ipdSummaryService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("GetIpdSummaryData/{dealId}/{ipdRunId}")]
        public List<IpdSummaryResultEntity> GetIpdSummaryData(int dealId, int ipdRunId)
        {
            try
            {

                return _ipdSummaryService.GetIpdSummaryData(dealId, ipdRunId, LoggedInUserName);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "GetIpdSummaryData" };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

    }
}