﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/counterPartyRating")]
    [Authorize]
    public class CounterPartyRatingController : SFPControllerBase, ICounterpartyRatingController
    {
        private readonly ICounterpartyRatingService _cpRatingService;

        public CounterPartyRatingController(ICounterpartyRatingService cpRatingService)
        {
            this._cpRatingService = cpRatingService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCounterpartyRatingData/{dealId}/{ipdRunId}")]
        public CounterpartyRatingEntity GetCounterpartyRatingData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _cpRatingService.GetCounterpartyRatingData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCreditRatings")]
        public IList<CreditRatingEntity> GetCreditRatings()
        {
            return _cpRatingService.GetCreditRatings(LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("isCPRatingEdited/{ipdRunId}")]
        public bool IsCPRatingEdited(int ipdRunId)
        {
            return _cpRatingService.IsCPRatingEdited(ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("resetCPRating/{ipdRunId}")]
        public int ResetCounterpartyRatingData(int ipdRunId)
        {
            return _cpRatingService.ResetCounterpartyRatingData(ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("saveCounterpartyRatingData")]
        public int SaveCounterpartyRatingData(dynamic cpRatingEntity)
        {
            return _cpRatingService.SaveCounterpartyRatingData(cpRatingEntity, LoggedInUserName);
        }
    }
}
