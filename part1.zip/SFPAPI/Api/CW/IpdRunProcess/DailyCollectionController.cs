﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.ApiController;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/dailyCollection")]
    [Authorize]
    public class DailyCollectionController : SFPControllerBase, IDailyCollectionController
    {
        #region Variables  declaration and Construction

        private readonly IDailyCollectionService _dailyCollectionService;

        public DailyCollectionController(IDailyCollectionService dailyCollectionService)
        {
            this._dailyCollectionService = dailyCollectionService;
        }
        #endregion


        [HttpGet("getDailyCollectionData/{dealId}/{ipdRunId}")]
        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.View)]
        public DailyCollection GetDailyCollectionData(int dealId, int ipdRunId)
        {
            IPDFeedParam ipdFeedParam = new IPDFeedParam();
            ipdFeedParam.DealId = dealId;
            ipdFeedParam.IPDRunId = ipdRunId;
            ipdFeedParam.UserName = LoggedInUserName;
            return _dailyCollectionService.GetDailyCollectionData(ipdFeedParam);
        }


        [HttpPost("saveDailyCollectionData")]
        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.AddEdit)]
        public int SaveDailyCollectionData(DailyCollectionEntity dailyCollectionEntity)
        {
            //dailyCollectionEntity.UserName = LoggedInUserName;
            return _dailyCollectionService.SaveDailyCollectionData(dailyCollectionEntity, LoggedInUserName);
        }
    }
}
