﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.ApiController;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW.IR;
using SFPAPI.Api;
using System;
using System.Data;
using System.Net.Http;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/ipdrunprocess/controls")]
    [Authorize]
    public class DealIpdControlsController : SFPControllerBase, IDealIpdControlsController
    {
        private readonly IDealIpdControlsService _ControlsService;
        private IExcelService _ExcelService;
        private IOptions<CashWaterfallSettings> _cwSettings;

        public DealIpdControlsController(IDealIpdControlsService ControlsService,
            IExcelService ExcelService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._ControlsService = ControlsService;
            this._ExcelService = ExcelService;
            this._cwSettings = cwSettings;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("stormvssfp/{dealId}/{ipdRunId}")]
        public StormVsSfpEntity StormVsSfp(int dealId, int ipdRunId)
        {
            return _ControlsService.StormVsSfp(dealId, ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getStormVsSfpExcelFile/{dealId}/{ipdRunId}")]
        public string PreStormVsSfpReportDownload(int dealId, int ipdRunId)
        {
            string TemplateLocation = _cwSettings.Value.LiablityFeatureTemplateLocation;
            string TemplateFileName = _cwSettings.Value.ControlsPreStormVsSfpTemplateName;

            string TemplatePath = TemplateLocation + TemplateFileName;
            string TemplateBackupPath = TemplateLocation + TemplateFileName.Insert(TemplateFileName.LastIndexOf("."), Convert.ToString(Math.Abs(Environment.TickCount)));

            DataSet ExcelDs = _ControlsService.StormVsSfpExcelData(dealId, ipdRunId, LoggedInUserName);

            string OutputFileName = TemplateFileName;

            if (!System.IO.File.Exists(TemplateBackupPath))
                System.IO.File.Copy(TemplatePath, TemplateBackupPath);
            using (var workbook = new XLWorkbook(TemplateBackupPath))
            {

                int Holidays = Convert.ToInt32(ExcelDs.Tables[0].Rows[5][0]);

                DataTable HolidayDt = new DataTable();
                DataColumn HolidayCol = new DataColumn("Holiday");
                HolidayCol.DataType = System.Type.GetType("System.Int32");
                HolidayDt.Columns.Add(HolidayCol);                 
                DataRow dr = HolidayDt.NewRow();
                dr["holiday"] = Holidays;
                HolidayDt.Rows.Add(dr);

                ExcelDs.Tables[0].Rows.RemoveAt(5);
                _ExcelService.WriteDataIntoExcel(ExcelDs.Tables[0], workbook.Worksheets.Worksheet("Dates"), "B2");
                _ExcelService.WriteDataIntoExcel(HolidayDt, workbook.Worksheets.Worksheet("Dates"), "B7");
                _ExcelService.WriteDataIntoExcel(ExcelDs.Tables[1], workbook.Worksheets.Worksheet("STORM"), "A2");
                _ExcelService.WriteDataIntoExcel(ExcelDs.Tables[2], workbook.Worksheets.Worksheet("SFP"), "A2");
                _ExcelService.WriteDataIntoExcel(ExcelDs.Tables[3], workbook.Worksheets.Worksheet("Adjustments"), "D2");
                workbook.SaveAs(TemplateBackupPath);
            }
            byte[] bytes = System.IO.File.ReadAllBytes(TemplateBackupPath);
            System.IO.File.Delete(TemplateBackupPath);
            return Convert.ToBase64String(bytes);


        }
    }
}
