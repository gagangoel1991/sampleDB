﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace SFPAPI.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/ipdrunprocess/automateddata/colledger")]
    [Authorize]
    public class CollectionLedgerController : SFPControllerBase, ICollectionLedgerController
    {
        private readonly ICollectionLedgerService _collectionLedgerService;

        public CollectionLedgerController(ICollectionLedgerService collectionLedgerService)
        {
            this._collectionLedgerService = collectionLedgerService;
        }

        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.View)]
        [HttpGet("get/{dealId}/{ipdRunId}")]
        public CollectionLedger GetCollectionLedgerData(int dealId, int ipdRunId)
        {
            IPDFeedParam ipdFeedParam = new IPDFeedParam();
            ipdFeedParam.DealId = dealId;
            ipdFeedParam.IPDRunId = ipdRunId;
            ipdFeedParam.UserName = LoggedInUserName;
            return this._collectionLedgerService.GetCollectionLedgerData(ipdFeedParam);
        }


        [SFPAuthorize("CW_AutomatedData", PermissionAccessType.AddEdit)]
        [HttpPost("update")]
        public int UpdateCollectionLedgerData([FromBody] UpdateCollectionLedgerEntity objUpdateCollectionLedgerEntity)
        {
            return this._collectionLedgerService.UpdateCollectionLedgerData(objUpdateCollectionLedgerEntity, LoggedInUserName);
        }
    }
}
