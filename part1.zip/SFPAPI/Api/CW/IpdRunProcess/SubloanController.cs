﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/subloan")]
    [Authorize]
    public class SubloanController : SFPControllerBase, ISubloanController
    {
        private readonly ISubloanService _subLoanService;

        public SubloanController(ISubloanService subLoanService)
        {
            this._subLoanService = subLoanService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getSubloanData/{dealId}/{ipdRunId}")]
        public Subloan GetSubloan(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _subLoanService.GetSubloan(feedParms);
        }
    }
}
