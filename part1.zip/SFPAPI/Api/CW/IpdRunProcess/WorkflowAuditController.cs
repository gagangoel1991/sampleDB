﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/WorkflowAudit")]
    [Authorize]
    public class WorkflowAuditController : SFPControllerBase, IWorkflowAuditController
    {
        private readonly IWorkflowAuditService _workflowAuditService;
        public WorkflowAuditController(IWorkflowAuditService workflowAuditService)
        {
            this._workflowAuditService = workflowAuditService;
        }

        
        [SFPAuthorize("WorkflowManagement", PermissionAccessType.View)]
        [HttpGet("getWorkflowAuditData/{workflowTypeId}/{referenceId}")]
        public IList<WorkflowAuditEntity> GetWorkflowAuditData(int workflowTypeId, int referenceId)
        {
            return _workflowAuditService.GetWorkflowAuditData(workflowTypeId, referenceId, LoggedInUserName);
        }

       
    }
}
