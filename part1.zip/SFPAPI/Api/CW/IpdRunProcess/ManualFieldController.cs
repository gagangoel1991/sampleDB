﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Drawing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Dynamic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;


namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/ManualField")]
    [Authorize]
    public class ManualFieldController : SFPControllerBase, IManualFieldController
    {
        IManualFieldService _objManualFieldService;

        public ManualFieldController(IManualFieldService objManualFieldService)
        {
            _objManualFieldService = objManualFieldService;
        }

        dynamic sampleObject = new ExpandoObject();

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getManualFieldData/{DealIpdRunId}/{mfGrouptypeId}")]
        public dynamic GetManualFieldData(int DealIpdRunId,int mfGrouptypeId)
        {
            var Result = _objManualFieldService.GetManualFieldData(DealIpdRunId, mfGrouptypeId, LoggedInUserName);
            var FormattedResult = GetFormattedResult(Result);

            return new
            {
                IpdDates = Result.Select(a => a.IpdDate).Distinct().OrderByDescending(b => b),
                ManualFieldData = FormattedResult
            };
        }


        public dynamic GetFormattedResult(List<ManualFieldEntity> Result)
        {
            var FormattedResult = Result.GroupBy(a => a.GroupDisplayName).OrderBy(OrdGrp => OrdGrp.Select(key => key.GroupSortOrder).FirstOrDefault())
                         .Select(b => new
                         {
                             header = b.Key,
                             val = b.GroupBy(c => c.SubGroupDisplayName).OrderBy(OrdSubGrp => OrdSubGrp.Select(key => key.SubGroupSortOrder).FirstOrDefault())
                                    .Select(c => new
                                    {
                                        header = c.Key,
                                        isCollapsed = false,
                                        val = c.GroupBy(d => d.FieldDisplayName).OrderBy(OrdFld => OrdFld.Select(key => key.FieldSortOrder).FirstOrDefault())
                                               .Select(e => new
                                               {
                                                   header = e.Key,
                                                   TooltipText = e.Select(k => k.TooltipText).FirstOrDefault(),
                                                   val = e.Select(i => new
                                                   {
                                                       i.ManualFieldValueId,
                                                       i.FieldDisplayName,
                                                       i.FieldValue,
                                                       i.ManualFieldId,
                                                       i.FieldDataType,
                                                       i.IpdDate,
                                                       i.ModifiedBy,
                                                       i.ModifiedDate

                                                   }).OrderByDescending(j => j.IpdDate)
                                               })

                                    })
                         });
            return FormattedResult;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("updateManualFieldData/{mfGrouptypeId}")]
        public int UpdateManualFieldData(List<ManualFieldKeyValue> ManualFieldKeyValue,int mfGrouptypeId)
        {
            return _objManualFieldService.UpdateManualFieldData(ManualFieldKeyValue, mfGrouptypeId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("resetManualFieldData/{DealIpdRunId}/{mfGrouptypeId}")]
        public int ResetManualFieldData(int DealIpdRunId, int mfGrouptypeId)
        {
            return _objManualFieldService.ResetManualFieldData(DealIpdRunId, mfGrouptypeId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getManualExcelData/{DealIpdRunId}/{mfGrouptypeId}")]
        public string getManualExcelData(int DealIpdRunId, int mfGrouptypeId)
        {
            var Result = _objManualFieldService.GetManualFieldData(DealIpdRunId, mfGrouptypeId, LoggedInUserName);


            IXLWorkbook workbook = new XLWorkbook();
            IXLWorksheet worksheet = workbook.Worksheets.Add("Manual Values");

            var FormattedResult = GetFormattedResult(Result);
            var ipdDates = Result.Select(a => a.IpdDate).Distinct().OrderByDescending(b => b);


            string HeaderColour = "#248dad";
            string SubHeaderColour = "#7d898d";
            string HeaderTextColour = "#ffffff";

            string OddRowColour = "#e6e6e6";
            string EvenRowColour = "#f2f2f2";



            worksheet.Column(1).Width = 100;
            for (int k = 0; k < ipdDates.Count(); k++)
            {
                worksheet.Column(k + 2).Width = 20;
            }

            int i = 0;
            foreach (var HeaderElem in FormattedResult)
            {
                i++;
                int groupStart = i;
                worksheet.Cell(i, 1).Value = HeaderElem.header;
                worksheet.Cell(i, 1).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
                worksheet.Cell(i, 1).Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
                worksheet.Cell(i, 1).Style.Font.Bold = true;
                worksheet.Cell(i, 1).Style.Alignment.WrapText = true;

                int j = 2;
                foreach (var date in ipdDates)
                {
                    worksheet.Cell(i, j).Value = date;
                    worksheet.Cell(i, j).Style.Fill.BackgroundColor = XLColor.FromHtml(HeaderColour);
                    worksheet.Cell(i, j).Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
                    worksheet.Cell(i, j).Style.Font.Bold = true;

                    j++;
                }


                foreach (var SubHeaderElem in HeaderElem.val)
                {

                    if (SubHeaderElem.header != null)
                    {
                        i++;

                        worksheet.Cell(i, 1).Value = SubHeaderElem.header;
                        worksheet.Cell(i, 1).Style.Fill.BackgroundColor = XLColor.FromHtml(SubHeaderColour);
                        worksheet.Cell(i, 1).Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
                        worksheet.Cell(i, 1).Style.Font.Bold = true;
                        worksheet.Cell(i, 1).Style.Alignment.WrapText = true;


                        int k = 2;
                        foreach (var date in ipdDates)
                        {
                            worksheet.Cell(i, k).Value = date;
                            worksheet.Cell(i, k).Style.Fill.BackgroundColor = XLColor.FromHtml(SubHeaderColour);
                            worksheet.Cell(i, k).Style.Font.FontColor = XLColor.FromHtml(HeaderTextColour);
                            worksheet.Cell(i, k).Style.Font.Bold = true;
                            k++;
                        }
                    }

                    int b = 0;

                    foreach (var fieldGroup in SubHeaderElem.val)
                    {

                        string RowColour = OddRowColour;
                        if (b % 2 == 0)
                        {
                            RowColour = EvenRowColour;
                        }

                        i++;



                        worksheet.Cell(i, 1).Value = fieldGroup.header;
                        worksheet.Cell(i, 1).Style.Alignment.WrapText = true;
                        worksheet.Cell(i, 1).Style.Fill.BackgroundColor = XLColor.FromHtml(RowColour);

                        int l = 2;
                        foreach (var fieldElem in fieldGroup.val)
                        {

                            worksheet.Cell(i, l).Value = fieldElem.FieldValue;
                            worksheet.Cell(i, l).Style.Fill.BackgroundColor = XLColor.FromHtml(RowColour);

                            l++;
                        }



                        b++;
                    }


                }
                worksheet.Rows(groupStart + 1, i).Group(1);
                i++;

            }

            var workbookBytes = new byte[0];
            using (var ms = new MemoryStream())
            {
                workbook.SaveAs(ms);
                workbookBytes = ms.ToArray();
            }

            return Convert.ToBase64String(workbookBytes);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("resetManualFieldDealSwapData/{DealIpdRunId}/{mfGrouptypeId}")]
        public int ResetManualFieldDealSwapData(int DealIpdRunId, int mfGrouptypeId)
        {
            return _objManualFieldService.ResetManualFieldDealSwapData(DealIpdRunId, mfGrouptypeId, LoggedInUserName);
        }
    }
}
