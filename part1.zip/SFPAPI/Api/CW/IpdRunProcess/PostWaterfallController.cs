﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.BusinessService.CW;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.ApiController;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using NW.SFP.Message.CW.IR;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/ipdrunprocess/controls")]
    [Authorize]
    public class PostWaterfallController : SFPControllerBase
    {
        private readonly IAutomatedPostWaterfallControlService _AutomatedPostWaterfallControlService;
        private IExcelService _ExcelService;
        private IOptions<CashWaterfallSettings> _cwSettings;
        private IrReportService _reportService;


        private string sourcePath;
        

        public PostWaterfallController(IAutomatedPostWaterfallControlService AutomatedPostWaterfallControlService
            , IExcelService ExcelService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._AutomatedPostWaterfallControlService = AutomatedPostWaterfallControlService;
            this._ExcelService = ExcelService;
            this._cwSettings = cwSettings;
            sourcePath = _cwSettings.Value.IRTargetFileLocation;


        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("CreatePostWFControlExcelFile/{dealName}/{asAtDate}")]
        public IActionResult CreatePostWFControlFile(string dealName, string asAtDate)
        {
           try
            {

                var _ExcelUploadEntity = _AutomatedPostWaterfallControlService.GetPostWfControlList(dealName, asAtDate);

                               
                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;

                string PostWFControlFile = string.Concat(sourcePath, OutPutFileName);

                if (!System.IO.File.Exists(PostWFControlFile))
                {

                    var isFileCreated = _AutomatedPostWaterfallControlService.GenerateAutomatedPostWaterfallFile(dealName, asAtDate, LoggedInUserName);
                }

                var fileStream = new FileStream(PostWFControlFile, FileMode.Open);

                return File(fileStream, "application/octet-stream", OutPutFileName);

            }
            catch (Exception ex)
            {

             
                throw ex;
            }
           
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("GetPostWFControlDataFromFile/{dealName}/{asAtDate}")]
        public List<PostWaterfallReconcileEntity> GetPostWFControlDataFromFile(string dealName, string asAtDate)
        {
            try
            {
                var _ExcelUploadEntity = _AutomatedPostWaterfallControlService.GetPostWfControlList(dealName, asAtDate);

                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;

                string PostWFControlFile = string.Concat(sourcePath, OutPutFileName);

               
                var isFileCreated = _AutomatedPostWaterfallControlService.GenerateAutomatedPostWaterfallFile(dealName, asAtDate, LoggedInUserName);
               

                List<PostWaterfallReconcileEntity> PostWFControlFileString = _AutomatedPostWaterfallControlService.GetPostWaterfallTabData(PostWFControlFile, "Reconciliation");

                return PostWFControlFileString;
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

    }
}
