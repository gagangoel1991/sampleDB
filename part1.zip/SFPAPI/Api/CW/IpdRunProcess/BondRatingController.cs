﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.ApiController;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System.Collections.Generic;

namespace NW.SFP.API.Api.CW.IpdRunProcess
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/bondRating")]
    [Authorize]
    public class BondRatingController : SFPControllerBase, IBondRatingController
    {
        private readonly IBondRatingService _bondRatingService;

        public BondRatingController(IBondRatingService bondRatingService)
        {
            this._bondRatingService = bondRatingService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBondRatingData/{dealId}/{ipdRunId}")]
        public BondRating GetBondRatingData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _bondRatingService.GetBondRatingData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCreditRatings")]
        public IList<CreditRatingEntity> GetCreditRatings()
        {
            return _bondRatingService.GetCreditRatings(LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("isBondRatingEdited/{ipdRunId}")]
        public bool IsBondRatingEdited(int ipdRunId)
        {
            return _bondRatingService.IsBondRatingEdited(ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("resetBondRating/{ipdRunId}")]
        public int ResetBondRatingData(int ipdRunId)
        {
            return _bondRatingService.ResetBondRatingData(ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpPost("saveBondRatingData")]
        public int SaveBondRatingData(dynamic bondRatingEntity)
        {
            return _bondRatingService.SaveBondRatingData(bondRatingEntity, LoggedInUserName);
        }
    }
}
