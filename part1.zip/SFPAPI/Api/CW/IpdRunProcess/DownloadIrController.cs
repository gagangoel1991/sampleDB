﻿namespace NW.SFP.API.CW
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Threading.Tasks;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.CW;
    using Microsoft.Extensions.Logging;
    using Microsoft.AspNetCore.Authorization;
    using NW.SFP.API.Core.Auth;
    using NW.SFP.API.Core.Constants;
    using Microsoft.AspNetCore.Cors;
    using SFPAPI.Api;
    using NW.SFP.Message;
    using NW.SFP.Interface;
    using NW.SFP.Interface.Core;
    using System.IO;
    using NW.SFP.Message.Core;
    using Microsoft.Extensions.Options;
    using NW.SFP.Message.CW.IR;
    using Microsoft.Extensions.Configuration;
    using global::SFPAPI.Api;
    using System.Net.Http;
    using ClosedXML.Excel;
    using System.Net;
    using NW.SFP.BusinessService.CW;

    [ApiController]
    [Produces("application/json")]
    [Route("api/ir/file/")]
    [Authorize]
    public class DownloadIrController : SFPControllerBase
    {

        #region Variables  declaration and Construction
        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        private readonly ILoggerService _loggerService;

        private IrReportService _reportService;

        private IExcelService _excelService;
        

        private string parentWorkSheet;

        private readonly int _missingParentSheet =-2;

        public DownloadIrController(ILoggerService loggerService, IrReportService ReportService, IExcelService ExcelService
            , IOptions<CashWaterfallSettings> cwSettings)
        {
            
            this._loggerService = loggerService;
            this._cwSettings = cwSettings;
            _reportService = ReportService;
            _excelService = ExcelService;
            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
        }
        #endregion

        #region Action Methods
       


        [SFPAuthorize("CW_Reports", PermissionAccessType.AddEdit)]
        [HttpGet("download")]
        public bool Download(int dealIrConfigId, string asAtDate, int templateId, int ipdRunId)
        {
            string SourcePath = "";

            if (templateId == 0)
                SourcePath = _cwSettings.Value.IrConfigFileLocation;
            else
                SourcePath = _cwSettings.Value.IrTemplateFileLocation;

            string TargetPath = _cwSettings.Value.IRTargetFileLocation;

            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;

            string BackupTemplate = "";
            string GeneratedFileName = "";

            try
            {
                if(dealIrConfigId > 0)
                    {
                    IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = _reportService.GetBuildIrStratList(dealIrConfigId, asAtDate,"");

                    string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                    string OutPutFileName = _ExcelUploadEntity.First().DownloadIrFileName;

                    string TemplatePath = string.Concat(SourcePath, TemplateFile);

                    BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                    GeneratedFileName = string.Concat(TargetPath, OutPutFileName);


                    if (!System.IO.File.Exists(BackupTemplate))
                        System.IO.File.Copy(TemplatePath, BackupTemplate);

                    var isGenerated = _reportService.GenerateIRFile(BackupTemplate, GeneratedFileName, parentWorkSheet, true, _cwSettings.Value.IrProtectSheetKey, dealIrConfigId, asAtDate, _ExcelUploadEntity, LoggedInUserName, "");

                    System.IO.File.Delete(BackupTemplate);

                    return isGenerated;
                }

                return false;
                //log.Info(string.Format("Request {0} report processing completed at {1} from User {2}", RequestId, DateTime.Now, Environment.UserName));
            }
            catch (Exception ex)
            {

                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DownloadIrController.Download", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                
                throw ex;
            }
        }

        
       
        #endregion

    }
}
