﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using Microsoft.AspNetCore.Cors;
using SFPAPI.Api;
using NW.SFP.Message;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using System.IO;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Options;
using System.Net.Http;
using NW.SFP.Common;
using NW.SFP.DataService.Core;
using NW.SFP.Message.CW.IR;

namespace NW.SFP.API.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/stratmgt")]
    [Authorize]
    public class StratController : SFPControllerBase
    {

        #region Variables  declaration and Construction

        private readonly IStratService _assetStratService;
        private readonly ILoggerService _loggerService;


        public StratController(IStratService assetStratService, ILoggerService loggerService)
        {
            this._assetStratService = assetStratService;
            this._loggerService = loggerService;
        }
        #endregion

        #region Action Methods

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("strats/{AssetClassId}")]
        public ActionResult GetStratList(int AssetClassId)
        {
            try
            {
                var assetStratModel = _assetStratService.GetAssetStratList((int)StratType.ConfigStrat, AssetClassId);
                return Ok(assetStratModel);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.GetStratList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("configStrats/{AssetClassId}")]
        public ActionResult GetConfigStratList(int AssetClassId)
        {
            try
            {
                var assetStratModel = _assetStratService.GetAssetStratList((int)StratType.ConfigStrat, AssetClassId);
                return Ok(assetStratModel);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.GetStratList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("bespokeStrats/{AssetClassId}")]
        public ActionResult GetBespokeStratList(int AssetClassId)
        {
            try
            {
                var assetStratModel = _assetStratService.GetAssetStratList((int)StratType.BespokeStrat, AssetClassId);
                return Ok(assetStratModel);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.GetStratList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }



        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("stratsDtls/{stratId}")]
        public ActionResult GetStratDetail(int stratId)
        {
            try
            {
                var assetStratModel = _assetStratService.GetAssetStratDetail(stratId,LoggedInUserName);
                return Ok(assetStratModel);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.GetStratDetail", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }



        [SFPAuthorize("CW_IR_Config", PermissionAccessType.AddEdit)]
        [HttpPost("saveStrat/{AssetClassId}")]
        public ActionResult SaveStrat([FromBody] StratEntity assetStrat, int AssetClassId)
        {
            try
            {
                _assetStratService.Save(assetStrat, LoggedInUserName, AssetClassId, "");
                return Ok(assetStrat);
              
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.SaveStrat", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.Delete)]
        [HttpDelete("deleteStrat/{stratId}")]
        public ActionResult DeleteStrat(int stratId)
        {
            try
            {
                this._assetStratService.Delete(stratId, LoggedInUserName);
                return Ok();
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.DeleteStrat", ModuleId = (int)AppModule.Cashwaterfall, UserName =LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpPost("stratPreviewData")]
        public ActionResult PreviewStrat([FromBody] StratPreviewSearchEntity searchStratPreview )
        {
            try
            {
                var dt = this._assetStratService.GetStratPreviewData(searchStratPreview);
                List<StratPreviewEntity> stratPreviewData = new List<StratPreviewEntity>();
                if( dt != null )
                stratPreviewData = Utils.ConvertDataTable<StratPreviewEntity>(dt);

                return Ok(stratPreviewData);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.PreviewStrat", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpPost("beSpokeStratPreviewData")]
        public BespokeStratPreviewEntity GetBeSpokeStratPreviewData(StratPreviewSearchEntity stratPreviewSearchEntity)
        {
            return this._assetStratService.GetBeSpokeStratPreviewData(stratPreviewSearchEntity);
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("beSpokeStratDtl/{stratId}")]
        public ActionResult GetBeSpokeAssetStratDetail(int stratId)
        {
            try
            {
                var assetStratModel = _assetStratService.GetBeSpokeAssetStratDetail(stratId, LoggedInUserName);
                return Ok(assetStratModel);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "StratController.GetStratDetail", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        #endregion

    }
}
