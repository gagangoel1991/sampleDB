﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using Microsoft.AspNetCore.Cors;
using SFPAPI.Api;
using NW.SFP.Message;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using System.IO;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Options;

namespace NW.SFP.API.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/ir/lookup/")]
    [Authorize]
    public class IrLookupController : SFPControllerBase, IIrLookupController
    {

        #region Variables  declaration and Construction
        private readonly IIrLookupService _irLookupService;

        private readonly ILoggerService _loggerService;

        public IrLookupController(IIrLookupService irLookupService, ILoggerService loggerService)
        {
            this._irLookupService = irLookupService;
            this._loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("getstrat")]
        public IList<StratLookup> GetStratLookup(int stratTypeId)
       {
            try
            {
                return this._irLookupService.GetStratLookup(stratTypeId, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrLookupController.GetStratLookup", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        #endregion

    }
}
