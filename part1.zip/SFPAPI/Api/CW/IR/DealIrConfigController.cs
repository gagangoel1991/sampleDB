﻿namespace NW.SFP.API.CW
{
    using ClosedXML.Excel;
    using global::SFPAPI.Api;
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Http;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using NW.SFP.API.Core.Auth;
    using NW.SFP.API.Core.Constants;
    using NW.SFP.BusinessService.CW;
    using NW.SFP.Common;
    using NW.SFP.Interface;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Message.Common;
    using NW.SFP.Message.Core;
    using NW.SFP.Message.CW;
    using NW.SFP.Message.CW.IR;
    using System;
    using System.Collections.Generic;
    using System.IO;
    using System.Linq;

    [ApiController]
    [Produces("application/json")]
    [Route("api/ir/buildir/")]
    [Authorize]
    public class DealIrConfigController : SFPControllerBase, IDealIrConfigController
    {

        #region Variables  declaration and Construction
        private readonly IDealIrConfigService _dealIrConfigService;

        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        private readonly ILoggerService _loggerService;

        private IrReportService _reportService;

        private IExcelService _excelService;


        private string parentWorkSheet;

        private readonly string _missingParentSheet = "missing";

        public DealIrConfigController(IDealIrConfigService dealIrConfigService, ILoggerService loggerService, IOptions<CashWaterfallSettings> cwSettings
            , IrReportService ReportService, IExcelService ExcelService)
        {
            this._dealIrConfigService = dealIrConfigService;
            this._loggerService = loggerService;
            this._cwSettings = cwSettings;
            _reportService = ReportService;
            _excelService = ExcelService;
            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("getlist/{AssetClassId}/{ReportTypeName?}")]
        public IList<DealIrConfigListEntity> GetDealIrConfigList(int AssetClassId, string ReportTypeName = "")
        {
            try
            {
                return this._dealIrConfigService.GetDealIrConfigList(LoggedInUserName, ReportTypeName, AssetClassId);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.GetDealIrConfigList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("get")]
        public DealIrConfigEntity GetDealIrConfig(int dealIrConfigId, int AssetClassId)
        {
            try
            {

                return this._dealIrConfigService.GetDealIrConfig(dealIrConfigId, LoggedInUserName, "", AssetClassId);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.GetDealIrConfig", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("getIrConfigDealList")]
        public List<IR_ConfigDealList> getIrConfigDealList()
        {
            try
            {
                return this._dealIrConfigService.getIrConfigDealList(0, LoggedInUserName, "");
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.GetDealIrConfig", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("getIrConfigLayoutList")]
        public List<IR_ConfigLayoutList> getIrConfigLayoutList(int dealId, int AssetClassID)
        {
            try
            {
                return this._dealIrConfigService.getIrConfigLayoutList(0, dealId, LoggedInUserName, "", AssetClassID);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.GetIrConfigLayoutList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }


        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("getIrConfigStratList")]
        public List<IR_ConfigStartList> getIrConfigStratList(int dealId, int AssetClassID)
        {
            try
            {
                return this._dealIrConfigService.GetIrConfStartList(0, dealId, LoggedInUserName, "", AssetClassID);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.GetIrConfigStratList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }


        [SFPAuthorize("CW_IR_Config", PermissionAccessType.AddEdit)]
        [HttpPost("save/{AssetClassId}")]
        public int SaveDealIrConfig([FromBody] DealIrConfigAddEditEntity dealIrConfigData, int AssetClassId)
        {

            try
            {
                return this._dealIrConfigService.SaveDealIrConfig(dealIrConfigData, LoggedInUserName, "", AssetClassId);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.GetDealIrConfig", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }

        }


        [SFPAuthorize("CW_IR_Config", PermissionAccessType.Delete)]
        [HttpGet("delete")]
        public int DeleteDealIrConfig(int dealIrConfigId)
        {
            try
            {
                return this._dealIrConfigService.DeleteDealIrConfig(dealIrConfigId, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.DeleteDealIrConfig", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.AddEdit)]
        [HttpPost("upload/{assetClassId}")]
        public string UploadTemplate([FromForm] DealIrConfigAddEditEntity dealIrConfigData, int assetClassId)
        {
            try
            {
                var files = HttpContext.Request.Form.Files;
                SetParamsBasedOnAsset((AssetType)assetClassId);
                if (files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {
                            string customFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName); // Give file name
                            string GeneratedFileName = Path.Combine(_cwSettings.Value.IrConfigFileLocation, customFileName);

                            using (var fileStream = new FileStream(GeneratedFileName, FileMode.Create))
                            {
                                file.CopyTo(fileStream);
                            }

                            using (var workbook = new XLWorkbook(GeneratedFileName))
                            { 
                                if (!_excelService.IsWorksheetsExist(workbook, parentWorkSheet.Split('|')))
                                    {
                                    if (System.IO.File.Exists(GeneratedFileName))
                                        System.IO.File.Delete(GeneratedFileName);

                                    return _missingParentSheet;
                                }
                            }

                            dealIrConfigData.OriginalFileName = file.FileName;
                            dealIrConfigData.UploadedFileName = customFileName;
                        }
                    }
                }

                var isUploaded = this._dealIrConfigService.SaveDealIrConfig(dealIrConfigData, LoggedInUserName, "", 0);

                if (isUploaded == -1)
                    return "duplicate";
                else
                    return dealIrConfigData.UploadedFileName;

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.SaveTemplate", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("download")]
        public IActionResult Download(int dealIrConfigId, string asAtDate, int templateId, int assetId)
        {
            ///* To Stop Concurrent Process*/
            bool generateFinalIrCopy = false;
            string SourcePath = "";



            if (templateId == 0)
                SourcePath = _cwSettings.Value.IrConfigFileLocation;
            else
                SourcePath = _cwSettings.Value.IrTemplateFileLocation;

            string TargetPath = _cwSettings.Value.IRTargetFileLocation;

            SetParamsBasedOnAsset((AssetType)assetId);

            string BackupTemplate = "";
            string GeneratedFileName = "";

            try
            {
                IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = _reportService.GetBuildIrStratList(dealIrConfigId, asAtDate, "");

                string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;

                string TemplatePath = string.Concat(SourcePath, TemplateFile);

                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                GeneratedFileName = string.Concat(TargetPath, OutPutFileName);

                var isGenerated = _reportService.GenerateIRFile(BackupTemplate, GeneratedFileName, parentWorkSheet, generateFinalIrCopy, "", dealIrConfigId, asAtDate, _ExcelUploadEntity, LoggedInUserName, "", assetId);

                System.IO.File.Delete(BackupTemplate);

                var fileStream = new FileStream(GeneratedFileName, FileMode.Open);
                return File(fileStream, "application/octet-stream", OutPutFileName);
            }
            catch (Exception ex)
            {

                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.Download", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);


                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.ApproveReject)]
        [HttpPost("manageDealIRAuthWorkflow")]
        public int ManageDealIRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealIrConfigService.ManageDealIRAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.AddEdit)]
        [HttpPost("manageDealIRAuthWorkflowByUser")]
        public int ManageDealIRAuthWorkflowByUser(AuthWorkflowEntity authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealIrConfigService.ManageDealIRAuthWorkflow(authWorkflowEntity);
        }


        private void SetParamsBasedOnAsset(AssetType assetId)
        {
            switch (assetId)
            {
                case AssetType.Retail:
                    parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
                    break;
                case AssetType.Corporate:
                    parentWorkSheet = _cwSettings.Value.CBIrParentWorksheets;
                    break;
                default:
                    parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
                    break;
            }
        }
        #endregion
    }
}
