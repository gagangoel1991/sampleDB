﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW;
using Microsoft.Extensions.Logging;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using Microsoft.AspNetCore.Cors;
using SFPAPI.Api;
using NW.SFP.Message;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using System.IO;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Options;
using System.Net.Http;
using NW.SFP.Common;
using NW.SFP.DataService.Core;
using ClosedXML.Excel;
using NW.SFP.Message.CW.IR;
using NW.SFP.Interface.CW;
using ClosedXML.Excel;

namespace NW.SFP.API.CW
{

    [ApiController]
    [Produces("application/json")]
    [Route("api/ir/template")]
    [Authorize]
    public class IrTemplateController : SFPControllerBase, IIrTemplateController
    {

        #region Variables  declaration and Construction

        private readonly IIrTemplateService _templateService;
        private readonly ILoggerService _loggerService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;
        private IExcelService _excelService;
        private string parentWorkSheet;
        private readonly int _missingParentSheet = -2;

        public IrTemplateController(IIrTemplateService templateService, ILoggerService loggerService, IExcelService ExcelService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._templateService = templateService;
            this._loggerService = loggerService;
            this._cwSettings = cwSettings;
            this._excelService = ExcelService;
            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
        }
        #endregion

        #region Action Methods

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("list/{assetClassId}/{reportTypeName?}")]
        public IList<IrTemplateEntity> GetTemplateList(int assetClassId, string reportTypeName = "")
        {
            try
            {
                return _templateService.GetTemplateList(assetClassId, reportTypeName);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.GetTemplateList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.View)]
        [HttpGet("get")]
        public IrTemplateEntity GetTemplateDetail(int templateId, string reportTypeName = "")
        {
            try
            {
                return _templateService.GetTemplateDetail(templateId, LoggedInUserName, reportTypeName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.GetTemplate", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.AddEdit)]
        [HttpPost("save/{assetClassId}/{reportTypeName?}")]
        public int SaveTemplate([FromForm] IrTemplateEntity templateEntity, int assetClassId, string reportTypeName = "")
        {
            try
            {
                string GeneratedFileName;
                var files = HttpContext.Request.Form.Files;
                SetParamsBasedOnAsset((AssetType)templateEntity.AssetId, reportTypeName);
                if (files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {
                            string customFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName); // Give file name
                            GeneratedFileName = Path.Combine(_cwSettings.Value.IrTemplateFileLocation, customFileName);
                            if (reportTypeName == "Reference Registry")
                            {
                                GeneratedFileName = Path.Combine(_cwSettings.Value.RrTemplateFileLocation, customFileName);
                            }
                            using (var fileStream = new FileStream(GeneratedFileName, FileMode.Create))
                            {
                                file.CopyTo(fileStream);
                            }

                            using (var workbook = new XLWorkbook(GeneratedFileName))
                            {
                                if (!_excelService.IsWorksheetsExist(workbook, parentWorkSheet?.Split('|')) && !string.IsNullOrEmpty(parentWorkSheet))
                                {
                                    if (System.IO.File.Exists(GeneratedFileName))
                                        System.IO.File.Delete(GeneratedFileName);

                                    return _missingParentSheet;
                                }
                            }

                            templateEntity.OriginalFileName = file.FileName;
                            templateEntity.UploadedFileName = customFileName;
                        }
                    }
                }
                return _templateService.Save(templateEntity, LoggedInUserName, assetClassId, reportTypeName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.SaveTemplate", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_IR_Config", PermissionAccessType.Delete)]
        [HttpDelete("delete/{templateId}")]
        public int DeleteTemplate(int templateId)
        {
            try
            {
                return this._templateService.Delete(templateId, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.DeleteTemplate", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [HttpGet("downloadTemplate")]
        public IActionResult DownloadTemplateFile(int templateId, string reportTypeName = "")
        {
            try
            {
                IrTemplateEntity templateEntity = _templateService.GetTemplateDetail(templateId, LoggedInUserName, reportTypeName);
                string TemplateFileLocation = _cwSettings.Value.IrTemplateFileLocation;
                if (reportTypeName == "Reference Registry")
                {
                    TemplateFileLocation = _cwSettings.Value.RrTemplateFileLocation;
                }

                string templateFilePath = Path.Combine(TemplateFileLocation, templateEntity.UploadedFileName);
                var fileStream = new FileStream(templateFilePath, FileMode.Open);

                return File(fileStream, "application/octet-stream", templateEntity.OriginalFileName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "IrTemplateController.DownloadTemplateFile", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        private void SetParamsBasedOnAsset(AssetType assetId, string reportTypeName)
        {
            switch (assetId)
            {
                case AssetType.Retail:
                    parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
                    break;
                case AssetType.Corporate:
                    if (reportTypeName == "Reference Registry")
                        parentWorkSheet = "";
                    else
                        parentWorkSheet = _cwSettings.Value.CBIrParentWorksheets;
                    break;
                default:
                    parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
                    break;
            }
        }
        #endregion

    }
}