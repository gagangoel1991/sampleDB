﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Common;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/dealCollections")]
    [Authorize]
    public class DealCollectionsController : SFPControllerBase
    {
        private readonly ILoggerService _loggerService;
        private readonly IDailyCashCollectionsService _dailyCashCollectionsService;
        private readonly IDailyCashEstimationService _dailyCashEstimationService;
        private readonly IDealSummaryOutputService _dealSummaryOutputService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;
        private readonly IEmailService _emailService;

        public DealCollectionsController(IDailyCashCollectionsService dailyCashCollectionsService, IDailyCashEstimationService dailyCashEstimationService,
                                         IDealSummaryOutputService dealSummaryOutputService, ILoggerService loggerService, IOptions<CashWaterfallSettings> cwSettings,
                                         IEmailService emailService)
        {
            this._loggerService = loggerService;
            this._dailyCashCollectionsService = dailyCashCollectionsService;
            this._dailyCashEstimationService = dailyCashEstimationService;
            this._dealSummaryOutputService = dealSummaryOutputService;
            this._cwSettings = cwSettings;
            this._emailService = emailService;
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getCashEstimation/{dealName}/{asAtDate}")]
        public List<DailyCashEstimationDataEntity> GetCashEstimationSummary(string dealName, string asAtDate)
        {
            try
            {
                var lst = _dailyCashEstimationService.GetDailyCashEstimationData(dealName, asAtDate, LoggedInUserName);
                return lst;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCashEstimationSummary", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);



                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getCashEstDist/{dealName}/{asAtDate}")]
        public List<DailyCashEstimationDataEntity> GetCashEstimationDistinct(string dealName, string asAtDate)
        {
            try
            {
                var lst = _dailyCashEstimationService.GetCashEstimationDistinct(dealName, asAtDate, LoggedInUserName);
                return lst;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCashEstimationDistinct", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getCollectionDate/{dealName}/{asAtDate}")]
        public DateTime GetCollectionDate(string dealName, string asAtDate)
        {
            try
            {
                return _dailyCashEstimationService.GetCollectionDate(asAtDate, dealName, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCollectionDate", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

		[SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getCashEstExcel/{dealName}/{asAtDate}")]
        public string GetCashEstimationExcel(string dealName, string asAtDate)
        {
            try
            {
                var workbook = _dailyCashEstimationService.GetDailyCashEstimationExcel(dealName, asAtDate, LoggedInUserName);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCashEstimationExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getDealSummaryOutput")]
        public List<DealSummaryDataEntity> GetDealSummayOutput([FromBody] DealSummaryDataModel dealSummaryDataModel)
        {
            try
            {
                var lst = _dealSummaryOutputService.GetDealSummaryOutputData(Utils.SetSelectListTableDateValues(dealSummaryDataModel.adviceDate), dealSummaryDataModel.dealName, dealSummaryDataModel.dealCategoryName,dealSummaryDataModel.viewType, "");
                return lst;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealSummayOutput", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("saveDealSummaryAdjustment")]
        public int SaveDealSummayAdjustment([FromBody] List<DealSummarySaveAdjustmentModel> dealSummarySaveAdjustmentModel)
        {
            try
            {
                
                return  _dealSummaryOutputService.SaveDealSummayAdjustment(dealSummarySaveAdjustmentModel, LoggedInUserName);
                
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.SaveDealSummayAdjustment", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getCollectionHistory")]
        public ActionResult GetDealCollectionHistory([FromBody] DailyCollectionHistoryParam dailyCollectionHistParam)
        {
            try
            {
                var resultDynamic = _dailyCashCollectionsService.GetDealCollectionHistoryData(dailyCollectionHistParam, LoggedInUserName);
                return Ok(resultDynamic);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealCollectionHistory", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getPNRSplitDetails/{asAtDate}/{adviceDate}/{dealName}")]
        public ActionResult GetPNRSplitDetails(string asAtDate, string adviceDate, string dealName)
        {
            try
            {
                var resultDynamic = _dailyCashCollectionsService.GetPNRSplitData(asAtDate, adviceDate, dealName, LoggedInUserName);
                return Ok(resultDynamic);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.getPNRSplitDetails", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getDealDailyCollections/{asAtDate}")]
        public ActionResult GetDealDailyCollectionsDetails(string asAtDate)
        {
            try
            {
                var resultDynamic = _dailyCashCollectionsService.GetDealDailyCollectionData(asAtDate, LoggedInUserName);
                return Ok(resultDynamic);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.getDealDailyCollectionsDetails", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getCBOutput")]
        public ActionResult GetCBOutputDetails([FromBody] DailyCollectionHistoryParam cbOutputParam)
        {
            try
            {
                var resultDynamic = _dailyCashCollectionsService.GetCBOutputData(cbOutputParam, LoggedInUserName);
                return Ok(resultDynamic);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCBOutputDetails", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getDailyColExl/{asAtDate}")]
        public string GetDealDailyCollectionsExcel(string asAtDate)
        {
            try
            {
                var workbook = _dailyCashCollectionsService.GetDealDailyCollectionsExcel(asAtDate,LoggedInUserName);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealDailyCollectionsExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getPNRSplitExcel/{asAtDate}/{adviceDate}/{dealName}")]
        public string GetPNRSplitExcel(string asAtDate, string adviceDate, string dealName)
        {
            try
            {
                var workbook = _dailyCashCollectionsService.GetPNRSplitExcel(asAtDate, adviceDate, dealName, LoggedInUserName);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealDailyCollectionsExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }
       
        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getCBOutputExcel")]
        public string GetCBOutputExcel([FromBody] DailyCollectionHistoryParam cbOutputParam)
        {
            try
            {
                var workbook = _dailyCashCollectionsService.GetCBOutputExcel(cbOutputParam, LoggedInUserName);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCBOutputExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("downloadCollectionHistory")]
        public string downloadCollectionHistory([FromBody] DailyCollectionHistoryParam dailyCollectionHistParam)
        {
           
            string SourcePath = "";
            string BackupTemplate = "";
            string GeneratedFileName = "";

            SourcePath = _cwSettings.Value.CollectionHistoryTemplateFileLocation;
         


            try
            {
                string TemplateFile = _cwSettings.Value.CollectionHistoryFileName;
                string OutPutFileName = TemplateFile;

                string TemplatePath = string.Concat(SourcePath, TemplateFile);
                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                GeneratedFileName = string.Concat(SourcePath, Guid.NewGuid().ToString(), OutPutFileName);

                var isGenerated = _dailyCashCollectionsService.GenerateCollectionHistoryFile(dailyCollectionHistParam, BackupTemplate, GeneratedFileName, LoggedInUserName);

                System.IO.File.Delete(BackupTemplate);

                var fileStream = _dailyCashCollectionsService.GetDownloadFileStream(GeneratedFileName);

                return fileStream;

            }
            catch (Exception ex)
            {
                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.downloadCollectionHistory", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
            
        }


         [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getDealSummaryAudit")]
        public List<DealSummaryDataEntity> GetDealSummayAudit([FromBody] DealSummaryDataModel dealSummaryDataModel)
        {
            try
            {
                var lst = _dealSummaryOutputService.GetDealSummaryAuditData(Utils.SetSelectListTableDateValues(dealSummaryDataModel.adviceDate), dealSummaryDataModel.dealName, "");
                return lst;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealSummayAudit", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("saveDealSummaryAudit")]
        public int SaveDealSummayAudit([FromBody] DealSummarySaveAuditModel dealSummarySaveAuditModel)
        {
            try
            {
                return _dealSummaryOutputService.SaveDealSummayAudit(dealSummarySaveAuditModel,LoggedInUserName);

            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.SaveDealSummayAudit", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.AddEdit)]
        [HttpPost("manageDealSummaryAuditAuthWorkflowByUser")]
        public int ManageDealSummaryAuditAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._dealSummaryOutputService.ManageDealSummaryAuditAuthWorkflow(authWorkflowEntity);
        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getCollectionDateList/{dealName}/{asAtDate}")]
        public ActionResult GetCollectionDateList(string dealName, DateTime asAtDate)
        {
            try
            {

                var obj= _dealSummaryOutputService.GetCollectionDateList(asAtDate, dealName, LoggedInUserName);

                return Ok(obj);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetCollectionDateList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getDailyCollectionDealSummary/{adviceDate}/{dealName}")]
        public DailyCollectionDealSummaryModel GetDailyCollectionDealSummary(DateTime adviceDate, string dealName)
        {
            try
            {

                return _dealSummaryOutputService.GetDailyCollectionDealSummary(adviceDate, dealName, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDailyCollectionDealSummary", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getDealSummaryExcel")]
        public string GetDealSummaryExcel([FromBody]  DailyCollectionDatesExcel dailyCollectionDatesExcel)
        {
            try
            {
                var workbook = _dealSummaryOutputService.GetDealSummaryExcel(dailyCollectionDatesExcel, LoggedInUserName);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                    workbook.Dispose();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealSummaryExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getEmailData/{emailType}/{asAtDate}")]
        public ActionResult GetEmailDataForCollectionOutput(string emailType, string asAtDate)
        {
            try
            {

                string GeneratedFileName = "";
                string attachmentFileLocation = _cwSettings.Value.EmailTemplateFileLocation;

                GeneratedFileName = string.Concat(attachmentFileLocation,"DailyCollectionOutput" + "_" + asAtDate + ".xlsx");
                var obj = _dailyCashCollectionsService.GetEmailDataForCollectionOutput(emailType, asAtDate, GeneratedFileName, LoggedInUserName);
                   this._emailService.AttachmentforEmail(obj, GeneratedFileName);
                return Ok(obj);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetEmailDataForCollectionOutput", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getLoadDailyEstimationDealSummary/{adviceDate}/{dealName}/{isEstimationData}")]
        public int GetLoadDailyEstimationDealSummary(string adviceDate, string dealName,bool isEstimationData)
        {
            try
            {

                return _dealSummaryOutputService.GetLoadDailyEstimationDealSummary(adviceDate, dealName, isEstimationData, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetLoadDailyEstimationDealSummary", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpPost("getDealSummaryLoadDataEstimation")]
        public List<bool> getDealSummaryLoadDataEstimation([FromBody] DealSummaryDataModel dealSummaryDataModel)
        {
            try
            {
                var lst = _dealSummaryOutputService.GetDealSummaryLoadDataEstimation(Utils.SetSelectListTableDateValues(dealSummaryDataModel.adviceDate), dealSummaryDataModel.dealName, "");
                return lst;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.getDealSummaryLoadDataEstimation", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("isActualGMSDataAvaliable/{adviceDate}/{dealName}/{isEstimationData}")]
        public int IsActualGMSDataAvaliable(string adviceDate, string dealName, bool isEstimationData)
        {
            try
            {

                return _dealSummaryOutputService.IsActualGMSDataAvaliable(adviceDate, dealName, isEstimationData, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.IsActualGMSDataAvaliable", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }


        [SFPAuthorize("CW_DealCollection", PermissionAccessType.View)]
        [HttpGet("getLoadDeflagAdjustmentDealSummary/{adviceDate}/{dealName}/{isDeFlagAdjustment}")]
        public int getLoadDeflagAdjustmentDealSummary(string adviceDate, string dealName,int isDeFlagAdjustment)
        {
            try
            {

                return _dealSummaryOutputService.GetLoadDeflagAdjustmentDealSummary(adviceDate, dealName,isDeFlagAdjustment, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.getLoadDeflagAdjustmentDealSummary", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

    }
}