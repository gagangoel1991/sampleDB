﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.CW.Email;
using SFPAPI.Api;
using System.Collections.Generic;
 

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/email")]
    [Authorize]
    public class EmailConfigController : SFPControllerBase, IEmailConfigController
    {
        private readonly ILoggerService _loggerService;
        private readonly IEmailConfigService _emailConfigService;

        public EmailConfigController(IEmailConfigService emailConfigService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._emailConfigService = emailConfigService;
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("getEmailConfigList")]
        public IList<EmailConfigEntity> GetEmailConfigList()
        {
            return this._emailConfigService.GetEmailConfigList(LoggedInUserName);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.View)]
        [HttpGet("getEmailConfig/{emailConfigId}")]
        public IActionResult GetEmailConfig(int emailConfigId)
        {
            var entity = this._emailConfigService.GetEmailConfig(emailConfigId, LoggedInUserName);
            if (object.Equals(entity, null))
            {
                return NotFound();
            }
            else
            {
                return Ok(entity);
            }
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("saveEmailConfig")]
        public int SaveEmailConfig(EmailConfigEntity emailConfigEntity)
        {
            emailConfigEntity.UserName = LoggedInUserName;
            return this._emailConfigService.SaveEmailConfig(emailConfigEntity);
        }

        [SFPAuthorize("DealMgmt", PermissionAccessType.AddEdit)]
        [HttpGet("deleteEmailConfig/{emailConfigId}")]
        public IActionResult DeleteEmailConfig(int emailConfigId)
        {
            var entity = this._emailConfigService.DeleteEmailConfig(emailConfigId, LoggedInUserName);
            return Ok(entity);
        }
    }
}
