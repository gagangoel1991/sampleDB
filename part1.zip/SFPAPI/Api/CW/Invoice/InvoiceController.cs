﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.IO;

namespace NW.SFP.API.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/invoice")]
    [Authorize]
    public class InvoiceController : SFPControllerBase, IInvoiceController
    {

        #region Variables  declaration and Construction
        private readonly IInvoiceFacadeService _invoiceFacadeService;

        private readonly ILoggerService _loggerService;

        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        public InvoiceController(IInvoiceFacadeService invoiceFacadeService, ILoggerService loggerService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._invoiceFacadeService = invoiceFacadeService;
            this._loggerService = loggerService;
            this._cwSettings = cwSettings;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpPost("getinvoicelist")]
        public IList<InvoiceDataEntity> GetInvoiceList(InvoiceDataParams invoiceParams)
        {
            try
            {
                return this._invoiceFacadeService.GetInvoiceList(invoiceParams, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.GetInvoiceList", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("getinvoice")]
        public InvoiceDataEntity GetInvoice(int invoiceId)
        {
            try
            {
                return this._invoiceFacadeService.GetInvoice(invoiceId, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.GetInvoice", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("downloadInvoiceFile")]
        public IActionResult DownloadInvoiceFile(int invoiceId)
        {
            try
            {
                InvoiceDataEntity invoiceEntity = this._invoiceFacadeService.GetInvoice(invoiceId, LoggedInUserName);
                string invoiceFilePath = Path.Combine(_cwSettings.Value.InvoiceFileLocation, invoiceEntity.UploadedFileName);
                var fileStream = new FileStream(invoiceFilePath, FileMode.Open);

                return File(fileStream, "application/octet-stream", invoiceEntity.OriginalFileName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.DownloadInvoiceFile", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.AddEdit)]
        [HttpPost("saveInvoice")]
        public int SaveInvoice([FromForm] InvoiceDataEntity invoiceEntity)
        {
            try
            {
                var files = HttpContext.Request.Form.Files;
                if (files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {
                            string customFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName); // Give file name
                            using (var fileStream = new FileStream(Path.Combine(_cwSettings.Value.InvoiceFileLocation, customFileName), FileMode.Create))
                            {
                                file.CopyTo(fileStream);
                            }
                            invoiceEntity.OriginalFileName = file.FileName;
                            invoiceEntity.UploadedFileName = customFileName;
                        }
                    }
                }

                return this._invoiceFacadeService.SaveInvoiceData(invoiceEntity, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.SaveInvoice", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.Delete)]
        [HttpGet("deleteInvoice")]
        public int DeleteInvoiceData(int invoiceId)
        {
            try
            {
                return this._invoiceFacadeService.DeleteInvoiceData(invoiceId, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.DeleteInvoiceData", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("getInvoiceCatType")]
        public IList<InvoiceCategoryTypeEntity> GetInvoiceCategoryType()
        {
            try
            {
                return this._invoiceFacadeService.GetInvoiceCategoryType(LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.GetInvoiceCategoryType", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("getInvoiceCategory")]
        public IList<InvoiceCategoryEntity> GetInvoiceCategory(int invoiceCategoryTypeId)
        {
            try
            {
                return this._invoiceFacadeService.GetInvoiceCategory(invoiceCategoryTypeId, LoggedInUserName);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvoiceController.GetInvoiceCategory", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("getInvoiceIpdData/{dealId}/{ipdRunId}")]
        public IList<InvoiceDataEntity> GetInvoiceIpdData(int dealId, int ipdRunId)
        {
            IPDFeedParam iPDFeedParam = new IPDFeedParam();
            iPDFeedParam.DealId = dealId;
            iPDFeedParam.IPDRunId = ipdRunId;
            iPDFeedParam.UserName = LoggedInUserName;
            return _invoiceFacadeService.GetInvoiceIpdData(iPDFeedParam);
        }


        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("getSpotRate/{dealId}/{invoiceCurrencyId}/{spotRateDate}")]
        public decimal? GetSpotRate(int dealId, int invoiceCurrencyId, DateTime spotRateDate)
        {
            return _invoiceFacadeService.GetSpotRate(dealId, invoiceCurrencyId, spotRateDate, LoggedInUserName);
        }
        #endregion

    }
}
