﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.BusinessService.CW;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/deflag")]
    [Authorize]
    public class DeflagController : SFPControllerBase
    {
        #region Variables  declaration and Construction
        private readonly IDeflagAdjustmentService _deflagAdjustmentService;

        private readonly ILoggerService _loggerService;

        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        private IExcelService _ExcelService;

        public DeflagController(IDeflagAdjustmentService deflagAdjustmentService, ILoggerService loggerService, IOptions<CashWaterfallSettings> cwSettings, IExcelService excelService)
        {
            this._deflagAdjustmentService = deflagAdjustmentService;
            _ExcelService = excelService;
            this._cwSettings = cwSettings;
        }

        #endregion

        [SFPAuthorize("DeflagAdjustment", PermissionAccessType.View)]
        [HttpGet("getRepurchasePoolAdjustment")]
        public DataTable GetRepurchasePoolAdjustment()
        {
            DataTable dt = new DataTable();
            try
            {
                dt = _deflagAdjustmentService.GetRepurchasePoolAdjustmentData();
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DeflagController.GetRepurchasePoolAdjustment", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
            return dt;
        }

        [SFPAuthorize("DeflagAdjustment", PermissionAccessType.View)]
        [HttpGet("getPoolAdjustmentDetails/{poolCashCollectionAdjustmentId}")]
        public DataTable GetAdjustmentPoolDetails(int poolCashCollectionAdjustmentId)
        {
            DataTable dt = new DataTable();
            try
            {
                dt = _deflagAdjustmentService.GetAdjustmentPoolData(poolCashCollectionAdjustmentId);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DeflagController.GetRepurchasePoolAdjustment", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
            return dt;
        }

        [SFPAuthorize("DeflagAdjustment", PermissionAccessType.View)]
        [HttpGet("getDeflagAdjustmentExcelFile/{poolCashCollectionAdjustmentId}")]
        public string GetDeflagAdjustmentExcelFile(int poolCashCollectionAdjustmentId)
        {
            string userName = LoggedInUserName;
            string TemplateLocation = _cwSettings.Value.DeflagAdjustmentTemplateFileLocation;
            string TemplateFileName = _cwSettings.Value.DeflagAdjustmentFileName;

            string TemplatePath = TemplateLocation + TemplateFileName;
            string TemplateBackupPath = TemplateLocation + TemplateFileName.Insert(TemplateFileName.LastIndexOf("."), Convert.ToString(Math.Abs(Environment.TickCount)));

            DataTable ExcelDt = _deflagAdjustmentService.GetDeflagAdjustmentExcelData(poolCashCollectionAdjustmentId, userName);


            string OutputFileName = TemplateFileName;

            if (!System.IO.File.Exists(TemplateBackupPath))
                System.IO.File.Copy(TemplatePath, TemplateBackupPath);
            using (var workbook = new XLWorkbook(TemplateBackupPath))
            {
                _ExcelService.WriteDataIntoExcel(ExcelDt, workbook.Worksheets.Worksheet("Data"), 2,1);
                //_ExcelService.WriteDataIntoExcel(HolidayDt, workbook.Worksheets.Worksheet("Dates"), "B7");
                workbook.SaveAs(TemplateBackupPath);
            }
            byte[] bytes = System.IO.File.ReadAllBytes(TemplateBackupPath);
            System.IO.File.Delete(TemplateBackupPath);
            return Convert.ToBase64String(bytes);


        }

        [SFPAuthorize("DeflagAdjustment", PermissionAccessType.View)]
        [HttpGet("getControlCheckData/{poolCashCollectionAdjustmentId}")]
        public DataTable GetControlCheckData(int poolCashCollectionAdjustmentId)
        {
            string userName = LoggedInUserName;

            try
            {
                var lst = _deflagAdjustmentService.GetControlCheckData(poolCashCollectionAdjustmentId, userName);
                return lst;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DeflagController.GetRepurchasePoolAdjustment", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealCollection", PermissionAccessType.AddEdit)]
        [HttpPost("manageDeflagAdjustmentAuditAuthWorkflowByUser")]
        public int ManageDeflagAdjustmentAuditAuthWorkflowByUser(IPDFeedParam authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._deflagAdjustmentService.ManageDeflagAdjustmentAuditAuthWorkflowByUser(authWorkflowEntity);
        }

        [SFPAuthorize("DeflagAdjustment", PermissionAccessType.AddEdit)]
        [HttpPost("deflagAdjustmentSentforAuthorization")]
        public int DeflagAdjustmentSentforAuthorization(DefalgAdjustmentEntity DefalgAdjustmentEntity)
        {
            DefalgAdjustmentEntity.UserName = LoggedInUserName;
            return this._deflagAdjustmentService.DeflagAdjustmentSentforAuthorization(DefalgAdjustmentEntity);
        }
    }
}
