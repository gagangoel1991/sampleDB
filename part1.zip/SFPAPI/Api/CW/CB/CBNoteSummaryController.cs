﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Api.CW
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/cbNoteSummary")]
    [Authorize]
    public class CBNoteSummaryController : SFPControllerBase, ICBNoteSummaryController
    {
        private readonly ICBNoteSummaryService _cbNoteSummaryService;

        public CBNoteSummaryController(ICBNoteSummaryService cbNoteSummaryService)
        {
            this._cbNoteSummaryService = cbNoteSummaryService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getNoteSummary/{dealId}/{ipdRunId}")]
        public CBNoteSummary GetNoteSummary(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _cbNoteSummaryService.GetNoteSummary(feedParms);
        }
    }
}
