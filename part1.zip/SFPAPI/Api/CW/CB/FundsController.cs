﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;

namespace NW.SFP.API.Api.CW.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/reserveFund")]
    [Authorize]
    public class FundsController : SFPControllerBase, IFundsController
    {
        private readonly IFundsFacadeService _reserveFundService;
        private readonly ILoggerService _loggerService;

        public FundsController(IFundsFacadeService reserveFundService, ILoggerService loggerService)
        {
            this._reserveFundService = reserveFundService;
            this._loggerService = loggerService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCouponPaymentFund/{dealId}/{ipdRunId}")]
        public List<CouponPaymentEntity> GetCouponPaymentFund(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetCouponPaymentFund(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getPreMaturityLiquidityFund/{dealId}/{ipdRunId}")]
        public List<PreMaturityLiquidityEntity> GetPreMaturityLiquidityFund(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetPreMaturityLiquidityFund(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getReserveFund/{dealId}/{ipdRunId}")]
        public List<ReserveFundEntity> GetReserveFund(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                var obj = _reserveFundService.GetReserveFund(feedParms);

                return obj;
            }

            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "FundsController.GetReserveFund", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getSwapCollateral/{dealId}/{ipdRunId}")]
        public List<SwapCollateralEntity> GetSwapCollateral(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetSwapCollateral(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getReserveFundExcel/{dealId}/{ipdRunId}")]
        public string GetReserveFundExcel(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                var workbook = _reserveFundService.GetReserveFundExcel(feedParms);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "FundsController.GetReserveFundExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getReserveFundIpdDateHeader/{dealId}/{ipdRunId}")]
        public DataTable GetReserveFundIpdDateHeader(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                DataTable dt = new DataTable();
                dt = _reserveFundService.GetReserveFundIpdDateHeader(feedParms);
                return dt;
            }

            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "FundsController.GetReserveFundIpdDateHeader", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getRevenueLedger/{dealId}/{ipdRunId}")]
        public List<RevenueLedgerFund> GetRevenueLedger(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetRevenueLedger(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("GetPaymentLedger/{dealId}/{ipdRunId}")]
        public List<PaymentLedgerFund> GetPaymentLedger(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetPaymentLedger(feedParms);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getPrincipalLedger/{dealId}/{ipdRunId}")]
        public List<PrincipalLedgerFund> GetPrincipalLedger(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetPrincipalLedger(feedParms);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getMaturingLoansLedger/{dealId}/{ipdRunId}")]
        public List<MaturingLoansLedgerFund> GetMaturingLoansLedger(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetMaturingLoansLedger(feedParms);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCapitalAccountLedger/{dealId}/{ipdRunId}")]
        public List<CapitalAccountLedgerEntity> GetCapitalAccountLedger(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _reserveFundService.GetCapitalAccountLedger(feedParms);
        }



    }
}
