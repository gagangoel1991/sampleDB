﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Common;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NW.SFP.API.Api.CW.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/bondSwap")]
    [Authorize]
    public class BondSwapController : SFPControllerBase, IBondSwapController
    {
        private readonly IBondSwapService _bondSwapService;

        public BondSwapController(IBondSwapService bondSwapService)
        {
            this._bondSwapService = bondSwapService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBondSwapData/{dealId}/{ipdRunId}")]
        public List<BondSwapEntity> GetBondSwapData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _bondSwapService.GetBondSwapData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("geBondSwapExcel/{dealId}/{ipdRunId}")]
        public string exportToExcel(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var result = _bondSwapService.GetBondSwapData(feedParms);
            var customAttributes = typeof(BondSwapEntity).GetProperties().Select(p => p.GetCustomAttributes(typeof(TypesAttr), false)).Where(x => x.Length > 0).ToList();
            var workbookBytes = ExportExcel.GetExcel(result, customAttributes, "Bond Swap");
            return Convert.ToBase64String(workbookBytes);
        }
    }
}
