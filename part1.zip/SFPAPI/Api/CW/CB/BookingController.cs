﻿using DocumentFormat.OpenXml.Drawing.Charts;
using DocumentFormat.OpenXml.Spreadsheet;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.BusinessService.CW;
using NW.SFP.BusinessService.CW.CB;
using NW.SFP.Common;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Runtime;

namespace NW.SFP.API.Api.CW.CB
{

    [ApiController]
    [Produces("application/json")]
    [Route("api/booking")]
    [Authorize]
    public class BookingController : SFPControllerBase, IBookingController
    {

        private readonly IBookingService _bookingService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        public BookingController(IBookingService bookingService, IOptions<CashWaterfallSettings> cwSettings)
        {
            this._bookingService = bookingService;
            this._cwSettings = cwSettings;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingTradesData/{dealId}/{ipdRunId}")]
        public List<BookingTradesEntity> GetBookingTradesData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _bookingService.GetBookingTabData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingsIPDData/{dealId}/{ipdRunId}")]
        public List<BookingEntity> GetBookingsIPDData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _bookingService.GetBookingsIPDData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingExcel/{dealId}/{ipdRunId}/{isSwapSummaryData}")]
        public string GetBookingExcel(int dealId, int ipdRunId,bool isSwapSummaryData)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                var workbook = _bookingService.GetBookingExcel(feedParms, isSwapSummaryData);
                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                    workbook.Dispose();
                }
                return Convert.ToBase64String(workbookBytes);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.GetDealSummaryExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                //this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingNwbFoFeesData/{dealId}/{ipdRunId}")]
        public ActionResult GetBookingNwbFoFeesData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var resultDynamic = _bookingService.GetBookingNwbFoFeesData(feedParms);
            return Ok(resultDynamic);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingNwbFoLdData/{dealId}/{ipdRunId}")]
        public ActionResult GetBookingNwbFoLdData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var resultDynamic = _bookingService.GetBookingNwbFoLdData(feedParms);
            return Ok(resultDynamic);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingLlpMoData/{dealId}/{ipdRunId}")]
        public ActionResult GetBookingLLPMoFeesData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var resultDynamic = _bookingService.GetBookingLLPMoFeesData(feedParms);
            return Ok(resultDynamic);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingLoansDeposits/{dealId}/{ipdRunId}")]
        public ActionResult GetBookingLoansAndDepositsData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var resultDynamic = _bookingService.GetBookingLoansAndDepositsData(feedParms);
            return Ok(resultDynamic);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingSwapSummaryData/{dealId}/{ipdRunId}")]
        public ActionResult GetBookingSwapSummaryData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var resultDynamic = _bookingService.GetBookingSwapSummaryData(feedParms);
            return Ok(resultDynamic);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingReconData/{dealId}/{ipdRunId}")]
        public ActionResult GetBookingReconData(int dealId, int ipdRunId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var resultDynamic = _bookingService.GetBookingReconData(feedParms);
            return Ok(resultDynamic);

           
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getBookingReconExcelData/{dealId}/{ipdRunId}")]
        public string GetBookingReconExcelData(int dealId, int ipdRunId)
        {

            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;

            string SourcePath = "";
            string BackupTemplate = "";
            string GeneratedFileName = "";


            SourcePath = _cwSettings.Value.BookingReconTemplateFileLocation;

            try
            {
                string TemplateFile = _cwSettings.Value.BookingReconFileName;
                string OutPutFileName = TemplateFile;

                string TemplatePath = string.Concat(SourcePath, TemplateFile);
                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                GeneratedFileName = string.Concat(SourcePath, Guid.NewGuid().ToString(), OutPutFileName);


                var isGenerated = _bookingService.GetBookingReconExcelData(feedParms, BackupTemplate, GeneratedFileName);

                System.IO.File.Delete(BackupTemplate);

                var fileStream = _bookingService.GetDownloadFileStream(GeneratedFileName);

                return fileStream;

            }
            catch (Exception ex)
            {
                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealCollectionsController.downloadCollectionHistory", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                //  this._loggerService.LogError(logError);

                throw ex;
            }

            // var resultDynamic = _bookingService.GetBookingReconData(feedParms);
            // return Ok(resultDynamic);
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.AddEdit)]
        [HttpGet("processBookingsIPDData/{ipdRunId}")]
        public ActionResult ProcessBookingsIPDData(int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return Ok(_bookingService.ProcessBookingData(feedParms)); 
        }


    }
}
