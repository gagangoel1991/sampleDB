﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using SFPAPI.Api;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.Interface.CW.BusinessService;
using ClosedXML.Excel;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using System.IO;
using DocumentFormat.OpenXml.Wordprocessing;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CB;

namespace NW.SFP.API.Api.CW.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/SoniaCompounding")]
    [Authorize]
    public class SoniaCompoundingController : SFPControllerBase, ISoniaCompoundingController
    {
        ISoniaCompoundingService _objSoniaCompoundingService;

        public SoniaCompoundingController(ISoniaCompoundingService objSoniaCompoundingService)
        {
            _objSoniaCompoundingService = objSoniaCompoundingService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("GetSoniaCompoundingSummary/{dealId}/{ipdRunId}")]
        public List<SoniaCompoundingSummaryEntity> GetSoniaCompoundingSummary(int dealId, int ipdRunId)
        {
            return _objSoniaCompoundingService.GetSoniaCompoundingSummary(dealId, ipdRunId, LoggedInUserName);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getSoniaCompoundingData/{accrualStartDate}/{accrualEndDate}")]
        public dynamic GetSoniaCompoundingData(DateTime accrualStartDate, DateTime accrualEndDate)
        {
            return _objSoniaCompoundingService.GetSoniaCompoundingData(accrualStartDate, accrualEndDate, LoggedInUserName);
        }
    }
}
