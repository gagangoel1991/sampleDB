﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface.CW;
using SFPAPI.Api;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.Interface.CW.BusinessService;
using ClosedXML.Excel;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using System.IO;
using DocumentFormat.OpenXml.Wordprocessing;
using NW.SFP.Interface.CW.CB;

namespace NW.SFP.API.Api.CW.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/CollAndInt")]
    [Authorize]
    public class CollectionsAndReservesInterestController : SFPControllerBase, ICollectionsAndReservesInterestController
    {
        ICollectionsAndReservesInterestService _objCollectionsAndReservesService;

        public CollectionsAndReservesInterestController(ICollectionsAndReservesInterestService objCollectionsAndReservesService)
        {
            _objCollectionsAndReservesService = objCollectionsAndReservesService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCollandIntExcelData/{DealIpdRunId}")]
        public string GetCollandIntExcelSheet(int DealIpdRunId)
        {
            IXLWorkbook workbook = _objCollectionsAndReservesService.GetCollandIntExcelSheet(DealIpdRunId, LoggedInUserName);

            var workbookBytes = new byte[0];
            using (var ms = new MemoryStream())
            {
                workbook.SaveAs(ms);
                workbookBytes = ms.ToArray();
            }

            return Convert.ToBase64String(workbookBytes);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getCollandIntData/{DealIpdRunId}")]
        public dynamic GetCollandIntData(int DealIpdRunId)
        {

            return _objCollectionsAndReservesService.GetCollandIntData(DealIpdRunId, LoggedInUserName);


        }
    }
}
