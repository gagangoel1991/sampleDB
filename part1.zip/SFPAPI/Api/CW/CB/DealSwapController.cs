﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Common;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;

namespace NW.SFP.API.Api.CW.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/dealSwap")]
    [Authorize]
    public class DealSwapController : SFPControllerBase, IDealSwapController
    {
        private readonly IDealSwapService _dealSwapService;

        public DealSwapController(IDealSwapService dealSwapService)
        {
            this._dealSwapService = dealSwapService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getDealSwapData/{dealId}/{ipdRunId}")]
        public List<DealSwapEntity> GetDealSwapData(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            return _dealSwapService.GetDealSwapData(feedParms);
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("getDealSwapExcel/{dealId}/{ipdRunId}")]
        public string exportToExcel(int dealId, int ipdRunId)
        {
            IPDFeedParam feedParms = new IPDFeedParam();
            feedParms.DealId = dealId;
            feedParms.IPDRunId = ipdRunId;
            feedParms.UserName = LoggedInUserName;
            var result = _dealSwapService.GetDealSwapData(feedParms);
            var customAttributes = typeof(DealSwapEntity).GetProperties().Select(p => p.GetCustomAttributes(typeof(TypesAttr), false))
                                        .Where(x => x.Length > 0).OrderBy(p => p.OfType<TypesAttr>().First().Order).ToList();
            var workbookBytes = ExportExcel.GetExcel(result, customAttributes, "Deal Swap");
            return Convert.ToBase64String(workbookBytes);
        }

        private dynamic GetPayValue(string ipdDate, string conName, ref List<DealSwapEntity> dealSwapEntities, string swapName)
        {
            var entity = dealSwapEntities.Where(x => x.IpdDate == ipdDate && x.SwapName == swapName);
            switch (conName)
            {
                case "PayCouponPeriodStart":
                    return entity.Select(x => x.PayCouponPeriodStart);
                case "PayCouponPeriodEnd":
                    return entity.Select(x => x.PayCouponPeriodEnd);
                case "PayRate":
                    return entity.Select(x => x.PayRate);
                case "PayNotional":
                    return entity.Select(x => x.PayNotional);
                case "PayMarginDifferential":
                    return entity.Select(x => x.PayMarginDifferential);
                case "PayAmount":
                    return entity.Select(x => x.PayAmount);
                default:
                    return "0.00";
            }
        }

        private dynamic GetReceiveValue(string ipdDate, string conName, ref List<DealSwapEntity> dealSwapEntities, string swapName)
        {
            var entity = dealSwapEntities.Where(x => x.IpdDate == ipdDate && x.SwapName == swapName);
            switch (conName)
            {
                case "ReceiveCouponPeriodStart":
                    return entity.Select(x => x.ReceiveCouponPeriodStart);
                case "ReceiveCouponPeriodEnd":
                    return entity.Select(x => x.ReceiveCouponPeriodEnd);
                case "PayRaReceiveRatete":
                    return entity.Select(x => x.ReceiveRate);
                case "ReceiveNotional":
                    return entity.Select(x => x.ReceiveNotional);
                case "ReceiveMarginDifferential":
                    return entity.Select(x => x.ReceiveMarginDifferential);
                case "ReceiveAmount":
                    return entity.Select(x => x.ReceiveAmount);
                default:
                    return "0.00";
            }
        }
    }
}
