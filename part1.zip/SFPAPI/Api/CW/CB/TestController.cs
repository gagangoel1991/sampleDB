﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW.CB;
using NW.SFP.Message.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;


namespace NW.SFP.API.Api.CW.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/Test")]
    [Authorize]
    public class TestController : SFPControllerBase
    {
        private readonly ILoggerService _loggerService;
        private readonly ITestService _testService;

        public TestController(ITestService testService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._testService = testService;
        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("summary/{dealId}/{ipdRunId}")]
        public dynamic GetTestSummary(int dealId, int ipdRunId)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                var objSummaryTuple = _testService.GetTestDataSummary(feedParms);

                return new
                {
                    IpdTestSummaryItems = objSummaryTuple.Item1,
                    IpdDates = objSummaryTuple.Item2,
                    IpdTabs = objSummaryTuple.Item3
                };

            }

            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "TestController.GetTestSummary", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("testData/{dealId}/{ipdRunId}/{testTypeName}")]
        public List<TestDataEntity> GetTestData(int dealId, int ipdRunId, string testTypeName)
        {
            try
            {
                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                var obj = _testService.GetTestData(feedParms, testTypeName);

                return obj;

            }

            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "TestController.GetTestData", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [SFPAuthorize("CW_DealIpdProcess", PermissionAccessType.View)]
        [HttpGet("testExcel/{dealId}/{ipdRunId}/{testTypeName}")]
        public string GetTestExcel(int dealId, int ipdRunId, string testTypeName)
        {
            try
            {              

                IPDFeedParam feedParms = new IPDFeedParam();
                feedParms.DealId = dealId;
                feedParms.IPDRunId = ipdRunId;
                feedParms.UserName = LoggedInUserName;
                var workbook = _testService.GetTestExcel(feedParms, testTypeName);

                var workbookBytes = new byte[0];
                using (var ms = new MemoryStream())
                {
                    workbook.SaveAs(ms);
                    workbookBytes = ms.ToArray();
                }

                return Convert.ToBase64String(workbookBytes);

            }

            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "TestController.GetTestExcel", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        

    }




}
