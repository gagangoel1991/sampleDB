﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Auth
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/auth0")]
    [Authorize]
    public class AuthenticationController : SFPControllerBase
    {
        #region Variables  declaration and Construction
        private readonly IAuthService _authService;

        private readonly ILoggerService _loggerService;

        public AuthenticationController(IAuthService authService, ILoggerService loggerService)
        {
            this._authService = authService;
            this._loggerService = loggerService;
        }

        #endregion

        #region Action Methods
        [AllowAnonymous]
        [HttpGet("checkHeartBeat")]
        public bool CheckHeartBeat()
        {
            return true;
        }

        [HttpGet("getDefaultAssetClass")]
        public string GetDefaultAssetClass()
        {
            return this._authService.GetDefaultAssetClass(LoggedInUserName, UserAllADGroup);

        }

        [HttpGet("getAppInitialData/{selectedAssetId}")]
        public UserDetailEntity GetUserAndMenuData(int selectedAssetId)
        {
            try
            {
                UserDetailEntity userDetail = this._authService.GetUserAndMenuData(LoggedInUserName, UserAllADGroup, selectedAssetId);

                _loggerService.LogInfo(new LogInfoEntity() { ActionPerformed = "Fetch user and menu details", UserName = LoggedInUserName, LogDetail = "Fetching Menu Detail. User AD Group: " + UserAllADGroup, ModuleId = (int)AppModule.Cashwaterfall });

                return userDetail;
            }
            catch(Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() {  ErrorMessage = ex.Message, ErrorMethod = "Auth.GetUserAndMenuData. AD Group: " + UserAllADGroup, ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        [HttpGet("getdealipdmenu")]
        public IList<MenuItemEntity> GetDealIpdMenuData(int dealId)
        {
            try
            {
                IList<MenuItemEntity> menuItems = this._authService.GetDealIpdMenuData(dealId, LoggedInUserName);

                _loggerService.LogInfo(new LogInfoEntity() { ActionPerformed = "Fetch deal IPD Menu details", UserName = LoggedInUserName, LogDetail = "Fetching Menu Detail. User AD Group: " + UserAllADGroup, ModuleId = (int)AppModule.Cashwaterfall });

                return menuItems;
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "Auth.GetUserAndMenuData. AD Group: " + UserAllADGroup, ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        #endregion
    }
}