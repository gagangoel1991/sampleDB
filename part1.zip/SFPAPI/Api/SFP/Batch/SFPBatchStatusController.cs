﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP.DTO;
using SFPAPI.Api;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/sfp/batchstatus")]
    [Authorize]
    public class SfpBatchStatusController : SFPControllerBase, ISfpBatchStatusController
    {
        #region Variables  declaration and Construction
        private readonly ISfpBatchStatusService _sfpBatchService;
        private readonly ILoggerService _loggerService;

        public SfpBatchStatusController(ISfpBatchStatusService sfpBatchService, ILoggerService loggerService)
        {
            _sfpBatchService = sfpBatchService;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("SFP_BatchStatus", PermissionAccessType.View)]
        [HttpGet("batchData")]
        public ActionResult<BatchStatusDetailDto> GetSFPBatchStatusData()
        {
            BatchStatusDetailDto sfpBatchData = _sfpBatchService.GetSFPBatchStatusData();
            return Ok(sfpBatchData);
        }


        #endregion
    }
}
