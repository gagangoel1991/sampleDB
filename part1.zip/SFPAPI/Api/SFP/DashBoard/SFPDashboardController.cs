﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP;
using SFPAPI.Api;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/sfp/dashboard")]
    [Authorize]
    public class SfpDashboardController : SFPControllerBase, ISFPDashboardController
    {
        #region Variables  declaration and Construction
        private readonly ISFPDashboardService _sfpDashBoardService;
        private readonly ILoggerService _loggerService;

        public SfpDashboardController(ISFPDashboardService sfpDashBoardService, ILoggerService loggerService)
        {
            _sfpDashBoardService = sfpDashBoardService;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("SFP_DashBoard", PermissionAccessType.View)]
        [HttpGet("dashboardData")]
        public ActionResult<SfpDashBoardDataList> GetSFPDashBoardData()
        {
            SfpDashBoardDataList sfpDashBoardData = _sfpDashBoardService.GetSFPDashBoardData(LoggedInUserName);
            return Ok(sfpDashBoardData);
        }


        #endregion
    }
}
