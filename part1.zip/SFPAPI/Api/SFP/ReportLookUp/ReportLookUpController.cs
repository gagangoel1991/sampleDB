﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP.Model;
using SFPAPI.Api;
using System.Collections.Generic;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/sfp/reportlookup")]
    [Authorize]
    public class ReportLookUpController : SFPControllerBase
    {
        #region Variables  declaration and Construction
        private readonly IReportLookUpService _sfpReportLookUpService;
        private readonly ILoggerService _loggerService;

        public ReportLookUpController(IReportLookUpService sfpReportLookUpService, ILoggerService loggerService)
        {
            _sfpReportLookUpService = sfpReportLookUpService;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpGet("reportlookupData")]
        public ActionResult<List<ReportLookupDto>> GetReportLookupData()
        {
            List<ReportLookupDto> sfpReportLookUpData = _sfpReportLookUpService.GetReportLookupData();
            return Ok(sfpReportLookUpData);
        }

        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpPost("updateLookUpAction")]
        public ActionResult<int> UpdateLookUpActionWorkFlow(ReportLookupDto reportLookUpData)
        {
            int result = _sfpReportLookUpService.UpdateLookUpActionWorkFlow(LoggedInUserName, reportLookUpData.AuthorisationRequestStatus, reportLookUpData.ReportLookUpWorkPadId);
            return Ok(result);
        }

        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpGet("reportlookupDataById")]
        public ActionResult<ReportLookupDto> GetReportLookupDataById(int reportLookUWorkPadpId)
        {
            ReportLookupDto sfpReportLookUpData = _sfpReportLookUpService.GetReportLookupDataById(reportLookUWorkPadpId);
            return Ok(sfpReportLookUpData);
        }

        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpPost("insertLookUpData")]
        public ActionResult<ReportLookupDto> InsertReportLookUpData(ReportLookupDto reportLookUpData)
        {
            reportLookUpData.Changer = LoggedInUserName;
            ReportLookupDto insertResult = _sfpReportLookUpService.InsertReportLookUpData(reportLookUpData);
            return Ok(insertResult);
        }

        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpDelete("deleteLookUpData/{lookupId}")]
        public ActionResult<int> DeleteReportLookUpData(int lookupId)
        {
           int status = _sfpReportLookUpService.DeleteReportLookUpData(lookupId);
            return Ok(status);
        }

        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpGet("dashboardData")]
        public void SupportInsertReportLookUpData(ReportLookupModel reportLookUpData)
        {
            _sfpReportLookUpService.SupportInsertReportLookUpData(reportLookUpData);
        }

        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpPost("updateLookUpdata")]
        public ActionResult<ReportLookupDto> UpdateWorkpadReportLookUpData(ReportLookupDto reportLookUpData)
        {
            reportLookUpData.Changer = LoggedInUserName;
            ReportLookupDto sfpReportLookUpData = _sfpReportLookUpService.UpdateWorkpadReportLookUpData(reportLookUpData);
            return Ok(sfpReportLookUpData);
        }
    
        [SFPAuthorize("SFP_LookUpData", PermissionAccessType.View)]
        [HttpGet("refrencelookupData")]
        public ActionResult<ReportLookupReferenceDataDto> GetReportLookUpReferenceData()
        {
              ReportLookupReferenceDataDto refLookUpData = _sfpReportLookUpService.GetReportLookUpReferenceData();
            return Ok(refLookUpData);
        }

        #endregion
    }
}
