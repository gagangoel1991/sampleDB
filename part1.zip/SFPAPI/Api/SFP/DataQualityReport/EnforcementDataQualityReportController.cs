﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP;
using SFPAPI.Api;

namespace NW.SFPAPI.Api.PS
{
    /// <summary>
    /// Thsi controller is used to get Data-Quality-Report Data for Enforcement Files un new Upload Functionality
    /// </summary>
    [ApiController]
    [Produces("application/json")]
    [Route("api/sfp/dataQualityReport")]
    [Authorize]
    public class EnforcementDataQualityReportStatusController : SFPControllerBase, IEnforcementDataQualityReportController
    {
        #region Variables  declaration and Construction
        private readonly IEnforcementDataQualityReportService _enforcemetDataQualityReportService;

        /// <summary>
        /// Constructor
        /// </summary>
        /// <param name="sfpDataQualityReportService"></param>
        public EnforcementDataQualityReportStatusController(IEnforcementDataQualityReportService enforcemetDataQualityReportService)
        {
            _enforcemetDataQualityReportService = enforcemetDataQualityReportService;
        }
        #endregion

        #region Action Methods
        
        /// <summary>
        /// Get Enforcement Data Quality Report data
        /// </summary>
        /// <returns></returns>
        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("enforcementReportData")]
        public ActionResult<EnforcementDataQualityReport> GetEnforcementDataQualityReportData()
        {
            EnforcementDataQualityReport sfpDataQualityData = _enforcemetDataQualityReportService.GetEnforcementDataQualityReportData();
            return Ok(sfpDataQualityData);
        }

        /// <summary>
        /// Get data validation for Enforcement Reports 
        /// </summary>
        /// <returns></returns>
        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("enforcementValidation")]
        public ActionResult<int> GetEnforcementDataValidationStatus()
        {
            int sfpEnforcementValidation = _enforcemetDataQualityReportService.GetEnforcementDataValidationStatus();
            return Ok(sfpEnforcementValidation);
        }

        #endregion
    }
}
