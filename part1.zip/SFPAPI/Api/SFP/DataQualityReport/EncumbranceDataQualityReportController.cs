﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP;
using SFPAPI.Api;

namespace NW.SFPAPI.Api.PS
{
    /// <summary>
    /// Thsi controller is used to get Data-Quality-Report Data for Encumbrance Files un new Upload Functionality
    /// </summary>
    [ApiController]
    [Produces("application/json")]
    [Route("api/sfp/dataQualityReport")]
    [Authorize]
    public class EncumbranceDataQualityReportStatusController : SFPControllerBase, IEncumbranceDataQualityReportController
    {
        #region Variables  declaration and Construction
        private readonly IEncumbranceDataQualityReportService _encumbranceDataQualityReportService;

        public EncumbranceDataQualityReportStatusController(IEncumbranceDataQualityReportService encumbranceDataQualityReportService)
        {
            _encumbranceDataQualityReportService = encumbranceDataQualityReportService;
        }
        #endregion

        #region Action Methods
        
        /// <summary>
        /// Get Encumbrance data Quality Report for File Upload Functionality
        /// </summary>
        /// <returns></returns>
        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("encumbranceReportData")]
        public ActionResult<EncumbranceDataQualityReport> GetEncumbranceDataQualityReportData()
        {
            EncumbranceDataQualityReport encumbranceDataQualityData = _encumbranceDataQualityReportService.GetEncumbranceDataQualityReportData();
            return Ok(encumbranceDataQualityData);
        }



        /// <summary>
        /// Get data validation for Enforcement Reports 
        /// </summary>
        /// <returns></returns>
        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("encumbranceValidation")]
        public ActionResult<int> GetEncumbranceDataValidationStatus()
        {
            int sfpEncumbranceValidation = _encumbranceDataQualityReportService.GetEncumbrancedataValidationStatus();
            return Ok(sfpEncumbranceValidation);
        }
        #endregion
    }
}
