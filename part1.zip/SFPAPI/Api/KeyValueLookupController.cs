﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Cors;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Message;
using NW.SFP.Message.Core;
using NW.SFP.Message.CW;
using SFPAPI.Api;

namespace NW.SFP.API.Core
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/shared/lookup")]
    [Authorize]
    public class KeyValueLookupController : SFPControllerBase, IKeyValueLookupController
    {
        #region Variables  declaration and Construction
        private readonly IKeyValueLookupService _lookupService;

        private readonly ILoggerService _loggerService;

        public KeyValueLookupController(IKeyValueLookupService lookupService, ILoggerService loggerService)
        {
            this._lookupService = lookupService;
            this._loggerService = loggerService;
        }

        #endregion

        #region Action Methods

        [HttpGet("getdata")]
        public IList<KeyValueLookupEntity> GetKeyValueLookupData(string lookupTypeIds)
        {
            try
            {
                return this._lookupService.GetKeyValueLookupData(lookupTypeIds, LoggedInUserName);
            }
            catch(Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() {  ErrorMessage = ex.Message, ErrorMethod = "KeyValueLookupController.GetKeyValueLookupData"};
                this._loggerService.LogError(logError);

                throw ex;
            }

        }

        #endregion
    }
}