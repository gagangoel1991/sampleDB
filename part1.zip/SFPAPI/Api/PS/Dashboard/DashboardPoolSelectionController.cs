﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Linq;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/poolselection/dashboard/")]
    [Authorize]
    public class DashboardPoolSelectionController : SFPControllerBase, IDashboardPoolSelectionController
    {
        #region Variables  declaration and Construction
        private readonly IDashboardPoolSelectionService _dashboardPoolSelectionService;
        private readonly ILoggerService _loggerService;

        public DashboardPoolSelectionController(IDashboardPoolSelectionService dashboardServicePS, ILoggerService loggerService)
        {
            _dashboardPoolSelectionService = dashboardServicePS;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("PS_Dashboard", PermissionAccessType.View)]
        [HttpGet("summary/{assetClassId}")]
        public ActionResult<IList<DashboardSummary>> GetDashboardSummary(int assetClassId = 1)
        {
            List<DashboardSummary> dashboardSummary = _dashboardPoolSelectionService.GetDashboardSummary(LoggedInUserName, assetClassId).ToList();
            return Ok(dashboardSummary);
        }

        [SFPAuthorize("PS_Dashboard", PermissionAccessType.View)]
        [HttpGet("previouswork/{fromDate}/{toDate}/{assetClassId}")]
        public ActionResult<IList<DashboardSummary>> GetPreviousWork(DateTime fromDate, DateTime toDate, int assetClassId = 1)
        {
            List<DashboardSummary> dashboardSummary = _dashboardPoolSelectionService.GetPreviousWork(fromDate, toDate, LoggedInUserName, assetClassId).ToList();
            return Ok(dashboardSummary);
        }


        [SFPAuthorize("PS_Dashboard", PermissionAccessType.View)]
        [HttpGet("poolFlagDeflagData/{fromDate}/{toDate}/{assetClassId}")]
        public ActionResult<IList<DashBoardPoolData>> GetDashBoardCompletedPoolData(string fromDate, string toDate, int assetClassId = 1)
        {
            DateTime _fromdate = Convert.ToDateTime(fromDate);
            DateTime _todate = Convert.ToDateTime(toDate);
            List<DashBoardPoolData> dashboardPoolData = _dashboardPoolSelectionService.GetDashBoardCompletedPoolData(_fromdate, _todate, LoggedInUserName, assetClassId).ToList();
            return Ok(dashboardPoolData);
        }

        [SFPAuthorize("PS_Dashboard", PermissionAccessType.View)]
        [HttpGet("dealFlagDeflagData/{analysisDate}/{isInitial}/{assetClassId}")]
        public ActionResult<DealFlagDeFlagData> GetDashBoardDealsData(string analysisDate, bool IsInitial, int assetClassId = 1)
        {
            DateTime _analysisDate = Convert.ToDateTime(analysisDate);
            DealFlagDeFlagData dashboardPoolData = _dashboardPoolSelectionService.GetDashBoardDealsData(_analysisDate, LoggedInUserName, IsInitial, assetClassId);
            return Ok(dashboardPoolData);
        }

        [SFPAuthorize("PS_Dashboard", PermissionAccessType.View)]
        [HttpGet("failedPoolData/{analysisDate}/{assetClassId}")]
        public ActionResult<IList<DashBoardFailedPoolData>> GetFailedPoolData(string analysisDate, int assetClassId = 1)
        {
            DateTime _analysisDate = Convert.ToDateTime(analysisDate); 
            List<DashBoardFailedPoolData> dashboardPoolFailedData = _dashboardPoolSelectionService.GetFailedPoolData(_analysisDate, LoggedInUserName, assetClassId).ToList();
            return Ok(dashboardPoolFailedData);
        }

        #endregion
    }
}
