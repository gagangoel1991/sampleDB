﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/poolmanagement")]
    [Authorize]
    public class EligibilityController : SFPControllerBase, IEligibilityController
    {
        #region Variable Declarations and Constructor
        private readonly ILoggerService _loggerService;
        private readonly IEligibilityService _eligibilityController;
        public EligibilityController(IEligibilityService eligibilityController, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._eligibilityController = eligibilityController;
        }
        #endregion

        #region Get Eligibility Custom Fields
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("getECFieldList/{assetId}")]
        public IDictionary<string, EligibilityCriteria.Field> GetEligibilityFields(int assetId)
        {
            return _eligibilityController.GetEligibilityFields(assetId);
        }
        #endregion

        #region Get Eligibility Regulation
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("getECRegulation")]
        public ActionResult<IList<EligibilityCriteria.ECRegulation>> GetEligibilityRegulation()
        {
            return _eligibilityController.GetEligibilityRegulation().ToList();
        }
        #endregion

        #region Get Eligibility Type
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("getECType/{assetId}")]
        public ActionResult<IList<EligibilityCriteria.ECType>> GetEligibilityType(int assetId)
        {
            return _eligibilityController.GetEligibilityType(assetId).ToList();
        }
        #endregion

        #region Get Eligibility FieldInfo On Field Selection
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("getECFieldInfo")]
        public IList<EligibilityCriteria.FieldInfo> GetEligibilityFieldInfo(int fieldId)
        {
            return _eligibilityController.GetEligibilityFieldInfo(fieldId);
        }
        #endregion

        #region Save Eligibility
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.AddEdit)]
        [HttpPost("saveEC")]
        [HttpPut("saveEC")]
        public ActionResult<string> SaveEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes)
        {
            return _eligibilityController.SaveEligibilityCriteria(eligibilityCriteriaAttributes, LoggedInUserName);
        }
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.AddEdit)]
        [HttpPut("editEC")]
        public ActionResult<string> EditEligibilityCriteria(string ecid, EligibilityCriteriaAttributes eligibilityCriteriaAttributes)
        {
            return _eligibilityController.SaveEligibilityCriteria(eligibilityCriteriaAttributes, LoggedInUserName);
        }
        #endregion

        #region Amend Eligibility
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.AddEdit)]
        [HttpPost("amendEC")]
        public ActionResult<int> AmendEligibilityCriteria(EligibilityCriteriaAttributes eligibilityCriteriaAttributes)
        {
            return _eligibilityController.AmendEligibilityCriteria(eligibilityCriteriaAttributes, LoggedInUserName);
        }
        #endregion

        #region Get Eligibility; for Edit
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("getEC/{eligibilityId}/{assetId}")]
        public ActionResult<IList<EligibilityCriteriaDetail>> GetEligibilityCriteria(int eligibilityId, int assetId)
        {
            return _eligibilityController.GetEligibilityCriteria(eligibilityId, assetId).ToList();
        }
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("getECExp")]
        public ActionResult<IList<QueryExpressionDetail>> GetEligibilityCriteriaExpression(int eligibilityId)
        {
            return _eligibilityController.GetEligibilityCriteriaExpression(eligibilityId).ToList();
        }
        #endregion

        #region Get EligibilityCriterias
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("EligibilityCriteriasList/{assetId}")]
        public ActionResult<IList<EligibilityCriteriaList>> GetEligibilityCriterias(int assetId)
        {
            List<EligibilityCriteriaList> ecList = _eligibilityController.GetEligibilityCriterias(assetId, LoggedInUserName).ToList();
            return Ok(ecList);
        }

        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("EligibilityCriterias/EcPoolsReportData/{EcId}")]
        public ActionResult GetEcPoolsReportData(int EcId)
        {
            var stream = _eligibilityController.GetEcPoolsReportData(EcId, LoggedInUserName);
            if (stream != null)
            {
                return ConvertFileResultContent(EcId, stream.ToArray());
            }
            return null;
        }
        #endregion

        #region Delete EligibilityCriterias
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.Delete)]
        [HttpDelete("EligibilityCriterias/{ecId}")]
        public ActionResult<int> DeleteEligibility(int? ecId)
        {
            int result;

            int _ecId = Convert.ToInt32(ecId);
            result = _eligibilityController.DeleteEligibility(_ecId, LoggedInUserName);
            if (result == -1)
            {
                return NotFound(result);
            }
            return Ok(result);
        }
        #endregion

        #region Validate Ec Fields Status
        [SFPAuthorize("PS_EligibilityManagement", PermissionAccessType.View)]
        [HttpGet("validateEcFields/{eligibilityId}")]
        public ActionResult<bool> ValidateEcFields(int eligibilityId)
        {
            return this._eligibilityController.ValidateEcFields(eligibilityId);
        }
        #endregion

        #region Private Methods
        private ActionResult ConvertFileResultContent(int EcId, byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $"Export_{ EcId}.xlsx");
        }
        #endregion

    }
}