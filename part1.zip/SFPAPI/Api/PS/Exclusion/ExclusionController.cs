﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using ClosedXML.Excel;
using System.IO;
using System.Linq;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/exclusionmanagement")]
    [Authorize]
    public class ExclusionController : SFPControllerBase, IExclusionController
    {
        #region Variables  declaration and Construction
        private readonly IExclusionService _exclusionService;
        private readonly ILoggerService _loggerService;

        public ExclusionController(IExclusionService exclusionService, ILoggerService loggerService)
        {
            _exclusionService = exclusionService;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods

        [SFPAuthorize("PS_ExclusionManagement", PermissionAccessType.View)]
        [HttpGet("getExclusion")]
        public ActionResult<Exclusion> GetExclusionById(int exclusionId)
        {
            Exclusion exclusion = _exclusionService.GetExclusionByID(exclusionId, LoggedInUserName);
            return Ok(exclusion);
        }

        [SFPAuthorize("PS_ExclusionManagement", PermissionAccessType.AddEdit)]
        [HttpPost("createExclusion")]
        public ActionResult<int> CreateExclusion([FromBody]Exclusion exclusion)
        {
            int rowsAffected = _exclusionService.CreateExclusion(exclusion, LoggedInUserName);

            if (rowsAffected < 1)
            {
                return BadRequest();
            }

            return Ok(rowsAffected);
        }

        [SFPAuthorize("PS_ExclusionManagement", PermissionAccessType.AddEdit)]
        [HttpPost("exclusions/validateUpload")]
        public ActionResult<IList<ExclusionValidationResult>> ValidateExclusion(Exclusion exclusion)
        {
            var result = _exclusionService.ValidateExclusion(exclusion, LoggedInUserName);
            return Ok(result);
        }
        #endregion

        [SFPAuthorize("PS_ExclusionManagement", PermissionAccessType.View)]
        [HttpGet("exclusions/export/activityLog")]
        public ActionResult<ExclusionData> GetExclusionManagementData()
        {
            var result = _exclusionService.GetExclusionManagementData(LoggedInUserName);
            return Ok(result);
        }

        #region Private Methods
        private ActionResult ExcelSheet(Exclusion exclusion)
        {
            using (var workbook = new XLWorkbook())
            {
                var worksheet = workbook.Worksheets.Add($"Exclusions");
                var currentRow = 1;
                worksheet.Cell(currentRow, 1).Value = "LoanNumber";
                worksheet.Cell(currentRow, 2).Value = "Reason";

                foreach (var exclusionItem in exclusion.ExclusionItems)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = exclusionItem.LoanNumber;
                    worksheet.Cell(currentRow, 2).Value = exclusionItem.Reason;
                }

                using (var stream = new MemoryStream())
                {
                    workbook.SaveAs(stream);
                    var content = stream.ToArray();
                    return File(content,"application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",exclusion.UploadedFileName);
                }
            }
        }
        #endregion
    }
}
