﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS.ApiController;
using NW.SFP.Interface.PS.BusinessService;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/adhocReport")]
    [Authorize]
    public class PoolAdhocReportController : SFPControllerBase, IPoolAdhocReportController
    {

        #region Variable Declarations and Constructor
        private readonly IPoolAdhocReportService _poolAdhocReportService;
        public PoolAdhocReportController(IPoolAdhocReportService poolAdhocReportService)
        {
            _poolAdhocReportService = poolAdhocReportService;
        }
        #endregion

        #region Public Actions
        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("reports/{assetClassId}")]
        public ActionResult<IList<PoolAdhocReportTemplateList>> GetAdhocReports(int assetClassId)
        {
            List<PoolAdhocReportTemplateList> poolAdhocReports = _poolAdhocReportService.GetAdhocReports(LoggedInUserName, assetClassId).ToList();
            return Ok(poolAdhocReports);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("fields/{assetClassId}")]
        public ActionResult<IList<AdhocReportField>> GetFieldsForReports(int assetClassId)
        {
            List<AdhocReportField> poolAdhocReports = _poolAdhocReportService.GetFieldsForReports(LoggedInUserName, assetClassId).ToList();
            return Ok(poolAdhocReports);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("reportTemplate/{reportTemplateId}")]
        public ActionResult<ReportTemplateData> GetReportTemplateData(int reportTemplateId)
        {
            ReportTemplateData reportTemplateData = _poolAdhocReportService.GetReportTemplateData(reportTemplateId, LoggedInUserName);
            return Ok(reportTemplateData);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.AddEdit)]
        [HttpPost("save")]
        public ActionResult<int> SaveReportTemplateData([FromBody] ReportTemplateData reportTemplateData)
        {
            int result = _poolAdhocReportService.SaveReportTemplateData(reportTemplateData, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.Delete)]
        [HttpDelete("deleteTemplate/{reportTemplateId}")]
        public ActionResult<int> DeleteReportTemplateData(int reportTemplateId)
        {
            int result = _poolAdhocReportService.DeleteReportTemplateData(reportTemplateId, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("reportRefData/{assetClassId}")]
        public ActionResult<AdhocReportRefData> GetReportRefData(int assetClassId = 1)
        {
            var adhocReportRefs = _poolAdhocReportService.GetReportRefData(LoggedInUserName, assetClassId);
            return Ok(adhocReportRefs);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("generateReport/{reportTemplateId}/{poolId}/{isCsv}")]
        public ActionResult GenerateReportData(int reportTemplateId, int poolId, bool isCsv)
        {
            var stream = _poolAdhocReportService.GenerateReportData(reportTemplateId, poolId, LoggedInUserName, null, Convert.ToBoolean(isCsv));
            if (stream != null)
            {
                if (isCsv)
                    return ConvertFileResultContentCsv(poolId, stream.ToArray());

                return ConvertFileResultContent(poolId, stream.ToArray());
            }
            return null;
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("reportAggregationMap")]
        public ActionResult<IDictionary<int, List<AdhocReportOperator>>> GetDatatypeAggregationMap()
        {
            var result = _poolAdhocReportService.GetDatatypeAggregationMap(LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpPatch("generateReport/{poolId}/{isCsv}")]
        public ActionResult GenerateReportData(int poolId, [FromBody] ReportTemplateData reportTemplateData, bool isCsv)
        {
            var stream = _poolAdhocReportService.GenerateReportData(0, poolId, LoggedInUserName, reportTemplateData, Convert.ToBoolean(isCsv));
            if (stream != null)
            {
                if (isCsv)
                    return ConvertFileResultContentCsv(poolId, stream.ToArray());

                return ConvertFileResultContent(poolId, stream.ToArray());
            }
            return null;
        }

        [SFPAuthorize("PS_AdhocReportManagement", PermissionAccessType.View)]
        [HttpGet("getAdhocReportTypeList")]
        public ActionResult<IList<AdhocReportTypeEntity>> GetAdhocReportTypeList()
        {
            return Ok(_poolAdhocReportService.GetAdhocReportTypeList(LoggedInUserName));
        }

        #endregion

        #region private methods
        private ActionResult ConvertFileResultContent(int poolId, byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $"PoolReport_{ poolId}.xlsx");
        }


        private ActionResult ConvertFileResultContentCsv(int poolId, byte[] content)
        {
            return File(
                   content,
                   "text/csv",
                     $"PoolReport_{ poolId}.csv");
        }
        #endregion
    }
}
