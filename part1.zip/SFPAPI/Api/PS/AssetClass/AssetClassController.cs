﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/poolmanagement")]
    [Authorize]
    public class AssetClassController : SFPControllerBase, IAssetClassController
    {
        #region Variable Declarations and Constructor
        private readonly IAssetClassService _eligibilityController;
        public AssetClassController(IAssetClassService eligibilityController)
        {
            this._eligibilityController = eligibilityController;
        }
        #endregion

        #region Get AssetClass
        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("getAssetClass")]
        public ActionResult<IList<AssetClass>> GetAssetClass()
        { 
                return _eligibilityController.GetAssetClass().ToList(); 
        }
        #endregion
    }
}
