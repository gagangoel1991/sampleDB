﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using ClosedXML.Excel;
using System.IO;
using System.Linq;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/replinceReport")]
    [Authorize]
    public class ReplinseReportController : SFPControllerBase, IReplinesReportController
    {
        #region Variables  declaration and Construction
        private readonly IReplinesReportService _replineReportService;
        private readonly ILoggerService _loggerService;

        public ReplinseReportController(IReplinesReportService replinceReportService, ILoggerService loggerService)
        {
            _replineReportService = replinceReportService;
            _loggerService = loggerService;
        }
        #endregion

        [SFPAuthorize("PS_ReplinesReport", PermissionAccessType.View)]
        [HttpGet("reportData/{inceptionDate}/{dealKey}")]
        public ActionResult GetReplinesReportData(string inceptionDate, int dealKey)
        {
            DateTime _inceptionDate;
            if (DateTime.TryParse(inceptionDate, out _inceptionDate))
            {
                var stream = _replineReportService.GetReplinesReportData(_inceptionDate, dealKey, LoggedInUserName);
                if (stream != null)
                {
                    return ConvertFileResultContent(_inceptionDate, stream.ToArray());
                }
            }
            return null;
        }
        
        #region Private Methods
       

        private ActionResult ConvertFileResultContent(DateTime inceptionDate, byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $"Replinesreport_"+ inceptionDate +".xlsx");
        }
        #endregion
    }
}
