﻿using ClosedXML.Excel;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/poolmanagement")]
    [Authorize]
    public class PoolController : SFPControllerBase, IPoolController
    {
        #region Variables  declaration and Construction
        private readonly IPoolService _poolService;
        
        public PoolController(IPoolService poolService)
        {
            _poolService = poolService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("poolsList/{assetId}")]
        public ActionResult<IList<PoolList>> GetPools(int assetId)
        {
            List<PoolList> pools = _poolService.GetPools(assetId, LoggedInUserName).ToList();
            return Ok(pools);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.Delete)]
        [HttpDelete("pools/{poolId}")]
        public ActionResult<int> DeletePool(int poolId)
        {
            int result;

            int _poolId = Convert.ToInt32(poolId);
            result = _poolService.DeletePool(_poolId, LoggedInUserName);
            if (result == -1)
            {
                return NotFound(result);
            }
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/{poolId}")]
        public ActionResult<Pool> GetPoolById(int poolId)
        {
            int _poolId = Convert.ToInt32(poolId);
            Pool pool = _poolService.GetPoolById(_poolId, LoggedInUserName);
            if (pool.Id == null)
            {
                return NotFound();
            }
            return Ok(pool);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/{poolId}/SourceDealSummary")]
        public ActionResult<IList<PoolSourceDealSummary>> GetPoolSourceDealSummaryById(int poolId)
        {
            int _poolId = Convert.ToInt32(poolId);
            List<PoolSourceDealSummary> poolSummaryReport = _poolService.GetPoolSourceDealSummaryById(_poolId, LoggedInUserName).ToList();
            return Ok(poolSummaryReport);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.AddEdit)]
        [HttpPost("pools")]
        public ActionResult<int> CreatePool([FromBody] Pool pool)
        {
            int poolId = _poolService.CreatePool(pool, LoggedInUserName);
            return Ok(poolId);

        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.AddEdit)]
        [HttpPut("pools")]
        public ActionResult<int> UpdatePool([FromBody] Pool pool)
        {
            int returnCode = _poolService.UpdatePool(pool, LoggedInUserName);
            return Ok(returnCode);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.AddEdit)]
        [HttpGet("buildPools/{poolId}/{assetId}")]
        public ActionResult<IList<Pool>> BuildPool(int poolId, int assetId=1)
        {
            return _poolService.BuildPool(Convert.ToInt32(poolId), LoggedInUserName, assetId).ToList();
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("exportData/{poolId}/{reportTypeId}/{assetClassId}")]
        public ActionResult ExportAdvanceSourceData(int? poolId, int reportTypeId, int assetClassId = 1)
        {
            int _poolId;
            _poolId = Convert.ToInt32(poolId);
            var advanceSourceData = _poolService.ExportAdvanceSourceData(_poolId, LoggedInUserName, reportTypeId, assetClassId);
            if (assetClassId == 1)
            {
                return ExcelSheet(poolId, advanceSourceData, reportTypeId);
            }
            else
            {
                return ExcelSheetCB(poolId, advanceSourceData, reportTypeId);
            }
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.AddEdit)]
        [HttpPost("validateUpload/{vintageDate}/{isRemoveDuplicates}/{AssetClassId}")]
        public ActionResult<UploadValidationResult> ValidateUploadAssets(IList<long> assets, string vintageDate, bool isRemoveDuplicates = false, int AssetClassId = 1)
        {
            var result = _poolService.ValidateUploadAssets(assets, vintageDate, LoggedInUserName, Convert.ToBoolean(isRemoveDuplicates), AssetClassId);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("validateDrillThrough/{poolId}/{assetClassId}")]
        public ActionResult<int> ValidateDrillThroughReport(int poolId, int assetClassId = 1)
        {
            var result = _poolService.ValidateDrillThroughReport(poolId, LoggedInUserName, assetClassId);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("validateEligibilityReport/{poolId}/{assetClassId}")]
        public ActionResult<int> ValidateEligibilityReport(int poolId, int assetClassId = 1)
        {
            var result = _poolService.ValidateEligibilityReport(poolId, LoggedInUserName, assetClassId);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("poolaccounts/{poolId}/{dealId}/{vintageDate}")]
        public ActionResult<IList<PoolAccount>> GetPoolLoanList(int poolId, string dealId, string vintageDate)
        {
            List<PoolAccount> poolLoans = _poolService.GetPoolDetailsById(poolId, dealId, vintageDate, LoggedInUserName).ToList();
            return Ok(poolLoans);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("poolaccounts/getinclusionreasons")]
        public ActionResult<IList<LoanInclusionReason>> GetInclusionReasonList()
        {
            List<LoanInclusionReason> inclusionReasonList = _poolService.GetPoolInclusionReasons().ToList();
            return Ok(inclusionReasonList);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.AddEdit)]
        [HttpPost("poolaccountsupdate")]
        public ActionResult<int> UpdatePoolAccounts(PoolAccountData poolAccountData)
        {
            var result = _poolService.UpdatePoolAccounts(poolAccountData.PoolAccounts, poolAccountData.PoolId, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("generateReport/{poolId}/{poolReportType}/{assetClassId}")]
        public ActionResult GenerateDrillThroughReport(int poolId, int poolReportType, int assetClassId = 1)
        {
            if (assetClassId == 1)
            {
                if (poolReportType == 2)
                {
                    var stream = _poolService.GenerateDrillThroughReport(poolId, LoggedInUserName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent(poolId, stream.ToArray());
                    }
                }
                else
                {
                    var stream = _poolService.GenerateDetailedReport(poolId, LoggedInUserName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent(poolId, stream.ToArray());
                    }
                }
            }
            else if (assetClassId == 2)
            {
                MemoryStream clReportStream = _poolService.GenerateEligibilityCriteriaReportsForCB(poolId, poolReportType, LoggedInUserName);
                if (clReportStream != null)
                {
                    return ConvertFileResultContent(poolId, clReportStream.ToArray());
                }
            }
            
            return null;
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("brandList")]
        public ActionResult<IList<BrandList>> GetBrandList()
        {
            List<BrandList> blist = _poolService.GetBrandList().ToList();
            return Ok(blist);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.AddEdit)]
        [HttpPost("submitPool")]
        public ActionResult<int> ValidateSubmitAndUpdatePool([FromBody] SubmittedPoolData submittedPoolData)
        {
            var result = _poolService.ValidateSubmitAndUpdatePool(submittedPoolData, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.ApproveReject)]
        [HttpPatch("pools/{poolId}/{isRejected}/{ModifiedDate}")]
        public ActionResult<int> UpdatePoolAuthorisationStatus(int poolId, bool isRejected, [FromBody] string comments, DateTime ModifiedDate)
        {
            int result;
            int _poolId = Convert.ToInt32(poolId);
            result = _poolService.UpdatePoolAuthorisationStatus(_poolId, isRejected, comments, LoggedInUserName, ModifiedDate);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/{poolId}/GetDependentPools")]
        public ActionResult<IList<int>> GetDependentPools(int poolId)
        {
            int _poolId = Convert.ToInt32(poolId);
            IList<int> result = _poolService.GetDependentPools(_poolId, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/{poolId}/{isQueueRequired}/ValidateSubmittedLoans")]
        public ActionResult<PoolValidationSummary> ValidateSubmittedLoans(int poolId, bool isQueueRequired)
        {
            int _poolId = Convert.ToInt32(poolId);
            PoolValidationSummary result = _poolService.ValidateSubmittedLoans(_poolId, isQueueRequired, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/{poolId}/ValidateExclusionChangeImpact")]
        public ActionResult<PoolExclusionChangeImpact> ValidateExclusionChangeImpact(int poolId)
        {
            PoolExclusionChangeImpact result = _poolService.ValidateExclusionChangeImpact(poolId, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/RegionsWithHoliday/{poolId}/{effectiveDate}")]
        public ActionResult<IList<string>> GetPoolRegionWithHoliday(int poolId, string effectiveDate)
        {
            IList<string> result = _poolService.GetPoolRegionWithHoliday(poolId, effectiveDate, LoggedInUserName);
            return Ok(result);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/PoolEcAndCtReportData/{PoolId}/{assetClassId}")]
        public ActionResult GetPoolEcAndCtReportData(int PoolId, int assetClassId = 1)
        {
            var stream = _poolService.GetPoolEcAndCtReportData(PoolId, LoggedInUserName, assetClassId);
            if (stream != null)
            {
                return ConvertFileResultContent(PoolId, stream.ToArray());
            }
            return null;
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/PoolSourceDeals/{PoolId}")]
        public string GetPoolSourceDealsById(int PoolId)
        {
            return _poolService.GetPoolSourceDealsById(PoolId, LoggedInUserName);
        }


        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/checkForPoolSubmissionQueue/{PoolId}")]
        public ActionResult<bool> IsCurrentPoolInSubmissionQueue(int PoolId)
        {
            return _poolService.IsCurrentPoolInSubmissionQueue(PoolId);
        }

        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/PoolLastFlagDate/{PoolId}")]
        public string GetPoolLastFlagDateById(int PoolId)
        {
            return _poolService.GetPoolLastFlagDateById(PoolId, LoggedInUserName);
        }

        #endregion

        #region Private Methods
        private ActionResult ExcelSheet(int? poolId, IList<ExportAdvanceSourceData> advanceSourceData, int reportTypeId)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet = workbook.Worksheets.Add($"Export_{ poolId}");
                if (reportTypeId == 3)
                {                    
                    var currentRow = 1;
                    worksheet.Cell(currentRow, 1).Value = "Vintage Date";
                    worksheet.Cell(currentRow, 2).Value = "LoanIdentifier";
                    worksheet.Cell(currentRow, 3).Value = "DealName";
                    worksheet.Cell(currentRow, 4).Value = "BrandCode";
                    worksheet.Cell(currentRow, 5).Value = "TrueBalance";
                    worksheet.Cell(currentRow, 6).Value = "OutstandingCapitalBalanceAmount";

                    foreach (var data in advanceSourceData)
                    {
                        currentRow++;
                        worksheet.Cell(currentRow, 1).Value = data.VintageDate;
                        worksheet.Cell(currentRow, 2).Value = data.LoanId;
                        worksheet.Cell(currentRow, 3).Value = data.DealName;
                        worksheet.Cell(currentRow, 4).Value = data.BrandID;
                        worksheet.Cell(currentRow, 5).Value = data.TrueBalance == null ? "0" : string.Format("{0:N}", data.TrueBalance);
                        worksheet.Cell(currentRow, 6).Value = data.OutstandingCapitalBalance == null ? "0" : string.Format("{0:N}", data.OutstandingCapitalBalance);
                    }
                }
                else
                {
                    var currentRow = 1;
                    var currentSheet = 1;
                    setHeaders(worksheet, currentRow);
                    foreach (var data in advanceSourceData)
                    {
                        currentRow++;
                        if (currentRow > 1048576)
                        {
                            currentSheet++;
                            worksheet = workbook.Worksheets.Add($"Export_{ poolId}_{currentSheet}");
                            currentRow = 1;
                            setHeaders(worksheet, currentRow);
                            currentRow++;
                        }
                        worksheet.Cell(currentRow, 1).Value = data.VintageDate;
                        worksheet.Cell(currentRow, 2).Value = data.LoanId;
                        worksheet.Cell(currentRow, 3).Value = data.SubAccountId;
                        worksheet.Cell(currentRow, 4).Value = data.DealName;
                        worksheet.Cell(currentRow, 5).Value = data.BrandID;
                        worksheet.Cell(currentRow, 6).Value = data.TrueBalance == null ? "0" : string.Format("{0:N}", data.TrueBalance);
                        worksheet.Cell(currentRow, 7).Value = data.OutstandingCapitalBalance == null ? "0" : string.Format("{0:N}", data.OutstandingCapitalBalance);
                    }
                }
                workbook.SaveAs(stream);
                var content = stream.ToArray();
                return File(
                    content,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    $"Export_{ poolId}.xlsx");
            }
        }

        private ActionResult ExcelSheetCB(int? poolId, IList<ExportAdvanceSourceData> advanceSourceData, int reportTypeId)
        {
            using (var workbook = new XLWorkbook())
            using (var stream = new MemoryStream())
            {
                var worksheet = workbook.Worksheets.Add($"Export_{ poolId}");
                
                var currentRow = 1;
                worksheet.Cell(currentRow, 1).Value = "Vintage Date";
                worksheet.Cell(currentRow, 2).Value = "FacilityIdentifier";
                worksheet.Cell(currentRow, 3).Value = "DealName";
                worksheet.Cell(currentRow, 4).Value = "TotalCreditLimit(GBP)";
                worksheet.Cell(currentRow, 5).Value = "Utilisation(GBP)";
                worksheet.Cell(currentRow, 6).Value = "RONA(GBP)";
                worksheet.Cell(currentRow, 7).Value = "CISCode";

                foreach (var data in advanceSourceData)
                {
                    currentRow++;
                    worksheet.Cell(currentRow, 1).Value = data.VintageDate;
                    worksheet.Cell(currentRow, 2).Value = data.LoanId;
                    worksheet.Cell(currentRow, 3).Value = data.DealName;
                    worksheet.Cell(currentRow, 4).Style.NumberFormat.Format = "#,###,##0.00";
                    worksheet.Cell(currentRow, 4).Value = data.TrueBalance == null ? "0" : string.Format("{0:N}", data.TrueBalance);
                    worksheet.Cell(currentRow, 5).Style.NumberFormat.Format = "#,###,##0.00";
                    worksheet.Cell(currentRow, 5).Value = data.OutstandingCapitalBalance == null ? "0" : string.Format("{0:N}", data.OutstandingCapitalBalance);
                    worksheet.Cell(currentRow, 6).Style.NumberFormat.Format = "#,###,##0.00";
                    worksheet.Cell(currentRow, 6).Value = data.Rona == null ? "0" : string.Format("{0:N}", data.Rona);
                    worksheet.Cell(currentRow, 7).Value = data.CisCode;
                }

                workbook.SaveAs(stream);
                var content = stream.ToArray();
                return File(
                    content,
                    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    $"Export_{ poolId}.xlsx");
            }
        }

        private void setHeaders(IXLWorksheet worksheet, int currentRow)
        {
            worksheet.Cell(currentRow, 1).Value = "Vintage Date";
            worksheet.Cell(currentRow, 2).Value = "LoanIdentifier";
            worksheet.Cell(currentRow, 3).Value = "SubAccountId";
            worksheet.Cell(currentRow, 4).Value = "DealName";
            worksheet.Cell(currentRow, 5).Value = "BrandCode";
            worksheet.Cell(currentRow, 6).Value = "TrueBalance";
            worksheet.Cell(currentRow, 7).Value = "OutstandingCapitalBalanceAmount";
        }

        private ActionResult ConvertFileResultContent(int poolId, byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $"Export_{ poolId}.xlsx");
        }
        #endregion
    }
}
