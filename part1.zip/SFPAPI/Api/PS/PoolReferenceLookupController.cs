﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/poolmanagement")]
    [Authorize]
    public class PoolReferenceLookupController : SFPControllerBase, IPoolReferenceLookupController
    {
        #region Variables  declaration and Construction
        private readonly IPoolReferenceLookupService _poolReferenceLookupService;
        
        public PoolReferenceLookupController(IPoolReferenceLookupService poolService)
        {
            _poolReferenceLookupService = poolService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("PS_PoolManagement", PermissionAccessType.View)]
        [HttpGet("pools/referencedata/{assetId}")]
        public ActionResult<PoolReferenceData> GetPoolReferenceData(int assetId)
        {
            PoolReferenceData PoolReferenceData = _poolReferenceLookupService.GetPoolReferenceData(LoggedInUserName, assetId);
            return Ok(PoolReferenceData);
        }

        #endregion

    }
}
