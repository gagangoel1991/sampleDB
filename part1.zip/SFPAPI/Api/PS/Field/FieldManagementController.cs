﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/poolmanagement")]
    [Authorize]
    public class FieldManagementController : SFPControllerBase, IFieldManagementController
    {
        #region Variable Declarations and Constructor
        private readonly ILoggerService _loggerService;
        private readonly IFieldManagementService _fieldController;
        public FieldManagementController(IFieldManagementService fieldController, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._fieldController = fieldController;
        }
        #endregion

        #region Get Fields Data

        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getFieldsData/{assetId}")]
        public IDictionary<string, FieldManagement.FieldInfo> GetFieldsData(int assetId, string fieldType)
        {
            return _fieldController.GetFieldsData(assetId, fieldType);
        }
        #endregion

        #region Get Fields Data Type
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getFieldsDataType")]
        public ActionResult<IList<FieldManagement.FieldDataType>> GetFieldsDataType()
        {
            return _fieldController.GetFieldsDataType().ToList();
        }
        #endregion

        #region Get Functions
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getArithmeticOperators")]
        public ActionResult<IList<BasicLookUpData>> GetArithmeticOperators()
        {
            return _fieldController.GetArithmeticOperators().ToList();            
        }
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getFunctions")]
        public ActionResult<IList<FieldFunction>> GetFunctions()
        {
            return _fieldController.GetFunctions(LoggedInUserName).ToList();
        }
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getFunctionDetail")]
        public ActionResult<FieldFunction> GetFunctionDetail(int functionId)
        {
            return _fieldController.GetFunctionDetail(functionId, LoggedInUserName);
        }
        #endregion

        #region Save Field
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.AddEdit)]
        [HttpPost("saveField")]
        [HttpPut("saveField")]
        public ActionResult<string> SaveCustomField(FieldManagement.CustomFieldAttribute customFieldDetail)
        {
            return _fieldController.SaveCustomField(customFieldDetail, LoggedInUserName);
        }
        #endregion

        #region Amend Custom Field
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.AddEdit)]
        [HttpPost("amendCustomField")]
        public ActionResult<int> AmendCustomField(FieldManagement.CustomFieldAttribute customFieldAttribute)
        {
            return _fieldController.AmendCustomField(customFieldAttribute, LoggedInUserName);
        }
        #endregion

        #region Get Field
        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getField")]
        public ActionResult<FieldManagement.CustomFieldDetail> GetCustomFieldDetail(int fieldId)
        {
            try
            {
                return _fieldController.GetCustomFieldDetail(fieldId);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "FieldManagementController.GetCustomFieldDetail", ModuleId = (int)AppModule.PoolSelection, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }
        #endregion

        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getFieldList/{assetId}")]
        public ActionResult<IList<Field>> GetFieldList(int assetId)
        {
            var fields = _fieldController.GetFields(assetId, LoggedInUserName);
            return Ok(fields);
        }

        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.Delete)]
        [HttpDelete("deleteField/{fieldId}")]
        public ActionResult<int> DeleteField(int fieldId)
        {
            var rowsAffected = _fieldController.DeleteField(fieldId, LoggedInUserName);
            if (rowsAffected == -1)
            {
                return NotFound(rowsAffected);
            }
            return Ok(rowsAffected);
        }

        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.View)]
        [HttpGet("getECByField")]
        public ActionResult<IList<EligibilityCriteriaAttributes>> GetECByField(int fieldId)
        {
            return _fieldController.GetECByField(fieldId, LoggedInUserName).ToList();
        }

        [SFPAuthorize("PS_FieldManagement", PermissionAccessType.AddEdit)]
        [HttpPost("updateECsOnFieldChange")]
        public ActionResult<int> UpdateECsOnFieldChange(FieldRename fieldNameChangeModel)
        {
            return _fieldController.UpdateECsOnFieldChange(fieldNameChangeModel, LoggedInUserName);
        }
    }
}