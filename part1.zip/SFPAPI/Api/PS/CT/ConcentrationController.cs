﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using System;
using System.Collections.Generic;
using System.Linq;

namespace SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/concentrationmanagement")]
    [Authorize]
    public class ConcentrationController : SFPControllerBase, IConcentrationController
    {
        #region Variables  declaration and Construction
        private readonly IConcentrationService _ctService;
        private readonly ILoggerService _loggerService;

        public ConcentrationController(IConcentrationService ctService, ILoggerService loggerService)
        {
            _ctService = ctService;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.View)]
        [HttpPost("ct/saveConcentration")]
        public ActionResult<string> SaveConcentration(ConcentrationTest concentrationTest)
        {
            return _ctService.SaveConcentration(concentrationTest, LoggedInUserName);
        }

        #region Amend Concentration Test
        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.AddEdit)]
        [HttpPost("ct/amendConcentration")]
        public ActionResult<int> AmendConcentration(ConcentrationTest concentrationTest)
        {
            return _ctService.AmendConcentration(concentrationTest, LoggedInUserName);
        }
        #endregion


        #region Get Concentration Tests

        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.View)]
        [HttpGet("ct/getconcentrationtestlist")]
        public ActionResult<IList<ConcentrationTestList>> GetConcentrationTestList(int assetClassId)
        {
            List<ConcentrationTestList> ecList = _ctService.GetConcentrationTestList(assetClassId, LoggedInUserName).ToList();
            return Ok(ecList);
        }
        #endregion


        #region Get Concentration Tests By ID

        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.View)]
        [HttpGet("ct/getConcentration")]
        public ActionResult<ConcentrationTest> GetConcentrationTestbyId(int? concentrationTestId)
        {
            int _ctId = Convert.ToInt32(concentrationTestId);
            return _ctService.GetConcentrationTestByID(_ctId);
        }
        #endregion


        #region Delete Concentration Tests

        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.Delete)]
        [HttpDelete("ct/deleteConcentration/{ctId}")]
        public ActionResult<int> DeleteConcentrationTest(int? ctId)
        {
            int result;
            int _ctId = Convert.ToInt32(ctId);
            result = _ctService.DeleteConcentrationTest(_ctId, LoggedInUserName);
            if (result == -1)
            {
                return NotFound(result);
            }
            return Ok(result);
        }
        #endregion

        #endregion
    }
}