﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/concentrationmanagement")]
    [Authorize]
    public class ConcentrationReferenceLookupController : SFPControllerBase, IConcentrationlReferenceLookupController
    {
        #region Variables  declaration and Construction
        private readonly IConcentrationReferenceLookupService _ctReferenceLookupService;
        private readonly ILoggerService _loggerService;

        public ConcentrationReferenceLookupController(IConcentrationReferenceLookupService ctService, ILoggerService loggerService)
        {
            _ctReferenceLookupService = ctService;
            _loggerService = loggerService;
        }
        #endregion

        #region Action Methods
        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.View)]
        [HttpGet("ct/referencedata")]
        public ActionResult<ConcentrationReferenceData> GetConcentrationReferenceData(int assetClassId)
        {
            ConcentrationReferenceData ctReferenceData = _ctReferenceLookupService.GetConcentrationReferenceData(assetClassId, LoggedInUserName);
            return Ok(ctReferenceData);
        }

        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.View)]
        [HttpGet("ct/fieldData")]
        public ActionResult<List<BasicLookUpData>> GetConcentrationFieldsData(string type, int assetClassId)
        {
            List<BasicLookUpData> ctFieldData = _ctReferenceLookupService.GetConcentrationFieldsData(type, assetClassId, LoggedInUserName);
            return Ok(ctFieldData);
        }

        [SFPAuthorize("PS_ConcentrationManagement", PermissionAccessType.View)]
        [HttpGet("ct/fieldRefData")]
        public ActionResult<ConcentrationFieldReferenceData> GetConcentrationFieldReferenceData(int fieldId)
        {
            ConcentrationFieldReferenceData ctFieldRefData = _ctReferenceLookupService.GetConcentrationFieldReferenceData(fieldId, LoggedInUserName);
            return Ok(ctFieldRefData);
        }
        #endregion
    }
}
