﻿namespace NW.SFP.API.CW
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using NW.SFP.API.Core.Auth;
    using NW.SFP.API.Core.Constants;
    using NW.SFP.BusinessService.CW;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Interface.Report;
    using NW.SFP.Message.Core;
    using NW.SFP.Message.CW;
    using System;
    using System.IO;
    using System.Collections.Generic;
    using System.Linq;
    using global::SFPAPI.Api;
    using NW.SFP.Message.Report;
    using NW.SFP.Message.CW.IR;
    using NW.SFP.Common;

    [ApiController]
    [Produces("application/json")]
    [Route("api/report/")]
    [Authorize]
    public class InvestorReportController : SFPControllerBase
    {
        #region Variables  declaration and Construction

        private readonly ILoggerService _loggerService;
        private readonly IInvestorReportService _investorReportService;
        private IrReportService _reportService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;
        private IExcelService _excelService;
        private IAutomatedPostWaterfallControlService _automatedPostWFService;
        private InvestorReportResultEntity reportModel;

        private string parentWorkSheet;
        private string dealName;


        public InvestorReportController(IInvestorReportService InvestorReportService, ILoggerService loggerService, IrReportService ReportService, IExcelService ExcelService
            , IOptions<CashWaterfallSettings> cwSettings, IAutomatedPostWaterfallControlService automatedPostWFService)
        {

            this._loggerService = loggerService;
            this._cwSettings = cwSettings;
            _reportService = ReportService;
            _excelService = ExcelService;
            this._automatedPostWFService = automatedPostWFService;
            this._investorReportService = InvestorReportService;
            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;
        }

       
        #endregion

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("investorreportfilename/{dealId}/{ipdDate}/{formatType}")]
        public ActionResult GetInvestorReportFile(int dealId, string ipdDate, string formatType)
        {
            try
            {
                var data = _investorReportService.GetInvestorReportFileName(dealId, ipdDate, formatType);
                return Ok(data);
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvestorReportController.GetInvestorReportFile", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }

        }
        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("DownloadInvestorReport/{fileName}")]
        public IActionResult DownloadInvestorReport(string fileName)
        {
            try
            {
                
                string reportFilePath = Path.Combine(_cwSettings.Value.IRTargetFileLocation, fileName);
                var fileStream = new FileStream(reportFilePath, FileMode.Open);

                return File(fileStream, "application/octet-stream", fileName);
            }
            catch (FileNotFoundException e)
            {
                return new NoContentResult();
            }
            catch (Exception ex)
            {
                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvestorReportController.DownloadInvestorReport", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);

                throw ex;
            }
        }


        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("CreateIr")]
        public bool CreateIr(int dealIrConfigId, string asAtDate, int templateId, int ipdRunId, int dealId)
        {
            LogInfoEntity logInfo = new LogInfoEntity() { LogDetail="IR data process strated" , ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
            this._loggerService.LogInfo(logInfo);

            string SourcePath = "";

            if (templateId == 0)
                SourcePath = _cwSettings.Value.IrConfigFileLocation;
            else
                SourcePath = _cwSettings.Value.IrTemplateFileLocation;

            string TargetPath = _cwSettings.Value.IRTargetFileLocation;

            parentWorkSheet = _cwSettings.Value.IrParentWorksheet;

            string BackupTemplate = "";
            string GeneratedFileName = "";

            logInfo = new LogInfoEntity() { LogDetail = "IR file configuration path has been set", ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
            this._loggerService.LogInfo(logInfo);


            try
            {
                if (dealIrConfigId > 0)
                {

                    logInfo = new LogInfoEntity() { LogDetail = "IR file configuration read for dealId " + dealId.ToString(), ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);

                    IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = _reportService.GetBuildIrStratList(dealIrConfigId, asAtDate,"");

                    string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                    string OutPutFileName = _ExcelUploadEntity.First().DownloadIrFileName;
                    dealName= _ExcelUploadEntity.First().DealName;

                    string TemplatePath = string.Concat(SourcePath, TemplateFile);

                    BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                    GeneratedFileName = string.Concat(TargetPath, OutPutFileName);

                    logInfo = new LogInfoEntity() { LogDetail = "IR file configuration read for IRConfig " + dealIrConfigId.ToString(), ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);


                    if (!System.IO.File.Exists(BackupTemplate))
                        System.IO.File.Copy(TemplatePath, BackupTemplate);

                    logInfo = new LogInfoEntity() { LogDetail = "IR file BackupTemplate created for writing " + BackupTemplate, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);


                    var isGenerated = _reportService.GenerateIRFile(BackupTemplate, GeneratedFileName, parentWorkSheet, true, _cwSettings.Value.IrProtectSheetKey, dealIrConfigId, asAtDate, _ExcelUploadEntity, LoggedInUserName, "");


                    logInfo = new LogInfoEntity() { LogDetail = "IR file file writing done created on  " + GeneratedFileName, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);


                    reportModel = new InvestorReportResultEntity();
                    reportModel.DealIpdIrLocationId = 0;
                    reportModel.DealipdRunId = ipdRunId;
                    reportModel.DealId = dealId;
                    reportModel.FileName = OutPutFileName;
                    var investorReportResultEntity  = _investorReportService.Save(reportModel, LoggedInUserName);


                    logInfo = new LogInfoEntity() { LogDetail = "IR file entry passed to location database " + GeneratedFileName, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);

                    
                    System.IO.File.Delete(BackupTemplate);


                    logInfo = new LogInfoEntity() { LogDetail = "IR file backup file deleting backup file   " + BackupTemplate, ActionPerformed = "InvestorReportController.CreateIr", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                    this._loggerService.LogInfo(logInfo);


                    return isGenerated;
                }

                return false;
                
            }
            catch (Exception ex)
            {

                reportModel = new InvestorReportResultEntity();
                reportModel.DealIpdIrLocationId = -1;
                reportModel.DealipdRunId = ipdRunId;
                var investorReportResultEntity = _investorReportService.Save(reportModel, LoggedInUserName);


                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "InvestorReportController.Download", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);


                throw ex;
            }
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("AggregateDownload")]
        public IActionResult AggregateDownload(int dealId, string asAtDate, string ReportTypeName, int AssetId)
        {
            bool generateFinalIrCopy = true;
            string SourcePath = "";

            IR_Config DealIRConfigDetail = _reportService.GetDealIRConfigByDealId(dealId, ReportTypeName);
            int templateId = DealIRConfigDetail.TemplateId.HasValue ? DealIRConfigDetail.TemplateId.Value : 0;
            int dealIrConfigId = DealIRConfigDetail.DealIrConfigId.HasValue ? DealIRConfigDetail.DealIrConfigId.Value : 0;

            if (templateId == 0)
                SourcePath = _cwSettings.Value.IrConfigFileLocation;
            else
                SourcePath = _cwSettings.Value.IrTemplateFileLocation;

            string TargetPath = _cwSettings.Value.IRTargetFileLocation;

            SetWorkSheetName(ReportTypeName);

            string BackupTemplate = "";
            string GeneratedFileName = "";

            try
            {
                IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = _reportService.GetBuildIrStratList(dealIrConfigId, asAtDate, ReportTypeName);

                string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;

                string TemplatePath = string.Concat(SourcePath, TemplateFile);

                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                GeneratedFileName = string.Concat(TargetPath, OutPutFileName);

                var isGenerated = _reportService.GenerateIRFile(BackupTemplate, GeneratedFileName, parentWorkSheet, generateFinalIrCopy, "", dealIrConfigId, asAtDate, _ExcelUploadEntity, LoggedInUserName, ReportTypeName, AssetId);

                System.IO.File.Delete(BackupTemplate);
                Response.Headers.Add("OutPutFileName", OutPutFileName);
                Response.Headers.Add("Access-Control-Expose-Headers", "OutPutFileName");

                var fileStream = new FileStream(GeneratedFileName, FileMode.Open);
                return File(fileStream, "application/octet-stream", OutPutFileName);
            }
            catch (Exception ex)
            {

                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.Download", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("BuildAndDownloadReport")]
        public IActionResult BuildAndDownloadReport(int dealId, string asAtDate, string ReportTypeName, int AssetId)
        {
            bool generateFinalIrCopy = true;
            string SourcePath = "";

            IR_Config DealIRConfigDetail = _reportService.GetDealIRConfigByDealId(dealId, ReportTypeName);
            int templateId = DealIRConfigDetail.TemplateId.HasValue ? DealIRConfigDetail.TemplateId.Value : 0;
            int dealIrConfigId = DealIRConfigDetail.DealIrConfigId.HasValue ? DealIRConfigDetail.DealIrConfigId.Value : 0;

            if (templateId == 0 || DealIRConfigDetail.UploadedFileName != null)
                SourcePath = _cwSettings.Value.IrConfigFileLocation;
            else
                SourcePath = _cwSettings.Value.IrTemplateFileLocation;

            string TargetPath = _cwSettings.Value.IRTargetFileLocation;

            SetWorkSheetName(ReportTypeName);

            string BackupTemplate = "";
            string GeneratedFileName = "";

            try
            {
                IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = _reportService.GetBuildIrStratList(dealIrConfigId, asAtDate, ReportTypeName);

                string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;

                string TemplatePath = string.Concat(SourcePath, TemplateFile);

                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                GeneratedFileName = string.Concat(TargetPath, OutPutFileName);

                var isGenerated = _reportService.GenerateIRFile(BackupTemplate, GeneratedFileName, parentWorkSheet, generateFinalIrCopy, "", dealIrConfigId, asAtDate, _ExcelUploadEntity, LoggedInUserName, ReportTypeName, AssetId);

                System.IO.File.Delete(BackupTemplate);
                Response.Headers.Add("OutPutFileName", OutPutFileName);
                Response.Headers.Add("Access-Control-Expose-Headers", "OutPutFileName");

                var fileStream = new FileStream(GeneratedFileName, FileMode.Open);
                return File(fileStream, "application/octet-stream", OutPutFileName);
            }
            catch (Exception ex)
            {

                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.Download", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("checkIRTemplateAvailable/{dealId}/{ReportTypeName}")]
        public int checkIRTemplateAvailable(int dealId, string ReportTypeName)
        { 
            IR_Config DealIRConfigDetail = _reportService.GetDealIRConfigByDealId(dealId, ReportTypeName); 
            return DealIRConfigDetail.DealIrConfigId.HasValue ? DealIRConfigDetail.DealIrConfigId.Value : 0; 
        }


        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("ESMAAnnexDownload")]
        public IActionResult ESMAAnnexDownload(int dealId, string asAtDate, string ReportTypeName,  int assetId)
        {
            bool generateFinalIrCopy = true;
            string SourcePath = "";

            IR_Config DealIRConfigDetail = _reportService.GetDealIRConfigByDealId(dealId, ReportTypeName);
            int templateId = DealIRConfigDetail.TemplateId.HasValue ? DealIRConfigDetail.TemplateId.Value : 0;
            int dealIrConfigId = DealIRConfigDetail.DealIrConfigId.HasValue ? DealIRConfigDetail.DealIrConfigId.Value : 0;

            if (assetId == (int)AssetType.Retail)
            {
                parentWorkSheet = DealIRConfigDetail.ReportParentSheet;
            }
            else if (assetId == (int)AssetType.Corporate)
            {
                parentWorkSheet = _cwSettings.Value.CBAnnex12SecWorksheets;
            }

            SourcePath = _cwSettings.Value.IrTemplateFileLocation;

            string TargetPath = _cwSettings.Value.IRTargetFileLocation;;

            string BackupTemplate = "";
            string GeneratedFileName = "";

            try
            {
                IEnumerable<ExcelUploadEntity> _ExcelUploadEntity = _reportService.GetBuildIrStratList(dealIrConfigId, asAtDate, ReportTypeName);

                string TemplateFile = _ExcelUploadEntity.First().ExcelTemplateFile;
                string OutPutFileName = _ExcelUploadEntity.First().ExcelOutputFile;

                string TemplatePath = string.Concat(SourcePath, TemplateFile);

                BackupTemplate = string.Concat(SourcePath, Math.Abs(Environment.TickCount), OutPutFileName);

                if (!System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Copy(TemplatePath, BackupTemplate);

                GeneratedFileName = string.Concat(TargetPath, OutPutFileName);

                var isGenerated = _reportService.GenerateIRFile(BackupTemplate, GeneratedFileName, parentWorkSheet, generateFinalIrCopy, "", dealIrConfigId, asAtDate, _ExcelUploadEntity, LoggedInUserName, ReportTypeName, assetId);

                System.IO.File.Delete(BackupTemplate);
                Response.Headers.Add("OutPutFileName", OutPutFileName);
                Response.Headers.Add("Access-Control-Expose-Headers", "OutPutFileName");

                var fileStream = new FileStream(GeneratedFileName, FileMode.Open);
                return File(fileStream, "application/octet-stream", OutPutFileName);
            }
            catch (Exception ex)
            {

                if (System.IO.File.Exists(BackupTemplate))
                    System.IO.File.Delete(BackupTemplate);

                if (System.IO.File.Exists(GeneratedFileName))
                    System.IO.File.Delete(GeneratedFileName);

                LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "DealIrConfigController.Download", ModuleId = (int)AppModule.Cashwaterfall, UserName = LoggedInUserName };
                this._loggerService.LogError(logError);
                throw ex;
            }
        }
        private void SetWorkSheetName(string ReportTypeName)
        {
            if (ReportTypeName.ToUpper() == "HTT")
                parentWorkSheet = _cwSettings.Value.HTTParentWorksheets;
            else if (ReportTypeName.ToUpper() == "ANNEX2D")
                parentWorkSheet = _cwSettings.Value.Annex2DParentWorksheet;
            else if (ReportTypeName.ToUpper() == "MOODYS")
                parentWorkSheet = _cwSettings.Value.MoodysParentWorksheet;
            else
                parentWorkSheet = _cwSettings.Value.CBIrParentWorksheets;
        }
    }
    }
