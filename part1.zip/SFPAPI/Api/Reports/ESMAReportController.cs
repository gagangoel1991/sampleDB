﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using ClosedXML.Excel;
using System.IO;
using System.Linq;
using NW.SFP.Interface.Report;

namespace NW.SFPAPI.Api.PS
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/esmaReport")]
    [Authorize]
    public class ESMAReportController : SFPControllerBase, IESMAReportController
    {
        #region Variables  declaration and Construction
        private readonly IESMAReportService _esmaReportService;
        private readonly ILoggerService _loggerService;

        public ESMAReportController(IESMAReportService esmaReportService, ILoggerService loggerService)
        {
            _esmaReportService = esmaReportService;
            _loggerService = loggerService;
        }
        #endregion

        [SFPAuthorize("CB_ESMA4", PermissionAccessType.View)]
        [HttpGet("reportEsma4Data/{asAtDate}/{poolId?}/{dealName?}/{poolName?}")]
        public ActionResult GetESMA4ReportData(string asAtDate, string dealName = null, int poolId = -1, string poolName = null)
        {
            DateTime _asAtDate;
            if (DateTime.TryParse(asAtDate, out _asAtDate))
            {
                try
                {
                    var stream = _esmaReportService.GetESMA4Data(dealName, _asAtDate, LoggedInUserName, poolId, poolName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent("ESMA4 Report", stream.ToArray());
                    }
                }
                catch (Exception ex)
                {
                    LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "ESMAReportController.GetESMA4ReportData", ModuleId = (int)AppModule.PoolSelection, UserName = LoggedInUserName };
                    _loggerService.LogError(logError);
                }
            }
            return BadRequest();
        }


        [SFPAuthorize("CB_ESMA9", PermissionAccessType.View)]
        [HttpGet("reportEsma9Data/{asAtDate}/{poolId?}/{dealName?}/{poolName?}")]
        public ActionResult GetESMA9ReportData(string asAtDate, string dealName = null, int poolId = -1, string poolName = null)
        {
            DateTime _asAtDate;
            if (DateTime.TryParse(asAtDate, out _asAtDate))
            {
                try
                {
                    var stream = _esmaReportService.GetESMA9ata(dealName, _asAtDate, LoggedInUserName, poolId, poolName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent("ESMA9 Report", stream.ToArray());
                    }
                }
                catch (Exception ex)
                {
                    LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "ESMAReportController.GetESMA9ReportData", ModuleId = (int)AppModule.PoolSelection, UserName = LoggedInUserName };
                    _loggerService.LogError(logError);
                }
            }
            return BadRequest();
        }

        [SFPAuthorize("CB_FCA4", PermissionAccessType.View)]
        [HttpGet("reportFCAAnnex4Data/{asAtDate}/{poolId?}/{dealName?}/{poolName?}")]
        public ActionResult GetFCAAnnex4ReportData(string asAtDate, string dealName = null, int poolId = -1, string poolName = null)
        {
            DateTime _asAtDate;
            if (DateTime.TryParse(asAtDate, out _asAtDate))
            {
                try
                {
                    var stream = _esmaReportService.GetFCAAnnex4Data(dealName, _asAtDate, LoggedInUserName, poolId, poolName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent("FCA Annex 4 Report", stream.ToArray());
                    }
                }
                catch (Exception ex)
                {
                    LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "ESMAReportController.GetFCA4ReportData", ModuleId = (int)AppModule.PoolSelection, UserName = LoggedInUserName };
                    _loggerService.LogError(logError);
                }
            }
            return BadRequest();
        }

        [SFPAuthorize("CB_FCA9", PermissionAccessType.View)]
        [HttpGet("reportFCAAnnex9Data/{asAtDate}/{poolId?}/{dealName?}/{poolName?}")]
        public ActionResult GetFCAAnnex9ReportData(string asAtDate, string dealName = null, int poolId = -1, string poolName = null)
        {
            DateTime _asAtDate;
            if (DateTime.TryParse(asAtDate, out _asAtDate))
            {
                try
                {
                    var stream = _esmaReportService.GetFCAAnnex9Data(dealName, _asAtDate, LoggedInUserName, poolId, poolName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent("FCA Annex 9 Report", stream.ToArray());
                    }
                }
                catch (Exception ex)
                {
                    LogErrorEntity logError = new LogErrorEntity() { ErrorMessage = ex.Message, ErrorMethod = "ESMAReportController.GetFCA9ReportData", ModuleId = (int)AppModule.PoolSelection, UserName = LoggedInUserName };
                    _loggerService.LogError(logError);
                }
            }
            return BadRequest();
        }
        #region Private Methods


        private ActionResult ConvertFileResultContent(string reportName, byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $""+ reportName + ".xlsx");
        }
        #endregion
    }
}
