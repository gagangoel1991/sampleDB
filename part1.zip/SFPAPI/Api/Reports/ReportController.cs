﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.Report.BusinessService;
using NW.SFP.Message.Report;
using NW.SFP.Message.SFP.Model;
using SFPAPI.Api;
using System.Collections.Generic;
using System.Linq;

namespace NW.SFP.API.Api.Reports
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/reports")]
    [Authorize]
    public class ReportController : SFPControllerBase
    {
        #region Variable Declarations and Constructor
        private readonly ILoggerService _loggerService;
        private readonly IReportService _reportService;
        public ReportController(IReportService reportService, ILoggerService loggerService)
        {
            _loggerService = loggerService;
            _reportService = reportService;
        }
        #endregion

        #region Public Actions
        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("getReportConfig")]
        public ActionResult<ReportConfigs> GetReportConfig()
        {
            ReportConfigs reportConfigs = _reportService.GetReportConfig(LoggedInUserName);
            return Ok(reportConfigs);
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("getHypoPools/{assetClassId?}/{poolStatusId?}")]
        public ActionResult<IList<HypoPool>> GetHypoPools(int assetClassId=1, int poolStatusId=0)
        {
            IList<HypoPool> pools = _reportService.GetHypoPools(LoggedInUserName, assetClassId,poolStatusId);
            return Ok(pools);
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("getReports/{id}")]
        public ActionResult<Report> GetReports(int id)
        {
            var report = _reportService.GetReports(LoggedInUserName, id);
            return Ok(report);
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpPost("setReportForQueue")]
        public ActionResult<SfpBatchDataDto> SetReportForQueue([FromBody] Report report)
        {
            SfpBatchDataDto sfpBatchData = _reportService.SetReportForQueue(LoggedInUserName, report);
            return Ok(sfpBatchData);
        }

        [SFPAuthorize("CW_Reports", PermissionAccessType.View)]
        [HttpGet("getReportQueue")]
        public ActionResult<List<ReportQueue>> GetReportQueue()
        {
            var reportQueues = _reportService.GetReportQueue(LoggedInUserName).ToList();
            return Ok(reportQueues);
        }
        #endregion
    }
}
