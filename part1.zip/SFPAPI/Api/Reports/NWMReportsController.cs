﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.PS;
using NW.SFP.Message.Core;
using NW.SFP.Message.PS;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using ClosedXML.Excel;
using System.IO;
using System.Linq;
using NW.SFP.Interface.Report;
using NW.SFP.Interface.Report.BusinessService;

namespace NW.SFP.API.Api.Reports
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/nwmReports")]
    [Authorize]
    public class NWMReportsController : SFPControllerBase
    {
         #region Variables  declaration and Construction
        private readonly INWMReportsService _nwmReporsService;
        private readonly ILoggerService _loggerService;

        public NWMReportsController(INWMReportsService nwmReporsService, ILoggerService loggerService)
        {
            _nwmReporsService = nwmReporsService;           
            _loggerService = loggerService;
        }
        #endregion
        [SFPAuthorize("NWM_AssetRegister", PermissionAccessType.View)]
        [HttpGet("reportNWMAssetData/{asAtDate}")]
        public ActionResult GetNWMAssetReportData(string asAtDate)
        {
            DateTime _asAtDate;
            if (DateTime.TryParse(asAtDate, out _asAtDate))
            {
                 var stream = _nwmReporsService.GenerateAssetReportData( _asAtDate, LoggedInUserName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent("NWMAsset Report", stream.ToArray());
                    }                
            }
            return BadRequest();
        }


        [SFPAuthorize("NWM_Loansoutstandingreport", PermissionAccessType.View)]
        [HttpGet("reportNWMOutstandingData/{asAtDate}")]
        public ActionResult GetNWMOutstandingtData(string asAtDate)
        {
            DateTime _asAtDate;
            if (DateTime.TryParse(asAtDate, out _asAtDate))
            {
                
                    var stream = _nwmReporsService.GenerateLoansOutstandingReportData(_asAtDate, LoggedInUserName);
                    if (stream != null)
                    {
                        return ConvertFileResultContent("Outstanding Report", stream.ToArray());
                    }               
                
            }
            return BadRequest();
        }

        #region Private Methods
        private ActionResult ConvertFileResultContent(string reportName, byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $"" + reportName + ".xlsx");
        }
        #endregion
    }
}
