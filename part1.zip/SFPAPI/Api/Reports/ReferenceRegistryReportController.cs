﻿namespace NW.SFPAPI.Api.PS
{
    using Microsoft.AspNetCore.Authorization;
    using Microsoft.AspNetCore.Mvc;
    using Microsoft.Extensions.Options;
    using NW.SFP.API.Core.Auth;
    using NW.SFP.API.Core.Constants;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.Report;
    using NW.SFP.Message.Core;
    using System;
    using System.IO;
    using System.Collections.Generic;
    using System.Linq;
    using global::SFPAPI.Api;
    using NW.SFP.Message.Report;
    using NW.SFP.Message.Common;
    using NW.SFP.Message.PS;
    using NW.SFP.Message.CW.IR;
    using NW.SFP.Interface.CW;
    using ClosedXML.Excel;

    [ApiController]
    [Produces("application/json")]
    [Route("api/referenceRegistryReport")]
    [Authorize]
    public class ReferenceRegistryReportController : SFPControllerBase
    {
        #region Variables  declaration and Construction

        private readonly IReferenceRegistryReportService _ireferenceRegistryReportService;
        private readonly IDealIrConfigService _dealIrConfigService;
        private readonly IOptions<CashWaterfallSettings> _cwSettings;

        public ReferenceRegistryReportController(IReferenceRegistryReportService ReferenceRegistryReportService,
            IDealIrConfigService DealIrConfigService, ILoggerService loggerService,
            IOptions<CashWaterfallSettings> cwSettings)
        {
            this._ireferenceRegistryReportService = ReferenceRegistryReportService;
            this._dealIrConfigService = DealIrConfigService;
            this._cwSettings = cwSettings;
        }

        #endregion


        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpGet("downloadReferenceRegistryReport/{dealRrrConfigId}/{AsAtDate}")]
        public ActionResult DownloadReferenceRegistryReport(int dealRrrConfigId, string AsAtDate)
        {
            var stream = _ireferenceRegistryReportService.GenerateReferenceRegistryReportData(dealRrrConfigId, AsAtDate, LoggedInUserName);
            if (stream != null)
            {
                return ConvertFileResultContent(stream.ToArray());
            }
            return null;
        }

        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpGet("downloadFinalReferenceRegistryReport/{dealId}/{AsAtDate}/{poolId}/{ReportOutputType}")]
        public ActionResult DownloadFinalReferenceRegistryReport(int dealId, string AsAtDate, int poolId=0, string ReportOutputType="")
        {
            var stream = _ireferenceRegistryReportService.DownloadFinalReferenceRegistryReport(dealId, AsAtDate, LoggedInUserName, poolId, ReportOutputType);
            if (stream != null)
            {
                return ConvertFileResultContent(stream.ToArray());
            }
            return null;
        }

        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpGet("checkReferenceRegistryTemplateAvailable/{dealId}/{AsAtDate}")]
        public int checkReferenceRegistryTemplateAvailable(int dealId, string AsAtDate)
        {
            return _ireferenceRegistryReportService.checkReferenceRegistryTemplateAvailable(dealId, AsAtDate, LoggedInUserName);
        }




        private ActionResult ConvertFileResultContent(byte[] content)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     $"ReferenceRegistryReport.xlsx");
        }

        private ActionResult ConvertFileResultContentCsv(byte[] content)
        {
            return File(
                   content,
                   "text/csv",
                     $"ReferenceRegistryReport.csv");
        }

        //todo -- need to change PermissionAccessType
        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpPost("manageRRAuthWorkflow")]
        public int ManageRRAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            var responseCode = _ireferenceRegistryReportService.ManageRRAuthWorkflow(authWorkflowEntity);
            return responseCode;
        }

     

        /// <summary>
        /// This will Save Build RRR Data 
        /// </summary>
        /// <param name="dealIrConfigData"></param>
        /// <returns></returns>
        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.AddEdit)]
        [HttpPost("save")]
        public int SaveDealRrrConfig([FromBody] DealIrConfigAddEditEntity dealIrConfigData)
        {
            return this._ireferenceRegistryReportService.SaveDealRrrConfig(dealIrConfigData, LoggedInUserName, "Reference Registry");
        }

        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpGet("buildRrr/{buildRrrId}/{AssetClassID}")]
        public ActionResult<DealIrConfigEntity> GetBuildRrrData(int buildRrrId, int AssetClassID)
        {
            return this._ireferenceRegistryReportService.GetRefRegData(buildRrrId, LoggedInUserName, AssetClassID);
        }

        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpPost("upload")]
        public string UploadTemplate([FromForm] DealIrConfigAddEditEntity dealIrConfigData)
        {
            var files = HttpContext.Request.Form.Files;
            if (files.Count > 0)
            {
                foreach (var file in files)
                {
                    if (file.Length > 0)
                    {
                        string customFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName); // Give file name
                        string GeneratedFileName = Path.Combine(_cwSettings.Value.RrConfigFileLocation, customFileName);

                        using (var fileStream = new FileStream(GeneratedFileName, FileMode.Create))
                        {
                            file.CopyTo(fileStream);
                        }

                        dealIrConfigData.OriginalFileName = file.FileName;
                        dealIrConfigData.UploadedFileName = customFileName;
                    }
                }
            }


            var isUploaded = this._dealIrConfigService.SaveDealIrConfig(dealIrConfigData, LoggedInUserName, "Reference Registry", 2);

            if (isUploaded == -1)
                return "duplicate";
            else
                return dealIrConfigData.UploadedFileName;
        }


        [SFPAuthorize("CW_InvoiceMgmt", PermissionAccessType.View)]
        [HttpGet("downloadTemplate")]
        public IActionResult DownloadInvoiceFile(string uploadedFileName)
        {
            string invoiceFilePath = Path.Combine(_cwSettings.Value.RrConfigFileLocation, uploadedFileName);
            var fileStream = new FileStream(invoiceFilePath, FileMode.Open);

            return File(fileStream, "application/octet-stream", uploadedFileName);
        }

        [SFPAuthorize("PS_ReffRegistryReportManagement", PermissionAccessType.View)]
        [HttpGet("fields/{assetClassId}")]
        public ActionResult<IList<RRReportField>> GetFieldsForRRReports(int assetClassId)
        {
            List<RRReportField> poolRRReports = _ireferenceRegistryReportService.GetFieldsForReports(LoggedInUserName, assetClassId).ToList();
            return Ok(poolRRReports);
        }

    }
}