﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.CB;
using NW.SFP.Interface.Core;
using NW.SFP.Message.CB;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFPAPI.Api.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/commercialbanking")]
    [Authorize]
    public class DataCorrectionRefController: SFPControllerBase, IDataCorrectionRefController
    {
        #region Variables declaration and Construction
        readonly IDataCorrectionRefBusinessService _dataCorrectionRefService;

        public DataCorrectionRefController(IDataCorrectionRefBusinessService dataCorrectionRefService)
        {
            _dataCorrectionRefService = dataCorrectionRefService;
        }
        #endregion

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("cb/datacorrectionRef")]
        public ActionResult<DataCorrectionReference> GetDataCorrectionReferenceData()
        {
            return _dataCorrectionRefService.GetDataCorrectionReferenceData(LoggedInUserName);
        }
    }
}
