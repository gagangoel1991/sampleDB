﻿using ClosedXML.Excel;
using DocumentFormat.OpenXml.Spreadsheet;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.CB;
using NW.SFP.Interface.Core;
using NW.SFP.Message.CB;
using NW.SFP.Message.Corp;
using SFPAPI.Api;
using System;
using System.Collections.Generic;
using System.Data;
using System.IO;
using System.Linq;
using System.Runtime.Serialization.Formatters.Binary;
using System.Threading.Tasks;

namespace NW.SFPAPI.Api.CB
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/commercialbanking")]
    [Authorize]
    public class DataCorrectionController : SFPControllerBase, IDataCorrectionController
    {
        #region Variables declaration and Construction

        readonly ILoggerService _logger;
        readonly IDataCorrectionBusinessService _dataCorrectionService;

        public DataCorrectionController(IDataCorrectionBusinessService dataCorrectionService, ILoggerService logger)
        {
            _logger = logger;
            _dataCorrectionService = dataCorrectionService;
        }

        #endregion

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("cb/dataattribute/{entityId}")]
        public ActionResult<IList<DataCorrectionAttribute>> GetDataCorrectionAttribute(int entityId)
        {
            return _dataCorrectionService.GetDataCorrectionAttribute(entityId, LoggedInUserName).ToList();
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpPost("cb/datacorrection")]
        public ActionResult<DataCorrectionDetail> GetDataCorrectionDetail(DataCorrectionBasicInfo basicInfo)
        {
            try
            {
                return _dataCorrectionService.GetDataCorrectionDetail(basicInfo, LoggedInUserName);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpPost("cb/savedatacorrection")]
        public ActionResult<string> SaveDataCorrection(DataCorrectionBasicInfo basicInfo)
        {
            try
            {
                return _dataCorrectionService.SaveDataCorrection(basicInfo, LoggedInUserName);
            }
            catch (Exception ex)
            {
                return null;
            }
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("cb/getUpdateOverrideList/{dealId}/{*AsAtDate}")]
        public IList<UpdateOverrideListEntity> GetUpdateOverrideList(int dealId, string AsAtDate)
        {
            return _dataCorrectionService.GetUpdateOverrideList(LoggedInUserName, dealId, AsAtDate);
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("getLinkageAuditReportData/{dealId}/{AsAtDate}")]
        public ActionResult getLinkageAuditReportData(int dealId, string AsAtDate, int isTemplate)
        {
            var stream = _dataCorrectionService.getLinkageAuditReportData(dealId, AsAtDate, LoggedInUserName);
            if (stream != null)
            {
                return ConvertFileResultContent(dealId, stream.ToArray(), "LinkageAuditReportData");
            }
            return null;
        }


        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("downloadFacilityOverrideData/{dealId}/{isTemplate}/{*AsAtDate}")]
        public ActionResult downloadFacilityOverrideData(int dealId, string AsAtDate, int isTemplate)
        {
            var stream = _dataCorrectionService.getFacilityOverrideData(dealId,  AsAtDate, LoggedInUserName, isTemplate);
            if (stream != null)
            { 
                return ConvertFileResultContent(dealId, stream.ToArray(), "FacilityOverrideData");
            }
            return null;
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("downloadSecurityOverrideData/{dealId}/{isTemplate}/{*AsAtDate}")]
        public ActionResult downloadSecurityOverrideData(int dealId, string AsAtDate, int isTemplate)
        {
            var stream = _dataCorrectionService.getSecurityOverrideData(dealId, AsAtDate, LoggedInUserName, isTemplate);
            if (stream != null)
            {
                return ConvertFileResultContent(dealId, stream.ToArray(), "SecurityOverrideData");
            }
            return null;
        }


        private ActionResult ConvertFileResultContent(int dealId, byte[] content, string fileName)
        {
            return File(
                   content,
                   "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                     fileName+ "_{ dealId}.xlsx");
        }
 

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.AddEdit)]
        [HttpPost("saveOverrideData/{dealId}/{AsAtDate}")]
        //[HttpPost("saveOverrideData/{dealId}/{AsAtDate}/List<FacilitySecurityLink>")]
        // public ActionResult<string> saveOverrideData(int dealId, string AsAtDate, [FromBody] List<FacilitySecurityLink> LinkList)
        public ActionResult<string> saveOverrideData(int dealId, string AsAtDate)
        {
            dynamic resultObj = null;
            List<Dictionary<string, string>> ErrorExcel;
            int isErrorListAvailable = 0;
            List<string> LstcolumnNames = new List<string>();
            string ErrorEntity = "";
            string isListEdited = HttpContext.Request.Form["isListEdited"].ToString();

            List<FacilitySecurityLink> LinkList = new List<FacilitySecurityLink>(); 
            if (!string.IsNullOrEmpty(HttpContext.Request.Form["linkageList"].ToString()))
            {
                LinkList = JsonConvert.DeserializeObject<List<FacilitySecurityLink>>(HttpContext.Request.Form["linkageList"].ToString());
            } 


            int result = _dataCorrectionService.saveOverrideData(dealId, AsAtDate, LoggedInUserName, HttpContext.Request.Form.Files, 
                LinkList, isListEdited, HttpContext.Request.Form,
                out ErrorExcel, out LstcolumnNames, out ErrorEntity);

            if (ErrorExcel != null && ErrorExcel.Count > 0)
            {
                isErrorListAvailable = 1;
            }

            resultObj = new
            {
                errorListJson = ErrorExcel,
                isErrorListAvailable = isErrorListAvailable,
                errorExcelHeaderList = LstcolumnNames,
                entityName = ErrorEntity,
                returnCode = result
            };

            return JsonConvert.SerializeObject(resultObj);
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("downloadOverrideAuditTrail/{dealId}/{entityType}/{vintageDate}")]
        public ActionResult DownloadAuditTrailReport(int dealId, string entityType, string vintageDate)
        {
            var stream = _dataCorrectionService.GetOverrideAuditTrailData(dealId, entityType, vintageDate, LoggedInUserName);
            if (stream != null)
            {
                return ConvertFileResultContent(dealId, stream.ToArray(), "OverrideAuditTrail");
            }

            return null;
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("getOverrideVintageDatesList/{dealId}")]
        public IList<string> GetOverrideVintageDatesList(int dealId)
        {
            return _dataCorrectionService.GetOverrideVintageDateList(dealId, LoggedInUserName).ToList();
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("downloadComparisionData/{DealIrConfigId}/{dealId}/{AsAtDate}/{PreviousReportingDate}/{AnyDiffFlag}/{entity}")]
        public ActionResult downloadComparisionData(int dealIrConfigId, int dealId, string asAtDate, 
            string previousReportingDate, int anyDiffFlag, string entity)
        {
            if (entity.ToLower() == "facility")
            {
                var stream = _dataCorrectionService.getFacilityComparisionData(dealIrConfigId, dealId, asAtDate,
                    previousReportingDate, anyDiffFlag, LoggedInUserName);
                if (stream != null)
                {
                    return ConvertFileResultContent(dealId, stream.ToArray(), "FacilityComparisionData");
                }
            }
            else
            {
                var stream = _dataCorrectionService.getSecurityComparisionData(dealIrConfigId, dealId, asAtDate,
                    previousReportingDate, anyDiffFlag, LoggedInUserName);
                if (stream != null)
                {
                    return ConvertFileResultContent(dealId, stream.ToArray(), "SecurityComparisionData");
                }
            }
            return null;
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.AddEdit)]
        [HttpGet("validatePoolAndOverrideAuthorize/{callFromOverrideAuth}/{id}")]
        public ActionResult<string> validatePoolAndOverrideAuthorize(int callFromOverrideAuth, int id)
        {
            return _dataCorrectionService.validatePoolAndOverrideAuthorize(callFromOverrideAuth, id);
        }


        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.View)]
        [HttpGet("cb/getFacilitySecurityLinkStatus/{AsAtDate}/{ComparisonDate}/{DealId}")]
        public IList<FacilitySecurityLinkEntity> getFacilitySecurityLinkStatus(string AsAtDate, string ComparisonDate, int dealId)
        {
            return _dataCorrectionService.getFacilitySecurityLinkStatus(LoggedInUserName, AsAtDate, ComparisonDate, dealId);
        }

        [SFPAuthorize("CB_DealDataCorrectionManagement", PermissionAccessType.AddEdit)]
        [HttpGet("resetOverrideData/{DealOverrideParentId}/{Entity}")]
        public ActionResult<string> resetOverrideData(int DealOverrideParentId, string Entity)
        {
            return _dataCorrectionService.resetOverrideData(DealOverrideParentId, Entity);
        }

    }
}
