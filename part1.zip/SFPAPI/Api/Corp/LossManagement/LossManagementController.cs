﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.CB;
using NW.SFP.Interface.Upload;
using NW.SFP.Message.CB;
using NW.SFP.Message.Core;
using NW.SFP.Message.Upload;
using SFPAPI.Api;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFPAPI.Api.Upload
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/LossManagement")]
    [Authorize]
    public class LossManagementController : SFPControllerBase, ILossManagementController
    {
        #region Variables declaration and Construction
       readonly ILossManagementService _lossManagementBusinessService;

        public LossManagementController(ILossManagementService lossManagementBusinessService)
        {
            _lossManagementBusinessService = lossManagementBusinessService;
        }
        #endregion
        
        [SFPAuthorize("LossManagement", PermissionAccessType.View)]
        [HttpGet("LossManagementList")]
        public ActionResult<IList<LossManagementList>> GetLossManagementList()
        {
            var lossList = _lossManagementBusinessService.GetLossManagementList(LoggedInUserName).ToList();
            return lossList;
        }

        [SFPAuthorize("LossManagement", PermissionAccessType.View)]
        [HttpGet("LossRefData")]
        public ActionResult<LossManagementRefData> GetLossManagementRefData()
        {
            var lossRefData = _lossManagementBusinessService.GetLossManagementRefData(LoggedInUserName);
            return Ok(lossRefData);
        }

        [SFPAuthorize("LossManagement", PermissionAccessType.View)]
        [HttpGet("LossUpdatedData")]
        public ActionResult<IList<LossManagementList>> GetLossUpdatedData()
        {
            var lossUpdatedData = _lossManagementBusinessService.GetLossUpdatedData(LoggedInUserName).ToList();
            return lossUpdatedData;
        }

        [SFPAuthorize("LossManagement", PermissionAccessType.AddEdit)]
        [HttpPost("UploadWriteOffFile")]
        public ActionResult<int> UploadWriteOffFile(IList<WriteOffData> writeOffData)
        {
            var writeOfres = _lossManagementBusinessService.UploadWriteOffFile(writeOffData, LoggedInUserName);
            return Ok(writeOfres);
        }

        [SFPAuthorize("LossManagement", PermissionAccessType.View)]
        [HttpPost("DefaultDateData")]
        public ActionResult<DefaultDateData> GetDefaultDateData(DefaultDateData defaultDateParam)
        {
            var defaultDateData = _lossManagementBusinessService.GetDefaultDateData(defaultDateParam, LoggedInUserName);
            return Ok(defaultDateData);
        }

        [SFPAuthorize("LossManagement", PermissionAccessType.AddEdit)]
        [HttpPost("UpdateLossDetails")]
        public ActionResult<int> UpdateLossDetails(LossManagementList lossManagementList)
        {
            var updateRes = _lossManagementBusinessService.UpdateLossDetails(lossManagementList, LoggedInUserName);
            return Ok(updateRes);
        }

        [SFPAuthorize("LossManagement", PermissionAccessType.View)]
        [HttpGet("LoadAllocatedLoss/{lossManagementId}")]
        public ActionResult<decimal?> LoadAllocatedLoss(int lossManagementId)
        {
            decimal? allocatedLoss = _lossManagementBusinessService.LoadAllocatedLoss(lossManagementId, LoggedInUserName);
            return Ok(allocatedLoss);
        }
    }
}
