﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Upload.BusinessService;
using NW.SFP.Message.Upload;
using SFPAPI.Api;

namespace NW.SFP.API.Api.Upload
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/uploadFilesUtility")]
    [Authorize]
    public class FileUploadUtilityController : SFPControllerBase
    {
        readonly IFileUploadUtilityBusinessService _objFileUploadUtilityBusinessService;

        public FileUploadUtilityController(IFileUploadUtilityBusinessService objFileUploadUtilityBusinessService)
        {
            _objFileUploadUtilityBusinessService = objFileUploadUtilityBusinessService;
        }


        [SFPAuthorize("FileUploadUtility", PermissionAccessType.AddEdit)]
        [HttpPost("uploadFiles")]
        public int UploadFiles([FromForm] FileUploadUtilityAddEntity objFileUploadUtilityAddEntity)
        {         
            var objFileUploadUtilityConfiguration = _objFileUploadUtilityBusinessService
                                                    .GetFileUploadUtilityConfiguration(objFileUploadUtilityAddEntity.FileUploadUtilityConfigurationId,
                                                                                       LoggedInUserName);

            if (objFileUploadUtilityConfiguration != null)
            {

                var files = HttpContext.Request.Form.Files;
                if (files.Count > 0)
                {
                    foreach (var file in files)
                    {
                        if (file.Length > 0)
                        {
                            string customFileName = Guid.NewGuid().ToString() + Path.GetExtension(file.FileName);

                            objFileUploadUtilityAddEntity.FileUploadInfoList.Add(new FileUploadFileDetails()
                            {
                                OriginalFileName = file.FileName,
                                FileSystemFileName = customFileName
                            });

                            // Give file name
                            using (var fileStream = new FileStream(Path.Combine(objFileUploadUtilityConfiguration.UploadLocation, customFileName), FileMode.Create))
                            {
                                file.CopyTo(fileStream);
                            }
                        }
                    }
                }
            }

            objFileUploadUtilityAddEntity.UserName = LoggedInUserName;
            _objFileUploadUtilityBusinessService.SaveFileUploadUtilityDetails(objFileUploadUtilityAddEntity);

            return 1;


        }

        [SFPAuthorize("FileUploadUtility", PermissionAccessType.View)]
        [HttpGet("getFileUploadUtilityDetails/{fileUploadUtilityConfigurationId}/{referenceId}")]
        public IList<FileUploadUtilityDetailsEntity> GetFileUploadUtilityDetails(int FileUploadUtilityConfigurationId, int ReferenceId)
        {
            return _objFileUploadUtilityBusinessService.GetFileUploadUtilityDetails(FileUploadUtilityConfigurationId, ReferenceId, LoggedInUserName);
        }

        [SFPAuthorize("FileUploadUtility", PermissionAccessType.View)]
        [HttpGet("downloadFile/{fileUploadUtilityConfigurationId}/{fileSystemFileName}")]
        public IActionResult DownloadFile(int fileUploadUtilityConfigurationId, string fileSystemFileName)
        {
            var objFileUploadUtilityConfiguration = _objFileUploadUtilityBusinessService
                                                    .GetFileUploadUtilityConfiguration(fileUploadUtilityConfigurationId,
                                                                                       LoggedInUserName);
            string invoiceFilePath = Path.Combine(objFileUploadUtilityConfiguration.UploadLocation, fileSystemFileName);
            var fileStream = new FileStream(invoiceFilePath, FileMode.Open);
            return File(fileStream, "application/octet-stream");
        }

        [SFPAuthorize("FileUploadUtility", PermissionAccessType.Delete)]
        [HttpDelete("deleteFile/{fileUploadUtilityDetailsId}")]
        public int DeleteFile(int fileUploadUtilityDetailsId)
        {
            return _objFileUploadUtilityBusinessService.DeleteFileUploadUtilityDetails(fileUploadUtilityDetailsId, LoggedInUserName);
        }

        [SFPAuthorize("FileUploadUtility", PermissionAccessType.AddEdit)]
        [HttpGet("getFileUploadUtilityConfiguration/{fileUploadUtilityConfigurationId}")]
        public FileUploadUtilityConfiguration GetFileUploadUtilityConfiguration(int FileUploadUtilityConfigurationId)
        {
            return _objFileUploadUtilityBusinessService.GetFileUploadUtilityConfiguration(FileUploadUtilityConfigurationId, LoggedInUserName);
        }


    }
}
