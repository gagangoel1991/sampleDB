﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Upload;
using NW.SFP.Message.Core;
using NW.SFP.Message.Upload;
using SFPAPI.Api;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFPAPI.Api.Upload
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/FileUploadManagement")]
    [Authorize]
    public class FileUploadInfoController : SFPControllerBase, IFileUploadInfoController
    {
        #region Variables declaration and Construction
        readonly IFileUploadInfoBusinessService _fileUploadInfoBusinessService;
        readonly IOptions<UploadSettings> _uploadSettings;

        public FileUploadInfoController(IFileUploadInfoBusinessService fileUploadInfoBusinessService, IOptions<UploadSettings> uploadSettings)
        {
            _fileUploadInfoBusinessService = fileUploadInfoBusinessService;
            _uploadSettings = uploadSettings;
        }
        #endregion

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("upload/FileInfo/{assetClassId}")]
        public ActionResult<IList<FileUploadInfo>> GetFileUploadReferenceData(int assetClassId)
        {            
            return _fileUploadInfoBusinessService.GetFileUploadReferenceData(LoggedInUserName, UserAllADGroup, assetClassId).ToList();
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpPost("upload/file/{fileId}")]
        [DisableRequestSizeLimit]
        public ActionResult<Task<FileUploadResult>> UploadFile(IFormFile file, int fileId)
        {
            Task<FileUploadResult> result = _fileUploadInfoBusinessService.UploadFile(file, fileId, LoggedInUserName);
            result.Wait();
            return result;
        }
        
        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("getFileWorkflow/{fileInfoId}")]
        public ActionResult<IList<UploadFileWorflowState>> GetFileWorkflowState(int fileInfoId)
        {
            var uploadFileWorflowStates = _fileUploadInfoBusinessService.GetFileWorkflowState(fileInfoId, LoggedInUserName).ToList();
            return uploadFileWorflowStates;
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.AddEdit)]
        [HttpPost("setFileWorkflow/{fileInfoId}/{fileStatus}")]
        public ActionResult SetFileWorkflowState(int fileInfoId, string fileStatus)
        {
            var newFileStatus = _fileUploadInfoBusinessService.SetFileWorkflowState(fileInfoId, fileStatus ,LoggedInUserName);
            return Ok(newFileStatus);
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.AddEdit)]
        [HttpGet("checkFileExists/{fileName}/{selectedAssetClassCode}")]
        public ActionResult<bool> CheckFileExists(string fileName, string selectedAssetClassCode)
        {
            bool isFileExists = _fileUploadInfoBusinessService.CheckFileExists(fileName, selectedAssetClassCode);
            return Ok(isFileExists);
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.AddEdit)]
        [HttpPost("moveFile/{fileName}/{selectedAssetClassCode}")]
        public ActionResult<bool> MoveFile(string filename, string selectedAssetClassCode)
        {
            bool isSuccessfull = _fileUploadInfoBusinessService.MoveFile(filename, selectedAssetClassCode);

            return Ok(isSuccessfull);
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.AddEdit)]
        [HttpGet("downloadTemplate")]
        public ActionResult DownloadTemplate(string templateName)
        {
            string templateFilePath = Path.Combine(_uploadSettings.Value.TemplatePath, templateName);
            var fileStream = new FileStream(templateFilePath, FileMode.Open);

            return File(fileStream, "application/octet-stream", templateName);
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("loadStagingData/{fileInfoId}")]
        public ActionResult<UploadFileStageData> LoadStagingData(int fileInfoId)
        {
            UploadFileStageData output = _fileUploadInfoBusinessService.LoadStagingData(fileInfoId, LoggedInUserName);

            return Ok(output);
        }

        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("getCopyFileSharedPath/{selectedAssetClassCode}")]
        public ActionResult<string> GetCopyFileSharedPath(string selectedAssetClassCode)
        {
            string path = _fileUploadInfoBusinessService.GetCopyFileSharedPath(selectedAssetClassCode);

            return Ok(path);
        }
        
        [SFPAuthorize("FileUploadManagement", PermissionAccessType.View)]
        [HttpGet("getUploadETLMessages/{fileInfoId}")]
        public ActionResult<IList<UploadETLMessage>> GetUploadETLMessages(int fileInfoId)
        {
            List<UploadETLMessage> messages = _fileUploadInfoBusinessService.GetUploadETLMessages(fileInfoId, LoggedInUserName).ToList();

            return Ok(messages);
        }
    }
}
