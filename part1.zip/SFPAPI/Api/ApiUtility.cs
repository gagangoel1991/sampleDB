﻿using NW.SFP.Message;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace SFPAPI.Api
{
    public class ApiUtility
    {
        public static int LogLevel = 1;
    }

    public enum AppModule
    {
        Cashwaterfall = 1,

        PoolSelection = 2
    }
}
