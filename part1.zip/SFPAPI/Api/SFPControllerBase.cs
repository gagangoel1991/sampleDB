﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;
using NW.SFP.Message.Core;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SFPAPI.Api
{
    public class SFPControllerBase : ControllerBase
    {
        public string LoggedInUserName
        {
            get
            {
                return User.Claims.Where(k => k.Type.Equals("UserRacf")).FirstOrDefault().Value;
            }
        }

        public List<string> UserADGroup
        {
            get
            {
                return User.Claims.Where(k => k.Type.Equals("UserADGroup")).FirstOrDefault().Value.Split('|').ToList();
            }
        }

        public string UserAllADGroup
        {
            get
            {
                return User.Claims.Where(k => k.Type.Equals("UserADGroup")).FirstOrDefault().Value;
            }
        }
    }
}
