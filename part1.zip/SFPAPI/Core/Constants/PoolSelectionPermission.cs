﻿using System.ComponentModel;

namespace NW.SFP.API.Core.Constants
{
    public enum PoolSelectionPermission
    {
        //PS Dashboard
        [Description("Pool Selection Dashboard Access")]
        Dashboard = 1001,

        //Pool List
        [Description("Pool Management Access")]
        PS_PoolManagement = 4,

        // Eligibility Management
        [Description("Pool Selection - Eligibility Management")]
        PS_EligibilityManagement = 5,
        
        // Exclusion Management
        [Description("Pool Selection - Exclusion")]
        PS_ExclusionManagement = 6,
        
        // Pool Selection Dashboard
        [Description("Pool Selection - Dashboard")]
        PS_Dashboard = 8,

        // Field Management
        [Description("Pool Selection - Field Management")]
        PS_FieldManagement = 9,
    }
}
