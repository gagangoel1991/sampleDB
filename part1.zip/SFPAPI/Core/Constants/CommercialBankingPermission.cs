﻿using System.ComponentModel;

namespace NW.SFP.API.Core.Constants
{
    public enum CommercialBankingPermission
    {
        //DealDataCorrection Management
        [Description("DealDataCorrection Management Access")]
        CB_DealDataCorrectionManagement = 18
    }
}
