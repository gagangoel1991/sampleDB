﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Threading.Tasks;

namespace NW.SFP.API.Core.Constants
{
    public enum CWPermissionEnum
    {
        //CW Dashboard
        [Description("Cashwaterfall Dashboard")]
        CW_Dashboard = 1,

        [Description("Invoice Management Listing Access")]
        CW_InvoiceMgmt = 2,

        [Description("Deal List Access")]
        DealMgmt = 3
    }

    public enum PermissionAccessType
    {
        [Description("View Access")]
        View = 1,

        [Description("Add Edit Access")]
        AddEdit = 2,

        [Description("Delete Access")]
        Delete = 3,

        [Description("Approve-Reject Access")]
        ApproveReject = 4
    }
}
