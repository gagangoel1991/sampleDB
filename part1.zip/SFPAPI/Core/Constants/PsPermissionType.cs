﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel;

namespace NW.SFP.API.Core.Constants
{
    public enum PsPermissionAccessType
    {
        [Description("View Access")]
        View = 1,

        [Description("Add Edit Access")]
        AddEdit = 2,

        [Description("Delete Access")]
        Delete = 3,

        [Description("Approve-Reject Access")]
        ApproveReject = 4
    }
}
