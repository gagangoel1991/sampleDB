﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Message.core;
using System.Collections.Generic;

namespace SFPAPI.Api.Core
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/datelist")]
    [Authorize]
    public class DateListController : SFPControllerBase, IDateListController
    {
        #region Variables  declaration and Construction
        private readonly IDateListService _dateListService;
        private readonly ILoggerService _loggerService;

        public DateListController(IDateListService dateListService, ILoggerService loggerService)
        {
            _dateListService = dateListService;
            _loggerService = loggerService;
        }
        #endregion

        #region Get holiday list

        [SFPAuthorize("WorkflowManagement", PermissionAccessType.View)]
        [HttpGet("getHolidayList")]
        public IList<HolidayDate> GetHolidayList()
        {
            return this._dateListService.GetHolidayList();
        }
        #endregion
    }
}