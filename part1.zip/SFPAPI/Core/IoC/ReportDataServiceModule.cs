﻿namespace NW.SFP.API.Core.IoC
{
    using Autofac;
    using NW.SFP.DataService.Core;
    using NW.SFP.DataService.CW;
    using NW.SFP.DataService.CW.IpdRunProcess;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Interface.CW.DataService;

    public class ReportDataServiceModule : Module
    {


        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type

           
          
            #endregion

            #region Register Class 

           

            #endregion
        }
    }
}
