namespace NW.SFP.API.Core.IoC
{
    using Autofac;
    using NW.SFP.BusinessService.Core;
    using NW.SFP.BusinessService.CW;
    using NW.SFP.BusinessService.CW.IpdRunProcess;
    using NW.SFP.DataService.Core;
    using NW.SFP.DataService.CW;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Interface.CW.DataService;
    using NW.SFP.DataService.CW.IpdRunProcess;
    using NW.SFP.Message.Core;
    using Microsoft.Extensions.Options;
    using NW.SFP.Interface.CW.BusinessService;
    using NW.SFP.DataService.CW.CB;
    using NW.SFP.BusinessService.CW.CB;
    using NW.SFP.Interface.CW.CB;
    using NW.SFP.DataService.CW.DailyCashCollections;

    public class CWBusinessServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type

            builder.RegisterType<AuthDataService>().As<IAuthDataService>();
            builder.RegisterType<KeyValueLookupDataService>().As<IKeyValueLookupDataService>();
            builder.RegisterType<LoggerDataService>().As<ILoggerDataService>();


            builder.RegisterType<IrReportService>().As<IIrReportService>();

            builder.RegisterType<ExcelService>().As<IExcelService>();
            builder.RegisterType<SelectlookupService>().As<ISelectLookupService>();
            builder.RegisterType<StratService>().As<IStratService>();
            builder.RegisterType<IrTemplateService>().As<IIrTemplateService>();

            builder.RegisterType<InvoiceCategoryTypeDataService>().As<IInvoiceCategoryTypeDataService>();
            builder.RegisterType<InvoiceCategoryDataService>().As<IInvoiceCategoryDataService>();
            builder.RegisterType<InvoiceDataService>().As<IInvoiceDataService>();
            builder.RegisterType<InvoiceFacadeService>().As<IInvoiceFacadeService>();

            builder.RegisterType<APITokenDataService>().As<IAPITokenDataService>();

            //Deal
            builder.RegisterType<DealDataService>().As<IDealDataService>();
            builder.RegisterType<DealDateDataService>().As<IDealDateDataService>();


            //Deal Counterparty
            builder.RegisterType<DealCounterpartyDataService>().As<IDealCounterpartyDataService>();

            //Investor Report
            builder.RegisterType<IrLookupDataService>().As<IIrLookupDataService>();
            builder.RegisterType<DealIrConfigDataService>().As<IDealIrConfigDataService>();

            //IPD Run
            builder.RegisterType<AdjustmentWaterfallService>().As<IAdjustmentWaterfallService>();

            //IPD Parent Deal Run

            builder.RegisterType<IpdProcessParentService>().As<IIpdProcessParentService>();

            builder.RegisterType<ManualFieldDataService>().As<IManualFieldDataService>();

            builder.RegisterType<CollectionsInterestDataService>().As<ICollectionsInterestDataService>();

            builder.RegisterType<ReservesInterestDataService>().As<IReservesInterestDataService>();

            //Automated Data
            builder.RegisterType<CashLadderDataService>().As<ICashLadderDataService>();
            builder.RegisterType<DailyCollectionDataService>().As<IDailyCollectionDataService>();
            builder.RegisterType<CollectionLedgerDataService>().As<ICollectionLedgerDataService>();
            builder.RegisterType<BondRatingDataService>().As<IBondRatingDataService>();
            builder.RegisterType<CreditRatingDataService>().As<ICreditRatingDataService>();
            builder.RegisterType<CounterpartyRatingDataService>().As<ICounterpartyRatingDataService>();
            builder.RegisterType<InterestRateDataService>().As<IInterestRateDataService>();
            builder.RegisterType<SubloanDataService>().As<ISubloanDataService>();
            builder.RegisterType<ReserveDataService>().As<IReserveDataService>();
            builder.RegisterType<RatingUploadDataService>().As<IRatingUploadDataService>();
            builder.RegisterType<PdlBreakdownDataService>().As<IPdlBreakdownDataService>();
            builder.RegisterType<UpstreamDataAuthWorkflowDataService>().As<IUpstreamDataAuthWorkflowDataService>();
            builder.RegisterType<DealSwapDataService>().As<IDealSwapDataService>();
            builder.RegisterType<SwapCollateralDataService>().As<ISwapCollateralDataService>();
            builder.RegisterType<PreMaturityLiquidityDataService>().As<IPreMaturityLiquidityDataService>();
            builder.RegisterType<ReserveFundDataService>().As<IReserveFundDataService>();
            builder.RegisterType<CouponPaymentDataService>().As<ICouponPaymentDataService>();
            builder.RegisterType<FundsFacadeService>().As<IFundsFacadeService>();
            builder.RegisterType<BondSwapDataService>().As<IBondSwapDataService>();
            builder.RegisterType<TestService>().As<ITestService>();

            builder.RegisterType<SwapCollateralService>().As<ISwapCollateralService>();
            builder.RegisterType<ReserveFundService>().As<IReserveFundService>();
            builder.RegisterType<PreMaturityLiquidityService>().As<IPreMaturityLiquidityService>();
            builder.RegisterType<CouponPaymentService>().As<ICouponPaymentService>();
            builder.RegisterType<CBNoteSummaryDataService>().As<ICBNoteSummaryDataService>();

            //CW Dashboard
            builder.RegisterType<IpdManagementDataService>().As<IIpdManagementDataService>();
            builder.RegisterType<NoteSummaryDataService>().As<INoteSummaryDataService>();
            builder.RegisterType<PdlSummaryDataService>().As<IPdlSummaryDataService>();
            builder.RegisterType<RatingTriggerDataService>().As<IRatingTriggerDataService>();
            builder.RegisterType<NonRatingTriggerDataService>().As<INonRatingTriggerDataService>();
            builder.RegisterType<IpdAuthWorkflowDataService>().As<IIpdAuthWorkflowDataService>();

            builder.RegisterType<AdjustmentWaterfallOutputDataService>().As<IAdjustmentWaterfallOutputDataService>();
            builder.RegisterType<DealConditionTestDataService>().As<IDealConditionTestDataService>();

            //Controls
            builder.RegisterType<DealIpdControlsDataService>().As<IDealIpdControlsDataService>();
            builder.RegisterType<AutomatedPostWaterfallControlService>().As<IAutomatedPostWaterfallControlService>();

            //IPD Summary
            builder.RegisterType<IpdSummaryDataService>().As<IIpdSummaryDataService>();

            //Audit Trail
            builder.RegisterType<WorkflowAuditDataService>().As<IWorkflowAuditDataService>();

            //Post Waterfall Controls
            builder.RegisterType<PostWaterfallDataService>().As<IPostWaterfallDataService>();

            //Data load  Controls
            builder.RegisterType<DataLoadService>().As<IDataLoadService>();

            //Deal Note
            builder.RegisterType<DealNoteDataService>().As<IDealNoteDataService>();

            // Daily Cash Collections
            builder.RegisterType<DailyCashCollectionsService>().As<IDailyCashCollectionsService>();
            builder.RegisterType<DailyCashEstimationService>().As<IDailyCashEstimationService>();
            builder.RegisterType<DealSummaryOutputDataService>().As<IDealSummaryOutputDataService>();
            builder.RegisterType<DailyCollectionDealDataSummary>().As<IDailyCollectionDealDataSummary>();

            //Email Config
            builder.RegisterType<EmailConfigDataService>().As<IEmailConfigDataService>();
            builder.RegisterType<EmailService>().As<IEmailService>();

            //Booking
            builder.RegisterType<BookingDataService>().As<IBookingDataService>();
            builder.RegisterType<BookingIPDDataService>().As<IBookingIPDDataService>();

            //Deflag
            builder.RegisterType<DeflagAdjustmentDataService>().As<IDeflagAdjustmentDataService>();

            #endregion

            #region Register Class 
            builder.Register(c => new LoggerService(c.Resolve<ILoggerDataService>()));
            builder.Register(c => new KeyValueLookupService(c.Resolve<IKeyValueLookupDataService>()));
            builder.Register(c => new AuthService(c.Resolve<IAuthDataService>()));

            builder.Register(c => new InvoiceService(c.Resolve<IInvoiceDataService>()));
            builder.Register(c => new InvoiceFacadeService(c.Resolve<IInvoiceService>(), c.Resolve<IInvoiceCategoryService>(),
                c.Resolve<IInvoiceCategoryTypeService>()));

            builder.Register(c => new IrReportService(c.Resolve<IIrReportDataService>(), c.Resolve<IExcelService>(), c.Resolve<ILoggerService>()));

            //Auotmated PostWF
            builder.Register(c => new AutomatedPostWaterfallControlService(c.Resolve<IIrReportDataService>(), c.Resolve<IExcelService>(), c.Resolve<ILoggerService>(),
                c.Resolve<IOptions<CashWaterfallSettings>>(), c.Resolve<IPostWaterfallDataService>()));

            //Deal
            builder.Register(c => new DealService(c.Resolve<IDealDataService>()));
            builder.Register(c => new DealDateService(c.Resolve<IDealDateDataService>()));

            //Strat
            
            //CW Dashboard
            builder.Register(c => new IpdManagementService(c.Resolve<IIpdManagementDataService>()));

            //Deal Counterparty
            builder.Register(c => new DealCounterpartyService(c.Resolve<IDealCounterpartyDataService>()));

            //Investor Report
            builder.Register(c => new IrLookupService(c.Resolve<IIrLookupDataService>()));
            builder.Register(c => new DealIrConfigService(c.Resolve<IDealIrConfigDataService>()));

            //automated Data
            builder.Register(c => new CashLadderService(c.Resolve<ICashLadderDataService>()));
            builder.Register(c => new CollectionLedgerService(c.Resolve<ICollectionLedgerDataService>()));
            builder.Register(c => new DailyCollectionService(c.Resolve<IDailyCollectionDataService>()));
            builder.Register(c => new BondRatingService(c.Resolve<IBondRatingDataService>(), c.Resolve<ICreditRatingDataService>()));
            builder.Register(c => new CounterpartyRatingService(c.Resolve<ICounterpartyRatingDataService>(), c.Resolve<ICreditRatingDataService>()));
            builder.Register(c => new InterestRateService(c.Resolve<IInterestRateDataService>()));
            builder.Register(c => new SubloanService(c.Resolve<ISubloanDataService>()));
            builder.Register(c => new ReserveService(c.Resolve<IReserveDataService>()));
            builder.Register(c => new PdlBreakdownService(c.Resolve<IPdlBreakdownDataService>()));
            builder.Register(c => new NoteSummaryService(c.Resolve<INoteSummaryDataService>()));
            builder.Register(c => new PdlSummaryService(c.Resolve<IPdlSummaryDataService>()));
            builder.Register(c => new TriggerService(c.Resolve<IRatingTriggerDataService>(), c.Resolve<INonRatingTriggerDataService>()));
            builder.Register(c => new UpstreamDataAuthWorkflowService(c.Resolve<IUpstreamDataAuthWorkflowDataService>()));
            builder.Register(c => new IpdAuthWorkflowService(c.Resolve<IIpdAuthWorkflowDataService>()));
            builder.Register(c => new DealSwapService(c.Resolve<IDealSwapDataService>()));
            builder.Register(c => new SwapCollateralService(c.Resolve<ISwapCollateralDataService>()));
            //builder.Register(c => new LedgersFundService(c.Resolve<ILedgersFundDataService>()));
            builder.Register(c => new ReserveFundService(c.Resolve<IReserveFundDataService>()));
            builder.Register(c => new PreMaturityLiquidityService(c.Resolve<IPreMaturityLiquidityDataService>()));
            builder.Register(c => new CouponPaymentService(c.Resolve<ICouponPaymentDataService>()));
            builder.Register(c => new FundsFacadeService(c.Resolve<ISwapCollateralService>(), c.Resolve<IReserveFundService>(), c.Resolve<IPreMaturityLiquidityService>(), c.Resolve<ICouponPaymentService>(), c.Resolve<ILedgersFundService>()));
            builder.Register(c => new BondSwapService(c.Resolve<IBondSwapDataService>()));
            builder.Register(c => new CBNoteSummaryService(c.Resolve<ICBNoteSummaryDataService>()));
            builder.RegisterType<LedgersFundService>().As<ILedgersFundService>();

            //Rating Upload
            builder.Register(c => new RatingUploadService(c.Resolve<IRatingUploadDataService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));
            builder.Register(c => new DealConditionTestService(c.Resolve<IDealConditionTestDataService>()));

            //Controls
            builder.Register(c => new DealIpdControlsService(c.Resolve<IDealIpdControlsDataService>()));

            //IPD Summary
            builder.Register(c => new IpdSummaryService(c.Resolve<IIpdSummaryDataService>()));

            //Audit Trail
            builder.Register(c => new WorkflowAuditService(c.Resolve<IWorkflowAuditDataService>()));

            //Manual Values  
            builder.Register(c => new ManualFieldService(c.Resolve<IManualFieldDataService>()));


            //Collections and Reserves 
            builder.Register(c => new CollectionsAndReservesInterestService(c.Resolve<ICollectionsInterestDataService>(), c.Resolve<IReservesInterestDataService>()));

            //Sonia Compounding
            builder.Register(c => new SoniaCompoundingService(c.Resolve<ISoniaCompoundingDataService>()));

            //Adhoc Data Load 
            builder.Register(c => new DataLoadService(c.Resolve<IDataLoadDataService>()));


            builder.Register(c => new APITokenService(c.Resolve<IAPITokenDataService>()));

            //Deal Note
            builder.Register(c => new DealNoteService(c.Resolve<IDealNoteDataService>()));

            // Daily Cash Collections
            builder.Register(c => new DailyCashCollectionsService(c.Resolve<IDailyCashCollectionsDataService>(), c.Resolve<IExcelService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new DailyCashEstimationService(c.Resolve<IDailyCashCollectionsDataService>()));
            builder.Register(c => new DealSummaryOutputService(c.Resolve<IDealSummaryOutputDataService>(), c.Resolve<IDailyCollectionDealDataSummary>()));
            //Email Config
            builder.Register(c => new EmailConfigService(c.Resolve<IEmailConfigDataService>()));

            //Booking

            builder.Register(c => new BookingService(c.Resolve<IBookingDataService>(), c.Resolve<IBookingIPDDataService>(), c.Resolve<IExcelService>(), c.Resolve<ILoggerService>()));


            //Deflag
            builder.Register(c => new DeflagAdjustmentService(c.Resolve<IDeflagAdjustmentDataService>()));


         

            #endregion

        }
    }
}