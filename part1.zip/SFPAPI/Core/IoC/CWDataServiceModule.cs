﻿namespace NW.SFP.API.Core.IoC
{
    using Autofac;
    using NW.SFP.DataService.Core;
    using NW.SFP.DataService.CW;
    using NW.SFP.DataService.CW.CB;
    using NW.SFP.DataService.CW.IpdRunProcess;
    using NW.SFP.Interface.Core;
    using NW.SFP.Interface.CW;
    using NW.SFP.Interface.CW.CB;
    using NW.SFP.Interface.CW.DataService;

    public class CWDataServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type

            builder.RegisterType<UnitOfWork>().As<IUnitOfWork>().InstancePerLifetimeScope();

            builder.RegisterType<IrReportDataService>().As<IIrReportDataService>();
            builder.RegisterType<StratConfigtDataService>().As<IStratConfigtDataService>();
            builder.RegisterType<StratDealTypeDataService>().As<IStratDealTypeDataService>();
            builder.RegisterType<SelectLookupDataService>().As<ISelectLookupDataService>();
            builder.RegisterType<StratDataService>().As<IStratDataService>();
            builder.RegisterType<IrTemplateDataService>().As<IIrTemplateDataService>();
            builder.RegisterType<CashLadderDataService>().As<ICashLadderDataService>();
            builder.RegisterType<DailyCollectionDataService>().As<IDailyCollectionDataService>();
            builder.RegisterType<AdjustmentWaterfallDataService>().As<IAdjustmentWaterfallDataService>();
            builder.RegisterType<IpdProcessParentDataService>().As<IIpdProcessParentDataService>();
            builder.RegisterType<AdjustmentWaterfallOutputDataService>().As<IAdjustmentWaterfallOutputDataService>();
            builder.RegisterType<ManualFieldDataService>().As<IManualFieldDataService>();
            builder.RegisterType<CollectionsInterestDataService>().As<ICollectionsInterestDataService>();
            builder.RegisterType<ReservesInterestDataService>().As<IReservesInterestDataService>();
            builder.RegisterType<SoniaCompoundingDataService>().As<ISoniaCompoundingDataService>();
            builder.RegisterType<TestDataService>().As<ITestDataService>();
            builder.RegisterType<DataLoadDataService>().As<IDataLoadDataService>();
            builder.RegisterType<DailyCashCollectionsDataService>().As<IDailyCashCollectionsDataService>();
            builder.RegisterType<LedgersFundDataService>().As<ILedgersFundDataService>();

            #endregion

            #region Register Class 

            builder.RegisterGeneric(typeof(Repository<>))
                .As(typeof(IRepository<>))
                .InstancePerRequest();

            #endregion
        }
    }
}
