﻿using Autofac;

namespace SFPAPI.Core.IoC
{
    public class PsDataServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type


            #endregion

            #region Register Class 

            #endregion
        }
    }
}
