﻿using Autofac;
using NW.SFP.DataService.Upload;
using NW.SFP.Message.Core;
using NW.SFP.Interface.Upload;
using Microsoft.Extensions.Options;
using NW.SFP.Message.ConnectionManager;

namespace NW.SFP.API.Core.IoC
{
    public class UploadDataServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<FileUploadInfoDataService>().As<IFileUploadInfoDataService>();
            builder.Register(c => new FileUploadInfoDataService(c.Resolve<IOptions<DataServiceSettings>>(), c.Resolve<IOptions<UploadSettings>>(), c.Resolve<IOptions<DBConnectionSettings>>()));
            builder.RegisterType<FileUploadUtilityDataService>().As<IFileUploadUtilityDataService>();
        }
    }
}
