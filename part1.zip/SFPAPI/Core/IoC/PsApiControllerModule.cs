﻿using Autofac;
using Microsoft.Extensions.Options;
using NW.SFP.API.Auth;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.BusinessService.Core;
using NW.SFP.BusinessService.PS;
using NW.SFP.BusinessService.PS.PoolAdhocReport;
using NW.SFP.BusinessService.Report;
using NW.SFP.DataService.PS;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.PS;
using NW.SFP.Interface.PS.BusinessService;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Queue.Publisher;
using NW.SFP.Queue.Subscriber;
using NW.SFPAPI.Api.PS;
using SFPAPI.Api.Core;
using SFPAPI.Api.PS;

namespace NW.SFPAPI.Core.IoC
{
    public class PsApiControllerModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Register Type HERE
            builder.RegisterType<PoolService>().As<IPoolService>();            
            builder.RegisterType<PoolReferenceLookupService>().As<IPoolReferenceLookupService>();
            builder.RegisterType<ConcentrationReferenceLookupService>().As<IConcentrationReferenceLookupService>();
            builder.RegisterType<ConcentrationService>().As<IConcentrationService>();
            builder.RegisterType<LoggerService>().As<ILoggerService>();
            builder.RegisterType<EligibilityService>().As<IEligibilityService>();
            builder.RegisterType<AssetClassService>().As<IAssetClassService>();
            builder.RegisterType<FieldManagementService>().As<IFieldManagementService>();
            builder.RegisterType<ExclusionService>().As<IExclusionService>();
            builder.RegisterType<DashboardPoolSelectionService>().As<IDashboardPoolSelectionService>();
            builder.RegisterType<PoolAdhocReportService>().As<IPoolAdhocReportService>();
            builder.RegisterType<AuthWorkflowService>().As<IAuthWorkflowService>();
            builder.RegisterType<DateListService>().As<IDateListService>();
            builder.RegisterType<ReplinseReportService>().As<IReplinesReportService>();
            builder.RegisterType<SubscriberService>().As<IQueueSubscriberService>();
            builder.RegisterType<PublisherService>().As<IQueuePublisherService>();
            builder.RegisterType<ListingPageService>().As<IListingPageService>();
            builder.RegisterType<ReferenceRegistryReportService>().As<IReferenceRegistryReportService>();

            #endregion

            #region Register Class HERE
            builder.Register(c => new UserInfoClaimsTransformation(c.Resolve<IAuthService>()));
            builder.Register(c => new AuthenticationController(c.Resolve<IAuthService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new PoolController(c.Resolve<IPoolService>()));
            builder.Register(c => new PoolReferenceLookupController(c.Resolve<IPoolReferenceLookupService>()));
            builder.Register(c => new SFPAuthorizeActionFilter(string.Empty, PermissionAccessType.View, c.Resolve<IAuthService>()));
            builder.Register(c => new EligibilityController(c.Resolve<IEligibilityService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new ConcentrationReferenceLookupController(c.Resolve<IConcentrationReferenceLookupService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new ConcentrationController(c.Resolve<IConcentrationService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new AssetClassController(c.Resolve<IAssetClassService>()));
            builder.Register(c => new FieldManagementController(c.Resolve<IFieldManagementService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new ExclusionController(c.Resolve<IExclusionService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new DashboardPoolSelectionController(c.Resolve<IDashboardPoolSelectionService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new PoolAdhocReportController(c.Resolve<IPoolAdhocReportService>()));
            builder.Register(c => new AuthWorkflowController(c.Resolve<IAuthWorkflowService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new DateListController(c.Resolve<IDateListService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new ReplinseReportController(c.Resolve<IReplinesReportService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new ListingPageController(c.Resolve<IListingPageService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new ReferenceRegistryReportController(c.Resolve<IReferenceRegistryReportService>(), c.Resolve<IDealIrConfigService>(), c.Resolve<ILoggerService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));

            #endregion

        }
    }
}
