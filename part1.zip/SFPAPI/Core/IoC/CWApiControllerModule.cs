﻿using Autofac;
using Microsoft.Extensions.Options;
using NW.SFP.API.Api.CW;
using NW.SFP.API.Api.CW.IpdRunProcess;
using NW.SFP.API.Auth;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.API.CW;
using NW.SFP.BusinessService.Core;
using NW.SFP.BusinessService.CW;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.CW.BusinessService;
using NW.SFP.Message.Core;
using SFPAPI.Api.CW;
using NW.SFP.BusinessService.CW.IpdRunProcess;
using NW.SFP.API.Api.CW.Dashboard;
using NW.SFP.BusinessService.CW.CB;
using NW.SFP.Interface.CW.CB;
using NW.SFP.API.Api.CW.CB;
using NW.SFP.API.Core.Token;
using NW.SFP.API.Api;


namespace NW.SFP.API.Core.IoC
{
    public class CWApiControllerModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type

            builder.RegisterType<AuthService>().As<IAuthService>();
            builder.RegisterType<KeyValueLookupService>().As<IKeyValueLookupService>();
            builder.RegisterType<LoggerService>().As<ILoggerService>();

            builder.RegisterType<InvoiceCategoryTypeService>().As<IInvoiceCategoryTypeService>();
            builder.RegisterType<InvoiceCategoryService>().As<IInvoiceCategoryService>();
            builder.RegisterType<InvoiceService>().As<IInvoiceService>();
            builder.RegisterType<InvoiceFacadeService>().As<IInvoiceFacadeService>();
            builder.RegisterType<APITokenService>().As<IAPITokenService>();

            //Deal
            builder.RegisterType<DealService>().As<IDealService>();
            builder.RegisterType<DealDateService>().As<IDealDateService>();

            //Deal Counterparty
            builder.RegisterType<DealCounterpartyService>().As<IDealCounterpartyService>();

            //Investor Report
            builder.RegisterType<IrLookupService>().As<IIrLookupService>();
            builder.RegisterType<DealIrConfigService>().As<IDealIrConfigService>();

            //automated data
            builder.RegisterType<CashLadderService>().As<ICashLadderService>();
            builder.RegisterType<DailyCollectionService>().As<IDailyCollectionService>();
            builder.RegisterType<CollectionLedgerService>().As<ICollectionLedgerService>();
            builder.RegisterType<BondRatingService>().As<IBondRatingService>();
            builder.RegisterType<CounterpartyRatingService>().As<ICounterpartyRatingService>();

            builder.RegisterType<InterestRateService>().As<IInterestRateService>();
            builder.RegisterType<SubloanService>().As<ISubloanService>();
            builder.RegisterType<ReserveService>().As<IReserveService>();
            builder.RegisterType<PdlBreakdownService>().As<IPdlBreakdownService>();
            builder.RegisterType<NoteSummaryService>().As<INoteSummaryService>();
            builder.RegisterType<RatingUploadService>().As<IRatingUploadService>();
            builder.RegisterType<PdlSummaryService>().As<IPdlSummaryService>();
            builder.RegisterType<TriggerService>().As<ITriggerService>();
            builder.RegisterType<UpstreamDataAuthWorkflowService>().As<IUpstreamDataAuthWorkflowService>();
            builder.RegisterType<DealSwapService>().As<IDealSwapService>();
            builder.RegisterType<FundsFacadeService>().As<IFundsFacadeService>();
            builder.RegisterType<BondSwapService>().As<IBondSwapService>();
            builder.RegisterType<CBNoteSummaryService>().As<ICBNoteSummaryService>();

            //CW Dashboard
            builder.RegisterType<IpdManagementService>().As<IIpdManagementService>();
            builder.RegisterType<DealConditionTestService>().As<IDealConditionTestService>();

            //ipd auth workflow
            builder.RegisterType<IpdAuthWorkflowService>().As<IIpdAuthWorkflowService>();

            //Controls
            builder.RegisterType<DealIpdControlsService>().As<IDealIpdControlsService>();

            //IPD Summary
            builder.RegisterType<IpdSummaryService>().As<IIpdSummaryService>();

            //Audit Trail
            builder.RegisterType<WorkflowAuditService>().As<IWorkflowAuditService>();

            builder.RegisterType<ManualFieldService>().As<IManualFieldService>();

            builder.RegisterType<CollectionsAndReservesInterestService>().As<ICollectionsAndReservesInterestService>();

            //Sonia Compounding
            builder.RegisterType<SoniaCompoundingService>().As<ISoniaCompoundingService>();

            //Deal Note

            builder.RegisterType<DealNoteService>().As<IDealNoteService>();

            builder.RegisterType<DealSummaryOutputService>().As<IDealSummaryOutputService>();

            //Email Config
            builder.RegisterType<EmailConfigService>().As<IEmailConfigService>();

            //Booking

            builder.RegisterType<BookingService>().As<IBookingService>();

            //Deflag
            builder.RegisterType<DeflagAdjustmentService>().As<IDeflagAdjustmentService>();

            #endregion

            #region Register Class 

            builder.Register(c => new UserInfoClaimsTransformation(c.Resolve<IAuthService>()));
            builder.Register(c => new KeyValueLookupController(c.Resolve<IKeyValueLookupService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new AuthenticationController(c.Resolve<IAuthService>(), c.Resolve<ILoggerService>()));

            builder.Register(c => new InvoiceController(c.Resolve<IInvoiceFacadeService>(), c.Resolve<ILoggerService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));

            builder.Register(c => new SFPAuthorizeActionFilter(string.Empty, PermissionAccessType.View, c.Resolve<IAuthService>()));

            builder.Register(c => new ValidateTokenAttributeExtended(c.Resolve<IAPITokenService>()));

            //Deal
            builder.Register(c => new DealController(c.Resolve<IDealService>()));
            builder.Register(c => new DealDateController(c.Resolve<IDealDateService>()));

            //Deal Counterparty
            builder.Register(c => new DealCounterpartyController(c.Resolve<IDealCounterpartyService>()));

            //Investor Report
            builder.Register(c => new IrLookupController(c.Resolve<IIrLookupService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new DealIrConfigController(c.Resolve<IDealIrConfigService>(), c.Resolve<ILoggerService>(), c.Resolve<IOptions<CashWaterfallSettings>>(), c.Resolve<IrReportService>(), c.Resolve<IExcelService>()));

            //CW Dashboard
            builder.Register(c => new IpdManagementController(c.Resolve<IIpdManagementService>(), c.Resolve<ILoggerService>()));

            //IPF Summary
            builder.Register(c => new IpdSummaryController(c.Resolve<IIpdSummaryService>(), c.Resolve<ILoggerService>()));

            //Audit Trail
            builder.Register(c => new WorkflowAuditController(c.Resolve<IWorkflowAuditService>()));

            #endregion

            //automated data 
            builder.Register(c => new CashLadderController(c.Resolve<ICashLadderService>()));
            builder.Register(c => new DailyCollectionController(c.Resolve<IDailyCollectionService>()));
            builder.Register(c => new CollectionLedgerController(c.Resolve<ICollectionLedgerService>()));
            builder.Register(c => new BondRatingController(c.Resolve<IBondRatingService>()));
            builder.Register(c => new CounterPartyRatingController(c.Resolve<ICounterpartyRatingService>()));
            builder.Register(c => new InterestRateController( c.Resolve<IInterestRateService>()));
            builder.Register(c => new SubloanController(c.Resolve<ISubloanService>()));
            builder.Register(c => new ReserveController(c.Resolve<IReserveService>()));
            builder.Register(c => new PdlBreakdownController(c.Resolve<IPdlBreakdownService>()));
            builder.Register(c => new NoteSummaryController(c.Resolve<INoteSummaryService>()));
            builder.Register(c => new RatingUploadController(c.Resolve<IRatingUploadService>(), c.Resolve<ILoggerService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));
            builder.Register(c => new PdlSummaryController(c.Resolve<IPdlSummaryService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new TriggerController(c.Resolve<ITriggerService>()));
            builder.Register(c => new UpstreamDataAuthWorkflowController(c.Resolve<IUpstreamDataAuthWorkflowService>()));
            builder.Register(c => new DealConditionTestController(c.Resolve<IDealConditionTestService>()));
            builder.Register(c => new DealSwapController(c.Resolve<IDealSwapService>()));
            builder.Register(c => new FundsController(c.Resolve<IFundsFacadeService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new BondSwapController(c.Resolve<IBondSwapService>()));
            builder.Register(c => new CBNoteSummaryController(c.Resolve<ICBNoteSummaryService>()));
            //ipd auth workflow
            builder.Register(c => new IpdAuthWorkflowController(c.Resolve<IIpdAuthWorkflowService>()));

            //Controls
            builder.Register(c => new DealIpdControlsController(c.Resolve<IDealIpdControlsService>(), c.Resolve<IExcelService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));
            builder.Register(c => new DownloadIrController(c.Resolve<ILoggerService>(), c.Resolve<IrReportService>(), c.Resolve<IExcelService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));
            //Post Waterfall Controls
            builder.Register(c => new PostWaterfallController(c.Resolve<IAutomatedPostWaterfallControlService>(), c.Resolve<IExcelService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));

            //Manual Values  
            builder.Register(c => new ManualFieldController(c.Resolve<IManualFieldService>()));

            //Collections And Reserves
            builder.Register(c => new CollectionsAndReservesInterestController(c.Resolve<ICollectionsAndReservesInterestService>()));

            //Sonia Compounding
            builder.Register(c => new SoniaCompoundingController(c.Resolve<ISoniaCompoundingService>()));

            //Deal Note
            builder.Register(c => new DealNoteController(c.Resolve<IDealNoteService>(), c.Resolve<ILoggerService>()));

            //Deal Collection
            builder.Register(c => new DealCollectionsController(c.Resolve<IDailyCashCollectionsService>(), c.Resolve<IDailyCashEstimationService>(),
                                         c.Resolve<IDealSummaryOutputService>(), c.Resolve<ILoggerService>(), c.Resolve<IOptions<CashWaterfallSettings>>(), c.Resolve<IEmailService>()));
            //Email Config
            builder.Register(c => new EmailConfigController(c.Resolve<IEmailConfigService>(), c.Resolve<ILoggerService>()));

            //Booking
            builder.Register(c => new BookingController(c.Resolve<IBookingService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));

            //Deflag
            builder.Register(c => new DeflagController(c.Resolve<IDeflagAdjustmentService>(), c.Resolve<ILoggerService>(), c.Resolve<IOptions<CashWaterfallSettings>>(),c.Resolve<IExcelService>()));

        }
    }
}