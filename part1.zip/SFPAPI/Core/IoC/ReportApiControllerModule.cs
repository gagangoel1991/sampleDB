﻿using Autofac;
using Microsoft.Extensions.Options;
using NW.SFP.API.Api.Reports;
using NW.SFP.API.CW;
using NW.SFP.BusinessService.CW;
using NW.SFP.BusinessService.Report;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.Report;
using NW.SFP.Interface.Report.BusinessService;
using NW.SFP.Message.Core;
using NW.SFPAPI.Api.PS;
using NW.SFP.Interface.Report.BusinessService;
using NW.SFP.API.Api.Reports;

namespace NW.SFP.API.Core.IoC
{
    public class ReportApiControllerModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type

            //Investor Reports
            builder.RegisterType<InvestorReportService>().As<IInvestorReportService>();
            builder.RegisterType<ESMAReportService>().As<IESMAReportService>();
            //Generic Report from SFP to SFP+
            builder.RegisterType<ReportService>().As<IReportService>();
            builder.RegisterType<NWReportsService>().As<INWMReportsService>();
          
            #endregion

            #region Register Class 

            //Report

            //Investor Report
            builder.Register(c => new InvestorReportController(c.Resolve<IInvestorReportService>(),  c.Resolve<ILoggerService>(), c.Resolve<IrReportService>(), c.Resolve<IExcelService>()
                , c.Resolve<IOptions<CashWaterfallSettings>>(), c.Resolve<IAutomatedPostWaterfallControlService>() ));
            builder.Register(c => new ESMAReportController(c.Resolve<IESMAReportService>(), c.Resolve<ILoggerService>()));
            // Generic Reports
            builder.Register(c => new ReportController(c.Resolve<IReportService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new NWMReportsController(c.Resolve<INWMReportsService>(), c.Resolve<ILoggerService>()));
            #endregion


        }

    }
}
