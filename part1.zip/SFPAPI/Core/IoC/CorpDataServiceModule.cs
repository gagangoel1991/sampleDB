﻿using Autofac;
using NW.SFP.DataService.CB;
using NW.SFP.Interface.CB;

namespace NW.SFP.API.Core.IoC
{
    public class CorpDataServiceModule: Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<DataCorrectionDataService>().As<IDataCorrectionDataService>();
            builder.RegisterType<DataCorrectionRefDataService>().As<IDataCorrectionRefDataService>();
            builder.RegisterType<LossManagementDataService>().As<ILossManagementDataService>();
        }
    }
}