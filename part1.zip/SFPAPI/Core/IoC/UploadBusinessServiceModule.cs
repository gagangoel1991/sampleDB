﻿using Autofac;
using NW.SFP.BusinessService.Upload;
using NW.SFP.Interface.Upload;
using NW.SFP.Interface.Upload.BusinessService;

namespace NW.SFP.API.Core.IoC
{
    public class UploadBusinessServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            builder.RegisterType<FileUploadInfoBusinessService>().As<IFileUploadInfoBusinessService>();
            builder.RegisterType<FileUploadUtilityBusinessService>().As<IFileUploadUtilityBusinessService>();
        }
    }
}
