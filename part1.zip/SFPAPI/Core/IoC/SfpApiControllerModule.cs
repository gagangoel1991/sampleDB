﻿using Autofac;
using NW.SFP.BusinessService.SFP;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.SFP;
using NW.SFPAPI.Api.PS;

namespace NW.SFPAPI.Core.IoC
{
    public class SfpApiControllerModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Register Type HERE

            builder.RegisterType<SFPDashboardService>().As<ISFPDashboardService>();
            builder.RegisterType<SfpBatchStatusService>().As<ISfpBatchStatusService>();
            builder.RegisterType<EnforcementDataQualityReportService>().As<IEnforcementDataQualityReportService>();
            builder.RegisterType<EncumbranceDataQualityReportService>().As<IEncumbranceDataQualityReportService>();
            builder.RegisterType<ReportLookUpService>().As<IReportLookUpService>();

            #endregion

            #region Register Class HERE

            builder.Register(c => new SfpDashboardController(c.Resolve<ISFPDashboardService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new SfpBatchStatusController(c.Resolve<ISfpBatchStatusService>(), c.Resolve<ILoggerService>()));
            builder.Register(c => new EncumbranceDataQualityReportStatusController(c.Resolve<IEncumbranceDataQualityReportService>()));
            builder.Register(c => new EnforcementDataQualityReportStatusController(c.Resolve<IEnforcementDataQualityReportService>()));
            builder.Register(c => new ReportLookUpController(c.Resolve<IReportLookUpService>(), c.Resolve<ILoggerService>()));


            #endregion

        }
    }
}
