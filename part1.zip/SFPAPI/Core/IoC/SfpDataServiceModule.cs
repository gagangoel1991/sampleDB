﻿using Autofac;
using Microsoft.Extensions.Options;
using NW.SFP.DataService;
using NW.SFP.DataService.SFP;
using NW.SFP.Interface.ConnectionManager;
using NW.SFP.Message.ConnectionManager;
using NW.SFP.Message.SFP;
using NW.SFP.Message.SFP.DTO;
using NW.SFP.Message.SFP.Model;

namespace SFPAPI.Core.IoC
{
    public class SfpDataServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type
            
            builder.RegisterType<SfpDashBoardDataList>().As<SfpDashBoardDataList>();
            builder.RegisterType<ConnectionManager>().As<IConnectionManager>();
            builder.RegisterType<BatchStatusDetailModel>().As<BatchStatusDetailModel>();

            #endregion

            #region Register Class

            builder.Register(c => new ConnectionManager(c.Resolve<IOptions<DBConnectionSettings>>()));
            builder.Register(c => new SfpDashBoardDataService(c.Resolve<IConnectionManager>(), c.Resolve<SfpDashBoardDataList>()));
            builder.Register(c => new SfpBatchStatusDataService(c.Resolve<IConnectionManager>(), c.Resolve<BatchStatusDetailModel>()));
            builder.Register(c => new EncumbranceDataQualityReportDataService(c.Resolve<IConnectionManager>()));
            builder.Register(c => new EnforcementDataQualityReportDataService(c.Resolve<IConnectionManager>()));
            builder.Register(c => new ReportLookUpDataService(c.Resolve<IConnectionManager>()));

            #endregion
        }
    }
}
