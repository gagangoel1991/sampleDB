﻿using Autofac;
using Microsoft.Extensions.Options;
using NW.SFP.BusinessService.Core;
using NW.SFP.BusinessService.PS;
using NW.SFP.BusinessService.PS.PoolAdhocReport;
using NW.SFP.BusinessService.Report;
using NW.SFP.DataService.Core;
using NW.SFP.DataService.PS;
using NW.SFP.DataService.PS.PoolAdhocReport;
using NW.SFP.DataService.Report;
using NW.SFP.Interface.Core;
using NW.SFP.Interface.CW;
using NW.SFP.Interface.PS;
using NW.SFP.Interface.PS.DataService;
using NW.SFP.Interface.Report;
using NW.SFP.Message.Core;
using NW.SFP.Queue.Publisher;
using NW.SFP.Queue.Subscriber;

namespace NW.SFPAPI.Core.IoC
{
    public class PsBusinessServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Register Type HERE
            builder.RegisterType<PoolDataService>().As<IPoolDataService>();
            builder.RegisterType<PoolReferenceLookupDataService>().As<IPoolReferenceLookupDataService>();
            builder.RegisterType<ConcentrationReferenceLookupDataService>().As<IConcentrationReferenceLookupDataService>();
            builder.RegisterType<ConcentrationDataService>().As<IConcentrationDataService>();
            builder.RegisterType<LoggerDataService>().As<ILoggerDataService>();
            builder.RegisterType<EligibilityDataService>().As<IEligibilityDataService>();
            builder.RegisterType<AssetClassDataService>().As<IAssetClassDataService>();
            builder.RegisterType<FieldManagementDataService>().As<IFieldManagementDataService>();
            builder.RegisterType<ExclusionDataService>().As<IExclusionDataService>();
            builder.RegisterType<DashboardPoolSelectionDataService>().As<IDashboardPoolSelectionDataService>();
            builder.RegisterType<PoolAdhocReportDataService>().As<IPoolAdhocReportDataService>();
            builder.RegisterType<AuthWorkflowDataService>().As<IAuthWorkflowDataService>();
            builder.RegisterType<DateListDataService>().As<IDateListDataService>();
            builder.RegisterType<ReplinesReportDataService>().As<IReplinesReportDataService>();
            builder.RegisterType<ListingPageDataService>().As<IListingPageDataService>();
            builder.RegisterType<ReferenceRegistryReportDataService>().As<IReferenceRegistryReportDataService>();

            #endregion

            #region Register Class HERE
            builder.Register(c => new LoggerService(c.Resolve<ILoggerDataService>()));
            builder.Register(c => new PublisherService(c.Resolve<IPoolDataService>()));
            builder.Register(c => new SubscriberService(c.Resolve<IQueuePublisherService>()));
            builder.Register(c => new PoolService(c.Resolve<IPoolDataService>(), c.Resolve<IQueueSubscriberService>()));
            builder.Register(c => new PoolReferenceLookupService(c.Resolve<IPoolReferenceLookupDataService>()));
            builder.Register(c => new ConcentrationReferenceLookupService(c.Resolve<IConcentrationReferenceLookupDataService>()));
            builder.Register(c => new ConcentrationService(c.Resolve<IConcentrationDataService>()));
            builder.Register(c => new EligibilityService(c.Resolve<IEligibilityDataService>()));
            builder.Register(c => new AssetClassService(c.Resolve<IAssetClassDataService>()));
            builder.Register(c => new FieldManagementService(c.Resolve<IFieldManagementDataService>()));
            builder.Register(c => new ExclusionService(c.Resolve<IExclusionDataService>()));
            builder.Register(c => new DashboardPoolSelectionService(c.Resolve<IDashboardPoolSelectionDataService>()));
            builder.Register(c => new PoolAdhocReportService(c.Resolve<IPoolAdhocReportDataService>()));
            builder.Register(c => new AuthWorkflowService(c.Resolve<IAuthWorkflowDataService>()));
            builder.Register(c => new DateListService(c.Resolve<IDateListDataService>()));
            builder.Register(c => new ReplinseReportService(c.Resolve<IReplinesReportDataService>()));
            builder.Register(c => new ListingPageService(c.Resolve<IListingPageDataService>()));
            builder.Register(c => new ReferenceRegistryReportService(c.Resolve<IReferenceRegistryReportDataService>(), c.Resolve<IDealIrConfigDataService>(), c.Resolve<IIrReportDataService>(), c.Resolve<IExcelService>(), c.Resolve<IOptions<CashWaterfallSettings>>()));
            #endregion
        }
    }
}
