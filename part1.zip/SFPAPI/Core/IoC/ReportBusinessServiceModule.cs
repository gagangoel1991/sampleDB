﻿namespace NW.SFP.API.Core.IoC
{
    using Autofac;   
    using NW.SFP.Message.Core;
    using Microsoft.Extensions.Options;
    using NW.SFP.DataService.Report;
    using NW.SFP.Interface.Report;
    using NW.SFP.BusinessService.Report;
    using NW.SFP.Interface.Report.DataService;
    using NW.SFP.DataService.Report.NWMReport;
    using NW.SFP.Interface.Report.BusinessService;
    using NW.SFP.API.Api.Reports;

    public class ReportBusinessServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region First Register All Type

            // Investor Report
            builder.RegisterType<InvestorReportDataService>().As<IInvestorReportDataService>();
            builder.RegisterType<ESMAReportsDataService>().As<IESMAReportDataService>();


            // Report Data service
            builder.RegisterType<ReportDataService>().As<IReportDataService>();
            builder.RegisterType<NWMReportsDataService>().As<INWMReportsDataService>();
            #endregion

            #region Register Class 

            builder.Register(c => new InvestorReportService(c.Resolve<IInvestorReportDataService>(), c.Resolve<IOptions<ReportSettings>>()));
            builder.Register(c => new ESMAReportService(c.Resolve<IESMAReportDataService>(), c.Resolve<IOptions<ReportSettings>>()));
            builder.Register(c => new ReportDataService(c.Resolve<IOptions<DataServiceSettings>>(), c.Resolve<IOptions<ReportSettings>>()));
            builder.Register(c => new NWReportsService(c.Resolve<INWMReportsDataService>(), c.Resolve<IOptions<ReportSettings>>()));
           
            #endregion

        }
    }
}
