﻿using Autofac;
using NW.SFP.BusinessService.CB;
using NW.SFP.Interface.CB;

namespace NW.SFP.API.Core.IoC
{
    public class CorpBusinessServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {   
            builder.RegisterType<DataCorrectionBusinessService>().As<IDataCorrectionBusinessService>();
            builder.RegisterType<DataCorrectionRefBusinessService>().As<IDataCorrectionRefBusinessService>();
            builder.RegisterType<LossManagementService>().As<ILossManagementService>();
        }
    }
}