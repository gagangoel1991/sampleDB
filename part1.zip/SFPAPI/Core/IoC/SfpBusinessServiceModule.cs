﻿using Autofac;
using NW.SFP.BusinessService.SFP;
using NW.SFP.DataService.SFP;
using NW.SFP.Interface.SFP;
using NW.SFP.Message.SFP.DTO;
using NW.SFP.Message.SFP.Model;

namespace NW.SFPAPI.Core.IoC
{
    public class SfpBusinessServiceModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Register Type HERE

            builder.RegisterType<SfpDashBoardDataService>().As<ISfpDashboardDataService>();
            builder.RegisterType<SfpBatchStatusDataService>().As<ISfpBatchStatusDataService>();
            builder.RegisterType<EncumbranceDataQualityReportDataService>().As<IEncumbranceDataQualityReportDataService>();
            builder.RegisterType<EnforcementDataQualityReportDataService>().As<IEnforcementDataQualityReportDataService>();
            builder.RegisterType<BatchStatusDetailDto>().As<BatchStatusDetailDto>();
            builder.RegisterType<ReportLookUpDataService>().As<IReportLookUpDataService>();

            #endregion

            #region Register Class HERE

            builder.Register(c => new SFPDashboardService(c.Resolve<ISfpDashboardDataService>()));
            builder.Register(c => new SfpBatchStatusService(c.Resolve<ISfpBatchStatusDataService>(), c.Resolve<BatchStatusDetailDto>()));
            builder.Register(c => new EnforcementDataQualityReportService(c.Resolve<IEnforcementDataQualityReportDataService>()));
            builder.Register(c => new EncumbranceDataQualityReportService(c.Resolve<IEncumbranceDataQualityReportDataService>()));
            builder.Register(c => new ReportLookUpService(c.Resolve<IReportLookUpDataService>()));

            #endregion
        }
    }
}
