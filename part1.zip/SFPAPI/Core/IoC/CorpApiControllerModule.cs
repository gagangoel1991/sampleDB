﻿using Autofac;
using NW.SFP.BusinessService.CB;
using NW.SFP.BusinessService.Core;
using NW.SFP.Interface.CB;
using NW.SFP.Interface.Core;

namespace NW.SFP.API.Core.IoC
{
    public class CorpApiControllerModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Register Type 
            builder.RegisterType<DataCorrectionBusinessService>().As<IDataCorrectionBusinessService>();
            builder.RegisterType<LoggerService>().As<ILoggerService>();
            builder.RegisterType<LossManagementService>().As<ILossManagementService>();
            #endregion 

            //Ressolve Types
            
        }
    }
}