﻿using Autofac;
using NW.SFP.BusinessService.Upload;
using NW.SFP.Interface.Upload;
using NW.SFP.Interface.Core;
using NW.SFP.BusinessService.Core;
using NW.SFP.Interface.Upload.BusinessService;

namespace NW.SFP.API.Core.IoC
{
    public class UploadApiControllerModule : Module
    {
        protected override void Load(ContainerBuilder builder)
        {
            #region Register Type 
            builder.RegisterType<FileUploadInfoBusinessService>().As<IFileUploadInfoBusinessService>();
            builder.RegisterType<LoggerService>().As<ILoggerService>();
            builder.RegisterType<FileUploadUtilityBusinessService>().As<IFileUploadUtilityBusinessService>();            
            #endregion

        }
    }
}
