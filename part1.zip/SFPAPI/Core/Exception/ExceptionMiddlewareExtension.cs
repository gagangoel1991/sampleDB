﻿using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Diagnostics;
using Microsoft.AspNetCore.Http;
using System;
using NW.SFP.Interface.Core;
using System.Data.SqlClient;
using SFPAPI.Api;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using log4net;
using System.Threading.Tasks;
using NW.SFP.Message.Core;
using Microsoft.Extensions.Logging;

namespace SFPAPI.Core
{
    public static class ExceptionMiddlewareExtension
    {
        public static readonly ILog Log = LogManager.GetLogger(typeof(ExceptionMiddlewareExtension));
        public static void ConfigureExceptionHandler(this IApplicationBuilder app, ILoggerService loggerService, IHttpContextAccessor httpContextAccessor)
        {
            app.UseExceptionHandler(appError =>
              {
                  appError.Run(async context =>
                 {
                      context.Response.StatusCode = (int)HttpStatusCode.InternalServerError;
                      context.Response.ContentType = "application/json";

                      var contextFeature = context.Features.Get<IExceptionHandlerFeature>();
                      if (contextFeature != null)
                      {
                         int StatusCode = SetExceptionDetails(contextFeature);

                         LogErrorEntity logError = new LogErrorEntity()
                          {
                              ErrorMessage = contextFeature.Error.Message,
                              ErrorMethod = contextFeature.Error.TargetSite.DeclaringType.FullName + '.' + contextFeature.Error.TargetSite.Name,
                              ModuleId = contextFeature.Error.TargetSite.DeclaringType.FullName.Contains("NW.SFPAPI.Api.PS")
                                          ? (int)AppModule.PoolSelection
                                          : (int)AppModule.Cashwaterfall,
                              UserName = httpContextAccessor.HttpContext.User.Claims.Where(k
                                              => k.Type.Equals("UserRacf")).FirstOrDefault().Value
                          };

                         loggerService.LogError(logError);

                         await context.Response.WriteAsync(new ExceptionMessage()
                          {
                              StatusCode = StatusCode,
                              Message = "Internal Server Error.",
                              ErrorId = logError.ErrorId
                          }.ToString());
                      }
                  });
              });
        }
        private static int SetExceptionDetails(IExceptionHandlerFeature contextFeature)
        {
            var methodName = contextFeature.Error.TargetSite.Name;
            var controllerFullName = contextFeature.Error.TargetSite.DeclaringType.FullName;
            string logErrorReason = "";
            int httpStatusCode;

            if (contextFeature.Error is ArgumentOutOfRangeException)
            {
                logErrorReason = "ArgumentOutOfRangeException";
                httpStatusCode = 1001;

                if (contextFeature.Error.Message.ToLower().Contains("must be non-negative and less than the size of the collection"))
                { 
                    logErrorReason = "Index was out of range. Must be non-negative and less than the size of the collection.";
                    httpStatusCode = 1002;
                }
                else if (contextFeature.Error.Message.ToLower().Contains("row number must be between 1 and"))
                { 
                    logErrorReason = "Row number must be between 1 and 1048576";
                    httpStatusCode = 1003;
                }
            }
            else if (contextFeature.Error is ArgumentNullException)
            {
                logErrorReason = "ArgumentNullException";
                httpStatusCode = 1004;
            }
            else if (contextFeature.Error is ArgumentException)
            {
                logErrorReason = "ArgumentException";
                httpStatusCode = 1005;

                if(contextFeature.Error.Message.Contains("There isn't a worksheet named"))
                {
                    logErrorReason = "Expected worksheer not available.";
                    httpStatusCode = 1006;
                }
            } 
            else if (contextFeature.Error is System.IO.FileNotFoundException)
            {
                logErrorReason = "FileNotFoundException";
                httpStatusCode = 1007;
            } 
            else if (contextFeature.Error is IndexOutOfRangeException)
            {
                logErrorReason = "IndexOutOfRangeException";
                httpStatusCode = 1008;
            }
            else if (contextFeature.Error is ArithmeticException)
            {
                logErrorReason = "ArithmeticException";
                httpStatusCode = 1009;
            }
            else if (contextFeature.Error is DivideByZeroException)
            {
                logErrorReason = "DivideByZeroException";
                httpStatusCode = 1010;
            }
            else if (contextFeature.Error is OutOfMemoryException)
            {
                logErrorReason = "OutOfMemoryException";
                httpStatusCode = (int)HttpStatusCode.InsufficientStorage;
            }
            else if (contextFeature.Error is TimeoutException)
            {
                logErrorReason = "TimeoutException";
                httpStatusCode = (int)HttpStatusCode.RequestTimeout;
            } 
            else if (contextFeature.Error is SqlException sqlException)
            {
                logErrorReason = "SqlException";
                var errorNumber = httpStatusCode = sqlException.Number;  

                if (errorNumber == 2812 ||  (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("could not find stored procedure")))
                {
                    logErrorReason = "Sql Exception : Could not find stored procedure";
                    httpStatusCode = 2812;
                }
                else if (errorNumber == 208 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("invalid object name")))
                {
                    logErrorReason = "Sql Exception : Invalid Object Name";
                    httpStatusCode = 208;
                }
                else if (errorNumber == 207 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("invalid column name")))
                {
                    logErrorReason = "Sql Exception : Invalid column name";
                    httpStatusCode = 207;
                }
                else if (errorNumber == 916 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("does not have access to database")))
                {
                    logErrorReason = "Sql Exception : Does not have access to database";
                    httpStatusCode = 916;
                }
                else if (errorNumber == 500 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("trying to pass a table-valued parameter with")))
                {
                    logErrorReason = "Sql Exception : Incorrect number of columns in table-valued parameter.";
                    httpStatusCode = 501;
                }
                else if (errorNumber == 4121 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("cannot find either column")))
                {
                    logErrorReason = "Sql Exception : Incorrect column or user defined function.";
                    httpStatusCode = 4121;
                }
                else if (errorNumber == 213 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("column name or number of supplied values does not match table definition")))
                {
                    logErrorReason = "Sql Exception : Column name or number of supplied values does not match table definition.";
                    httpStatusCode = 213;
                }
                else if (errorNumber == 207 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("invalid column name")))
                {
                    logErrorReason = "Sql Exception : Invalid Column Name.";
                    httpStatusCode = 207;
                }
                else if (errorNumber == 229 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("permission was denied")))
                {
                    logErrorReason = "Sql Exception : Insert permission was denied.";
                    httpStatusCode = 229;
                }
                else if (
                    errorNumber == 916 || 
                    (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("does not have access to database") || contextFeature.Error.Message.ToLower().Contains("not able to access the database"))
                    )
                {
                    logErrorReason = "Sql Exception : Access to the database denied.";
                    httpStatusCode = 916;
                }
                else if (errorNumber == 512 || 
                    (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("subquery returned more than 1 value. this is not permitted")))
                {
                    logErrorReason = "Sql Exception : Incorrect subquery which returns more than 1 value.";
                    httpStatusCode = 512;
                }
                else if (errorNumber == 515 ||
                   (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("cannot insert the value null")))
                {
                    logErrorReason = "Sql Exception : Cannot insert NULL into table column.";
                    httpStatusCode = 515;
                }
                else if (errorNumber == 201 ||
                    (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("procedure or function") &&
                    contextFeature.Error.Message.Contains("expects parameter")))
                {
                    logErrorReason = "Sql Exception : Parameter to stored procedure or function was not supplied.";
                    httpStatusCode = 201;
                }
                else if (errorNumber == 245 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("conversion failed when converting")))
                {
                    logErrorReason = "Sql Exception : Data conversion failed.";
                    httpStatusCode = 245;
                }
                else if (errorNumber == 9002 ||
                    (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("the transaction log for database") &&
                    contextFeature.Error.Message.Contains("is full due to")))
                {
                    logErrorReason = "Sql Exception : Transaction log is full.";
                    httpStatusCode = 9002;
                }
                else if (errorNumber == 2627 ||
                    (errorNumber == 50000 && (contextFeature.Error.Message.ToLower().Contains("violation of primary key constraint") ||
                    contextFeature.Error.Message.Contains("Cannot insert duplicate key"))))
                {
                    logErrorReason = "Sql Exception : Cannot insert duplicate key.";
                    httpStatusCode = 2627;
                }
                else if (errorNumber == 5313 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("refers to an invalid object")))
                {
                    logErrorReason = "Sql Exception : Refers to an invalid synonym object.";
                    httpStatusCode = 5313;
                }
                else if (errorNumber == 1205 || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("deadlocked on lock resources with another process")))
                {
                    logErrorReason = "Sql Exception :  Transaction was deadlocked on lock resources with another process.";
                    httpStatusCode = 1205;
                }
                else if (errorNumber == 4060)
                {
                    logErrorReason = "Sql Exception :  Cannot open database. Database not available or login failed.";
                    httpStatusCode = 4060;
                }
                else if (errorNumber == 927 
                    || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("it is in the middle of a restore")))
                { 
                    logErrorReason = "Sql Exception :  Database cannot be opened. It is in the middle of a restore.";
                    httpStatusCode = 927;
                }
                else if (errorNumber == -2
                    || (errorNumber == 50000 && contextFeature.Error.Message.ToLower().Contains("timeout expired")))
                {
                    logErrorReason = "Sql Exception :  Timeout expired at database.";
                    httpStatusCode = -2;
                } 
            }
            else if (contextFeature.Error is AggregateException 
                && (contextFeature.Error.Message.ToLower().Contains("access to the path")))
            { 
                    logErrorReason = contextFeature.Error.Message;
                    httpStatusCode = 1011;
            }
            else if (contextFeature.Error is AggregateException
                && (contextFeature.Error.Message.ToLower().Contains("the process cannot access the file"))
                && (contextFeature.Error.Message.ToLower().Contains("because it is being used by another process"))
                )
            {
                logErrorReason = contextFeature.Error.Message;
                httpStatusCode = 1012;
            }
            else
            {
                logErrorReason = "Exception";
                httpStatusCode = (int)HttpStatusCode.InternalServerError;
            }
            Log.Error("Exception Message : " + contextFeature.Error.Message);
            Log.Error(logErrorReason + " occured at " + methodName + " under " + controllerFullName);
            Log.Error("Exception Details : " + contextFeature.Error);
            return httpStatusCode;
        }
    }
}
