﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using System.Security.Principal;
using NW.SFP.Interface.CW;
using NW.SFP.API.Core.Constants;
using NW.SFP.Message;
using SFPAPI.Core.Auth;
using Microsoft.AspNetCore.Http;
using NW.SFP.Message.Core;

namespace NW.SFP.API.Core.Auth
{
    public class SFPAuthorizeActionFilter : IAuthorizationFilter
    {
        private readonly string _permission;

        private readonly PermissionAccessType _accessType;

        private readonly IAuthService _authService;

        public SFPAuthorizeActionFilter(string permission, PermissionAccessType accessType, IAuthService authService)
        {
            this._permission = permission;
            this._accessType = accessType;
            this._authService = authService;
        }

        public void OnAuthorization(AuthorizationFilterContext context)
        {
            bool isAuthorized = CheckUserPermission(context.HttpContext.User, _permission, _accessType);
            if (!isAuthorized)
            {
                //Here returning the 412 status code instead of 401 to avoid the Browser Log in popup 
                context.Result = new StatusCodeResult(StatusCodes.Status412PreconditionFailed);
            }
        }

        private bool CheckUserPermission(ClaimsPrincipal principal, string permission, PermissionAccessType accessType)
        {
            UserAuthParams authParams = new UserAuthParams()
            {
                AccessType = (int)accessType,
                ADGroupName = principal.Claims.Where(k => k.Type.Equals("UserADGroup")).FirstOrDefault().Value,
                PermissionName = permission,
                UserName = principal.Claims.Where(k => k.Type.Equals("UserRacf")).FirstOrDefault().Value
            };

            return this._authService.IsUserActionAuthorized(authParams);
        }
    }

    public class SFPAuthorizeAttribute : TypeFilterAttribute
    {
        public SFPAuthorizeAttribute(string permission, PermissionAccessType accessType)
            : base(typeof(SFPAuthorizeActionFilter))
        {
            Arguments = new object[] { permission, accessType };
        }
    }
}
