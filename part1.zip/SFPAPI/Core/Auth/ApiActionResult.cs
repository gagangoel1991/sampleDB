﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Threading.Tasks;

namespace SFPAPI.Core.Auth
{

    public class ApiActionResult<T> 
        where T : class, new()
    {
        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public int StatusCode { get; set; }

        [DataMember]
        public string StatusMessage { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }

        [DataMember]
        public T Content { get; set; }
    }

    public class UnauthorizedAccess
    {

    }

    [DataContract]
    public class ApiActionResultList<T>
        where T : class, new()
    {
        [DataMember]
        public string Status { get; set; }

        [DataMember]
        public int StatusCode { get; set; }

        [DataMember]
        public string StatusMessage { get; set; }

        [DataMember]
        public string ErrorMessage { get; set; }

        [DataMember]
        public List<T> Content { get; set; }
    }
}
