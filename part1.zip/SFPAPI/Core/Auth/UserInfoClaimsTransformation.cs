﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Security.Claims;
using Microsoft.AspNetCore.Authentication;
using System.Security.Principal;
using NW.SFP.Interface.CW;

namespace NW.SFP.API.Core.Auth
{
    public class UserInfoClaimsTransformation :  IClaimsTransformation
    {

        private readonly IAuthService _authService;

        public UserInfoClaimsTransformation(IAuthService authService)
        {
            this._authService = authService;
        }


        public Task<ClaimsPrincipal> TransformAsync(ClaimsPrincipal principal)
        {
            var claiminfo = (ClaimsIdentity)principal.Identity;
           
            IList<string> adGroupList = this._authService.GetADGroup(claiminfo.Name);
            bool isUserGroupValid = false;
            List<string> groupName = new List<string>();
            foreach (string group in adGroupList)
            {
                if (principal.IsInRole(group))
                {
                    groupName.Add(group);
                    isUserGroupValid = true;
                }
            }
            claiminfo.AddClaim(new Claim("UserADGroup", String.Join("|", groupName)));
            claiminfo.AddClaim(new Claim("UserRacf", claiminfo.Name));
            claiminfo.AddClaim(new Claim("IsUserAuthenticated", isUserGroupValid.ToString()));

            return Task.FromResult(principal);
        }
    }
}
