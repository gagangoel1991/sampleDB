﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Core;
using SFPAPI.Api;
using Microsoft.AspNetCore.Authorization;
using NW.SFP.Message.Core.Token;

namespace NW.SFP.API.Core.Token
{
    [ApiController]
    [Produces("application/json")]
    [Route("api/token")]
    [Authorize]
    public class TokenController : SFPControllerBase
    {

        private readonly IAPITokenService _APITokenService;

        public TokenController(IAPITokenService APITokenService)
        {
            this._APITokenService = APITokenService;
        }

        [HttpGet("getTokenByKey/{key}")]
        public string GetTokenByKey(String key)
        {
            if (string.IsNullOrEmpty(key))
                throw new Exception("Token key cannot be null or empty");

            APITokenEntity objAPITokenEntity = new APITokenEntity()
            {
                Key = key,
                UserName = LoggedInUserName
            };

            var Guid = _APITokenService.GetAPITokenbyKey(objAPITokenEntity);

            string Json = System.Text.Json.JsonSerializer.Serialize(new TokenHeaderEntity
            {
                Key = key,
                Token = Guid
            });

            return Json;
        }


    }
}
