﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Filters;
using Microsoft.Extensions.Primitives;
using Newtonsoft.Json;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Core;
using System;
using System.Linq;
using NW.SFP.Message.Core.Token;

namespace NW.SFP.API.Core.Token
{
    public class ValidateTokenAttributeExtended : ExceptionFilterAttribute, IActionFilter, IResultFilter
    {

        private readonly IAPITokenService _APITokenService;

        public ValidateTokenAttributeExtended(IAPITokenService APITokenService) => (_APITokenService) = (APITokenService);

        public void OnActionExecuting(ActionExecutingContext context)
        {
            StringValues headerValues;
            context.HttpContext.Request.Headers.TryGetValue(TokenHeaderEntity.TokenInfoKeyName, out headerValues);

            if (!String.IsNullOrEmpty(Convert.ToString(headerValues)))
            {
                TokenHeaderEntity objTokenHeaderEntity = JsonConvert.DeserializeObject<TokenHeaderEntity>(headerValues);
                var UserRacf = context.HttpContext.User.Claims.Where(k => k.Type.Equals("UserRacf")).FirstOrDefault().Value;

                APITokenEntity objAPITokenEntity = new APITokenEntity()
                {
                    Key = objTokenHeaderEntity.Key,
                    Token = objTokenHeaderEntity.Token,
                    UserName = UserRacf,
                    FromIsProcessRunning = false,
                    ToIsProcessRunning = true,
                };

                APITokenUpdateOutputEntity ObjAPITokenUpdateOutputEntity = _APITokenService.UpdateAPIToken(objAPITokenEntity);

                if (ObjAPITokenUpdateOutputEntity.IsTokenUpdated)
                {

                    _APITokenService.APITokenEntity = new APITokenEntity()
                    {
                        FromIsProcessRunning = false,
                        ToIsProcessRunning = true,
                        Key = objTokenHeaderEntity.Key,
                        Token = ObjAPITokenUpdateOutputEntity.UpdatedToken,
                        UserName = UserRacf
                    };
                }
                else
                {
                    var objectResult = new ObjectResult("Token Update Failed");

                    if (ObjAPITokenUpdateOutputEntity.IsProcessRunning)
                    {
                        objectResult.StatusCode = 398;
                    }
                    else
                    {
                        objectResult.StatusCode = 399;
                    }

                    context.Result = objectResult;
                }

            }


        }
        public void OnResultExecuting(ResultExecutingContext context)
        {
            UpdateAndUnlockTheToken();
        }
        public override void OnException(ExceptionContext context)
        {
            UpdateAndUnlockTheToken();
            base.OnException(context);
        }
        public void UpdateAndUnlockTheToken()
        {
            if (_APITokenService.APITokenEntity != null)
            {
                _APITokenService.APITokenEntity.FromIsProcessRunning = true;
                _APITokenService.APITokenEntity.ToIsProcessRunning = false;
                APITokenUpdateOutputEntity ObjAPITokenUpdateOutputEntity = _APITokenService.UpdateAPIToken(_APITokenService.APITokenEntity);
            }
        }

        #region Unused Methods
        public void OnResultExecuted(ResultExecutedContext context) { }
        public void OnActionExecuted(ActionExecutedContext context) { }
        #endregion

    }

    public class ValidateTokenAttribute : TypeFilterAttribute
    {
        public ValidateTokenAttribute() : base(typeof(ValidateTokenAttributeExtended)) { }
    }
}
