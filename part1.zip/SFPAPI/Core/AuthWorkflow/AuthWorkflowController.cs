﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Message.Common;

namespace SFPAPI.Api.Core
{

    [Produces("application/json")]
    [Authorize]
    [Route("api/authWorkflow")]
    [ApiController]
    public class AuthWorkflowController : SFPControllerBase, IAuthWorkflowController
    {
        private readonly ILoggerService _loggerService;
        private readonly IAuthWorkflowService _authWorkflowService;

        public AuthWorkflowController(IAuthWorkflowService authWorkflowService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._authWorkflowService = authWorkflowService;
        }


        [SFPAuthorize("WorkflowManagement", PermissionAccessType.View)]
        [HttpPost("getAuthWorkflowStatus")]
        public AuthWorkflowEntity GetAuthWorkflowStatus(AuthWorkflowEntity authWorkflowEntity)
        {
           authWorkflowEntity.UserName = LoggedInUserName;
            return this._authWorkflowService.GetAuthWorkflowStatus(authWorkflowEntity);
        }

        [SFPAuthorize("WorkflowManagement", PermissionAccessType.ApproveReject)]
        [HttpPost("manageAuthWorkflow")]
        public int ManageAuthWorkflow(AuthWorkflowEntity authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._authWorkflowService.ManageAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("WorkflowManagement", PermissionAccessType.AddEdit)]
        [HttpPost("manageAuthWorkflowByUser")]
        public int ManageAuthWorkflowByUser(AuthWorkflowEntity authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._authWorkflowService.ManageAuthWorkflow(authWorkflowEntity);
        }

        [SFPAuthorize("WorkflowManagement", PermissionAccessType.View)]
        [HttpPost("getEntityAuditDetails")]
        public AuthAuditEntity GetEntityAuditDetails(AuthWorkflowEntity authWorkflowEntity)
        {
            authWorkflowEntity.UserName = LoggedInUserName;
            return this._authWorkflowService.GetEntityAuditDetails(authWorkflowEntity);
        }

    }
}
