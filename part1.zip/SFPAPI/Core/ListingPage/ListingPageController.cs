﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using NW.SFP.API.Core.Auth;
using NW.SFP.API.Core.Constants;
using NW.SFP.Interface.Core;
using NW.SFP.Message.core;

namespace SFPAPI.Api.Core
{

    [Produces("application/json")]
    [Authorize]
    [Route("api/listingpage")]
    [ApiController]
    public class ListingPageController : SFPControllerBase, IListingPageController
    {
        #region Variables  declaration and Construction
        private readonly ILoggerService _loggerService;
        private readonly IListingPageService _listingPageService;

        public ListingPageController(IListingPageService listingPageService, ILoggerService loggerService)
        {
            this._loggerService = loggerService;
            this._listingPageService = listingPageService;
        }
        #endregion

        #region Get Listing Preference

        [SFPAuthorize("WorkflowManagement", PermissionAccessType.View)]
        [HttpGet("getUserListingPreference")]
        public ActionResult<ListingPreference> GetUserListingPreference(string listingPageName)
        {
            return this._listingPageService.GetUserListingPreference(listingPageName, LoggedInUserName);
        }
        #endregion

        #region Save Listing Preference

        [SFPAuthorize("WorkflowManagement", PermissionAccessType.View)]
        [HttpPost("saveUserListingPreference")]
        public ActionResult<int> SaveUserListingPreference(ListingPreference listingPreference)
        {
            return this._listingPageService.SaveUserListingPreference(listingPreference, LoggedInUserName);
        }
        #endregion
    }
}
