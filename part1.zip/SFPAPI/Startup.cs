using Autofac;
using Autofac.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.AspNetCore.Authentication.Negotiate;
using Microsoft.Extensions.Logging;
using NW.SFP.API.Core.IoC;
using NW.SFP.API.Core.Auth;
using System.Data.SqlClient;
using SFPAPI.Core.IoC;
using NW.SFP.Message.Core;
using NW.SFPAPI.Core.IoC;
using SFPAPI.Core;
using NW.SFP.Interface.Core;
using NW.SFP.BusinessService.Core;
using Microsoft.AspNetCore.Http;
using NW.SFP.Message.ConnectionManager;

namespace NW.SFP.API
{
    public class Startup
    {

        #region Autofac Container Specific Methods

        public Startup(IWebHostEnvironment env)
        {
            var builder = new ConfigurationBuilder()
                //.SetBasePath(env.ContentRootPath)
                .AddJsonFile("appsettings.json", optional: true, reloadOnChange: true)
                //.AddJsonFile($"appsettings.{env.EnvironmentName}.json", optional: true)
                //.AddEnvironmentVariables()
                ;
            this.Configuration = builder.Build();
        }

        public IConfigurationRoot Configuration { get; private set; }

        public ILifetimeScope AutofacContainer { get; private set; }

        // ConfigureServices is where you register dependencies. This gets
        // called by the runtime before the ConfigureContainer method, below.
        public void ConfigureServices(IServiceCollection services)
        {
            services.Configure<DataServiceSettings>(Configuration.GetSection("DataServiceSettings"));
            services.Configure<DBConnectionSettings>(Configuration.GetSection("DBConnectionSettings"));
            services.Configure<ApiControllerSettings>(Configuration.GetSection("ApiControllerSettings"));
            
            string webHostUrl = Configuration["WebHostUrl"];

            services.AddCors(options =>
            {
                options.AddPolicy("AllowAllHeaders",
                      builder =>
                      {
                          builder.WithOrigins(webHostUrl)
                                                  .AllowAnyMethod()
                                                  .AllowAnyHeader()
                                                  .AllowCredentials();
                      });
            });
            
            services.AddControllers().AddNewtonsoftJson();
            services.AddScoped<IClaimsTransformation, UserInfoClaimsTransformation>();
            services.Configure<CashWaterfallSettings>(options => Configuration.GetSection("CashWaterfallSetting").Bind(options));
            services.Configure<ReportSettings>(options => Configuration.GetSection("ReportSetting").Bind(options));
            services.AddAuthentication(NegotiateDefaults.AuthenticationScheme).AddNegotiate();
            services.Configure<UploadSettings>(options => Configuration.GetSection("UploadSettings").Bind(options));
            services.Configure<AssetWiseFileCopyPaths>(options => Configuration.GetSection("AssetWiseFileCopyPaths").Bind(options));

            services.Configure<IISServerOptions>(options =>
            {
                options.MaxRequestBodySize = int.MaxValue;                
            });

            //services.AddAuthentication(IISServerDefaults.AuthenticationScheme);
            services.AddOptions();
            services.AddSingleton<ILoggerService, LoggerService>();
            services.AddHttpContextAccessor();
        }


        // Register your own things directly with Autofac, like:
        // ConfigureContainer is where you can register things directly
        // with Autofac. This runs after ConfigureServices so the things
        // here will override registrations made in ConfigureServices.
        // Don't build the container; that gets done for you by the factory.
        public void ConfigureContainer(ContainerBuilder builder)
        {
            // Register your own things directly with Autofac, like:
            builder.RegisterModule(new CWApiControllerModule());
            builder.RegisterModule(new CWBusinessServiceModule());
            builder.RegisterModule(new CWDataServiceModule());
            builder.RegisterModule(new PsApiControllerModule());
            builder.RegisterModule(new PsBusinessServiceModule());
            builder.RegisterModule(new SfpApiControllerModule());
            builder.RegisterModule(new SfpBusinessServiceModule());
            builder.RegisterModule(new SfpDataServiceModule());
            builder.RegisterModule(new ReportApiControllerModule());
            builder.RegisterModule(new ReportBusinessServiceModule());

            builder.RegisterModule(new CorpApiControllerModule());
            builder.RegisterModule(new CorpBusinessServiceModule());
            builder.RegisterModule(new CorpDataServiceModule());

            builder.RegisterModule(new UploadApiControllerModule());
            builder.RegisterModule(new UploadBusinessServiceModule());
            builder.RegisterModule(new UploadDataServiceModule());

            builder.Register<SqlConnection>(con => new SqlConnection(Configuration.GetSection("DataServiceSettings:ConnectionString").Value)).AsSelf();
        }

        // Configure is where you add middleware. This is called after
        // ConfigureContainer. You can use IApplicationBuilder.ApplicationServices
        // here if you need to resolve things from the container.
        public void Configure(
          IApplicationBuilder app,
          IWebHostEnvironment environment,
          ILoggerService loggerService,
          IHttpContextAccessor httpContextAccessor,
          ILoggerFactory loggerFactory)
        {
            app.UseHttpsRedirection();
            app.UseStaticFiles();
            app.UseRouting();
            app.UseCors("AllowAllHeaders");
            app.UseAuthentication();
            app.UseAuthorization();          

            
            if (environment.EnvironmentName == "Dev")
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.ConfigureExceptionHandler(loggerService, httpContextAccessor);
            }
            

            app.UseStatusCodePages();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
                endpoints.MapControllerRoute(
                    name: "default",
                    pattern: "{api}/{controller=Home}/{action=Index}/{id?}");                
            });
            this.AutofacContainer = app.ApplicationServices.GetAutofacRoot();
        }
        #endregion

    }
}
