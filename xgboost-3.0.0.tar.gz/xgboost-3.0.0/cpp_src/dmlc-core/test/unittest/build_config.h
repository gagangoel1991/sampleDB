#define CMAKE_CURRENT_SOURCE_DIR "/home/jiamingy/workspace/xgboost_dev/xgboost/dmlc-core/test/unittest"
