USE SFP_Securitisation

GO
IF OBJECT_ID('[cb].[spIR_GetProductRate_ReversionaryData]') IS NOT NULL
	DROP PROCEDURE [cb].[spIR_GetProductRate_ReversionaryData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spIR_GetProductRate_ReversionaryData]
/*
 * Author: Kapil Sharma
 * Date:	21.02.2022
 * Description:  This will return the Product Rate Type and Reversionary Profilesdata for Deimos IR
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * Usages:
 * [cb].[spIR_GetProductRate_ReversionaryData] '2021-09-30', 'Deimos', 'System'
 * -------------------------------------------------------
*/
(
	@pAsAtDate			DATE, 
	@pDealName			VARCHAR(100),
	@pUserName			VARCHAR(80) = NULL
) 
AS  
BEGIN   

   BEGIN TRY
		DECLARE 
			@totalLoan				DECIMAL(15, 4),
			@totalAmount			DECIMAL(36, 16)

		DECLARE @dealId int;
		DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		DECLARE @totalSubAccounts float, @totalOutstandingCapitalBalance float

		DECLARE @tblProductData AS TABLE(Id SMALLINT IDENTITY(1,1), DisplayName VARCHAR(200), LoanCount INT, LoanPercentage DECIMAL(36, 18), CapitalBalanceValue DECIMAL(36, 18), CapitalBalanceValuePercentage DECIMAL(36, 18),
			 CurrentRate DECIMAL(36, 18), RemainingTeaserPeriod DECIMAL(15, 8), CurentMargin DECIMAL(36, 18), ReversionaryMargin DECIMAL(36, 18), 
			 InitialRate DECIMAL(36, 18));

		SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
		SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  

		EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
		INSERT INTO #VwMortgageSubAccount   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId

		SELECT @totalOutstandingCapitalBalance = sum(Outstandng_Capital_Balance_Amt)
		, @totalSubAccounts = count(*)
		FROM #VwMortgageSubAccount 

		--Now returning the data 
		INSERT INTO @tblProductData
		SELECT 
			dpd.DisplayName, 
			dpd.LoanCount AS 'Number', 
			CASE WHEN @totalSubAccounts >0 THEN (dpd.LoanCount/@totalSubAccounts) ELSE 0 END AS '% of total number',
			dpd.CapitalBalanceValue AS 'Amount (GBP)',
			CASE WHEN @totalOutstandingCapitalBalance> 0 THEN dpd.CapitalBalanceValue/@totalOutstandingCapitalBalance ELSE 0 END AS '% of total amount',
			dpd.CurrentRate AS 'Current Rate',
			dpd.RemainingTeaserPeriod AS 'Remaining teaser period (months)',
			dpd.CurentMargin AS 'Current margin',
			dpd.ReversionaryMargin AS 'Reversionary margin',
			dpd.InitialRate AS 'Initial rate'
			---TODO - This provision is done for only May release, this will be captured in a seperate table in July release
		FROM 
			[cb].[DealProductData] dpd
		WHERE 
			CorrelatedDate = @pAsAtDate
			--and dpd.DisplayName <> 'Total'
		ORDER BY dpd.DisplayName


		Create Table #TblLineItem(DisplayName varchar(255))
		Insert Into #TblLineItem values ('Fixed at origination, reverting to SVR'),
				('Fixed at origination, reverting to Libor'),
				('Fixed at origination, reverting to tracker'),
				('Fixed for life'),
				('Tracker at origination, reverting to SVR'),
				('Tracker at origination, reverting to Libor'),
				('Tracker for life'),
				('SVR, including discount to SVR'),
				('Libor'),
				('Total')
		
		


		SELECT 
			ISNULL(T.DisplayName,'Total') AS '~HeaderText',
			LoanCount AS 'Number', 
			LoanPercentage AS '% of total number',
			CapitalBalanceValue AS 'Amount (GBP)',
			CapitalBalanceValuePercentage AS '% of total amount',
			CurrentRate AS 'Current Rate',
			RemainingTeaserPeriod AS 'Remaining teaser period (months)',
			CurentMargin AS 'Current margin',
			ReversionaryMargin AS 'Reversionary margin',
			InitialRate AS 'Initial rate'
		FROM 
			#TblLineItem T
			Left Join @tblProductData P on T.DisplayName=P.DisplayName
		ORDER BY CASE T.DisplayName WHEN  'Fixed at origination, reverting to SVR' THEN 1
				WHEN 'Fixed at origination, reverting to Libor' THEN 2
				WHEN 'Fixed at origination, reverting to tracker' THEN 3
				WHEN 'Fixed for life' THEN 4
				WHEN 'Tracker at origination, reverting to SVR' THEN 5
				WHEN 'Tracker at origination, reverting to Libor' THEN 6
				WHEN 'Tracker for life' THEN 7
				WHEN 'SVR, including discount to SVR' THEN 8
				WHEN 'Libor' THEN 9
				WHEN 'Total' THEN 10
				ELSE 10 END

	END TRY    
	BEGIN CATCH     
  
		DECLARE     
		   @errorMessage     NVARCHAR(MAX),    
		   @errorSeverity    INT,    
		   @errorNumber      INT,    
		   @errorLine        INT,    
		   @errorState       INT;    
  
		SELECT     
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()    
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetProductRate_ReversionaryData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage    
		, 'System'    
  
		RAISERROR (@errorMessage,    
			@errorSeverity,    
			@errorState )    
  
	END CATCH    
END
GO