USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetPdlLedgerSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetPdlLedgerSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spIR_GetPdlLedgerSummary 
(
@pAsAtDate datetime,
 @pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL
)  
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get Pdl Ledger summary for IR liability Strats
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */ 
AS 
  BEGIN 
	 BEGIN TRY 
	 --		Declare @pDealName varchar(200)='ARDMORE1'
		--,@pAsAtDate datetime='2018-07-31'

		DECLARE @dealIpdRunId        INT,
				@dealId              SMALLINT,
				@ipdDate             DATETIME,
				@previousIPDDateName VARCHAR(200)='PreviousIPD',
				@ipdSequence         INT,
				@previousIpdDate      DATE,  
				@dealPreviousIpdRunId INT  

      IF( Object_id('tempdb..#temp') IS NOT NULL ) 
        DROP TABLE #temp 

      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL ) 
        DROP TABLE #tempPrevious 

	   SELECT   
	  @dealIpdRunId = dir.DealIpdRunId  
	  , @dealId = dir.DealId  
	  , @ipdDate = di.IpdDate  
	  , @previousIpdDate  = ipdDt.PreviousIPD  
	 FROM     
	  cw.vwDealIpdDates ipdDt  
	 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
	 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
	 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
	 WHERE   
	  deal.DealName = @pDealName  
	  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
	  AND dir.IpdSequence <> 0   

	
	 SELECT @dealPreviousIpdRunId = prevRunId FROM cw.vwDealIpdRun dir  
	 WHERE DealIpdRunId = @dealIpdRunId

      SELECT dn.DealNoteId, 
             dn.NAME                        DisplayName, 
             ClosingBalance CurrentPeriodAmount, 
			 CONVERT(DECIMAL(38, 16), NULL) AS PreviousPeriodAmount, 
			 dn.NoteRank
      INTO   #temp 
      FROM   cw.PdlLedger_PostWf pdlLedgerPost 
             JOIN cfgcw.DealNote dn ON dn.DealNoteId = pdlLedgerPost.DealNoteId
      WHERE  pdlLedgerPost.DealIpdRunId = @dealIpdRunId  

       SELECT dn.DealNoteId, 
             dn.NAME                        DisplayName, 
             ClosingBalance CurrentPeriodAmount, 
			 dn.NoteRank
      INTO   #tempPrevious 
      FROM   cw.PdlLedger_PostWf pdlLedgerPost 
             JOIN cfgcw.DealNote dn ON dn.DealNoteId = pdlLedgerPost.DealNoteId 
      WHERE  pdlLedgerPost.DealIpdRunId = @dealPreviousIpdRunId

      UPDATE t 
      SET    PreviousPeriodAmount = tPrevious.CurrentPeriodAmount 
      FROM   #temp t, 
             #tempPrevious tPrevious 
      WHERE  t.DealNoteId = tPrevious.DealNoteId 

      SELECT DisplayName, 
             CONVERT(DECIMAL(38, 2), Round(CurrentPeriodAmount, 2))               CurrentPeriodAmount,
             CONVERT(DECIMAL(38, 2), Round(COALESCE(PreviousPeriodAmount, 0), 2)) PreviousPeriodAmount
      FROM   #temp 
	  ORDER BY NoteRank
  END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetPdlLedgerSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  END 

GO