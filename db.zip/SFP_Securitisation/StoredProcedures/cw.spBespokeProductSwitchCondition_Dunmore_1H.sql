USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spBespokeProductSwitchCondition_Dunmore_1H') IS NOT NULL
	DROP PROCEDURE cw.spBespokeProductSwitchCondition_Dunmore_1H
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spBespokeProductSwitchCondition_Dunmore_1H ( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  09.08.2020 
 *   Description: 
 *   
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *    
 *   exec cw.spBespokeProductSwitchCondition_Dunmore_1H	32,'fm\shriyad'
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20),
  @oValue BIT OUTPUT
)
AS 
BEGIN 
	 DECLARE @dealId  INT, @CollectionBusinessEndDate   datetime

	SELECT @dealId = DealId FROM  cw.vwDealIpdRun WHERE  DealIpdRunId = @pDealIpdRunId 

	SET @CollectionBusinessEndDate=(SELECT DealDateValue 
								  FROM   cw.vwDealDate 
								  WHERE  DealIpdRunId=@pDealIpdRunId 
										 AND DealDateKeyInternalName = 'CollectionBusinessEnd') 

		SELECT
		 @oValue = CASE WHEN SUM(QuarterlyCapitalBalanceValue)!=0 THEN 0 ELSE 1 END
		FROM
		[cw].[DealProductSwitchData] psd
		JOIN  [cfgCW].[ProductSwitchType] pst ON psd.ProductSwitchTypeId = pst.ProductSwitchTypeId AND pst.IsActive = 1
		WHERE
		dealid=@dealId
		AND CorrelatedDate =@CollectionBusinessEndDate
		AND pst.Name IN ('LIFETIMEFIXEDHIGH-FIXEDLOW','LIFETIMEFIXEDLOW-FIXEDHIGH') 

		SELECT @oValue
END

GO