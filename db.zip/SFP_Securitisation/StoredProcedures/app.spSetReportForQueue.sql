USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[app].[spSetReportForQueue]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [app].[spSetReportForQueue]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spSetReportForQueue]
(
	@pReportId INT,
	@pUserName VARCHAR(50),
	@pReportDate    VARCHAR(20)  = NULL, 
    @pPoolName      VARCHAR(120) = NULL,  --Deal (Pool) name or hypo Pool name.
	@pParamList AS app.udtIntVarArray READONLY, 
    @pBatchReportId INT OUTPUT
)
AS             
BEGIN  
BEGIN TRANSACTION SetReportBatch
	BEGIN TRY	

		EXEC sfp.syn_SfpModel_sp_app_spSetReportBatch @pReportId, @pUserName, @pReportDate, @pPoolName, @pBatchReportId OUTPUT	
		IF (@pBatchReportId > 1) 
		BEGIN 
			SELECT * INTO #tempT FROM @pParamList;

			WHILE EXISTS( SELECT 1 FROM #tempT)
			BEGIN 
				DECLARE @ReportParamId INT;
				DECLARE @ReportParamValue VARCHAR(120);
				
				SELECT TOP 1 @ReportParamId = pl.Id, @ReportParamValue = pl.Value 
				FROM #tempT pl;		
								
				EXEC sfp.syn_SfpModel_sp_app_spSetReportBatchParameter @pBatchReportId, @ReportParamId, @ReportParamValue;

				DELETE  FROM #tempT  WHERE Id = @ReportParamId;
			END

			EXEC sfp.syn_SfpModel_sp_app_spValidateOnDemandParameters @pBatchReportId;
		END 

		COMMIT TRANSACTION SetReportBatch;
	END TRY            
BEGIN CATCH            
  DECLARE             
   @errorMessage     NVARCHAR(MAX),            
   @errorSeverity    INT,            
   @errorNumber      INT,            
   @errorLine        INT,            
   @errorState       INT;         
   
   SET @pBatchReportId = -1;
  SELECT             
   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()            
  
  IF @@TRANCOUNT > 0
  BEGIN
			ROLLBACK TRANSACTION SetReportBatch
  END
  EXEC app.SaveErrorLog 2, 1, 'spSetReportForQueue', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
              
  RAISERROR (@errorMessage,            
             @errorSeverity,            
             @errorState)            
 END CATCH            
END

GO
