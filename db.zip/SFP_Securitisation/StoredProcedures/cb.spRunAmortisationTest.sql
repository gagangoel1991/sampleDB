USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRunAmortisationTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunAmortisationTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRunAmortisationTest] 
    @pDealIpdRunId INT,
	@pUserName  VARCHAR(80)       
AS  
--   
/*
 * Author: Suresh Pandey
 * Date:	20-01-2022
 * Description:  This will run the amortisation test and insert data for test.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Exec [cb].[spRunAmortisationTest] 46, 'System'
 * 
*/
BEGIN  
  
	BEGIN TRY  

		DECLARE 
			@result									VARCHAR(10)='N/A',
			@isNoticeToPayLLPGiven					VARCHAR(10),						
			@amortisationTestTrueBalance			DECIMAL(38, 16) = 0, 				
			@authorisedInvestments					DECIMAL(38, 16) = 0 ,   					
			@substitutionAssets						DECIMAL(38, 16) = 0, 							
			@negativeCarryAmount					DECIMAL(38, 16) = 0,							
			@principalOutstandingAmount				DECIMAL(38, 16) = 0,					
			@weightedAverageRemainingTermYears		DECIMAL(38, 16) = 0,			
			@negativeCarryFactor					DECIMAL(38, 16) = 0,							
			@weightedAverageMargin					DECIMAL(38, 16) = 0,			 
			@amortisationTestAggregateLoanAmount	DECIMAL(38, 16)= 0 ,			
			@ipdDate								DATETIME,
			@collectionEndDate						DATE,
			@testTypeID								INT,
			@dealId									INT,
			@createdDate							DATE = GETDATE()

		SELECT @ipdDate = IpdDate, @dealId = DealId FROM  cw.vwDealIpdRun 
			WHERE  DealIpdRunId = @pDealIpdRunId; 
		
		SELECT @collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
			FROM 
				[cw].[vwDealIpdDates] ipdDt
			JOIN
				cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
			WHERE
				ipdRun.RunId = @pDealIpdRunId

		SELECT @testTypeID=TestTypeID  FROM cfgcb.TestType WHERE InternalName='AmortisationTest'

		SET @isNoticeToPayLLPGiven =(SELECT CASE WHEN [CW].[fnIsTriggerBreached](@dealId, @pDealIpdRunId,'NonRatingTrigger','IssuerEventOfDefault')=1 THEN 'YES' ELSE 'NO' END)

		SET @authorisedInvestments=	(SELECT ISNULL(( SELECT [Value] FROM cb.ManualFieldValue mfv JOIN cfgcb.ManualField mf ON  mf.ManualFieldId=mfv.ManualFieldId
				WHERE mf.InternalName='Other_Authorised_Investments'AND mfv.DealIpdRunId=@pDealIpdRunId),0))
 
		SET @substitutionAssets=	(SELECT ISNULL(( SELECT [Value] FROM cb.ManualFieldValue mfv JOIN cfgcb.ManualField mf ON  mf.ManualFieldId=mfv.ManualFieldId
			WHERE mf.InternalName='SubstitutionAssets'AND mfv.DealIpdRunId=@pDealIpdRunId),0))

		IF(@isNoticeToPayLLPGiven ='YES')
		BEGIN

			SET @weightedAverageMargin = (SELECT [Cb].[fnGetWeightedAverageMargin](@dealId, @pDealIpdRunId) ) 
	 

			SET @negativeCarryFactor = (SELECT [Cb].[fnGetNegativeCarryFactor](@dealId, @pDealIpdRunId))	
	 
			SELECT @principalOutstandingAmount = ISNULL(SUM(PrincipalOutstanding_GBP),0) FROM [cb].[DealNote_Wf] dnwf
				JOIN [cfgcb].[DealNote] dn
					ON dn.dealnoteid =dnwf.DealNoteId AND DealIpdRunId=@pDealIpdRunId
 
			SELECT @weightedAverageRemainingTermYears= ISNULL(SUM(PrincipalOutstanding_GBP * RemainingTermYears)/CAST(SUM(PrincipalOutstanding_GBP) AS FLOAT) ,0) 
				FROM 
					[cb].[DealNote_Wf] dnwf
				JOIN 
					[cfgcb].[DealNote] dn
				ON dn.dealnoteid =dnwf.DealNoteId AND DealIpdRunId=@pDealIpdRunId

			SET @negativeCarryAmount = @principalOutstandingAmount*@weightedAverageRemainingTermYears*@negativeCarryFactor
	
			SET @amortisationTestTrueBalance =(SELECT ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDate, @dealId, 'AmortisationTrueBalance'),0) )
		
			SET @amortisationTestAggregateLoanAmount = @amortisationTestTrueBalance + @authorisedInvestments + @substitutionAssets - @negativeCarryAmount
	
			SET @result= (SELECT IIF(@amortisationTestAggregateLoanAmount>@principalOutstandingAmount AND @isNoticeToPayLLPGiven='YES','PASS',
								IIF(@amortisationTestAggregateLoanAmount<@principalOutstandingAmount AND @isNoticeToPayLLPGiven='YES','FAIL','N/A')))

		END

		IF ( Object_id('tempdb..#TestLineItemValue') IS NOT NULL ) 
			DROP TABLE #TestLineItemValue 

		CREATE TABLE #TestLineItemValue(
			TestLineItemID INT,
			InternalName VARCHAR(200),
			DealIpdRunId INT,
			[Value] VARCHAR(500))

		INSERT INTO #TestLineItemValue(TestLineItemID,InternalName,DealIpdRunId,[Value])
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,@isNoticeToPayLLPGiven FROM cfgcb.TestLineItem WHERE InternalName='IsNoticeToPayLLPgiven'
		UNION				  
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@amortisationTestTrueBalance AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='A_AmortisationTestTrueBalance'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@authorisedInvestments AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='B_AuthorisedInvestments'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@substitutionAssets AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='C_SubstitutionAssets'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@negativeCarryAmount AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='Z_NegativeCarryAmount'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@principalOutstandingAmount AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='PrincipalOutstandingAmount(Sterling)'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@weightedAverageRemainingTermYears AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='WeightedAverageRemainingTerm(Years)'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@negativeCarryFactor AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='NegativeCarryFactor'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@weightedAverageMargin AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='WeightedAverageMargin'
		UNION				 
		SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@amortisationTestAggregateLoanAmount AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='AmortisationTestAggregateLoanAmount'
		UNION				 
		SELECT TestLineItemID,InternalName, @pDealIpdRunId, @result FROM cfgcb.TestLineItem WHERE InternalName='AmortisationTestResult'
		

		--Now merge the line item values into main table
		MERGE cb.TestLineItemValue AS trg
		USING #TestLineItemValue AS src
		ON src.TestLineItemId = trg.TestLineItemId AND trg.DealIpdrunId = @pDealIpdRunId
		WHEN NOT MATCHED BY Target THEN
			INSERT (TestLineItemID, DealIpdRunId, [Value], IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			VALUES (src.TestLineItemId, @pDealIpdRunId, src.[Value], 1, @pUserName, @createdDate, @pUserName, @createdDate)
		WHEN MATCHED THEN UPDATE SET
			trg.[Value]	= src.[Value], trg.ModifiedDate = @createdDate, trg.ModifiedBy = @pUserName;

		---Save the test result 
		EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeID, @result, @pUserName

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spRunAmortisationTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH  
END
GO