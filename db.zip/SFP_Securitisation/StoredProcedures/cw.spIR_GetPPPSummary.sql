USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetPPPSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetPPPSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spIR_GetPPPSummary 
(
@pAsAtDate datetime,
 @pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL
) 

/* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get Principal priority of payment summary for IR liability Strats
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */ 
AS 
  BEGIN 
  BEGIN TRY 
   --  Declare @pDealName varchar(200)='ARDMORE1'
	  --,@pAsAtDate datetime='2018-07-31'

     DECLARE @dealIpdRunId        INT,
        @dealId              SMALLINT,
        @ipdDate             DATETIME,
        @previousIPDDateName VARCHAR(200)='PreviousIPD',
		@PreviousRunNum      SMALLINT,
		@previousIpdDate      DATE,  
		@dealPreviousIpdRunId INT  
  
  

      IF( Object_id('tempdb..#temp') IS NOT NULL ) 
        DROP TABLE #temp 

      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL ) 
        DROP TABLE #tempPrevious 

			SELECT   
		  @dealIpdRunId = dir.DealIpdRunId  
		  , @dealId = dir.DealId  
		  , @ipdDate = di.IpdDate  
		  , @previousIpdDate  = ipdDt.PreviousIPD  
		 FROM     
		  cw.vwDealIpdDates ipdDt  
		 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		 WHERE   
		  deal.DealName = @pDealName  
		  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
		  AND dir.IpdSequence <> 0   
		        
		 SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
		 JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
		 WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1  


      SELECT wli.WaterfallLineItemId, 
             wli.DisplayName, 
             pwps.TotalRequiredAmount       CurrentRequiredAmount, 
             pwps.TotalPaidAmount           CurrentPaidAmount, 
             pwps.RemainingDueAmount        CurrentShortfall, 
             CONVERT(DECIMAL(38, 16), NULL) PreviousRequiredAmount, 
             CONVERT(DECIMAL(38, 16), NULL) PreviousPaidAmount, 
             CONVERT(DECIMAL(38, 16), NULL) PreviousShortfall,
			 wli.SortOrder
      INTO   #temp 
      FROM   cw.PrincipalWaterfallPaymentSummary pwps
             JOIN cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = pwps.WaterfallLineItemId 
      WHERE  
				pwps.DealIpdRunId = @dealIpdRunId 
             
      ORDER  BY wli.SortOrder ASC 

      SELECT wli.WaterfallLineItemId, 
             pwps.TotalRequiredAmount PreviousRequiredAmount, 
             pwps.TotalPaidAmount     PreviousPaidAmount, 
             pwps.RemainingDueAmount  PreviousShortfall 
      INTO   #tempPrevious 
      FROM    cw.PrincipalWaterfallPaymentSummary pwps
             JOIN cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = pwps.WaterfallLineItemId  
      WHERE  
			pwps.DealIpdRunId = @dealPreviousIpdRunId 
             
      ORDER  BY wli.SortOrder ASC 

      UPDATE t 
      SET    PreviousRequiredAmount = tPrevious.PreviousRequiredAmount, 
             PreviousPaidAmount = tPrevious.PreviousPaidAmount, 
             PreviousShortfall = tPrevious.PreviousShortfall 
      FROM   #temp t
             JOIN #tempPrevious tPrevious ON t.WaterfallLineItemId = tPrevious.WaterfallLineItemId
        

      SELECT DisplayName, 
             CONVERT(DECIMAL(38, 16), CurrentRequiredAmount)               CurrentRequiredAmount,
             CONVERT(DECIMAL(38, 16), CurrentPaidAmount)                   CurrentPaidAmount,
             CONVERT(DECIMAL(38, 16), CurrentShortfall)                    CurrentShortfall,
             CONVERT(DECIMAL(38, 16), COALESCE(PreviousRequiredAmount, 0)) PreviousRequiredAmount,
             CONVERT(DECIMAL(38, 16), COALESCE(PreviousPaidAmount, 0))     PreviousPaidAmount,
             CONVERT(DECIMAL(38, 16), COALESCE(PreviousShortfall, 0))      PreviousShortfall
      FROM   #temp 
	  ORDER BY SortOrder

	END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetPPPSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  END

GO