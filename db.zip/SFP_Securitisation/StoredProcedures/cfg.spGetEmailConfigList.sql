USE [SFP_Securitisation]
GO

IF OBJECT_ID('cfg.spGetEmailConfigList') IS NOT NULL
	DROP PROCEDURE cfg.spGetEmailConfigList
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Suresh Pandey  
--Date: 06-09-2022  
--Description: To get Email Config data
--Exec cfg.spGetEmailConfigList 0,'suresh' 
--==================================  
CREATE PROCEDURE [cfg].[spGetEmailConfigList] 
	@pEmailConfigId INT=NULL,
	@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
		IF(ISNULL(@pEmailConfigId,0)>0)
		BEGIN
			SELECT 
				ec.EmailConfigId
				,ec.EmailTypeId
				,et.DisplayName AS EmailType
				,ec.InternalName
				,ec.DisplayName
				,ec.EmailFrom
				,ec.EmailTo
				,ec.EmailCC
				,ec.EmailBCC
				,ec.EmailSubject
				,ec.EmailBody
				,ec.EmailImportance
				,CASE WHEN ec.EmailImportance=1 THEN 'High' ELSE 'Normal' END AS EmailImportanceText
				,ec.EmailFormat
				,ec.Attachment
				,CASE WHEN ec.Attachment=1 THEN 'Yes' ELSE 'No' END AS AttachmentText
				,ec.IsActive
				,CASE WHEN ec.IsActive=1 THEN 'Active' ELSE 'Inactive' END AS ActiveStatus
				,ec.CreatedBy
				,ec.CreatedDate
				,ec.ModifiedBy
				,ec.ModifiedDate 
			FROM [cfg].[EmailConfiguration] ec
			JOIN [cfg].EmailType et
				ON et.EmailTypeId=ec.EmailTypeId 
			WHERE ec.EmailConfigId=@pEmailConfigId
		END
		ELSE
		BEGIN 
			SELECT 
				ec.EmailConfigId
				,ec.EmailTypeId
				,et.DisplayName AS EmailType
				,ec.InternalName
				,ec.DisplayName
				,ec.EmailFrom
				,ec.EmailTo
				,ec.EmailCC
				,ec.EmailBCC
				,ec.EmailSubject
				,ec.EmailBody
				,ec.EmailImportance
				,CASE WHEN ec.EmailImportance=1 THEN 'High' ELSE 'Normal' END AS EmailImportanceText
				,ec.EmailFormat
				,ec.Attachment
				,CASE WHEN ec.Attachment=1 THEN 'Yes' ELSE 'No' END AS AttachmentText
				,ec.IsActive
				,CASE WHEN ec.IsActive=1 THEN 'Active' ELSE 'Inactive' END AS ActiveStatus
				,ec.CreatedBy
				,ec.CreatedDate
				,ec.ModifiedBy
				,ec.ModifiedDate 
			FROM [cfg].[EmailConfiguration] ec
			JOIN [cfg].EmailType et
				ON et.EmailTypeId=ec.EmailTypeId
		END

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2
			,1
			,'cfg.spGetEmailConfigList'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH;
END

GO
