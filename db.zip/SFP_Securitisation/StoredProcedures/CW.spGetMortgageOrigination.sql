USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetMortgageOrigination') IS NOT NULL
	DROP PROC CW.spGetMortgageOrigination
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:    20.05.2020
 * Description:  This will return Current Mortgage size at Origination for Investor report.
 * Usage : CW.spGetMortgageOrigination @pAsAtDate  ='28-FEB-2020'
 * 		,@pDealName  = 'DUNMORE1'
 * 		,@pStratInternalName = 'MortgageOrigination'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetMortgageOrigination @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY 
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
BEGIN TRY

	
	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	 , @totalNumberofSubAccounts float
	 , @totalOutstandingCapitalBalance float
	 , @totalTrueBalance float
		
	 SELECT @totalNumberofSubAccounts = COUNT(ISNULL(MAP.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(MAP.CapitalBalanceAtFlagged, 0))  
		, @totalTrueBalance  = SUM(ISNULL(MAP.TrueBalanceAtFlagged, 0)) 

		FROM [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool] MAP  
		INNER JOIN sfp.[syn_SfpModel_vw_MortgageDeal_v1] md ON ( MAP.MortgageDealKey = md.MortgageDealKey  
											 AND md.dealName = @pDealName  
											 AND md.AsatDatefrom <= @pAsAtDate  
											 AND md.AsatDateto > @pAsAtDate  
											 )  
		INNER JOIN sfp.syn_SfpModel_vw_Calendar_v1 cal ON MAP.FlaggedDateKey = cal.AsAtDateKey  
		WHERE cal.AsAtDate = md.dealstartdate  AND MAP.IsFurtherAdvance = 0 
		GROUP BY MAP.MortgageDealKey
	
	
	SELECT DealName, MAP.MortgageDealKey, MAP.MortgageSubAccountKey, MAP.CapitalBalanceAtFlagged AS TotalOutstandingCapitalBalance, MAP.TrueBalanceAtFlagged AS TotalTrueBalance
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MAP.CapitalBalanceAtFlagged) AS BandRange
	INTO #temp
	FROM [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool]  MAP  
		INNER JOIN sfp.[syn_SfpModel_vw_MortgageDeal_v1] md ON ( MAP.MortgageDealKey = md.MortgageDealKey  
											 AND md.dealName = @pDealName  
											 AND md.AsatDatefrom <= @pAsAtDate  
											 AND md.AsatDateto > @pAsAtDate  
											 )  
		INNER JOIN sfp.syn_SfpModel_vw_Calendar_v1 cal ON MAP.FlaggedDateKey = cal.AsAtDateKey  
		WHERE cal.AsAtDate = md.dealstartdate  AND MAP.IsFurtherAdvance = 0   

	SELECT dans.DisplayName 'HeaderText', isNull(count(MortgageSubAccountKey),0) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalNumberofSubAccounts  ) AS Decimal(38,8)) ELSE 0 END AS Float) , 0)AS MortgageLoansPercent 
	, ISNULL(CAST(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) AS Float) , 0) 'TotalOutCapitalBalance' 
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance )  AS Decimal(38,8))  ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent 
	, CAST(IsNull(sum(TotalTrueBalance),0) AS Float) TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TotalTrueBalance) / @totalTrueBalance)  AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) TrueBalancePercent  
	INTO #FinalData
	FROM @pStratRangeData dans 
	LEFT JOIN #temp T ON T.BandRange = dans.DisplayName 
	GROUP BY dans.DisplayName , dans.SortOrder	
	
	
	SELECT HeaderText, MortgageLoans, MortgageLoansPercent, TotalOutCapitalBalance, TotalOutCapitalBalancePercent
	FROM (
	SELECT DISTINCT 
		IsNull(dans.DisplayName,'Total') AS 'HeaderText',
		SUM(F.[MortgageLoans]) AS 'MortgageLoans', 
		SUM(F.MortgageLoansPercent) AS 'MortgageLoansPercent', 
		SUM(F.TotalOutCapitalBalance) AS 'TotalOutCapitalBalance', 
		SUM(F.TotalOutCapitalBalancePercent) AS 'TotalOutCapitalBalancePercent' ,
		SUM(dans.SortOrder)  AS 'SortOrder'
	FROM @pStratRangeData dans
	INNER JOIN #FinalData F ON F.[HeaderText] = dans.DisplayName
	GROUP BY dans.DisplayName, dans.SortOrder WITH ROLLUP
	) AS Tbl 
	ORDER BY SortOrder
			
	
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetMortgageOrigination', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			

END


GO
