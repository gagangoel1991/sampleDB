USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetForberancePrimarySecondaryMonthsInArrear', 'P') IS NOT NULL
 DROP PROC  CW.spGetForberancePrimarySecondaryMonthsInArrear;

GO
  
/*  
 * Author: Arun  
 * Date:    28.05.2020  
 * Description:  This will return Forbearance - Primary & Secondary Month In Arrears for Investor report.  
 * Usage : CW.spGetForberancePrimarySecondaryMonthsInArrear @pAsAtDate  = '30-Nov-2020'  
 *   ,@pDealName  = 'DUNMORE1' 
 *   ,@pUserName = NULL                                                    
 * Change History  
 * --------------  
 * Author              Date                 Description  
 * -------------------------------------------------------  
*/  
CREATE PROC CW.spGetForberancePrimarySecondaryMonthsInArrear @pAsAtDate DATE  
  ,@pDealName VARCHAR(255)   
  ,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY  
  ,@pUserName VARCHAR(50) = NULL    
  
AS  
BEGIN  
      
      
BEGIN TRY  
  

	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	DECLARE @dealId int
	,@totalSubAccounts float, @totalOutstandingCapitalBalance float, @totalTrueBalance float
	,@capitalisationTotalSubAccounts float, @capitalisationTotalEURAmount float, @capitalisationTotalTrueBalance float  
	,@termExtensionTotalSubAccounts float, @termExtensionTotalEURAmount float , @termExtensionTotalTrueBalance float 
	,@bothTotalSubAccounts float, @bothTotalEURAmount float , @bothTotalTrueBalance float 

	IF OBJECT_ID('#Forbearance')				 IS NOT NULL DROP TABLE	#Forbearance						
	IF OBJECT_ID('#Capitalisation')			 IS NOT NULL DROP TABLE	#Capitalisation
	IF OBJECT_ID('#TermExtension')			 IS NOT NULL DROP TABLE	#TermExtension
	IF OBJECT_ID('#TempCapitalisation')		 IS NOT NULL DROP TABLE	#TempCapitalisation
	IF OBJECT_ID('#TempTermExtension')		 IS NOT NULL DROP TABLE	#TempTermExtension
	IF OBJECT_ID('#FinalCapitalisation')		 IS NOT NULL DROP TABLE	#FinalCapitalisation
	IF OBJECT_ID('#FinalTermExtension')		 IS NOT NULL DROP TABLE	#FinalTermExtension
	IF OBJECT_ID('tempdb..#VwMortgageSubAccount')               IS NOT NULL DROP TABLE #VwMortgageSubAccount
	
	SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1 

	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId


	 
	SELECT MortgageSubAccountKey, ForbearanceKey, FORBEARANCE_TYPE AS ForbearanceType, FORBEARANCE_COUNTER AS ForbearanceCounter, FORBEARANCE_STATUS AS forbearanceStatus
	, CURRENT_CAPITALISATION_DATE AS CapitalisationDate, CURRENT_TERM_EXT_DATE AS TermExtensionDate
	, FIRST_FORBEARANCE_START_DATE AS FirstForbearanceStartDate, CURRENT_FORBEARANCE_END_DATE AS CurrentForbearanceEndDate, Forbearance_AsAtDateFrom AS AsAtDateFrom, Forbearance_AsAtDateTo AS AsAtDateTo
	, Outstandng_Capital_Balance_Amt AS TotalOutstandingCapitalBalance, True_Balance_Amt AS TrueBalance
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MONTHS_IN_ARREARS ) AS BandRange  
	INTO #Forbearance        
	FROM #VwMortgageSubAccount


	CREATE CLUSTERED INDEX FB ON #Forbearance  (forbearancekey);       

	---=For Capitalisation of Arrears (Only) ---    
	SELECT MortgageSubAccountKey,ForbearanceKey, CapitalisationDate, TermExtensionDate, forbearanceStatus, ForbearanceCounter, TotalOutstandingCapitalBalance, TrueBalance
	INTO #Capitalisation  
	FROM #Forbearance        f    
	WHERE f.CapitalisationDate NOT IN (      '0001-01-01'  ,  '1900-01-01' )    
	AND f.TermExtensionDate IN (  '0001-01-01'  ,'1900-01-01'  )    
	AND f.ForbearanceStatus = 'L'
	AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate    

	CREATE CLUSTERED INDEX CR ON #Capitalisation  (forbearancekey);       

	---=For Term Extension (Only) ----    

	SELECT  MortgageSubAccountKey,ForbearanceKey, CapitalisationDate, TermExtensionDate, forbearanceStatus, ForbearanceCounter, TotalOutstandingCapitalBalance, TrueBalance    
	INTO #TermExtension   
	FROM #Forbearance        f    
	WHERE  f.CapitalisationDate IN (      '0001-01-01'  ,  '1900-01-01' )    
	AND f.TermExtensionDate NOT IN (  '0001-01-01'  ,'1900-01-01'  )    
	AND f.ForbearanceStatus = 'L'    
	AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate

	CREATE CLUSTERED INDEX CO ON #TermExtension   (forbearancekey);       

	---=For Both Extension (Only) ----    

	SELECT  MortgageSubAccountKey,ForbearanceKey, CapitalisationDate, TermExtensionDate, forbearanceStatus, ForbearanceCounter, TotalOutstandingCapitalBalance, TrueBalance     
	INTO #BothTerm   
	FROM #Forbearance        f 
	WHERE f.CapitalisationDate NOT IN (      '0001-01-01'  ,  '1900-01-01' )    
	AND f.TermExtensionDate NOT IN (  '0001-01-01'  ,'1900-01-01'  )    
	AND f.ForbearanceStatus = 'L'    
	AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate

	CREATE CLUSTERED INDEX CO ON #BothTerm   (forbearancekey);       


	--=FOR % of Total pool of assets  
	SELECT @totalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @totalOutstandingCapitalBalance = SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0))    
	, @totalTrueBalance = SUM(ISNULL(FB.TrueBalance, 0)) 
	FROM   #Forbearance FB  


	---=For Capitalisation of Arrears (Only) ============================================================  
	SELECT @capitalisationTotalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @capitalisationTotalEURAmount = SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0)) 
	, @capitalisationTotalTrueBalance = SUM(ISNULL(FB.TrueBalance, 0))    
	FROM   #Forbearance FB  
		   INNER JOIN #Capitalisation AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey   
	         

	---=For Term Extension (Only) ============================================================  
	SELECT @termExtensionTotalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @termExtensionTotalEURAmount =IsNull(SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0)),0)
	, @termExtensionTotalTrueBalance = SUM(ISNULL(FB.TrueBalance, 0))   
	FROM   #Forbearance FB  
		   INNER JOIN #TermExtension AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey    


	---=For Both Term (Only) ============================================================  
	SELECT @bothTotalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @bothTotalEURAmount =IsNull(SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0)),0)
	, @bothTotalTrueBalance = SUM(ISNULL(FB.TrueBalance, 0))   
	FROM   #Forbearance FB  
		   INNER JOIN #BothTerm AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey    
	       
	         
	SELECT @pDealName AS DealName, FB.ForbearanceKey, FB.MortgageSubAccountKey, FB.TotalOutstandingCapitalBalance AS TotalOutstandingCapitalBalance, FB.TrueBalance  
	, BandRange  
	INTO #TempCapitalisation  
	FROM   #Forbearance FB  
		   INNER JOIN #Capitalisation AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey  
	         
	SELECT @pDealName AS DealName, FB.ForbearanceKey, FB.MortgageSubAccountKey, FB.TotalOutstandingCapitalBalance AS TotalOutstandingCapitalBalance, FB.TrueBalance  
	, BandRange  
	INTO #TempTermExtension  
	FROM   #Forbearance FB  
		   INNER JOIN #TermExtension AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey     
	       
	  
	SELECT @pDealName AS DealName, FB.ForbearanceKey, FB.MortgageSubAccountKey, FB.TotalOutstandingCapitalBalance AS TotalOutstandingCapitalBalance, FB.TrueBalance  
	, BandRange  
	INTO #TempTermBoth
	FROM   #Forbearance FB  
		   INNER JOIN #BothTerm AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey                                     


	SELECT dans.DisplayName '~HeaderText', iSNull(count(MortgageSubAccountKey),0) [MortgageLoans]  
	, Cast(CASE WHEN @capitalisationTotalSubAccounts > 0 THEN ISNULL( Cast( (COUNT(MortgageSubAccountKey) / @capitalisationTotalSubAccounts  ) AS Decimal(38,18)) , 0) ELSE 0 END AS Decimal(18,4)) AS MortgageLoansPercent    
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance'  
	, ISNULL(CAST( CASE WHEN @capitalisationTotalEURAmount > 0 THEN  Cast( (sum(TotalOutstandingCapitalBalance) / @capitalisationTotalEURAmount ) AS Decimal(38,18)) ELSE 0 END AS Decimal(18,4)) , 0) TotalOutCapitalBalancePercent
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance) AS Decimal(38,18)) ELSE 0 END AS Decimal(18,4)) , 0) [TotalAssetPoolAmountPercent]  
	, ISNULL(CAST(sum(TrueBalance) AS Decimal(38,2)) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance)  AS Decimal(38,18)) ELSE 0 END AS Decimal(18,4)) , 0) TrueBalancePercent  
	INTO #FinalCapitalisation  
	FROM @pStratRangeData dans   
	LEFT JOIN #TempCapitalisation T ON T.BandRange = dans.DisplayName   
	GROUP BY dans.DisplayName , dans.SortOrder   
	ORDER BY dans.SortOrder;    


	SELECT dans.DisplayName '~HeaderText', iSNull(count(MortgageSubAccountKey),0) [MortgageLoans]  
	, Cast(CASE WHEN @termExtensionTotalSubAccounts > 0 THEN   ISNULL( Cast( (COUNT(MortgageSubAccountKey) / @termExtensionTotalSubAccounts ) AS Decimal(38,18)) , 0) ELSE 0 END AS Decimal(18,4)) AS MortgageLoansPercent    
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance'   
	, Cast(CASE WHEN @termExtensionTotalEURAmount > 0 THEN ISNULL( Cast( (sum(TotalOutstandingCapitalBalance) / @termExtensionTotalEURAmount )  AS Decimal(38,18)),0) ELSE 0 END  AS Float) TotalOutCapitalBalancePercent    
	, Cast(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN  ISNULL( Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) AS Decimal(38,18)),0)  ELSE 0  END AS Decimal(18,4))  [TotalAssetPoolAmountPercent]
	, ISNULL(CAST(sum(TrueBalance) AS Decimal(38,2)) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) AS Decimal(38,18)) ELSE 0 END AS Decimal(18,4)) , 0) TrueBalancePercent  
	INTO #FinalTermExtension  
	FROM @pStratRangeData dans   
	LEFT JOIN #TempTermExtension  T ON T.BandRange = dans.DisplayName   
	GROUP BY dans.DisplayName , dans.SortOrder   
	ORDER BY dans.SortOrder;   


	SELECT dans.DisplayName '~HeaderText', iSNull(count(MortgageSubAccountKey),0) [MortgageLoans]  
	, Cast(CASE WHEN @bothTotalSubAccounts > 0 THEN   ISNULL( Cast( (COUNT(MortgageSubAccountKey) / @bothTotalSubAccounts ) AS Decimal(38,18)) , 0) ELSE 0 END AS Decimal(18,4)) AS MortgageLoansPercent    
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance'   
	, Cast(CASE WHEN @bothTotalEURAmount > 0 THEN ISNULL( Cast( (sum(TotalOutstandingCapitalBalance) / @bothTotalEURAmount )  AS Decimal(38,18)),0) ELSE 0 END  AS Float) TotalOutCapitalBalancePercent    
	, Cast(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN  ISNULL( Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) AS Decimal(38,18)),0)  ELSE 0  END AS Decimal(18,4))  [TotalAssetPoolAmountPercent]
	, ISNULL(CAST(sum(TrueBalance) AS Decimal(38,2)) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) AS Decimal(38,18)) ELSE 0 END AS Decimal(18,4)) , 0) TrueBalancePercent  
	INTO #FinalTermBoth
	FROM @pStratRangeData dans   
	LEFT JOIN #TempTermBoth T ON T.BandRange = dans.DisplayName   
	GROUP BY dans.DisplayName , dans.SortOrder   
	ORDER BY dans.SortOrder;   


	SELECT DISTINCT 
	ISnull(dans.DisplayName,'Total') AS '~HeaderText',
	SUM(CRNT.[MortgageLoans]) AS 'Number of Mortgage Loans~Capitalisation', 
	SUM(CRNT.TotalOutCapitalBalance) AS 'Amount (EUR)~Capitalisation', 
	SUM(CRNT.TotalAssetPoolAmountPercent) AS 'Amount as % of total pool assets~Capitalisation', 

	SUM(CMO.[MortgageLoans]) AS 'Number of Mortgage Loans~TermExtension',  
	SUM(CMO.TotalOutCapitalBalance) AS 'Amount (EUR)~TermExtension',  
	SUM(CMO.TotalAssetPoolAmountPercent)  AS 'Amount as % of total pool assets~TermExtension',  

	SUM(FTB.[MortgageLoans]) AS 'Number of Mortgage Loans~Both',  
	SUM(FTB.TotalOutCapitalBalance) AS 'Amount (EUR)~Both',  
	SUM(FTB.TotalAssetPoolAmountPercent)  AS 'Amount as % of total pool assets~Both',
			
	SUM(CRNT.TotalAssetPoolAmountPercent)+SUM(CMO.TotalAssetPoolAmountPercent) +SUM(FTB.TotalAssetPoolAmountPercent) AS 'Amount as % of total pool assets~Overall' 		  

	INTO #FinalData
	FROM @pStratRangeData dans
	LEFT JOIN #FinalCapitalisation CRNT  ON CRNT.[~HeaderText] = dans.DisplayName
	LEFT JOIN #FinalTermExtension CMO ON  dans.DisplayName = CMO.[~HeaderText]  AND CRNT.[~HeaderText] = CMO.[~HeaderText]
	LEFT JOIN #FinalTermBoth FTB ON  dans.DisplayName = FTB.[~HeaderText]  AND CRNT.[~HeaderText] = FTB.[~HeaderText]
	GROUP BY dans.DisplayName, dans.SortOrder WITH ROLLUP
	--ORDER BY SUM(dans.SortOrder)

	SELECT F.* 
	FROM 
	#FinalData F 
	LEFT JOIN @pStratRangeData dans ON  F.[~HeaderText] = dans.DisplayName
	ORDER BY CASE WHEN F.[~HeaderText] = 'Total' THEN 100 ELSE   dans.SortOrder END

END TRY  
BEGIN CATCH  
    DECLARE   
                @errorMessage     NVARCHAR(MAX),  
                @errorSeverity    INT,  
                @errorNumber      INT,  
                @errorLine        INT,  
                @errorState       INT;  
  
    SELECT   
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()  
  
    EXEC app.SaveErrorLog 1, 1, 'spGetForberancePrimarySecondaryMonthsInArrear', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
    RAISERROR (@errorMessage,  
                @errorSeverity,  
                @errorState )  
END CATCH     
END  

GO
