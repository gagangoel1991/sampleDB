USE SFP_Securitisation
GO

IF OBJECT_ID('cw.spGetUploadedRatingData') IS NOT NULL
	DROP PROCEDURE cw.spGetUploadedRatingData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--================================================
--Author: Saurabh Bhatia
--Date:	18-May-2021
--Description:  To get Single User Rating Data
--Exec cw.spGetUploadedRatingData 7
--================================================
CREATE PROCEDURE cw.spGetUploadedRatingData (@RatingUploadDetailId INT)
AS
BEGIN
	SELECT d.DealName
		,urf.CollectionDate
		,urf.OriginalFileName
		,urf.UploadedFileName
		,urf.[Comment]
		,urf.UploadedBy
		,urf.UploadedDate
	FROM cw.RatingUploadDetail urf
	JOIN cw.vw_ActiveDeal d ON urf.DealId = d.DealId
	WHERE urf.RatingUploadDetailId = @RatingUploadDetailId;

	SELECT [Type]
		,[Unique Identifier]
		,[CRA]
		,[Rating Type]
		,[Rating Value]
		,[Comment]
	FROM (
		SELECT Row_number() OVER (
				PARTITION BY ubr.ISIN
				,ubr.Series
				,ubr.CRAId
				,ubr.RatingTypeId
				,CAST(ubr.RatingDate AS DATE) ORDER BY ubr.ModifiedDate DESC
				) AS RowNumber
			,'Bond' AS [Type]
			,ubr.ISIN AS [Unique Identifier]
			,cra.[Name] AS CRA
			,'Bond Rating' AS [Rating Type]
			,ubr.[Rating] AS [Rating Value]
			,ISNULL(ubr.[Comment], '') AS [Comment]
		FROM cw.UserBondRating ubr
		JOIN cfgCW.CreditRatingAgency cra ON cra.CRAId = ubr.CRAId
		JOIN cfgcw.RatingType rt ON rt.RatingTypeId = ubr.RatingTypeId
		JOIN cw.UserBondRating ubr1 ON ubr1.ISIN = ubr.ISIN
			AND ubr1.Series = ubr.Series
			AND ubr1.CRAId = ubr.CRAId
			AND ubr1.RatingTypeId = ubr.RatingTypeId
			AND CAST(ubr1.RatingDate AS DATE) = CAST(ubr.RatingDate AS DATE)
			AND ubr1.RatingUploadDetailId = @RatingUploadDetailId
		) AS x
	WHERE RowNumber = 1
	
	UNION ALL
	
	SELECT [Type]
		,[Unique Identifier]
		,[CRA]
		,[Rating Type]
		,[Rating Value]
		,[Comment]
	FROM (
		SELECT ROW_NUMBER() OVER (
				PARTITION BY ucr.CRAId
				,ucr.RatingTypeId
				,ucr.CisCode
				,CAST(ucr.RatingDate AS DATE) ORDER BY ucr.ModifiedDate
				) AS RowNumber
			,'Counterparty' AS [Type]
			,ucr.CisCode AS [Unique Identifier]
			,cra.[Name] AS CRA
			,rt.[Name] AS [Rating Type]
			,ucr.[Rating] AS [Rating Value]
			,ISNULL(ucr.[Comment], '') AS [Comment]
		FROM cw.UserCounterpartyRating ucr
		JOIN cfgCW.CreditRatingAgency cra ON cra.CRAId = ucr.CRAId
		JOIN cfgcw.RatingType rt ON rt.RatingTypeId = ucr.RatingTypeId
		JOIN cw.UserCounterpartyRating ucr1 ON ucr.CRAId = ucr1.CRAId
			AND ucr.RatingTypeId = ucr1.RatingTypeId
			AND ucr.CisCode = ucr1.CisCode
			AND CAST(ucr.RatingDate AS DATE) = CAST(ucr1.RatingDate AS DATE)
			AND ucr.RatingUploadDetailId = @RatingUploadDetailId
		) AS Y
	WHERE RowNumber = 1
END
GO