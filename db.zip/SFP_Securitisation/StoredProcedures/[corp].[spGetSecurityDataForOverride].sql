USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetSecurityDataForOverride]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetSecurityDataForOverride]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
	CREATED BY : Sakthivel
	DATE	   : 10-Aug-2022
	NOTES	   : To get the list of securities for the given Deal and Date combination. This list will be used for security deal data upload.
	--EXEC [corp].[spGetSecurityDataForOverride] '31-MAY-2022',1,'SAK'
*/

CREATE PROCEDURE [corp].[spGetSecurityDataForOverride]  
(  
 @pDate DATE,  
 @pDealId INT,  
 --@pEntityId INT = 1, 
 @pUserName VARCHAR(20) ,
 @pIsTemplate INT = 1
)  
AS  
BEGIN  
 BEGIN TRY 
	 IF OBJECT_ID('tempdb.dbo.#DealDataCorrectionAttribute', 'U') IS NOT NULL    
	  DROP TABLE #DealDataCorrectionAttribute;    
	 IF OBJECT_ID('tempdb.dbo.#DownlodableDataTbl', 'U') IS NOT NULL    
	  DROP TABLE #DownlodableDataTbl;    
	 IF OBJECT_ID('tempdb.dbo.#OverriddenData', 'U') IS NOT NULL    
	  DROP TABLE #OverriddenData;    
	 IF OBJECT_ID('tempdb.dbo.#PivotedCorrectedData', 'U') IS NOT NULL    
	  DROP TABLE #PivotedCorrectedData;   
  
	 DECLARE @pEntityId INT = (SELECT DealDataCorrectionEntityId FROM CORP.DealDataCorrectionEntity WHERE EntityName = 'Security')  
  
	 DECLARE @DateString VARCHAR(10) = CONVERT(VARCHAR(10),@pDate)  
	 DECLARE @EntityIdString VARCHAR(2) = CONVERT(VARCHAR(2),@pEntityId)  
	 DECLARE @DealIDString VARCHAR(3) = CONVERT(VARCHAR(3),@pDealID)  
  
	 DECLARE @DealId_Atlas INT = (SELECT DealId FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] WHERE DealName ='Atlas')  
	 DECLARE @DealId_Chowa INT = (SELECT DealId FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] WHERE DealName ='Chowa')  
  
  
	 CREATE TABLE #DealDataCorrectionAttribute(  
	 [SeqNumber] INT,  
	 [AttributeId] INT NOT NULL,  
	 [AttributeName] VARCHAR(100) NOT NULL,  
	 [DisplayName] VARCHAR(200) NOT NULL,  
	 [Description] VARCHAR(200) NOT NULL,  
	 [EntityTypeId] INT NOT NULL,  
	 [AttributeObjectId] BIGINT NOT NULL,  
	 [AttributeObjectName] VARCHAR(50) NOT NULL,  
	 [DataType] VARCHAR(20) NOT NULL,  
	 [IsEditable] BIT NOT NULL,  
	 [IsChecked] BIT NOT NULL,  
	 [IsHideAllowed] BIT NOT NULL,  
	 [IsActive] BIT NOT NULL ,
	 [StageDataType] VARCHAR(30),
	 [StageMaxAllowedValue] INT,
	 [StageMaxprecision] INT
	 )  
  
	 INSERT INTO #DealDataCorrectionAttribute  
	 EXEC corp.GetOverrideFieldAttributes 'SECURITY'   
	 DELETE FROM  #DealDataCorrectionAttribute WHERE AttributeName IN ('FACILITYID','SECURITYID')  
  
	 --SELECT * INTO   
	 --#DealDataCorrectionAttribute  
	 --FROM [corp].[DealDataCorrectionAttribute]   
	 --WHERE EntityTypeId = @pEntityId   
	 --  AND IsActive = 1   
	 --  AND AttributeName != 'SecurityId'  
  
	 DELETE FROM #DealDataCorrectionAttribute   
	 WHERE @pDealId NOT IN (@DealId_Atlas,@DealId_Chowa)   
		-- AND AttributeName IN ('TCE','Utilisation','RONA', 'ViabilityCategory') 
		AND AttributeName IN ('TCE','Utilisation', 'ViabilityCategory') 
  
   
	 -- CREATE DOWNLODABLE TABLE --  
	 --CREATE TABLE #DownlodableDataTbl                                      
	 --   (          
	 --  SecurityId BIGINT     
	 --   );  
  
	 DECLARE @AddFieldsColumn VARCHAR(MAX) = '';   
	 --SET @AddFieldsColumn  = 'ALTER Table #DownlodableDataTbl ADD '            
	 --SELECT @AddFieldsColumn = @AddFieldsColumn +  '[' + AttributeName  + ']' + CASE WHEN DataType IN ('VARCHAR','TEXT') THEN ' VARCHAR(MAX),'   
	 --                    --WHEN DataType IN ('INT','BIGINT', 'INTEGER') THEN ' INT,'  
	 --                    --WHEN DataType = 'DECIMAL' THEN ' DECIMAL(15,2),'  
	 --                    WHEN DataType = 'DATE' THEN ' DATE,'  
	 --                    ELSE ' VARCHAR(100),' END  
	 -- FROM #DealDataCorrectionAttribute    
	 -- ORDER BY SeqNumber  
	 --SET @AddFieldsColumn = (SUBSTRING(@AddFieldsColumn, 0, LEN(@AddFieldsColumn)))   
	 --EXEC(@AddFieldsColumn)  
  
  
	 -- CREATE OVERRIDEED TABLE --  
	 CREATE TABLE #OverriddenData                                    
		(    
		FacilityId BIGINT,
	   SecurityId BIGINT  
		);  
	 SELECT @AddFieldsColumn = '';   
	 SET @AddFieldsColumn  = 'ALTER Table #OverriddenData ADD '            
	 SELECT @AddFieldsColumn = @AddFieldsColumn +  '[' + AttributeName  + ']' + CASE WHEN DataType IN ('VARCHAR','TEXT') THEN ' VARCHAR(MAX),'   
						 --WHEN DataType IN ('INT','BIGINT', 'INTEGER') THEN ' INT,'  
						 --WHEN DataType = 'DECIMAL' THEN ' DECIMAL(15,2),'  
						 WHEN DataType = 'DATE' THEN ' DATE,'  
						 ELSE ' VARCHAR(100),' END  
	  FROM #DealDataCorrectionAttribute  
	  ORDER BY SeqNumber  
	 SET @AddFieldsColumn = (SUBSTRING(@AddFieldsColumn, 0, LEN(@AddFieldsColumn)))  
	 EXEC(@AddFieldsColumn)  
  
  
	 -- FOR CALLING COMMON SP FOR LOADING DOWNLODABLE TABLE WITH SECURITY IDS--  
		DECLARE @RowID VARCHAR(100)  
		--EXEC [rpt].[uspCommercialFacilityEntity] '2022-01-31' , '1', '', NULL, @OutputRowID = @RowID OUTPUT  
	 --EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]  
	 --@VintageDate = @pDate,  
	 --@DealKey  = @pDealID,  
	 --@OutputRowID = @RowID OUTPUT  
   
  
	 --INSERT INTO #DownlodableDataTbl (SecurityId)  
	 --SELECT DISTINCT CradleSecurityId FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
	 --SecurityKey,CradleSecurityId  
  
	 -- APPLY PIVOT FOR OVERRIDDEN DATA --  
	 DECLARE @PivotColumnNames VARCHAR(MAX) = '';           
	 SELECT @PivotColumnNames = @PivotColumnNames +  '[' + AttributeName + '], '     
	  FROM #DealDataCorrectionAttribute  
	  ORDER BY SeqNumber  
	 SET @PivotColumnNames = (SUBSTRING(@PivotColumnNames, 0, LEN(@PivotColumnNames)))  
  
	   INSERT INTO #OverriddenData  
	   EXEC(' SELECT * FROM   
			(  
			SELECT  
				ddcd.FacilityID
				,ddcd.FacilitySecurityId AS SecurityId  
				,attr.AttributeName       
				,ddcd.Value    
		  FROM [corp].[DealDataCorrectionDetail] ddcd    
				INNER JOIN [corp].[DealDataCorrection] ddc  ON ddc.dealdatacorrectionid = ddcd.dealdatacorrectionid    
				INNER JOIN #DealDataCorrectionAttribute attr ON attr.AttributeId = ddcd.AttributeId AND attr.IsActive = 1 
				INNER JOIN [corp].[DealOverrideParent] dop ON ddc.AsAtDate = dop.AsAtDate 
														  AND ddc.DealId = dop.DealID 
														  AND ddc.DealOverrideParentId = dop.DealOverrideParentId
				WHERE 
							ddc.AsAtDate = CONVERT(DATE,'''+ @DateString +''') 
						AND ddc.EntityTypeId = '''+ @EntityIdString +''' 
						AND ddc.DealId = '''+ @DealIDString +'''    
						AND dop.DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] 
														WHERE STATUS NOT IN (''Authorised'')) 
		   )pvt  
		   PIVOT  
		   (  
			MAX(pvt.Value)  
			FOR AttributeName IN  
			(  
		   '+ @PivotColumnNames +'  
			)  
		   ) pvtDataCorrection')  
  
  
	 -- UPDATING DOWNLODABLE TABLE WITH OVERRIDDEN TABLE DATA --  
	 --SELECT ROW_NUMBER()OVER (ORDER BY SeqNumber) RowId, AttributeName, DisplayName, DataType  
	 --INTO #Tbl_Attributes  
	 --FROM #DealDataCorrectionAttribute  
  
	 --DECLARE @LoopCount INT = 1, @LoopMax INT = (SELECT MAX(RowId) FROM #Tbl_Attributes)  
	 --DECLARE @CurrentAttribute VARCHAR(200)  
	 --WHILE(@LoopCount <= @LoopMax)  
	 --BEGIN  
	 -- SELECT @CurrentAttribute = AttributeName from #Tbl_Attributes WHERE RowId = @LoopCount  
	 -- EXEC('UPDATE Dwnlodtbl  
	 --    SET Dwnlodtbl.'+ @CurrentAttribute +' = OvrRdn.'+ @CurrentAttribute +'  
	 --    FROM #DownlodableDataTbl Dwnlodtbl   
	 --    INNER JOIN #OverriddenData OvrRdn ON Dwnlodtbl.SecurityId = OvrRdn.SecurityId')  
	 -- SELECT @LoopCount = @LoopCount + 1  
	 --END  
  
  
	 -- GETTING FIELD DISPLAY NAME FOR DOWNLOAD --  
	 DECLARE @fieldDsplyNames VARCHAR(MAX) = '';           
	 SELECT @fieldDsplyNames = @fieldDsplyNames + '[' + AttributeName + '] AS [' + DisplayName + '], '     
	  FROM #DealDataCorrectionAttribute    
	  ORDER BY SeqNumber  
	 SET @fieldDsplyNames = (SUBSTRING(@fieldDsplyNames, 0, LEN(@fieldDsplyNames)))  
  
	  IF(@pIsTemplate = 1)  
	  DELETE FROM #OverriddenData  
    
	  EXEC('SELECT FacilityId, SecurityId, '+ @fieldDsplyNames +' FROM #OverriddenData')   
	  --EXEC('SELECT SecurityId, '+ @fieldDsplyNames +' FROM #DownlodableDataTbl') 
  
END TRY  
 BEGIN CATCH                       
  DECLARE                       
  @errorMessage     NVARCHAR(MAX),                      
  @errorSeverity    INT,                      
  @errorNumber      INT,                      
  @errorLine        INT,                      
  @errorState       INT;                      
  SELECT                       
  @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                      
                      
  EXEC app.SaveErrorLog 2, 1, 'spGetSecurityDataForOverride', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                      
                        
  RAISERROR (@errorMessage, @errorSeverity, @errorState)  
 END CATCH  
END
GO
-- EXEC [corp].[spGetSecurityDataForOverride] '31-AUG-2022',1,'SAK'