USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spSaveDealIpdTestResult]') IS NOT NULL
	DROP PROCEDURE [cb].[spSaveDealIpdTestResult]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spSaveDealIpdTestResult]
/*
 * Author: Kapil Sharma
 * Date:	24.02.2022
 * Description:  This will save the Deal IPD TEST Result
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pTestTypeId				INT,
@pResult					VARCHAR(100),
@pUserName					VARCHAR(80) = ''
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		DECLARE
			@currentDate	DATETIME = GETDATE();

		IF NOT EXISTS(SELECT TOP 1 * FROM [cb].[DealIpdTestResult] WHERE DealIpdRunId = @pDealIpdRunId AND TestTypeId = @pTestTypeId)
		BEGIN
			INSERT INTO [cb].[DealIpdTestResult](TestTypeId, DealIpdRunId, Result, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			VALUES(@pTestTypeId, @pDealIpdRunId, @pResult, @pUserName, @currentDate, @pUserName, @currentDate)
		END
		ELSE
		BEGIN
			UPDATE [cb].[DealIpdTestResult] SET Result = @pResult, ModifiedBy = @pUserName, ModifiedDate = @currentDate
			WHERE DealIpdRunId = @pDealIpdRunId AND TestTypeId = @pTestTypeId
		END
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spSaveDealIpdTestResult', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO