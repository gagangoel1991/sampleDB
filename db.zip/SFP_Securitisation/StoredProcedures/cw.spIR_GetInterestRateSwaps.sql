USE SFP_Securitisation

IF OBJECT_ID('cw.spIR_GetInterestRateSwaps') IS NOT NULL
	DROP PROC cw.spIR_GetInterestRateSwaps
GO

/*
 * ---------------------------------------------------
 * Author: Arun 
 * Date:	09-Feb-2022
 * Description: This SP is Used to Get Interest Rate Swaps 
 * 
 * 
 * EXEC cw.spIR_GetInterestRateSwaps '2021-05-28','DEIMOS'
 * ---------------------------------------------------
*/
CREATE PROCEDURE cw.spIR_GetInterestRateSwaps 
	 @pAsAtDate DATETIME
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
AS
BEGIN
	BEGIN TRY
		
		DECLARE @dealIpdRunId        INT,
        @dealId              SMALLINT;
        

		SELECT 
		@dealIpdRunId = dir.DealIpdRunId
		, @dealId = dir.DealId
	FROM   
		cw.vwDealIpdDates dt
	JOIN
		cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId AND dir.DealId = dt.DealId
	WHERE	
		dir.InternalDealName = @pDealName
		AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)

		
		DECLARE @FixedSwap varchar(50) ='Fixed'
		, @SVRSwap varchar(50) ='Variable'
		, @TrackerSwap varchar(50) ='Tracker'
	
		IF( Object_id('tempdb..#Tbl') IS NOT NULL ) 
			DROP TABLE #Tbl

		SELECT ds.SwapName, ds.MaturityDate, dsWf.PayNotional, dsWf.ReceiveRate, ds.ReceiveMargin, dsWf.PayRate, dsWf.PayMarginDifferential
		INTO #Tbl
		FROM [cfgcb].[DealSwap] ds
		INNER JOIN [cb].[DealSwap_Wf] dsWf ON ds.DealSwapId  = dsWf.DealSwapId
		WHERE ds.DealID=dealId 
		AND ds.SwapName IN ( @FixedSwap, @SVRSwap, @TrackerSwap )
		AND dsWf.DealIpdrunID=@dealIpdRunId

		--Select * From #Tbl
		IF( Object_id('tempdb..#OutPut') IS NOT NULL ) 
			DROP TABLE #OutPut

		CREATE TABLE #OutPut ( LineItems varchar(max), Value nvarchar(max))
		
		INSERT INTO #OutPut
		SELECT 'Swap notional amount(s) (GBP) (Total)' AS Text, CONVERT(nvarchar , ( SELECT SUM(PayNotional) FROM #Tbl )) AS Value
		UNION ALL
		SELECT 'Swap notional maturity/ies' AS Text,  CONVERT(nvarchar, (SELECT Max(MaturityDate) FROM #Tbl ),  103) AS Value
		UNION ALL
		SELECT 'Swap notional amount(s) (GBP) (NWB Fixed)' AS Text, CONVERT(nvarchar , (SELECT PayNotional FROM #Tbl WHERE SwapName=@FixedSwap)) AS Value
		UNION ALL
		SELECT 'LLP receive rate (NWB Fixed)' AS Text,CONVERT(nvarchar , (SELECT ReceiveRate/100 FROM #Tbl WHERE SwapName=@FixedSwap)) AS Value	
		UNION ALL
		SELECT 'LLP receive margin (NWB Fixed)' AS Text, CONVERT(nvarchar ,(SELECT ReceiveMargin/10000 FROM #Tbl WHERE SwapName=@FixedSwap)) AS Value 		
		UNION ALL
		SELECT 'LLP pay rate (NWB Fixed)' AS Text, CONVERT(nvarchar ,(SELECT PayRate/100 FROM #Tbl WHERE SwapName=@FixedSwap)) AS Value
		UNION ALL
		SELECT 'LLP pay margin (NWB Fixed)' AS Text, CONVERT(nvarchar ,(SELECT PayMarginDifferential/100 FROM #Tbl WHERE SwapName=@FixedSwap))  AS Value
		UNION ALL
		SELECT 'Swap notional amount(s) (GBP) (NWB Tracker)' AS Text, CONVERT(nvarchar ,(SELECT PayNotional FROM #Tbl WHERE SwapName=@TrackerSwap)) AS Value	
		UNION ALL
		SELECT 'LLP receive rate (NWB Tracker)' AS Text, CONVERT(nvarchar , (SELECT ReceiveRate/100 FROM #Tbl WHERE SwapName=@TrackerSwap))  AS Value
		UNION ALL
		SELECT 'LLP receive margin (NWB Tracker)' AS Text, CONVERT(nvarchar ,(SELECT ReceiveMargin/10000 FROM #Tbl WHERE SwapName=@TrackerSwap)) AS Value
		UNION ALL
		SELECT 'LLP pay rate (NWB Tracker)' AS Text, CONVERT(nvarchar ,(SELECT PayRate/100 FROM #Tbl WHERE SwapName=@TrackerSwap)) AS Value
		UNION ALL
		SELECT 'LLP pay margin (NWB Tracker)' AS Text, CONVERT(nvarchar ,(SELECT PayMarginDifferential/100 FROM #Tbl WHERE SwapName=@TrackerSwap)) AS Value
		UNION ALL
		SELECT 'Swap notional amount(s) (GBP) (NWB Variable)' AS Text, CONVERT(nvarchar ,(SELECT PayNotional FROM #Tbl WHERE SwapName=@SVRSwap))  AS Value
		UNION ALL
		SELECT 'LLP receive rate (NWB Variable)' AS Text, CONVERT(nvarchar ,(SELECT ReceiveRate/100 FROM #Tbl WHERE SwapName=@SVRSwap))  AS Value
		UNION ALL
		SELECT 'LLP receive margin (NWB Variable)' AS Text,CONVERT(nvarchar , (SELECT ReceiveMargin/10000 FROM #Tbl WHERE SwapName=@SVRSwap)) AS Value
		UNION ALL
		SELECT 'LLP pay rate (NWB Variable)' AS Text, CONVERT(nvarchar ,(SELECT PayRate/100 FROM #Tbl WHERE SwapName=@SVRSwap))  AS Value
		UNION ALL
		SELECT 'LLP pay margin (NWB Variable)' AS Text, CONVERT(nvarchar ,(SELECT PayMarginDifferential/100 FROM #Tbl WHERE SwapName=@SVRSwap)) AS Value
		UNION ALL
		SELECT 'Collateral posting amount(s) (GBP)' AS Text, '0' AS Value

		SELECT LineItems, IsNull(Value, '0') AS Value FROM #OutPut
	END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetInterestRateSwaps', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  
END

Go



