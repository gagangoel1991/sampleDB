USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratificationSummaryDataPFDeal]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratificationSummaryDataPFDeal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-----------------------------------------------------------------------------------------------------------------------------
--Author         : Mukesh Sharma 
--Creation Date  : 06-March-2023
--Description    : This will return calculated data for strats by PF Deal, for more detail refer  SFTP-14489
--Execution      : EXEC [corp].[spStratificationSummaryDataPFDeal]  @pAsAtDate= '2023-01-31', @pDealId = 2,@pUserName=NULL

------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [corp].[spStratificationSummaryDataPFDeal]	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100)
		DECLARE @CountStratsType INT
		DECLARE @Initialize INT=1
		DECLARE @StratType VARCHAR(20)
		DECLARE @Flag INT
		DECLARE @DealinitialSize INT
		DECLARE @SumProjectStatus FLOAT
		DECLARE @SumTechnologyBiomass FLOAT
		DECLARE @SumTechnologyOther FLOAT
		DECLARE @DealIdCommonSP INT
		DECLARE @DealName VARCHAR(50)
		DECLARE @DealIdS INT
		DECLARE @DealSize FLOAT
		

	SET @DealIdCommonSP                                   = @pDealId
	SET @DealName                                         =(SELECT DealName from [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealId=@pDealId  AND IsActive='Y')
	SET @DealIdS                                          =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)
	SET @DealSize                                         =(SELECT  DealInitialSize FROM [cfg].[Deal] WHERE DealId=  @DealIdS and isactive=1)


		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats
		IF OBJECT_ID('tempdb..#StratsSummary') IS NOT NULL
		DROP TABLE #StratsSummary
		IF OBJECT_ID('tempdb..#FinalStratsSummary') IS NOT NULL
		DROP TABLE #FinalStratsSummary
		IF OBJECT_ID('tempdb..#TempStratsSummary') IS NOT NULL
		DROP TABLE #TempStratsSummary
	


		--- Creating final strats table

		CREATE TABLE #FinalStratsSummary

		( 
		 [Attributes] VARCHAR(100)
		,[Pool] VARCHAR(50)
		)

		INSERT INTO #FinalStratsSummary([Attributes])
		VALUES
		('facility_count')
		,('Pool notional pre co-share')
		,('Pool utilisation pre co-share')
		,('Pool notional post co-share')
		,('WA PD%')
		,('WA Life yrs')
		,('Assets in construction phase (as % of Initial Reference Portfolio)')
		,('Energy From Waste and Biomass (as % of Initial Reference Portfolio)')
		,('Other Power (as % of Initial Reference Portfolio)')
		,('Risk weight approach')
		,('Internal Loss Given Default Estimate')


        
		/*List of required Columns*/   
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','CommittedExposure','UtilisationGBP_SecDate','RONA','PDMidPoint','ProjectStatus','TTCLGD','Technology') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
		PRINT 'Strats Calculation Start : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId
			  ,CommittedExposure
			  ,UtilisationGBP_SecDate AS Utilisation
			  ,RONA
			  ,PDMidPoint
			  ,ProjectStatus
			  ,TTCLGD 
			  ,Technology
		INTO #Strats 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SET @SumProjectStatus=(SELECT SUM(RONA)FROM #Strats WHERE ProjectStatus='Construction')
		SET @SumTechnologyBiomass=(SELECT SUM(RONA)FROM #Strats WHERE Technology IN ('Energy from Waste','Biomass'))
		SET @SumTechnologyOther=(SELECT SUM(RONA)FROM #Strats WHERE Technology IN ('Other Power'))

				/*Deleting Data from Staging table after use*/
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		

		SELECT [facility_count] = CONVERT(VARCHAR,COUNT(FacilityId))	 
		,[Pool notional pre co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(CommittedExposure)))
		,[Pool utilisation pre co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(Utilisation)))
		,[Pool notional post co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(RONA)))
		,[WA PD%] =IIF(SUM(RONA) = 0,NULL, CONVERT(VARCHAR, CONVERT(DECIMAL(10,4),SUM(RONA * PDMidPoint)/SUM(RONA))))
		,[WA Life yrs]=CONVERT(VARCHAR,'0.00')
		,[Assets in construction phase (as % of Initial Reference Portfolio)]=IIF(@DealSize = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(10,4),@SumProjectStatus/ @DealSize)) )
		,[Energy From Waste and Biomass (as % of Initial Reference Portfolio)]=IIF(@DealSize = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(10,4),@SumTechnologyBiomass/ @DealSize)))
		,[Other Power (as % of Initial Reference Portfolio)]=IIF(@DealSize = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(10,4),@SumTechnologyOther/ @DealSize)) )
		,[Risk weight approach]=CONVERT(VARCHAR,'Slotting')
		,[Internal Loss Given Default Estimate] = IIF(SUM(RONA) = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(10,4),SUM(RONA * TTCLGD)/ SUM(RONA))) )
		INTO #StratsSummary
		FROM #Strats  

		SELECT [Attributes],[Value]  
		INTO #TempStratsSummary
		FROM #StratsSummary  
		UNPIVOT   
		(   
		[Value] FOR [Attributes] 
		IN (   
		 [facility_count] 
		,[Pool notional pre co-share]
		,[Pool utilisation pre co-share]
		,[Pool notional post co-share]
		,[WA PD%] 
		,[WA Life yrs] 
		,[Assets in construction phase (as % of Initial Reference Portfolio)]
		,[Energy From Waste and Biomass (as % of Initial Reference Portfolio)]	
		,[Other Power (as % of Initial Reference Portfolio)]
		,[Risk weight approach]
		,[Internal Loss Given Default Estimate]


			)  )
	    AS UnpivotTable  


		-- updating strats dynamically based on strats type

	

		UPDATE FSM

		SET [Pool]=SM.Value
		FROM #FinalStratsSummary AS FSM
		INNER JOIN #TempStratsSummary AS SM  on
		SM.[Attributes]=FSM.[Attributes]

		

		SELECT *
		FROM #FinalStratsSummary

		IF OBJECT_ID('tempdb..#StratsSummary') IS NOT NULL
		DROP TABLE #StratsSummary
		IF OBJECT_ID('tempdb..#TempStratsSummary') IS NOT NULL
		DROP TABLE #TempStratsSummary
		IF OBJECT_ID('tempdb..#FinalStratsSummary') IS NOT NULL
		DROP TABLE #FinalStratsSummary




		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    
	
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationSummaryDataPFDeal', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO


