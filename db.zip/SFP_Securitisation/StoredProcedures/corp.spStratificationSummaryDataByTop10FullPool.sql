USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratificationSummaryDataByTop10FullPool]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratificationSummaryDataByTop10FullPool]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


----------------------------------------------------------------------------------------------------------------------------------------------------
--Author         : Mukesh Sharma 
--Creation Date  : 06-March-2023
--Description    : This will return calculated data for strats by 10 Single Name Concentration List For Full Pool, for more detail refer  SFTP-14504
--Execution      : EXEC [corp].[spStratificationSummaryDataByTop10FullPool]  @pAsAtDate= '2023-01-31', @pDealId = 1,@pUserName=NULL

---------------------------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [corp].[spStratificationSummaryDataByTop10FullPool]	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100)
		DECLARE @TotalRONA FLOAT

		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats
		IF OBJECT_ID('tempdb..#FinalStratsSummary') IS NOT NULL
		DROP TABLE #FinalStratsSummary



		CREATE TABLE #FinalStratsSummary

		( 
		 [Reference Entity Group ID] VARCHAR(100)
		,[Exposure (£m)] NVARCHAR(50)
		,[MGS]  VARCHAR(50)
		,[% total] VARCHAR(50)
		,[SNC Cap] VARCHAR(50)
		)

		/*List of required Columns*/   
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','RONA','CIS','RiskParentCisCode','MasterGradingScore') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
		PRINT 'Strats Calculation Start : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId
			  , RONA
			  ,CASE WHEN MasterGradingScore ='N/A' THEN 0 ELSE  MasterGradingScore END AS MasterGradingScore
			  ,RiskParentCisCode
			  ,CIS
		INTO #Strats 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID AND RiskParentCisCode<>'N/A'
				/*Deleting Data from Staging table after use*/
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID


	    SET @TotalRONA= (SELECT SUM(RONA) FROM #Strats)
		INSERT INTO #FinalStratsSummary([Reference Entity Group ID],[Exposure (£m)],[MGS],[% total])

		SELECT TOP 10 
		RiskParentCisCode
		,CONVERT(DECIMAL(23,2),RONA/1000000) AS RONA
		,CONVERT(DECIMAL(23,0),MasterGradingScore) AS MasterGradingScore
		,CONVERT( DECIMAL(10,4),RONA/NULLIF(@TotalRONA,0.00))  AS [% total]
		FROM 
		(SELECT  SUM(RONA) AS RONA
		,MAX(MasterGradingScore) AS MasterGradingScore
		,RiskParentCisCode from #Strats GROUP BY RiskParentCisCode)  AS Temp 
		 ORDER BY  Temp.RONA DESC


		 UPDATE  #FinalStratsSummary
		 SET [SNC Cap]=(SELECT MAX([% total])  FROM #FinalStratsSummary)


		SELECT  
        [Reference Entity Group ID]	
		,[Exposure (£m)]
		,CASE WHEN [MGS]=0 THEN 'N/A' ELSE [MGS] END AS [MGS]
		,[% total]
		,[SNC Cap]
		FROM  #FinalStratsSummary





		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    
	
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationSummaryDataByTop10FullPool', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO


