USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spLoadCashLadderData') IS NOT NULL 
	DROP PROCEDURE [cw].[spLoadCashLadderData] ;
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spLoadCashLadderData]
/*-------------------------------------------------------
 * Author: Kapil Sharma
 * Date:	12.09.2020
 * Description:  This will TRANSNFORM & LOAD data from staging into CW table for Cash Ladder
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
(
	@pFeedRunLogId			INT,
	@pAsAtDate				DATETIME
)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		BEGIN TRANSACTION

		IF @pFeedRunLogId IS NOT NULL
		BEGIN
			--SELECT TOP 1 @feedRunId = FeedRunLogId FROM @tblFeedRunId;

			DECLARE 
				@collectionDate			DATETIME,
				@dealId					SMALLINT,
				@dealName				VARCHAR(100), 
				@caNumber1				VARCHAR(150),
				@dealReference			VARCHAR(100),
				@product				VARCHAR(100),
				@subProduct				VARCHAR(100),
				@counterparty			VARCHAR(200),
				@contextName			VARCHAR(500),
				@rate					DECIMAL(38,18),
				@maturityDate			VARCHAR(20),
				@currency				VARCHAR(3),
				@inflowAmount			DECIMAL(38,18),
				@outflowAmount			DECIMAL(38,18),
				@flowsubTotal			DECIMAL(38,18),
				@versionId				SMALLINT,
				@fileName				VARCHAR(500),
				@relatedToDate			INT,
				@createdDate			DATETIME,
				@createdBy				VARCHAR(40);

			--Set parameters
			SET @createdDate = GETDATE();
			SET @createdBy = 'System';

			DECLARE cursorCashLadderStg CURSOR
			FOR SELECT 
					[Deal],
					[Date],
					[CorrespondentAccountNumber],
					[DealReference],
					[Product],
					[SubProduct],
					[CounterParty],
					[ContextName],
					[Rate],
					[MaturityDate],
					[Currency],
					[InflowAmount],
					[OutflowAmount],
					[FlowSubTotal],
					[FileName],
					[RelatesToDate]
				FROM 
					[cw].[Syn_SfpStaging_tbl_CashLadder] stg
				JOIN
					[cw].[vw_ActiveDeal] deal ON deal.DealName = stg.Deal;

			OPEN cursorCashLadderStg;
			FETCH NEXT FROM cursorCashLadderStg INTO 
				@dealName, @collectionDate, @caNumber1, @dealReference, @product, @subProduct, @counterparty,
				@contextName, @rate, @maturityDate, @currency, @inflowAmount, @outflowAmount, @flowsubTotal,
				@fileName, @relatedToDate

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SELECT @dealId = cw.DealId FROM [cfgCW].CashWaterfallDeal cw
				JOIN cfg.Deal deal ON cw.DealId = deal.DealId
				WHERE deal.DealName = @dealName;
				SET @versionId = 1;

				IF EXISTS(SELECT TOP 1* FROM [CW].[CashLadder] WHERE DealId = @dealId AND CollectionDate = @collectionDate AND CorrespondentAccountNumber = @caNumber1
				AND DealReference = @dealReference AND Product = @product AND SubProduct = @subProduct)
				BEGIN
					SELECT @versionId = MAX(Version) FROM [CW].[CashLadder] 
					WHERE DealId = @dealId AND CollectionDate = @collectionDate AND CorrespondentAccountNumber = @caNumber1
					AND DealReference = @dealReference AND Product = @product AND SubProduct = @subProduct

					DELETE FROM [CW].[CashLadder]
					WHERE DealId = @dealId AND CollectionDate = @collectionDate AND CorrespondentAccountNumber = @caNumber1
					AND DealReference = @dealReference AND Product = @product AND SubProduct = @subProduct

					SET @versionId = ISNULL(@versionId, 0) + 1
				END

				--Inserting data into CW.CashLadder Table
				INSERT INTO CW.CashLadder (FeedRunLogId, DealId, CollectionDate, CorrespondentAccountNumber, DealReference,
				Product, SubProduct, CounterParty, ContextName, Rate, MaturityDate, Currency, InflowAmount, OutflowAmount,
				FlowSubTotal, Version, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES(@pFeedRunLogId, @dealId, @collectionDate, @caNumber1, @dealReference,
				@product, @subProduct, @counterparty, @contextName, @rate, @maturityDate, @currency, @inflowAmount, @outflowAmount,
				@flowsubTotal, @versionId, @createdBy, @createdDate, @createdBy, @createdDate);

				--Fetch record again from cursor
				FETCH NEXT FROM cursorCashLadderStg INTO 
					@dealName, @collectionDate, @caNumber1, @dealReference, @product, @subProduct, @counterparty,
					@contextName, @rate, @maturityDate, @currency, @inflowAmount, @outflowAmount, @flowsubTotal,
					@fileName, @relatedToDate
			END;
		END	
		CLOSE cursorCashLadderStg;
		DEALLOCATE cursorCashLadderStg;

		--Deleting extra record, if any
		DELETE cl
		FROM 
			[CW].[CashLadder] cl
		JOIN 
			[cw].[vw_ActiveDeal] deal ON deal.DealId = cl.DealId 
		LEFT JOIN 
			[cw].[Syn_SfpStaging_tbl_CashLadder] stg ON stg.Deal = deal.DealName
			AND stg.CorrespondentAccountNumber = cl.CorrespondentAccountNumber
			AND stg.DealReference = cl.DealReference
			AND stg.Product = cl.Product
			AND stg.SubProduct = cl.SubProduct
			AND stg.OutflowAmount = cl.OutflowAmount
			AND stg.InflowAmount = cl.InflowAmount
			AND stg.Date = @collectionDate
		WHERE 
			cl.CollectionDate = @collectionDate
			AND stg.deal IS NULL
		
		UPDATE [CW].[FeedRunLog] SET FileName = @fileName WHERE FeedRunLogId = @pFeedRunLogId;

		COMMIT TRANSACTION;  
			
	END TRY
	BEGIN CATCH

		IF @@trancount > 0 ROLLBACK TRANSACTION; 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC [CW].[spUpdateFeedRunLog]	@pFeedRunLogId, '', 'Failed', 0

		EXEC app.SaveErrorLog 1, 1, 'cw.LoadCashLadderData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO