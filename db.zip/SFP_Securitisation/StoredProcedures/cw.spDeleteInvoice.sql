USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spDeleteInvoice]') IS NOT NULL
	DROP PROCEDURE [cw].[spDeleteInvoice]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spDeleteInvoice]
/*
 * Author: Kapil Sharma
 * Date:	15.07.2020
 * Description:  This will delete the invoice data
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pInvoiceId					INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE @dealIpdDate DATE

		SELECT @dealIpdDate = DealIpdDate FROM [cw].[InvoiceData] WHERE InvoiceID = @pInvoiceId
	
		DELETE FROM [cw].[InvoiceData] WHERE InvoiceID = @pInvoiceId AND InvoiceStatusId = (SELECT [cw].[fnGetDealLookupValueId]('InvoiceStatus', 'Active'))
			
		-------********************Code for updating the Senior Expenses on invocie deletion***********************---------
		DECLARE
			@dealIpdRunId		INT,
			@workflowStepName	VARCHAR(100),
			@resultCode			INT

		SELECT @dealIpdRunId = dir.RunId, @workflowStepName = wfs.StepName FROM cw.DealIPD di
		JOIN cw.DealIpdRun dir ON dir.DealIpdID = di.DealIpdId
		JOIN cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
		WHERE di.IpdDate = @dealIpdDate

		IF @dealIpdRunId IS NOT NULL AND ISNULL(@dealIpdRunId, 0) > 0 AND @workflowStepName NOT IN ('Authorise', 'SendForAuthorisation')
		BEGIN
			EXEC [cw].[spReCalculateIpd] @dealIpdRunId, @pUserName, @resultCode OUTPUT

			EXEC [CW].[spUpdateIpdSummaryLineItemStatus]  @dealIpdRunId, 'Invoices', @pUserName
		END

			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spDeleteInvoice', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
