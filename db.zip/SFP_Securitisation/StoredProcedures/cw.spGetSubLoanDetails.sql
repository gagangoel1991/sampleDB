USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetSubloanDetails]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetSubloanDetails] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 27-04-2021 
--Description: GET sub loan details 
--(PRE and Post)
--[cw].[spGetSubloanDetails] 14,103,''
--==================================   
CREATE PROCEDURE [cw].[spGetSubloanDetails] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
	BEGIN TRY   
         
		SELECT 
			sl.SubLoanTypeId AS SubloanTypeId, CONVERT(VARCHAR(10),ipd.IpdDate,103) AS IPDDate,
			CASE dlv.[Value] WHEN 'FIXED' THEN 'N/A' ELSE CAST(spre.BaseRate AS VARCHAR(50)) END AS BaseRate ,
			spre.Coupon * 100 AS TotalRate,spre.DayCount AS InterestPeriod, spre.Principal_bf,spre.TotalIntDue AS InterestDue,
			spre.Interest_bf AS UnpaidInterestRate_bf,spre.IntOnBfInt AS InterestOnUnpaidInterest, 
			spost.TotalInterestPaid AS TotalInterestPaid,
			spost.InterestPaid AS InterestPaid,
			spost.Interest_cf AS UnpaidInterest_cf, 
			spost.TotalPrincipalPaid AS TotalPrincipalPaid, 
			spost.PrincipalPaid AS PrincipalPaid, 
			spost.Principal_cf AS Principal_cf
		FROM cfgcw.dealsubloan sl
		JOIN cw.subloan_prewf spre ON sl.DealsubloanId=spre.DealsubloanId
		JOIN cw.dealipdrun dir ON  dir.RunId=spre.DealipdRunid 
		JOIN cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN cfgCW.DealLookupValue dlv ON sl.RateTypeId=dlv.LookupValueId 
		LEFT JOIN  cw.subloan_postwf spost ON  spre.DealipdRunid=spost.DealipdRunid AND spre.DealsubloanId = spost.DealsubloanId
		WHERE 
			dir.RunId IN(SELECT RunId FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId,4))
		ORDER BY 
			ipd.IpdDate DESC 
    
	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spGetSubloanDetails', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH  
END
GO