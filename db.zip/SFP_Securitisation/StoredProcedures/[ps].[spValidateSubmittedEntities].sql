
USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spValidateSubmittedEntities]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [ps].[spValidateSubmittedEntities]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [ps].[spValidateSubmittedEntities]       
 @pPoolId INT,  
 @pUserName VARCHAR(50)        
AS
BEGIN
	DECLARE @AssetClassID INT
	DECLARE @AssetClassID_Retail INT = (SELECT AssetClassId FROM PS.AssetClass WHERE CODE = 'RT') 

	SELECT @AssetClassID =  psPool.AssetClassId
	FROM ps.[pool] psPool 
	WHERE psPool.PoolId = @pPoolId 

	IF(@AssetClassID = @AssetClassID_Retail)
	BEGIN
		EXEC [ps].[spValidateSubmittedLoans] @pPoolId, @pUserName
	END
	ELSE
	BEGIN
		EXEC [corp].[spValidateSubmittedFacilities] @pPoolId, @pUserName
	END
END
GO