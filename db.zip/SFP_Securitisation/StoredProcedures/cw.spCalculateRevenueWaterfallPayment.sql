USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculateRevenueWaterfallPayment') IS NOT NULL
	DROP PROCEDURE cw.spCalculateRevenueWaterfallPayment
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculateRevenueWaterfallPayment 
(
@pDealIpdRunId INT, 
@pUserName  VARCHAR(40)
/* 
exec [cw].[spCalculateRevenueWaterfallPayment] 2,'fm\shriyad' 

*/ 
) 
AS 
BEGIN 

	DECLARE 
		@Message			VARCHAR(4000)
    
	BEGIN TRY  

		DECLARE @dealId SMALLINT

		SELECT @dealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId

		IF( Object_id('tempdb..#temp') IS NOT NULL ) 
			DROP TABLE #temp 

		CREATE TABLE #temp 
		( 
			Id                       INT, 
			DealId                   INT, 
			CategoryName             VARCHAR(500), 
			DisplayName              VARCHAR(500), 
			SourceId                 INT, 
			SourceName               VARCHAR(200), 
			[Priority]				INT, 
			[Rank]					DECIMAL(9,3),
			WaterfallExpressionValue DECIMAL(38, 16), 
			SourceExpressionValue    DECIMAL(38, 16), 
			FormatType               VARCHAR(500), 
			Sortorder                DECIMAL(38, 16) 
		) 

		INSERT INTO #temp
		SELECT 
			wli.WaterfallLineItemId Id, 
			wc.DealId, 
			wc.DisplayName          CategoryName, 
			wli.DisplayName, 
			ws.WaterfallSourceId    AS SourceId, 
			ws.SourceName, 
			ws.Priority, 
			wli.Rank,
			wlia.TotalRequiredAmount	AS WaterfallExpressionValue,
			ev.Value					AS SourceExpressionValue,
			wli.FormatType, 
			wli.Sortorder  
		FROM   
			cfgcw.WaterfallLineItem wli 
		JOIN 
			cfgcw.WaterfallCategory wc ON wli.WaterfallCategoryId = wc.WaterfallCategoryId 
		JOIN 
			cw.vwDealIpdRun dir ON dir.DealId = wc.DealId 
		JOIN 
			cw.WaterfallLineItemAmount wlia ON wli.WaterfallLineItemId=wlia.WaterfallLineItemId AND dir.DealIpdRunId=wlia.DealIpdRunId
		JOIN 
			cfgcw.WaterfallSource ws ON dir.DealId = ws.DealId 
		LEFT JOIN 
			cw.ExpressionValue ev ON ws.ExpressionId = ev.ExpressionId 
			AND dir.DealIpdRunId=ev.DealIpdRunId
		WHERE  
			wc.InternalName = 'RevenuePriorityofPayments' 
			AND wli.isactive = 1 
			AND ws.DealId = wc.DealId 
			AND dir.DealIpdRunId=@pDealIpdRunId
			--Excluding the parent line items ids
			AND wli.WaterfallLineItemId NOT IN (SELECT ParentWaterfallLineItemId FROM cfgcw.WaterfallLineItem WHERE ParentWaterfallLineItemId IS NOT NULL)
		ORDER  BY 
			ws.Priority, 
			wli.Rank,
			wli.Sortorder
			
		IF( OBJECT_ID('tempdb..#TblCalculate') IS NOT NULL ) 
			DROP TABLE #TblCalculate 

		IF( OBJECT_ID('tempdb..#tempSourceTbl') IS NOT NULL ) 
			DROP TABLE #tempSourceTbl 

		IF( OBJECT_ID('tempdb..#calculatedSourceTbl') IS NOT NULL ) 
			DROP TABLE #calculatedSourceTbl 

		CREATE TABLE #TblCalculate 
		( 
			rowNum                INT, 
			DisplayName           VARCHAR(2000),-- tbdel 
			WaterfallLineItemId   INT, 
			TotaldueAmount        DECIMAL(38, 16), 
			SourceTotalAmount     DECIMAL(38, 16), 
			SourceId              INT, 
			SourceName            VARCHAR(200), 
			Priority              INT, 
			IsEligible            BIT, 
			SortOrder             DECIMAL(9, 3), 
			LineItemRank		  DECIMAL(9, 3), 
			IsRankAmtDistributed  BIT,		
			SourceCurrentAmount   DECIMAL(38, 16), 
			DueAmount             DECIMAL(38, 16), 
			AmountPaidFromSource  DECIMAL(38, 16), 
			SourceRemainingAmount DECIMAL(38, 16), 
			TotalPaidAmount       DECIMAL(38, 16), 
			RemainingDueAmount    DECIMAL(38, 16) 
		) 

		CREATE TABLE #tempSourceTbl 
		( 
			rowNum                INT, 
			DisplayName           VARCHAR(2000),-- tbdel 
			WaterfallLineItemId   INT, 
			TotaldueAmount        DECIMAL(38, 16), 
			SourceTotalAmount     DECIMAL(38, 16), 
			SourceId              INT, 
			SourceName            VARCHAR(200), 
			Priority              INT, 
			IsEligible            BIT, 
			SortOrder             DECIMAL(9, 3), 
			LineItemRank		  DECIMAL(9, 3), 
			IsRankAmtDistributed  BIT,	
			SourceCurrentAmount   DECIMAL(38, 16), 
			DueAmount             DECIMAL(38, 16), 
			AmountPaidFromSource  DECIMAL(38, 16), 
			SourceRemainingAmount DECIMAL(38, 16), 
			TotalPaidAmount       DECIMAL(38, 16), 
			RemainingDueAmount    DECIMAL(38, 16) 
		) 

		CREATE TABLE #calculatedSourceTbl 
		( 
			rowNum                INT, 
			DisplayName           VARCHAR(2000),-- tbdel
			WaterfallLineItemId   INT, 
			TotaldueAmount        DECIMAL(38, 16), 
			SourceTotalAmount     DECIMAL(38, 16), 
			SourceId              INT, 
			SourceName            VARCHAR(200), 
			Priority              INT, 
			IsEligible            BIT, 
			SortOrder             DECIMAL(9, 3), 
			LineItemRank		  DECIMAL(9, 3), 
			IsRankAmtDistributed  BIT,	
			SourceCurrentAmount   DECIMAL(38, 16), 
			DueAmount             DECIMAL(38, 16), 
			AmountPaidFromSource  DECIMAL(38, 16), 
			SourceRemainingAmount DECIMAL(38, 16), 
			TotalPaidAmount       DECIMAL(38, 16), 
			RemainingDueAmount    DECIMAL(38, 16) 
		) 

		INSERT INTO #TblCalculate 
		SELECT 
			ROW_NUMBER() 
			OVER( 
				ORDER BY SourceId ASC, t.SortOrder ASC, eligiblewaterfallsourceid DESC) rowNum,
			wli.DisplayName, 
			t.id                                                                        AS WaterfallLineItemId,
			WaterfallExpressionValue                                                    AS TotaldueAmount,
			SourceExpressionValue                                                       AS SourceTotalAmount,
			SourceId                                                                    AS SourceId,
			SourceName, 
			Priority, 
			CASE 
			WHEN EligibleWaterfallSourceId IS NULL THEN 0 
			ELSE 1 
			END                                                                         AS IsEligible,
			t.SortOrder, 
			wli.Rank,
			0																			AS IsRankAmtDistributed,
			0.0                                                                         AS SourceCurrentAmount,
			0.0                                                                         AS DueAmount,
			0.0                                                                         AS AmountPaidFromSource,
			0.0                                                                         AS SourceRemainingAmount,
			0.0                                                                         AS TotalPaidAmount,
			0.0                                                                         AS RemainingDueAmount
		FROM   
			#temp t 
		LEFT JOIN 
			cfgcw.WaterfallSourceEligibility wse ON t.SourceId = wse.EligibleWaterfallSourceId 
			AND t.id = wse.WaterfallLineItemId 
		LEFT JOIN 
			cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = t.Id 
		ORDER  BY 
			t.[Priority] ASC, 
			wli.Rank ASC,
			wli.SortOrder ASC, 
			EligibleWaterfallSourceId DESC 

		--select * from #TblCalculate order by Priority asc,SortOrder asc 
		DECLARE 
			@tempId								INT, 
			@previousId							INT, 
			@SourceRemainingAmount_Priority		DECIMAL(38, 16),
			@PreviousWaterfallSourcePriority	DECIMAL(9, 3), 
			@PreviousWaterfallSourceId			INT, 
			@WaterfallSourcePriority			DECIMAL(9, 3),
			@WaterfallSourceId					INT,
			@FirstWaterfallSourceId				INT

		DECLARE 
			@tempRowNum					INT,
			@prevRowNum					INT,
			@lineItemRank				DECIMAL(9,3),
			@sourceCurrentAmt			DECIMAL(38,16),
			@sameRankItemTotalDueAmt	DECIMAL(38,16),
			@sameRankTotalItem			INT

		DECLARE @tblSameRankLineItem TABLE (RowNum INT, WaterfallLineItemId INT, DueAmount DECIMAL(38,16), AmountPaidFromSource DECIMAL(38,16));
		
		SET @WaterfallSourcePriority = NULL;
		SET @WaterfallSourceId = NULL;
		SELECT TOP 1 @WaterfallSourcePriority = [Priority],
			@WaterfallSourceId = WaterfallSourceId 
		FROM cfgCW.WaterfallSource 
		WHERE  DealId = @dealId ORDER  BY priority 

		SET @FirstWaterfallSourceId = @WaterfallSourceId; 
		SET @PreviousWaterfallSourcePriority =@WaterfallSourcePriority; 
		SET @PreviousWaterfallSourceId =@WaterfallSourceId; 

		WHILE ( @WaterfallSourceId > 0 ) 
		BEGIN 
			DELETE FROM #tempSourceTbl 

			--putting rows for sourceid to pay from 
			INSERT INTO #tempSourceTbl 
			(
				rowNum, 
				DisplayName, -- tbdel 
				WaterfallLineItemId, 
				TotaldueAmount, 
				SourceTotalAmount, 
				SourceId, 
				SourceName, 
				Priority, 
				IsEligible, 
				SortOrder, 
				LineItemRank,
				SourceCurrentAmount, 
				DueAmount, 
				AmountPaidFromSource, 
				SourceRemainingAmount, 
				TotalPaidAmount, 
				RemainingDueAmount
			) 
			SELECT 
				rowNum, 
				DisplayName, -- tbdel 
				WaterfallLineItemId, 
				TotaldueAmount, 
				SourceTotalAmount, 
				SourceId, 
				SourceName, 
				Priority, 
				IsEligible, 
				SortOrder, 
				LineItemRank,
				SourceCurrentAmount, 
				DueAmount, 
				AmountPaidFromSource, 
				SourceRemainingAmount, 
				TotalPaidAmount, 
				RemainingDueAmount 
			FROM   #TblCalculate 
			WHERE  SourceId = @WaterfallSourceId
			ORDER BY LineItemRank; 

			UPDATE #tempSourceTbl 
			SET    SourceCurrentAmount = SourceTotalAmount 

			--updating dueAmount as TotalDueAmount for prioritySource 1 
			IF( @FirstWaterfallSourceId = @WaterfallSourceId ) 
			BEGIN 
				UPDATE #tempSourceTbl 
				SET    dueAmount = totalDueAMount 
			END 
			ELSE 
			BEGIN 
				--updating dueAmount as RemainingDueAmount for previous priority waterfall 
				UPDATE ts 
					SET    DueAmount = cs.RemainingDueAmount 
				FROM   
					#tempSourceTbl ts 
				JOIN 
					#calculatedSourceTbl cs ON ts.WaterfallLineItemId = cs.WaterfallLineItemId 
					AND cs.sourceid = @PreviousWaterfallSourceId 
			END 

			SET @tempRowNum	= NULL;
			SET @prevRowNum	= NULL;
			SET @lineItemRank = NULL;
			SET @sourceCurrentAmt = NULL;

			SELECT TOP 1 
				@tempRowNum = rowNum, 
				@tempId = WaterfallLineItemId,
				@lineItemRank = LineItemRank,
				@sourceCurrentAmt = SourceCurrentAmount
			FROM   #tempSourceTbl 
			ORDER  BY rowNum ASC
            
			WHILE( @tempRowNum > 0 ) 
			BEGIN 
				--print @tempId 
				IF EXISTS(SELECT TOP 1 * 
								FROM   #tempSourceTbl 
								WHERE  WaterfallLineItemId = @tempId AND IsEligible = 1) 
				BEGIN 
					--Check the same rank line items
					IF EXISTS(SELECT TOP 1 * FROM #tempSourceTbl WHERE LineItemRank = @lineItemRank AND rowNum > @tempRowNum AND IsEligible = 1 
						AND ISNULL(IsRankAmtDistributed, 0)<>1)
					AND ((SELECT SUM(DueAmount) FROM #tempSourceTbl WHERE LineItemRank = @lineItemRank AND rowNum >= @tempRowNum 
						AND IsEligible = 1 AND ISNULL(IsRankAmtDistributed, 0)<>1)> @sourceCurrentAmt)
					BEGIN
						PRINT 'inside the same rank'
						SET @sameRankTotalItem= NULL;
						SET @sameRankItemTotalDueAmt= NULL;
						SELECT @sameRankItemTotalDueAmt = SUM(DueAmount), @sameRankTotalItem = COUNT(WaterfallLineItemId) FROM #tempSourceTbl WHERE LineItemRank = @lineItemRank 
						AND rowNum >= @tempRowNum AND IsEligible = 1 AND ISNULL(IsRankAmtDistributed, 0)<>1;

						DELETE FROM @tblSameRankLineItem;
			
						INSERT INTO @tblSameRankLineItem(RowNum, WaterfallLineItemId, DueAmount)
						SELECT RowNum, WaterfallLineItemId, DueAmount FROM #tempSourceTbl 
						WHERE LineItemRank = @lineItemRank AND rowNum >= @tempRowNum AND IsEligible = 1 AND ISNULL(IsRankAmtDistributed, 0)<>1

						--Update the Amount paid from source based on percentage
						UPDATE @tblSameRankLineItem SET AmountPaidFromSource = (DueAmount/@sameRankItemTotalDueAmt)*@sourceCurrentAmt

						--Updating the amount into the source table with IsRankAmtDistributed flag set as 1 
						UPDATE st SET st.IsRankAmtDistributed = 1, st.AmountPaidFromSource = tmp.AmountPaidFromSource FROM #tempSourceTbl st
						JOIN @tblSameRankLineItem tmp ON st.rowNum = tmp.RowNum AND st.WaterfallLineItemId = tmp.WaterfallLineItemId

					END
					UPDATE #tempSourceTbl 
					SET    AmountPaidFromSource = CASE 
													WHEN ISNULL(IsRankAmtDistributed, 0)= 1 THEN AmountPaidFromSource
													WHEN ( SourceCurrentAmount - DueAmount ) >= 0 THEN DueAmount
													ELSE SourceCurrentAmount 
													END 
					WHERE  WaterfallLineItemId = @tempId 

					UPDATE #tempSourceTbl 
					SET    SourceRemainingAmount = CASE 
														WHEN ( SourceCurrentAmount - AmountPaidFromSource ) >= 0 THEN (
														SourceCurrentAmount - AmountPaidFromSource )
														ELSE SourceCurrentAmount 
													END 
					WHERE  WaterfallLineItemId = @tempId 
				END 
				ELSE 
				BEGIN 
					UPDATE #tempSourceTbl 
					SET    SourceRemainingAmount = SourceCurrentAmount 
					WHERE  WaterfallLineItemId = @tempId 
				END 

				UPDATE #tempSourceTbl 
				SET    TotalPaidAmount = AmountPaidFromSource 
										+ COALESCE((SELECT TotalPaidAmount FROM #calculatedSourceTbl WHERE
										WaterfallLineItemId = @tempId 
										AND sourceid=@PreviousWaterfallSourceId), 0) 
				WHERE  WaterfallLineItemId = @tempId 

				UPDATE #tempSourceTbl 
				SET    RemainingDueAmount = DueAmount - AmountPaidFromSource 
				WHERE  WaterfallLineItemId = @tempId 

				SET @previousId=@tempId; 

				--set the variable to null before assigning the next row variable
				SET @prevRowNum = @tempRowNum;
				SET @tempRowNum = NULL;
				SET @tempId = NULL;
				SET @lineItemRank = NULL;
				SET @sourceCurrentAmt = NULL;
				SELECT TOP 1 
					@tempRowNum = rowNum, 
					@tempId = WaterfallLineItemId,
					@lineItemRank = LineItemRank,
					@sourceCurrentAmt = SourceCurrentAmount
				FROM   #tempSourceTbl 
				WHERE  rowNum > @prevRowNum 
				ORDER  BY rowNum ASC

				---if next row exists 
				IF EXISTS(SELECT * 
						FROM   #tempSourceTbl 
						WHERE  WaterfallLineItemId = @tempId) 
				BEGIN 
					UPDATE #tempSourceTbl 
					SET    SourceCurrentAmount = (SELECT SourceRemainingAmount 
													FROM   #tempSourceTbl 
													WHERE  WaterfallLineItemId = @previousId)
					WHERE  WaterfallLineItemId = @tempId 
				END 
				ELSE 
				BEGIN 
					SELECT @SourceRemainingAmount_Priority = SourceRemainingAmount 
					FROM   #tempSourceTbl 
					WHERE  WaterfallLineItemId = @previousId 
				END 
			END 

			INSERT INTO #calculatedSourceTbl 
			SELECT * 
			FROM   #tempSourceTbl 

			SET @PreviousWaterfallSourcePriority =@WaterfallSourcePriority; 

			SET @PreviousWaterfallSourceId =@WaterfallSourceId; 

			SET @WaterfallSourcePriority =(SELECT TOP 1 priority 
											FROM   cfgCW.WaterfallSource 
											WHERE  DealId = @dealId 
													AND priority > @WaterfallSourcePriority 
											ORDER  BY priority); 

			SET @WaterfallSourceId =(SELECT WaterfallSourceId 
										FROM   cfgCW.WaterfallSource 
										WHERE  DealId = @dealId 
											AND priority = @WaterfallSourcePriority); 
		END 

		--select * from #calculatedSourceTbl 
		DELETE FROM cw.RevenueWaterfallPayment 
		WHERE  DealIpdRunId = @pDealIpdRunId; 

		---------EligibleRequiredAmount is for principal waterfall as it is using this coloumn 
		--select * from #calculatedSourceTbl
		INSERT INTO cw.RevenueWaterfallPayment(
			DealIpdRunId, 
			WaterfallLineItemId, 
			TotalDueAmount, 
			SourceTotalAmount, 
			SourceId, 
			SourceName, 
			IsEligible, 
			Priority, 
			SortOrder, 
			SourceCurrentAmount, 
			DueAmount, 
			EligibleRequiredAmount, 
			AmountPaidFromSource, 
			SourceRemainingAmount, 
			RemainingDueAmount, 
			TotalPaidAmount, 
			CreatedDate, 
			CreatedBy, 
			ModifiedDate, 
			ModifiedBy) 
		SELECT 
			@pDealIpdRunId, 
			WaterfallLineItemId, 
			TotalDueAmount, 
			SourceTotalAmount, 
			SourceId, 
			SourceName, 
			IsEligible, 
			Priority, 
			SortOrder, 
			SourceCurrentAmount, 
			DueAmount, 
			( IsEligible * DueAmount ) EligibleRequiredAmount, 
			AmountPaidFromSource, 
			SourceRemainingAmount, 
			RemainingDueAmount, 
			TotalPaidAmount, 
			Getdate(), 
			@pUserName, 
			Getdate(), 
			@pUserName 
		FROM   
			#calculatedSourceTbl 
		UNION
		SELECT 
			@pDealIpdRunId, 
			wli.WaterfallLineItemId, 
			0, 
			0, 
			ws.WaterfallSourceId, 
			ws.SourceName, 
			CASE 
			WHEN EligibleWaterfallSourceId IS NULL THEN 0 
			ELSE 1 
			END                                                                         AS IsEligible, 
			Priority, 
			wli.SortOrder, 
			0 SourceCurrentAmount, 
			0 DueAmount, 
			0 EligibleRequiredAmount, 
			0 AmountPaidFromSource, 
			0 SourceRemainingAmount, 
			0 RemainingDueAmount, 
			0 TotalPaidAmount, 
			Getdate(), 
			@pUserName, 
			Getdate(), 
			@pUserName 
		FROM   
			cfgcw.WaterfallLineItem wli 
		JOIN 
			cfgcw.WaterfallCategory wc ON wli.WaterfallCategoryId = wc.WaterfallCategoryId 
		JOIN 
			cfgcw.WaterfallSource ws ON wc.DealId = ws.DealId 
		LEFT JOIN 
			cfgcw.WaterfallSourceEligibility wse ON ws.WaterfallSourceId = wse.EligibleWaterfallSourceId 
			AND wli.WaterfallLineItemId = wse.WaterfallLineItemId 
		WHERE
			wc.InternalName = 'RevenuePriorityofPayments'
			AND wc.DealId = @dealId
			AND wli.WaterfallLineItemId IN (SELECT ParentWaterfallLineItemId FROM cfgcw.WaterfallLineItem WHERE ParentWaterfallLineItemId IS NOT NULL)
		----------------

		  DELETE FROM cw.RevenueWaterfallPaymentSummary 
		  WHERE  DealIpdRunId = @pDealIpdRunId; 

		  INSERT INTO cw.RevenueWaterfallPaymentSummary 
					  (WaterfallLineItemId, 
					   DealIpdRunId, 
					   RequiredAmount, 
					   AdjustedAmount, 
					   TotalRequiredAmount, 
					   TotalPaidAmount, 
					   RemainingDueAmount) 
		  SELECT wli.WaterfallLineItemId, 
				 rwp.DealIpdRunId, 
				 pwli.RequiredAmount, 
				 pwli.AdjustedAmount, 
				 pwli.TotalRequiredAmount, 
				 rwp.TotalPaidAmount, 
				 rwp.RemainingDueAmount 
		  FROM   cw.RevenueWaterfallPayment rwp 
				 JOIN cw.WaterfallLineItemAmount pwli ON pwli.WaterfallLineItemId = rwp.WaterfallLineItemId 
				 JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = pwli.DealIpdRunId 
											AND dir.DealIpdRunId = rwp.DealIpdRunId
				 JOIN cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = pwli.WaterfallLineItemId 
													 AND rwp.WaterfallLineItemId = wli.WaterfallLineItemId 
		  WHERE  
				 dir.DealIpdRunId = @pDealIpdRunId
				 AND rwp.SourceId = (SELECT TOP 1 WaterfallSourceId 
									 FROM   cfgcw.WaterfallSource ws 
									 WHERE  DealId = dir.DealId 
									 ORDER  BY Priority DESC) 
		  ORDER  BY wli.Sortorder 

		  
	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spCalculateRevenueWaterfallPayment', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
        
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  

		
	END CATCH  
END
GO