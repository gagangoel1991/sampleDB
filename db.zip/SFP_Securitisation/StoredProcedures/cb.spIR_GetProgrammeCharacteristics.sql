USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spIR_GetProgrammeCharacteristics]') IS NOT NULL
BEGIN 
	DROP PROCEDURE [cb].[spIR_GetProgrammeCharacteristics]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cb].[spIR_GetProgrammeCharacteristics]
/*
 * Author: Kapil Sharma
 * Date:	14.03.2022
 * Description:  This will return the programme level characteristics for deimos IR 
 * 
 * Example - 
 * [cb].[spIR_GetProgrammeCharacteristics] '2021-05-28', 'Deimos', 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pAsAtDate			DATE, 
@pDealName			VARCHAR(100),
@pUserName			VARCHAR(80) = NULL
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE 
			@dealIpdRunId               INT,
			@dealId                     SMALLINT,
			@mortgageDealId				INT,
			@calendarStartDt			DATE,
			@calendarEndDt				DATE,
			@collectionEndDt			DATE,
			@value						VARCHAR(100),
			@plcValue					DECIMAL(22, 2),
			@setoffValue				DECIMAL(36, 16),
			@principalOutstanding_GBP	DECIMAL(36, 16),
			@currentLtv					DECIMAL(36, 16),
			@indexedLtv					DECIMAL(36, 16),
			@currentLtvWeightedAvg		DECIMAL(36, 16),
			@indexedLtvWeightedAvg		DECIMAL(36, 16),
			@seasoningWeightedAvg		DECIMAL(36, 16),
			@loancount					INT,
			@spotRate					DECIMAL(16, 12),
			@gbpCurrencyId				INT,
			@prevIpdDate				DATE,
			@partitionId				INT

		SELECT   
		  @dealIpdRunId = dir.DealIpdRunId ,
		  @dealId = dir.DealId,
		  @mortgageDealId = deal.MortgageDealId,
		  @collectionEndDt = did.CollectionBusinessEnd,
		  @calendarStartDt = did.CollectionCalendarStart,
		  @calendarEndDt = did.CollectionCalendarEnd,
		  @prevIpdDate = did.PreviousIPD
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		JOIN cw.vwDealIPDDates did ON did.DealIpdId = di.DealIpdId
		WHERE   
			deal.DealName = @pDealName  
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
			AND dir.IpdSequence <> 0  

		SET @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		DECLARE @tblTestLineItemValue TABLE(Id INT IDENTITY(1,1), DisplayName VARCHAR(300), LineItemValue VARCHAR(100))

		SELECT @gbpCurrencyId  = CurrencyId FROM cfgcw.Currency WHERE Code = 'GBP'
		SELECT @principalOutstanding_GBP = SUM(ISNULL(PrincipalOutstanding_GBP, 0)) FROM cb.DealNote_Wf WHERE  DealIpdRunId = @dealIpdRunId
		SELECT @setoffValue  = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'SetOffPercentage_Moodys'), 0)
		
		SELECT @indexedLtv = dad.LoanBalance, @indexedLtvWeightedAvg = dad.WeightedAvgBalance FROM cw.DealAggregatedData dad
		JOIN cfgcw.DealAggregatedField daf ON dad.DealAggregatedFieldId = daf.DealAggregatedFieldId AND dad.DealId = daf.DealId
		WHERE CorrelatedDate = @collectionEndDt AND dad.DealId = @dealId
		AND daf.FieldName = 'IndexedLTV'
		SELECT @currentLtv = dad.LoanBalance, @loancount = dad.LoanCount, @currentLtvWeightedAvg = dad.WeightedAvgBalance FROM cw.DealAggregatedData dad
		JOIN cfgcw.DealAggregatedField daf ON dad.DealAggregatedFieldId = daf.DealAggregatedFieldId AND dad.DealId = daf.DealId
		WHERE CorrelatedDate = @collectionEndDt AND dad.DealId = @dealId
		AND daf.FieldName = 'CurrentLTV'

		SELECT @seasoningWeightedAvg = dad.WeightedAvgBalance FROM cw.DealAggregatedData dad
		JOIN cfgcw.DealAggregatedField daf ON dad.DealAggregatedFieldId = daf.DealAggregatedFieldId AND dad.DealId = daf.DealId
		WHERE CorrelatedDate = @collectionEndDt AND dad.DealId = @dealId
		AND daf.FieldName = 'Seasoning'

		--1. Programme currency
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Programme currency', 'Euro'

		--2. Programme size
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Programme size', '25000000000.00'

		--3. Covered bonds principal amount outstanding (GBP, non-GBP series converted at swap FX rate)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Covered bonds principal amount outstanding (GBP, non-GBP series converted at swap FX rate)', CAST(@principalOutstanding_GBP AS DECIMAL(18,2)) 

		--4. Covered bonds principal amount outstanding (GBP, non-GBP series converted at current spot rate)  
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 
			'Covered bonds principal amount outstanding (GBP, non-GBP series converted at current spot rate)',
			CAST(SUM(CASE WHEN cur.Code <> 'GBP' THEN PrincipalOutstanding_Ccy*[cw].[fnGetCurrencySwapRate](cur.CurrencyId, @gbpCurrencyId, @collectionEndDt) ELSE PrincipalOutstanding_GBP END ) AS DECIMAL(18,2)) 
		FROM cb.DealNote_Wf dnWf
		JOIN cfgcb.DealNote dn ON dn.DealNoteId = dnWf.DealNoteId
		JOIN cfgcw.Currency cur ON cur.CurrencyId = dn.CurrencyId
		WHERE  DealIpdRunId = @dealIpdRunId

		--5. Cover pool balance (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Cover pool balance (GBP)', CAST(@currentLtv AS DECIMAL(18,2)) 

		--6. GIC account balance (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'GIC account balance (GBP)', CAST(SUM(ISNULL(amount, 0)) AS DECIMAL(18,2)) 
		FROM
		(
			SELECT SUM(TotalCollection) AS amount FROM cb.SFPCollectionInterest WHERE CollectionDate>=@calendarStartDt AND CollectionDate<=@calendarEndDt
			UNION
			SELECT SUM(InterestAmount) AS amount FROM cb.SFPCollectionInterest WHERE DepositDate>=@calendarStartDt AND DepositDate<=@calendarEndDt
			UNION
			SELECT SUM(InterestAmount) AS amount FROM cb.ReserveInterest WHERE DepositDate>=@calendarStartDt AND DepositDate<=@calendarEndDt
			UNION
			SELECT requiredAmount AS amount FROM cb.ReserveInterest WHERE DepositDate = @prevIpdDate
			UNION
			SELECT (SUM(ISNULL(wla.AdjustedAmount, 0.0))) AS amount FROM cfgCW.WaterfallCategory wc
			INNER JOIN cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId
			LEFT JOIN cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId
					AND DealIpdRunId = @dealIpdRunId
			WHERE dealId = @dealId AND wc.InternalName = 'PreAvailableRevenueReceipts'
			AND wli.InternalName IN('PreAvailableRevenueReceipts_2.100', 'PreAvailableRevenueReceipts_2.200')
		) AS t1

		--7. Any additional collateral (please specify) 
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Any additional collateral (please specify)', CAST(ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'PLC_AnyAdditionalCollateral', 'PLC_AnyAdditionalCollateral_ccy'), 0) AS DECIMAL(20,2))

		--8.Any additional collateral (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Any additional collateral (GBP)', CAST(ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'PLC_AnyAdditionalCollateral', 'PLC_AnyAdditionalCollateral_GBP'), 0) AS DECIMAL(20,2))

		--9. Aggregate balance of off-set mortgages (GBP) 
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Aggregate balance of off-set mortgages (GBP)', CAST(ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'ProgrammeLevelCharacteristic', 'PLC_AggrBalanceOffsetMortgageGBP'), 0) AS DECIMAL(20,2))

		--10. Aggregate deposits attaching to the cover pool (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Aggregate deposits attaching to the cover pool (GBP)', CAST(CAST(@currentLtv*@setoffValue AS FLOAT)/100 AS DECIMAL(18,2))

		--11. Aggregate deposits attaching specifically to the off-set mortgages (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Aggregate deposits attaching specifically to the off-set mortgages (GBP)', CAST(ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'ProgrammeLevelCharacteristic', 'PLC_AggrDepositOffsetMortgageGBP'), 0) AS DECIMAL(18,2))

		--12. Nominal level of overcollateralisation (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Nominal level of overcollateralisation (GBP)', CAST((@currentLtv - @principalOutstanding_GBP) AS DECIMAL(18, 2))

		--13. Nominal level of overcollateralisation (%)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Nominal level of overcollateralisation (%)', CAST(CAST(((@currentLtv - @principalOutstanding_GBP)/@principalOutstanding_GBP) AS DECIMAL(12, 8)) AS VARCHAR(12)) 

		--14. Number of loans in cover pool
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Number of loans in cover pool', @loancount

		--15. Average loan balance (GBP)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Average loan balance (GBP)', CAST(@currentLtv/@loancount AS DECIMAL(18,2))

		--16. Weighted average non-indexed LTV (%)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Weighted average non-indexed LTV (%)', CAST(CAST(@currentLtvWeightedAvg AS DECIMAL(12, 8)) AS VARCHAR(12)) 

		--17. Weighted average indexed LTV (%)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Weighted average indexed LTV (%)', CAST(CAST(@indexedLtvWeightedAvg AS DECIMAL(12, 8)) AS VARCHAR(12)) 

		--18. Weighted average seasoning (months)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Weighted average seasoning (months)', CAST(dad.WeightedAvgBalance AS DECIMAL(26, 8)) FROM cw.DealAggregatedData dad
		JOIN cfgcw.DealAggregatedField daf ON dad.DealAggregatedFieldId = daf.DealAggregatedFieldId AND dad.DealId = daf.DealId
		WHERE CorrelatedDate = @collectionEndDt AND dad.DealId = @dealId
		AND daf.FieldName = 'Seasoning'
		
		--19. Weighted average remaining term (months)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Weighted average remaining term (months)', CAST(dad.WeightedAvgBalance AS DECIMAL(26, 8)) FROM cw.DealAggregatedData dad
		JOIN cfgcw.DealAggregatedField daf ON dad.DealAggregatedFieldId = daf.DealAggregatedFieldId AND dad.DealId = daf.DealId
		WHERE CorrelatedDate = @collectionEndDt AND dad.DealId = @dealId
		AND daf.FieldName = 'RemainingTerm'

		--20. Weighted average interest rate (%)
		SELECT @plcValue = CAST(dpd.TrueBalanceValue AS DECIMAL(14, 2)) FROM cw.dealProductData dpd
		JOIN cfgcw.ProductType pt ON pt.ProductTypeId = dpd.ProductTypeId
		WHERE DealId = @dealId  AND pt.[Name] = 'WAInterestRate' AND dpd.CorrelatedDate = @collectionEndDt

		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Weighted average interest rate (%)', CAST(CAST(ISNULL(CAST(@plcValue/100 AS float), 0) AS DECIMAL(14, 8)) AS VARCHAR(20)) 

		--21. Standard Variable Rate(s) (%) --TODO
		DECLARE
			@btlWeightedAvgInterestRate		DECIMAL(10,2),
			@ownWeightedAvgInterestRate		DECIMAL(10,2)

		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult') IS NOT NULL DROP TABLE #tmpMortgageLoanResult  
		SELECT * INTO #tmpMortgageLoanResult FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @collectionEndDt, @mortgageDealId;

		INSERT INTO #tmpMortgageLoanResult     
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @mortgageDealId 

		SELECT  
			@btlWeightedAvgInterestRate = SUM((CURRENT_INTEREST_RATE/100)*OUTSTANDNG_CAPITAL_BALANCE_AMT)/SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT)*100  
		FROM  
			#tmpMortgageLoanResult  
		WHERE  
			Product = 'SVR' AND PROPERTY_OCCUPANCY = 'BTL'

		SELECT  
			@ownWeightedAvgInterestRate = SUM((CURRENT_INTEREST_RATE/100)*OUTSTANDNG_CAPITAL_BALANCE_AMT)/SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT)*100  
		FROM  
			#tmpMortgageLoanResult  
		WHERE  
			Product = 'SVR' AND PROPERTY_OCCUPANCY = 'OWN'

		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Standard Variable Rate(s) (%)', CAST(@ownWeightedAvgInterestRate AS VARCHAR(12)) + '%; ' + CAST(@btlWeightedAvgInterestRate AS VARCHAR(12)) + '%'
		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult') IS NOT NULL DROP TABLE #tmpMortgageLoanResult 

		--22. Constant Pre-Payment Rate (%, current month)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Constant Pre-Payment Rate (%, current month)', CAST(CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'AnnualisedCPR'), 0) AS DECIMAL(12,8)) AS VARCHAR(12))

		--23. Constant Pre-Payment Rate (%, quarterly average)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Constant Pre-Payment Rate (%, quarterly average)', CAST(CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'QuarterlyCPR'), 0) AS DECIMAL(12,8)) AS VARCHAR(12)) 

		--24. Principal Payment Rate (%, current month)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Principal Payment Rate (%, current month)', CAST(CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'AnnualisedPPR'), 0) AS DECIMAL(12,8)) AS VARCHAR(12)) 

		--25. Principal Payment Rate (%, quarterly average)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Principal Payment Rate (%, quarterly average)', CAST(CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'QuarterlyPPR'), 0) AS DECIMAL(12,8)) AS VARCHAR(12)) 

		--26. Constant Default Rate (%, current month)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Constant Default Rate (%, current month)', '0.00'

		--27. Constant Default Rate (%, quarterly average)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Constant Default Rate (%, quarterly average)', '0.00'

		--28. Fitch Discontinuity Cap 
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Fitch Discontinuity Cap', ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'ProgrammeLevelCharacteristic', 'PLC_FitchDiscontinuityCap'), '0')

		--29. Moody's Timely Payment Indicator 
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Moody''s Timely Payment Indicator', ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'ProgrammeLevelCharacteristic', 'PLC_MoodysTimelyPaymentIndicator'), '')

		--30. Moody's Collateral Score (%) (incl. Risk /excl risk) 
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Moody''s Collateral Score (%) (incl. Risk /excl risk)', 
		CAST(CAST(ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'PLC_MoodysCollateralScore', 'PLC_MoodysCollateralScore_IncludingRisk'), 0) AS DECIMAL(10, 2)) AS VARCHAR(10)) + '% / ' +
		CAST(CAST(ISNULL([cb].[fnGetManualFieldValue](@dealIpdRunId, 'PLC_MoodysCollateralScore', 'PLC_MoodysCollateralScore_ExcludingRisk'), 0) AS DECIMAL(10, 2)) AS VARCHAR(10)) + '%'

		--31. Set off %(Monthly)
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue)
		SELECT 'Set off %(Monthly)', CAST(@setoffValue AS DECIMAL(18,8))
		SELECT DisplayName, LineItemValue [Value] FROM @tblTestLineItemValue ORDER BY Id


		

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetProgrammeCharacteristics', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END

GO