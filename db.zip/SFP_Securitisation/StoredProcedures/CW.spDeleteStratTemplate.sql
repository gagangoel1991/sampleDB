USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spDeleteStratTemplate]') IS NOT NULL
	DROP PROCEDURE [cw].[spDeleteStratTemplate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spDeleteStratTemplate]
/*
 * Author: Kapil Sharma
 * Date:	10.12.2020
 * Description:  This will delete the strat template
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pStratTemplateId			INT,
@pUserName					VARCHAR(80),
@pResult					INT OUTPUT --This will return the outcome the action. 1 - Success, -1 - Locked
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		IF EXISTS(SELECT TOP 1 * FROM cfgCW.IR_StratTemplate WHERE StratTemplateId = @pStratTemplateId AND IsLocked = 0)
		BEGIN
			BEGIN TRANSACTION
				DELETE 
					stm 
				FROM 
					cfgcw.IR_StratTemplateMap stm
				JOIN 
					cfgCW.IR_StratTemplate st ON st.StratTemplateId = stm.StratTemplateId
				WHERE 
					st.StratTemplateId = @pStratTemplateId
					AND st.IsLocked = 0

				--Deleting from master table
				DELETE FROM cfgcw.IR_StratTemplate 
				WHERE StratTemplateId = @pStratTemplateId AND IsLocked = 0
			COMMIT

			SET @pResult = 1
		END
		ELSE
			SET @pResult = -1 --Record is locked
			
	END TRY
	BEGIN CATCH
		IF @@trancount > 0 ROLLBACK TRANSACTION; 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spDeleteStratTemplate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
