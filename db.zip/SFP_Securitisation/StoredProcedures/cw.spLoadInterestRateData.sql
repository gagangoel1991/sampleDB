USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spLoadInterestRateData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadInterestRateData]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [CW].[spLoadInterestRateData]  
/*-------------------------------------------------------  
Author: Arun
Date: 12.09.2020  
Description:  This will TRANSNFORM & LOAD data from staging into CW table for InterestRate
			  [cw].[spLoadInterestRateData]  1, '05-Oct-20'
Change History  
--------------  
Author			Date			Description  
-------------------------------------------------------  
Kapil Sharma	10-Dec-2021		SFS-2008 - Added the calling for calculating the SONIA Compounding on a daily basis

*/  
(  
	 @pFeedRunLogId		INT,  
	 @pAsAtDate			DATETIME  
)  
AS  
BEGIN 
	Declare 
		@createdDate		DateTime = GETDATE(),
		@createdBy			varchar(100) = 'System',
		@Version			int=0,
		@Asset				varchar(25), 
		@Source				varchar(25), 
		@BaseDate			DateTime, 
		@CurrencyId			int,
		@RICCode			varchar(25), 
		@Tenor				varchar(25), 
		@Rate				Decimal(38,18)

	BEGIN TRY  
		IF @pFeedRunLogId IS NOT NULL  
		BEGIN  
			DECLARE cursorInterestRateStg CURSOR FAST_FORWARD
			FOR Select Asset, Source, BaseDate, C.CurrencyId,  RICCode, Tenor, Rate 
			FROM cw.Syn_SfpStaging_tbl_InterestRate I
			Left join cfgCW.Currency C on C.Code = I.Currency

			--===================================
			OPEN cursorInterestRateStg
			--===================================
			
			FETCH NEXT FROM cursorInterestRateStg INTO 
				@Asset, @Source, @BaseDate, @CurrencyId,  @RICCode, @Tenor, @Rate

				WHILE @@FETCH_STATUS = 0
				BEGIN
					SET @Version = 1;

					IF EXISTS(SELECT TOP 1* FROM CW.InterestRate WHERE Cast(BaseDate as date)= Cast(@BaseDate as date) and RICCode=@RICCode 
																	and Tenor=@Tenor and Source=@Source)
					BEGIN
						
						Select @Version = Max(Version) from cw.InterestRate where Cast(BaseDate as date)= Cast(@BaseDate as date) and RICCode=@RICCode 
																					and Tenor=@Tenor and Source=@Source
		
						DELETE FROM cw.InterestRate
						WHERE Cast(BaseDate as date)= Cast(@BaseDate as date) and RICCode=@RICCode 
										and Tenor=@Tenor and Source=@Source

						SET @Version = ISNULL(@Version, 0) + 1
					END

					--Inserting data into CW.InterestRate Table
					Insert into CW.InterestRate (FeedRunLogId, Asset, Source, BaseDate, CurrencyId, RICCode, Tenor, Rate
					,Version,  CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
					Select @pFeedRunLogId, @Asset, @Source, @BaseDate, @CurrencyId,  @RICCode, @Tenor, @Rate
					, @Version as Version, @createdBy, @createdDate, @createdBy, @createdDate

				--Fetch record again from cursor
				FETCH NEXT FROM cursorInterestRateStg INTO 
					@Asset, @Source, @BaseDate, @CurrencyId,  @RICCode, @Tenor, @Rate
					
				
				END
			CLOSE cursorInterestRateStg;
			DEALLOCATE cursorInterestRateStg;			
			
		END

		-----*************Now Calling the SONIA Compounding Procedure *******************************
		EXEC [cb].[spCalculateDailySoniaCompounding] @pAsAtDate

	END TRY
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  

		SELECT   
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  

		EXEC [CW].[spUpdateFeedRunLog] @pFeedRunLogId, '', 'Failed', 0  

		EXEC app.SaveErrorLog 1, 1, 'cw.spLoadInterestRateData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
		, 'System'  

		RAISERROR (@errorMessage,  
			 @errorSeverity,  
			 @errorState )  
	END CATCH  
END
GO

