USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spIR_GetDealRatingTriggers_Deimos]') IS NOT NULL
	DROP PROCEDURE [cb].[spIR_GetDealRatingTriggers_Deimos] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
--==================================    
--Author: Ravindra Singh  
--Date: 24-02-2022   
--Description: This will return the Deal rating triggers detail for IR for Deimos Deal
--[cb].[spIR_GetDealRatingTriggers_Deimos]  '2021-09-30', 'DEIMOS'  
--==================================     
CREATE PROCEDURE [cb].[spIR_GetDealRatingTriggers_Deimos]   
(  
 @pAsAtDate datetime,   
 @pDealName  varchar(200)  
)       
AS    
BEGIN    
    
BEGIN TRY     
 DECLARE   
  @dealIpdRunId  INT,  
        @dealId    SMALLINT,  
        @ipdDate   DATETIME,  
        @dealIpdRunVersion SMALLINT   
  
 SELECT   
  @dealIpdRunId = dir.DealIpdRunId  
  , @dealId = dir.DealId  
  , @ipdDate = ipddate  
  , @dealIpdRunVersion = DealIpdRunVersion  
 FROM     
  cw.vwDealIpdDates dt  
 JOIN  
  cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId   
  AND dir.DealId = dt.DealId  
 WHERE   
  dir.InternalDealName = @pDealName  
  AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)  
   
 SELECT   
  CASE 
  WHEN t.DisplayName ='Reserve Fund Establishment'
  THEN REPLACE(t.DisplayName, 'Reserve Fund Establishment', 'Reserve Fund Establishment *8')
  WHEN t.DisplayName ='Pre-Maturity Test'
  THEN REPLACE(t.DisplayName, 'Pre-Maturity Test', 'Pre-Maturity Test *9')
  WHEN t.DisplayName ='Title Deeds Segregation'
  THEN REPLACE(t.DisplayName, 'Title Deeds Segregation', 'Title Deeds *11')
  WHEN t.DisplayName ='Depositor Set-off Determination Date'
  THEN REPLACE(t.DisplayName, 'Depositor Set-off Determination Date', 'Depositor Set-off Determination Date *10')
  ELSE t.DisplayName
  END AS [Event],  
  t.TriggerSummary AS [Summary of Event],  
  cw.fnIR_GetTriggerThresholdRating(tr.DealIpdTriggerResultId) AS [Trigger (S&P, Moody's, Fitch, DBRS; Short-term, Long-term)],
  CASE
  WHEN tr.IsBreached = 1 AND t.InternalName<>'Pre-MaturityTest'
  THEN 'YES'    
  WHEN t.InternalName='Pre-MaturityTest'
  THEN 'N/A'
  ELSE 'NO' END AS [Trigger Breached (Yes/No)],   
  t.Consequences AS [Consequence of a Trigger Breach]  
  --'' AS [Action Taken]  
 FROM   
  cw.DealIpdTriggerResult tr   
 JOIN   
  cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId  
 JOIN   
  cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId  
 JOIN   
  cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId  
 JOIN   
  cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId  
 WHERE    
  tr.DealIpdRunId=@dealIpdRunId AND tm.DealId=@dealId   
  AND tt.InternalName = 'RatingTrigger'  

  ORDER BY
   CASE
			 WHEN t.InternalName='AccountBankDowngrade' THEN 1
			 WHEN t.InternalName='SwapCollateralAccountBankDowngrade' THEN 2
			 WHEN t.InternalName='ReserveFundEstablishment' THEN 3	
			 WHEN t.InternalName='Pre-MaturityTest' THEN 4
			 WHEN t.InternalName='CashManagerRelevantEvent' THEN 5
			 WHEN t.InternalName='Back-UpCashManagementAppointment' THEN 6	
			 WHEN t.InternalName='BackupCashManager-Replacement' THEN 7
			 WHEN t.InternalName='AssetMonitorReview' THEN 8
			 WHEN t.InternalName='DepositorSet-offDeterminationDate' THEN 9
			 WHEN t.InternalName='Back-upServicerEvent' THEN 10
			 WHEN t.InternalName='ServicerRatingsEvent(Replacement)' THEN 11
			 WHEN t.InternalName='TitleDeedsSegregation' THEN 12
			 WHEN t.InternalName='LegalAssignmentofLoans' THEN 13
			 				
			END ASC
  
END TRY    
BEGIN CATCH    
 DECLARE     
  @errorMessage     NVARCHAR(MAX),    
  @errorSeverity    INT,    
  @errorNumber      INT,    
  @errorLine        INT,    
  @errorState       INT;    
    
 SELECT     
 @errorMessage = ERROR_MESSAGE()
 ,@errorSeverity = ERROR_SEVERITY()
 ,@errorNumber = ERROR_NUMBER()
 ,@errorLine = ERROR_LINE()
 ,@errorState = ERROR_STATE()    
    
 EXEC app.SaveErrorLog 1, 1, 'cw.spGetRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, 'System'    
      
 RAISERROR (@errorMessage,    
    @errorSeverity,    
             @errorState )    
END CATCH    
END  