USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRun12MonthsForwardOCTTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRun12MonthsForwardOCTTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRun12MonthsForwardOCTTest] 
    @pDealIpdRunId INT,
	@pUserName  VARCHAR(80) ='System'      
AS  
--   
/*
 * Author: Suresh Pandey
 * Date:	08-02-2022
 * Description:  This will run the  PeMaturity test and insert data for test.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Exec [cb].[spRun12MonthsForwardOCTTest] 1035,'suresh'
 * 
 * 	select * from cb.DealIpdTestResult where DealIpdRunId=1035 and testtypeid=10
 * select * from cb.TestLineItemValue  where DealIpdRunId=1035 and TestLineItemID in(select TestLineItemID from cfgcb.TestLineItem where testtypeid=10)
 * 
*/
BEGIN  
  
BEGIN TRY  
  
	DECLARE @result						VARCHAR(10),
			@gbpEquivalentOfBonds				DECIMAL(38, 16),
			@threshold							DECIMAL(38, 16),
			@12MonthForwardPool					DECIMAL(38, 16),
			@12MonthForwardOvercollateralisation	DECIMAL(38, 16),
			@ipdDate							DATETIME,
			@testTypeID							INT;
			 

			 
	SELECT @ipdDate = IpdDate FROM  cw.vwDealIpdRun 
		WHERE  DealIpdRunId = @pDealIpdRunId; 
			
	SELECT @testTypeID=TestTypeID  FROM cfgcb.TestType WHERE InternalName='12MonthsForwardOCTTest'
	
	SELECT @gbpEquivalentOfBonds = ISNULL(SUM(PrincipalOutstanding_GBP),0) 
		FROM [cb].[DealNote_Wf] dnwf
		JOIN [cfgcb].[DealNote] dn ON dn.dealnoteid =dnwf.DealNoteId AND DealIpdRunId=@pDealIpdRunId

	SELECT @threshold = CAST([Value] AS DECIMAL(10,3)) FROM [CW].[vw_DealLookup] WHERE TypeCode = 'Deimos_Test_Config' AND [Name] = 'OCT_Threshold'

	SELECT @12MonthForwardPool= ForwardPool FROM [cb].[ForwardPoolData]  WHERE DealIpdRunId=@pDealIpdRunId AND Months=12

	SET @12MonthForwardOvercollateralisation= (ISNULL(@12MonthForwardPool,0)/CAST(@gbpEquivalentOfBonds AS FLOAT))*100
	
	SET @result=IIF(@12MonthForwardOvercollateralisation<@threshold,'FAIL','PASS')

	 
	IF ( Object_id('tempdb..#TestLineItemValue') IS NOT NULL ) 
		DROP TABLE #TestLineItemValue 

	CREATE TABLE #TestLineItemValue(
		TestLineItemID INT,
		InternalName VARCHAR(200),
		DealIpdRunId INT,
		[Value] VARCHAR(500))

	INSERT INTO #TestLineItemValue(TestLineItemID,InternalName,DealIpdRunId,[Value])
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@12MonthForwardPool AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='OCT_12MonthForwardPool'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(CAST(@12MonthForwardOvercollateralisation AS DECIMAL(18,4)) AS VARCHAR) + '%' FROM cfgcb.TestLineItem WHERE InternalName='OCT_12MonthForwardOvercollateralisation'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@result FROM cfgcb.TestLineItem WHERE InternalName='OCT12Months_Result'

	IF NOT EXISTS(SELECT 1 FROM cb.TestLineItemValue tv
							JOIN cfgcb.TestLineItem tl  ON tl.TestLineItemID=tv.TestLineItemID
							JOIN cfgcb.TestType tt ON tt.TestTypeId=tl.TestTypeId
							WHERE DealIpdRunId =@pDealIpdRunId AND tt.TestTypeId=@testTypeID)
	BEGIN
		INSERT INTO cb.TestLineItemValue(TestLineItemID,DealIpdRunId,[Value],IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,DealIpdRunId,CAST(ISNULL([Value],0) AS VARCHAR),1,@pUserName,GETDATE(),@pUserName,GETDATE() FROM #TestLineItemValue 
		
	END
	ELSE
	BEGIN	
		
		UPDATE tv SET tv.[Value]=CAST(ISNULL(temp.[Value],0) AS VARCHAR),tv.ModifiedBy=@pUserName, tv.ModifiedDate=GETDATE() 
			FROM cb.TestLineItemValue tv
			JOIN #TestLineItemValue temp
				ON temp.TestLineItemID=tv.TestLineItemID AND temp.DealIpdRunId=tv.DealIpdRunId
		WHERE temp.DealIpdRunId=@pDealIpdRunId

	END

	EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeID, @result, @pUserName

END TRY 
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cb.spRun12MonthsForwardOCTTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END

GO