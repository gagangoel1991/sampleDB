USE [SFP_Securitisation]
GO
IF OBJECT_ID('[CW].[spAdhocDataLoad]') IS NOT NULL
	DROP PROCEDURE [CW].[spAdhocDataLoad]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CW].[spAdhocDataLoad]
/*-----------------------------------------------------
 * Author: Kapil Sharma
 * Date:	18.05.2022
 * Description:  This will run the ad-hoc data load from UI
 * 
 * [CW].[spAdhocDataLoad] 'Monthly Deal Aggregation', '2022-03-31', 'System'
 * 
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
(
	@pLoadType			VARCHAR(200),
	@pLoadDate			DATE,
	@userName           VARCHAR(40)
)
AS
BEGIN
	BEGIN TRY
		
		IF @pLoadType IN ('Monthly Deal Aggregation', 'Monthly Product Data Load') 
		BEGIN
			DECLARE
				@nextMonthDt		DATE = DATEADD(MM, 1, @pLoadDate)

			IF @pLoadType = 'Monthly Deal Aggregation'
			BEGIN
				DECLARE
					@partitionId		INT,
					@dealRegionCode		VARCHAR(40),
					@mortgageDealId		INT

				DECLARE cursorCWDeal CURSOR FOR     
				SELECT DISTINCT MortgageDealId, DealRegionCode FROM [cw].[vw_ActiveDeal] WHERE DealStatusDisplayName = 'Active'
  
				OPEN cursorCWDeal    
  
				FETCH NEXT FROM cursorCWDeal INTO @mortgageDealId, @dealRegionCode
				WHILE @@FETCH_STATUS = 0    
				BEGIN 
					SELECT 
						TOP 1 @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), AsAtDate, 112)) 
					FROM 
						sfp.syn_SfpModel_vw_Calendar_v1
					WHERE 
						Month = Month(@pLoadDate)  AND year = Year(@pLoadDate)  
						AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
					ORDER BY	
						AsAtDate DESC 

					DELETE FROM [sfp].[MortgageFieldResultSchema] WHERE PartitionId = @partitionId AND MortgageDealKey = @mortgageDealId

					FETCH NEXT FROM cursorCWDeal INTO @mortgageDealId, @dealRegionCode
				END
				CLOSE cursorCWDeal;  
				DEALLOCATE cursorCWDeal;

				EXEC [CW].[spTransformMonthlyDealAggregatedData] 1, @nextMonthDt, 0
			END
			ELSE IF @pLoadType = 'Monthly Product Data Load'
			BEGIN
				EXEC [CW].[spLoadDealProductnSwitchData] 1, @nextMonthDt
				EXEC [cb].[spProcessDealProductData] 1, @nextMonthDt
			END
		END

	END TRY
	BEGIN CATCH
		IF CURSOR_STATUS('global','cursorCWDeal') >= 0 
		BEGIN
			CLOSE cursorCWDeal;
			DEALLOCATE cursorCWDeal;	
		END
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cw.spAdhocDataLoad', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO