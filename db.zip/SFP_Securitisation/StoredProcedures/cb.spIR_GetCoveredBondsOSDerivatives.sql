USE SFP_Securitisation
GO

IF OBJECT_ID('cb.spIR_GetCoveredBondsOSDerivatives') IS NOT NULL
	DROP PROC cb.spIR_GetCoveredBondsOSDerivatives
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-----------------------------------------------------
--Author: Arun 
--Date:	09-Feb-2022
--Description: This SP is Used toGet  Covered Bonds Outstanding and Associated Derivatives

--EXEC cb.spIR_GetCoveredBondsOSDerivatives '2021-04-30','DEIMOS'
--go
--EXEC cb.spIR_GetCoveredBondsOSDerivatives '2022-02-28','DEIMOS'

-----------------------------------------------------


CREATE PROCEDURE cb.spIR_GetCoveredBondsOSDerivatives
(
	 @pAsAtDate DATETIME
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
)

AS

BEGIN
	BEGIN TRY  
	
		DECLARE @dealIpdRunId        INT,
		@previousDealIpdRunId		 INT,
		@previousIpdDate			 Date,
        @dealId						SMALLINT,
	    @ipdDate			DATETIME,
        @dealIpdRunVersion	SMALLINT,
		@daysAccrued		INT,
		@craNames			VARCHAR(200),
		@ratingTypeId		TINYINT,
		@rateDate			DATE,
		@colBusinessEndDate	DATE
        

		SELECT 
			@dealIpdRunId = dir.DealIpdRunId
			, @previousIpdDate  = dt.PreviousIPD  
			, @dealId = dir.DealId
			, @ipdDate = dt.IPD
		FROM   
			cw.vwDealIpdDates dt
		JOIN
			cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId AND dir.DealId = dt.DealId
		WHERE	
			dir.InternalDealName = @pDealName
			AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)

		

		SELECT @ratingTypeId = RatingTypeId FROM cfgCW.RatingType WHERE Name ='Bond Rating'

		--Fetch all the applicable CRAs for Note
		SELECT @craNames = COALESCE(@craNames + ' / ', '') + cra.Name  FROM cfgcw.CreditRatingAgency cra 
		JOIN cfgCW.DealSubjectCRAMap craMap ON craMap.CRAId = cra.CRAId 
		WHERE 
			craMap.DealId = @dealId 
			AND craMap.DealSubjectTypeId = 1 --Note

		IF( Object_id('tempdb..#temp') IS NOT NULL ) 
		DROP TABLE #temp 

		IF( Object_id('tempdb..#temp2') IS NOT NULL ) 
			DROP TABLE #temp2 

		IF( Object_id('tempdb..#temp3') IS NOT NULL ) 
			DROP TABLE #temp3

		IF( Object_id('tempdb..#tempLineOrder') IS NOT NULL ) 
			DROP TABLE #tempLineOrder 

		CREATE TABLE #tempLineOrder (InternalName varchar(200), DisplayName varchar(500), sortOrder decimal(9,3))

		SELECT ISNULL('Series ' + CAST(dn.Series AS VARCHAR(200)), 'N/A')      																AS [Series]
		, ISNULL(CAST(CONVERT(DATE, dn.IssuanceDate)	 AS VARCHAR(200)), 'N/A')												AS [IssuanceDate] -- as [Issue date]
		, ISNULL(CAST([cw].[fnGetNoteISINRating](dn.DealId, dn.ISIN, @ratingTypeId, NULL) AS VARCHAR(200)), 'N/A')  			AS [OriginalRatings]
		, ISNULL(CAST([cw].[fnGetNoteISINRating](dn.DealId, dn.ISIN, @ratingTypeId, @pAsAtDate) AS VARCHAR(200)), 'N/A')		AS [CurrentRatings]
		, ISNULL(CAST(C.Name	 AS VARCHAR(200)), 'N/A')  																		AS [Denomination]  
		, ISNULL(CAST(dn.IssuanceAmount		 AS VARCHAR(200)), 'N/A')  															AS [IssuanceAmount]
		, ISNULL(CAST(dnWf.PrincipalOutstanding_Ccy	 AS VARCHAR(200)), 'N/A')  													AS [AmountOutstanding]
		, ISNULL(CAST(dn.FXRateAtIssuance	 AS VARCHAR(200)), 'N/A')  															AS [FXswapRate] 
		, ISNULL(CAST(vdt.Value AS VARCHAR(200)), 'N/A')  																		AS [MaturityType] 
		, ISNULL(CAST(CONVERT(DATE, dn.MaturityDate)	 AS VARCHAR(200)), 'N/A')												AS [MaturityDate] 
		, ISNULL(CAST(CONVERT(DATE, LegalFinalMaturityDate)	AS VARCHAR(200)), 'N/A')  											AS [LegalFinalMaturityDate] 
		, ISNULL(CAST(dn.ISIN	 AS VARCHAR(200)), 'N/A')  																		AS [ISIN]
		, ISNULL(CAST(dn.StockExchange		 AS VARCHAR(200)), 'N/A')  															AS [StockExchange] 
		, ISNULL(CAST(vdf.Name		 AS VARCHAR(200)), 'N/A')  																	AS [CouponPaymentFrequency]
		, ISNULL(CAST(CONVERT(DATE, dnWf.CouponPaymentEndPeriod)	AS VARCHAR(200)), 'N/A')									AS [CouponPaymentDate]
		, ISNULL(CAST(CASE WHEN vdl.Value= 'FIXED' THEN 
				CAST(dn.CouponForFixed/100  AS varchar)
				ELSE CASE WHEN CONVERT(DATE, @ipdDate) = CONVERT(DATE, dnWf.CouponPaymentEndPeriod) THEN CAST(CAST(dnWf.Coupon * 100 AS Decimal(18,4)) AS varchar) + '%' ELSE  vdb.DisplayText + ' + ' + Cast( Cast(dn.Margin/100 AS decimal(18,2)) AS varchar) + '%' END END AS VARCHAR(200)), 'N/A') AS [Coupon] 
		, ISNULL(CAST( vdb.DisplayText + ' + ' +  Cast( Cast(dn.MarginUnderExtendedMaturity/100 AS decimal(18,2)) AS varchar ) + '%' AS VARCHAR(200))  , 'N/A')	AS [InterestRateExtendedMaturity] 
		, ISNULL(CAST(CASE WHEN dn.IsSwapLinked =0 THEN 'N/A' ELSE dcp.CounterpartyName END  AS VARCHAR(200)), 'N/A')			AS [SwapCounterParties]
		, ISNULL(CAST(CASE WHEN dn.IsSwapLinked =0 THEN 'N/A' ELSE C.Name END AS VARCHAR(200)), 'N/A')							AS [SwapNotionalDenomination]
		, ISNULL(CAST(ns.ReceiveNotional AS VARCHAR(200)), 'N/A')																AS [SwapNotionalAmount]
		, ISNULL(CAST(CONVERT(DATE, ns.MaturityDate)	AS VARCHAR(200)), 'N/A')												AS [SwapNotionalMaturity]
		, ISNULL(CAST(ns.PayMargin/10000	AS VARCHAR(200)), 'N/A')																	AS [LLPPayMargin]
		, ISNULL(CAST(nsWf.PayRate	 AS VARCHAR(200)), 'N/A')																	AS [LLPPayRate]
		, ISNULL(CAST(ns.ReceiveMargin AS VARCHAR(200)), 'N/A')																	AS [LLPReceiveMargin]
		, ISNULL(CAST(ns.ReceiveRateForFixed/100 AS VARCHAR(200)), 'N/A')															AS [LLPReceiveRate]
		, ISNULL(CAST(CASE 
						WHEN dn.Series<>11 THEN '0'
						WHEN dn.IsSwapLinked = 1  AND dn.Series=11 THEN 'Swap Value' 
						ELSE 'N/A' END AS VARCHAR(200)), 'N/A')					AS [CollateralPostingAmount] 
		
		INTO #temp 
		FROM [cfgcb].[DealNote] dn
		INNER JOIN [cb].[DealNote_Wf] dnWf ON dn.DealNoteId = dnWf.DealNoteId
		LEFT JOIN [cfgCW].[Currency] C ON C.CurrencyId= dn.CurrencyId
		LEFT JOIN [cfgcb].[NoteSwap] ns ON ns.DealNoteId = dn.DealNoteId AND  @pAsAtDate>=ns.ValidFrom AND  @pAsAtDate<=ns.ValidTo 
		LEFT JOIN [Cb].[NoteSwap_Wf] nsWf ON ns.NoteSwapId = nsWf.NoteSwapId AND dnWf.DealIpdRunId = nsWf.DealIpdRunId 
		LEFT JOIN [CW].[vw_ActiveDealCounterparty] dcp ON dcp.DealId=dn.DealId AND dcp.DealCounterpartyId = ns.DealCounterPartyId
		LEFT JOIN [CW].[vw_DealLookup] vdl ON vdl.TypeCode='RateType' AND vdl.LookupValueId= dn.RateTypeId
		LEFT JOIN [CW].[vw_DealLookup] vdb ON vdb.TypeCode='Benchmark' AND vdb.LookupValueId= dn.BenchmarkIdUnderExtendedMaturity
		LEFT JOIN [CW].[vw_DealLookup] vdf ON vdf.TypeCode='IpdFrequency' AND vdf.LookupValueId= dn.CouponPaymentFrequencyId
		LEFT JOIN [CW].[vw_DealLookup] vdt ON vdt.TypeCode='Bullet' AND vdt.LookupValueId= dn.BulletId
		WHERE dn.DealId=@dealId
		AND dnWf.DealIpdRunId=@dealIpdRunId

		
		SELECT [Series], NoteName, Valuee 
		INTO   #temp2 
		FROM   #temp 
				UNPIVOT ( Valuee 
                    FOR NoteName IN ([IssuanceDate], [Denomination], [OriginalRatings], [CurrentRatings], [IssuanceAmount], [AmountOutstanding]
									, [FXswapRate], [MaturityType], [MaturityDate], [LegalFinalMaturityDate], [ISIN], [StockExchange], [CouponPaymentFrequency]
									, [CouponPaymentDate], [Coupon], [InterestRateExtendedMaturity], [SwapCounterParties], [SwapNotionalDenomination], [SwapNotionalAmount]
									, [SwapNotionalMaturity], [LLPPayMargin], [LLPPayRate], [LLPReceiveMargin], [LLPReceiveRate], [CollateralPostingAmount] 
								) 
			) unpiv; 

	

	INSERT INTO #tempLineOrder VALUES
		 ('Series','Series', 1)
		,('IssuanceDate','Issue date',2)
		,('OriginalRatings', + 'Original Ratings (' + @craNames + ')',3)
		,('CurrentRatings', + 'Current Ratings (' + @craNames + ')',4)
		,('Denomination','Denomination',5)
		,('IssuanceAmount','Amount at issuance',6)
		,('AmountOutstanding','Amount outstanding',7)
		,('FXswapRate','FX swap rate (rate:�1)',8)
		,('MaturityType', + 'Maturity type ( hard /soft-bullet / pass-through )', 9)
		,('MaturityDate','Scheduled final maturity date', 10)
		,('LegalFinalMaturityDate','Legal final maturity date', 11)
		,('ISIN','ISIN', 12)
		,('StockExchange','Stock exchange listing',13)
		,('CouponPaymentFrequency','Coupon payment frequency', 14)
		,('CouponPaymentDate','Coupon payment date', 15)
		,('Coupon','Coupon (rate if fixed, margin and reference rate if floating)',16)
		,('InterestRateExtendedMaturity','Interest rate payable under extended maturity period',17)
		,('SwapCounterParties','Swap counterparties',18)
		,('SwapNotionalDenomination','Swap notional denomination', 19)
		,('SwapNotionalAmount','Swap notional amount', 20)
		,('SwapNotionalMaturity','Swap notional maturity', 21)
		,('LLPPayMargin','LLP pay margin', 22)
		,('LLPPayRate','LLP pay rate', 23)
		,('LLPReceiveMargin','LLP receive margin', 24)
		,('LLPReceiveRate','LLP receive rate', 25)
		,('CollateralPostingAmount','Collateral posting amount *5', 26)


		 SELECT t1.Series, t2.DisplayName, t1.Valuee, t2.SortOrder
		 INTO	#temp3
		 FROM	#temp2 t1, #tempLineOrder t2 WHERE t1.NoteName=t2.InternalName
		 ORDER BY t1.Series, t2.SortOrder

		DECLARE @cols  AS NVARCHAR(MAX), 
				@query AS NVARCHAR(MAX) 

		SELECT @cols = Stuff((SELECT ',' + Quotename(Series) 
							FROM   #temp3 
							GROUP  BY Series 
							ORDER  BY CASE WHEN Series ='Series 8' THEN 1
										   WHEN Series ='Series 9' THEN 2
										   WHEN Series ='Series 11' THEN 3
										   ELSE 4
										   END 
							FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '') 

		SET @query = N'SELECT DisplayName as Series,' + @cols 
					+ N' from   ( select DisplayName, Series, Valuee, SortOrder from #temp3 ) x pivot  ( max(Valuee) for Series in (' + @cols + N') ) p ' 

		EXEC sp_executesql @query; 

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetCoveredBondsOSDerivatives', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   

END

Go
