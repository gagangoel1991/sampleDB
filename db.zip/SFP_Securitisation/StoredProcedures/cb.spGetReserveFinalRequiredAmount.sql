USE [SFP_Securitisation]

IF OBJECT_ID('cb.spGetReserveFinalRequiredAmount') IS NOT NULL
	DROP PROC  cb.spGetReserveFinalRequiredAmount

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 *   Author: Saurabh Bhatia
 *   Date:  22-March-2022
 *   Description:  To Get Collection Data 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   declare @pFinalRequiredAmount decimal(38,16)  
 *   exec cb.spGetReserveFinalRequiredAmount 34,'europa\bhasaaa',@pFinalRequiredAmount output
 *   Select @pFinalRequiredAmount
 *    
*/
CREATE PROC cb.spGetReserveFinalRequiredAmount
	 @pDealIpdRunId INT
	,@pUserName VARCHAR(20)
	,@pFinalRequiredAmount decimal(38,16) OUTPUT  
AS
BEGIN
	BEGIN TRY		
		
		SET @pFinalRequiredAmount = ISNULL((SELECT ReserveFund_bF FROM [cb].[ReserveFund_PreWF] WHERE DealIpdRunId = @pDealIpdRunId),0.0);

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spGetReserveFinalRequiredAmount'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO