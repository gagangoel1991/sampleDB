USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetSFPPlusDashBoardCompletedPools]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetSFPPlusDashBoardCompletedPools]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 *   Author: Sakthivel Loganathan
 *   Date:  23-Feb-2023
 *   Description: To get Retail/Corporate data for pool dashboard
 *   Change History 
 *   ---------------------------------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   exec [ps].[spGetSFPPlusDashBoardCompletedPools] '1 jan 2023','1 feb 2023','System', 1
*/


CREATE PROCEDURE [ps].[spGetSFPPlusDashBoardCompletedPools]  
(        
 @pFromDate DATE,  
 @pToDate DATE,  
 @pUserName VARCHAR(50),
 @pAssetClassID INT = 1
)        
AS        
BEGIN      
 
   DECLARE @AssetClass_Retail INT = (SELECT AssetClassId FROM PS.AssetClass WHERE CODE = 'RT')

  IF(@pAssetClassID = @AssetClass_Retail )
  BEGIN
		EXEC [ps].[spGetSFPPlusCompletedPools] @pFromDate,@pToDate,@pUserName,@pAssetClassID
   END
   ELSE
   BEGIN
	   EXEC [corp].[spGetSfpPlusCompletedPoolsCorporate] @pFromDate,@pToDate,@pUserName,@pAssetClassID
   END        
END

GO
--EXEC [ps].[spGetSFPPlusDashBoardCompletedPools_sak] '13-JAN-2023','13-FEB-2023' , 'LOGA', 1