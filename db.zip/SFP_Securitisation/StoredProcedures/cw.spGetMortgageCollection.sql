USE SFP_Securitisation

IF OBJECT_ID('cw.spGetMortgageCollection') IS NOT NULL
	DROP PROC cw.spGetMortgageCollection
GO

/*
 * ---------------------------------------------------
 * Author: Saurabh Bhatia
 * Date:	26-Nov-2021
 * Description: This SP is Used to Get Covered Bond 
 * Deimos Deal Mortgage Collections Data.
 * 
 * EXEC cw.spGetMortgageCollection '2022-03-31','DEIMOS'
 * ---------------------------------------------------
*/
CREATE PROCEDURE cw.spGetMortgageCollection @pAsAtDate datetime
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
AS
BEGIN
	BEGIN TRY
		DECLARE @dealId INT
			,@collectionBusinessStart DATE
			,@collectionBusinessEnd DATE
			,@ipdMinus1BusinessDay DATE
			,@interest DECIMAL(38, 18)
			,@schedulePrincipal DECIMAL(38, 18)
			,@unschedulePrincipal DECIMAL(38, 18)
			,@MortgageCollectionUnscheduledInterest DECIMAL(38, 18)
			,@previousIpdDate DATE
			,@partitionId				INT
			,@prevPartitionId			INT
			,@mortgageDealKey			INT

		SELECT @dealId = di.dealId
			,@collectionBusinessStart = did.CollectionBusinessStart
			,@collectionBusinessEnd = did.CollectionBusinessEnd
			,@previousIpdDate  = did.PreviousIPDCollectionBusinessEnd  
			,@mortgageDealKey = d.MortgageDealId
		FROM cw.DealIpd di
		JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
		JOIN cw.vw_ActiveDeal d ON d.dealId = di.dealId
		WHERE CAST(did.CollectionBusinessEnd AS DATE)= @pAsAtDate   
			AND d.DealName = @pDealName;

		--Mortgage collections (interest)	
		SET @interest = (
				SELECT SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(38, 18)))
				FROM [cw].[vwDailyCollection] dc
				WHERE dc.DealId = @dealId
					AND dc.DailyCollectionFieldColumnName = 'TotalRevenueReceipts'
					AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
						AND @collectionBusinessEnd
				)
		--Mortgage collections (scheduled - principal)
		SET @schedulePrincipal = (
				SELECT SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(38, 18)))
				FROM [cw].[vwDailyCollection] dc
				WHERE dc.DealId = @dealId
					AND dc.DailyCollectionFieldColumnName = 'ScheduledPrincipalReductions'
					AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
						AND @collectionBusinessEnd
				)
		--Mortgage collections (unscheduled - principal)
		SET @unschedulePrincipal = (
				SELECT SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(38, 18)))
				FROM [cw].[vwDailyCollection] dc
				WHERE dc.DealId = @dealId
					AND dc.DailyCollectionFieldColumnName IN (
						'PartialPrepayments'
						,'OverPayments'
						,'Redemptions'
						,'FurtherStageAdvances'
						,'FeesChargedCapitalised'
						,'OtherPrincipalMovements'
						)
					AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
						AND @collectionBusinessEnd
				);

		SET @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		SET @prevPartitionId = CONVERT(INT, CONVERT(VARCHAR(8), @previousIpdDate, 112))
		
		SET @MortgageCollectionUnscheduledInterest = ( SELECT (SUM(FeesPaid) + SUM(FinesPaid))
				FROM   [sfp].[syn_SfpModel_vw_Fact_MortgageSubAccountSecTransaction_v1] AS fsat
					   JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS msa ON fsat.MortgageSubAccountKey = msa.MortgageSubAccountKey
				WHERE  fsat.PartitionID > @prevPartitionId
					   AND fsat.PartitionID <= @partitionId
					   AND msa.InceptionDate <> '0001-01-01'
					   AND msa.ProcessStatus <> 1
					   AND fsat.MortgageDealKey = @mortgageDealKey )


		SELECT 'Mortgage Collections (interest)' AS [~HeaderText]
			,ABS(ISNULL(@interest, 0)) AS 'Current Period (GBP)'
		
		UNION ALL
		
		SELECT 'Mortgage Collections (scheduled - principal)' AS [~HeaderText]
			,ABS(ISNULL(@schedulePrincipal, 0)) AS 'Current Period (GBP)'
		
		UNION ALL
		
		SELECT 'Mortgage Collections (unscheduled - principal)' AS [~HeaderText]
			,ABS(ISNULL(@unschedulePrincipal, 0)) AS 'Current Period (GBP)'

		
		UNION ALL
		
		SELECT 'Mortgage Collections (unscheduled - interest)' AS [~HeaderText]
			,ABS(ISNULL(@MortgageCollectionUnscheduledInterest, 0)) AS 'Current Period (GBP)'

	 


	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetMortgageCollection'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO
