USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetKeyPrimaryForberanceMonthsInArrear') IS NOT NULL
DROP PROC CW.spGetKeyPrimaryForberanceMonthsInArrear
GO

/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Key Primary Forbearance - Month In Arrears for Investor report.
 * Usage : CW.spGetKeyPrimaryForberanceMonthsInArrear @pAsAtDate  = '30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetKeyPrimaryForberanceMonthsInArrear @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY 
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
				
				
BEGIN TRY
			
  
	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	,@totalSubAccounts float, @totalOutstandingCapitalBalance float, @totalTrueBalance float
	,@amortisingTotalSubAccounts float, @amortisingTotalOutstandingCapitalBalance float
	,@discountRateTotalSubAccounts float, @discountRateTotalOutstandingCapitalBalance float
	,@interestOnlySubAccounts float, @interestOnlyTotalOutstandingCapitalBalance float	
	,@dealId INT;
	  
	  --Dropping Temp Tables if they exist
	   IF OBJECT_ID('tempdb..#Mortgage')			IS NOT NULL DROP TABLE	#Mortgage
	   IF OBJECT_ID('tempdb..#ReportLookUp')		IS NOT NULL DROP TABLE 	#ReportLookUp
	   IF OBJECT_ID('tempdb..#Forbearance')			IS NOT NULL DROP TABLE  #Forbearance
	   IF OBJECT_ID('tempdb..#Amortising')			IS NOT NULL DROP TABLE 	#Amortising
	   IF OBJECT_ID('tempdb..#DiscountRate')		IS NOT NULL DROP TABLE 	#DiscountRate
	   IF OBJECT_ID('tempdb..#InterestOnly')        IS NOT NULL DROP TABLE 	#InterestOnly
	   IF OBJECT_ID('tempdb..#FinalAmortisingFB')   IS NOT NULL DROP TABLE 	#FinalAmortisingFB
	   IF OBJECT_ID('tempdb..#FinalDiscountRateFB') IS NOT NULL DROP TABLE 	#FinalDiscountRateFB
	   IF OBJECT_ID('tempdb..#FinalInterestOnlyFB') IS NOT NULL DROP TABLE 	#FinalInterestOnlyFB
	   
	  


	 

	SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1 

	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId

	SELECT MortgageSubAccountKey, ForbearanceKey, FORBEARANCE_TYPE AS ForbearanceType, FORBEARANCE_COUNTER AS ForbearanceCounter, FORBEARANCE_STATUS AS forbearanceStatus
	, CURRENT_CAPITALISATION_DATE AS CapitalisationDate, CURRENT_TERM_EXT_DATE AS TermExtensionDate
	, FIRST_FORBEARANCE_START_DATE AS FirstForbearanceStartDate, CURRENT_FORBEARANCE_END_DATE AS CurrentForbearanceEndDate, Forbearance_AsAtDateFrom AS AsAtDateFrom, Forbearance_AsAtDateTo AS AsAtDateTo
	, Outstandng_Capital_Balance_Amt AS TotalOutstandingCapitalBalance, True_Balance_Amt AS TrueBalance
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MONTHS_IN_ARREARS ) AS BandRange  
	INTO #Mortgage        
	FROM #VwMortgageSubAccount	

	CREATE CLUSTERED INDEX FB ON #Mortgage  (forbearancekey);     


	SELECT L.LookUpValue, AL.ReportLookupValue AS LookUpValueDescription  
	INTO #ReportLookUp
	FROM cfgcw.IR_AssetStratGroupingLookupData AL 
	INNER JOIN  cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
	INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 L ON L.ReportTemplateName='SFP+' 
		AND L.LookupValueDescription=AL.ReportLookupName AND L.LookupName =M.FieldName
	WHERE M.FieldName='FORBEARANCE_TYPE'	
	
	CREATE CLUSTERED INDEX IndxLookup ON #ReportLookUp (LookUpValue)
	
	SELECT MortgageSubAccountKey, ForbearanceKey, ForbearanceType, ForbearanceStatus, TotalOutstandingCapitalBalance, TrueBalance, BandRange, FirstForbearanceStartDate, CurrentForbearanceEndDate
	INTO #Forbearance  
	FROM #Mortgage f
	WHERE f.ForbearanceStatus = 'L'  
	AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate
   
    CREATE CLUSTERED INDEX CR ON #Forbearance  (forbearancekey); 	

--=FOR % of Total pool of Mortgage
	SELECT @totalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0))  
		, @totalTrueBalance  = ISNULL(SUM(M.TrueBalance), 0)
	FROM   #Mortgage M
	
---=For @Amortising in Forbearance ---  
	SELECT F.MortgageSubAccountKey, F.TotalOutstandingCapitalBalance, F.TrueBalance, F.BandRange
	INTO #Amortising
	FROM #Forbearance F
	INNER JOIN #ReportLookUp r ON r.LookUpValue = f.ForbearanceType  AND r.LookUpValueDescription = 'Reduced Repayment - Amortising'  



	SELECT @amortisingTotalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
		, @amortisingTotalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0)) 
	FROM #Amortising M


---=For @DiscountRate in Forbearance ----  
	SELECT  F.MortgageSubAccountKey, F.TotalOutstandingCapitalBalance, F.TrueBalance, F.BandRange
	INTO #DiscountRate
	FROM #Forbearance F
	INNER JOIN #ReportLookUp r ON r.LookUpValue = f.ForbearanceType  AND r.LookUpValueDescription = 'Alternate Treatments - Discount Rate'  	

	SELECT @discountRateTotalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
		, @discountRateTotalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0)) 
	FROM #DiscountRate M

---=For @InterestOnly in Forbearance ----  
	SELECT  F.MortgageSubAccountKey, F.TotalOutstandingCapitalBalance, F.TrueBalance, F.BandRange
	INTO #InterestOnly
	FROM #Forbearance F
	INNER JOIN #ReportLookUp r ON r.LookUpValue = f.ForbearanceType  AND r.LookUpValueDescription = 'Reduced Repayment - Interest Only'  

	SELECT @interestOnlySubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
		, @interestOnlyTotalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0)) 
	FROM #InterestOnly M
               
--=========================================================================================

	SELECT SortOrder, dans.DisplayName 'HeaderText',   count(MortgageSubAccountKey) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts> 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalSubAccounts  ) AS Decimal(38,8)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance' 
	, CAST(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN ISNULL(Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance)  AS Decimal(38,8)),0)  ELSE 0 END AS Float) [TotalAssetPoolAmountPercent]
	, ISNULL(CAST(sum(TrueBalance) AS Float) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance> 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) * 100 AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) TrueBalancePercent  
	INTO #FinalAmortisingFB
	FROM @pStratRangeData dans 
	LEFT JOIN #Amortising T ON T.BandRange = dans.DisplayName 
	--Where dans.StratInternalName = @pStratInternalName
	GROUP BY dans.DisplayName , dans.SortOrder	
	ORDER BY dans.SortOrder;

	
	SELECT SortOrder , dans.DisplayName 'HeaderText',  count(MortgageSubAccountKey) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts> 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalSubAccounts  ) AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance' 
	, CAST(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN ISNULL(Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance) AS Decimal(38,8)),0) ELSE 0 END AS Float) [TotalAssetPoolAmountPercent]
	, ISNULL(CAST(sum(TrueBalance) AS Float) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance> 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance)  AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) TrueBalancePercent  
	INTO #FinalDiscountRateFB
	FROM @pStratRangeData dans 
	LEFT JOIN #DiscountRate T ON T.BandRange = dans.DisplayName 
	--Where dans.StratInternalName = @pStratInternalName
	GROUP BY dans.DisplayName , dans.SortOrder	
	ORDER BY dans.SortOrder;
	
	SELECT  SortOrder ,dans.DisplayName 'HeaderText',  count(MortgageSubAccountKey) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts> 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalSubAccounts  ) AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance' 
	, CAST(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN ISNULL(Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance) AS Decimal(38,8)),0) ELSE 0 END AS Float) [TotalAssetPoolAmountPercent]
	, ISNULL(CAST(sum(TrueBalance) AS Float) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance> 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) TrueBalancePercent  
	INTO #FinalInterestOnlyFB
	FROM @pStratRangeData dans 
	LEFT JOIN #InterestOnly T ON T.BandRange = dans.DisplayName 
	--Where dans.StratInternalName = @pStratInternalName
	GROUP BY dans.DisplayName , dans.SortOrder	
	ORDER BY dans.SortOrder;;		
	

	
	SELECT 
	IIF(FA.HeaderText IS NULL, 'Total',FA.HeaderText+' Months in Arrears') AS '~HeaderText',
	SUM(FA.[MortgageLoans]) AS 'Number of Mortgage Loans~ReducedRepaymentAmortising',
	SUM(FA.TotalOutCapitalBalance) AS 'Amount (EUR)~ReducedRepaymentAmortising', 
	SUM(FA.[TotalAssetPoolAmountPercent]) AS 'Amount as % of total pool assets~ReducedRepaymentAmortising', 
	SUM(FD.[MortgageLoans]) AS 'Number of Mortgage Loans~AlternateTreatmentsDiscountRate',
	SUM(FD.TotalOutCapitalBalance) AS 'Amount (EUR)~AlternateTreatmentsDiscountRate',
	SUM(FD.[TotalAssetPoolAmountPercent]) AS 'Amount as % of total pool assets~AlternateTreatmentsDiscountRate', 
	SUM(FI.[MortgageLoans]) AS 'Number of Mortgage Loans~ReducedRepaymentInterest', 
	SUM(FI.TotalOutCapitalBalance) AS 'Amount (EUR)~ReducedRepaymentInterest', 
	SUM(FI.[TotalAssetPoolAmountPercent]) AS 'Number of Mortgage Loans~ReducedRepaymentInterest',
	SUM(FA.[TotalAssetPoolAmountPercent])+SUM(FD.[TotalAssetPoolAmountPercent])+SUM(FI.[TotalAssetPoolAmountPercent]) AS 'Amount as % of total pool assets~Total'
	FROM #FinalAmortisingFB FA
	INNER JOIN #FinalDiscountRateFB FD ON FA.HeaderText = FD.HeaderText
	INNER JOIN #FinalInterestOnlyFB FI ON FA.HeaderText = FI.HeaderText
	GROUP BY FA.HeaderText WITH Rollup
	ORDER BY SUM(FA.SortOrder)+SUM(FD.SortOrder)+SUM(FI.SortOrder)

END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetKeyPrimaryForberanceMonthsInArrear', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END

GO


