USE [SFP_Securitisation]
GO

IF Object_Id('PS.spGetBusinessDates') is Not Null 
	Drop PROCEDURE PS.spGetBusinessDates
	
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--EXEC PS.spGetBusinessDates '2020-11-29', 0
--EXEC PS.spGetBusinessDates '8 JUNE 2022', 6
--EXEC PS.spGetBusinessDates null, 16 

create PROCEDURE PS.spGetBusinessDates
(
	@StartingMonth DATE = NULL,
	@NoOfMonths INT = 6
)
AS
BEGIN
	DECLARE @MonthCount INT = 0, @TodayDate DATE = GETUTCDATE()
	DECLARE @CurrentMonth DATE;

	IF OBJECT_ID('tempdb.dbo.#BusinessMonths', 'U') IS NOT NULL    
    DROP TABLE #BusinessMonths 


	CREATE TABLE #BusinessMonths(BusinessDate DATE, DisplayDate VARCHAR(8))

	-- STARTING FROM GIVEN MONTH TO CURRENT MONTH
	IF(@StartingMonth IS NOT NULL AND @NoOfMonths = 0) 
	BEGIN
	    DECLARE  @CurrentBusinessDate DATE
		DECLARE @StartingMonth_Tmp DATE = (@StartingMonth);

		WHILE(@StartingMonth_Tmp < @TodayDate)
		BEGIN
			SELECT @CurrentMonth = DATEADD(Month, @MonthCount, @StartingMonth) 
			SELECT @CurrentBusinessDate = [cw].[fnGetBusinessDate] (EOMONTH(@CurrentMonth), 'UK', 0, 1)
			
			IF(@CurrentBusinessDate < @TodayDate)
			BEGIN
				INSERT INTO #BusinessMonths SELECT @CurrentBusinessDate, FORMAT (@CurrentBusinessDate, 'MMM yyyy')
			END
			SELECT @StartingMonth_Tmp = @CurrentMonth;
			SELECT @MonthCount = @MonthCount + 1
		END 

		SELECT @CurrentBusinessDate = [cw].[fnGetBusinessDate] (@TodayDate, 'UK', 0, 1)
		INSERT INTO #BusinessMonths 
		SELECT @CurrentBusinessDate, FORMAT(@CurrentBusinessDate, 'MMM yyyy')
	END
	-- STARTING FROM GIVEN MONTH TO NUMBER OF MONTHS
	IF(@StartingMonth IS NOT NULL AND @NoOfMonths > 0)
	BEGIN
			SELECT @MonthCount = 0
			WHILE(@MonthCount < @NoOfMonths)
			BEGIN
				SELECT @CurrentMonth = DATEADD(Month, @MonthCount, @StartingMonth)
				SELECT @CurrentBusinessDate = [cw].[fnGetBusinessDate] (EOMONTH(@CurrentMonth), 'UK', 0, 1)

				INSERT INTO #BusinessMonths
				SELECT @CurrentBusinessDate, FORMAT(@CurrentBusinessDate, 'MMM yyyy')
				SELECT @MonthCount = @MonthCount +1 
			END
	END
	-- STARTING FROM CURRENT MONTH TO NUMBER OF MONTHS BACKWARDS
	ELSE IF(@StartingMonth IS NULL AND @NoOfMonths > 0)
	BEGIN
			--DECLARE @CurrentDate2 date = @TodayDate
			WHILE(@NoOfMonths > 0)
			BEGIN
					SELECT @CurrentMonth = DATEADD(Month, -@NoOfMonths, @TodayDate)

					SELECT @CurrentBusinessDate = [cw].[fnGetBusinessDate] (EOMONTH(@CurrentMonth), 'UK', 0, 1)

					INSERT INTO #BusinessMonths
					SELECT @CurrentBusinessDate, FORMAT(@CurrentBusinessDate, 'MMM yyyy')
					SELECT @NoOfMonths = @NoOfMonths -1 
			END
	END
	SELECT DISTINCT * FROM #BusinessMonths ORDER BY BusinessDate

	IF OBJECT_ID('tempdb.dbo.#BusinessMonths', 'U') IS NOT NULL    
    DROP TABLE #BusinessMonths 

END
GO
