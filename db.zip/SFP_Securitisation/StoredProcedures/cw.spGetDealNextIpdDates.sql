USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetDealNextIpdDates]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealNextIpdDates]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--================================================
--Author: Saurabh Bhatia
--Date:	26-May-2021
--Description:  To get Deal Ipd dates
--Exec cw.spGetDealNextIpdDates 
--================================================
CREATE PROCEDURE cw.spGetDealNextIpdDates
AS
BEGIN
	SELECT 
		 d.DealId
		,d.DealName
		,cast(CollectionBusinessEnd AS DATE) AS IpdDate
	FROM (
		SELECT vwdates.CollectionBusinessEnd
			,vwdates.DealId
			,Row_number() OVER (
				PARTITION BY vwdates.DealId ORDER BY vwdates.CollectionBusinessEnd ASC
				) AS Rn
		FROM cw.vwDealIpdDates vwdates
		JOIN cw.dealIpd dIpd ON cast(vwdates.ipd AS DATE) >= cast(dIpd.ipddate AS DATE)
			AND IsCurrentIPD = 1
			AND vwdates.DealId = dIpd.DealId
		GROUP BY vwdates.CollectionBusinessEnd
			,vwdates.DealId
		) DealCollectionDates
	JOIN cw.vw_ActiveDeal d ON d.DealId = DealCollectionDates.DealId
	WHERE DealCollectionDates.Rn < 3
	ORDER BY CollectionBusinessEnd ASC
END
GO