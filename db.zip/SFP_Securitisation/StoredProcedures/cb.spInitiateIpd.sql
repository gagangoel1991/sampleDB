USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spInitiateIpd') IS NOT NULL
	DROP PROCEDURE cb.spInitiateIpd
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/********

	DECLARE @pResultCode INT         
  exec cb.spInitiateIpd	6,'2021-05-24' ,'fm\shriyad','Initiate',@pResultCode OUTPUT
  Select @pResultCode

  NOTE: ANY CHANGE DONE HERE MUST BE ANALYSED in [cb].[spReCalculateIpd] sp AS WELL.
  **********/

CREATE PROC [cb].[spInitiateIpd]
(
	@pDealId SMALLINT,
	@pIpdDate  DATETIME,
	@pUserName	VARCHAR(80),
 @pAuthStepName VARCHAR(50),
	@pResultCode INT OUTPUT 
	/*
		1  : Success
		-1 : Previous IPD is not authorised yet, so you cannot initiate the next IPD
		-2 : Speciified IPD is already authorised so you cannot re-run this IPD
		-3 : Speciified IPD is already initiated, so you cannot re-initiate this IPD
	*/
)
AS
BEGIN

	--Declare 
	--@pDealId SMALLINT=6,
	--	@pIpdDate  DATETIME='2021-05-24',
	--	@pUserName	VARCHAR(80)='',
	-- @pAuthStepName VARCHAR(50)='Initiate',
	--	@pResultCode INT  
	
	DECLARE
		@Message		VARCHAR(4000),
		@stepCode		VARCHAR(50)= 'CB_INIT_DEALIPD',
		@logStatus		VARCHAR(20) = 'STARTED',
		@logDescription	VARCHAR(1000),
		@inputParams	VARCHAR(100) = 'DealId=' + CONVERT(VARCHAR(10) ,@pDealId) + ';IpdDate=' + CONVERT(VARCHAR(50) ,@pIpdDate),
		@logExecutionId INT ,
		@LogStepId      INT,
		@LogDealRunID   INT,
		@exceptionErrorMessage  NVARCHAR(4000),
		@logFeatureID       INT,
		@ModuleID           INT

	
	SET NOCOUNT ON

	DECLARE @tblWaterfallLogStepIpd TABLE
		(
		ExecutionId [INT] IDENTITY(1,1) NOT NULL,
		[LogStepId] [INT],
		[RelatedId] [INT] ,
		[StepCode] [varchar](100) NULL,
		[StartTime] [datetime] NOT NULL,
		[EndTime] [datetime] NULL,
		[Status] [varchar](100) NULL,
		[InputParams] [varchar](500) NULL,
		[ErrorDetails] [varchar](500) NULL,
		[IsDebug] [INT],
		[AdditonalDescription] [varchar](1000) NULL,
		[CreatedBy] [varchar](50) NOT NULL,
		[CreatedDate] [datetime] NOT NULL
		)

	BEGIN TRY
	    
			
		SELECT @LogDealRunID=DealIpdRunId FROM cw.vwDealIpdRun WHERE DealId=@pDealId AND IpdDate=@pIpdDate ;

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep WHERE StepCode = 'CB_INIT_DEALIPD'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep WHERE  StepCode = 'CB_INIT_DATE'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep WHERE  StepCode = 'CB_INIT_MANUALFIELD'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());
		
		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep WHERE  StepCode = 'CB_INIT_DEALNOTE'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_DEALSWAP'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_NOTESWAP'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_PREMATURITYLIQUIDITYTEST'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_PREMATURITYLIQUIDITY'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_COUPONPAYMENTFUND'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_SWAPCOLLATERALFUND'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_TRIGGERS'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_INVOICE'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_EXP_1'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_DEALCONFIG'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_WLI_1'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

			SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_WLI_OVERRIDE_1'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());


				SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INT_RESERVEFUND_PRE'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

				SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_EXP_2'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

				SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_WLI_2'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

				SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_WLI_OVERRIDE_2'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

				SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_RUNALLTESTS'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

			SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_UPDATELINEITEM'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_SAVEIPDDATA'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

			SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_PROCESSRESERVEINTERESTBYIPD'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

			SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_INIT_PROCESSCOLLECTIONINTEREST'
		INSERT INTO @tblWaterfallLogStepIpd(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@LogDealRunID, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		
		DECLARE
			@prevIpdDate				DATE,
			@nextIpdDate				DATE,
			@prevIpdWorkflowStatusId	SMALLINT,
			@currentIpdWorkFlowStatusId	SMALLINT,
			@dealIpdAuthorisedStatusId	SMALLINT

		SELECT @dealIpdAuthorisedStatusId = [cw].[fnGetWorkflowStepId]('Authorise', 'Deal_Ipd')

		--Previous IPD 
		SELECT TOP 1 @prevIpdDate = di.IpdDate, @prevIpdWorkflowStatusId = dir.WorkflowStepId FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		WHERE di.DealID = @pDealId AND di.IpdDate < @pIpdDate AND di.IpdSequence>0
		AND dir.IsCurrentVersion = 1 
		ORDER BY di.IpdDate DESC

		--Current IPD
		SELECT @currentIpdWorkFlowStatusId = dir.WorkflowStepId FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		WHERE di.DealID = @pDealId AND CAST(di.IpdDate AS DATE) = CAST(@pIpdDate AS DATE) AND di.IpdSequence > 0
		AND dir.IsCurrentVersion = 1 
		ORDER BY di.IpdDate DESC

		----*******************Do some checks before initiating the IPD****************************
		IF @prevIpdDate IS NOT NULL AND @prevIpdWorkflowStatusId <> @dealIpdAuthorisedStatusId
		BEGIN
			SET @Message =  'Previous IPD is not authorised yet, so you cannot initiate the next IPD'
			SET @pResultCode = -1
		END
		ELSE IF @currentIpdWorkFlowStatusId IS NOT NULL AND @currentIpdWorkFlowStatusId = @dealIpdAuthorisedStatusId
		BEGIN
			SET @Message =  'Speciified IPD is already authorised so you cannot re-run this IPD'
			SET @pResultCode = -2
		END
		ELSE IF EXISTS (SELECT 1 FROM cw.DealIPDRun with (nolock) WHERE Runid = @LogDealRunID  AND ISNULL(IsIpdRunning,0) <> 0   AND @pAuthStepName <> 'Reset')  
		BEGIN  
			SET @Message =  'Speciified IPD is already initiated, so you cannot re-initiate this IPD'  
			SET @pResultCode = -3  
		END  
		ELSE IF (SELECT TOP 1 WorkflowStepId FROM cw.WorkflowProcess with (nolock) WHERE ProcessReferenceId=@LogDealRunID ORDER BY 1 DESC ) =38  AND @pAuthStepName <> 'Reset'  
		BEGIN  
			SET @Message =  'Speciified IPD is already initiated, so you cannot re-initiate this IPD'  
			SET @pResultCode = -3  
		END
		--ELSE IF NOT EXISTS(SELECT TOP 1 1 FROM cb.SFPCollectionInterest WHERE  CollectionDate=(SELECT CollectionBusinessEnd FROM cw.vwdealipddates WHERE ipd =@pIpdDate) ) 
		--BEGIN  
		--	SET @Message =  'Collection and Interest Data is not available, so you cannot initiate this IPD'  
		--	SET @pResultCode = -4  
		--END
		ELSE
		BEGIN
			---Now IPD can be initiated/re-run
			BEGIN TRAN
			DECLARE 
				@dealIpdRunId		INT
				,@dealIpdId			INT
				,@version			INT
				,@ipdSequence		INT
				,@ipdDraftStepId	INT
				,@date				DATETIME = GETDATE()
				,@pWorkflowProcessId INT
				,@CollectionBusinessStart DATETIME
				,@CollectionCalendarEnd DATETIME

			SELECT @ipdDraftStepId = [cw].[fnGetWorkflowStepId]('Draft', 'Deal_Ipd');

			SELECT @dealIpdRunId=DealIpdRunId,@dealIpdId=DealIpdId, @version=DealIpdRunVersion, @ipdSequence=IpdSequence 
			FROM cw.vwDealIpdRun with (nolock) WHERE DealId=@pDealId AND IpdDate=@pIpdDate   AND IsCurrentVersion = 1;
	
			SELECT @dealIpdId=DealIpdId, @ipdSequence=IpdSequence 
			FROM cw.DealIpd with (nolock) WHERE DealId=@pDealId AND IpdDate=@pIpdDate ;

			SELECT @dealIpdRunId=RunId, @version=[version]
			FROM cw.DealIpdRun with (nolock) WHERE DealIpdId=@dealIpdId  AND IsCurrentVersion = 1;

			IF(@dealIpdId IS NOT NULL)
			BEGIN
				-- update last ipd status
				UPDATE cw.DealIpd
				SET IsCurrentIPD=0
				WHERE DealId = @pDealId AND IpdSequence = @ipdSequence -1;

				UPDATE cw.DealIpd
				SET IsCurrentIPD=1
				WHERE DealIpdId = @dealIpdId;

				IF(@dealIpdRunId IS NOT NULL)
				BEGIN
					IF(@pAuthStepName = 'Initiate' )
					BEGIN 
						SET @Message =  'Speciified IPD is already initiated, so you cannot re-initiate this IPD'
						SET @pResultCode = -3
						UPDATE cw.DealIPDRun SET IsIpdRunning = 0, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE RunId = @dealIpdRunId
						COMMIT TRAN ;
						RETURN;
					END
					--reset IPD
					UPDATE cw.DealIpdRun SET WorkflowStepId = @ipdDraftStepId, IsIpdRunning = 2, ModifiedBy=@pUserName, ModifiedDate=GETDATE()  WHERE RunId = @dealIpdRunId
					PRINT 'RESET!!'
				END
				ELSE
				BEGIN
					INSERT INTO cw.DealIpdRun(DealIpdId, Version, IsCurrentVersion, WorkflowStepId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate,IsIpdRunning)
					VALUES(@dealIpdId, 1, 1, @ipdDraftStepId, @pUserName, @date, @pUserName, @date, 1)
		
					SET @dealIpdRunId= (SELECT SCOPE_IDENTITY());

					SELECT @version=DealIpdRunVersion, @ipdSequence=IpdSequence 
					FROM cw.vwDealIpdRun WHERE DealIpdRunId=@dealIpdRunId;
				END
			END
			ELSE
			BEGIN
				PRINT 'NEW IPD!!'
				--update last IPD
				SET @ipdSequence= (SELECT MAX(IpdSequence) FROM cw.vwDealIpdRun WHERE DealId=@pDealId);

				UPDATE cw.DealIpd
				SET IsCurrentIpd=0
				WHERE DealId=@pDealId
				AND IpdSequence=@ipdSequence;

				UPDATE dir
				SET IsCurrentVersion=0
				FROM cw.DealIpdRun dir
					JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId
				WHERE 
					DealId=@pDealId
					AND IpdSequence=@ipdSequence
					AND IsCurrentVersion=1;

				--initiate IPD

				INSERT INTO cw.DealIpd (DealId, IpdSequence, IpdDate, IsCurrentIPD, CollectionBusinessDayCount, CollectionCalendarDayCount, IpdDayCount
				,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
				VALUES(@pDealId, @ipdSequence+1, @pIpdDate , 1, 0, 0, 0,1, 'System', @date, 'System', @date)

				SET @dealIpdId= (SELECT SCOPE_IDENTITY());

				INSERT INTO  cw.DealIpdRun(DealIpdId, Version, IsCurrentVersion, WorkflowStepId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate,IsIpdRunning)
				VALUES(@dealIpdId, 1, 1, @ipdDraftStepId, @pUserName, @date ,@pUserName, @date,1)
		
				SET @dealIpdRunId= (SELECT SCOPE_IDENTITY());

				SELECT @version=DealIpdRunVersion, @ipdSequence=IpdSequence 
				FROM cw.vwDealIpdRun WHERE DealIpdRunId=@dealIpdRunId;

			END

			--Populating the dates for the IPD
			EXEC cw.spPopulateIpdDate @dealIpdId

			--Insert next IPD and populate the dates so that it will be available on the UI
			SELECT @nextIpdDate = NextIPD FROM cw.vwDealIpdDates WHERE DealIpdId = @dealIpdId
			IF @nextIpdDate IS NOT NULL 
			BEGIN
				DECLARE
					@nextDealIpdID		INT
				--Check whether the next Deal IPD record is exist or not
				IF NOT EXISTS(SELECT TOP 1* FROM cw.DealIpd WHERE DealId = @pDealId AND CAST(IpdDate AS DATE) = CAST(@nextIpdDate AS DATE))
				BEGIN
					INSERT INTO cw.DealIpd (DealId, IpdSequence, IpdDate, IsCurrentIPD, CollectionBusinessDayCount, CollectionCalendarDayCount, IpdDayCount
					,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
					VALUES(@pDealId, @ipdSequence+1, @nextIpdDate , 0, 0, 0, 0, 1, 'System', @date, 'System', @date)

					SET @nextDealIpdID= (SELECT SCOPE_IDENTITY());
				END
				ELSE
				BEGIN
					SELECT @nextDealIpdID = DealIpdID FROM cw.DealIpd WHERE DealId = @pDealId AND CAST(IpdDate AS DATE)= CAST(@nextIpdDate AS DATE)
				END

				--Populating the dates for the Next IPD
				EXEC cw.spPopulateIpdDate @nextDealIpdID
				
			END 

			SELECT @CollectionBusinessStart = CollectionBusinessStart, @CollectionCalendarEnd = CollectionCalendarEnd 
			FROM cw.vwDealIpdDates WHERE DealIpdId=@dealIpdId

			IF(@LogDealRunID IS NULL)
			UPDATE @tblWaterfallLogStepIpd SET RelatedId=@dealIpdRunId 

			SELECT @ModuleID =  ModuleId FROM app.Module WHERE Name ='Cashwaterfall'
			SELECT @logFeatureID = LogFeatureId FROM app.LogFeature WHERE Feature = 'IpdInitiate' AND ModuleId = @ModuleID;

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_MANUALFIELD',@logFeatureID);
			EXEC [cb].[spProcessManualFieldsOnIpdInit] @dealIpdRunId, @pUserName

			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_DEALNOTE',@logFeatureID);
		    EXEC  [Cb].[spProcessDealNote] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
		
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_DEALSWAP',@logFeatureID);
			EXEC  [Cb].[spProcessDealSwap] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
						
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_NOTESWAP',@logFeatureID);
			EXEC  [Cb].[spProcessNoteSwap] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_RUNALLTESTS',@logFeatureID);
			EXEC [cb].[spRunAllTest] @dealIpdRunId,@pUserName --since ACT contains WaterfallLineItemAmount values
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
			 						
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_PREMATURITYLIQUIDITYTEST',@logFeatureID);
			EXEC [cb].[spRunPreMaturityTest] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_PREMATURITYLIQUIDITY',@logFeatureID);
			EXEC  [Cb].[spProcessPreMaturityLiquidity_PreWF] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_TRIGGERS',@logFeatureID);
			EXEC [cw].[spProcessTriggersOnIpdInit] @dealIpdRunId,@pUserName -- done
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
			
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_COUPONPAYMENTFUND',@logFeatureID);
			EXEC  [Cb].[spProcessCouponPaymentFund_PreWf] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
			
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_SWAPCOLLATERALFUND',@logFeatureID);
			EXEC  [Cb].[spProcessSwapCollateralFund] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_INVOICE',@logFeatureID);
			EXEC [CW].[spProcessInterimWaterfallFee] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_EXP_1',@logFeatureID);
			EXEC [cw].[spCalculateExpression] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			EXEC [cb].[spProcessManualFieldsOnIpdInit] @dealIpdRunId, @pUserName
			
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_DEALCONFIG',@logFeatureID);
			EXEC  cw.spProcessDealConfigValue @dealIpdRunId, @pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId


			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_WLI_1',@logFeatureID);
			EXEC [cw].[spProcessWaterfallLineItemAmount] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_WLI_OVERRIDE_1',@logFeatureID);
			EXEC [cw].[spCalculateCWOverrideSql] @dealIpdRunId, @pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INT_RESERVEFUND_PRE',@logFeatureID);
			EXEC [Cb].[spProcessReserveFund_PreWF] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_EXP_2',@logFeatureID);
			EXEC  [cw].[spCalculateExpression] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_WLI_2',@logFeatureID);
			EXEC [cw].[spProcessWaterfallLineItemAmount] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_WLI_OVERRIDE_2',@logFeatureID);
			EXEC  cw.spCalculateCWOverrideSql @dealIpdRunId, @pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_RUNALLTESTS',@logFeatureID);
			EXEC [cb].[spRunAllTest] @dealIpdRunId,@pUserName --since ACT contains WaterfallLineItemAmount values
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
			
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_UPDATELINEITEM',@logFeatureID);
			EXEC [cw].[spUpdateIpdSummaryLineItemStatus]  @dealIpdRunId, '', @pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			 SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_SAVEIPDDATA',@logFeatureID);
			EXEC [cw].[spManageIpdAuthWorkflow]  @pDealId=@pDealId, @pIPDRunId=@dealIpdRunId,@pStepName= @pAuthStepName, @pComment ='', @pUserName=@pUserName,@pOutput= @pWorkflowProcessId OUT  
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			 SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_PROCESSRESERVEINTERESTBYIPD',@logFeatureID);
			EXEC [cb].[spProcessReserveInterestByIpd] @dealIpdRunId
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			 SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_PROCESSCOLLECTIONINTEREST',@logFeatureID);
			EXEC [cb].[spProcessCollectionInterestForRange] @CollectionBusinessStart, @CollectionCalendarEnd
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_REVENUEFUND',@logFeatureID);
			EXEC  [Cb].[spProcessRevenueLedgerFund] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_PRINCIPALFUND',@logFeatureID);
			EXEC  [cb].[spProcessPrincipalLedgerFund] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_PAYMENTFUND',@logFeatureID);
			EXEC  [cb].[spProcessPaymentLedgerFund] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_CAPITALACCOUNT',@logFeatureID);
			EXEC  [cb].[spProcessCapitalAccountLedger] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_MATURINGFUND',@logFeatureID);
			EXEC  [cb].[spProcessMaturingProceedsLoanFund] @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
			
			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_BOOKINGS',@logFeatureID);
			EXEC  cb.spProcessBookingsIPDData @dealIpdRunId,@pUserName
			UPDATE @tblWaterfallLogStepIpd SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
			

			UPDATE cw.DealIPDRun SET IsIpdRunning = 0, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE RunId = @dealIpdRunId

			SET @pResultCode = 1

			COMMIT TRAN 

			SET @Message='SUCCESS: InitiateIpd data PRE table is filled!'

			SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_DEALIPD',@logFeatureID);
			UPDATE @tblWaterfallLogStepIpd SET Status= 'SUCCESS' , EndTime =  GETDATE(), AdditonalDescription = @Message WHERE LogStepID=@LogStepId
		END
		
		
	END TRY
	BEGIN CATCH
		
		ROLLBACK TRAN 

		DECLARE @dealRunID INT
		SELECT @dealRunID=DealIpdRunId FROM cw.vwDealIpdRun WHERE DealId=@pDealId AND IpdDate=@pIpdDate ;
		
		UPDATE cw.DealIPDRun SET IsIpdRunning = 0, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE RunId = @dealRunID

		DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			 @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spInitiateIpd', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		SET @pResultCode = 0

		SELECT @exceptionErrorMessage = ERROR_MESSAGE()
		UPDATE @tblWaterfallLogStepIpd SET Status='FAILED',ErrorDetails = @exceptionErrorMessage , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
		
		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_INIT_DEALIPD',@logFeatureID);
		UPDATE @tblWaterfallLogStepIpd SET Status= 'FAILED' , EndTime =  GETDATE(), AdditonalDescription = 'Init process is failed due to the validation error: '
		 WHERE LogStepID=@LogStepId

		RAISERROR (@Message,
             @errorSeverity,
             @errorState )

		
	END CATCH

		INSERT INTO [cw].[LogExecution]
		(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
		SELECT LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate 
		 FROM @tblWaterfallLogStepIpd

		SELECT @Message
END

GO