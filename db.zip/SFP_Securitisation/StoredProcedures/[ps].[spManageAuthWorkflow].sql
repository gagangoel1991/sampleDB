USE [SFP_Securitisation]
GO

IF OBJECT_ID('[ps].[spManageAuthWorkflow]') IS NOT NULL
	DROP PROCEDURE [ps].[spManageAuthWorkflow] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=================================================      
--Author: Aditya Aggarwal      
--Date: 12-08-2021     
--Description: manage pool selection auth workflow     
--[ps].[spManageAuthWorkflow] 14,3,''    
--=================================================       
CREATE PROCEDURE [ps].[spManageAuthWorkflow]     
   @pWorkflowType   VARCHAR(100),        
   @pPsId   INT,           
   @pStatus INT,    
   @pStepName VARCHAR(100),     
   @pComment  VARCHAR(500)='',      
   @pUserName  VARCHAR(80)           
AS      
BEGIN      
	BEGIN TRY       
		DECLARE 
			@workflowStepId				INT,
			@workflowProcessId			INT,
			@ctWorkflow	VARCHAR(50) = 'Concentration_Test',
			@ecWorkflow	VARCHAR(50) = 'Eligibility_Criteria',
			@ecfWorkflow VARCHAR(50) = 'Custom_Field',
			@authoriseStep VARCHAR(50) = 'Authorise',
			@submitStep VARCHAR(50) = 'SendForAuthorisation',
			@ddcWorkflow VARCHAR(50) = 'DealDataCorrection',
			@lossWorkflow VARCHAR(50) = 'Loss_Management'
  
  		DECLARE @CurrentDateTime DATETIME = GETUTCDATE() 

		SET @workflowStepId=(SELECT cw.fnGetWorkflowStepId(@pStepName,@pWorkflowType));    
       
		BEGIN TRAN ManageWorkflow
  
		EXEC [cw].[spSaveWorkflowProcess] @pPsId, @workflowStepId, @pComment, @pUserName, @workflowProcessId OUTPUT
 
		IF @pWorkflowType=@ctWorkflow
		BEGIN  
			IF @pStepName=@authoriseStep    
				BEGIN    
					UPDATE [ps].[ConcentrationTest] 
				        SET [StatusId]=@pStatus,AuthorizedBy=@pUserName,AuthorizedDate=GETDATE() , ModifiedDate = @CurrentDateTime     
				        WHERE ConcentrationTestId=@pPsId AND isActive = 1  
				END    
			ELSE    
			BEGIN    
			    UPDATE [ps].[ConcentrationTest] SET [StatusId]=@pStatus, ModifiedDate = @CurrentDateTime  WHERE ConcentrationTestId=@pPsId AND isActive = 1  
			END  
		END
		ELSE IF @pWorkflowType=@ecWorkflow
		BEGIN  
			IF @pStepName=@authoriseStep    
				BEGIN    
					UPDATE [ps].[EligibilityCriteria] 
				        SET [EligibilityCriteriaStatusId]=@pStatus,AuthorizedBy=@pUserName,AuthorizedDate=GETDATE(),CommentsByAuthoriser=@pComment  
					  , ModifiedDate = @CurrentDateTime 
					WHERE EligibilityCriteriaId=@pPsId AND isActive = 1
				END    
			ELSE IF @pStepName=@submitStep
				BEGIN
				        UPDATE [ps].[EligibilityCriteria] SET [EligibilityCriteriaStatusId]=@pStatus,CommentsBySubmitter=@pComment  , ModifiedDate = @CurrentDateTime  
				        WHERE EligibilityCriteriaId=@pPsId AND isActive = 1  
				END
			ELSE
				BEGIN    
				        UPDATE [ps].[EligibilityCriteria] SET [EligibilityCriteriaStatusId]=@pStatus    , ModifiedDate = @CurrentDateTime 
				        WHERE EligibilityCriteriaId=@pPsId AND isActive = 1   
				END
		END
		ELSE IF @pWorkflowType=@ecfWorkflow
		BEGIN  
			IF @pStepName=@authoriseStep    
				BEGIN    
					UPDATE [ps].[EligibilityCriteriaField] 
				        SET [FieldStatusId]=@pStatus,AuthorizedBy=@pUserName,AuthorizedDate=GETDATE(),CommentsByAuthoriser=@pComment   , ModifiedDate = @CurrentDateTime 
				        WHERE EligibilityCriteriaFieldId=@pPsId AND isActive = 1  
				END    
			ELSE IF @pStepName=@submitStep 
				BEGIN    
				        UPDATE [ps].[EligibilityCriteriaField] SET [FieldStatusId]=@pStatus,CommentsBySubmitter=@pComment , ModifiedDate = @CurrentDateTime    
				        WHERE EligibilityCriteriaFieldId=@pPsId AND isActive = 1   
				END
			ELSE    
				BEGIN    
				        UPDATE [ps].[EligibilityCriteriaField] SET [FieldStatusId]=@pStatus , ModifiedDate = @CurrentDateTime    
				        WHERE EligibilityCriteriaFieldId=@pPsId AND isActive = 1  
				END
		END		
		ELSE IF @pWorkflowType=@ddcWorkflow  
		BEGIN
			    IF @pStepName=@authoriseStep        
				BEGIN        
					--UPDATE [corp].[DealDataCorrection]   
					-- SET DataCorrectionStatus=@pStatus,AuthorizedBy=@pUserName,AuthorizedDate=GETDATE(), ModifiedDate = @CurrentDateTime     
					-- WHERE DealDataCorrectionId=@pPsId AND isActive = 1   
		 
				UPDATE [corp].[DealOverrideParent]
				SET DataCorrectionStatus=@pStatus,AuthorizedBy=@pUserName,AuthorizedDate=GETDATE(), ModifiedDate = @CurrentDateTime     
				WHERE DealOverrideParentId=@pPsId AND isActive = 1  
				END  
				ELSE  
				BEGIN      
					--UPDATE [corp].[DealDataCorrection]  
					--SET DataCorrectionStatus=@pStatus, ModifiedDate = @CurrentDateTime, ModifiedBy = @pUserName   
					--WHERE DealDataCorrectionId = @pPsId AND isActive = 1 
		 
					UPDATE [corp].[DealOverrideParent]
				SET DataCorrectionStatus=@pStatus, ModifiedDate = @CurrentDateTime , ModifiedBy = @pUserName    
				WHERE DealOverrideParentId=@pPsId AND isActive = 1
				END 
		END
		ELSE IF @pWorkflowType=@lossWorkflow
		BEGIN
			UPDATE [corp].[LossManagement]
			SET [WorkflowStepId]=@workflowStepId, 
				ModifiedDate = @CurrentDateTime, 
				ModifiedBy = @pUserName,
				ManualRemovePartitionId = IIF(@pStepName = 'RemovedFromReview', [corp].[fnGetMaxPartitionId](), NULL)
			WHERE LossManagementId = @pPsId AND IsActive = 1
		END
		COMMIT TRAN
	END TRY      
	BEGIN CATCH      
		IF @@trancount > 0 ROLLBACK TRANSACTION ManageWorkflow;   
		DECLARE       
			@errorMessage     NVARCHAR(MAX),      
			@errorSeverity    INT,      
			@errorNumber      INT,      
			@errorLine        INT,      
			@errorState       INT;      
      
		SELECT       
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()      
      
		EXEC app.SaveErrorLog 1, 1, 'ps.spManageAuthWorkflow', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName      
        
		RAISERROR (@errorMessage,      
			@errorSeverity,      
			@errorState )      
	END CATCH      
END
GO
