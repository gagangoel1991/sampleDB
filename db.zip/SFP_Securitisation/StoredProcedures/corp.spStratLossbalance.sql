


USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratLossbalance]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratLossbalance]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------------------------------------------------------------  
  
  --Author: Mukesh Sharma
  --Date: 2023-02-27
  --Description:  Generating Strats for Lossbalance
  --Note- ASAtDate parameter is not required in this Strat but adding it to make compatible with strats framework
  --exec  [corp].[spStratLossbalance] @pAsAtDate='2023-01-31',@pDealId= 1,@pUserName=null
------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [corp].[spStratLossbalance]
(    @pAsAtDate DATE ,
	 @pDealId INT ,
	 @pUserName VARCHAR(100)=NULL
)
AS
BEGIN
	
            
            DECLARE 
            @msgtxt VARCHAR(100) = ''
			,@Asatdate DATE
 			,@DealIdS INT
			,@DealName Varchar(50)
		    ,@DealIdCommonSP INT
			,@PreviousQuarterDate Date
	        ,@CurrentQuarterMinDate Date



    BEGIN TRY
    SET @msgtxt = 'Calculating variables  ' + CONVERT(VARCHAR(20), getdate(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT
	SET @DealIdCommonSP                      = @pDealId
	SET @DealName                            =(SELECT DealName from [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealId=@pDealId  AND IsActive='Y')
	SET @DealIdS                             =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)
	SET @Asatdate						     = @pAsAtDate
	SET @PreviousQuarterDate			     = (SELECT DATEADD(MONTH,-3,asatdate)FROM [sfp].[syn_SfpModel_vw_Calendar_v1] 
											  WHERE asatdate=@Asatdate AND Regioncode='UK')

	SET @PreviousQuarterDate			     =(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]  
											   WHERE IsWorkingDay=1 AND MONTH(asatdate)=MONTH(@PreviousQuarterDate) 
											   AND YEAR(asatdate)=YEAR(@PreviousQuarterDate) AND Regioncode='UK')
	SET @CurrentQuarterMinDate			     =(SELECT DATEADD(MONTH, DATEDIFF(MONTH,0,DATEADD(MONTH,1,@PreviousQuarterDate)),0))



	 SELECT
	 CONVERT(DECIMAL(23,2),SUM(InitialLossAmount)) AS [Loss balances]	
	 FROM [corp].[LossManagement]  
	 WHERE dealid=@DealIdS 
	 AND IsActive=1 AND (WaterfallDateClaimed BETWEEN @CurrentQuarterMinDate AND EOMONTH (@Asatdate))
	 AND WorkflowStepId IN(90, 93, 94, 96,97)
 

	SET @msgtxt = 'End of strats generation : ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	END TRY
     BEGIN CATCH                  
     DECLARE       
	 @errorMessage     NVARCHAR(MAX),      
	 @errorSeverity    INT,      
	 @errorNumber      INT,      
	 @errorLine        INT,      
     @errorState       INT;      
     SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()     
     EXEC app.SaveErrorLog 2, 1, 'spStratLossbalance', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName   
     RAISERROR (@errorMessage,  @errorSeverity,  @errorState )              
     END CATCH   

  END
GO


