USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingLoansAndDepositsData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingLoansAndDepositsData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


--==================================  
--Author: Rajesh Sahu
--Date: 10-Feb-2023 
--Description: GET Booking Loans And Deposits 
--[cb].[spGetBookingLoansAndDepositsData] 6,60,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingLoansAndDepositsData] 
    @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  

BEGIN TRY  
    Declare @ValueDate Date;
	Declare @MaturityDate varchar(10);
	Declare @TradeType varchar(100);
	Declare @Book varchar(100);
	Declare @CounterParty varchar(500);
	Declare @PrincipalAmt DECIMAL(36, 18);
	Declare @NextIpd Date;
	Declare @NextBusinessDate VARCHAR(10);
	Declare @NWBLoanMaturityDate VARCHAR(30);

	IF EXISTS(SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#LoansAndDeposits') and type='U')
		Drop table #LoansAndDeposits
		
	CREATE TABLE #LoansAndDeposits
		(
			[Id] [int] IDENTITY(1,1) NOT NULL,
			[TradeType] [varchar](100) NULL,
			[Book] [varchar](100) NULL,
			[Counterparty] [varchar](500) NULL,
			[ValueDate] [varchar](10) NULL,
			[MaturityDate] [varchar](10) NULL,
			[PrincipalAmount] [decimal](38, 2) NULL,
			[RateType] [varchar](100) NULL,
			[Index] [varchar](100) NULL,
			[IndexRateTenor] [varchar](100) NULL,
			[Margin] [varchar](100) NULL,
			[AllinRate] [varchar](100) NULL,
			[Currency] [varchar](100) NULL,
			[Interest] [varchar](100) NULL,
			[DayCountConvention] [varchar](100) NULL,
			[Description] [varchar](500) NULL,
			[FlipIndicator] [varchar](100) NULL,
			[FlipCounterparty] [varchar](100) NULL,
			[FlipBook] [varchar](100) NULL,
			[GTCollection] [varchar](100) NULL			
		)
	
	SELECT   
		  @NextIpd = ipdDt.NextIPD,
		  @ValueDate = dir.IpdDate,
		  @MaturityDate = CONVERT(VARCHAR(30),cw.fnGetBusinessDate(datefromparts(year(DATEADD(month, 1, dir.IpdDate)), month(DATEADD(month, 1, dir.IpdDate)),1),'UK',0,0),103)
		FROM     
			 cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		JOIN cw.vwDealIPDDates did ON did.DealIpdId = di.DealIpdId
		WHERE   
			dir.DealIpdRunId = @pIPDRunId
			AND dir.IpdSequence <> 0 

	SET @NextBusinessDate =  CONVERT(VARCHAR(10), (SELECT [cw].[fnGetBusinessDate] (@ValueDate, 'UK', 1, 0)),126);
	
	Select @NWBLoanMaturityDate = CONVERT(VARCHAR(30), [Value], 103) from [cb].[vwBookingLineItemValue] where LineItemInternalName = 'NWB_Loan_Maturity_Date_Principal_NGL07' AND DealIpdRunId = @pIPDRunId
	
	IF EXISTS(SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#LineItems') and type='U')
		Drop table #LineItems

		CREATE Table #LineItems
		(SortOrder INT, LineItemInternalName varchar(255), MaturityDate Date, RateType VARCHAR(20), [Index] VARCHAR(20), IndexRateTenor VARCHAR(20), Margin VARCHAR(20), AllInRate VARCHAR(20)
		, FlipIndicator VARCHAR(10), FlipCounterParty VARCHAR(255), FlipBook VARCHAR(100))

		Insert INTO #LineItems
		(SortOrder, LineItemInternalName, MaturityDate, RateType, [Index], IndexRateTenor, Margin, AllInRate, FlipIndicator, FlipCounterParty, FlipBook)

		Select 1, 'New_Proceeds_Loan_NCA_03', @NextIpd, 'Fixed', '', '', null, '', 'TRUE', 'NWBPLC GT DEIMOS COL', 'GTNWDEIMOS'
		UNION ALL	
		Select 2, 'New_NW_Capital_Contribution_NCA_04', @NextIpd, 'Fixed', '', '', null, '0.00', 'TRUE', 'NWBPLC GT DEIMOS COL', 'NWLLP_TRANS'
		UNION ALL	
		Select 3, 'New_Cumulative_Daily_GIC_Loan_NCBD_20', @NextBusinessDate, 'Index', 'LIBOR', '1m', -8.00, '', 'FALSE', '', ''
		UNION ALL	
		Select 4, 'New_Credit_Reserve_Ledger_IPD+1_NCBD_21', @NextBusinessDate, 'Index', 'LIBOR', '1m', -8.00, '', 'FALSE', '', ''
		UNION ALL	
		Select 5, 'New_Retained_Principal_IPD_NCBD_23', Convert(datetime, @NWBLoanMaturityDate, 103), 'Index', 'LIBOR', '1m', -8.00, '', 'FALSE', '', ''
		UNION ALL	
		Select 6, 'New_Daily_GIC_Loan_NCBD_12', @NextIpd, 'Index', 'LIBOR', '1m', -8.00, '', 'TRUE', 'RBS Covered LLP Deposit Account', 'GTSPV_DEIMOS' 
		UNION ALL	
		Select 7, 'New_Credit_Reserve_Ledger_IPD_NCBD_13', @NextIpd, 'Index', 'LIBOR', '1m', -8.00, '', 'TRUE', 'RBS Covered LLP Deposit Account', 'GTSPV_DEIMOS' 
		UNION ALL	
		Select 8, 'New_Retained_Principal_NCBD_14', @NextIpd, 'Index', 'LIBOR', '1m', -8.00, '', 'TRUE', 'RBS Covered LLP Deposit Account', 'GTSPV_DEIMOS' 
		UNION ALL	
		Select 9, 'Additional_Cash_on_Account_from_Trans_NCBD_22', Convert(datetime, @NWBLoanMaturityDate, 103), 'Index', 'LIBOR', '1m', -8.00, '', 'FALSE', '' , ''


		Select bv.AccountTypeLookupName as TradeType, BookName as Book, CounterpartyName as Counterparty, CONVERT(VARCHAR(30), @ValueDate,103) AS [ValueDate], CONVERT(VARCHAR(30), MaturityDate,103) AS MaturityDate
		, ABS(TRY_CAST(bv.[Value] AS DECIMAL(38, 2))) AS PrincipalAmount, RateType,  [Index], IndexRateTenor, Margin, AllInRate, bv.Currency, '' as Interest
		, 'Act/365 Fixed' as DayCountConvention, '' as [Description], FlipIndicator, FlipCounterParty, FlipBook, 'FALSE' as GTCollection
		FROM #LineItems bg
		LEFT JOIN [cb].[vwBookingLineItemValue] bv ON bg.LineItemInternalName =bv.LineItemInternalName
		LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
		where bv.DealIpdRunId = @pIPDRunId AND dir.IsCurrentVersion = 1
		order by bg.SortOrder

END TRY   
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetBookingLoansAndDepositsData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END


GO


