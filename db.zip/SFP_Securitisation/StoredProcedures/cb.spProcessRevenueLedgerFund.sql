USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cb].[spProcessRevenueLedgerFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessRevenueLedgerFund]
GO

/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 11/17/2022 10:05:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessRevenueLedgerFund] 
( 
  /* 
 *   Author: Arun 
 *   Date:  24.11.2022
 *   Description:  Fill Revenue ledger Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessRevenueLedgerFund] 33,'fm\shriyad'
 *    select * from [Cb].[SwapCollateralFund] where dealipdrunid=33           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
        

			DECLARE @dealId  INT, 
				@coveredBondFundId INT,
				@ipdDate DATE,
				@revenueLedgerFund_bF decimal(38,16),
				@revenueLedgerAmountReceived decimal(38,16),
				@revenueLedgerOthersReceived decimal(38, 16),
				@cashCapitalContrubution decimal(38, 16),
				@releaseToARR decimal(38, 16),
				@preAccelerationCredit decimal(38, 16),
				@revenueLedgerFund_cf  decimal(38, 16)
				  
			SELECT @dealId = DealId, 
			@ipdDate = IpdDate
			FROM   cw.vwDealIpdRun dir
			WHERE  DealIpdRunId = @pDealIpdRunId 
		  
			
			DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

			Select @coveredBondFundId = CoveredBondFundId FROM	cfgcb.CoveredBondFund cbf
                WHERE  cbf.InternalName = 'RevenueLedgerFund' 

			SELECT @revenueLedgerFund_bF = RevenueLedgerFund_cf
			FROM cb.[RevenueLedgerFund] scf
			JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
			AND  cbf.InternalName = 'RevenueLedgerFund'
			WHERE DealIpdRUnId = @dealPreviousIpdRunId

			
			Select @revenueLedgerAmountReceived = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName in ('PreAvailableRevenueReceipts_1.100' , 'PreAvailableRevenueReceipts_1.200')
			and DealIpdRunId=@pDealIpdRunId
		
			SET @revenueLedgerOthersReceived=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName   = 'TermAdvanceBorrowedbyLLP'
									AND ManualFieldGroupInternalName = 'TermAdvanceAppliedToCreditReserveFund'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @cashCapitalContrubution=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  =  'NWB_terminationPayment'
									AND ManualFieldGroupInternalName = 'AvailableRevenueReceipts'
									AND DealIpdRunId = @pDealIpdRunId);


			SET @releaseToARR = @revenueLedgerAmountReceived 

			Select @preAccelerationCredit = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='RevenuePriorityofPayments_8.000'
			and DealIpdRunId=@pDealIpdRunId

          DELETE FROM cb.[RevenueLedgerFund] WHERE DealIpdRunId = @pDealIpdRunId 

          INSERT INTO cb.[RevenueLedgerFund] 
                      ( DealIpdRunId,
						CoveredBondFundId,
						RevenueLedgerFund_bF,
						RevenueLedgerReceiptsReceived,
						RevenueLedgerOthersReceived,
						CashCapitalContrubution,
						ReleaseToARR,
						PreAccelerationCredit,
						RevenueLedgerFund_cf,
						IsActive,
						CreatedBy,
						CreatedDate,
						ModifiedBy,
						ModifiedDate) 
					SELECT @pDealIpdRunId
						,@coveredBondFundId
						,IsNull(@revenueLedgerFund_bF,0)
						,@revenueLedgerAmountReceived
						,@revenueLedgerOthersReceived
						,@cashCapitalContrubution
						,@releaseToARR
						,@preAccelerationCredit
						,@revenueLedgerAmountReceived - @releaseToARR
						 ,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessRevenueLedgerFund', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END