USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spGetIPDRevenueWaterfall') IS NOT NULL
	DROP PROCEDURE cb.spGetIPDRevenueWaterfall
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cb.spGetIPDRevenueWaterfall
(
	@pDealIpdRunId INT,
	@pUserName	VARCHAR(80)
/*
exec cb.spGetIPDRevenueWaterfall 50,'fm\shriyad'
*/
)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @sourceId_DueAmount_cols AS NVARCHAR(MAX), @Max_SourceId_DueAmount_cols AS NVARCHAR(MAX)
		DECLARE @sourceId_AmountPaidFromSource_cols AS NVARCHAR(MAX), @Max_SourceId_AmountPaidFromSource_cols AS NVARCHAR(MAX)
		DECLARE @sourceId_Shortfall_cols AS NVARCHAR(MAX), @Max_SourceId_Shortfall_cols AS NVARCHAR(MAX)
		DECLARE @sourceId_IsEligible_cols AS NVARCHAR(MAX), @Max_SourceId_IsEligible_cols AS NVARCHAR(MAX)
		DECLARE @colNameToDisplay AS NVARCHAR(MAX);

		DECLARE @dealId  SMALLINT
		SELECT @dealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId

		IF( Object_id('tempdb..#tempSourceDisplayName') IS NOT NULL ) 
		DROP TABLE #tempSourceDisplayName 

		CREATE TABLE #tempSourceDisplayName (SourceName varchar(200), SourceDisplayName varchar(500))

		INSERT INTO #tempSourceDisplayName VALUES
		 ('Pre Available Principal Receipts','AvailablePrincipalReceipt')
		,('Pre Available Revenue Receipts','AvailableRevenueReceipt')

		IF( Object_id('tempdb..#tempWaterfallEligibleSource') IS NOT NULL ) 
			DROP TABLE #tempWaterfallEligibleSource 

		CREATE TABLE #tempWaterfallEligibleSource 
		(WaterfallSourceId int, SourceDisplayName varchar(200), [priority] decimal(9,3))

		INSERT INTO #tempWaterfallEligibleSource
			SELECT ws.WaterfallSourceId, temp.SourceDisplayName, ws.[priority]
			FROM cfgCW.WaterfallSource ws
			JOIN cfgcw.WaterfallSourceEligibility wlse ON wlse.DealId = ws.DealId
			JOIN cfgcw.waterfallCategory wc  ON wc.DealId = wlse.DealId AND wlse.EligibleWaterfallSourceId=ws.WaterfallSourceId 
			JOIN cfgcw.waterfallLineItem wli  ON wli.waterfallCategoryId = wc.waterfallCategoryId
											AND wli.waterfallLineItemId = wlse.waterfallLineItemId
			JOIN #tempSourceDisplayName temp ON temp.SourceName = ws.SourceName
			WHERE 
			wc.InternalName='RevenuePriorityofPayments'
			AND ws.DealId=@dealId 
			AND ws.IsActive=1 
			GROUP BY ws.WaterfallSourceId,SourceDisplayName,[priority]
			ORDER BY [priority]

		SELECT @colNameToDisplay=STUFF((SELECT 
		+',' + QUOTENAME('IsEligible_'+SourceDisplayName)
		+',' + QUOTENAME('DueAmount_'+SourceDisplayName)
		+',' + QUOTENAME('AmountPaidFromSource_'+SourceDisplayName)
		+',' + QUOTENAME('ShortfallAfter_'+SourceDisplayName)
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')

				
		SELECT 
		-------------------DueAmount
				@sourceId_DueAmount_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+10000) 
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_DueAmount_cols
				=STUFF((SELECT ',max(' + QUOTENAME(WaterfallSourceId+10000)+') as ' + QUOTENAME('DueAmount_'+SourceDisplayName) +''
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				-------------------AmountPaidFromSource
				,@sourceId_AmountPaidFromSource_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+100000000) 
						FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_AmountPaidFromSource_cols
				=STUFF((SELECT 
				',max(' + QUOTENAME(WaterfallSourceId+100000000) +') as ' + QUOTENAME('AmountPaidFromSource_'+SourceDisplayName) +''
						FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
					-------------------ShortfallAfter_
				,@sourceId_Shortfall_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+100000000000000) 
						FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_Shortfall_cols
				=STUFF((SELECT  ',max(' + QUOTENAME(WaterfallSourceId+100000000000000) +') as ' + QUOTENAME('ShortfallAfter_'+SourceDisplayName) +'' FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				-------------------IsEligible
				,@sourceId_IsEligible_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+1000000000000) 
						FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_IsEligible_cols=STUFF((SELECT 
				',max(' + QUOTENAME(WaterfallSourceId+1000000000000) +') as ' + QUOTENAME('IsEligible_'+SourceDisplayName) +'' 
						FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')


				IF(object_id('tempdb..#finalTable') IS NOT NULL) DROP TABLE #finalTable

				DECLARE  @query  AS NVARCHAR(MAX);

				SET @query ='SELECT   WaterfallLineItemId,max(TotalDueAmount) as TotalDueAmount
				,'+@Max_SourceId_DueAmount_cols+','+@Max_SourceId_AmountPaidFromSource_cols+',
				'+@Max_SourceId_Shortfall_cols+','+@Max_SourceId_IsEligible_cols+',max(TotalPaidAmount) as TotalPaidAmount
				into #finalTable
				 from 
					 (
						select WaterfallLineItemId
						,[cw].[fnCalculateRPPParentChildValue](WaterfallLineItemId,SourceId,'+CONVERT(VARCHAR(200),@pDealIpdRunId)+',''TotalDueAmount'',TotalDueAmount) TotalDueAmount
						,[cw].[fnCalculateRPPParentChildValue](WaterfallLineItemId,SourceId,'+CONVERT(VARCHAR(200),@pDealIpdRunId)+',''DueAmount'',DueAmount) DueAmount
						,[cw].[fnCalculateRPPParentChildValue](WaterfallLineItemId,SourceId,'+CONVERT(VARCHAR(200),@pDealIpdRunId)+',''AmountPaidFromSource'',AmountPaidFromSource) AmountPaidFromSource
						,[cw].[fnCalculateRPPParentChildValue](WaterfallLineItemId,SourceId,'+CONVERT(VARCHAR(200),@pDealIpdRunId)+',''RemainingDueAmount'',RemainingDueAmount) Shortfall
						,CAST([cw].[fnCalculateRPPParentChildValue](WaterfallLineItemId,SourceId, '+CONVERT(VARCHAR(200),@pDealIpdRunId)+' ,''IsEligible'', IsEligible)  AS TINYINT) IsEligible
						,[cw].[fnCalculateRPPParentChildValue](WaterfallLineItemId,SourceId,'+CONVERT(VARCHAR(200),@pDealIpdRunId)+',''TotalPaidAmount'',TotalPaidAmount) TotalPaidAmount
						,SourceId+10000 as SourceId_DueAmount
						,SourceId+100000000 as SourceId_AmountPaidFromSource
						,SourceId+100000000000000 as SourceId_Shortfall
						,SourceId+1000000000000 as SourceId_IsEligible
						from cw.RevenueWaterfallPayment  where DealIpdRunId='+CONVERT(VARCHAR(200),@pDealIpdRunId)+' 
					) x
					pivot 
					(
						max(DueAmount)
						for SourceId_DueAmount in ('+@sourceId_DueAmount_cols+')
					) p1 
					
					pivot 
					(
						max(AmountPaidFromSource)
						for SourceId_AmountPaidFromSource in ('+@sourceId_AmountPaidFromSource_cols+')
					) p3
					
					pivot 
					(
						max(Shortfall)
						for SourceId_Shortfall in ('+@sourceId_Shortfall_cols+')
					) p6
					pivot 
					(
						max(IsEligible)
						for SourceId_IsEligible in ('+@sourceId_IsEligible_cols+')
					) p5 
					
					GROUP BY WaterfallLineItemId
					ORDER BY WaterfallLineItemId;

					select wli.WaterfallLineItemId, wli.DisplayName LineItem,TotalDueAmount,
					'+@colNameToDisplay+'
					,TotalPaidAmount
					,CAST(Case When wliParent.ParentWaterfallLineItemId is NOT NULL Then 1 Else 0 End AS BIT) as IsParent,
					Case When wliParent.ParentWaterfallLineItemId is NOT NULL Then wliParent.ParentWaterfallLineItemId Else ISNULL(wli.ParentWaterfallLineItemId, 0) End as ParentWaterfallLineItemId
					from #finalTable f JOIN  cfgCW.WaterfallLineItem wli ON f.WaterfallLineItemId=wli.WaterfallLineItemId
					JOIN cfgCW.WaterfallCategory wc ON wc.WaterfallCategoryId =wli.WaterfallCategoryId
					LEFT JOIN
					(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
					where  wc.DealId='+CONVERT(varchar(200),@dealId)+' and wli.IsActive=1 order by wli.SortOrder
							'
					PRINT @query
					EXECUTE(@query)


	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spGetIPDRevenueWaterfall', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO