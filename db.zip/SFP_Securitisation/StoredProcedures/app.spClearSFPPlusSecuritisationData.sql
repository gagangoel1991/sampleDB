
USE [SFP_Securitisation]
GO

IF EXISTS 
(
	SELECT 1 FROM sys.objects
	WHERE object_id = OBJECT_ID(N'[app].[spClearSFPPlusSecuritisationData]')   
		AND type IN (N'P', N'PC')
)
	DROP PROCEDURE [app].[spClearSFPPlusSecuritisationData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spClearSFPPlusSecuritisationData]
AS
BEGIN

	BEGIN TRY

	------------------ Clear Pool Selection Data ---------------------- 

			EXEC [ps].[spClearSFPPlusPoolData];

			EXEC [ps].[spClearECData];

			EXEC [ps].[spClearCTData];

			EXEC [ps].[spClearFieldData];

	---------------------------------------------------------------------



	END TRY
	BEGIN CATCH

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		
		EXEC app.SaveErrorLog 2, 1, 'spClearSFPPlusSecuritisationData',
			@errorNumber, @errorSeverity, @errorLine, @errorMessage, 'system'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;


END
GO
