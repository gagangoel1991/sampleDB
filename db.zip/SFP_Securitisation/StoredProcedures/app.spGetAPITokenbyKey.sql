USE [SFP_Securitisation]
GO

IF OBJECT_ID('app.spGetAPITokenbyKey') IS NOT NULL
	DROP PROCEDURE app.spGetAPITokenbyKey
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Saurabh Bhatia
--Date: 18-06-2022 
--Description: GET API Token by Key 
--	DECLARE @Token UNIQUEIDENTIFIER
--	EXEC app.spGetAPITokenbyKey 'abc',@Token OUTPUT,'EUROPA\bhasaaa'
--	SELECT @Token
--================================== 
CREATE PROCEDURE app.spGetAPITokenbyKey 
	 @pKey VARCHAR(2000)
	,@pToken UNIQUEIDENTIFIER OUTPUT
	,@pUserName VARCHAR(80)
AS
BEGIN
	
	BEGIN TRY

	SELECT @pToken = Token
	FROM app.APIToken
	WHERE [Key] = @pKey;

	IF (@pToken IS NULL)
	BEGIN
		DECLARE @OutputTbl TABLE (Token UNIQUEIDENTIFIER)

		INSERT INTO app.APIToken ([Key],CreatedBy,ModifiedBy)
		OUTPUT INSERTED.Token
		INTO @OutputTbl(Token)
		VALUES (@pKey,@pUserName,@pUserName)

		SELECT TOP 1 @pToken = Token
		FROM @OutputTbl
	END
	END TRY
	BEGIN CATCH

		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'app.spGetAPITokenbyKey'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO
