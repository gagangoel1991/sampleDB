USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetStratMasterByType]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetStratMasterByType]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [cw].[spGetStratMasterByType]
/*
 * Author: Kapil Sharma
 * Date:	10.12.2020
 * Description:  This will return the strats master list based on start type
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/		
@pStratTypeId			TINYINT,
@pUserName				VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		
		SELECT 
			st.StratId,
			st.Name AS [Name],
			st.Description
		FROM
			cfgCW.IR_Strat st
		JOIN
			[cfgCW].[IR_StratType] sType ON sType.StratTypeId = st.StratTypeId
		WHERE
			sType.StratTypeId = @pStratTypeId
		ORDER BY
			st.Name ASC
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetStratMasterByType', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
