USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cb].[spProcessCapitalAccountLedger]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessCapitalAccountLedger]
GO

/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 11/17/2022 10:05:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessCapitalAccountLedger] 
( 
  /* 
 *   Author: Arun 
 *   Date:  24.11.2022
 *   Description:  Fill Principal ledger Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessPaymentLedgerFund] 33,'fm\shriyad'
 *    select * from [Cb].[SwapCollateralFund] where dealipdrunid=33           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
        

			DECLARE @dealId  INT, 
			@calendarStartDt			DATE,
			@calendarEndDt			DATE,
			@coveredBondFundId INT,
			@ipdDate DATE, @prevIpdDate DATE, 
			@CapitalAccountLedger_bF decimal(38,16),
			@CapitalDistribution decimal(38,16),
			@CapitalDistributionLLPtoNW decimal(38,16),
			@LossesSoldToLLP decimal(38,16),
			@CapitalisedInterest decimal(38,16),
			@BorrowerLoanAdvance decimal(38,16),
			@LoanSecuritySaleToLLP decimal(38,16),
			@SubsitutionAssetSale decimal(38,16),
			@PaymentTermination decimal(38,16),
			@PaymentCouponAmount decimal(38,16),
			@PaymentCouponAmountShortfall decimal(38,16),
			@PaymentRedemtionAmount decimal(38,16),
			@CashCapitalRedemtionContribution decimal(38,16),
			@CapitalAccountLedger_cf decimal(38,16)

			SELECT 	@dealId = d.DealId, @ipdDate = Ipd
			, @calendarStartDt = CAST(d.CollectionCalendarStart AS DATE) 
			, @calendarEndDt= CAST(d.CollectionCalendarEnd AS DATE) 			
			FROM cw.vwDealIpdDates d
			JOIN cw.vwDealIpdRun r			
			ON CAST(d.IPD AS DATE) = r.IpdDate
				AND d.DealIpdId =r.DealIpdId
			Where DealIpdRunId=@pDealIpdRunId

		  
			DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

			SELECT @prevIpdDate = IpdDate FROM cw.vwDealIpdRun dir WHERE  DealIpdRunId = @dealPreviousIpdRunId 

			Select @coveredBondFundId = CoveredBondFundId FROM	cfgcb.CoveredBondFund cbf
                WHERE  cbf.InternalName = 'CapitalAccountLedger' 

			SELECT @CapitalAccountLedger_bF = CapitalAccountLedger_cf
			FROM [cb].[CapitalAccountLedger] scf
			JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
			AND  cbf.InternalName = 'CapitalAccountLedger'
			WHERE DealIpdRUnId = @dealPreviousIpdRunId

		
			Select @CapitalDistribution = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='PrincipalPriorityofPayments_6.000'
			and DealIpdRunId=@pDealIpdRunId

			SET @CapitalDistributionLLPtoNW =	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='NwTermAdvanceLLP'
									AND ManualFieldGroupInternalName = 'CapitalDistributions'
									AND DealIpdRunId = @pDealIpdRunId);
			
			SET @LossesSoldToLLP =	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='LossesLoanSoldFroCapital'
									AND ManualFieldGroupInternalName = 'LossesonLoans'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @CapitalisedInterest= (SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='IncreaseOSCapitalBalanceExpenses'
									AND ManualFieldGroupInternalName = 'CapitalContributionsInKind'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @BorrowerLoanAdvance =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='IncreaseOSCapitalBalanceBorrower'
									AND ManualFieldGroupInternalName = 'CapitalContributionsInKind'
									AND DealIpdRunId = @pDealIpdRunId);
									

			SET @LoanSecuritySaleToLLP =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='LoansSaleRelatedSecurityLLP'
									AND ManualFieldGroupInternalName = 'CapitalContributionsInKind'
									AND DealIpdRunId = @pDealIpdRunId);
			
			SET @SubsitutionAssetSale =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='SubstitutionSaleAssetsLLP'
									AND ManualFieldGroupInternalName = 'CapitalContributionsInKind'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @PaymentTermination =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='NWB_terminationPayment'
									AND ManualFieldGroupInternalName = 'AvailableRevenueReceipts'
									AND DealIpdRunId = @pDealIpdRunId);
			
			SET @PaymentCouponAmount =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='CouponPaymentLedger_CashCapitalContribution'
									AND ManualFieldGroupInternalName = 'CouponPaymentLedger'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @PaymentCouponAmountShortfall =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='CouponPaymentLedger_CashCapitalShortfallContribution'
									AND ManualFieldGroupInternalName = 'CouponPaymentLedger'
									AND DealIpdRunId = @pDealIpdRunId);


			SET @PaymentRedemtionAmount =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='RequiredRedemptionSeriesHardBullet'
									AND ManualFieldGroupInternalName = 'CashCapitalContributions'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @CashCapitalRedemtionContribution  =(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='CashCapital_RedemptionCoveredBond'
									AND ManualFieldGroupInternalName = 'CashCapitalContributions'
									AND DealIpdRunId = @pDealIpdRunId);
			
			SET @CapitalAccountLedger_cf = ( IsNull(@CapitalAccountLedger_bF,0) - @CapitalDistribution - @CapitalDistributionLLPtoNW - @LossesSoldToLLP )
			+ ( @CapitalisedInterest + @BorrowerLoanAdvance + @LoanSecuritySaleToLLP + @PaymentTermination + @CashCapitalRedemtionContribution)

			DELETE FROM [cb].[CapitalAccountLedger] WHERE DealIpdRunId = @pDealIpdRunId 

			INSERT INTO [cb].[CapitalAccountLedger] 
						  ( DealIpdRunId,
							CoveredBondFundId,
							CapitalAccountLedger_bF,
							CapitalDistribution,
							CapitalDistributionLLPtoNW,
							LossesSoldToLLP,
							CapitalisedInterest,
							BorrowerLoanAdvance,
							LoanSecuritySaleToLLP,
							SubsitutionAssetSale,
							PaymentTermination,
							PaymentCouponAmount,
							PaymentCouponAmountShortfall,
							PaymentRedemtionAmount,
							CashCapitalRedemtionContribution,
							CapitalAccountLedger_cf,
							IsActive,
							CreatedBy,
							CreatedDate,
							ModifiedBy,
							ModifiedDate) 
				SELECT @pDealIpdRunId,
							@coveredBondFundId,
							IsNull(@CapitalAccountLedger_bF,0),
							@CapitalDistribution,
							@CapitalDistributionLLPtoNW,
							@LossesSoldToLLP,
							@CapitalisedInterest,
							@BorrowerLoanAdvance,
							@LoanSecuritySaleToLLP,
							@SubsitutionAssetSale,
							@PaymentTermination,
							@PaymentCouponAmount,
							@PaymentCouponAmountShortfall,
							@PaymentRedemtionAmount,
							@CashCapitalRedemtionContribution,
							@CapitalAccountLedger_cf
							 ,1, 
							 @pUserName, 
							 Getdate(), 
							 @pUserName ,
							 Getdate()

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessPaymentLedgerFund', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END