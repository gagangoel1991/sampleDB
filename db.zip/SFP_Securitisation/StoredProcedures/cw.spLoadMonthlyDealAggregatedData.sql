USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spLoadMonthlyDealAggregatedData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadMonthlyDealAggregatedData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cw].[spLoadMonthlyDealAggregatedData]
/*-------------------------------------------------------  
 * Author Arun Kumar
 * Date 20.10.2020  
 * Description  This will load the SFP monthly collection data in temporary table for further transformation  
 * cw.spLoadMonthlyDealAggregatedData 1, '01-DEC-2020' --Dunmore of collection period upto 31-Aug-20
 * Change History  
 * --------------  
 * Author  	Date  			Description  
 * Kapil S		26-Feb-2020		Implemented the common generic logic and use daily collection data for some fields
-------------------------------------------------------*/  
(  
	@pFeedRunLogId				INT,  
	@pAsAtDate					DATETIME,
	@pRecalOnlyDailyColChg		BIT = 0 -- This flag is used to re-calculate only daily collection related aggregated values
)  
AS   
BEGIN   

    DECLARE 
        @dealName							VARCHAR(100),
        @mortgageDealId						INT,
		@dealId								INT,
        @fromCollectionDate					DATETIME,
		@fromCollectionDatePrevMonth		DATETIME,
		@fromCollectionDatePrev2Month		DATETIME,
		@toCollectionDate					DATETIME,
		@partitionId						INT,
		@vintageDate						DATE,
		@aggregatedFieldId					SMALLINT,
		@dailyColFieldName					VARCHAR(100),
		@prevMonthCorrelatedDate			DATETIME,
		@prev2MonthCorrelatedDate			DATETIME,
		@value1								DECIMAL(38,16),
		@value2								DECIMAL(38,16),
		@value3								DECIMAL(38,16),
		@monthToBeProcessed					DATETIME,
		@dealRegionCode						VARCHAR(10),
		@loanCount							INT,
		@dealPoolTotal						DECIMAL(38,16)

	BEGIN TRY  
	
		--As batch will be run on first day of each month for prev month
		SET @monthToBeProcessed = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-2)) 
		SET @fromCollectionDatePrevMonth = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-3)) 
		SET @fromCollectionDatePrev2Month = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-4)) 
		SET @toCollectionDate = EOMONTH(@pAsAtDate, -1) 
		

		--check temp table if exists
		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult') IS NOT NULL DROP TABLE #tmpMortgageLoanResult
		IF OBJECT_ID('tempdb..#tmpAggregatedData') IS NOT NULL DROP TABLE #tmpAggregatedData
		IF OBJECT_ID('tempdb..#tmpRangeText') IS NOT NULL DROP TABLE #tmpRangeText
			
		CREATE TABLE #tmpAggregatedData(CorrelatedDate DATE, DealId INT, FieldId SMALLINT, LoanBalance DECIMAL(38, 16),  MinBalance DECIMAL(38, 16), MaxBalance DECIMAL(38, 16), WeightedAvgBalance DECIMAL(38, 16), LoanCount INT)
		CREATE TABLE #tmpRangeText(Id SMALLINT, RangeText VARCHAR(40));

		SELECT * INTO #tmpMortgageLoanResult FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1
		
		DECLARE cursorCWDeal CURSOR FOR     
		SELECT DISTINCT MortgageDealId, DealId, DealRegionCode FROM [cw].[vw_ActiveDeal] WHERE DealId IN(14, 15, 6)
  
		OPEN cursorCWDeal    
  
		FETCH NEXT FROM cursorCWDeal INTO @mortgageDealId, @dealId, @dealRegionCode
		WHILE @@FETCH_STATUS = 0    
		BEGIN 
			TRUNCATE TABLE #tmpMortgageLoanResult;
			IF OBJECT_ID('tempdb..#MonthInArrear') IS NOT NULL DROP TABLE #MonthInArrear

			--Get the partition id, and last working date of the month
			SELECT 
				TOP 1 @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), AsAtDate, 112)) ,
				@vintageDate =  AsAtDate,
				@toCollectionDate = AsAtDate
			FROM 
				sfp.syn_SfpModel_vw_Calendar_v1
			WHERE 
				Month = Month(@monthToBeProcessed)  AND year = Year(@monthToBeProcessed)  
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
			ORDER BY	
				AsAtDate DESC  

			---Get the first working day of the month
			SELECT 
				TOP 1 @fromCollectionDate = AsAtDate
			FROM 
				sfp.syn_SfpModel_vw_Calendar_v1
			WHERE 
				Month = Month(@monthToBeProcessed) AND year = Year(@monthToBeProcessed)  
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
			ORDER BY	
				AsAtDate ASC  

			-----(Previous-1) month last business date i.e. if we are fetching data for May 2020 then we need the last business day of Apr2020
			SELECT 
				TOP 1 @prevMonthCorrelatedDate =  AsAtDate
			FROM 
				sfp.syn_SfpModel_vw_Calendar_v1
			WHERE 
				Month = Month(@fromCollectionDatePrevMonth) AND year = Year(@fromCollectionDatePrevMonth)  
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
			ORDER BY	
				AsAtDate DESC

			-----(Previous-2) month last business date i.e. if we are fetching data for May 2020 then we need the last business day of Apr2020
			SELECT 
				TOP 1 @prev2MonthCorrelatedDate =  AsAtDate
			FROM 
				sfp.syn_SfpModel_vw_Calendar_v1
			WHERE 
				Month = Month(@fromCollectionDatePrev2Month) AND year = Year(@fromCollectionDatePrev2Month)  
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
			ORDER BY	
				AsAtDate DESC

			IF @pRecalOnlyDailyColChg = 0
			BEGIN
				--Checking and loading the mortgage field data into the base table from SFP
				EXEC [CW].[spCheckAndLoadMortgageFieldData] @vintageDate, @mortgageDealId
				INSERT INTO #tmpMortgageLoanResult   
				SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @mortgageDealId

				--Set the toal loan count and deal pool total
				SELECT @loanCount = COUNT(*) FROM #tmpMortgageLoanResult
				SELECT @dealPoolTotal = SUM(ISNULL(OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) FROM #tmpMortgageLoanResult WHERE OUTSTANDNG_CAPITAL_BALANCE_AMT >=0

				PRINT 'Execution completed -  Mortgage Commmon SP'

				--MIA Fields Data Calculation
				SELECT @dealId AS DealId, MortgageAccountKey, MortgageSubAccountKey, OUTSTANDNG_CAPITAL_BALANCE_AMT, MONTHS_IN_ARREARS,
				CASE WHEN MONTHS_IN_ARREARS <1 OR MONTHS_IN_ARREARS IS NULL THEN 'MIA_LT1'
				WHEN MONTHS_IN_ARREARS >=1 AND MONTHS_IN_ARREARS <2 THEN 'MIA_GtEq1_LT2'
				WHEN MONTHS_IN_ARREARS >=2 AND MONTHS_IN_ARREARS <3 THEN 'MIA_GtEq2_LT3'
				WHEN MONTHS_IN_ARREARS >=3 AND MONTHS_IN_ARREARS <4 THEN 'MIA_GtEq3_LT4'
				WHEN MONTHS_IN_ARREARS >=4 AND MONTHS_IN_ARREARS <5 THEN 'MIA_GtEq4_LT5'
				WHEN MONTHS_IN_ARREARS >=5 AND MONTHS_IN_ARREARS <6 THEN 'MIA_GtEq5_LT6'
				WHEN MONTHS_IN_ARREARS >=6 AND MONTHS_IN_ARREARS <7 THEN 'MIA_GtEq6_LT7'
				WHEN MONTHS_IN_ARREARS >=7 AND MONTHS_IN_ARREARS <8 THEN 'MIA_GtEq7_LT8'
				WHEN MONTHS_IN_ARREARS >=8 AND MONTHS_IN_ARREARS <9 THEN 'MIA_GtEq8_LT9'
				WHEN MONTHS_IN_ARREARS >=9 AND MONTHS_IN_ARREARS <10 THEN 'MIA_GtEq9_LT10'
				WHEN MONTHS_IN_ARREARS >=10 AND MONTHS_IN_ARREARS <11 THEN 'MIA_GtEq10_LT11'
				WHEN MONTHS_IN_ARREARS >=11 AND MONTHS_IN_ARREARS <12 THEN 'MIA_GtEq11_LT12'
				WHEN MONTHS_IN_ARREARS >=12 AND MONTHS_IN_ARREARS <24 THEN 'MIA_GtEq12_LT24'
				WHEN MONTHS_IN_ARREARS >=24 THEN 'MIA_GtEq24' END AS BandRange
				INTO #MonthInArrear
				FROM   
					#tmpMortgageLoanResult
		
				--Inserting the MIA data
				INSERT INTO #tmpAggregatedData(CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount) 
				SELECT 
					@vintageDate,
					tmp.DealId, 
					field.DealAggregatedFieldId,
					CAST(ISNULL(SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT),0) AS DECIMAL(38, 16)) 'LoanBalance', 
					CAST(MIN(ISNULL(OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))  AS DECIMAL(38, 16)) 'MinBalance',
					CAST(MAX(ISNULL(OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))  AS DECIMAL(38, 16)) 'MaxBalance',
					CAST(ISNULL(SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT),0) AS DECIMAL(38, 16))/COUNT(MortgageSubAccountKey) 'WeightedAvgBalance',
					COUNT(MortgageSubAccountKey) AS LoanCount
				FROM 
					#MonthInArrear tmp
				JOIN
					cfgCW.DealAggregatedField field ON tmp.BandRange = field.FieldName AND field.DealId = tmp.DealId
				WHERE
					field.DealId = @dealId
				GROUP BY 
					tmp.BandRange, field.DealAggregatedFieldId, tmp.DealId
			
				--Insert Missing MIA
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, field.DealAggregatedFieldId, 0, 0, 0, 0, 0
				FROM
					cfgCW.DealAggregatedField field 
				LEFT JOIN
					#MonthInArrear tmp ON tmp.BandRange = field.FieldName 
				WHERE
					field.DealId = @dealId
					AND field.FieldName  LIKE 'MIA%'
					AND tmp.BandRange IS NULL


				--Current LTV
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate,
					@dealId,
					(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'CurrentLTV' AND DealId = @dealId), 
					CAST(SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS LoanBalance,
					CAST(MIN(result.CURRENT_LTV)/100 AS DECIMAL(18,8)) AS MinBalance,
					CAST(MAX(result.CURRENT_LTV)/100 AS DECIMAL(18,8)) AS MaxBalance,
					CAST((SUM(result.CURRENT_LTV * result.OUTSTANDNG_CAPITAL_BALANCE_AMT) / SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) )/100  AS DECIMAL(18,8)) WeightedAvgBalance,
					COUNT(MortgageSubAccountKey) AS LoanCount
				FROM 
					#tmpMortgageLoanResult result  
  
				UNION ALL

				SELECT 
					@vintageDate,
					@dealId,
					(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'IndexedLTV' AND DealId = @dealId), 
					CAST(SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS LoanBalance,
					CAST(MIN(result.INDEXED_LTV)/100 AS DECIMAL(18,8)) AS MinBalance,
					CAST(MAX(result.INDEXED_LTV)/100 AS DECIMAL(18,8)) AS MaxBalance,
					CAST((SUM(result.INDEXED_LTV * result.OUTSTANDNG_CAPITAL_BALANCE_AMT) / SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT))/100  AS DECIMAL(18,8)) WeightedAvgBalance,
					COUNT(MortgageSubAccountKey) AS LoanCount    
				FROM 
					#tmpMortgageLoanResult result   
  
				UNION ALL

				SELECT 
					@vintageDate,
					@dealId,
					(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'MortgageSize' AND DealId = @dealId), 
					CAST(SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS LoanBalance,
					(SELECT CAST(MIN(m1.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) 
					FROM (SELECT SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT) AS OUTSTANDNG_CAPITAL_BALANCE_AMT FROM #tmpMortgageLoanResult GROUP BY Loan_Identifier, MortgageDealKey) AS m1) AS MinBalance,
					--CAST(MIN(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS MinBalance,
					(SELECT CAST(MAX(m2.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) 
					FROM (SELECT SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT) AS OUTSTANDNG_CAPITAL_BALANCE_AMT FROM #tmpMortgageLoanResult GROUP BY MortgageSubAccountKey, MortgageDealKey) AS m2) AS MaxBalance,
					--CAST(MAX(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS MaxBalance,
					CAST(SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT * result.OUTSTANDNG_CAPITAL_BALANCE_AMT) / SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT)  AS DECIMAL(18,6)) WeightedAvgBalance,
					COUNT(MortgageSubAccountKey) AS LoanCount   
				FROM 
					#tmpMortgageLoanResult result 
				GROUP BY MortgageDealKey
  
				UNION ALL

				SELECT 
					@vintageDate,
					@dealId,
					(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'Seasoning' AND DealId = @dealId), 
					CAST(SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS LoanBalance,
					DATEDIFF(DAY, MAX(result.ACCOUNT_INCEPTION_DATE), @vintageDate) / 365.0 * 12.0 AS MinBalance,
					Cast(DATEDIFF(DAY, MIN(result.ACCOUNT_INCEPTION_DATE), @vintageDate) / 365.0 * 12.0 AS FLOAT)AS MaxBalance,
					SUM(CAST(DATEDIFF(DAY, result.ACCOUNT_INCEPTION_DATE, @vintageDate) / 365.0 * 12.0 AS FLOAT) * result.OUTSTANDNG_CAPITAL_BALANCE_AMT)  / SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) WeightedAvgBalance,
					COUNT(MortgageSubAccountKey) AS LoanCount     
				FROM 
					#tmpMortgageLoanResult result 
  
				UNION ALL

				SELECT 
					@vintageDate,
					@dealId,
					(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'RemainingTerm' AND DealId = @dealId), 
					CAST(SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(18,6)) AS LoanBalance,
					CASE WHEN CAST(DATEDIFF(DAY, @vintageDate, MIN(result.MATURITY_DATE)) / 365.0 AS FLOAT) <0 THEN 0 
										ELSE CAST(DATEDIFF(DAY, @vintageDate, min(result.MATURITY_DATE)) / 365.0 AS Float) END  AS MinBalance,
					CASE WHEN CAST(DATEDIFF(DAY, @vintageDate, max(result.MATURITY_DATE)) / 365.0 AS Float) <0 THEN 0 
										ELSE CAST(DATEDIFF(DAY, @vintageDate, max(result.MATURITY_DATE)) / 365.0 AS FLOAT) END AS MaxBalance,
					CAST(SUM(CAST((DATEDIFF(DAY, @vintageDate, result.MATURITY_DATE)*12 / 365.0)  AS FLOAT) * result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS float)  / SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) WeightedAvgBalance,
					COUNT(MortgageSubAccountKey) AS LoanCount   
				FROM 
					#tmpMortgageLoanResult result 
 
				UNION ALL
  
				SELECT 
					@vintageDate,
					@dealId,
					(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'MonthsInArrears' AND DealId = @dealId), 
					SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT) AS LoanBalance,
					CAST(MIN(result.MONTHS_IN_ARREARS) AS DECIMAL(18,6)) AS MinBalance,
					CAST(MAX(result.MONTHS_IN_ARREARS)  AS DECIMAL(18,6)) MaxBalance,
					CAST(SUM(result.MONTHS_IN_ARREARS * result.OUTSTANDNG_CAPITAL_BALANCE_AMT) / SUM(result.OUTSTANDNG_CAPITAL_BALANCE_AMT)  AS DECIMAL(18,6))  WeightedAvgBalance,
					COUNT(MortgageSubAccountKey) AS LoanCount     
				FROM 
					#tmpMortgageLoanResult result   
				
				--Losses Cumulative
				SET @aggregatedFieldId = NULL;
				SET @value1 = 0;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'LossesCurrent' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate,
						@dealId,
						(SELECT TOP 1 DealAggregatedFieldId FROM cfgcw.DealAggregatedField WHERE FieldName = 'LossesCurrent' AND DealId = @dealId), 
						SUM(result.LOSS_ON_SALE) AS LoanBalance,
						CAST(MIN(result.LOSS_ON_SALE) AS DECIMAL(18,6)) AS MinBalance,
						CAST(MAX(result.LOSS_ON_SALE)  AS DECIMAL(18,6)) MaxBalance,
						CAST(SUM(result.LOSS_ON_SALE) / COUNT(result.LOSS_ON_SALE)  AS DECIMAL(18,6))  WeightedAvgBalance,
						COUNT(MortgageSubAccountKey) AS LoanCount     
					FROM 
						#tmpMortgageLoanResult result
					WHERE
						LOSS_CALCULATION_DATE<>'1900-01-01'
						AND  CAST(LOSS_CALCULATION_DATE AS DATE) >= CAST(@fromCollectionDate AS DATE) 
						AND CAST(LOSS_CALCULATION_DATE AS DATE) <= CAST(@toCollectionDate AS DATE)
				END

				SET @aggregatedFieldId = NULL;
				SET @value1 = 0;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'LossesCumulative' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					SELECT 
						@value1 = ISNULL(LoanBalance, 0)
					FROM	
						cfgCW.DealAggregatedField field
					JOIN 
						[cw].[DealAggregatedData] data ON field.DealAggregatedFieldId = data.DealAggregatedFieldId
					WHERE 
						data.DealId = @dealId
						AND field.DealId = @dealId
						AND field.FieldName= 'LossesCumulative'
						AND CAST(data.CorrelatedDate AS DATE) = CAST(@prevMonthCorrelatedDate AS DATE)

					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate, @dealId, @aggregatedFieldId, (ISNULL(LoanBalance, 0) + @value1)  AS LoanBalance, NULL, NULL, NULL, NULL 
					FROM 
						#tmpAggregatedData tmp
					JOIN 
						cfgCW.DealAggregatedField field ON tmp.FieldId = field.DealAggregatedFieldId
					WHERE
						field.FieldName = 'LossesCurrent'
						AND field.DealId = @dealId
						AND tmp.DealId = @dealId
				END

				-- Calculate Set Off
				SET @aggregatedFieldId = NULL;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'SetOff' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					IF OBJECT_ID('tempdb..#tmpSetOffData') IS NOT NULL DROP TABLE #tmpSetOffData;

					WITH CTE AS      
					(      
						SELECT 
							PartitionId
							,MortgageAccountKey      
							,MortgageSubAccountKey      
							,MortgageDealKey         
							,CustomerSubAccountGroupKey 
						FROM   
							[sfp].[syn_SfpModel_vw_FactMortgageSubAccountEntity] fmsa      
						WHERE   
							fmsa.PartitionId = @partitionId     
							AND MortgageDealKey = @mortgageDealId      
					)     
					SELECT factCust.CustomerID, factCust.MortgageBalance, factCust.Deposit INTO #tmpSetOffData
					FROM 
						CTE fmsa      
					JOIN   
						[sfp].[syn_SfpModel_vw_MortgageAccountEntity] ma ON fmsa.MortgageAccountKey = ma.MortgageAccountKey  
					JOIN
						[sfp].[syn_SfpModel_vw_CustomerSubAccount_v1] csa ON csa.CustomerSubAccountGroupKey = fmsa.CustomerSubAccountGroupKey 
					JOIN
						[sfp].[syn_SfpModel_vw_Customer_v1] cust ON cust.CustomerKey = csa.CustomerKey
					JOIN 
						[sfp].[syn_SfpModel_vw_Fact_Customer] factCust ON factCust.CustomerID = cust.CustomerID AND fmsa.PartitionId = factCust.PartitionId 
					WHERE
						factCust.PartitionId = @partitionId
					GROUP BY 
						factCust.CustomerID, factCust.MortgageBalance, factCust.Deposit

					DECLARE
						@avgSetoff				DECIMAL(36,16),
						@totalSetoff			DECIMAL(36,16),
						@percentageSetoff		DECIMAL(36,16),
						@dsgLimit				DECIMAL(36,16), -- Deposit Guarantee --Ardmore- 100000 and Dunmore-85000
						@totalSetoffFSCS		DECIMAL(36,16),
						@avgSetoffFSCS			DECIMAL(36,16),
						@percentageSetoffFSCS	DECIMAL(36,16),
						@totalSetoffMoodys		DECIMAL(36,16),
						@avgSetoffMoodys		DECIMAL(36,16),
						@percentageSetoffMoodys	DECIMAL(36,16),
						@poolTotal				DECIMAL(36,16)

					IF EXISTS(SELECT TOP 1 * FROM #tmpSetOffData)
					BEGIN
						ALTER TABLE #tmpSetOffData ADD Setoff_1_FSCS DECIMAL(38, 16)
						ALTER TABLE #tmpSetOffData ADD Setoff_2_Moodys DECIMAL(38, 16)

						--***************This harcoding limit need to place in config table.
						SELECT @dsgLimit = CAST([Value] AS DECIMAL(16,4)) FROM [CW].[vw_DealLookup] WHERE TypeCode = 'Setoff_DSG_Limit' AND [Name] = CASE WHEN @dealId = 14 THEN 'Ardmore_DSG_Limit' 
											WHEN @dealId = 15 THEN 'Dunmore_DSG_Limit'
											WHEN @dealId = 6 THEN 'Deimos_DSG_Limit' END

						--Get the total number of loans
						SELECT @poolTotal = SUM(ISNULL(MortgageBalance, 0)) FROM #tmpSetOffData

						UPDATE #tmpSetOffData 
							SET Setoff_1_FSCS = CASE WHEN (MortgageBalance <= @dsgLimit AND Deposit <= @dsgLimit) THEN 0
											WHEN (MortgageBalance > @dsgLimit AND Deposit <= @dsgLimit) THEN 0
											WHEN (MortgageBalance <= @dsgLimit AND Deposit > @dsgLimit) THEN 0
											WHEN (MortgageBalance > @dsgLimit AND Deposit > @dsgLimit) THEN IIF(MortgageBalance>Deposit, Deposit, MortgageBalance) END,
							Setoff_2_Moodys = CASE WHEN (MortgageBalance <= @dsgLimit AND Deposit <= @dsgLimit) THEN 0
											WHEN (MortgageBalance > @dsgLimit AND Deposit <= @dsgLimit) THEN 0
											WHEN (MortgageBalance <= @dsgLimit AND Deposit > @dsgLimit) THEN IIF(MortgageBalance> (Deposit-@dsgLimit), (Deposit-@dsgLimit) , MortgageBalance)
											WHEN (MortgageBalance > @dsgLimit AND Deposit > @dsgLimit) THEN IIF((Deposit-@dsgLimit) > MortgageBalance , MortgageBalance , (Deposit-@dsgLimit)) END
						
						--Calculate the total, average and percentage setoff
						SELECT 
							@totalSetoffFSCS = SUM(ISNULL(Setoff_1_FSCS, 0)),
							@totalSetoffMoodys = SUM(ISNULL(Setoff_2_Moodys, 0))
						FROM
							#tmpSetOffData

						--Set average set off
						SET @avgSetoffFSCS = IIF(@loanCount > 0 , CAST(@totalSetoffFSCS AS FLOAT)/CAST(@loanCount AS FLOAT), 0)
						SET @avgSetoffMoodys = IIF(@loanCount > 0 , @totalSetoffMoodys/@loanCount, 0 )

						--Set Percentage set off
						SET @percentageSetoffFSCS = (CAST(@totalSetoffFSCS AS DECIMAL(18,4))/CAST(@dealPoolTotal AS DECIMAL(18, 4)))*100.0000
						SET @percentageSetoffMoodys = (CAST(@totalSetoffMoodys AS DECIMAL(18,4))/CAST(@dealPoolTotal AS DECIMAL(18, 4)))*100.0000

						--Set the final avg, total and percentage set off
						SELECT 
							@avgSetoff = IIF(@avgSetoffFSCS>@avgSetoffMoodys, @avgSetoffFSCS, @avgSetoffMoodys),
							@totalSetoff = IIF(@totalSetoffFSCS>@totalSetoffMoodys, @totalSetoffFSCS, @totalSetoffMoodys),
							@percentageSetoff = IIF(@percentageSetoffFSCS>@percentageSetoffMoodys, @percentageSetoffFSCS, @percentageSetoffMoodys)
					END

					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate,
						@dealId,
						@aggregatedFieldId, 
						@totalSetoff AS LoanBalance,
						0 AS MinBalance,
						0 AS MaxBalance,
						@avgSetoff AS  WeightedAvgBalance,
						ISNULL(@loanCount, 0) AS LoanCount

					---Now Insert the Setoff_1 (TotalSetOff_FSCS) record 
					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName IN ('TotalSetOff_FSCS', 'SetOff_1') AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@totalSetoffFSCS AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@avgSetoffFSCS AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END
					--Inserting average seprately, if it is having a separate field
					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AverageSetOff_FSCS' AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@avgSetoffFSCS AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@avgSetoffFSCS AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END

					---Now Insert the Setoff_2 (TotalSetOff_Moodys) record 
					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName IN ('TotalSetOff_Moodys', 'SetOff_2') AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@totalSetoffMoodys AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@avgSetoffMoodys AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END
					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AverageSetOff_Moodys' AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@avgSetoffMoodys AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@avgSetoffMoodys AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END

					---Now Insert the Percentage Setoff record 
					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'SetOffPercentage_FSCS' AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@percentageSetoffFSCS AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@percentageSetoffFSCS AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END
					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'SetOffPercentage_Moodys' AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@percentageSetoffMoodys AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@percentageSetoffMoodys AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END

					SET @aggregatedFieldId = NULL;
					SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'SetOffPercentage' AND DealId = @dealId
					IF @aggregatedFieldId IS NOT NULL
					BEGIN
						INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
						SELECT 
							@vintageDate,
							@dealId,
							@aggregatedFieldId, 
							@percentageSetoff AS LoanBalance,
							0 AS MinBalance,
							0 AS MaxBalance,
							@percentageSetoff AS  WeightedAvgBalance,
							ISNULL(@loanCount, 0) AS LoanCount
					END
				END
			
				-- Calculate WarehouseLoanAmount
				SET @aggregatedFieldId = NULL;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'WarehouseLoanAmount' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate,
						@dealId,
						@aggregatedFieldId, 
						0, 0, 0, 0, 0
				END
			
				
				--Calculate Swap Profile data
				IF OBJECT_ID('tempdb..#TBLProduct') IS NOT NULL DROP TABLE #TBLProduct

				
				SELECT PRODUCT, sum(OUTSTANDNG_CAPITAL_BALANCE_AMT)  AS SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT
				,  sum(OUTSTANDNG_CAPITAL_BALANCE_AMT * CURRENT_INTEREST_RATE) AS CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT
				INTO #TBLProduct
				FROM #tmpMortgageLoanResult
				WHERE MONTHS_IN_ARREARS <3
				AND OUTSTANDNG_CAPITAL_BALANCE_AMT >0
				AND MATURITY_DATE> BUSINESS_DATE 
				--AND PROCESS_STATUS =2
				GROUP BY PRODUCT
				
				
				SET @dailyColFieldName = 'SVRSwap'
				SET @aggregatedFieldId = NULL;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= @dailyColFieldName AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT  @vintageDate, @dealId, @aggregatedFieldId, CAST(sum(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(38,24)) , NULL, NULL
					, sum(CAST(CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT AS DECIMAL(38,24)))  / sum(CAST(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT AS DECIMAL(38,4)) ), NULL
					FROM #TBLProduct
					WHERE Product = 'SVR'
				END

				SET @dailyColFieldName = 'TrackerSwap'
				SET @aggregatedFieldId = NULL;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= @dailyColFieldName AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT  @vintageDate, @dealId, @aggregatedFieldId, CAST(sum(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(38,24)) , NULL, NULL
					, sum(CAST(CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT AS DECIMAL(38,24)))  / sum(CAST(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT AS DECIMAL(38,4)) ), NULL
					FROM #TBLProduct
					WHERE Product IN ('TRACKER', 'LIFETIMETRACKER' )
				END

				SET @dailyColFieldName = 'FixedSwap'
				SET @aggregatedFieldId = NULL;
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= @dailyColFieldName AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT  @vintageDate, @dealId, @aggregatedFieldId, CAST(sum(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(38,24)) , NULL, NULL
					, sum(CAST(CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT AS DECIMAL(38,24)))  / sum(CAST(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT AS DECIMAL(38,4)) ), NULL
					FROM #TBLProduct
					WHERE Product IN ('FIXED', 'LIFETIMEFIXED' )
				END
			
			END
			----------------------------------------Calculate Fields from Daily Collection -------------------------------------------------------------------------------------------------
			--Calculate Total Mortgage Oustanding Balance B/F
			SET @dailyColFieldName = 'PrevSumTotalCapital'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'TotalMortgageCapitalBalanceBF' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, NULL 
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND CAST(dc.CollectionDate AS DATE) = CAST(@fromCollectionDate AS DATE) 
			END
			
			--Calculate Total Mortgage Oustanding Balance c/F
			SET @dailyColFieldName = 'CurrentSumTotalCapital'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'TotalMortgageCapitalBalanceCF' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId,  SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, NULL 
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND CAST(dc.CollectionDate AS DATE) = CAST(@toCollectionDate AS DATE) 
			END

			--Monthly CPR = (Monthly Principal Receipts)/(Total Mortgage Oustanding Balance B/F)
			SET @dailyColFieldName = 'PrincipalReceipts'
			SET @aggregatedFieldId = NULL;
			SET @value1 = 0
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'MonthlyCPR' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				DECLARE
					@monthlyPrincipalReceipt		DECIMAL(38, 16),
					@monthlyCPR						DECIMAL(38, 16),
					@annualisedCPR					DECIMAL(38, 16)

				SELECT 
					@value1 = ISNULL(LoanBalance, 0)
				FROM	
					cfgCW.DealAggregatedField field
				JOIN 
					#tmpAggregatedData data ON field.DealAggregatedFieldId = data.FieldId
				WHERE 
					data.DealId = @dealId
					AND field.DealId = @dealId
					AND field.FieldName= 'TotalMortgageCapitalBalanceBF'
					--AND CAST(data.CorrelatedDate AS DATE) = CAST(@vintageDate AS DATE) 

				SELECT 
					@monthlyPrincipalReceipt = SUM(ISNULL(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16)), 0))  
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND  CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)

				--Annualised CPR
				SET @annualisedCPR = IIF (@value1 <> 0.0,  (1- POWER((1-(CAST(ABS(@monthlyPrincipalReceipt) AS FLOAT)/@value1)), 12.00)), 0)
				SET @monthlyCPR = (1-POWER((1-@annualisedCPR), 1/12.0))

				SET @aggregatedFieldId = NULL
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AnnualisedCPR' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate, @dealId, @aggregatedFieldId, @annualisedCPR AS LoanBalance, NULL, NULL, NULL, NULL 
				END
				
				--Monthly CPR
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'MonthlyCPR' AND DealId = @dealId
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, @monthlyCPR AS LoanBalance, NULL, NULL, NULL, NULL 	

				--Monthly Principal Receipts
				SET @aggregatedFieldId = NULL
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'MonthlyPrincipalReceipts' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate, @dealId, @aggregatedFieldId, @monthlyPrincipalReceipt AS LoanBalance, NULL, NULL, NULL, NULL 
				END

				--Quarterly CPR
				SET @aggregatedFieldId = NULL
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'QuarterlyCPR' AND DealId = @dealId
				IF @aggregatedFieldId IS NOT NULL
				BEGIN
					SELECT @value2 = SUM(ISNULL(dad.LoanBalance, 0)) FROM cw.DealAggregatedData dad
					JOIN cfgCW.DealAggregatedField daf ON daf.DealAggregatedFieldId = dad.DealAggregatedFieldId
					JOIN cfg.Deal d ON d.DealId = daf.DealId
					WHERE dad.CorrelatedDate IN (@prevMonthCorrelatedDate, @prev2MonthCorrelatedDate)
					AND daf.FieldName = 'AnnualisedCPR' AND dad.dealid = @dealId

					--Now calculate the last the month average
					INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
					SELECT 
						@vintageDate, @dealId, @aggregatedFieldId, (@annualisedCPR+ @value2)/3.00 AS LoanBalance, NULL, NULL, NULL, NULL 	
				END

			END
				
			--Calculation for Scheduled Redemptions
			SET @dailyColFieldName = 'ScheduledPrincipalReductions'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'ScheduledRedemptions' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, NULL 
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)
			END
			
			-- Calculate Unscheduled Redemptions
			SET @dailyColFieldName = 'PartialPrepayments'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'UnscheduledRedemptions' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL,  Count(dc.DailyCollectionValue)  
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName IN ('PartialPrepayments', 'Redemptions', 'OverPayments', 'FeesChargedCapitalised') 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND  CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)
			END
			
			-- Calculate Repurchases
			SET @dailyColFieldName = 'DeflaggedPrincipalReceipts'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'Repurchases' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, Count(dc.DailyCollectionValue) 
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND  CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)

			END
			
			---Calculate RepurchasesCumulative = (Repurchases value + Prev Month RepurchasesCumulative value)
			SET @dailyColFieldName = NULL
			SET @aggregatedFieldId = NULL;
			SET @value1= 0
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'RepurchasesCumulative' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN

				SELECT 
					@value1 = ISNULL(LoanBalance, 0)
				FROM	
					cfgCW.DealAggregatedField field
				JOIN 
					[cw].[DealAggregatedData] data ON field.DealAggregatedFieldId = data.DealAggregatedFieldId
				WHERE 
					data.DealId = @dealId
					AND field.DealId = @dealId
					AND field.FieldName= 'RepurchasesCumulative'
					AND CAST(data.CorrelatedDate AS DATE) = CAST(@prevMonthCorrelatedDate AS DATE)

				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, (ISNULL(LoanBalance, 0) + @value1)  AS LoanBalance, NULL, NULL, NULL, NULL 
				FROM 
					#tmpAggregatedData tmp
				JOIN 
					cfgCW.DealAggregatedField field ON tmp.FieldId = field.DealAggregatedFieldId
				WHERE
					field.FieldName = 'Repurchases'
					AND field.DealId = @dealId
					AND tmp.DealId = @dealId
			END
			
			--Further Advance
			SET @dailyColFieldName = 'FurtherStageAdvances'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'FurtherAdvance' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, NULL 
				FROM 
					cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)
			END
			
			---Calculate FurtherAdvanceCumulative = (FurtherStageAdvances value + Prev Month FurtherAdvanceCumulative value)
			SET @dailyColFieldName = NULL
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'FurtherAdvanceCumulative' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				SET @value1 = 0;

				SELECT 
					@value1 = ISNULL(LoanBalance, 0)
				FROM	
					cfgCW.DealAggregatedField field
				JOIN 
					[cw].[DealAggregatedData] data ON field.DealAggregatedFieldId = data.DealAggregatedFieldId
				WHERE 
					data.DealId = @dealId
					AND field.DealId = @dealId
					AND field.FieldName= 'FurtherAdvanceCumulative'
					AND CAST(data.CorrelatedDate AS DATE) = CAST(@prevMonthCorrelatedDate AS DATE)

				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, (ISNULL(LoanBalance, 0) + @value1)  AS LoanBalance, NULL, NULL, NULL, NULL 
				FROM 
					#tmpAggregatedData tmp
				JOIN 
					cfgCW.DealAggregatedField field ON tmp.FieldId = field.DealAggregatedFieldId
				WHERE
					field.FieldName = 'FurtherAdvance'
					AND field.DealId = @dealId
					AND tmp.DealId = @dealId
			END
			
			-- Calculate OtherMovements
			SET @dailyColFieldName = 'OtherPrincipalMovements'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'OtherMovements' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, NULL FROM cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)
			END


			-- Calculate TopupBalance
			SET @dailyColFieldName = 'TopupBalance'
			SET @aggregatedFieldId = NULL;
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= 'TopupBalance' AND DealId = @dealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@vintageDate, @dealId, @aggregatedFieldId, SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, Count(dc.DailyCollectionValue) 
					FROM cw.vwDailyCollection dc
				WHERE 
					dc.DailyCollectionFieldColumnName = @dailyColFieldName 
					AND dc.DailyCollectionFieldDealId = @dealId
					AND CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
					AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)
			END

			-- Calculate additional deimos fields
			IF EXISTS(SELECT TOP 1 * FROM cfg.Deal WHERE DealName = 'Deimos' AND DealId = @dealId)
			BEGIN
				EXEC [cb].[spLoadDeimosExtraFieldAggrData] @dealId, @vintageDate
			END

			FETCH NEXT FROM cursorCWDeal INTO @mortgageDealId, @dealId, @dealRegionCode
		END

		CLOSE cursorCWDeal;  
		DEALLOCATE cursorCWDeal; 
		
		DELETE FROM [cw].[DealAggregatedDataStg]

		PRINT 'Inserting the data into DealAggregatedDataStg'
		--Inserting data into stage table		
		INSERT INTO [cw].[DealAggregatedDataStg](CorrelatedDate, DealId, DealAggregatedFieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
		SELECT CorrelatedDate, DealId, FieldId, ISNULL(LoanBalance, 0), MinBalance, MaxBalance, WeightedAvgBalance, LoanCount FROM #tmpAggregatedData

		PRINT 'Completed............'

	END TRY  

	BEGIN CATCH   
		IF CURSOR_STATUS('global','cursorCWDeal') >= 0 
		BEGIN
			CLOSE cursorCWDeal;
			DEALLOCATE cursorCWDeal;	
		END
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  

		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  

		EXEC app.SaveErrorLog 1, 1, 'cw.spLoadMonthlyDealAggregatedData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
		, 'System'  

		RAISERROR (@errorMessage,  
		@errorSeverity,  
		@errorState )  

	END CATCH  

END
GO