USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetWIPDailyCollectionData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetWIPDailyCollectionData]    
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetWIPDailyCollectionData]  
/*
 * Author: Gunjan Chandola
 * Date:	04.03.2021
 * Description:  This will return daily collection data
 * FOR Comparision with source feed
 * [cw].[spGetWIPDailyCollectionData]  6,1034,''
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealId		INT,
@pIPDRunId INT,
@pUserName		VARCHAR(80)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
      DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX)
      DECLARE @collectionStartDate VARCHAR(10),@collectionEndDate VARCHAR(10)

      SELECT	
		    	@collectionStartDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessStart AS DATE),23), 
		    	@collectionEndDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessEnd AS DATE),23)
		    FROM 
		    	[cw].[vwDealIpdDates] ipdDt
		    JOIN
		    	cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		    WHERE
			   ipdRun.RunId = @pIPDRunId

      SELECT  @cols = STUFF((SELECT DISTINCT ',' + ColumnName 
      FROM [cfgCW].[DailyCollectionField]  cfm JOIN [cw].[DailyCollection] dc  ON  dc.[DailyCollectionFieldId]=cfm.[DailyCollectionFieldId]
      FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')

      SET @query= 'IF OBJECT_ID(''tempdb..#tmpWIPResult'') IS NOT NULL DROP TABLE #tmpWIPResult
      IF OBJECT_ID(''tempdb..#tmpLastDailyCollectionWIP'') IS NOT NULL DROP TABLE #tmpLastDailyCollectionWIP  
  
      ;WITH cteDailyCol  
      AS  
      (  
        SELECT TOP 100     
         DealId,  
         DailyCollectionId,  
         CollectionDate,  
         Value,  
         BrandId,  
         Status,  
         CreatedBy,  
         CreatedDate,  
		     ChangeReason,
         ROW_NUMBER() OVER (PARTITION BY DailyCollectionId ORDER BY ID DESC) AS RowNum   
        FROM [cw].[DailyCollection_WIP]   
        WHERE  DealId='+CAST(@pDealId AS VARCHAR(5))+'
        AND IsActive=1  
        AND CONVERT(VARCHAR(10), [CollectionDate],23) BETWEEN '''+@collectionStartDate+''' AND '''+@collectionEndDate+'''  
        ORDER BY CreatedDate DESC 
      )  
      SELECT * INTO #tmpLastDailyCollectionWIP FROM cteDailyCol WHERE RowNum = 1; 
      
      SELECT  * INTO #tmpWIPResult
      FROM
      (
        SELECT 
         dc.[CollectionDate] AS CollectionDate
        ,db.[Name] AS Brand
        ,cfm.ColumnName AS CollectionFieldColumnName
        ,ROUND(CAST(dc.[Value] AS decimal(30,8)),4) AS [Value]
        ,NULL AS Status
        --,dc.CreatedBy AS [ModifiedBy]
        --,dc.CreatedDate AS [ModifiedDate]
			  ,CAST(NULL AS VARCHAR(500)) as ChangeReason
        FROM [cw].[DailyCollection] dc 
        LEFT JOIN #tmpLastDailyCollectionWIP wip on dc.DailyCollectionId=wip.DailyCollectionId
        LEFT JOIN [cfgCW].[DailyCollectionField] cfm on dc.[DailyCollectionFieldId]=cfm.[DailyCollectionFieldId]
        LEFT JOIN [cfgCW].[DealBrand] db ON dc.[BrandId]=db.DealBrandId 
        WHERE dc.DealId='+CAST(@pDealId AS VARCHAR(5))+'
        AND CONVERT(VARCHAR(10),dc.[CollectionDate],23) BETWEEN '''+@collectionStartDate+''' AND '''+@collectionEndDate+''' 
        --AND wip.[status]!=3 --Authorized
      ) AS SourceTable PIVOT(AVG([Value]) FOR CollectionFieldColumnName IN('+@cols+')) AS PivotTable;

      ALTER TABLE #tmpWIPResult ADD  ModifiedBy VARCHAR(80)  
      ALTER TABLE #tmpWIPResult ADD  [ModifiedDate] DATETIME  


      UPDATE t SET t.Status=wip.Status, t.ChangeReason=wip.ChangeReason
      FROM #tmpWIPResult t 
        JOIN  [cfgCW].[DealBrand]  b ON b.[Name] = t.Brand 
        JOIN  #tmpLastDailyCollectionWIP wip ON wip.BrandId = b.DealBrandId 
          AND t.[CollectionDate] = CONVERT(VARCHAR(10),wip.[CollectionDate],23)
          AND wip.DealId='+CAST(@pDealId AS VARCHAR(5))+'
      
      SELECT *  FROM #tmpWIPResult ORDER BY CASE WHEN [Status] IS NOT NULL THEN 0 ELSE 1 END, CollectionDate' ;

    EXECUTE (@query)
    
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cw.spGetWIPDailyCollectionData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
