USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetSourceInterestRate]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetSourceInterestRate]  
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [cw].[spGetSourceInterestRate] 
--==================================
--Author: Gunjan Chandola
--Date:	13-04-2021
--Description:  To get interest rate on the basis 
--of CollectionBusinessStart AND CollectionBusinessEnd
-- Exec cw.spGetSourceInterestRate  14,7,''
--================================== 
    @pDealId		SMALLINT,
    @pIPDRunId		INT,
	@pUserName		VARCHAR(80) 
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY

		DECLARE 
			@cols				AS NVARCHAR(MAX), 
			@query				AS NVARCHAR(MAX),
			@interestRateDate	DATE,
			@dealType			VARCHAR(20),
			@prevIpdDate		DATE,
			@currentIpdDate		DATE,
			@startDt			DATE,
			@endDt				DATE,
			@dealRegionCode		VARCHAR(20)

		SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

		SELECT
			@interestRateDate = CAST(ipdDt.RateResetDate AS DATE),
			@currentIpdDate = ipdDt.Ipd, 
			@prevIpdDate= ipdDt.PreviousIPD,
			@dealRegionCode = deal.DealRegionCode
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.vwDealIpdRun dir ON ipdDt.DealIpdId = dir.DealIpdId
		JOIN 
			cw.vw_ActiveDeal deal ON deal.DealId = dir.DealId
		WHERE
			dir.DealIpdRunId = @pIPDRunId

		IF (@dealType='Covered Bond')
		BEGIN
			DECLARE
				@resetLeadDays		INT

			SELECT @resetLeadDays = CAST([Value] AS INT) FROM [cfgcb].[SoniaResetLeadDays] WHERE IsActive = 1
			SELECT @startDt = [CW].[fnGetBusinessDate](@prevIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
			SELECT @endDt = [CW].[fnGetBusinessDate](@currentIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
			--SET @startDt = DATEADD(DD, @resetLeadDays*-1 , @prevIpdDate)
			--SET @endDt = DATEADD(DD, @resetLeadDays*-1 , @currentIpdDate)
		END

		SELECT * INTO #tempInterestRate FROM cw.InterestRate_wip WHERE IsActive=1

		SELECT InterestRateId,RICCode,InterestRateType,IpdDate,InterestRate,[Status],ModifiedBy,ModifiedDate,Reason 
		FROM 
		(
			SELECT
				 wip.Status
				,ir.InterestRateId
				,ir.RICCode
				,ROW_NUMBER() OVER(PARTITION BY ir.InterestRateId ORDER BY Id DESC) AS RowNum 
				,ir.Asset AS InterestRateType  
				,ROUND(ir.Rate,4) AS  InterestRate
				,@interestRateDate AS IpdDate
				,ir.CreatedBy AS ModifiedBy
				,ir.CreatedDate AS ModifiedDate
				,wip.ChangeReason AS Reason
			FROM 
				cw.InterestRate ir 
			JOIN  
				#tempInterestRate wip ON ir.InterestRateId=wip.InterestRateId
			WHERE 
				(
					(@dealType = 'Covered Bond' AND CAST(ir.BaseDate AS DATE)>=@startDt AND CAST(ir.BaseDate AS DATE)<=@endDt)
					OR
					(@dealType = 'RMBS' AND (CAST(ir.BaseDate AS DATE)=CAST(@interestRateDate AS DATE)))
				)
		)t 
		WHERE t.RowNum=1  
          
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetSourceInterestRate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
				@errorSeverity,
				@errorState )
	END CATCH
END
GO
