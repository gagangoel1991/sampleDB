USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spIR_GetTestData]') IS NOT NULL
	DROP PROCEDURE [cb].[spIR_GetTestData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spIR_GetTestData] 
(
	@pAsAtDate			DATE, 
	@pDealName			VARCHAR(100),
	@pSearchCriteria	VARCHAR(MAX) = NULL,
	@pUserName			VARCHAR(80) = NULL
)
/* 
 *   Author: Kapil sharma
 *   Date:  21.02.2021 
 *   Description:  Get the test data based on test type
 *   
 *   Example - EXEC [cb].[spIR_GetTestData] '2021-05-28', 'Deimos', 'AssetCoverageTest', 'System'
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
*/ 
AS 
BEGIN 
	 BEGIN TRY 

		 DECLARE 
			@dealIpdRunId                  INT,
			@dealId                        SMALLINT

		SELECT   
		  @dealIpdRunId = dir.DealIpdRunId  
		  , @dealId = dir.DealId  
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		WHERE   
			deal.DealName = @pDealName  
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
			AND dir.IpdSequence <> 0  

			--SELECT @dealIpdRunId,@dealId

		IF(@pSearchCriteria='AssetCoverageTest')
		BEGIN

			CREATE TABLE #TestLineItemOrder ( SortOrderNo INT IDENTITY (1,1), TestLineItem Varchar(255))
			INSERT INTO #TestLineItemOrder
			SELECT 'A' UNION ALL
			SELECT 'B' UNION ALL
			SELECT 'C' UNION ALL
			SELECT 'D' UNION ALL
			SELECT 'E' UNION ALL
			SELECT 'V' UNION ALL
			SELECT 'W' UNION ALL
			SELECT 'X' UNION ALL
			SELECT 'Y' UNION ALL
			SELECT 'Z' UNION ALL
			SELECT 'Total' UNION ALL
			SELECT 'Method used for calculating component ''A'' ' UNION ALL
			SELECT 'Asset percentage (%)'		 UNION ALL
			SELECT 'Maximum asset percentage from Fitch (%)'	 UNION ALL	
			SELECT 'Maximum asset percentage from Moody''s (%)'	 UNION ALL
			SELECT 'Maximum asset percentage from S&P (%)'	 UNION ALL	
			SELECT 'Maximum asset percentage from DBRS (%)' UNION ALL	
			SELECT 'Credit support as derived from ACT (GBP)'	 UNION ALL	
			SELECT 'Credit support as derived from ACT (%)'	

			

			SELECT 
			CASE WHEN tli.InternalName='ACT_1.1_ComponentA' 
					THEN 'A'
					WHEN tli.InternalName='ACT_1.2_ComponentB' 
					THEN 'B'
					WHEN tli.InternalName='ACT_1.3_ComponentC' 
					THEN 'C'
					WHEN tli.InternalName='ACT_1.4_ComponentD' 
					THEN 'D'
					WHEN tli.InternalName='ACT_1.5_ComponentE' 
					THEN 'E'
					WHEN tli.InternalName='ACT_1.6_ComponentX' 
					THEN 'X'
					WHEN tli.InternalName='ACT_1.7_ComponentY' 
					THEN 'Y'
					WHEN tli.InternalName='ACT_1.8_ComponentZ' 
					THEN 'Z'
					ELSE ''
			END AS TestLineItem,				 
			CAST(CONVERT(DECIMAL(30,18),tliv.Value) AS VARCHAR(50)) AS [Value (GBP)],
			--CAST(SUM(CONVERT(DECIMAL(30,18),tliv.Value)) AS VARCHAR(50)) AS [Value (GBP)],
			CASE WHEN tli.InternalName='ACT_1.1_ComponentA' 
					THEN 'Adjusted current balance' 
					WHEN tli.InternalName='ACT_1.2_ComponentB' 
					THEN 'Principal collections not yet applied'
					WHEN tli.InternalName='ACT_1.3_ComponentC' 
					THEN 'Qualifying additional collateral'
					WHEN tli.InternalName='ACT_1.4_ComponentD' 
					THEN 'Substitute assets'
					WHEN tli.InternalName='ACT_1.5_ComponentE' 
					THEN 'Proceeds of sold mortgage loans'
					WHEN tli.InternalName='ACT_1.6_ComponentX' 
					THEN 'Flexible draw capacity'
					WHEN tli.InternalName='ACT_1.7_ComponentY' 
					THEN 'Set-off'
					WHEN tli.InternalName='ACT_1.8_ComponentZ' 
					THEN 'Negative carry'
					ELSE ''
			END	AS [Description (please edit if different)]
		INTO #TestData
		FROM 
			cb.TestLineItemValue tliv
		JOIN cfgcb.TestLineItem tli ON tli.TestLineItemID = tliv.TestLineItemID
		JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
		
		WHERE 
			tt.InternalName = @pSearchCriteria AND tliv.DealIpdRunId = @dealIpdRunId 
						AND (tli.InternalName = 'ACT_1.1_ComponentA' OR tli.InternalName = 'ACT_1.2_ComponentB'
						OR tli.InternalName = 'ACT_1.3_ComponentC' OR tli.InternalName =  'ACT_1.4_ComponentD'
						OR tli.InternalName = 'ACT_1.5_ComponentE' OR tli.InternalName = 'ACT_1.6_ComponentX'
						OR tli.InternalName = 'ACT_1.7_ComponentY' OR tli.InternalName =  'ACT_1.8_ComponentZ')
				--		and tli.formatType ='decimal'
		--	group by SUBSTRING(tli.InternalName,1,8)
		

	UNION
	
		SELECT 
			'Total',
			 tliv.Value AS [Value (GBP)], 
			 ''
		FROM 
			cb.TestLineItemValue tliv
		JOIN cfgcb.TestLineItem tli ON tli.TestLineItemID = tliv.TestLineItemID
		JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
		WHERE 
			tt.InternalName = @pSearchCriteria AND tliv.DealIpdRunId = @dealIpdRunId 
			AND	tli.InternalName IN ('ACT_AggregatedAdjustedAssetAmount')


	UNION
		SELECT
		CASE WHEN  tli.InternalName='ACT_1.1_A(ii)_MaximumAssetPercentageFromFitch' 
					THEN 'Maximum asset percentage from Fitch (%)' 
			 WHEN tli.InternalName='ACT_1.1_A(ii)_MaximumAssetPercentageFromMoodys'
					THEN 'Maximum asset percentage from Moody''s (%)'
			 WHEN tli.InternalName='ACT_1.1_A(ii)_MoodysBenchmark' 
					THEN 'Asset percentage (%)'
			 WHEN tli.InternalName='ACT_1.1_MethodUsedForCalculatingComponentA'
					THEN 'Method used for calculating component ''A'''
			 WHEN tli.InternalName='ACT_CreditSupportAsDerivedFromACT(GBP)'
					THEN 'Credit support as derived from ACT (GBP)'
			 WHEN tli.InternalName='ACT_CreditSupportAsDerivedFromACTPercentage'
					THEN 'Credit support as derived from ACT (%)'					
					ELSE tli.DisplayName
			END,
			 tliv.Value AS [Value (GBP)], 
			 ''
		FROM 
			cb.TestLineItemValue tliv
		JOIN cfgcb.TestLineItem tli ON tli.TestLineItemID = tliv.TestLineItemID
		JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
		WHERE 
			tt.InternalName = @pSearchCriteria AND tliv.DealIpdRunId = @dealIpdRunId 
			AND	tli.InternalName IN 
			('ACT_1.1_MethodUsedForCalculatingComponentA',
			 'ACT_1.1_A(ii)_MaximumAssetPercentageFromFitch',
			 'ACT_1.1_A(ii)_MaximumAssetPercentageFromMoodys',
			 'ACT_1.1_A(ii)_MoodysBenchmark',
			 'ACT_CreditSupportAsDerivedFromACT(GBP)',
			 'ACT_CreditSupportAsDerivedFromACTPercentage',
			 'ACT_1.1_A(ii)_MoodysBenchmark',
			 'ACT_MaximumAssetPercentageFromS&P',
			 'ACT_MaximumAssetPercentageFromDBRS')

			
			SELECT tlo.TestLineItem, IsNull(td.[Value (GBP)], 'N/A') AS [Value (GBP)]
			, CASE WHEN Tlo.TestLineItem='V' THEN 'Set-off offset loans'
				  WHEN Tlo.TestLineItem='W' THEN 'Personal secured loans'
				  ELSE td.[Description (please edit if different)] END AS [Description (please edit if different)]
			FROM #TestLineItemOrder tlo
			LEFT JOIN #TestData td   ON tlo.TestLineItem = td.TestLineItem	 
			ORDER BY tlo.SortOrderNo

		END
		ELSE
		 BEGIN
			SELECT 
				tli.TestLineItemID,  
				tli.InternalName AS TestLineItemInternalName, 
				tli.SortOrder,
				 tliv.Value AS [Value (GBP)], 
				tli.DisplayName AS [Description (please edit if different)],
				tli.ParentTestLineItemId
			FROM 
				cb.TestLineItemValue tliv
			JOIN cfgcb.TestLineItem tli ON tli.TestLineItemID = tliv.TestLineItemID
			JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
			WHERE 
				tt.InternalName = @pSearchCriteria AND tliv.DealIpdRunId = @dealIpdRunId 
			ORDER BY 
				tli.SortOrder 
		END

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetTestData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH   
END 
GO
