
USE [SFP_Securitisation]
GO


GO

IF OBJECT_ID('cb.spReProcessBookingsIPDData') IS NOT NULL
	DROP PROCEDURE cb.spReProcessBookingsIPDData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure cw.spReProcessBookingsIPDData    Script Date: 4/24/2023 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	24.04.2023
 * Description:  Description:  Re-Calculate Bookings IPD Date. 
 * NOTE: THIS MUST BE SAME AS RUN IPD. ANY CHANGE IN RE-Calculate MUST BE ANALYSED HERE AS WELL.
 * Change History
 * --------------
 * Author		Date		Description
 * 
	
exec cb.spReProcessBookingsIPDData @pIPDRunId =71, @pUserName ='kumavnb'
 * -------------------------------------------------------
*/    
        
        
CREATE PROC cb.spReProcessBookingsIPDData
	@pIPDRunId SMALLINT,
	@pUserName	VARCHAR(80),
	@pResultCode INT = 0 OUTPUT 
AS
BEGIN

	BEGIN TRY

		EXEC [cw].[spCalculateExpression] @pIPDRunId, @pUserName

		Exec cb.spProcessBookingsIPDData @pIPDRunId, @pUserName


		SET @pResultCode = 1

	END TRY
	BEGIN CATCH
		
		DECLARE
		@Message		VARCHAR(MAX)

		DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			 @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spReProcessBookingsIPDData', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		SET @pResultCode = 0
		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )

		
	END CATCH
END
