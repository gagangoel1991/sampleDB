USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetNoteSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetNoteSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC cw.spIR_GetNoteSummary 
(
  @pAsAtDate DATETIME,
  @pDealName  VARCHAR(200),
  @pUserName	VARCHAR(80) = NULL
) 
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get Note summary for IR liability Strats
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */ 
AS 
BEGIN
	BEGIN TRY  

	DECLARE 
		@dealIpdRunId		INT,
        @dealId				SMALLINT,
        @ipdDate			DATETIME,
        @dealIpdRunVersion	SMALLINT,
		@daysAccrued		INT,
		@craNames			VARCHAR(200),
		@ratingTypeId		TINYINT,
		@rateDate			DATE,
		@colBusinessEndDate	DATE

	SELECT 
		@dealIpdRunId = dir.DealIpdRunId
		, @dealId = dir.DealId
		, @ipdDate = ipddate
		, @dealIpdRunVersion = DealIpdRunVersion
		, @daysAccrued = dir.IpdDayCount
		, @colBusinessEndDate =  CAST(dt.CollectionBusinessEnd AS DATE)
		, @rateDate = CAST(dt.RateResetDate AS DATE)
	FROM   
		cw.vwDealIpdDates dt
	JOIN
		cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId AND dir.DealId = dt.DealId
	WHERE	
		dir.InternalDealName = @pDealName
		AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)

	SELECT @ratingTypeId = RatingTypeId FROM cfgCW.RatingType WHERE Name ='Bond Rating'

	--Fetch all the applicable CRAs for Note
    SELECT @craNames = COALESCE(@craNames + ' / ', '') + cra.Name  FROM cfgcw.CreditRatingAgency cra 
    JOIN cfgCW.DealSubjectCRAMap craMap ON craMap.CRAId = cra.CRAId 
    WHERE 
		craMap.DealId = @dealId 
		AND craMap.DealSubjectTypeId = 1 --Note

	IF( Object_id('tempdb..#temp') IS NOT NULL ) 
		DROP TABLE #temp 

	IF( Object_id('tempdb..#temp2') IS NOT NULL ) 
		DROP TABLE #temp2 

	IF( Object_id('tempdb..#temp3') IS NOT NULL ) 
		DROP TABLE #temp3

	IF( Object_id('tempdb..#tempLineOrder') IS NOT NULL ) 
		DROP TABLE #tempLineOrder 

	CREATE TABLE #tempLineOrder (InternalName varchar(200), DisplayName varchar(500), sortOrder decimal(9,3))

	SELECT 
		ISNULL(CAST(dn.Series AS VARCHAR(200)), 'N/A')                       AS Series, 
		ISNULL(CAST(dn.ISIN AS VARCHAR(200)), 'N/A')                         AS ISIN, 
		ISNULL(CAST(dn.StockExchange AS VARCHAR(200)), 'N/A')                AS StockExchange,
		ISNULL(CAST(c.NAME AS VARCHAR(200)), 'N/A')                          AS Currency, 
		ISNULL(CAST(CAST(dn.IssuanceAmount AS DECIMAL(38,2)) AS VARCHAR(200)), 'N/A')   AS IssuanceAmount,
		ISNULL(CAST(CONVERT(DATE, dn.MaturityDate) AS VARCHAR(200)), 'N/A')  AS MaturityDate,
		ISNULL(CAST(CONVERT(DATE, dn.StepUpDate) AS VARCHAR(200)), 'N/A')    AS StepUpDate, 
		ISNULL(CAST(dir.IpdDayCount AS VARCHAR(200)), 'N/A')                 AS DaysAccrued, 
		ISNULL(CAST(dlvPaymentFrequency.DisplayText AS VARCHAR(200)), 'N/A') AS PaymentFrequency,
		ISNULL(CAST(dlvBenchmark.DisplayText AS VARCHAR(200)), 'N/A')        AS InterestReferenceRate,
		CASE WHEN dn.Series = 'A' THEN CAST(ISNULL(dn.Margin, 0) AS VARCHAR(200)) ELSE CASE WHEN ISNULL(dn.Margin, 0) = 0 THEN 'N/A' ELSE CAST(dn.Margin AS VARCHAR(200)) END END AS Margin,
		CASE WHEN dn.Series = 'A' THEN CAST(dn.StepUpMargin * 10000 AS VARCHAR(200)) ELSE CASE WHEN ISNULL(dn.StepUpMargin, 0) = 0 THEN 'N/A' ELSE CAST(dn.StepUpMargin * 10000 AS VARCHAR(200)) END END AS StepUpMargin,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPre.Coupon, 0)  AS DECIMAL(38,8)) AS VARCHAR(200)) ELSE CASE WHEN ISNULL(nPre.Coupon, 0) = 0 THEN 'N/A' ELSE CAST(CAST(nPre.Coupon AS DECIMAL(38,8)) AS VARCHAR(200)) END END AS ApplicableCouponRate,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.InterestPaid, 0)  AS DECIMAL(38,2)) AS VARCHAR(200)) ELSE CASE WHEN ISNULL(nPost.InterestPaid, 0) = 0 THEN 'N/A' ELSE CAST(CAST(nPost.InterestPaid  AS DECIMAL(38,2)) AS VARCHAR(200)) END END AS InterestPaid,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.PrincipalPaid, 0)  AS DECIMAL(38,2)) AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPost.PrincipalPaid  AS DECIMAL(38,2)) AS VARCHAR(200)), 'N/A') END AS PrincipalPaid,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.TotalInterestPaid, 0) AS DECIMAL(38,2))  AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPost.TotalInterestPaid AS DECIMAL(38,2))  AS VARCHAR(200)), 'N/A') END AS TotalInterestPaid,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.TotalPrincipalPaid, 0) AS DECIMAL(38,2))  AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPost.TotalPrincipalPaid AS DECIMAL(38,2))  AS VARCHAR(200)), 'N/A') END AS TotalPrincipalPaid,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.Interest_Cf, 0) AS DECIMAL(38,2)) AS VARCHAR(200)) ELSE CASE WHEN ISNULL(nPost.Interest_Cf, 0) = 0 THEN 'N/A' ELSE CAST(CAST(nPost.Interest_Cf  AS DECIMAL(38,2)) AS VARCHAR(200)) END END AS Interest_cf,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.Principal_Cf, 0)  AS DECIMAL(38,2)) AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPost.Principal_Cf  AS DECIMAL(38,2)) AS VARCHAR(200)), 'N/A')  END AS Principal_cf,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPost.ClosingPoolFactor, 0)  AS DECIMAL(38,6)) AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPost.ClosingPoolFactor  AS DECIMAL(38,6)) AS VARCHAR(200)), 'N/A') END AS ClosingPoolFactor,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPre.Principal_bf, 0)  AS DECIMAL(38,2)) AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPre.Principal_bf  AS DECIMAL(38,2)) AS VARCHAR(200)), 'N/A') END AS Principal_bf,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPre.Interest_bf, 0)  AS DECIMAL(38,2)) AS VARCHAR(200)) ELSE CASE WHEN ISNULL(nPre.Interest_bf, 0)= 0 THEN 'N/A' ELSE CAST(CAST(nPre.Interest_bf  AS DECIMAL(38,2)) AS VARCHAR(200)) END END AS Interest_bf,
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPre.IntOnBfInt, 0) AS DECIMAL(38,2))  AS VARCHAR(200)) ELSE CASE WHEN ISNULL(nPre.IntOnBfInt, 0) = 0 THEN 'N/A' ELSE CAST(CAST(nPre.IntOnBfInt AS DECIMAL(38,2))  AS VARCHAR(200)) END END AS IntOnBfInt,
		CASE WHEN dn.Series = 'A' THEN CAST(ISNULL(nPre.IntOnPrincipal, 0) AS VARCHAR(200)) ELSE CASE WHEN ISNULL(nPre.IntOnPrincipal, 0) = 0 THEN 'N/A' ELSE CAST(nPre.IntOnPrincipal AS VARCHAR(200)) END END AS IntOnPrincipal, 
		CASE WHEN dn.Series = 'A' THEN CAST(CAST(ISNULL(nPre.OpeningPoolFactor, 0)  AS DECIMAL(38,5)) AS VARCHAR(200)) ELSE ISNULL(CAST(CAST(nPre.OpeningPoolFactor  AS DECIMAL(38,5)) AS VARCHAR(200)), 'N/A')  END AS OpeningPoolFactor,
		CAST([cw].[fnGetNoteISINRating](dn.DealId, dn.ISIN, @ratingTypeId, NULL) AS VARCHAR(200))			  AS OriginalRatings,
		CAST([cw].[fnGetNoteISINRating](dn.DealId, dn.ISIN, @ratingTypeId, @colBusinessEndDate) AS VARCHAR(200))	  AS CurrentRatings
	INTO   #temp 
	FROM   
		cfgcw.dealnote dn 
	JOIN 
		cw.notedata_prewf nPre ON dn.DealNoteId = nPre.DealNoteId 
	JOIN 
		cw.notedata_postwf nPost ON nPre.DealNoteId = nPost.DealNoteId AND nPre.DealIpdRunId = nPost.DealIpdRunId 
	JOIN 
		cw.vwDealIpdRun dir ON nPre.DealIpdRunId = dir.DealIpdRunId 
	JOIN 
		cfgcw.currency c  ON  dn.CurrencyId = c.CurrencyId 
	LEFT JOIN 
		cfgcw.deallookupvalue dlvPaymentFrequency 
		ON dn.CouponPaymentFrequencyId = dlvPaymentFrequency.LookupValueId 
	LEFT JOIN 
		cfgcw.deallookupvalue dlvBenchmark 
		ON dn.BenchmarkId = dlvBenchmark.LookupValueId 
	WHERE  
		dir.DealIpdRunId = @dealIpdRunId 

    SELECT Series, 
            NoteName, 
            Valuee 
    INTO   #temp2 
    FROM   #temp 
            UNPIVOT ( Valuee 
                    FOR NoteName IN (ISIN,StockExchange, Currency, IssuanceAmount, MaturityDate, StepUpDate, 
									DaysAccrued, OriginalRatings, CurrentRatings, PaymentFrequency, InterestReferenceRate, Margin, StepUpMargin, 
									ApplicableCouponRate, InterestPaid, PrincipalPaid, TotalInterestPaid, TotalPrincipalPaid, 
									Interest_Cf, Principal_Cf, ClosingPoolFactor, Principal_bf, Interest_bf, 
									IntOnBfInt, IntOnPrincipal, OpeningPoolFactor 
								) 
			) unpiv; 


		INSERT INTO #tempLineOrder VALUES
		 ('ISIN','Identifier',1)
		,('StockExchange','Stock Exchange Listing',2)
		,('Currency','Currency',3)
		,('IssuanceAmount','Issuance Size',4)
		,('MaturityDate','Final Maturity Date',5)
		,('StepUpDate','Step-Up date',6)
		,('DaysAccrued','Days Accrued',7)
		,('OriginalRatings', + 'Original Ratings (' + @craNames + ')', 8)
		,('CurrentRatings','Current Ratings (' + @craNames + ')', 9)
		,('PaymentFrequency','Payment Frequency', 10)
		,('InterestReferenceRate','Interest Reference Rate', 11)
		,('Margin','Margin',12)
		--,('StepUpMargin','Step-Up margin', 13)
		,('ApplicableCouponRate','Applicable Coupon Rate', 14)
		,('IntOnPrincipal','Current Period Scheduled Coupon',15)
		,('InterestPaid','Current Period Coupon Paid',16)
		,('IntOnBfInt','Interest on Deferred Interest',17)
		,('Interest_bf','Deferred Interest of the Period', 18)
		,('Interest_cf','Cumulative Deferred Interest', 19)
		,('Principal_bf','Opening Principal Balance', 20)
		,('OpeningPoolFactor','Opening Pool Factor', 21)
		,('PrincipalPaid','Current Period Principal Redemption', 22)
		,('TotalPrincipalPaid','Cumulative Principal Distribution', 23)
		,('Principal_cf','Closing Principal Balance', 24)
		,('ClosingPoolFactor','Closing Pool Factor', 25)
		,('Interest_bf','Opening Interest', 26)
		,('TotalInterestPaid','Cumulative Interest Distribution', 27)

	 SELECT t1.Series, t2.DisplayName, t1.Valuee, t2.SortOrder
	 INTO	#temp3
	 FROM	#temp2 t1, #tempLineOrder t2 WHERE t1.NoteName=t2.InternalName
	 ORDER BY t1.Series, t2.SortOrder

      DECLARE @cols  AS NVARCHAR(MAX), 
              @query AS NVARCHAR(MAX) 

      SELECT @cols = Stuff((SELECT ',' + Quotename(Series) 
                            FROM   #temp3 
                            GROUP  BY Series 
                            ORDER  BY Series 
                            FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)'), 1, 1, '') 

      SET @query = N'SELECT DisplayName,' + @cols 
                   + N' from   ( select DisplayName,Series,Valuee, SortOrder from #temp3 ) x pivot  ( max(Valuee) for Series in (' + @cols + N') ) p ' 

      EXEC sp_executesql 
        @query; 
    
		  END TRY 

	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetNoteSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
END
GO