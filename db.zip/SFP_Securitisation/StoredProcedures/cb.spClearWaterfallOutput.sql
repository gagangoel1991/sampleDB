USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spClearWaterfallOutput') IS NOT NULL
	DROP PROCEDURE cb.spClearWaterfallOutput
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [Cb].[spClearWaterfallOutput]
(
	@pDealId SMALLINT,  
	 @pIpdDate  DATETIME,      
	 @pIpdRunId  INT,    
	 @pUserName VARCHAR(80)
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  23.03.2022
 *   Description:  Clear waterfall output. 
 *   NOTE: THIS MUST BE SAME AS INITIATE IPD. ANY CHANGE IN INITIATE MUST BE ANALYSED HERE AS WELL.
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *    
 *   exec cb.spClearWaterfallOutput	6,'2021-05-24',36,'fm\shriyad'
 *              
  */ 
)         
AS      
BEGIN     
 BEGIN TRY    
 DECLARE  @businessStartDate DATE,  
          @businessEndDate   DATE,  
          @maxBondRatingDate DATE,  
          @maxCPRatingDate   DATE,
          @dealType VARCHAR(100);
  
  BEGIN TRAN  
   SELECT  @businessStartDate = did.CollectionBusinessStart,   
           @businessEndDate = did.CollectionBusinessEnd  
          FROM cw.DealIpd di  
          JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId  
          JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId  
          WHERE dir.RunId = @pIpdRunId  
  
   SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

   IF (@dealType='Covered Bond')
	BEGIN
	     SET @maxBondRatingDate = ISNULL((  
              SELECT CAST(MAX(br.RatingDate) AS DATE)  
              FROM CW.vwBondRating br  
              JOIN [cfgCb].[DealNote] dn ON dn.ISIN = br.ISIN  
              WHERE CAST(br.RatingDate AS DATE) BETWEEN @businessStartDate  
                AND @businessEndDate  
               AND dn.DealId = @pDealId  
              ), @businessEndDate); 	
    END
	ELSE IF(@dealType='RMBS')
	BEGIN
	     SET @maxBondRatingDate = ISNULL((  
              SELECT CAST(MAX(br.RatingDate) AS DATE)  
              FROM CW.vwBondRating br  
              JOIN [cfgCW].[DealNote] dn ON dn.ISIN = br.ISIN  
              WHERE CAST(br.RatingDate AS DATE) BETWEEN @businessStartDate  
                AND @businessEndDate  
               AND dn.DealId = @pDealId  
              ), @businessEndDate); 	
    END  
    
  
     SET @maxCPRatingDate = ISNULL((  
      SELECT CAST(MAX(cp.RatingDate) AS DATE)  
      FROM CW.vwCounterpartyRating cp  
      JOIN [CW].[vw_ActiveDealCounterparty] dc ON dc.CisCode = cp.CisCode  
      WHERE CAST(cp.RatingDate AS DATE) BETWEEN @businessStartDate  
        AND @businessEndDate  
       AND dc.DealId = @pDealId  
      ), @businessEndDate);  
      
    DELETE FROM [cw].[RevenueWaterfallPayment] WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.RevenueWaterfallPaymentSummary WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.PrincipalWaterfallPayment WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.PrincipalWaterfallPaymentSummary WHERE DealIpdRunId=@pIpdRunId  
  
    --DELETE FROM cb.DealNote_Wf WHERE DealIpdRunId=@pIpdRunId  
  
    --DELETE FROM cb.DealSwap_Wf WHERE DealIpdRunId=@pIpdRunId  
  
    --DELETE FROM cb.NoteSwap_Wf WHERE DealIpdRunId=@pIpdRunId  
  
    --DELETE FROM cb.TestLineItemValue WHERE DealIpdRunId=@pIpdRunId  

    --DELETE FROM cb.DealIpdTestResult WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cb.PreMaturityLiquidity_PostWF WHERE DealIpdRunId=@pIpdRunId  

    DELETE FROM cb.ReserveFund_PostWF WHERE DealIpdRunId=@pIpdRunId  

    DELETE FROM cb.CouponPaymentFund_PostWf WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM [cw].[InvoiceData_PostWF] WHERE DealIpdDate=@pIpdDate  
  
    DELETE FROM [CW].[WaterfallLineItemAmount_PostWF] WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM [cw].[DealIpdTriggerResult_PostWF] WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM [cw].[UserBondRating_PostWF] WHERE RatingDate=@maxBondRatingDate  
  
    DELETE FROM [CW].[UserCounterpartyRating_PostWF] WHERE RatingDate= @maxCPRatingDate  
  
    --SELECT Replace(wc.InternalName, 'PreAvailable', 'PostAvailable') InternalName,RequiredAmount,AdjustedAmount,TotalRequiredAmount,wli.SortOrder  INTO #preTable  
    --FROM cw.WaterfallLineItemAmount pwli JOIN cfgcw.WaterfallLineItem wli ON pwli.WaterfallLineItemId=wli.WaterfallLineItemId  
    --JOIN  cfgcw.WaterfallCategory wc ON  wc.WaterfallCategoryId=wli.WaterfallCategoryId   
    --JOIN  cw.vwDealIpdRun dir ON dir. DealId=wc. DealId  
    --WHERE pwli.DealIpdRunId=dir.DealIpdRunId  
    --AND dir.DealIpdRunId=@pIpdRunId  
    --AND wc.InternalName IN ('PreAvailablePrincipalReceipts','PreAvailableRevenueReceipts')  
    --ORDER BY wc.WaterfallCategoryId, wli.SortOrder  
  
    --UPDATE pwli SET pwli.RequiredAmount=pre.RequiredAmount, pwli.AdjustedAmount=0, pwli.TotalRequiredAmount=pre.TotalRequiredAmount  
    --FROM cw.WaterfallLineItemAmount pwli   
    --JOIN cfgcw.WaterfallLineItem wli ON pwli.WaterfallLineItemId=wli.WaterfallLineItemId  
    --JOIN  cfgcw.WaterfallCategory wc ON  wc.WaterfallCategoryId=wli.WaterfallCategoryId   
    --JOIN  cw.vwDealIpdRun dir ON dir. DealId=wc. DealId  
    --JOIN #preTable pre ON pre.InternalName=wc.InternalName  
    --WHERE pwli.DealIpdRunId=dir.DealIpdRunId  
    --AND dir.DealIpdRunId=@pIpdRunId  
    --AND wli.Sortorder=pre.Sortorder  
    --AND wc.InternalName IN ('PostAvailablePrincipalReceipts','PostAvailableRevenueReceipts')  
  COMMIT TRAN  
 END TRY        
 BEGIN CATCH      
  IF @@TRANCOUNT > 0    
    ROLLBACK TRAN    
  DECLARE       
   @errorMessage     NVARCHAR(MAX),      
   @errorSeverity    INT,      
   @errorNumber      INT,      
   @errorLine        INT,      
   @errorState       INT;      
      
  SELECT       
  @errorMessage = ERROR_MESSAGE()
  ,@errorSeverity = ERROR_SEVERITY()
  ,@errorNumber = ERROR_NUMBER()
  ,@errorLine = ERROR_LINE()
  ,@errorState = ERROR_STATE()      
      
  EXEC app.SaveErrorLog 1, 1, '[cw].[spClearWaterfallOutput]', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName      
        
  RAISERROR (@errorMessage, @errorSeverity,@errorState )      
 END CATCH      
END

GO