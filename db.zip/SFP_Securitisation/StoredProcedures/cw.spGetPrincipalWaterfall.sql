USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spGetPrincipalWaterfall') IS NOT NULL
	DROP PROCEDURE cw.spGetPrincipalWaterfall
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/********
  exec cw.spGetPrincipalWaterfall	50,'fm\shriyad'
  **********/

CREATE PROC cw.spGetPrincipalWaterfall
(
	@pDealIpdRunId INT,
	@pUserName	VARCHAR(80)
)
AS
BEGIN
	DECLARE @Message	VARCHAR(4000) 		

	BEGIN TRY 
		
		DECLARE @DealName		VARCHAR(20)=(SELECT DealName FROM cw.vwDealIpdRun WHERE DealIpdRunId=@pDealIpdRunId);

		IF(@DealName IN ('ARDMORE1','DUNMORE1'))
			BEGIN
			  EXEC cw.spRMBSGetPrincipalWaterfall	@pDealIpdRunId ,@pUserName 
			END
		ELSE
		   BEGIN
			  EXEC cb.spGetPrincipalWaterfall	@pDealIpdRunId ,@pUserName
			END		

	END TRY 
    BEGIN CATCH
	 DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'cw.spGetPrincipalWaterfall', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )
	END CATCH


END
GO