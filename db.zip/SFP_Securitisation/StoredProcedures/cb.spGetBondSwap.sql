USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBondSwap]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBondSwap]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 28-02-2022 
--Description: GET Bond Swap Details 
--[cb].[spGetBondSwap] 6,56,''
--==================================   
CREATE PROCEDURE [cb].[spGetBondSwap] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
		SELECT nsWf.NoteswapId AS SwapId
			,dn.Name AS SwapName
			,CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
			,CONVERT(VARCHAR(10), nsWf.PayCouponPeriodStart, 103) PayCouponPeriodStart
			,CONVERT(VARCHAR(10), nsWf.PayCouponPeriodEnd, 103) PayCouponPeriodEnd
			,DATEDIFF(DAY, nsWf.PayCouponPeriodStart ,nsWf.PayCouponPeriodEnd ) PayAccrualDays
			,ns.PayNotional
			,nsWf.PayBaseRate*100 AS PayBaseRate
			,nsWf.PayRate*100 AS PayRate
			,nsWf.PayAmount
			,CONVERT(VARCHAR(10), nsWf.ReceiveCouponPeriodStart, 103) ReceiveCouponPeriodStart
			,CONVERT(VARCHAR(10), nsWf.ReceiveCouponPeriodEnd, 103) ReceiveCouponPeriodEnd
			,DATEDIFF(DAY,  nsWf.CouponPaymentCalendarStartPeriod ,nsWf.CouponPaymentCalendarEndPeriod ) ReceiveAccrualDays
			,ns.ReceiveNotional
			,ns.PayMargin/100 AS PayMargin
			,ns.ReceiveMargin/100 AS ReceiveMargin
			,nsWf.ReceiveBaseRate
			,nsWf.ReceiveRate*100 AS ReceiveRate
			,nsWf.ReceiveAmount
			,CASE 
				WHEN nsWf.PayAmount > nsWf.ReceiveAmount
					THEN nsWf.NetAmount
				END PayNetAmount
			,CASE 
				WHEN nsWf.ReceiveAmount > nsWf.PayAmount
					THEN nsWf.NetAmount
				END ReceiveNetAmount
		FROM cb.NoteSwap_Wf nsWf
		JOIN cfgcb.NoteSwap ns ON nsWf.NoteSwapId = ns.NoteSwapId
		JOIN cfgcb.DealNote dn ON ns.DealNoteId = dn.DealNoteId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = nsWf.DealipdRunid
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
		ORDER BY dir.IpdDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetBondSwap'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


