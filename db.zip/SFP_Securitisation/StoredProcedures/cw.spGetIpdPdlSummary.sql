USE SFP_Securitisation
GO
IF OBJECT_ID('cw.spGetIpdPdlSummary') IS NOT NULL
	DROP PROCEDURE cw.spGetIpdPdlSummary 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================  
--Author:		Kapil Sharma 
--Date:			11-05-2021 
--Description:	This will return the PDL Summary 

--[cw].[spGetIpdPdlSummary] 14,4,''
--==================================   
CREATE PROCEDURE [cw].[spGetIpdPdlSummary] 
   @pDealId		INT,    
   @pIPDRunId	INT, 
   @pUserName	VARCHAR(80)       
AS  
BEGIN  
	BEGIN TRY   
		
		SELECT 
			ipd.IpdDate AS IpdDate,
			pdlPre.ArrearsPDL AS [AggregateProvisionalArrears],
			pdlPre.Losses AS [Losses],
			pdlPre.WarehouseLoanAmount AS [WarehouseLoanAmount],
			pdlPre.PDLAllocationForCurrentIPD AS [TotalPdlAllocation],
			pdlPre.PDLSettledTillDate AS [PdlSettledTillDate],
			pdlPre.PDEForCurrentIPD AS [PrincipalDeficiencyExcess],
			pdlPre.PDLToBePaidInCurrentIPD AS [PdlDue],
			pdlPost.TotalPDLPaidForCurrentIPD AS [PdlPaid],
			pdlPost.TotalPDLPaidTillDate AS [TotalPdlPaid]
		INTO #Result
		FROM 
			cw.pdl_prewf pdlPre
		JOIN
			cw.dealipdrun dir ON dir.RunId=pdlPre.DealipdRunid 
		JOIN
			cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		LEFT JOIN
			cw.Pdl_postwf pdlPost ON pdlPre.DealipdRunid=pdlPost.DealipdRunid 
		WHERE
			dir.RunId IN(SELECT RunId FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId,4))
			AND ipd.DealId=@pDealId 
		ORDER BY
			ipd.IpdDate DESC

	    --To Add Blank Rows for UI Only
	    ALTER TABLE #Result ALTER COLUMN IpdDate DATETIME NULL			
	    DECLARE @RowCount INT= (SELECT Count(1) FROM #Result)			
	    
	    WHILE ( @RowCount < 4)
	    BEGIN
	    	INSERT INTO #Result DEFAULT VALUES
	    	SET @RowCount=@RowCount+1;
	    END

		SELECT * FROM #Result ORDER BY IpdDate DESC;

	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spGetIpdPdlSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH  
END
GO