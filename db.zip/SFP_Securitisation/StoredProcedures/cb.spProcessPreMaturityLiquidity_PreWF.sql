USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessPreMaturityLiquidity_PreWF]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessPreMaturityLiquidity_PreWF]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessPreMaturityLiquidity_PreWF] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  27.01.2022
 *   Description:  Fill PreMaturityLiquidity CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date		Description 
 *   ------------------------------------------------------- 
 *   AS		10.03.2022	changed column name	TestTypeId
 * 						change result string to FAIL from FALSE
 *   
 *   exec cb.[spProcessPreMaturityLiquidity_PreWF] 1034,'fm\shriyad'
 *    select * from [Cb].[PreMaturityLiquidity_PreWf] where dealipdrunid=1034           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=35, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @dealId  INT, 
				  @ipdDate DATE,
				  @preMaturityLiquidity_bF decimal(38,16),
				  @requiredAmount1 decimal(38,16),
				  @capitalContribution decimal(38,16)

          SELECT @dealId = DealId, 
				@ipdDate = IpdDate
          FROM   cw.vwDealIpdRun dir
          WHERE  DealIpdRunId = @pDealIpdRunId 
		  

		  DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

          IF Object_id('tempdb..#PreMaturityLiquidity_PreWF') IS NOT NULL 
            DROP TABLE #PreMaturityLiquidity_PreWF

          CREATE TABLE #PreMaturityLiquidity_PreWF
            ( 
				[DealIpdRunId] [int] NOT NULL,
				[CoveredBondFundId] [smallint] NOT NULL,
				[PreMaturityLiquidity_bF] [decimal](38, 16) NULL,
				[RequiredAmount1] [decimal](38, 16) NULL,
				[FinalRequiredAmount] [decimal](38, 16) NULL,
				[CapitalContribution] [decimal](38, 16) NULL,
				[DueAmount] [decimal](38, 16) NULL,
				[ResidualAmount] [decimal](38, 16) NULL
            ) 

				SELECT @preMaturityLiquidity_bF = PreMaturityLiquidity_cf
				FROM cb.PreMaturityLiquidity_PostWF pml_postwf
					JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = pml_postwf.CoveredBondFundId
					AND  cbf.InternalName = 'PreMaturityLiquidityFund'
				WHERE DealIpdRUnId = @dealPreviousIpdRunId

				SELECT @requiredAmount1 = SUM(RequiredRedemptionForHardBullet)
				FROM cfgcb.DealNote dn 
						JOIN cb.DealNote_Wf dn_Wf ON dn.DealNoteId = dn_Wf.DealNoteId
							AND dn.ExtendedCoveredBond = 1
							AND ValidFrom<=GETDATE() AND ValidTo>=GETDATE()
							AND DealIpdRUnId = @pDealIpdRunId
				

				SET @capitalContribution= (SELECT CONVERT(decimal(38,16),ManualFieldValue) FROM [Cb].[vwManualField] 		
												WHERE ManualFieldInternalName = 'Cash_HardBulletRedemptionAmount_PreMaturity'
												AND ManualFieldGroupInternalName = 'PreMaturityLiquidityLedger'
												AND DealIpdRunId = @pDealIpdRunId);; 

                INSERT INTO #PreMaturityLiquidity_PreWF 
                            (DealIpdRunId
							,CoveredBondFundId
							,PreMaturityLiquidity_bF
							,RequiredAmount1
							,FinalRequiredAmount
							,CapitalContribution
							,DueAmount
							,ResidualAmount
							) 
                 SELECT @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,COALESCE(@preMaturityLiquidity_bF,0) PreMaturityLiquidity_bF
						,COALESCE(@requiredAmount1,0)
						,COALESCE(IIF(ttr.Result = 'PASS', 0, @requiredAmount1),0) FinalRequiredAmount
						,COALESCE(@capitalContribution,0) CapitalContribution
						,NULL DueAmount
						,NULL ResidualAmount 
                FROM	cfgcb.CoveredBondFund cbf
						LEFT JOIN [cb].[DealIpdTestResult] ttr ON cbf.ApplicableId = ttr.TestTypeID AND ttr.DealIpdRunId = @pDealIpdRunId
                WHERE  cbf.InternalName = 'PreMaturityLiquidityFund' 
						AND TriggerOrTestApplicable='TEST'


                UPDATE #PreMaturityLiquidity_PreWF 
                SET		DueAmount = IIF(FinalRequiredAmount - (PreMaturityLiquidity_bF + CapitalContribution) > 0
										, FinalRequiredAmount - (PreMaturityLiquidity_bF + CapitalContribution)
										, 0)
						,ResidualAmount = COALESCE(PreMaturityLiquidity_bF + CapitalContribution - FinalRequiredAmount,0)


			--select * from #PreMaturityLiquidity_PreWF

          DELETE FROM [Cb].[PreMaturityLiquidity_PreWF] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[PreMaturityLiquidity_PreWF] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,PreMaturityLiquidity_bF
						,RequiredAmount1
						,FinalRequiredAmount
						,CapitalContribution
						,DueAmount
						,ResidualAmount
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
          SELECT  DealIpdRunId
						,CoveredBondFundId
						,PreMaturityLiquidity_bF
						,RequiredAmount1
						,FinalRequiredAmount
						,CapitalContribution
						,DueAmount
						,ResidualAmount
						 ,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM   #PreMaturityLiquidity_PreWF 

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessPreMaturityLiquidity_PreWF', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO