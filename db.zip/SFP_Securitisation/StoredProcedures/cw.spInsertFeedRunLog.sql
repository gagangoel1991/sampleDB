USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spInsertFeedRunLog') IS NOT NULL 
	DROP PROCEDURE [cw].[spInsertFeedRunLog] ;
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [cw].[spInsertFeedRunLog]
/*-----------------------------------------------------
 * Author: Kapil Sharma
 * Date:	1.09.2020
 * Description:  This will insert the feed run log
 * 				
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
(
	@feedName			VARCHAR(200),
	@stageIdx			TINYINT,
	@fileName			VARCHAR(500)
)
AS
BEGIN
	BEGIN TRY
		DECLARE
			@feedStageId			SMALLINT,
			@status					VARCHAR(20),
			@createdDate			DATETIME,
			@createdBy				VARCHAR(40);

		SET @status = 'Started';
		SET @createdBy = 'System';
		SET @createdDate = GETDATE();

		SELECT 
			@feedStageId = FeedStageId 
		FROM 
			cfgCW.FeedStage fs
		JOIN 
			cfgCW.SourceSystemFeed ssf ON fs.SourceSystemFeedId = ssf.SourceSystemFeedId
		WHERE
			ssf.Name = @feedName
			AND fs.StageIndex = @stageIdx

		--Now insert record in FeedRunLog Table
		INSERT INTO [CW].[FeedRunLog](FeedStageId, StartDate, EndDate, Status, FileName, RelatedToDate, 
		CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
		VALUES(@feedStageId, @createdDate, NULL, @status, @fileName, NULL, 
		@createdBy, @createdDate, @createdBy, @createdDate)

		SELECT SCOPE_IDENTITY() AS FeedRunLogId;
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 3, 1, 'spInsertFeedRunLog', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System-ETL'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END

GO