USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetInvoiceList]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetInvoiceList]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetInvoiceList]
	/*
 * Author: Kapil Sharma
 * Date:	15.07.2020
 * Description:  This will return the THE INVOICE DATA
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * EXEC [cw].[spGetInvoiceList] 0
 * 	,0
 * 	,'2021-08-14'
 * 	,'2022-02-10'
 * 	,NULL
 * 	,''
 * 
 * -------------------------------------------------------
*/
	@pDealId INT = NULL
	,@pIPDRunId INT = 0
	,@pPaidStartDate DATETIME = NULL
	,@pPaidEndDate DATETIME = NULL
	,@pIPDDate DATETIME = NULL
	,@pUserName VARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @ipdDate DATE

		SELECT @ipdDate = CAST(IPD AS DATE)
		FROM [cw].[vwDealIpdDates] ipdDt
		JOIN cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE ipdRun.RunId = @pIPDRunId

		SELECT DISTINCT invoice.Name AS [Name]
			,invoice.InvoiceId
			,deal.DealId
			,deal.DealName
			,
			--dir.DealIpdId,
			--dir.RunId,
			ICT.InvoiceCategoryTypeId
			,ICT.Name AS InvoiceCategoryType
			,IC.InvoiceCategoryId
			,IC.Name AS InvoiceCategory
			,dcp.CounterpartyName
			,dcp.DealCounterpartyId
			,invoice.Description
			,CAST(invoice.Amount AS DECIMAL(38, 4)) Amount
			,invoice.PaidDate
			,invoice.DealIpdDate
			,invoice.UploadedFileName
			,invoice.OriginalFileName
			,dlv.DisplayText AS STATUS
			,invoice.ReferenceNumber AS ReferenceNumber
			,invoice.SourceSpotRate
			,invoice.SpotRate
			,invoice.InvoiceDate
			,CAST(invoice.InvoicePaidAmount AS DECIMAL(38, 4)) AS InvoicePaidAmount
			,invoice.CreatedBy AS CreatedBy
			,invoice.CreatedDate AS CreatedDate
			,invoice.ModifiedBy AS ModifiedBy
			,invoice.ModifiedDate AS ModifiedDate
		FROM [CW].[InvoiceData] invoice
		JOIN [cfgCW].[InvoiceCategory] IC ON IC.InvoiceCategoryId = invoice.InvoiceCategoryId
		JOIN [cfgCW].[InvoiceCategoryType] ICT ON IC.InvoiceCategoryTypeId = ICT.InvoiceCategoryTypeId
		JOIN cw.dealIpd di ON di.DealId = invoice.DealId
			AND di.IpdDate = invoice.DealIpdDate
		--JOIN 
		--	cw.dealipdrun dir ON di.dealIpdid = dir.dealipdId
		JOIN [cw].[vwDealIPDDates] dt ON dt.DealIpdID = di.DealIpdId
		JOIN [cw].[vw_ActiveDeal] deal ON invoice.DealId = deal.DealId
		JOIN [cw].[vw_ActiveDealCounterparty] dcp ON dcp.DealCounterpartyId = invoice.DealCounterpartyId
		JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = invoice.InvoiceStatusId
		JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
		WHERE (
				@pDealId = 0
				OR invoice.DealId = @pDealId
				)
			AND (
				(
					@pIPDRunId = 0
					AND @pPaidStartDate IS NOT NULL
					AND invoice.PaidDate >= @pPaidStartDate
					AND invoice.PaidDate <= @pPaidEndDate
					)
				OR (
					ISNULL(@pIPDRunId, 0) <> 0
					AND @pPaidStartDate IS NULL
					AND (CAST(invoice.DealIpdDate AS DATE) = CAST(@ipdDate AS DATE))
					)
				OR (
					ISNULL(@pIPDRunId, 0) <> 0
					AND @pPaidStartDate IS NULL
					AND (CAST(invoice.DealIpdDate AS DATE) = CAST(@pIPDDate AS DATE))
					)
				OR (
					@pPaidStartDate IS NULL
					AND (CONVERT(VARCHAR(6), CAST(invoice.DealIpdDate AS DATE), 112) = CONVERT(VARCHAR(6), CAST(@pIPDDate AS DATE), 112))
					)
				)
			AND dlt.TypeCode = 'InvoiceStatus'
		ORDER BY invoice.ModifiedDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetInvoiceList'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


