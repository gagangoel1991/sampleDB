USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRunInterestRateShortfallTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunInterestRateShortfallTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRunInterestRateShortfallTest] 
    @pDealIpdRunId INT,
	@pUserName  VARCHAR(80) ='System'      
AS  
--   
/*
 * Author: Suresh Pandey
 * Date:	08-02-2022
 * Description:  This will run the Interest Rate Short fall test and insert data for test.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Exec [cb].[spRunInterestRateShortfallTest] 6,1034,'suresh'
 * 
*/
BEGIN  
  
BEGIN TRY  

	DECLARE @result VARCHAR(10)='N/A',
			@interestRateShortfall  DECIMAL(38, 16) = 0, 				
			@interestRateShortfallMax  DECIMAL(38, 16) = 0, 				
			@interestRateShortfallHeadroom DECIMAL(38, 16) = 0 ,  
			@interestRateShortfallHeadroomMax DECIMAL(38, 16) = 0 ,  
			@interestRateShortfallHeadroomPercentage  DECIMAL(38, 16) = 0,  
			@reserveLedgerBF  DECIMAL(38, 16) = 0,  
			@interestRateSwap  DECIMAL(38, 16) = 0, 
			@availableExpenses  DECIMAL(38, 16) = 0,
			@availableRevenue  DECIMAL(38, 16) = 0,
			@totalARR  DECIMAL(38, 16) = 0, 
			@testTypeID INT,
			@revenueExpenses  DECIMAL(38, 16) = 0,
			@revenueIncome  DECIMAL(38, 16) = 0,
			@netRevenue  DECIMAL(38, 16) = 0,
			@dealId	INT;
 
			
	SELECT @testTypeID=TestTypeID  FROM cfgcb.TestType WHERE InternalName='InterestRateShortfallTest'

	SELECT  @dealId = di.DealId
		FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1

	SELECT    
		@availableExpenses =CAST(IsNull(Sum(TotalRequiredAmount),0) AS DECIMAL(38,16))  
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId
	WHERE
		dealId=@dealId
		AND DealIpdRunId=@pDealIpdRunId
		AND wc.InternalName = 'RevenuePriorityofPayments'
		AND wli.InternalName IN('RevenuePriorityofPayments_1.000'
								,'RevenuePriorityofPayments_2.000'
								,'RevenuePriorityofPayments_3.100'
								,'RevenuePriorityofPayments_3.200'
								,'RevenuePriorityofPayments_3.300'
								,'RevenuePriorityofPayments_3.400'
								,'RevenuePriorityofPayments_3.500'
								,'RevenuePriorityofPayments_5.000')
	
	
	SELECT    
		@interestRateSwap =CAST(ISNULL(SUM(TotalRequiredAmount),0) AS DECIMAL(38,16))  
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId
	WHERE
		dealId=@dealId
		AND DealIpdRunId=@pDealIpdRunId
		AND wc.InternalName = 'RevenuePriorityofPayments'
		AND wli.InternalName = 'RevenuePriorityofPayments_4.000'

	
	SELECT    
		@totalARR =CAST(ISNULL(SUM(TotalRequiredAmount),0) AS DECIMAL(38,4))  
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId
	WHERE
		dealId=@dealId
		AND DealIpdRunId=@pDealIpdRunId
		AND wc.InternalName = 'PreAvailableRevenueReceipts'
		AND wli.InternalName = 'PreAvailableRevenueReceipts_10.000'
	
	SELECT 
		@reserveLedgerBF =  CAST(IsNull(Sum(rf.ReserveFund_bF),0) AS decimal(38,4)) 
	FROM 
		cb.ReserveFund_PreWF rf
	JOIN 
		cfgcb.CoveredBondFund cbf ON cbf.CoveredBondFundId=rf.CoveredBondFundId
	WHERE 
		cbf.InternalName='ReserveFund'
		AND DealIpdRunId=@pDealIpdRunId



	SET @revenueExpenses = @availableExpenses
	SET @revenueIncome = @totalARR - @interestRateSwap 
	SET @netRevenue = @revenueIncome + @reserveLedgerBF 

	SET @interestRateShortfall = (SELECT @revenueExpenses - @netRevenue) 
	SET @interestRateShortfallMax  = (SELECT IIF(@interestRateShortfall>0,@interestRateShortfall,0))

	SET @interestRateShortfallHeadroom = (SELECT @netRevenue -@revenueExpenses)
	SET @interestRateShortfallHeadroomMax =  (SELECT IIF(@interestRateShortfallHeadroom>0,@interestRateShortfallHeadroom,0))

	SET @interestRateShortfallHeadroomPercentage = (SELECT  @interestRateShortfallHeadroomMax/@revenueExpenses)

	SET @result = (SELECT IIF(@interestRateShortfallHeadroomMax>0,'PASS','FAIL'))

	 
	IF ( Object_id('tempdb..#TestLineItemValue') IS NOT NULL ) 
		DROP TABLE #TestLineItemValue 

	CREATE TABLE #TestLineItemValue(
		TestLineItemID INT,
		InternalName VARCHAR(200),
		DealIpdRunId INT,
		[Value] VARCHAR(500))

	INSERT INTO #TestLineItemValue(TestLineItemID,InternalName,DealIpdRunId,[Value])
	SELECT TestLineItemID,InternalName,@pDealIpdRunId, CAST(@interestRateShortfallMax AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='InterestRateShortfall'
	UNION				  
	SELECT TestLineItemID,InternalName,@pDealIpdRunId, CAST(@interestRateShortfallHeadroomMax AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='InterestRateShortfallHeadroom'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId, CAST(@revenueExpenses AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='RevenueExpenses'
	UNION				  
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@netRevenue AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='NetRevenue'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId, CAST(@revenueIncome AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='RevenueIncome'
	UNION				  
	SELECT TestLineItemID,InternalName,@pDealIpdRunId, CAST(@reserveLedgerBF AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='ReserveFund'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId, CAST(CAST(@interestRateShortfallHeadroomPercentage * 100 AS decimal(18, 4)) AS VARCHAR) + '%' FROM cfgcb.TestLineItem WHERE InternalName='InterestRateShortfallHeadroomPercentage'
	
	
	IF NOT EXISTS(SELECT 1 FROM cb.TestLineItemValue tv
							JOIN cfgcb.TestLineItem tl  ON tl.TestLineItemID=tv.TestLineItemID
							JOIN cfgcb.TestType tt ON tt.TestTypeId=tl.TestTypeId
							WHERE DealIpdRunId =@pDealIpdRunId AND tt.TestTypeId=@testTypeID AND tl.InternalName !='InterestRateShortfallTestResult')
	BEGIN
		INSERT INTO cb.TestLineItemValue(TestLineItemID,DealIpdRunId,[Value],IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,DealIpdRunId,CAST(ISNULL([Value],0) AS VARCHAR),1,@pUserName,GETDATE(),@pUserName,GETDATE() FROM #TestLineItemValue 
		
	END
	ELSE
	BEGIN	
		
		UPDATE tv SET tv.[Value]=CAST(ISNULL(temp.[Value],0) AS VARCHAR),tv.ModifiedBy=@pUserName, tv.ModifiedDate=GETDATE() 
			FROM cb.TestLineItemValue tv
			JOIN #TestLineItemValue temp
				ON temp.TestLineItemID=tv.TestLineItemID AND temp.DealIpdRunId=tv.DealIpdRunId
		WHERE temp.DealIpdRunId=@pDealIpdRunId AND temp.InternalName !='InterestRateShortfallTestResult'

	END

	IF NOT EXISTS(SELECT 1 FROM cb.TestLineItemValue tv
							JOIN cfgcb.TestLineItem tl  ON tl.TestLineItemID=tv.TestLineItemID
							JOIN cfgcb.TestType tt ON tt.TestTypeId=tl.TestTypeId
							WHERE DealIpdRunId =@pDealIpdRunId AND tt.TestTypeId=@testTypeID AND tl.InternalName ='InterestRateShortfallTestResult')
	BEGIN

	INSERT INTO #TestLineItemValue(TestLineItemID,InternalName,DealIpdRunId,[Value])
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@result FROM cfgcb.TestLineItem WHERE InternalName='InterestRateShortfallTestResult'

		INSERT INTO cb.TestLineItemValue(TestLineItemID,DealIpdRunId,[Value],IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,DealIpdRunId,[Value],1,@pUserName,GETDATE(),@pUserName,GETDATE() FROM #TestLineItemValue WHERE InternalName ='InterestRateShortfallTestResult'
		
	END
	ELSE
	BEGIN	
		
		UPDATE tv SET tv.[Value]=temp.[Value],tv.ModifiedBy=@pUserName, tv.ModifiedDate=GETDATE() 
			FROM cb.TestLineItemValue tv
			JOIN #TestLineItemValue temp
				ON temp.TestLineItemID=tv.TestLineItemID AND temp.DealIpdRunId=tv.DealIpdRunId
		WHERE temp.DealIpdRunId=@pDealIpdRunId AND temp.InternalName ='InterestRateShortfallTestResult'

	END

	EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeID, @result, @pUserName
	

END TRY 
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cb.spRunInterestRateShortfallTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO