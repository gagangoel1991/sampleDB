USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spConditionActionDrawdownServicer') IS NOT NULL
	DROP PROCEDURE cw.spConditionActionDrawdownServicer
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spConditionActionDrawdownServicer
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  10.08.2021
 *   Description:  
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *      
 * 	 cw.spConditionActionDrawdownServicer 32,'fm\shriyad'
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80)
)
AS
BEGIN
	BEGIN TRY
		--DECLARE @pDealIpdRunId INT = 32, @pUserName	VARCHAR(80) ='fm\shriyad'

		 DECLARE @dealId  INT, 
		 @CollectionBusinessEndDate   datetime, 
		 @LoanCount decimal(38,16)  


		SELECT @dealId = DealId FROM  cw.vwDealIpdRun WHERE  DealIpdRunId = @pDealIpdRunId 

		SET @CollectionBusinessEndDate=(SELECT DealDateValue 
									  FROM   cw.vwDealDate 
									  WHERE  DealIpdRunId=@pDealIpdRunId 
											 AND DealDateKeyInternalName = 'CollectionBusinessEnd') 

		SELECT 
		@LoanCount = SUM(QuarterlyLoanCount)
			FROM
			[cw].[DealProductSwitchData] psd
			JOIN  [cfgCW].[ProductSwitchType] pst ON psd.ProductSwitchTypeId = pst.ProductSwitchTypeId AND pst.IsActive = 1
			WHERE
			dealid=@dealId
			AND CorrelatedDate =@CollectionBusinessEndDate
			AND pst.Name IN ('SVR-FIXED') 


		UPDATE ct
		SET LoanCount = @LoanCount 
		FROM cw.DealIpdConditionTest ct, cfgcw.DealCondition dc
		WHERE ct.DealConditionId = dc.DealConditionId
		AND dc.DealId = @dealId
		AND ct.DealIpdRunId = @pDealIpdRunId
		AND dc.ActionStoredProcedure = 'cw.spConditionActionDrawdownServicer'

		END TRY 

      BEGIN CATCH 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spConditionActionDrawdownServicer', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

END 


GO
