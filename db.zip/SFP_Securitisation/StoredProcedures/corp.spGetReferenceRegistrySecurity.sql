USE SFP_Securitisation
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'corp.spGetReferenceRegistrySecurity') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE corp.spGetReferenceRegistrySecurity
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE corp.spGetReferenceRegistrySecurity
      @pDealIrConfigId		INT, 
	  @pAsAtDate Date = NULL,  
	  @pDealID INT, 
	  @pUserName VARCHAR(100),
	  @pPoolID INT = 0,
	  @pOutputType VARCHAR(20) = ''
AS
BEGIN

	DECLARE @CorporateDealId INT = (Select AssetClassDealId from [corp].[vwActiveDeal] WHERE DealId =  @pDealID);
   	
	EXEC [ps].[spGenerateReferenceRegistryReports] 
	@pDealIrConfigId = @pDealIrConfigId, 
	@pUserName = @pUserName , 
	@pDealID = @CorporateDealId , 
	@pAsAtDate= @pAsAtDate ,
	@pTabType = 'Security',
	@pPoolID = @pPoolID,
	@pOutputType = @pOutputType

END


	