USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spIR_GetSwapRatingTriggers_Deimos]') IS NOT NULL
	DROP PROCEDURE [cb].[spIR_GetSwapRatingTriggers_Deimos] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
--==================================    
--Author: Ravindra Singh  
--Date: 24-02-2022   
--Description: This will return the Deal rating triggers detail for IR for Deimos Deal
--[cb].[spIR_GetSwapRatingTriggers_Deimos]  '2021-05-28', 'DEIMOS'  
--==================================     
CREATE PROCEDURE [cb].[spIR_GetSwapRatingTriggers_Deimos]   
(  
 @pAsAtDate datetime,   
 @pDealName  varchar(200)  
)       
AS    
BEGIN    
    
BEGIN TRY     
 DECLARE   
  @dealIpdRunId  INT,  
        @dealId    SMALLINT,  
        @ipdDate   DATETIME,  
        @dealIpdRunVersion SMALLINT   
  
 SELECT   
  @dealIpdRunId = dir.DealIpdRunId  
  , @dealId = dir.DealId  
  , @ipdDate = ipddate  
  , @dealIpdRunVersion = DealIpdRunVersion  
 FROM     
  cw.vwDealIpdDates dt  
 JOIN  
  cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId   
  AND dir.DealId = dt.DealId  
 WHERE   
  dir.InternalDealName = @pDealName  
  AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)  
   
 SELECT   
  CASE 
  WHEN t.DisplayName ='IR Swap Moody''s Qualifying Collateral Trigger'
  THEN REPLACE(t.DisplayName, 'IR Swap Moody''s Qualifying Collateral Trigger', 'Interest Rate Swap Provider Downgrade - Moody''s Qualifying Collateral Trigger *6')
  WHEN t.DisplayName ='IR Swap Moody''s Qualifying Transfer Trigger'
  THEN REPLACE(t.DisplayName, 'IR Swap Moody''s Qualifying Transfer Trigger', 'Interest Rate Swap Provider Downgrade - Moody''s Qualifying Transfer Trigger *6')
  WHEN t.DisplayName ='IR Swap Initial Fitch Rating Event (Formula 1)'
  THEN REPLACE(t.DisplayName, 'IR Swap Initial Fitch Rating Event (Formula 1)', 'Interest Rate Swap Provider Downgrade - Initial Fitch Rating Event (Formula 1) *7')
  WHEN t.DisplayName ='IR Swap Initial Fitch Rating Event (Formula 2)'
  THEN REPLACE(t.DisplayName, 'IR Swap Initial Fitch Rating Event (Formula 2)', 'Interest Rate Swap Provider Downgrade - Initial Fitch Rating Event (Formula 2)')

  WHEN t.DisplayName ='IR Swap Subsequent Fitch Rating Event'
  THEN REPLACE(t.DisplayName, 'IR Swap Subsequent Fitch Rating Event', 'Interest Rate Swap Provider Downgrade - Subsequent Fitch Rating Event')
  

  WHEN t.DisplayName ='CB Swap Moody''s Qualifying Collateral Trigger(Series 3 and 8)'
  THEN REPLACE(t.DisplayName, 'CB Swap Moody''s Qualifying Collateral Trigger(Series 3 and 8)', 'Covered Bond Swap Provider Downgrade - Moody''s Qualifying Collateral Trigger (Series 8) *6')
  
  WHEN t.DisplayName ='CB Swap Qualifying Moody''s Transfer (Series 3 and 8)'
  THEN REPLACE(t.DisplayName, 'CB Swap Qualifying Moody''s Transfer (Series 3 and 8)', 'Covered Bond Swap Provider Downgrade - Qualifying Moody''s Transfer (Series 8) *6')
  

  WHEN t.DisplayName ='CB Swap Provider Upgrade (Series 9 and 10)'
  THEN REPLACE(t.DisplayName, 'CB Swap Provider Upgrade (Series 9 and 10)', 'Covered Bond Swap Provider Upgrade (Series 9)')
  
  WHEN t.DisplayName ='CB Swap Provider Downgrade Qualifying Moody''s Transfer (Series 9 and 10)'
  THEN REPLACE(t.DisplayName, 'CB Swap Provider Downgrade Qualifying Moody''s Transfer (Series 9 and 10)', 'Covered Bond Swap Provider Downgrade Qualifying Moody''s Transfer (Series 9)')
  


  WHEN t.DisplayName ='CB Swap Provider Downgrade -  Initial Fitch Rating Event (Formula 1)'
  THEN REPLACE(t.DisplayName, 'CB Swap Provider Downgrade -  Initial Fitch Rating Event (Formula 1)', 'Covered Bond Swap Provider Downgrade -  Initial Fitch Rating Event (Formula 1) *7')
  

  WHEN t.DisplayName ='CB Swap Provider Downgrade - Initial Fitch Rating Event (Formula 2)'
  THEN REPLACE(t.DisplayName, 'CB Swap Provider Downgrade - Initial Fitch Rating Event (Formula 2)', 'Covered Bond Swap Provider Downgrade - Initial Fitch Rating Event (Formula 2)')
  WHEN t.DisplayName ='CB Swap Provider Downgrade - Subsequent Fitch Rating Event'
  THEN REPLACE(t.DisplayName, 'CB Swap Provider Downgrade - Subsequent Fitch Rating Event', 'Covered Bond Swap Provider Downgrade - Subsequent Fitch Rating Event')
  
  ELSE t.DisplayName
  END AS [Event],   
  t.TriggerSummary AS [Summary of Event],  
  Replace(cw.fnIR_GetTriggerThresholdRating(tr.DealIpdTriggerResultId),'Long Term Counterparty','CRA') AS [Trigger (S&P, Moody's, Fitch, DBRS; Short-term, Long-term)],
  CASE WHEN tr.IsBreached = 1 THEN 'YES' ELSE 'NO' END AS [Trigger Breached (Yes/No)],   
  t.Consequences AS [Consequence of a Trigger Breach]  
  --'' AS [Action Taken]  
 FROM   
  cw.DealIpdTriggerResult tr   
 JOIN   
  cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId  
 JOIN   
  cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId  
 JOIN   
  cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId  
 JOIN   
  cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId  
 WHERE    
  tr.DealIpdRunId=@dealIpdRunId AND tm.DealId=@dealId   
  AND tt.InternalName = 'SwapRatingTrigger'  

  ORDER BY
   CASE
			 WHEN t.InternalName='IRSwapMoody''sQualifyingCollateralTrigger' THEN 1
			 WHEN t.InternalName='IRSwapMoody''sQualifyingTransferTrigger' THEN 2
			 WHEN t.InternalName='IRSwapInitialFitchRatingEvent(Formula1)' THEN 3
			 WHEN t.InternalName='IRSwapInitialFitchRatingEvent(Formula2)' THEN 4	
			 WHEN t.InternalName='IRSwapSubsequentFitchRatingEvent' THEN 5
			 WHEN t.InternalName='CBSwapMoody''sQualifyingCollateralTrigger(Series3and8)' THEN 6
			 WHEN t.InternalName='CBSwapQualifyingMoody''sTransfer(Series3and8)' THEN 7	
			 WHEN t.InternalName='CBSwapProviderUpgrade(Series9and10)' THEN 8
			 WHEN t.InternalName='CBSwapProviderDowngradeQualifyingMoody''sTransfer(Series9and10)' THEN 9
			 WHEN t.InternalName='CBSwapProviderDowngrade-InitialFitchRatingEvent(Formula1)' THEN 10
			 WHEN t.InternalName='CBSwapProviderDowngrade-InitialFitchRatingEvent(Formula2)' THEN 11
			 WHEN t.InternalName='CBSwapProviderDowngrade-SubsequentFitchRatingEvent' THEN 12
			 
			 				
			END ASC
  
  
END TRY    
BEGIN CATCH    
 DECLARE     
  @errorMessage     NVARCHAR(MAX),    
  @errorSeverity    INT,    
  @errorNumber      INT,    
  @errorLine        INT,    
  @errorState       INT;    
    
 SELECT     
 @errorMessage = ERROR_MESSAGE()
 ,@errorSeverity = ERROR_SEVERITY()
 ,@errorNumber = ERROR_NUMBER()
 ,@errorLine = ERROR_LINE()
 ,@errorState = ERROR_STATE()    
    
 EXEC app.SaveErrorLog 1, 1, 'cw.spGetRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, 'System'    
      
 RAISERROR (@errorMessage,    
    @errorSeverity,    
             @errorState )    
END CATCH    
END  