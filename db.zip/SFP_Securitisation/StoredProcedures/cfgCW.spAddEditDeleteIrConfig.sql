IF OBJECT_ID('cfgCW.spAddEditDeleteIrConfig') IS NOT NULL
	DROP PROC  cfgCW.spAddEditDeleteIrConfig
GO
CREATE PROCEDURE cfgCW.spAddEditDeleteIrConfig
(
/*
 * Author: saurabh bhatia
 * Date:	16-02-2021
 * Description:  this will add update or delete 
*/
	@pDealIrConfigId int,
	@pName varchar(100),
	@pDescription varchar(100),
	@pDealId smallint,
	@pTemplateId int NULL,
	@pOriginalFileName varchar(100),
	@pUploadedFileName varchar(100),
	@pWorkFlowStepId smallint,
	@pDealIrStratMapList cfgCW.DealIrStratMapList readonly,
	@pUserName varchar(80),
	@pAction varchar(20)
)
AS
BEGIN
BEGIN TRY  
BEGIN TRANSACTION 

IF(@pAction='Add')
BEGIN
	DECLARE @OutputTblConfigId TABLE (DealIrConfigId INT);
		INSERT INTO [cfgCW].[IR_DealIrConfig] (
			 [Name]
			,[Description]
			,[DealId]
			,[TemplateId]
			,[OriginalFileName]
			,[UploadedFileName]
			,[WorkFlowStepId]
			,[IsLocked]
			,[CreatedBy]
			,[ModifiedBy]	
			)
		 OUTPUT INSERTED.DealIrConfigId INTO @OutputTblConfigId(DealIrConfigId)
		 VALUES (
			@pName ,
			@pDescription ,
			@pDealId ,
			@pTemplateId ,
			@pOriginalFileName ,
			@pUploadedFileName,
			@pWorkFlowStepId ,
			0,
			@pUserName,
			@pUserName
		 );
		
		 DECLARE @DealIrConfigId int = (SELECT DealIrConfigId FROM @OutputTblConfigId )
		
		 INSERT INTO [cfgCW].[IR_DealIrStratMap] ( 
						DealIrConfigId	 ,
						StratId			 ,
						AnchorCell		 ,
						CreatedBy		 ,		
						ModifiedBy	
						)
					SELECT 
					 @DealIrConfigId,
					 StratId,
					 AnchorCell,
					 @pUserName,
					 @pUserName
		  FROM @pDealIrStratMapList  
END

ELSE 
IF(@pAction='Update')
BEGIN
	
	UPDATE [cfgCW].[IR_DealIrConfig]
	SET [Name]					= 	 @pName,
		[Description]			=    @pDescription ,
		[DealId]				= 	 @pDealId ,
		[TemplateId]				= 	 @pTemplateId ,
		[OriginalFileName]		= 	 @pOriginalFileName,
		[UploadedFileName]		= 	 @pUploadedFileName,
		[WorkFlowStepId]		= 	 @pWorkFlowStepId ,
		[IsLocked]				= 	 0,
		[ModifiedBy]			=	 @pUserName,
		[ModifiedDate]			=	 GETDATE()
	WHERE DealIrConfigId	= @pDealIrConfigId;


		WITH TARGET AS 
	(
	    SELECT * 
	    FROM [cfgCW].[IR_DealIrStratMap]
	    WHERE DealIrConfigId = @pDealIrConfigId
	)
	  MERGE INTO TARGET  
	  USING @pDealIrStratMapList AS source	 
	  ON (source.DealIrStratMapId = target.DealIrStratMapId)  
	    WHEN MATCHED AND source.AnchorCell <> target.AnchorCell THEN
	        UPDATE 
			SET AnchorCell = source.AnchorCell,				
				ModifiedBy= @pUserName,
				ModifiedDate =getdate()

	    WHEN NOT MATCHED BY TARGET THEN  
	        INSERT (DealIrConfigId, StratId,AnchorCell,CreatedBy,ModifiedBy)  
	        VALUES (@pDealIrConfigId,source.StratId,source.AnchorCell,@pUserName,@pUserName)  
		WHEN NOT MATCHED BY SOURCE  
			THEN DELETE;
END
ELSE IF(@pAction='Delete')
BEGIN
	DELETE FROM [cfgCW].[IR_DealIrStratMap] WHERE  DealIrConfigId	= @pDealIrConfigId;
	DELETE FROM [cfgCW].[IR_DealIrConfig]  WHERE DealIrConfigId	= @pDealIrConfigId;
END
COMMIT TRAN 
 END TRY  
  
 BEGIN CATCH  

  IF @@TRANCOUNT > 0
        ROLLBACK TRAN

  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2, 1, 'spAddEditDeleteIrConfig', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END
