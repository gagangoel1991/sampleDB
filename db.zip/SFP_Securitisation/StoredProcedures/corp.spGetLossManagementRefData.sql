USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spGetLossManagementRefData]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spGetLossManagementRefData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 22-Sept-2022
Description    : This will return Loss Management Refernce Data
Execution      : EXEC [corp].[spGetLossManagementRefData] 'Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/


CREATE PROCEDURE [corp].[spGetLossManagementRefData]
	@pUserName VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE @LossWorkflowType INT = (SELECT [WorkflowTypeId] FROM [cfgcw].[WorkflowType] WHERE [Name] = 'Loss_Management' AND [IsActive] = 1)

		/* LIST OF STATUS AVAILABLE IN LOSS MANAGEMENT */
		SELECT 
			[WorkflowStepId] AS [Value]
			,[DisplayName] AS [Title]
		FROM [cfgcw].[WorkflowStep] 
		WHERE WorkflowTypeId = @LossWorkflowType AND [IsActive] = 1

		/* LIST OF LISTING PAGE TO STATUS MAP */
		SELECT
			[LWMap].[WorkflowStepId] AS [Value]
			,[LP].[ListingPageName] AS [Title]
		FROM [corp].[ListingWorkflowStepMap] LWMap
		INNER JOIN [app].[ListingPage] LP ON [LP].[ListingPageId] = [LWMap].[ListingPageId]
		WHERE [LP].[IsActive] = 1 AND [LWMap].[IsActive] = 1

		/* LIST OF STATUS IN UNDER REVIEW STATUS DROPDOWN */
		SELECT
			[WorkflowStepId] AS [Value]
			,[DisplayName] AS [Title]
		FROM [cfgcw].[WorkflowStep] 
		WHERE [StepName] IN ('UnderReview', 'RemovedFromReview', 'PotentialLoss', 'ReviewedNoAction') AND [IsActive] = 1
		ORDER BY [WorkflowStepId]

		/* LIST OF CREDIT EVENT TYPES */
		SELECT [LookUpValue] AS [Value], [LookUpValueDescription] AS [Title]
		FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]
		WHERE [ReportTemplateName] = 'SFP+' 
			AND [LookUpName] = 'CB Credit Event Type'

	   /* LIST OF ACCOUNT STATUS IN UNDER REVIEW ACCOUNT STATUS DROPDOWN */
	   SELECT [LookUpValue] AS [Value], [LookUpValueDescription] AS [Title]
	   FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]
	   WHERE [ReportTemplateName] = 'SFP+' 
			AND [LookUpName] = 'AccountStatus' 
		    AND [LookUpValueDescription] IN ('Defaulted according to Article 178 of Regulation (EU) No 575/2013 (DFLT)',
			 'Not defaulted according to Article 178 of Regulation (EU) No 575/2013 but classified as defaulted due to another definition of default being met (NDFT)',
			 'Defaulted both according to Article 178 of Regulation (EU) No 575/2013 and according to another definition of default being met (DTCR)',
			 'Defaulted only under another definition of default being met (DADB)')
			 

     /*LIST OF RECOVERY SOURCE IN FINAL CLAIMS RECOVERY SOURCE DROPDOWN */
	 SELECT [LookUpValue] AS [Value], [LookUpValueDescription] AS [Title]
	 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]
	 WHERE [ReportTemplateName] = 'SFP+' 
			AND [LookUpName] = 'RecoverySource'

    /* LIST OF DEFAULT REASON IN UNDER REVIEW RESAON FOR DEFAULTER FORECLOSURE DROPDOWN */
	 SELECT [LookUpValue] AS [Value], [LookUpValueDescription] AS [Title]
	 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]
	 WHERE [ReportTemplateName] = 'SFP+' 
			AND [LookUpName] = 'ReasonforDefaultorForeclosure'


	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetLossManagementRefData',
			@errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
