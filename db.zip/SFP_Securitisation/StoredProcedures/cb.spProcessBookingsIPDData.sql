USE [SFP_Securitisation]

GO

IF OBJECT_ID('cb.spProcessBookingsIPDData') IS NOT NULL
	DROP PROCEDURE cb.spProcessBookingsIPDData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure cb.spProcessBookingsIPDData    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	12.02.2023
 * Description:  Bookings lineitem save data.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
	
exec cb.spProcessBookingsIPDData @pDealIpdRunId=74,@pUserName ='kumavnb'
 * -------------------------------------------------------
*/    
        
        
CREATE PROC [cb].spProcessBookingsIPDData
	@pDealIpdRunId INT, 
	@pUserName  VARCHAR(20) 
AS        
BEGIN  
	
	BEGIN TRY  
		
		DECLARE
			@dealId							INT,
			@dealName						VARCHAR(55),
			@dealRegion						VARCHAR(20),
			@NextIpd						DATE,
			@pAsAtDate						DateTime

		
		SELECT 	@dealId = d.DealId, @dealName = r.DealName
			 , @pAsAtDate = CAST(d.IPD AS DATE)
			 , @NextIpd = d.NextIPD
			FROM cw.vwDealIpdDates d
			JOIN cw.vwDealIpdRun r			
			ON CAST(d.IPD AS DATE) = r.IpdDate
				AND d.DealIpdId =r.DealIpdId
			Where DealIpdRunId=@pDealIpdRunId

		SELECT @dealRegion = dlv.[Value], @dealId = DealId FROM cfg.Deal deal
		JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = deal.JurisdictionMarkerId
		WHERE deal.DealName = @dealName
		

		--SELECT   
		--  @pDealIpdRunId = dir.DealIpdRunId ,
		--  @NextIpd = ipdDt.NextIPD
		--FROM     
		--	 cw.vwDealIpdDates ipdDt  
		--JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		--JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		--JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		--JOIN cw.vwDealIPDDates did ON did.DealIpdId = di.DealIpdId
		--WHERE   
		--	deal.DealName = @pDealName  
		--	AND CAST(ipdDt.Ipd AS DATE)= @pAsAtDate   
		--	AND dir.IpdSequence <> 0  


		DECLARE
				@nextIpdPreviousBusinessDay		DATE,
				@depositDate					DATE,
				@monthFirstDay					DATE,
				@loanMaturityDate				DATE,
				@loanValueDate					DATE,
				@prevBusinessDay				DATE,
				@Value							VARCHAR(MAX),
				@CalculateValue					FLOAT,
				@latestIpdAdviceDate			DATE
		
		---========================== Booking LineItem Value from expression
		
		IF (Select Count(*) FROM [cb].[BookingLineItemValue] where [DealIpdRunId] =  @pDealIpdRunId)  = 0 
		BEGIN
			Insert INTO [cb].[BookingLineItemValue]
			([DealIpdRunId], [BookingLineItemId], Value, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			Select @pDealIpdRunId, vbli.BookingLineItemId, '0.00', @pUserName, getDate(), @pUserName, getDate()
			FROM [CB].[vwBookingLineItems] 	vbli		
			Where DealName=@dealName and vbli.ActiveEndDate is null
		END
		ELSE
			UPDATE [cb].[BookingLineItemValue] SET VALUE='0.00' WHERE DealIpdRunId=@pDealIpdRunId

		
		SELECT	vbli.BookingLineItemId, 
				vbli.ExpressionId, 
				ev.Value Value
				INTO #tempBookingExpressionLineItemValue
		FROM   [CB].[vwBookingLineItems] vbli
				JOIN cw.ExpressionValue ev ON vbli.ExpressionId = ev.ExpressionId 
		WHERE  ev.DealIpdRunId = @pDealIpdRunId and  vbli.ActiveEndDate is null


		Update bliv
		SET bliv.Value= tbeliv.Value
		FROM 
		[cb].[BookingLineItemValue] bliv
		INNER JOIN #tempBookingExpressionLineItemValue tbeliv on bliv.BookingLineItemId = tbeliv.BookingLineItemId
		Where bliv.DealIpdRunId = @pDealIpdRunId
		
		---============================================================

		SELECT @nextIpdPreviousBusinessDay = [cw].[fnGetBusinessDate](@NextIpd, @dealRegion, -1, 1)
		SELECT @loanMaturityDate = @nextIpdPreviousBusinessDay

		SELECT @prevBusinessDay = [cw].[fnGetBusinessDate](@pAsAtDate, @dealRegion, -1, 1)
		SELECT @monthFirstDay = DATEADD(month, DATEDIFF(month, 0, @pAsAtDate), 0)

		SELECT TOP 1 @depositDate =  AsAtDate
		FROM sfp.syn_SfpModel_vw_Calendar_v1
		WHERE AsAtDate>@pAsAtDate AND IsWorkingDay = 1 AND RegionCode = @dealRegion
		ORDER BY AsAtDate ASC  
			
		IF @depositDate IS NULL
		BEGIN
			SELECT @depositDate = AdviceDate FROM cw.CollectionLedger 
			WHERE DealId = @dealId AND CollectionDate = @pAsAtDate
		END

		SELECT TOP 1 @loanValueDate = CASE WHEN  IsWorkingDay = 0 THEN @pAsAtDate ELSE AsAtDate END
			FROM sfp.syn_SfpModel_vw_Calendar_v1
			WHERE AsAtDate>@pAsAtDate AND RegionCode = @dealRegion
			ORDER BY AsAtDate ASC  


		Declare @totalCollectionBeforeIpd	DECIMAL(36, 18),
				@totalInterestBeforeIpd		DECIMAL(36, 18),
				@totalReserveIntBeforeIpd	DECIMAL(36, 18)

		SELECT @totalCollectionBeforeIpd = SUM(TotalCollection) FROM cb.SFPCollectionInterest 
		WHERE CAST(CollectionDate AS DATE)>=CAST(@monthFirstDay AS DATE) AND CAST(DepositDate AS DATE)<CAST(@pAsAtDate AS DATE)

		
		SELECT @totalInterestBeforeIpd = SUM(InterestAmount) FROM cb.SFPCollectionInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@monthFirstDay AS DATE) AND CAST(DepositDate AS DATE)<CAST(@pAsAtDate AS DATE)

		SELECT @totalReserveIntBeforeIpd = SUM(InterestAmount) FROM cb.ReserveInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@monthFirstDay AS DATE) AND CAST(DepositDate AS DATE)<CAST(@pAsAtDate AS DATE)

		
		--Select @pDealIpdRunId '@pDealIpdRunId', @pAsAtDate, @monthFirstDay '@monthFirstDay', @depositDate '@depositDate'
		--, @loanValueDate '@loanValueDate', @loanMaturityDate '@loanMaturityDate', @nextIpdPreviousBusinessDay '@nextIpdPreviousBusinessDay'
		
		CREATE TABLE #Invoice(Name varchar(max), InvoiceId INT, DealId INT, DealName varchar(max), InvoiceCategoryTypeId INT, InvoiceCategoryType varchar(max), InvoiceCategoryId INT, InvoiceCategory varchar(max)
		, CounterpartyName varchar(max), DealCounterpartyId INT, Description varchar(max), Amount DECIMAL(38,18), PaidDate DATETIME, DealIpdDate DATETIME, UploadedFileName varchar(max), OriginalFileName varchar(max), STATUS varchar(max), ReferenceNumber varchar(max)
		, SourceSpotRate DECIMAL(38, 18), SpotRate DECIMAL(38, 18), InvoiceDate DATETIME, InvoicePaidAmount DECIMAL(38,18), CreatedBy varchar(max), CreatedDate DATETIME, ModifiedBy varchar(max), ModifiedDate DATETIME)
		
		INSERT INTO #Invoice
		EXEC [cw].[spGetInvoiceList] @pDealId=@dealId, @pIPDRunId=@pDealIpdRunId, @pPaidStartDate=null, @pPaidEndDate=null, @pIPDDate=null, @pUserName='system'

		SET @latestIpdAdviceDate = (SELECT MAX(DepositDate) from [cb].[SFPCollectionInterest] Where DepositDate<CAST(@pAsAtDate AS DATE))
		SET @Value = ISNULL((Select InterestAmount from [cb].[SFPCollectionInterest]  where DepositDate = @latestIpdAdviceDate),0)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Daily_GIC_Loan_Interest_MT02', @pValue =@Value
		

		SET @Value = CAST(CAST( ISNULL((Select InterestAmount from [cb].ReserveInterest  where DepositDate = @latestIpdAdviceDate),0) as DECIMAL(38, 2))  AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Credit_Reserve_Ledger_Interest_04', @pValue =@Value

	
		SET @Value = CAST(CAST(@totalCollectionBeforeIpd as DECIMAL(38, 2))  AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Daily_GIC_Loan_Amount_Principal_NGL01', @pValue = @Value

		SET @Value = CAST(CAST(@totalInterestBeforeIpd + @totalReserveIntBeforeIpd as DECIMAL(38, 2))  AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Daily_GIC_Loan_Amount_Interest_NGL02', @pValue =@Value

		Declare @CashDepositRBSGTPrincipal varchar(20) = 'FALSE'
		SELECT @CashDepositRBSGTPrincipal = ManualFieldValue  from [cb].[vwManualField] where ManualFieldInternalName='CashDepositwithRBSGT' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Cash_on_Deposit_with_RBS_GT_Principal_NGL03', @pValue = @CashDepositRBSGTPrincipal


		SET @Value =Convert(varchar, @loanValueDate, 103)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='NWB_Loan_Value_Date_Principal_NGL05', @pValue =@Value

		SET @Value =Convert(varchar, @loanMaturityDate, 103)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='NWB_Loan_Maturity_Date_Principal_NGL07', @pValue =@Value

		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='FALSE' THEN  CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('Daily_GIC_Loan_Principal_MT01', 'Daily_GIC_Loan_Interest_MT02') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Daily_GIC_Loan_IPD-1_NCBD_01', @pValue =@Value
		
		--Pending Items ( false condition overwrite value check )
		--Maturing_Retained_Principal_IPD-1_NCBD_03

		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='FALSE' THEN  CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('Credit_Reserve_Ledger_Principal_MT03', 'Credit_Reserve_Ledger_Interest_04') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Credit_Reserve_Ledger_IPD-1_NCBD_02', @pValue =@Value
		
		--IPD-1_Collections_Amounts_NCBD_04  - Default value as 0.00

		Select @Value=   CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('Maturing_Daily_GIC_Loan_IPD-1_NCBD_01','Maturing_Credit_Reserve_Ledger_IPD-1_NCBD_02','Maturing_Retained_Principal_IPD-1_NCBD_03',
		'IPD-1_Collections_Amounts_NCBD_04', 'Adjustment_of_Maturing_NWB_Trade_vs_Cash_NCBD_05') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_IPD-1_Cashflow_NCBD_06', @pValue =@Value

		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_Account_Balance_NCBD_07', @pValue =@Value
	
		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='TRUE' THEN  CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('Daily_GIC_Loan_Principal_MT01', 'Daily_GIC_Loan_Interest_MT02') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Daily_GIC_Loan_IPD_NCBD_08', @pValue =@Value
		

		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='TRUE' THEN  CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('Credit_Reserve_Ledger_Principal_MT03', 'Credit_Reserve_Ledger_Interest_04') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Credit_Reserve_Ledger_IPD_NCBD_09', @pValue =@Value

		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='TRUE' THEN  CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName = 'Retained_Principal_MT05' and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Retained_Principal_IPD_NCBD_10', @pValue =@Value
		
		
		--IPD_Collections_Amounts_NCBD_11   - Default value as 0.00

	
		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='TRUE' THEN  CAST(-1* SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('New_Daily_GIC_Loan_Amount_Principal_NGL01', 'New_Daily_GIC_Loan_Amount_Interest_NGL02') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Daily_GIC_Loan_NCBD_12', @pValue =@Value
		
		
		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='TRUE' THEN  CAST(-1* SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('Credit_Reserve_Ledger_Principal_MT03') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Credit_Reserve_Ledger_IPD_NCBD_13', @pValue =@Value

			
		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='TRUE' THEN  CAST(-1* SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from cw.ExpressionValue WHERE ExpressionId =425 and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Retained_Principal_NCBD_14', @pValue =@Value

		--GT_Interest_Top-up_NCBD_15 - Default value as 0.00
		--New_GIC_Loan_for_IPD_Collections_NCBD_19 - Default value as 0.00

		--
		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='FALSE' THEN  CAST(-1* SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('New_Daily_GIC_Loan_Amount_Principal_NGL01', 'New_Daily_GIC_Loan_Amount_Interest_NGL02') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Cumulative_Daily_GIC_Loan_NCBD_20', @pValue =@Value

		IF @CashDepositRBSGTPrincipal ='TRUE' 
		BEGIN
			SET @Value=  '0.00' 
			exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Credit_Reserve_Ledger_IPD+1_NCBD_21', @pValue =@Value
		END 

		Select @Value=  CASE WHEN @CashDepositRBSGTPrincipal ='FALSE' THEN  CAST(-1* SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR) ELSE '0.00' END 
		from cw.ExpressionValue WHERE ExpressionId =425 and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Additional_Cash_on_Account_from_Trans_NCBD_22', @pValue =@Value

		Select @Value=   CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('New_GIC_Loan_for_IPD_Collections_NCBD_19', 'New_Cumulative_Daily_GIC_Loan_NCBD_20', 'New_Credit_Reserve_Ledger_IPD+1_NCBD_21'
		, 'Additional_Cash_on_Account_from_Trans_NCBD_22', 'New_Retained_Principal_IPD_NCBD_23') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_IPD+1_Cashflow_NCBD_24', @pValue =@Value
		
		
		--Wells_Fargo_Covered_Bonds_SwapsPayments_NCBT_05 - Default value as 0.00
		--Repay_RBS_Cash_Capital_Contributions_NCBT_17 - Default value as 0.00

		
		

		--Transfer_of_Funds_to_Trans_NCBD_16
		Select @CalculateValue=   SUM(CAST(VALUE as DECIMAL(38,2)))
		from [cb].[vwBookingLineItemValue] 
		WHERE BookingGroup ='NWB Covered Bonds Transaction Account (600001 - 48803413 / NWBCOVBONDS-GBP)'  and DealIpdRunId=@pDealIpdRunId
		--AND LineItemInternalName <> 'Net_Cashflow_NCBT_25'

		Select @CalculateValue= ISNULL(@CalculateValue,0) +   CAST(VALUE as DECIMAL(38,2))
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName='Trans_Account_cash_to_be_utilised_Principal_MT13'  and DealIpdRunId=@pDealIpdRunId
		
		---====need to add invoice data
		SELECT @CalculateValue= ISNULL(@CalculateValue,0) +  (-1* ISNULL(SUM(Amount),0)) FROM #Invoice
		
		
		Select @Value=   CAST(CAST(@CalculateValue as DECIMAL(38,2)) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Transfer_of_Funds_to_Trans_NCBD_16', @pValue = @Value

		Select @Value=   CAST(-1*CAST(@CalculateValue as DECIMAL(38,2)) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Transfer_of_Funds_from_GIC_NCBT_01', @pValue = @Value
		
		Select @Value=   CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('Maturing_Daily_GIC_Loan_IPD_NCBD_08', 'Maturing_Credit_Reserve_Ledger_IPD_NCBD_09', 'Maturing_Retained_Principal_IPD_NCBD_10'
		, 'IPD_Collections_Amounts_NCBD_11', 'New_Daily_GIC_Loan_NCBD_12', 'New_Credit_Reserve_Ledger_IPD_NCBD_13', 'New_Retained_Principal_NCBD_14', 'GT_Interest_Top-up_NCBD_15', 'Transfer_of_Funds_to_Trans_NCBD_16')
		and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_IPD_Cashflow_NCBD_17', @pValue =@Value

		
		Select @Value=   CAST(SUM(CAST(VALUE as DECIMAL(38,2))) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('Net_IPD-1_Cashflow_NCBD_06', 'Net_IPD_Cashflow_NCBD_17') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_Account_Balance_IPD_NCBD_18', @pValue =@Value
		

		Select @CalculateValue=   SUM(CAST(VALUE as DECIMAL(38,2))) 
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('Net_IPD+1_Cashflow_NCBD_24', 'Net_IPD_Cashflow_NCBD_17', 'Net_IPD-1_Cashflow_NCBD_06') and DealIpdRunId=@pDealIpdRunId
		SET @Value = CAST((CAST(@CalculateValue as DECIMAL(38,2))) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_IPD_Period_Cashflow_NCBD_25', @pValue =@Value
		
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_Account_Balance_IPD+1_NCBD_26', @pValue =@Value

		
		Select @CalculateValue=   SUM(CAST(VALUE as DECIMAL(38,2)))
		from [cb].[vwBookingLineItemValue] 
		WHERE BookingGroup ='NWB Covered Bonds Transaction Account (600001 - 48803413 / NWBCOVBONDS-GBP)'  and DealIpdRunId=@pDealIpdRunId

		
		---====invoice data
		SELECT @CalculateValue= ISNULL(@CalculateValue,0) +   (-1* ISNULL(SUM(Amount),0)) FROM #Invoice

		SET @Value = CAST(CAST(@CalculateValue as DECIMAL(38,2)) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_Cashflow_NCBT_25', @pValue =@Value


		Select @Value = CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName ='Maturing_Proceeds_Loan_NCA_01' and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_NW_Proceeds_NCA1_01', @pValue =@Value

		Select @Value = CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName ='Maturing_Daily_GIC_Loan_IPD_NCBD_08' and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Daily_GIC_Loan_NCA1_02', @pValue =@Value
		
		Select @Value = CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName ='Maturing_Retained_Principal_IPD_NCBD_10' and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Retained_Principal_NW_NCA1_03', @pValue =@Value

		Select @Value = CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR)
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName ='Maturing_Credit_Reserve_Ledger_IPD_NCBD_09' and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_Credit_Reserve_Ledger_NCA1_04', @pValue =@Value


		Select @CalculateValue=   SUM(CAST(VALUE as DECIMAL(38,2))) 
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('GT2_Funding_Trade_Principal_MT07', 'GT2_Funding_Trade_Interest_MT08') and DealIpdRunId=@pDealIpdRunId
		SET @Value = CAST((CAST(@CalculateValue as DECIMAL(38,2))) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Maturing_NT9_Funding_Trade_NCA1_05', @pValue =@Value
		
		Select @CalculateValue = ISNULL((-1*CAST(VALUE as DECIMAL(38,2))) ,0)
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName ='Series_11_Coupon_Amount_NCA1_11' and DealIpdRunId=@pDealIpdRunId
		SET @Value = CAST(CAST(@CalculateValue as DECIMAL(38,18)) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Series_11_Coupon_Amount_NCA1_12', @pValue =@Value

		

		--Wells_Fargo_back-to-back_SwapReceipts_NCA1_09
		--IPD_Collections_Amounts_NCA1_13  
		--GT_Interest_Top-up_NCA1_14
		--Repay_RBS_Cash_Capital_Contributions_NCA1_24		--


		Select @Value=  CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR) 
		from [cb].[vwBookingLineItemValue] 
		WHERE LineItemInternalName in ('New_Proceeds_Loan_NCA_03') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_NW_Proceeds_NCA1_28', @pValue =@Value
		
		Select @Value=  CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR) 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('New_Daily_GIC_Loan_NCBD_12') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Daily_GIC_Loan_NCA1_29', @pValue =@Value
		
		Select @Value=  CAST(ISNULL((-1 * CAST(VALUE as DECIMAL(38,2) )) ,0) AS VARCHAR) 
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('New_Retained_Principal_NCBD_14') and DealIpdRunId=@pDealIpdRunId
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_Retained_Principal_NCA1_30', @pValue =@Value

		
		--New_Credit_Reserve_Ledger_NCA1_31 default as 0.00
		
		Declare @New_NT9_Funding_Trade_NCA1_32 Float
		Select @New_NT9_Funding_Trade_NCA1_32=   -1 *SUM(CAST(VALUE as DECIMAL(38,2)))
		from [cb].[vwBookingLineItemValue] 
		WHERE BookingGroup ='NW Collections Account (4607236 - LDNAWELO-GBP)'  and DealIpdRunId=@pDealIpdRunId
		SET @Value = CAST((CAST(@New_NT9_Funding_Trade_NCA1_32 as DECIMAL(38,2))) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='New_NT9_Funding_Trade_NCA1_32', @pValue =@Value

		Select @CalculateValue=   SUM(CAST(VALUE as DECIMAL(38,2)))
		from [cb].[vwBookingLineItemValue] 
		WHERE BookingGroup ='NW Collections Account (4607236 - LDNAWELO-GBP)'  and DealIpdRunId=@pDealIpdRunId
		SET @Value = CAST((CAST(@CalculateValue as DECIMAL(38,2))) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='Net_Cashflow_NW_Collection_NCA1_33', @pValue =@Value

		Select @CalculateValue=   CAST(VALUE as DECIMAL(38,2))
		from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('GT2_Funding_Trade_Principal_MT07') and DealIpdRunId=@pDealIpdRunId
		
		SET @CalculateValue = ISNULL(-1*@New_NT9_Funding_Trade_NCA1_32,0) - ISNULL(@CalculateValue,0)
		SET @Value = CAST((CAST(@CalculateValue as DECIMAL(38,2))) AS VARCHAR)
		exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId =@pDealIpdRunId, @pLineItemInternalName='RBS_Funding_Increase_Decrease_NCA1_34', @pValue =@Value
		
		---Process Recon Data
		exec cb.spProcessBookingsReconData @pDealIpdRunId=@pDealIpdRunId, @pUserName =@pUserName
	END TRY  
	BEGIN CATCH  

		
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE() + ' For Date ' + Convert(varchar(10), @pAsAtDate, 103) , @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cb.spProcessBookingsIPDData',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH   
	
END

GO



