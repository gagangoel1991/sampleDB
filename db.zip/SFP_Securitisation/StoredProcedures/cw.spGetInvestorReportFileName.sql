USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetInvestorReportFileName') IS NOT NULL
	DROP PROC  cw.spGetInvestorReportFileName
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Suresh Pandey 
--Date: 07-07-2021 
--Description: Get Investor Report File Name

-- exec [cw].[spGetInvestorReportFileName] 14,'2018-08-15','PDF'
--==================================   
CREATE PROCEDURE [cw].[spGetInvestorReportFileName] 
	@pDealId		INT,    
	@pIpdDate		VARCHAR(20), 
	@pFormatType	VARCHAR(10)       
AS  
BEGIN  
  
BEGIN TRY   
	  
	  DECLARE @DealIpdId INT

	  SET @DealIpdId =(SELECT TOP 1 DealIpdId FROM cw.DealIpd WHERE DealId = @pDealId AND IpdDate = @pIpdDate )


      SELECT DealIpdID,CASE WHEN IsOverrided =1 THEN 'Overrided_'+ [FileName] ELSE [FileName] END AS [FileName],FormatType FROM [cw].[DealIpdIrLocation] WHERE DealIpdID=@DealIpdId AND FormatType =@pFormatType
		    
    
END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END

GO