USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetDealsForPoolId]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetDealsForPoolId]
GO


/*  
 EXEC [ps].[spGetDealsForPoolId] 310
*/
CREATE PROCEDURE [ps].[spGetDealsForPoolId]  
(  
	@PoolId INT = 0
)  
AS  
BEGIN    
		DECLARE @Poolpurpose_RePurchase INT = (SELECT PoolPurposeId FROM PS.PoolPurpose WHERE CODE = 'DF')    
		DECLARE @Poolpurpose_Topup INT  = (SELECT PoolPurposeId FROM PS.PoolPurpose WHERE CODE = 'TP')    
		DECLARE @PoolPurposeId INT = (SELECT PoolPurposeId FROM PS.Pool WHERE PoolId = @PoolId)    
		DECLARE @PartitionId INT = (SELECT CONVERT(VARCHAR, VintageDate, 112) FROM PS.Pool WHERE PoolId=@PoolId)
		DECLARE @AssetClassID INT = ( SELECT AssetClassId FROM ps.AssetClass WHERE CODE = 'CL' )

		CREATE TABLE #tblPartitionIds(PartitionID VARCHAR(10)) 
		CREATE TABLE #Tmp_PoolBuild_Tbl (LoanId VARCHAR(10), PoolId INT)

		INSERT INTO #tblPartitionIds
		SELECT CONVERT(VARCHAR, VintageDate, 112) PartitionID
		FROM PS.Pool 
		WHERE AssetClassId = @AssetClassID

		INSERT INTO #Tmp_PoolBuild_Tbl
		SELECT CONVERT(VARCHAR(10), dtl.LoanId) LoanId, dtl.PoolId     
		FROM ps.PoolBuildDetail dtl (nolock) 
		INNER JOIN  PS.Pool pl ON dtl.PoolId = pl.PoolId
		WHERE pl.AssetClassId = @AssetClassID
  
		SELECT FCAP.*, FF.SourceId    
		INTO #Tmp_FF_AssetPool_Data_tbl  
		FROM  [corp].[syn_SfpModelCorporate_vw_FactCorporateAssetPool] FCAP (nolock)  
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock) ON FCAP.FacilityId = FF.FacilityId   
		--WHERE PartitionId IN(  SELECT DISTINCT PartitionID FROM #tblPartitionIds) 
		WHERE EXISTS (SELECT PartitionID FROM #tblPartitionIds tmp WHERE tmp.PartitionId = ff.PartitionId)
   
		SELECT distinct PB.PoolId, FCAP.DealId  -- FCAP.PoolflaggingDateKey, FCAP.PoolDeflaggingDateKey, FCAP.FacilityId
		INTO #AssetPoolFinalData  
		FROM #Tmp_FF_AssetPool_Data_tbl FCAP    
		INNER JOIN #Tmp_PoolBuild_Tbl pb WITH (NOLOCK) ON pb.LoanId + '\P' = FCAP.FacilityId    
		WHERE FCAP.SourceId = 2  
   
		INSERT INTO #AssetPoolFinalData  
		SELECT distinct PB.PoolId, FCAP.DealId -- FCAP.PoolflaggingDateKey, FCAP.PoolDeflaggingDateKey, FCAP.FacilityId
		FROM #Tmp_FF_AssetPool_Data_tbl FCAP    
		INNER JOIN #Tmp_PoolBuild_Tbl pb WITH (NOLOCK)        
		ON pb.LoanId = FCAP.FacilityId    
		WHERE FCAP.SourceId = 1   

		SELECT PoolId, DealId, 0 as PoolStatusId
		FROM #AssetPoolFinalData ORDER BY 1
END

GO
