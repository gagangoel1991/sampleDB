USE [SFP_Securitisation]
GO
--Need to remove the Deal Type Specific procedure.
IF OBJECT_ID('[cw].[spGetRMBSDealECB_BondData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetRMBSDealECB_BondData]   
GO
IF OBJECT_ID('[cw].[spGetECB_BondData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetECB_BondData]   
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [CW].[spGetECB_BondData]  
/*-------------------------------------------------------  
 * Author: Kapil Sharma
 * Date: 06.09.2021  
 * Description:  This will return the ECB data for RMBs deals
 * 			  [cw].[spGetECB_BondData]  'Dunmore1', '2021-07-30'
 * Change History  
 * --------------  
 * Author  Date		Description  
 * AS		22-10-2021	Changed 'Ending Reserve Account Balance', 'Target Reserve Account Balance','Drawings under Liquidity Facility'
 * 					added 8100 to currrent coupon wtih % sign as per Himanshi agreement
 * -------------------------------------------------------  
*/  
(  
 @DealName		VARCHAR(70),  
 @AsAtDate		DATETIME ,
 @PoolDescription VARCHAR(115) = NULL
)   
AS  
BEGIN 
	BEGIN TRY  

		DECLARE
			@dealIpdRunId					INT,
			@ipdDate						DATE,
			@dealIpdId						INT,
			@dealId							INT,
			@cpIssuer						VARCHAR(300),
			@classXNoteHolderLineItemId		VARCHAR(100),
			@dealType						VARCHAR(40)

		SELECT 
			@dealIpdRunId = RunId,
			@dealIpdId = di.DealIpdId,
			@ipdDate = di.IpdDate,
			@dealId = deal.DealId,
			@cpIssuer = dc.CounterpartyName
		FROM
			cw.DealIpdRun dir
		JOIN
			cw.DealIpd di ON dir.DealIpdId = di.DealIpdId
		JOIN
			cw.vwDealIpdDates dit ON di.IpdDate = dit.IPD
		JOIN
			cw.vw_ActiveDeal deal ON deal.DealId = di.DealId
		JOIN
			[CW].[vw_ActiveDealCounterparty] dc ON dc.DealId = deal.DealId
		JOIN
			cfgcw.DealCounterpartyRoleMap dcrm ON dc.DealCounterpartyId = dcrm.DealCounterpartyId
		JOIN
			cfgcw.CounterpartyRole cr ON cr.CounterpartyRoleId = dcrm.CounterpartyRoleId
		WHERE
			dit.CollectionBusinessEnd = @AsAtDate
			AND deal.DealName = @DealName
			AND dir.IsCurrentVersion = 1
			AND cr.InternalName = 'Issuer'

		SET @dealType =(SELECT [cw].[fnGetDealType] (@dealId))

		IF @dealType = 'RMBS'
		BEGIN
			SELECT @classXNoteHolderLineItemId = wfli.WaterfallLineItemId FROM cfgcw.WaterfallLineItem wfli 
			JOIN cfgcw.WaterfallCategory wfc ON wfc.WaterfallCategoryId = wfli.WaterfallCategoryId
			JOIN cw.vw_ActiveDeal deal ON deal.DealId = wfc.DealId
			WHERE wfc.DealId = @dealId AND wfc.InternalName = 'RevenuePriorityofPayments'
			AND  wfli.InternalName = CASE WHEN deal.DealName = 'ARDMORE1' THEN  'RevenuePriorityofPayments_18.000' 
			WHEN deal.DealName = 'DUNMORE1' THEN 'RevenuePriorityofPayments_13.000' END 
			AND wfc.DealId = @dealId

			SELECT 
				@AsAtDate AS ReportDate,
				@cpIssuer AS 'Issuer',
				CAST(ISNULL((SELECT sum(Reservefund_cf) FROM cw.ReserveFund_PostWF
					WHERE ReserveFundId IN (SELECT DISTINCT DealReserveFundId FROM cfgcw.DealReserveFundNoteMap rfnm WHERE rfnm.DealNoteId = dn.DealNoteId)
					AND DealIpdRunId = @dealIpdRunId
				), 0) AS DECIMAL(38, 4)) AS 'Ending Reserve Account Balance',
				CAST(ISNULL((SELECT sum(ReserveFundRequiredAmount) FROM cw.ReserveFund_PreWF
					WHERE ReserveFundId IN (SELECT DISTINCT DealReserveFundId FROM cfgcw.DealReserveFundNoteMap rfnm WHERE rfnm.DealNoteId = dn.DealNoteId)
					AND DealIpdRunId = @dealIpdRunId
				), 0) AS DECIMAL(38, 4)) AS 'Target Reserve Account Balance',
				CASE WHEN (SELECT COALESCE(DrawdownAmount,0) FROM cw.SubLoan_PreWF slPre
							JOIN cfgcw.DealSubLoan sl ON slPre.DealSubloanId = sl.DealSubloanId
							JOIN cfgcw.SubLoanType slt ON slt.SubloanTypeId = sl.SubloanTypeId
								AND slt.Name = 'ServicerAdvanceFacility'
				WHERE slPre.DealIpdRunId = @dealIpdRunId) >0 THEN 'Y' ELSE 'N' END 
				AS 'Drawings under Liquidity Facility',
				CAST(ISNULL((SELECT SUM(TotalPaidAmount) FROM [CW].[RevenueWaterfallPaymentSummary] rwps WHERE rwps.WaterfallLineItemId = @classXNoteHolderLineItemId
				AND rwps.DealIpdRunId = @dealIpdRunId), 0) AS DECIMAL(38, 4)) AS 'Excess Spread Amount',
				'N' AS 'Trigger Measurements/Ratios', --BR12 : Default to N 
				CAST(0 AS DECIMAL(19, 2)) AS 'Average Constant Pre-payment Rate', 
				'' AS 'Point Contact',
				'' AS 'Contact Information',
				dn.Series AS 'Bond Class Name',
				dn.ISIN AS 'International Securities Identification Number',
				@ipdDate AS 'Interest Payment Date',
				@ipdDate AS 'Principal Payment Date',
				currency.Code AS 'Currency',
				CAST(ISNULL(dn.IssuanceAmount, 0) AS DECIMAL(38, 4)) 'Original Principal Balance',
				CAST(ISNULL(notePost.Principal_cf, 0) AS DECIMAL(38, 4)) AS 'Total Ending Balance Subsequent to Payment',
				4 AS 'Reference Rate',
				CAST((dn.Margin/10000) AS DECIMAL(38, 6)) AS 'Relevant Margin',
				CAST(CASE WHEN lookupValueRT.Value = 'Floater' THEN (notePre.BaseRate/100) ELSE 0 END AS DECIMAL(38, 6)) AS 'Coupon Reference Rate',
				CONVERT(varchar(200),CAST(ISNULL(notePre.Coupon, 0) AS DECIMAL(38, 6))) AS 'Current Coupon',
				--convert(varchar(200),ISNULL(notePre.Coupon, 0)*100) + '%' AS 'Current Coupon',
				CASE WHEN notePost.Principal_Cf >0 THEN (notePost.Interest_Cf/notePost.Principal_Cf) ELSE 0 END AS  'Cumulative Interest Shortfall',
				CAST(0 AS DECIMAL(38,4)) AS 'Cumulative Principal Shortfalls',
				dn.MaturityDate AS 'Legal Maturity',
				dn.IssuanceDate AS 'Bond Issue Date'
			FROM
				cfgcw.DealNote dn
			JOIN 
				cw.NoteData_PostWF notePost ON notePost.DealNoteId = dn.DealNoteId
			JOIN
				cw.NoteData_PreWF notePre ON notepre.DealNoteId = dn.DealNoteId AND notePost.DealIpdRunId = notePre.DealIpdRunId
			JOIN
				cfgcw.Currency currency ON currency.CurrencyId = dn.CurrencyId
			JOIN
				cfgcw.DealLookupValue lookupValueRT ON lookupValueRT.LookupValueId = dn.RateTypeId
			JOIN 
				cfgcw.DealLookupType lookupTypeRT ON lookupTypeRT.LookupTypeId = lookupValueRT.LookupTypeId
			WHERE
				dn.DealId = @dealId
				AND notePost.DealIpdRunId = @dealIpdRunId
				AND lookupTypeRT.TypeCode = 'RateType'
		END
		ELSE
		BEGIN

			SELECT 
				@AsAtDate AS ReportDate,
				@cpIssuer AS 'Issuer',
				NULL AS 'Ending Reserve Account Balance',
				NULL AS 'Target Reserve Account Balance',
				'N' AS 'Drawings under Liquidity Facility',
				NULL AS 'Excess Spread Amount',
				'N' AS 'Trigger Measurements/Ratios', --BR12 : Default to N 
				CAST(0 AS DECIMAL(19, 2)) AS 'Average Constant Pre-payment Rate', 
				'' AS 'Point Contact',
				'' AS 'Contact Information',
				dn.[Name] AS 'Bond Class Name',
				dn.ISIN AS 'International Securities Identification Number',
				@ipdDate AS 'Interest Payment Date',
				@ipdDate AS 'Principal Payment Date',
				currency.Code AS 'Currency',
				CAST(ISNULL(dn.IssuanceAmount, 0) AS DECIMAL(38, 4)) 'Original Principal Balance',
				CAST(ISNULL(0, 0) AS DECIMAL(38, 4)) AS 'Total Ending Balance Subsequent to Payment',
				4 AS 'Reference Rate',
				CAST((dn.Margin/10000) AS DECIMAL(38, 6)) AS 'Relevant Margin',
				CAST(CASE WHEN lookupValueRT.Value = 'Floater' THEN (dnWf.BaseRate/100) ELSE 0 END AS DECIMAL(38, 6)) AS 'Coupon Reference Rate',
				CONVERT(varchar(200),CAST(ISNULL(dnWf.Coupon, 0) AS DECIMAL(38, 6))) AS 'Current Coupon',
				--convert(varchar(200),ISNULL(notePre.Coupon, 0)*100) + '%' AS 'Current Coupon',
				CAST(0 AS DECIMAL(38,4)) AS  'Cumulative Interest Shortfall',
				CAST(0 AS DECIMAL(38,4)) AS 'Cumulative Principal Shortfalls',
				dn.MaturityDate AS 'Legal Maturity',
				dn.IssuanceDate AS 'Bond Issue Date'
			FROM
				cfgcb.DealNote dn
			JOIN 
				cb.DealNote_Wf dnWf ON dnWf.DealNoteId = dn.DealNoteId
			JOIN
				cfgcw.Currency currency ON currency.CurrencyId = dn.CurrencyId
			JOIN
				cfgcw.DealLookupValue lookupValueRT ON lookupValueRT.LookupValueId = dn.RateTypeId
			JOIN 
				cfgcw.DealLookupType lookupTypeRT ON lookupTypeRT.LookupTypeId = lookupValueRT.LookupTypeId
			WHERE
				dn.DealId = @dealId
				AND dnWf.DealIpdRunId = @dealIpdRunId
				AND lookupTypeRT.TypeCode = 'RateType'
		END
		
	END TRY

	BEGIN CATCH  

	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  

	SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  

	EXEC app.SaveErrorLog 1, 1, 'cw.spGetECB_BondData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
	, 'System'  

	RAISERROR (@errorMessage,  
		 @errorSeverity,  
		 @errorState )  
	END CATCH  

END
GO