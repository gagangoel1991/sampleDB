USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spDeleteIrTemplate]') IS NOT NULL
	DROP PROCEDURE [cw].[spDeleteIrTemplate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Kapil Sharma
 * Date:	10.02.2020
 * Description:  This will delete the IR Template record based on template id
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
CREATE PROCEDURE [cw].[spDeleteIrTemplate]
@pTemplateId		INT = NULL,
@pUserName			VARCHAR(80),
@pReturnCode		INT =0 OUTPUT
AS  
BEGIN  

	BEGIN TRY  
 
		IF EXISTS(SELECT TOP 1 * FROM cfgCW.IR_Template WHERE TemplateId = @pTemplateId AND IsLocked = 0)
		BEGIN
			DELETE FROM cfgCW.IR_Template WHERE TemplateId = @pTemplateId AND Islocked = 0
			SET @pReturnCode = 1
		END
		ELSE
			SET @pReturnCode = -1 --Record is locked

		RETURN @pReturnCode;
   
	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 2, 1, 'spDeleteIrTemplate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
		, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH  
  
END  
GO
