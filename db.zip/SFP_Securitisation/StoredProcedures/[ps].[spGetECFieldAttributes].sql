USE [SFP_Securitisation]
GO
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetECFieldAttributes]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetECFieldAttributes]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- EXEC ps.spGetECFieldAttributes 'SAKK'
CREATE PROCEDURE [ps].[spGetECFieldAttributes]
 @pUserName AS VARCHAR(50)  
AS  
BEGIN              
  BEGIN TRY  

  
		SELECT ECM.EligibilityCriteriaFieldId, 
			   ECF.CriteriaFieldName,
			   RequireAccountingFormat,
			   DisplayFormat
		INTO #TableFormattedFields
		FROM [ps].[ECFieldAttributeMapping] ECM
		INNER JOIN 
		[ps].[EligibilityCriteriaField] ECF
		ON ECM.EligibilityCriteriaFieldId = ECF.EligibilityCriteriaFieldId 
		WHERE ECM.IsActive = 1;

		-- FOR REFF-REGISTRY REPORT AS THE COLUMN NAMES MAY COMES FROM USER'S DISPLAY NAME 
		INSERT INTO #TableFormattedFields
		SELECT ECM.EligibilityCriteriaFieldId,   
			  AdcMap.DisplayFieldName,  
			  RequireAccountingFormat,
			  DisplayFormat
		FROM [ps].[ECFieldAttributeMapping] ECM  
		INNER JOIN [ps].[PoolAdhocReportFieldMap] AdcMap
		ON ECM.EligibilityCriteriaFieldId = AdcMap.EligibilityCriteriaFieldId   
		WHERE ECM.IsActive = 1
		      AND DisplayFieldName NOT IN (SELECT CriteriaFieldName FROM #TableFormattedFields)

		SELECT distinct * FROM #TableFormattedFields

  END TRY              
  BEGIN CATCH              
   DECLARE   
     @errorMessage     NVARCHAR(MAX),  
     @errorSeverity    INT,  
     @errorNumber      INT,  
     @errorLine        INT,  
     @errorState       INT;  
   SELECT   
    @errorMessage = ERROR_MESSAGE()
    ,@errorSeverity = ERROR_SEVERITY()
    ,@errorNumber = ERROR_NUMBER()
    ,@errorLine = ERROR_LINE()
    ,@errorState = ERROR_STATE()  
  
   EXEC app.SaveErrorLog 2, 1, 'spGetECFieldAttributes', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
   RAISERROR (@errorMessage,  
     @errorSeverity,  
     @errorState )          
   END CATCH              
 END
 GO