USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.GetAssetDataMortgagePrincipalAnalysis') IS NOT NULL
	DROP PROC CW.GetAssetDataMortgagePrincipalAnalysis  ;

GO
