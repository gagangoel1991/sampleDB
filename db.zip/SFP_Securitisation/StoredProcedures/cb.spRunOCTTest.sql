USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRunOCTTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunOCTTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRunOCTTest] 
    @pDealIpdRunId INT,
	@pUserName  VARCHAR(80) ='System'      
AS  
--   
/*
 * Author: Suresh Pandey
 * Date:	08-02-2022
 * Description:  This will run the  PeMaturity test and insert data for test.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Exec [cb].[spRunOCTTest]  1035,'suresh'
 * 
 * select  *from cb.DealIpdTestResult where DealIpdRunId=1035 and testtypeid=8
 * select  *from cb.TestLineItemValue  where DealIpdRunId=1035 and TestLineItemID in(select TestLineItemID from cfgcb.TestLineItem where testtypeid=8)
 * 
*/
BEGIN  
  
BEGIN TRY  
  
	DECLARE @result								VARCHAR(10),
			@collectionStartDt					DATE,
			@collectionEndDt					DATE,
			@poolBalance						DECIMAL(38, 16),
			@gbpEquivalentOfBonds				DECIMAL(38, 16),
			@overCollateralisationPercentage	DECIMAL(38, 16),
			@threshold							DECIMAL(38, 16),
			@testTypeID							INT,
			@dealId								INT;

	SELECT  @dealId = di.DealId, 
			@collectionStartDt = did.CollectionBusinessStart, 
			@collectionEndDt = did.CollectionBusinessEnd
		FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
		WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1

	SELECT @testTypeID=TestTypeID  FROM cfgcb.TestType WHERE InternalName='OCTMonthly'
	
	SELECT @poolBalance= ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'AdjustedCapitalBalance'), 0)
		
	SELECT @gbpEquivalentOfBonds = ISNULL(SUM(PrincipalOutstanding_GBP),0) 
		FROM [cb].[DealNote_Wf] dnwf
		JOIN [cfgcb].[DealNote] dn ON dn.dealnoteid =dnwf.DealNoteId AND DealIpdRunId=@pDealIpdRunId

	SET @overCollateralisationPercentage = (@poolBalance/CAST(@gbpEquivalentOfBonds AS FLOAT))*100

	SELECT @threshold = CAST([Value] AS DECIMAL(10,4)) FROM [CW].[vw_DealLookup] WHERE TypeCode = 'Deimos_Test_Config' AND [Name] = 'OCT_Threshold'

	SET @result=IIF(@overCollateralisationPercentage<@threshold,'FAIL','PASS')
	 
 
	IF ( Object_id('tempdb..#TestLineItemValue') IS NOT NULL ) 
		DROP TABLE #TestLineItemValue 

	CREATE TABLE #TestLineItemValue(
		TestLineItemID INT,
		InternalName VARCHAR(200),
		DealIpdRunId INT,
		[Value] VARCHAR(500))

	INSERT INTO #TestLineItemValue(TestLineItemID,InternalName,DealIpdRunId,[Value])
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@poolBalance AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='OCT_PoolBalance'
	UNION				  
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(@gbpEquivalentOfBonds AS VARCHAR) FROM cfgcb.TestLineItem WHERE InternalName='OCT_GBPEquivalentOfBonds'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(CAST(@overCollateralisationPercentage AS DECIMAL(20,4)) AS VARCHAR) + '%' FROM cfgcb.TestLineItem WHERE InternalName='OCT_OverCollateralisationPercentage'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,CAST(CAST(@threshold AS DECIMAL(18,4)) AS VARCHAR) + '%' FROM cfgcb.TestLineItem WHERE InternalName='OCT_Threshold'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@result FROM cfgcb.TestLineItem WHERE InternalName='OCT_Result'
	 
	
	IF NOT EXISTS(SELECT 1 FROM cb.TestLineItemValue tv
							JOIN cfgcb.TestLineItem tl  ON tl.TestLineItemID=tv.TestLineItemID
							JOIN cfgcb.TestType tt ON tt.TestTypeId=tl.TestTypeId
							WHERE DealIpdRunId =@pDealIpdRunId AND tt.TestTypeId=@testTypeID)
	BEGIN
		INSERT INTO cb.TestLineItemValue(TestLineItemID,DealIpdRunId,[Value],IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,DealIpdRunId,CAST(ISNULL([Value],0) AS VARCHAR),1,@pUserName,GETDATE(),@pUserName,GETDATE() FROM #TestLineItemValue 
		
	END
	ELSE
	BEGIN	
		
		UPDATE tv SET tv.[Value]=CAST(ISNULL(temp.[Value],0) AS VARCHAR),tv.ModifiedBy=@pUserName, tv.ModifiedDate=GETDATE() 
			FROM cb.TestLineItemValue tv
			JOIN #TestLineItemValue temp
				ON temp.TestLineItemID=tv.TestLineItemID AND temp.DealIpdRunId=tv.DealIpdRunId
		WHERE temp.DealIpdRunId=@pDealIpdRunId

	END

	 
	---Save the test result 
	EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeID, @result, @pUserName

	----------------12 months Forward OCT Test

	EXEC [cb].[spRun12MonthsForwardOCTTest] @pDealIpdRunId, @pUserName

END TRY 
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cb.spRunOCTTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO