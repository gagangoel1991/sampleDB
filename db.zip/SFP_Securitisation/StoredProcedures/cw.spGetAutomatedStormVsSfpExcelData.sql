USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetAutomatedStormVsSfpExcelData') IS NOT NULL
	DROP PROC cw.spGetAutomatedStormVsSfpExcelData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*--====================================================================
 * Author: Saurabh Bhatia
 * Date: 01-07-2021   
 * Description: This will return the Storm vs Sfp Data for excel report
 * EXEC cw.spGetAutomatedStormVsSfpExcelData 14,8,'bhasaaa' 		
--==================================================================== */
CREATE PROCEDURE cw.spGetAutomatedStormVsSfpExcelData @pDealId SMALLINT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY

	DECLARE @PreviousIPDCollectionBusinessEnd varchar(40)
		,@collectionBusinessStart varchar(40)
		,@collectionBusinessEnd varchar(40)
		,@ipdMinus1BusinessDay varchar(40)
		,@ipdDate DATE
		,@nextCollectionStartDate varchar(40)
		,@HolidayCount varchar(40)
		,@sfpRevAdjustment DECIMAL(38, 18)
		,@sfpPrinAdjustment DECIMAL(38, 18)
		,@dealType VARCHAR(40)

	SELECT @previousIPDCollectionBusinessEnd = did.PreviousIPDCollectionBusinessEnd
		,@collectionBusinessStart = did.CollectionBusinessStart
		,@collectionBusinessEnd = did.CollectionBusinessEnd
		,@ipdMinus1BusinessDay = did.[IPD-1BusinessDay]
		,@ipdDate = did.IPD
		,@HolidayCount=ISNULL(di.HolidayCount,0)
	FROM cw.DealIpd di
	JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
	JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
	WHERE dir.RunId = @pIPDRunId

	SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))
	
	--Todo -- Need to change and pick the value from view cw.vwDealIpdDates
	SELECT @nextCollectionStartDate = CONVERT(varchar,DATEADD(MONTH, - 1, DATEADD(DAY, 1, EOMONTH(@ipdDate))), 23)



	--Dates Tab Data Start 
	SELECT @previousIPDCollectionBusinessEnd AS Dates	
	UNION ALL	
	SELECT @collectionBusinessStart AS Dates	
	UNION ALL	
	SELECT @collectionBusinessEnd AS Dates	
	UNION ALL	
	SELECT @ipdMinus1BusinessDay AS Dates	
	UNION ALL	
	SELECT @nextCollectionStartDate AS Dates
	UNION ALL
	SELECT @HolidayCount AS Dates
	--Dates Tab Data End 

	--Storm Tab Data Start
	SELECT CollectionDate
		,NetPrincipalCollections
		,FinanceCollections
		,OtherCollections
		,TotalDailyCashAmount
	FROM cw.collectionledger
	WHERE DealId = @pDealId
		AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
		--AND @collectionBusinessEnd
		AND @ipdMinus1BusinessDay
	ORDER BY CollectionDate
	--Storm Tab Data End
	 
	--SFP Tab Data Start
	SELECT  CollectionDate
		,SUM( CASE WHEN DailyCollectionFieldColumnName = 'TotalCashReceived' THEN CAST( DailyCollectionValue AS Decimal(38,18) ) END  ) AS TotalCashReceived
		,SUM( CASE WHEN DailyCollectionFieldColumnName = 'TotalRevenueReceipts' THEN CAST( DailyCollectionValue AS Decimal(38,18) ) END ) AS TotalRevenueReceipts
		,SUM( CASE WHEN DailyCollectionFieldColumnName = 'PrincipalReceipts' THEN CAST( DailyCollectionValue AS Decimal(38,18) ) END  )  AS PrincipalReceipts
		,SUM( CASE WHEN DailyCollectionFieldColumnName = 'DeflaggedPrincipalReceipts' THEN CAST( DailyCollectionValue AS Decimal(38,18) ) END  )  AS DeflaggedPrincipalReceipts
		,SUM( CASE WHEN DailyCollectionFieldColumnName = 'DeflaggedRevenueReceipts' THEN CAST( DailyCollectionValue AS Decimal(38,18) ) END  )  AS DeflaggedRevenueReceipts	
		,SUM( CASE WHEN DailyCollectionFieldColumnName = 'FurtherStageAdvances' THEN CAST( DailyCollectionValue AS Decimal(38,18) ) END  )  AS DeflaggedRevenueReceipts	
	FROM [cw].[vwDailyCollection] dc	
	WHERE dc.DealId = @pDealId
		AND dc.DailyCollectionFieldColumnName IN (
			'TotalCashReceived'
			,'TotalRevenueReceipts'
			,'PrincipalReceipts'
			,'DeflaggedPrincipalReceipts'
			,'DeflaggedRevenueReceipts'
			,'FurtherStageAdvances'
			)
		AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
		--AND @collectionBusinessEnd
		AND @ipdMinus1BusinessDay
	 GROUP BY CollectionDate
	 ORDER BY CollectionDate;
	--SFp Tab Data Start

	--Revenue and Principal Adjustments Start

		--SFP Revenue - Adjustment
	SELECT @sfpRevAdjustment = (SUM(ISNULL(wla.AdjustedAmount,0.0)) * -1)  
		FROM 
		cfgCW.WaterfallCategory wc
		INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId 
		LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIPDRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'PreAvailableRevenueReceipts' 
		AND wli.InternalName = CASE WHEN @dealType = 'Covered Bond' THEN 'PreAvailableRevenueReceipts_1.000' ELSE 'PreAvailableRevenueReceipts_2.100' END;


		--SFP Principal - Adjustment
		SELECT @sfpPrinAdjustment=(SUM(ISNULL(wla.AdjustedAmount, 0.0)) * - 1)
			FROM 
			cfgCW.WaterfallCategory wc
			INNER JOIN 
			cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId 
			LEFT JOIN 
			cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIPDRunId
		WHERE
			dealId=@pDealId
			AND wc.InternalName = 'PreAvailablePrincipalReceipts' 
			AND wli.InternalName IN ('PreAvailablePrincipalReceipts_1.100','PreAvailablePrincipalReceipts_1.200','PreAvailablePrincipalReceipts_1.300')

			SELECT @sfpRevAdjustment AS Adjustment 
			UNION ALL
			SELECT @sfpPrinAdjustment AS Adjustment

	--Revenue and Principal Adjustments End

END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cw.spGetAutomatedStormVsSfpExcelData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO