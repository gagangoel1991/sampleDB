USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[spStratificationObligorPDData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [corp].[spStratificationObligorPDData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Neeraj Jindal
Creation Date  : 18-Jul-2022
Description    : This will return calculated data for non-configurable strats
Execution      : EXEC [corp].[spStratificationObligorPDData] @pDealId = 1 , @pAsAtDate= '2022-01-31', @pUserName='Europa\jindnaj'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spStratificationObligorPDData] 	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100)   

		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats
		IF OBJECT_ID('tempdb..#ObligorPD') IS NOT NULL
		DROP TABLE #ObligorPD
		IF OBJECT_ID('tempdb..#EmptyBucket') IS NOT NULL
		DROP TABLE #EmptyBucket
        
		/*List of required Columns*/     
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','RONA','PDMidPoint','BorrowerFullName') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
		PRINT 'Strats Calculation Start : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId
			  ,RONA
			  ,PDMidPoint			 
			  ,BorrowerFullName
		INTO #Strats 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID	
		

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Calculating Non-Config Strats*/		
		SELECT Bucket
			  ,Percent_Of_Rona = IIF(MAX(RonaTotal) = 0, 0.00 ,CONVERT(DECIMAL(18,6),SUM(RONA) /MAX(RonaTotal)))
			  ,Count_Of_Obligors = COUNT(DISTINCT BorrowerFullName)			  
		INTO #ObligorPD
		FROM
			(SELECT
				 RONA
				,SUM(RONA) OVER() AS RonaTotal
				,BorrowerFullName			
				,CASE WHEN PDMidPoint < 0.001 THEN '1_Obligor Probability Of Default in Range [0.00%,0.10%)'
					  WHEN PDMidPoint >= 0.001 AND PDMidPoint < 0.0025 THEN '2_Obligor Probability Of Default in Range [0.10%,0.25%)'
					  WHEN PDMidPoint >= 0.0025 AND PDMidPoint < 0.01 THEN '3_Obligor Probability Of Default in Range [0.25%,1.00%)'
					  WHEN PDMidPoint >= 0.01 AND PDMidPoint < 0.075 THEN '4_Obligor Probability Of Default in Range [1.00%,7.50%)'
					  WHEN PDMidPoint >= 0.075 AND PDMidPoint < 0.20 THEN '5_Obligor Probability Of Default in Range [7.50%,20.00%)'
					  ELSE '6_Obligor Probability Of Default in Range [20.00%,100.00%]'
				END AS Bucket
			FROM #Strats	
			) pd		
		GROUP BY Bucket
		

		/*For Attaching a bucket which doen't come in actual data*/
		SELECT '1_Obligor Probability Of Default in Range [0.00%,0.10%)' AS Bucket, 0.00 Percent_Of_Rona, 0 AS Count_Of_Obligors
		INTO #EmptyBucket
		UNION SELECT '2_Obligor Probability Of Default in Range [0.10%,0.25%)',0.00,0
		UNION SELECT '3_Obligor Probability Of Default in Range [0.25%,1.00%)',0.00,0
		UNION SELECT '4_Obligor Probability Of Default in Range [1.00%,7.50%)',0.00,0
		UNION SELECT '5_Obligor Probability Of Default in Range [7.50%,20.00%)',0.00,0
		UNION SELECT '6_Obligor Probability Of Default in Range [20.00%,100.00%]',0.00,0		

		INSERT INTO #ObligorPD(Bucket, Percent_Of_Rona, Count_Of_Obligors)
		SELECT eb.Bucket, eb.Percent_Of_Rona, eb.Count_Of_Obligors 
		FROM #EmptyBucket eb
		WHERE eb.Bucket NOT IN (SELECT DISTINCT Bucket FROM #ObligorPD) 

		SELECT SUBSTRING(Bucket,3,LEN(Bucket)) AS [~Bucket], Percent_Of_Rona AS '% of RONA', Count_Of_Obligors AS 'Count of obligors' FROM #ObligorPD ORDER BY Bucket

		
		/*Deleting Data from Staging table after use*/
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    
	
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationObligorPDData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO
