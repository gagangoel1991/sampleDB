USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetTemplatetDetail]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetTemplatetDetail]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	10.02.2020
 * Description:  This will return the IR Template record based on template id
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
CREATE PROCEDURE [cw].[spGetTemplatetDetail]
@pTemplateId		INT = Null,
@pUserName			VARCHAR(100) = null,
@pReportTypeName VARCHAR(20) = '',
@pAssetClassID INT = 1
As    
BEGIN  
 
	BEGIN TRY  
	    DECLARE @ReportTypeId INT;
	  	SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
	  	SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 

		SELECT  
			I.TemplateId,  
			I.Name, 
			I.Description, 
			I.IsLocked, 
			OriginalFileName, 
			UploadedFileName,
			CASE WHEN I.IsLocked = 1 THEN 'Locked' ELSE 'Active' END AS Status,
			I.CreatedBy, 
			Cast(I.CreatedDate AS date) CreatedDate, 
			I.ModifiedBy, 
			Cast(I.ModifiedDate AS Date) ModifiedDate,
			I.DealTypeId,
			L.Value AS DealType
		FROM 
			cfgCW.IR_Template I
			LEFT JOIN cw.vw_DealLookup L ON L.TypeCode='DealType' AND L.LookupValueID= I.DealTypeId
		WHERE 
		 I.TemplateId = ISNULL(@pTemplateId, I.TemplateId)  
		 AND I.ReportTypeId = ISNULL(@ReportTypeId, I.ReportTypeId)
		 AND( ISNULL(@pTemplateId,0) > 0  OR I.AssetClassId = @pAssetClassID)
		ORDER BY 
			I.IsLocked DESC, i.ModifiedDate DESC
  
	END TRY  
  
	BEGIN CATCH  
		DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 2, 1, 'spGetTemplatetDetail', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
		, @pUserName
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH  
END  
GO
