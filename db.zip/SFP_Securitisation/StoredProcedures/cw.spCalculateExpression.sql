USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculateExpression') IS NOT NULL
	DROP PROCEDURE cw.spCalculateExpression
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculateExpression
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  04.05.2020 
 *   Description:  Calculate varaible and expression 
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 * 	--#1	AS      04.05.2021		Resetting variable @variableValue to null before assinging value
 * 			AS      08.03.2021		Added not equal clause everywhere 
 *    
 *   exec cw.spCalculateExpression 1034,'fm\shriyad'   
 *              
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80)
)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY

		--DECLARE @pDealIpdRunId INT =3,@pUserName varchar(20)='fm\shriyad'
		DECLARE @Message VARCHAR(4000)

		DECLARE @dealId          INT,
				@tempId          INT,
				@text            VARCHAR(100),
				@returnValue_str VARCHAR(500),
				@SQL             NVARCHAR(max),
				@variableValue   VARCHAR(200),
				@tempSql         NVARCHAR(max),
				@expressionId           INT,
				@currentExpressionCount INT =0,
				@level                  INT,
				@tempStr             VARCHAR(max),
				@tempFilterCondition VARCHAR(max),
				@tempVariableId      INT,
				@expression_internalName VARCHAR(500),
				@String    VARCHAR(1000),
				@Delimiter CHAR(1) = '[',
				@maxLevel INT ;

		SELECT @dealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId


		IF OBJECT_ID('tempdb..#tempVariableFilter') IS NOT NULL DROP TABLE #tempVariableFilter

		---------TEMP TABLE 1
		CREATE TABLE #tempVariableFilter(
			[Id] [int] NULL,
			[variableId] [int] NULL,
			FilterColumnName	varchar(100)	,
			FilterColumnType	varchar(20)	,
			[FROMColumnName] [varchar](100) NULL,
			[FROMColumnValue] [varchar](100) NULL,
			FROMFilter	varchar(50)	,
			[ToColumnName] [varchar](100) NULL,
			[ToColumnValue] [varchar](100) NULL,
			ToFilter	varchar(50)	,
		)

		IF OBJECT_ID('tempdb..#tempVariable') IS NOT NULL DROP TABLE #tempVariable


		---------TEMP TABLE 1
		CREATE TABLE #tempVariable(
			[Id] [int] NULL,
			FilterCondition	varchar(max)	,
			[VariableValue] [varchar](100) NULL
		)
		-- and cc.DealId=v.DealId  -- CalculateCategory
		INSERT INTO #tempVariableFilter  
		SELECT row_number()OVER (ORDER BY v.VariableId ASC) AS Id,v.VariableId AS variableId, 
		FilterColumnName, FilterColumnType, FROMColumnName,	 
		FROMColumnName AS FROMColumnValue,vf.FROMFilter,ToColumnName,ToColumnName AS ToColumnValue,vf.ToFilter 
		FROM cw.variable v 
		JOIN cw.variableFilter vf ON v.VariableId=vf.VariableId
		WHERE v.DealId=@dealId 
		AND v.IsActive=1
		
		SET @tempVariableId =(SELECT TOP 1 variableId FROM #tempVariableFilter ORDER BY variableId ASC)
		
		WHILE(@tempVariableId>0)
		BEGIN
			SET @tempFilterCondition=''
		
			SET @tempId =(SELECT TOP 1 Id FROM #tempVariableFilter WHERE variableId=@tempVariableId ORDER BY Id ASC)
			WHILE(@tempId>0)
			BEGIN

					SET @text=(SELECT FROMColumnName FROM #tempVariableFilter WHERE Id=@tempId)
			
					IF(charindex('{',@text)>0 AND charindex('}',@text)>0)
					BEGIN
						IF(charindex('cw.vwCurrentDealDate',@text)>0 OR charindex('cw.vwCurrentDealDate',@text)>0)
						BEGIN
							SET @tempSql ='SELECT @returnValue_str=value FROM '+(SELECT cw.fnGetTableAndColumn(@text,'table'))+' WHERE DealId='+CONVERT(varchar(10),@dealId)+' and InternalName='''+(SELECT cw.fnGetTableAndColumn(@text,'column'))+'''';
						END
						ELSE IF (charindex('cfg.dealinitialconfig',@text)>0)
						BEGIN
							SET @tempSql ='SELECT @returnValue_str=value FROM '+(SELECT cw.fnGetTableAndColumn(@text,'table'))+' WHERE DealId='+CONVERT(varchar(10),@dealId)+' and InternalName='''+(SELECT cw.fnGetTableAndColumn(@text,'column'))+'''';
						END


						--print @tempsql;
						EXEC sp_executesql @tempsql, N'@text varchar(100) out, @dealId int out , @returnValue_str varchar(500) out'
															, @text out , @dealId out  , @returnValue_str out;
	

						UPDATE #tempVariableFilter
						SET FROMColumnValue=isnull(@returnValue_str,'')
						WHERE Id=@tempId;

					END
					ELSE
					BEGIN
						UPDATE #tempVariableFilter
						SET FROMColumnValue=isnull(@text,'')
						WHERE Id=@tempId;
					END


					SET @text=(SELECT ToColumnName FROM #tempVariableFilter WHERE Id=@tempId)


					IF(len(@text)>0)
					BEGIN

							IF(charindex('.',@text)>0)
							BEGIN
								IF(charindex('cw.vwCurrentDealDate',@text)>0 OR charindex('cw.vwCurrentDealDate',@text)>0)
								BEGIN
									SET @tempSql ='SELECT @returnValue_str=value FROM '+(SELECT cw.fnGetTableAndColumn(@text,'table'))+' WHERE DealId='+CONVERT(varchar(10),@dealId)+' and InternalName='''+(SELECT cw.fnGetTableAndColumn(@text,'column'))+'''';
								END
								ELSE IF(charindex('cfg.dealinitialconfig',@text)>0)
								BEGIN
									SET @tempSql ='SELECT @returnValue_str=value FROM '+(SELECT cw.fnGetTableAndColumn(@text,'table'))+' WHERE DealId='+CONVERT(varchar(10),@dealId)+' and name='''+(SELECT cw.fnGetTableAndColumn(@text,'column'))+'''';
								END

								--print @tempsql;
								EXEC sp_executesql @tempsql, N'@text varchar(100) out, @dealId int out , @returnValue_str varchar(500) out'
															, @text out , @dealId out  , @returnValue_str out;

	

								UPDATE #tempVariableFilter
								SET ToColumnValue=isnull(@returnValue_str,'')
								WHERE Id=@tempId;

							END
							ELSE
							BEGIN
								UPDATE #tempVariableFilter
								SET ToColumnValue=isnull(@text,'')
								WHERE Id=@tempId;
							END
					END
					

					SELECT @tempStr=FilterColumnName+
						CASE 
						WHEN FROMColumnValue IS NOT NULL AND ToColumnValue IS NOT NULL THEN 
							CASE WHEN FROMFilter='greaterthanequal' THEN +'>= '''+FROMColumnValue
								 WHEN FROMFilter='lessthanequal' THEN +'<= '''+FROMColumnValue
								 WHEN FROMFilter='equal' THEN +'= '''+FROMColumnValue
								 WHEN FROMFilter='notequal' THEN +'!= '''+FROMColumnValue
								 WHEN FROMFilter='greaterthan' THEN +'> '''+FROMColumnValue
								 WHEN FROMFilter='lessthan' THEN +'< '''+FROMColumnValue
							END
							+''' and '+FilterColumnName +''+
							CASE WHEN ToFilter='greaterthanequal' THEN +'>= '+ToColumnValue
								 WHEN ToFilter='lessthanequal' THEN +'<= '''+ToColumnValue
								 WHEN ToFilter='equal' THEN +'= '''+ToColumnValue
								 WHEN FROMFilter='notequal' THEN +'!= '''+ToColumnValue
								 WHEN ToFilter='greaterthan' THEN +'> '''+ToColumnValue
								 WHEN ToFilter='lessthan' THEN +'< '+ToColumnValue
							END
						WHEN FROMColumnValue IS NOT NULL AND ToColumnValue IS NULL THEN 
							CASE WHEN FROMFilter='greaterthanequal' THEN +'>= '''+FROMColumnValue
								 WHEN FROMFilter='lessthanequal' THEN +'<= '''+FROMColumnValue
								 WHEN FROMFilter='equal' THEN +'= '''+FROMColumnValue
								 WHEN FROMFilter='notequal' THEN +'!= '''+FROMColumnValue
								 WHEN FROMFilter='greaterthan' THEN +'> '''+FROMColumnValue
								 WHEN FROMFilter='lessthan' THEN +'< '''+FROMColumnValue
							END
						WHEN FROMColumnValue IS NULL AND ToColumnValue IS NOT NULL THEN 
							CASE WHEN ToFilter='greaterthanequal' THEN +'>= '''+ToColumnValue
								 WHEN ToFilter='lessthanequal' THEN +'<= '''+ToColumnValue
								 WHEN ToFilter='equal' THEN +'= '''+ToColumnValue
								 WHEN FROMFilter='notequal' THEN +'!= '''+ToColumnValue
								 WHEN ToFilter='greaterthan' THEN +'> '''+ToColumnValue
								 WHEN ToFilter='lessthan' THEN +'< '''+ToColumnValue
							END
						END+''''
						FROM #tempVariableFilter
						WHERE Id=@tempId;
					

					IF(@tempFilterCondition!='')
					BEGIN
						SET @tempFilterCondition=COALESCE(@tempFilterCondition,'')+' and '+@tempStr
					END
					ELSE 
					BEGIN
						SET @tempFilterCondition=@tempStr
					END

					SET @tempId=(SELECT TOP 1 Id FROM #tempVariableFilter WHERE variableId=@tempVariableId AND Id>@tempId ORDER BY 1 ASC)

			END

			
			INSERT INTO #tempVariable
			VALUES(@tempVariableId,@tempFilterCondition,NULL)


			SET @tempVariableId =(SELECT TOP 1 variableId FROM #tempVariableFilter WHERE variableId>@tempVariableId ORDER BY variableId ASC)
	
		END

		--SELECT * FROM #tempVariable
		

		--print 'START dynamic query generation'
		-----------------dynamic query generation
		
		SET @tempId =(SELECT TOP 1 Id FROM #tempVariable ORDER BY 1 ASC)

		WHILE(@tempId>0)
		BEGIN
			/*--#1: removing dealid=14
			FROM '+tableName+' WHERE DealId='+convert(varchar(10),@dealId)+' and '+FilterCondition
			*/
			SELECT @SQL='
			SELECT @variableValue=
			'+CASE WHEN resultFilter IS NOT NULL 
					THEN resultfilter+'(' 
					ELSE '' 
				END +' '+
				
				+CASE 
					WHEN PreResultFormatType LIKE '%DATETIME%'
						THEN 'FORMAT (convert(datetime,'
					WHEN PreResultFormatType IS NOT NULL
						THEN 'convert(' +PreResultFormatType+','
					ELSE '' 
				END +' '+

				SELECTColumnName+' '
				+CASE 
				WHEN PreResultFormatType LIKE '%DATETIME%' THEN '),''yyyy-MM-dd'')'
				WHEN PreResultFormatType IS NOT NULL THEN ')' ELSE '' END+
				
				+CASE WHEN resultFilter IS NOT NULL THEN ')' ELSE '' END+'
			FROM '+tableName+' WHERE '+FilterCondition
			FROM cw.variable v 
			JOIN #tempVariable vn ON v.VariableId=vn.Id 
			WHERE v.VariableId=@tempId AND v.IsActive=1

			/*--#1: resetting variable @variableValue */
			SET @variableValue = NULL;

				--print @SQL

			 EXEC sp_executesql @SQL, N'@variableValue varchar(50) out', @variableValue out;

			UPDATE #tempVariable
			SET VariableValue=isnull(@variableValue,0)
			WHERE Id=@tempId;


			 SET @tempId=(SELECT TOP 1 Id FROM #tempVariable WHERE Id>@tempId ORDER BY 1 ASC);
		END


		

		IF OBJECT_ID('tempdb..#mainVariabletbl') IS NOT NULL DROP TABLE #mainVariabletbl


		CREATE TABLE #mainVariabletbl
		(
		variablename varchar(500),
		value varchar(200)
		)

		INSERT INTO #mainVariabletbl
		SELECT 'cw.variable.'+v.InternalName AS variableName
		,variablevalue FROM cw.variable v, #tempVariable vn
		WHERE v.VariableId=vn.Id ORDER BY tablename


		--SELECT * FROM #mainVariabletbl
		--print 'MESSAGE: VALUES OF ALL VARIABLES GOT CALCULATED'

		----------------------------------------------------------------

		IF OBJECT_ID('tempdb..#tempIdTbl') IS NOT NULL DROP TABLE #tempIdTbl


		SELECT TOP 30000 IDENTITY(int,1,1) AS ID
		INTO #tempIdTbl FROM master.dbo.SysColumns


		IF OBJECT_ID('tempdb..#existingExpression') IS NOT NULL DROP TABLE #existingExpression
		IF OBJECT_ID('tempdb..#expression') IS NOT NULL DROP TABLE #expression
		IF OBJECT_ID('tempdb..#temp_expression') IS NOT NULL DROP TABLE #temp_expression

		CREATE TABLE #existingExpression
		(	
			[Id] [int]  NULL,
			[DealId] [smallint] NULL,
			[InternalName] [varchar](200) NULL,
			[DisplayName] [varchar](500) NULL,
			[Expression] [varchar](5000) NULL,
			[ValueFormat] [varchar](100) NULL,
			[CreatedDate] [datetime] NULL,
			[CreatedBy] [varchar](50) NULL,
			[ModifiedDate] [datetime] NULL,
			[ModifiedBy] [varchar](50) NULL,
			[IsActive] [bit] NULL
		)

		CREATE TABLE #expression
		(
		Id int,
		InternalName varchar(200),
		expression varchar(5000),
		Value varchar(200),
		Level int,
		expressionWithout varchar(5000)
		,expressionValuePlaced varchar(5000)
		,valueFormat varchar(5000)
		)

		CREATE TABLE #temp_expression
		(
		Id int,
		InternalName varchar(200),
		expression varchar(5000),
		Value varchar(200),
		Level int,
		expressionWithout varchar(500)
		,expressionValuePlaced varchar(500)
		)
		--e.DealId=cc.DealId and CalculateCategory
		INSERT INTO #existingExpression (Id,DealId,InternalName,DisplayName,Expression,ValueFormat,CreatedDate,
			CreatedBy,ModifiedDate,ModifiedBy,IsActive)
		SELECT					ExpressionId,e.DealId,InternalName,DisplayName,Expression,ValueFormat,e.CreatedDate,
			e.CreatedBy,e.ModifiedDate,e.ModifiedBy,e.IsActive
			FROM cw.expression e

			WHERE  e.DealId=@dealId AND e.isactive=1 
			
			ORDER BY 1 ASC

		

		------------------------INSERT 1st level entry FROM expression table only
		INSERT INTO #expression
			SELECT Id, InternalName,expression,CONVERT(varchar(200),NULL) AS value
			, 1 AS Level,replace(replace(expression,'[',''),']','')expressionWithout, replace(replace  (expression,'[',''),']','') expressionValuePlaced  ,ValueFormat
			FROM #existingExpression 
			WHERE expression NOT LIKE '%expression%'
			AND DealId=@dealId AND isactive=1 ORDER BY 1 ASC

		--SELECT * FROM #expression

		
		DECLARE @maxExpressionCount int=(SELECT count (*) FROM #existingExpression WHERE DealId=@dealId AND isactive=1)
		SET @currentExpressionCount =(SELECT count (*) FROM #Expression);

		SET  @level =2;

		
		WHILE(@currentExpressionCount<@maxExpressionCount)
		BEGIN

		SET @maxLevel =(SELECT max(level) FROM #expression)

			IF OBJECT_ID('tempdb..#SortlevelExpression') IS NOT NULL DROP TABLE #SortlevelExpression

			CREATE TABLE #SortlevelExpression
			(
			expressionId int,
			InternalName varchar(500),
			expression varchar(5000),
			value varchar(200)
			)


			INSERT INTO #SortlevelExpression
			SELECT id,InternalName ,expression,0 value  FROM #existingExpression WHERE id NOT IN (SELECT id FROM #expression)


			IF OBJECT_ID('tempdb..#SortInnerExpressionTbl') IS NOT NULL DROP TABLE #SortInnerExpressionTbl

			CREATE TABLE #SortInnerExpressionTbl
			(
				Id int IDENTITY(1,1)
				,expressionId int 
				,InternalName varchar(500)
				,variableToReplace varchar(500)	
				,variableName  varchar(500)
				,onlyVariableName varchar(200)
				,value varchar(200)
				,level int

			)

			SELECT TOP 1 @expressionId=expressionId FROM #SortlevelExpression ORDER BY expressionId ASC;
			--select @expressionId


			SET @Delimiter  = '['

			WHILE(@expressionId>0)
			BEGIN
				SELECT @String=expression,@expression_internalName=InternalName FROM #SortlevelExpression WHERE expressionId=@expressionId;


				SET @String = @Delimiter + @String + @Delimiter
				
				SET @String= (SELECT
				    CASE 
					 WHEN @String LIKE '%,greaterthanequal,%' THEN REPLACE(@String,',greaterthanequal,','')
				     WHEN @String LIKE '%,lessthanequal,%' THEN REPLACE(@String,',lessthanequal,','')
				     WHEN @String LIKE '%,equal,%' THEN REPLACE(@String,',equal,','')
				     WHEN @String LIKE '%,notequal,%' THEN REPLACE(@String,',notequal,','')
				     WHEN @String LIKE '%,greaterthan,%' THEN REPLACE(@String,',greaterthan,','')
				     WHEN @String LIKE '%,lessthan,%' THEN REPLACE(@String,',lessthan,','')
					 ELSE @String
					END);

				INSERT INTO #SortInnerExpressionTbl
				SELECT @expressionId  AS expressionId,@expression_internalName AS InternalName,
				SUBSTRING(@String, ID, CHARINDEX(@Delimiter, @String, ID+1) - ID) variableToReplace
				,
				replace(
						replace(
								SUBSTRING(@String, ID, CHARINDEX(@Delimiter, @String, ID+1) - ID-1),
								'[',
								'')
						,']'
						,'') variableName
						, NULL,CONVERT(varchar(200),NULL) AS value , NULL
				FROM #tempIdTbl
				WHERE ID < LEN(@String) AND ID>1
				AND SUBSTRING(@String, ID, 1) = @Delimiter

	
				SET @expressionId=(SELECT TOP 1 expressionId FROM #SortlevelExpression WHERE expressionId>@expressionId ORDER BY 1 ASC);

			END


			UPDATE #SortInnerExpressionTbl
			SET onlyVariableName=cw.fnGetTableAndColumn(variablename,'column') 


			UPDATE ie
			SET level=@level
			FROM #SortInnerExpressionTbl ie JOIN #expression e ON e.InternalName=ie.onlyVariableName

			UPDATE #SortInnerExpressionTbl
			SET level=@level
			WHERE cw.fnGetTableAndColumn(variablename,'table')='cw.variable'

			UPDATE #SortInnerExpressionTbl
			SET level=0
			WHERE level IS NULL


			INSERT INTO #expression
			SELECT id, InternalName,expression,CONVERT(varchar(200),NULL) AS value
			, @level AS Level,replace(replace(expression,'[',''),']','')expressionWithout
			, replace(replace  (expression,'[',''),']','') expressionValuePlaced  , ValueFormat
			FROM #existingExpression 
			WHERE id IN (SELECT expressionId FROM #SortInnerExpressionTbl GROUP BY expressionId HAVING min(level)=@level)

			SET @currentExpressionCount =(SELECT count (*) FROM #Expression);
			SET @level=@level+1;

		END


		--select * from #existingExpression
		--SELECT * FROM #expression

		--PRINT 'MESSAGE: EXPRESSION ARRANGED AS PER LEVEL'



		-------------------------------------------------------------------------------------------------------

		
		--DECLARE @pDealIpdRunId INT =11,@pUserName varchar(20)='fm\shriyad'
		--DECLARE @Message VARCHAR(4000)

		--DECLARE @dealId          INT,
		--		@tempId          INT,
		--		@text            VARCHAR(100),
		--		@returnValue_str VARCHAR(500),
		--		@SQL             NVARCHAR(max),
		--		@variableValue   VARCHAR(200),
		--		@tempSql         NVARCHAR(max),
		--		@expressionId           INT,
		--		@currentExpressionCount INT =0,
		--		@level                  INT,
		--		@tempStr             VARCHAR(max),
		--		@tempFilterCondition VARCHAR(max),
		--		@tempVariableId      INT,
		--		@expression_internalName VARCHAR(500),
		--		@String    VARCHAR(1000),
		--		@Delimiter CHAR(1) = '[',
		--		@maxLevel INT ;

		--SELECT @dealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId


		SET  @level =1;

		SET @maxLevel =(SELECT max(level) FROM #expression)

		WHILE(@level<=@maxLevel)
		BEGIN
			IF OBJECT_ID('tempdb..#levelExpression') IS NOT NULL DROP TABLE #levelExpression

			CREATE TABLE #levelExpression
			(
			expressionId int,
			InternalName varchar(500),
			expression varchar(5000),
			value varchar(200)
			)


			INSERT INTO #levelExpression
			SELECT id,InternalName ,expression,value  FROM #expression WHERE level=@level


			IF OBJECT_ID('tempdb..#InnerExpressionTbl') IS NOT NULL DROP TABLE #InnerExpressionTbl

			CREATE TABLE #InnerExpressionTbl
			(
				Id int IDENTITY(1,1)
				,expressionId int 
				,InternalName varchar(500),
				variableToReplace varchar(500)	,
				variableName  varchar(500)
				, value varchar(200)
			)


			SELECT TOP 1 @expressionId=expressionId FROM #levelExpression ORDER BY expressionId ASC;

			SET 
			@Delimiter = '['

			WHILE(@expressionId>0)
			BEGIN
				SELECT @String=expression,@expression_internalName=InternalName FROM #levelExpression WHERE expressionId=@expressionId;

				SET @String = @Delimiter + @String + @Delimiter


				SET @String= (SELECT
				    CASE 
					 WHEN @String LIKE '%,greaterthanequal,%' THEN REPLACE(@String,',greaterthanequal,','')
				     WHEN @String LIKE '%,lessthanequal,%' THEN REPLACE(@String,',lessthanequal,','')
				     WHEN @String LIKE '%,equal,%' THEN REPLACE(@String,',equal,','')
				     WHEN @String LIKE '%,notequal,%' THEN REPLACE(@String,',notequal,','')
				     WHEN @String LIKE '%,greaterthan,%' THEN REPLACE(@String,',greaterthan,','')
				     WHEN @String LIKE '%,lessthan,%' THEN REPLACE(@String,',lessthan,','')
					 ELSE @String
					END);

				INSERT INTO #InnerExpressionTbl
				SELECT @expressionId  AS expressionId,@expression_internalName AS InternalName,
				SUBSTRING(@String, ID, CHARINDEX(@Delimiter, @String, ID+1) - ID) variableToReplace
				,
				replace(
						replace(
								SUBSTRING(@String, ID, CHARINDEX(@Delimiter, @String, ID+1) - ID-1),
								'[',
								'')
						,']'
						,'') variableName
						, CONVERT(varchar(200),NULL) AS value 
				FROM #tempIdTbl

				WHERE ID < LEN(@String) AND ID>1

				AND SUBSTRING(@String, ID, 1) = @Delimiter

	
				SET @expressionId=(SELECT TOP 1 expressionId FROM #levelExpression WHERE expressionId>@expressionId ORDER BY 1 ASC);
			END

			DECLARE 
			 @variableName varchar(500),@tempValue varchar(200);

			SELECT TOP 1 @tempId=id FROM #InnerExpressionTbl ORDER BY Id ASC;

			WHILE(@tempId>0)
			BEGIN
				SELECT @variableName=variablename FROM #InnerExpressionTbl WHERE id=@tempId;

				IF CHARINDEX('ABS(',@variableName) > 0
				BEGIN
		
					IF CHARINDEX('cw.variable.',@variableName) > 0
					BEGIN
						
					   SET @variableName=(SELECT substring(@variableName,CHARINDEX('(',@variableName)+1,CHARINDEX(')',@variableName)-5));
		
					   SELECT @tempValue=value 
					   FROM #mainVariabletbl 
					   WHERE variableName=@variableName;

					   UPDATE #InnerExpressionTbl
					   SET value =CONVERT(decimal(38,16),abs(@tempValue))
					   WHERE id=@tempId; 
					END
				END
				ELSE IF CHARINDEX('MAX(',@variableName) > 0
				BEGIN
		
					IF CHARINDEX('cw.variable.',@variableName) > 0
					BEGIN
						
					   SET @variableName=(SELECT substring(@variableName,CHARINDEX('(',@variableName)+1,CHARINDEX(')',@variableName)-5));
		
					   SELECT @tempValue=value 
					   FROM #mainVariabletbl 
					   WHERE variableName=@variableName;

					   UPDATE #InnerExpressionTbl
					   SET value =abs(@tempValue)
					   WHERE id=@tempId; 
					END
				END
				ELSE
				BEGIN
					IF CHARINDEX('cw.variable.',@variableName) > 0
					BEGIN
					   SELECT @tempValue=value 
					   FROM #mainVariabletbl 
					   WHERE variableName=@variableName;

					   UPDATE #InnerExpressionTbl
					   SET value =@tempValue
					   WHERE id=@tempId;

					  
					END
				END

				SET @tempId=(SELECT TOP 1 id FROM #InnerExpressionTbl WHERE id>@tempId ORDER BY Id ASC);
			END

			

			---------------update InnerExpressionTbl FROM previous level values
			UPDATE ie
			SET value=e.value
			FROM #expression e, #InnerExpressionTbl ie
			WHERE ie.variablename='cw.expression.'+e.InternalName

		
		
			---------------update #expression FROM InnerExpressionTbl 
			DECLARE 
			@variableToRep varchar(500),@valueToRep varchar(200);

			SELECT TOP 1 @tempId=id FROM #InnerExpressionTbl ORDER BY id ASC;

			WHILE(@tempId>0)
			BEGIN
				SELECT @variableToRep=variableName,@valueToRep=value FROM #InnerExpressionTbl WHERE id=@tempId;

				UPDATE #expression
				SET expressionValuePlaced=replace(expressionValuePlaced,@variableToRep,@valueToRep)
				

				SET @tempId=(SELECT TOP 1 id FROM #InnerExpressionTbl WHERE id>@tempId ORDER BY 1 ASC);
			END
			
					

			
			---------------evaluating final value stored in expressionValuePlaced in #expression
			DECLARE 
			@valueQuery nvarchar(500),@expressionVal varchar(200)
			DECLARE @spName varchar(200)
			SELECT TOP 1 @tempId=id FROM #expression WHERE [level]=@level ORDER BY Id ASC
			WHILE(@tempId>0)
			BEGIN
				
					---------------------------------START: TRANSFORMATION IN QUERY JUST BEFORE EXECUTION 
					IF EXISTS (SELECT * FROM #expression WHERE id=@tempId AND expressionValuePlaced LIKE '%CW.SPEVALUATEBOOLEANCONDITION%')
					BEGIN
						SET @valueQuery =( SELECT expressionValuePlaced FROM #expression WHERE id=@tempId);

						SET @spName =  substring(@valueQuery,0, charindex(' ',@valueQuery));

						SET @valueQuery =  substring(@valueQuery,charindex(' ',@valueQuery)+1, len(@valueQuery));

						SELECT @valueQuery = ''''''''+substring(@valueQuery,0,charindex(',',@valueQuery))
						+''''',' 
						+substring(
							substring(@valueQuery,
										charindex(',',@valueQuery)+1,
										len(@valueQuery))
							,0
							,charindex(',',
									substring(@valueQuery,
												charindex(',',@valueQuery)+1,
												len(@valueQuery))
								)
							)
						+',''''' 
						+substring(
							substring(@valueQuery,
										charindex(',',@valueQuery)+1,
										len(@valueQuery))
							,charindex(',',
									substring(@valueQuery,
												charindex(',',@valueQuery)+1,
												len(@valueQuery))
								)+1
							,len(@valueQuery)
							)
						+''''''''

						SET @valueQuery = @spName + ' '+@valueQuery+',@oResult = @out OUTPUT'

						DECLARE @out bit
						--print 'here'
						--print @valueQuery
						EXEC sp_executesql @Valuequery, N'@out bit OUTPUT', @out OUTPUT;

						--select @out
						UPDATE #expression
						SET value=@out
						WHERE id=@tempId
					END

					ELSE IF EXISTS (SELECT * FROM #expression WHERE id=@tempId AND expressionValuePlaced LIKE '%CW.SPSETIIFCONDITION%')
					BEGIN
						SET @valueQuery =( SELECT expressionValuePlaced FROM #expression WHERE id=@tempId);

						SET @spName =  substring(@valueQuery,0, charindex(' ',@valueQuery));

						SET @valueQuery =  substring(@valueQuery,charindex(' ',@valueQuery)+1, len(@valueQuery));

						--SELECT @valueQuery = ''''''''+substring(@valueQuery,0,charindex(',',@valueQuery))
						--+''''',' 
						--+substring(
						--	substring(@valueQuery,
						--				charindex(',',@valueQuery)+1,
						--				len(@valueQuery))
						--	,0
						--	,charindex(',',
						--			substring(@valueQuery,
						--						charindex(',',@valueQuery)+1,
						--						len(@valueQuery))
						--		)
						--	)
						--+',''''' 
						--+substring(
						--	substring(@valueQuery,
						--				charindex(',',@valueQuery)+1,
						--				len(@valueQuery))
						--	,charindex(',',
						--			substring(@valueQuery,
						--						charindex(',',@valueQuery)+1,
						--						len(@valueQuery))
						--		)+1
						--	,len(@valueQuery)
						--	)
						--+''''''''

						--SET @valueQuery = @spName + ' '+@valueQuery+',@oResult = @outValue OUTPUT'
						SET @valueQuery = @spName + ' @InputStr='''+@valueQuery+''',@oResult = @outValue OUTPUT'

						DECLARE @outValue VARCHAR(MAX)
						--print 'here'
						--print @valueQuery
						EXEC sp_executesql @Valuequery, N'@outValue VARCHAR(MAX) OUTPUT', @outValue OUTPUT;

						--select @out
						UPDATE #expression
						SET value=@outValue
						WHERE id=@tempId
					END

					ELSE
					BEGIN

						IF EXISTS (SELECT * FROM  #expression WHERE id=@tempId AND valueFormat ='datetime')
						BEGIN
							SET @valueQuery=(SELECT 'SELECT @expressionVal='''+expressionValuePlaced+'''' FROM #expression WHERE id=@tempId)
						END
						ELSE
						BEGIN
							SET @valueQuery=(SELECT 'SELECT @expressionVal='+expressionValuePlaced FROM #expression WHERE id=@tempId)
						END

						IF(Charindex('CW.FNINLINEMAX',@valueQuery)>0)
						BEGIN

							SET @valueQuery=(
											SELECT 
												substring(@valueQuery,0,charindex('(',@valueQuery)+1)
												+''''+substring(@valueQuery
																,charindex('(',@valueQuery)+1,
																len(substring(@valueQuery
																			,charindex('(',@valueQuery)+1
																			,len(@valueQuery)-1))-1)+
												''''+substring(@valueQuery
													,charindex(')',@valueQuery)
													,len(@valueQuery))
											);
							END
				

					--print @valueQuery

					---------------------------------END: TRANSFORMATION IN QUERY JUST BEFORE EXECUTION

					SET @expressionVal = NULL;

					EXEC sp_executesql @valueQuery, N'@expressionVal varchar(200) OUT', @expressionVal OUt
					

					UPDATE #expression
					SET value=@expressionVal
					WHERE id=@tempId
				END

				SET @tempId=(SELECT TOP 1 id FROM #expression WHERE [level]=@level AND id>@tempId ORDER BY 1 ASC);
			END

			SET @level=@level+1;

		END
		
	
		DELETE FROM [CW].[VariableValue] 
		WHERE DealIpdRunId=@pDealIpdRunId AND VariableId IN ( SELECT VariableId FROM cw.Variable v
								WHERE   v.DealId=@dealId AND v.isactive=1  )

		INSERT INTO [CW].[VariableValue] (
		DealIpdRunId,VariableId,ValueFormat,Value,
		IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)
		SELECT @pDealIpdRunId,v.VariableId,v.ValueFormatType,mv.value,
		1,getDate(),@pUserName,GETDATE(),@pUserName
		FROM #mainVariabletbl mv, cw.Variable v WHERE 'cw.variable.'+v.InternalName=mv.variablename
		ORDER BY mv.variablename 
		
		DELETE FROM [CW].[ExpressionValue] 
		WHERE DealIpdRunId=@pDealIpdRunId AND ExpressionId IN ( SELECT expressionId FROM cw.Expression e
								WHERE    e.DealId=@dealId AND e.isactive=1  )

		INSERT INTO [CW].[ExpressionValue]
		(DealIpdRunId,ExpressionId,Level,ValueFormat,Value,
		IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)
		SELECT @pDealIpdRunId,ce.ExpressionId,e.Level,ce.ValueFormat,e.Value,
		1,getDate(),@pUserName,GETDATE(),@pUserName
		FROM #expression e
		JOIN cw.Expression ce ON e.InternalName= ce.InternalName
		


	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()
		EXEC app.SaveErrorLog 1, 1, 'spCalculateExpression', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName		
			
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )		

		
	END CATCH
END

GO