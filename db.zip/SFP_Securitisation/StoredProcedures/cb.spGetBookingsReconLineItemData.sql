USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingsReconLineItemData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingsReconLineItemData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 10-mar-2023
--Description: GET Booking Recon LineItem Data 
--[cb].[spGetBookingsReconLineItemData] 6,60,''

--==================================   
CREATE PROCEDURE [cb].[spGetBookingsReconLineItemData] 
   @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  

BEGIN TRY  
     SELECT
	   bg.InternalName as InternalName,
	   bg.displayName as LineItem,
	   CAST(bv.Value AS DECIMAL(18,2)) as LineItemValue,
	   bv.DealIpdRunId as DealIpdRunId
	FROM 
		[cfgcb].[BookingReconLineItem] bg
			LEFT JOIN [cb].[BookingReconLineItemValue] bv ON bg.BookingReconLineItemId =bv.BookingReconLineItemId
			LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
	WHERE 
			bv.DealIpdRunId = @pIPDRunId AND dir.IsCurrentVersion = 1 
  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetBookingsReconLineItemData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END

Go