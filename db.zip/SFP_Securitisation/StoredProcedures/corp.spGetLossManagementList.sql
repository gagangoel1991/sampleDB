USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spGetLossManagementList]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spGetLossManagementList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 22-Sept-2022
Description    : This will return Loss Management List
Execution      : EXEC [corp].[spGetLossManagementList] 'Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/


CREATE PROCEDURE [corp].[spGetLossManagementList]
	@pUserName VARCHAR(50)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE @ReqCols XML 
		DECLARE @RowID VARCHAR (100) 
		DECLARE @LossManagementWorkflowID INT = (SELECT WorkflowTypeId FROM cfgcw.WorkflowType WHERE [Name] = 'Loss_Management')
		DECLARE @UnderReviewID INT = (SELECT WorkflowStepId FROM cfgcw.WorkflowStep WHERE StepName = 'UnderReview' AND WorkflowTypeId = @LossManagementWorkflowID)
		DECLARE @CorpDealIds VARCHAR(50)
		DECLARE @CurrentDate DATETIME = GETDATE()
		DECLARE @RemovedFromReviewStepId INT = (SELECT WorkflowStepId FROM cfgCW.WorkflowStep WHERE WorkflowTypeId = 16 AND StepName = 'RemovedFromReview')
		

		/* FETCH MAX PARTITION ID FOR WHICH BATCH IS COMPLETE */			
		DECLARE @MaxPartitionID VARCHAR(10) = CONVERT(VARCHAR(10), [corp].[fnGetMaxPartitionId]()) 

		/* DROP TEMPORARY TABLES */
		IF OBJECT_ID('tempdb..#LossesData') IS NOT NULL
			DROP TABLE #LossesData
		IF OBJECT_ID('tempdb..#InactiveLosses') IS NOT NULL
			DROP TABLE #InactiveLosses
		IF OBJECT_ID('tempdb..#NewLosses') IS NOT NULL
			DROP TABLE #NewLosses


		/* CONVERT CORPORATE DEAL IDs TO COMMA SEPARATED STRING FORMAT */
		SET @CorpDealIds = STUFF((SELECT DISTINCT ',' + CONVERT(VARCHAR, [corpDeal].[DealId])
									FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] corpDeal
									INNER JOIN cfg.Deal SecDeal ON SecDeal.DealName = corpDeal.DealName
									INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] ff 
										ON ff.PartitionId = @MaxPartitionID
									INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bdf 
										ON bdf.DealFacilityGroupKey =  ff.DealFacilityGroupKey AND bdf.DealKey = corpDeal.DealId
									WHERE [corpDeal].[IsActive] = 'Y' AND [SecDeal].[IsActive] = 1
									FOR XML PATH('')
								),1,1,'')


		/* CONVERT REQUIRED COLUMN NAMES TO XML FORMAT */
		SELECT @ReqCols = (SELECT CriteriaFieldName
							FROM (VALUES ('FacilityId')
										,('DealName')
										,('FacilitySourceId')
										,('CIS')
										,('SubSector')
										,('FacilityStartDate')
										,('MaturityDate')
										,('OriginalLenderName')
										,('MasterGradingScore')
										,('UtilisationGBP_ReportingDate')
										,('CommittedExposure')
										,('LastGradingDate')
										,('RONAATFlagging')) Field(CriteriaFieldName)
									FOR XML PATH('Node'), ROOT('Root')
								)

		/* EXECUTE COMMON SP TO FETCH THE DATA  */

		PRINT 'Common SP Execution Started : ' + CONVERT(VARCHAR(20), GETDATE())

		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
				@VintageDate = @MaxPartitionID,
				@DealKey	 = @CorpDealIds,
				@FacilityIds = NULL,
				@ReqColumns	 = @ReqCols,
				@OutputRowID = @RowID OUTPUT

		PRINT 'Common SP Execution Ended : ' + CONVERT(VARCHAR(20), GETDATE())

		/* INSERT DATA INTO #LossesData FROM STAGING TABLE  */
		SELECT DISTINCT 
				DealName
				,FacilityId
				,FacilitySourceId
				,CIS
				,SubSector
				,FacilityStartDate
				,MaturityDate
				,OriginalLenderName AS [OriginatorName]
				,CommittedExposure
				,UtilisationGBP_ReportingDate
				,MasterGradingScore
				,LastGradingDate AS [MGS27DefaultDate]
				,RONAATFlagging
		INTO #LossesData 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		/* DELETE DATA FROM STAGING TABLE AFTER USE */
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		/* INSERT NEW LOSSES WHICH ARE NOT PRESENT IN [corp].[LossManagement] INTO #NewLosses */
		SELECT
			LossData.FacilityId
			,LossData.DealName
		INTO #NewLosses
		FROM #LossesData LossData
		INNER JOIN [cfg].[Deal] DL ON DL.DealName = LossData.DealName
		LEFT JOIN [corp].[LossManagement] LM ON LM.FacilityId = LossData.FacilityId AND LM.DealId = DL.DealId AND LM.IsActive = 1
		WHERE LM.LossManagementId IS NULL AND LossData.MasterGradingScore = '27'

		/* INSERT LOSSES WHICH ARE PRESENT IN REMOVED FROM REVIEW STATE INTO #InactiveLosses */
		SELECT
			LM.LossManagementId
		INTO #InactiveLosses
		FROM [corp].[LossManagement] LM
		INNER JOIN [cfg].[Deal] DL ON DL.DealId = LM.DealId 
		INNER JOIN #LossesData LossData ON LossData.FacilityId = LM.FacilityId AND LossData.DealName = DL.DealName
		WHERE LM.WorkflowStepId = @RemovedFromReviewStepId AND LM.ManualRemovePartitionId <> @MaxPartitionID AND LossData.MasterGradingScore = '27'

		BEGIN TRANSACTION CORP_NewLosses

		/* UPDATE LOSSES WHICH WERE REMOVED FROM REVIEW PREVIOUSLY */
		UPDATE LM
		SET [WorkflowStepId] = @UnderReviewID,
			[ManualRemovePartitionId] = NULL,
			[IsActive] = 1, 
			[ModifiedBy] = 'System',
			[ModifiedDate] = @CurrentDate, 
			[MGS27DefaultDate] = LossData.MGS27DefaultDate,
			[AllocatedLosses] = NULL,
			[IsAllocatedLossLoaded] = 0
		FROM [corp].[LossManagement] LM
		INNER JOIN [cfg].[Deal] DL ON DL.DealId = LM.DealId 
		INNER JOIN #LossesData LossData ON LossData.FacilityId = LM.FacilityId AND LossData.DealName = DL.DealName 
		WHERE LM.LossManagementId IN (SELECT LossManagementId FROM #InactiveLosses)

		/* UPDATE STATUS OF INACTIVE LOSSES IN [cw].[WorkflowProcess] TO UNDER REVIEW */
		INSERT INTO [cw].[WorkflowProcess]
			(ProcessReferenceId
			,WorkflowStepId
			,Comment
			,ActionedBy
			,ActionedDate
			,CreatedDate)
		SELECT
			LM.LossManagementId
			,@UnderReviewID
			,'Previously removed from review Facility marked Under Review again'
			,'System'
			,@CurrentDate
			,@CurrentDate
		FROM [corp].[LossManagement] LM
		INNER JOIN [cfg].[Deal] DL ON DL.DealId = LM.DealId
		INNER JOIN #InactiveLosses IL ON IL.LossManagementId = LM.LossManagementId 

		/* INSERT NEW LOSSES IN [corp].[LossManagement] */
		INSERT INTO [corp].[LossManagement]
					([FacilityId]
					,[DealId]
					,[FacilitySourceId]
					,[WorkflowStepId]
					,[IsActive]
					,[CreatedBy]
					,[CreatedDate]
					,[ModifiedBy]
					,[ModifiedDate]
					,[MGS27DefaultDate]
					,[IsAllocatedLossLoaded])
		SELECT
			LossData.FacilityId
			,DL.DealId
			,LossData.FacilitySourceId
			,@UnderReviewID
			,1
			,'System'
			,@CurrentDate
			,'System'
			,@CurrentDate
			,LossData.MGS27DefaultDate
			,0
		FROM #LossesData LossData
		INNER JOIN [cfg].[Deal] DL ON DL.DealName = LossData.DealName
		INNER JOIN #NewLosses NL ON LossData.FacilityId = NL.FacilityId AND NL.DealName = DL.DealName


		/* UPDATE STATUS OF NEW LOSSES IN [cw].[WorkflowProcess] */
		INSERT INTO [cw].[WorkflowProcess]
			(ProcessReferenceId
			,WorkflowStepId
			,Comment
			,ActionedBy
			,ActionedDate
			,CreatedDate)
		SELECT
			LM.LossManagementId
			,@UnderReviewID
			,'MGS 27 Facility marked Under Review'
			,'System'
			,@CurrentDate
			,@CurrentDate
		FROM [corp].[LossManagement] LM
		INNER JOIN [cfg].[Deal] DL ON DL.DealId = LM.DealId
		INNER JOIN #NewLosses NL ON LM.FacilityId = NL.FacilityId AND DL.DealName = NL.DealName

		COMMIT TRANSACTION CORP_NewLosses

		/* CTE TO GET LATEST WRITEOFF DATA FOR A FACILITY */
		;WITH writeOffCTE AS
		(
			SELECT *,
				ROW_NUMBER() OVER (PARTITION BY FacilityId ORDER BY [Year], [Month] DESC) AS RowNo
			FROM [corp].[WriteOffData]
			WHERE IsActive = 1
		)

		/* SELECT THE REQUIRED DATA FOR LOSS MANAGEMENT LISTING PAGE */ 
		SELECT 
				LM.LossManagementId AS [LossManagementId]
				,DL.DealName AS [Deal]
				,CASE 
					WHEN LM.FacilitySourceId = 1 THEN 'RMP'
					WHEN LM.FacilitySourceId = 2 THEN 'PRISM'
				END AS [Source]
				,CONVERT(INT, LM.FacilityId) AS [FacilityId]
				,LossData.CIS AS [ReferenceEntityId]
				,LossData.CIS AS [ReferenceEntityGroupId]
				,LossData.SubSector AS [SubSector]
				,CONVERT(VARCHAR(11), LossData.FacilityStartDate, 103) AS [FacilityStartDate]
				,CONVERT(VARCHAR(11), LossData.MaturityDate, 103) AS [MaturityDate]
				,LossData.RONAATFlagging AS [InitialRona]
				,LM.DefaultedNotional AS [DefaultedNotional]
				,LM.FacilitySharePercent AS [FacilitySharePercent]
				,LossData.OriginatorName AS [Originator]
				,LM.CreditEventNoticeDate AS [CreditEventNoticeDate]
				,LM.EvidenceSentDate AS [EvidenceSentDate]
				,LM.CreditEventVerifiedDate AS [CreditEventVerifiedDate]
				,LM.WaterfallDateClaimed AS [WaterfallDateClaimed]
				,LM.FxRateDate AS [FxRateDate]
				,LM.DefaultDate AS [DefaultDate]
				,LM.CreditEventTypeId AS [CreditEventTypeId]
				,LM.ExposureAtDefault AS [ExposureAtDefault]
				,LM.CurrentExposure AS [CurrentExposure]
				,LM.InitialLossPercent AS [InitialLossPercent]
				,LM.InitialLossAmount AS [InitialLossAmount]
				,LM.FinalLossAmount AS [FinalLossAmount]
				,LM.InitialVerifiedLossAmount AS [InitialVerifiedLossAmount]
				,LM.RealisedRecoveries AS [RealisedRecoveries]
				,LM.AdjustedRecoveries AS [AdjustedRecoveries]
				,LM.FinalEstimatedRecoveries AS [FinalEstimatedRecoveries]
				,LM.TotalAdjustedRecoveries AS [TotalAdjustedRecoveries]
				,LM.TotalLossAmount AS [TotalLossAmount]
				,LM.FinalWaterfallCalculationNumber AS [FinalWaterfallCalculationNumber]
				,LM.CreditLossEventAmount AS [CreditLossEventAmount]
				,LM.RestructuredPrincipalAmount AS [RestructuredPrincipalAmount]
				,LM.FinalVerificationDate AS [FinalVerificationDate]
				,LM.WaterfallDate AS [WaterfallDate]
				,lossData.CommittedExposure AS [CurrentLimit]
				,lossData.UtilisationGBP_ReportingDate [DrawnAmount]	
				,lossData.MasterGradingScore [MGS]
				,LM.MGS27DefaultDate AS [MGS27DefaultDate]
				,LM.AllocatedLosses AS [AllocatedLosses]
				,ISNULL(LM.IsAllocatedLossLoaded, 0) AS [IsAllocatedLossLoaded]
				,LM.WorkflowStepId AS [Status]
				,LM.Comments AS [Comments]
				,LM.ModifiedBy AS [ModifiedBy]	
				,lastAction.Comment AS [LastAuditComment]	
				,lastAction.ActionedDate AS [LastUpdateTimestamp]
				,LM.AccountStatus AS [AccountStatus]
				,LM.RecoverySource AS [RecoverySource]
				,LM.DefaultReason AS [DefaultReason]
				,LM.MGS27DefaultAmount AS [MGS27DefaultAmount]
		FROM [corp].[LossManagement] LM
		INNER JOIN [cfg].[Deal] DL ON LM.DealId = DL.DealId
		LEFT JOIN #LossesData LossData ON LM.FacilityId = LossData.FacilityId AND DL.DealName = LossData.DealName
		LEFT JOIN writeOffCTE WD ON LM.FacilityId = WD.FacilityId AND WD.RowNo = 1
		LEFT JOIN [cw].[vwWorkFlowLastAction] lastAction ON WorkflowTypeName = 'Loss_Management' AND LM.LossManagementId = lastAction.ProcessReferenceId
		WHERE LM.IsActive = 1 AND LM.WorkflowStepId <> @RemovedFromReviewStepId
		ORDER BY FacilityId

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION CORP_NewLosses
		END

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetLossManagementList',
			@errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
