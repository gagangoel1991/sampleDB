USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spIR_GetICT12MonthForwardTestResult]') IS NOT NULL
	DROP PROCEDURE [cb].[spIR_GetICT12MonthForwardTestResult]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cb].[spIR_GetICT12MonthForwardTestResult]
/*
 * Author: Kapil Sharma
 * Date:	10.02.2022
 * Description:  This will return the ICT 12 MONTHS forward calculation result
 * 
 * Example - 
 * [cb].[spIR_GetICT12MonthForwardTestResult] '2021-05-28', 'Deimos', 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pAsAtDate			DATE, 
@pDealName			VARCHAR(100),
@pUserName			VARCHAR(80) = NULL
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE 
			@dealIpdRunId                  INT,
			@dealId                        SMALLINT,
			@collectionEndDt				DATE

		SELECT   
		  @dealIpdRunId = dir.DealIpdRunId ,
		  @dealId = dir.DealId,
		  @collectionEndDt = did.CollectionBusinessEnd
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		JOIN cw.vwDealIPDDates did ON did.DealIpdId = di.DealIpdId
		WHERE   
			deal.DealName = @pDealName  
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
			AND dir.IpdSequence <> 0  

		DECLARE @tblTestLineItemValue TABLE(Id INT IDENTITY(1,1), DisplayName VARCHAR(200), LineItemValue VARCHAR(100), SortOrder INT)

		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue, SortOrder)
		SELECT 
			tli.DisplayName, 
			tliv.Value,
			tli.SortOrder
		FROM 
			cb.TestLineItemValue tliv
		JOIN cfgcb.TestLineItem tli ON tli.TestLineItemID = tliv.TestLineItemID
		JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
		WHERE 
			tt.InternalName = 'ICT12MonthsForwardTest' AND tliv.DealIpdRunId = @dealIpdRunId 
		ORDER BY 
			tli.SortOrder 

		--Now insert active notes details
		INSERT INTO @tblTestLineItemValue(DisplayName, LineItemValue, SortOrder)
		SELECT dn.[Name], CASE WHEN dn.IsSwapLinked = 1 THEN nsWF.PayRate * dnWF.PrincipalOutstanding_GBP ELSE dnWF.RateForEstimation*dnWF.PrincipalOutstanding_GBP END, 
		ROW_NUMBER() OVER(ORDER BY dn.DealNoteId)  + 2
		FROM cfgcb.DealNote dn
		JOIN cb.DealNote_Wf dnWF ON dnWF.DealNoteId = dn.DealNoteId 
		LEFT JOIN cfgcb.NoteSwap ns ON dn.DealNoteId = ns.DealNoteId AND ns.ValidTo>=@collectionEndDt
		LEFT JOIN cb.NoteSwap_Wf nsWF ON nsWF.NoteSwapId = ns.NoteSwapId AND nsWF.DealIpdRunId = dnWF.DealIpdRunId
		WHERE dnWF.DealIpdRunId = @dealIpdRunId


		SELECT DisplayName, LineItemValue [Value] FROM @tblTestLineItemValue ORDER BY SortOrder

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetICT12MonthForwardTestResult', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO


