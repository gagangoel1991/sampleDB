USE SFP_Securitisation

GO

IF OBJECT_ID('cw.spGetDealIrConfig') IS NOT NULL
DROP PROC  cw.spGetDealIrConfig
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetDealIrConfig]
/*
 * Author: Kapil Sharma
 * Date:	14.12.2020
 * Description:  This will return the Deal Ir Config single record based on id
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * Saurabh		6-2-2-2021
 * 
 * exec cw.spGetDealIrConfig 15,1,'bhasaaa'
 *
 * cw.spGetDealIrConfig 23,1,22,'bhasaaa','Reference Registry'
 * -------------------------------------------------------
*/		
@pDealIrConfigId		INT,
@pTypeId	VARCHAR(20),
@pDealId	INT = NULL,
@pUserName    VARCHAR(80) ,
@pReportTypeName VARCHAR(50) = '',
@pAssetClassID INT = 1
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE @DealTypeId INT;
		SET @DealTypeId=( SELECT DealTypeId FROM cfg.Deal WHERE DealId= @pDealId )
		DECLARE @ReportTypeId INT;
		SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
		SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 
	
		IF @pTypeId = '1'
		BEGIN
		
			DECLARE @defaultTemplateFile varchar(255)
			, @DraftRequestCreatedBy varchar(255)
			, @IR_Reporting_Management INT =1
			, @WorkflowName varchar(40)='IR_Reporting_Management'
			
			SELECT @defaultTemplateFile = Value FROM cw.vw_DealLookup WHERE TypeCode='Build_IR' AND Name='IR_Template'
			
			IF(@pReportTypeName = 'Reference Registry')
			BEGIN 
				SET @IR_Reporting_Management  = (select WorkflowTypeId from cfgcw.WorkflowType wft  WHERE wft.[Name] = 'RR_Reporting_Management')
				SET @WorkflowName = 'RR_Reporting_Management'
				Select @defaultTemplateFile = NULL;
			END 
			
			--Select @DraftRequestCreatedBy = ActionedBy
			--			From [cw].[vwWorkflowProcess] 
			--			where WorkflowProcessId = ( Select MAX(WorkflowProcessId) from [cw].[vwWorkflowProcess]
			--										where Name='IR Reporting Management' 
			--										and Description ='IR Reporting Mgmt - Draft'
			--										and ProcessReferenceId=@pDealIrConfigId )

			SELECT IR_Conf.Name,
			IR_Conf.Description,
			IR_Conf.DealId,
			IR_Conf.TemplateId,
			IR_Conf.OriginalFileName,
			IR_Conf.UploadedFileName,
			IRT.OriginalFileName AS TemplateFileName,
			@defaultTemplateFile AS DefaultFileName,
			IR_Conf.WorkflowStepId,
			wfc.Comment AS AuthorizerComment,
			isNull(wf.ActionedBy, '') AS 'AuthRequestorUserName',
			isNull(@DraftRequestCreatedBy,'') AS 'DraftRequestCreatedBy',
			IR_Conf.ModifiedBy AS LastModifiedUserName,
			IR_Conf.ModifiedDate AS LastModifiedDate,
			ws.DisplayName AS Status,
			convert(bit,IR_Conf.CanShowSecurity) as CanShowSecurity 
			FROM [cfgCW].[IR_DealIrConfig] IR_Conf
			LEFT JOIN cfgCW.IR_Template IRT ON IRT.TemplateID=IR_Conf.TemplateID  AND IR_Conf.ReportTypeId = IRT.ReportTypeId
			LEFT JOIN (SELECT ActionedBy, ProcessReferenceId   
						FROM [cw].[vwWorkflowProcess] 
						WHERE WorkflowProcessId = ( SELECT MAX(WorkflowProcessId) 
										FROM [cw].[vwWorkflowProcess]
										WHERE Name=@WorkflowName
										AND DisplayName ='Pending Authorisation'
										AND ProcessReferenceId=@pDealIrConfigId )
						) wf ON Wf.ProcessReferenceId = IR_Conf.DealIrConfigId
			LEFT JOIN (SELECT Comment, ProcessReferenceId
						FROM [cw].[vwWorkflowProcess] 
						WHERE WorkflowProcessId = ( SELECT MAX(WorkflowProcessId) 
										FROM [cw].[vwWorkflowProcess]
										WHERE Name=@WorkflowName AND ProcessReferenceId=@pDealIrConfigId 
										)) wfc ON Wfc.ProcessReferenceId = IR_Conf.DealIrConfigId						
			LEFT JOIN cfgCW.WorkflowStep ws ON ws.WorkflowStepId = IR_Conf.WorkflowStepId AND ws.WorkflowTypeId=@IR_Reporting_Management
		 	WHERE DealIrConfigId = @pDealIrConfigId  AND IR_Conf.ReportTypeId = @ReportTypeId
		END  
		ELSE IF @pTypeId = '2' -- Active Deal Names and selected deal name
			BEGIN
			SELECT 				
					DealId AS DealId,
					DealName
				FROM
					app.vwActiveDeal      
                WHERE (AssetClassId = @pAssetClassID  and SortOrder IS NOT NULL) 
				 OR ( AssetClassId = @pAssetClassID and DealType = 'SRT')

					--select * from corp.vwActiveDeal -- asset class id
			END 
			ELSE IF  @pTypeId = '3' --Template List 
			BEGIN
				SELECT Template.TemplateId  ,Template.Name 
				FROM [cfgCW].[IR_Template] Template	
			    	WHERE DealTypeId = ISNULL(@DealTypeId,DealTypeId) AND ReportTypeId = @ReportTypeId
					AND Template.AssetClassId = @pAssetClassID
					--Asset Class ID/Report Id
			END   
			ELSE IF  @pTypeId = '4' -- starts with selection 
			BEGIN	
				SELECT 
				DISTINCT 
				IrStratMap.DealIrStratMapId,
				Strat.StratID,
				Strat.StratTypeId,
				CASE WHEN DL.Name ='Bespoke Field' THEN '*' + Strat.Name ELSE Strat.Name END AS Name,
                CAST(CASE WHEN IrStratMap.DealIrStratMapId IS NULL THEN 0 ELSE 1 END AS BIT)  AS IsSelected,		
				IrStratMap.AnchorCell 
				 FROM [cfgCW].[IR_Strat]  Strat 
			    LEFT JOIN cfgCW.IR_AssetStrat SM ON SM.StratId=Strat.StratId AND SM.ReportTypeId = Strat.ReportTypeId 
			    LEFT JOIN cw.vw_DealLookup DL ON DL.LookupValueId = SM.FieldTypeLookupId        
				LEFT JOIN [cfgCW].[IR_DealIrStratMap] IrStratMap  ON Strat.StratID = IrStratMap.StratID
				AND( (IrStratMap.DealIrConfigId IS NULL) OR ( IrStratMap.DealIrConfigId = @pDealIrConfigId))
				INNER JOIN cfgCW.IR_StratDealTypeMap STM ON STM.StratId= Strat.StratId AND STM.StratDealTypeId = @DealTypeId
    			WHERE Strat.IsLocked <> 2 AND Strat.ReportTypeId = @ReportTypeId AND Strat.AssetClassId = @pAssetClassID
				ORDER BY Name
		END 
			ELSE IF @pTypeId = '5'
			BEGIN 
				SELECT fmap.EligibilityCriteriaFieldId AS [Value],
					ec.CriteriaFieldName as [Title],
					fmap.FieldOrderId,
					fmap.DisplayFieldName,
					fmap.AggregationTypeId,
					ec.FieldDescription,
					ec.FieldDataType,
					FL.FieldLevel
				FROM ps.PoolAdhocReportFieldMap fmap
				JOIN ps.EligibilityCriteriaField ec 
					ON fmap.EligibilityCriteriaFieldId = ec.EligibilityCriteriaFieldId
				JOIN [cfgCW].[IR_DealIrStratMap]  smap 
					ON smap.StratId = fmap.StratId
				JOIN [ps].[FieldLevel] FL
					ON FL.FieldLevelId = fmap.FieldLevelId
				WHERE smap.DealIrConfigId = IIF(@pDealIrConfigId = 0,-1,@pDealIrConfigId)
					AND fmap.IsActive =  1;
			END


			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetDealIRConfig', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
