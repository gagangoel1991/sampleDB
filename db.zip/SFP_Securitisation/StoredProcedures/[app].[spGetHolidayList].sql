USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spGetHolidayList]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [app].[spGetHolidayList]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- [app].[spGetHolidayList]
CREATE PROCEDURE [app].[spGetHolidayList]
AS
BEGIN	
	BEGIN TRY	
		SELECT AsAtDate AS Date,
			ISNULL([UK], 0) AS IsUKHoliday, 
			ISNULL([NI], 0) AS IsNIHoliday, 
			ISNULL([ROI], 0) AS IsROIHoliday
		FROM
		(
			SELECT AsAtDate, RegionCode, 1 AS IsHoliday
				FROM [sfp].[syn_SfpModel_vw_Calendar_v1] 
				WHERE IsWeekend = 0 AND IsWorkingDay = 0
		) AS SourceTable
		PIVOT
		(
			MAX(IsHoliday) FOR RegionCode IN ([UK], [NI], [ROI])
		) AS HolidayTable
		ORDER BY AsAtDate ASC

   END TRY
	BEGIN CATCH		
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetHolidayList', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, ''
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
