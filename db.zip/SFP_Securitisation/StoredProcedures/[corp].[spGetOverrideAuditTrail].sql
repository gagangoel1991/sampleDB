USE [SFP_Securitisation]
GO

-- exec [corp].[spGetOverrideAuditTrail] @dealId=1, @pEntityName='Facility', @vintageDate='2022-08-31', @pUserName = 'kumasdt' 
-- exec [corp].[spGetOverrideAuditTrail] @dealId=8, @pEntityName='Facility', @vintageDate='2022-08-31', @pUserName = 'kumasdt' 
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetOverrideAuditTrail]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetOverrideAuditTrail]
GO


/**********************************************************************************************************************************
Author:			Saurav Kumar
Description:	Gets the list of facilities and their original as well as overridden/updated values that is then output as Excel report
				for OverrideAuditTrail.
Update:			Saurav : Created the SP
				Saurav : 20-Feb-2023 | Changed logic for getting original values for Update fields (RONA, MaturityDate@Sec)
**********************************************************************************************************************************/
CREATE PROCEDURE [corp].[spGetOverrideAuditTrail]
	@dealId INT,
	@pEntityName VARCHAR(20),
	@vintageDate Date,
	@pUserName VARCHAR(50)
AS
BEGIN
	
	BEGIN TRY

		IF OBJECT_ID('tempdb.dbo.#tempAuditTrail', 'U') IS NOT NULL			DROP TABLE #tempAuditTrail
		IF OBJECT_ID('tempdb.dbo.#dfr', 'U') IS NOT NULL					DROP TABLE #dfr
		IF OBJECT_ID('tempdb.dbo.#tempOriginalValues', 'U') IS NOT NULL		DROP TABLE #tempOriginalValues
		IF OBJECT_ID('tempdb.dbo.#tmpCsp', 'U') IS NOT NULL					DROP TABLE #tmpCsp
		
		DECLARE @entityType INT = (SELECT DealDataCorrectionEntityId FROM [corp].[DealDataCorrectionEntity] WHERE EntityName = @pEntityName)
		DECLARE @dealStatus varchar(25) = 'Authorised'

		-- Get list of all available columns in common SP staging table
		DECLARE @sqlCsp varchar(max) = 'Select Top 1 * From [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] Where 1=0'
		SELECT   column_ordinal, name, system_type_name
		INTO     #tmpCsp
		FROM     sys.dm_exec_describe_first_result_set(@sqlCsp, NULL, 0)
		ORDER BY column_ordinal;

		-- Get the list of active attributes available for override
		DECLARE @sql1 NVARCHAR(MAX) = N'', 
				@sql2 NVARCHAR(MAX) = N'', 
				@sqlOverriddenCols NVARCHAR(MAX) = N'';

		-- Get the list of available attributes that can be overridden for the selected entity type
		Declare @AttributeList TABLE(AttributeName varchar(100), AttributeFieldName varchar(100))
		DECLARE @AttributeListActual TABLE(AttributeName varchar(100))
		DECLARE @AttributeListDiff TABLE(AttributeName varchar(100))

		IF @entityType = 1			-- Facility entity type
		BEGIN
			INSERT INTO @AttributeList
			SELECT CriteriaFieldSql, CriteriaFieldName FROM ps.EligibilityCriteriaField WHERE AssetClassId = 2 AND isOverrideAllowed = 1 AND IsActive = 1 AND CriteriaFieldTable = 'Facility' AND CriteriaFieldName NOT IN ('FacilityId', 'Comments', 'securityId')
		END
		ELSE IF @entityType = 2		-- Security entity type
		BEGIN
			INSERT INTO @AttributeList
			SELECT CriteriaFieldSql, CriteriaFieldName FROM ps.EligibilityCriteriaField WHERE AssetClassId = 2 AND isOverrideAllowed = 1 AND IsActive = 1 AND CriteriaFieldTable = 'Security' AND CriteriaFieldName NOT IN ('FacilityId', 'Comments', 'securityId')
		END
		
		INSERT INTO @AttributeListActual	SELECT AttributeName FROM @AttributeList	WHERE AttributeName IN (SELECT [name] FROM #tmpCsp)
		INSERT INTO @AttributeListDiff		SELECT AttributeName FROM @AttributeList	WHERE AttributeName NOT IN (SELECT [name] FROM #tmpCsp)


		SELECT Top 1 DealName FROM corp.vwActiveDeal WHERE AssetClassDealId = @dealId AND AssetClassId = 2


		-- Select the details about latest override set
			SELECT Top 1 
				   DOP.ModifiedBy OverriddenBy, 
				   DOP.ModifiedDate OverrideDate, 
				   DOP.AuthorizedBy AuthorisedBy, 
				   DOP.AuthorizedDate AuthorisationDate,
				   AD.DealName DealName,
				   DOP.AsAtDate VintageDate
			  FROM [corp].[DealOverrideParent] DOP
			  JOIN corp.[DealDataCorrectionStatus] ST ON ST.DealDataCorrectionStatusId = DOP.DataCorrectionStatus
			  JOIN corp.vwActiveDeal AD ON DOP.DealId = AD.AssetClassDealId AND AD.AssetClassId = 2
			 WHERE DOP.DealId = @dealId
			   AND ST.Status = @dealStatus
			   AND DOP.IsActive = 1
			   AND ST.IsActive = 1
		  ORDER BY DealOverrideParentId DESC
		
		-- Output list of attributes that can be overridden
		Select * From @AttributeList

		-- Break out from SP if there are no attributes
		DECLARE @AttributeCount INT = (SELECT COUNT(*) FROM @AttributeList)
		DECLARE @AttributeCountActual INT = (SELECT COUNT(*) FROM @AttributeListActual)

		IF (@AttributeCount = 0 OR @AttributeCountActual = 0)
		BEGIN
			RETURN
		END

		SELECT @sql1 = STUFF(
			(
				select ','+ cast(B.AttributeName as nvarchar(255)) 
				from @AttributeListActual B
				FOR XML PATH('')
			)
			,1,1,'')
		FROM @AttributeListActual A

		Set @sql2 = 'SELECT ' + @sql1 + ' FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE 1 = 0'

		SELECT @sqlOverriddenCols = STUFF(
			(
				select ',['+ cast(B.AttributeName as nvarchar(255)) + '-OverrideValue]'
				from @AttributeList B
				FOR XML PATH('')
			)
			,1,1,'')
		FROM @AttributeList A


		-- Create primary temp table with all the available dynamic columns
		Create Table #tempAuditTrail (
			FacilitySecurityId BIGINT NOT NULL,
			DealOverrideParentId INT NOT NULL, 
			[AuthorizedBy] VARCHAR(20),
			[AuthorizedDate] DATETIME,
			OverrideBy VARCHAR(20),
			OverrideDate DATETIME
		);

		SELECT   column_ordinal, name, system_type_name
		INTO     #dfr
		FROM     sys.dm_exec_describe_first_result_set(@sql2, NULL, 0)
		ORDER BY column_ordinal;

		DECLARE @OrdNo INT = (SELECT MAX(column_ordinal) FROM #dfr)

		INSERT INTO #dfr
		SELECT ROW_NUMBER() OVER(ORDER BY AttributeName) + @OrdNo, AttributeName, 'varchar(100)'
		FROM @AttributeListDiff

		DECLARE @alter NVARCHAR(MAX) = N'ALTER TABLE #tempAuditTrail ADD ';

		SET @alter += STUFF((   SELECT   NCHAR(10) + d.name + N' ' + d.system_type_name + N',[' + d.name + NCHAR(45) + N'OverrideValue] ' + d.system_type_name + N','
								FROM     #dfr AS d
								WHERE    d.name <> N'Id'
								ORDER BY d.column_ordinal
								FOR XML PATH(N''), TYPE ).value(N'.[1]', N'NVARCHAR(4000)'), 1, 1, N'');

		SET @alter = LEFT(@alter, LEN(@alter) - 1);

		EXEC ( @alter );

		-- Get the FacilityList along with the override values and add it to the temp table.
		Declare @sql3 NVARCHAR(MAX) = N'
		INSERT INTO #tempAuditTrail(FacilitySecurityId, DealOverrideParentId, [AuthorizedBy], [AuthorizedDate], OverrideBy, OverrideDate, ' + @sqlOverriddenCols + ')
		SELECT FacilitySecurityId, DealOverrideParentId, [AuthorizedBy], [AuthorizedDate], OverrideBy, OverrideDate, ' + @sqlOverriddenCols + '
		FROM (
				SELECT DOP.DealOverrideParentId, DDCD.FacilitySecurityId, FIELD.CriteriaFieldSql + ''-OverrideValue'' AS FieldName, DDCD.[Value], DOP.AuthorizedBy, DOP.AuthorizedDate, DOP.ModifiedBy OverrideBy, DOP.ModifiedDate OverrideDate
				  FROM [corp].[DealOverrideParent] DOP
				  JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId AND DOP.IsActive = 1 AND DDC.IsActive = 1 AND DDC.EntityTypeId = ' + cast(@entityType as varchar(100)) + '
				  JOIN [corp].[DealDataCorrectionDetail] DDCD ON DDC.DealDataCorrectionId = DDCD.DealDataCorrectionId AND DDC.IsActive = 1 AND DDCD.IsActive = 1
				  JOIN ps.EligibilityCriteriaField FIELD ON DDCD.AttributeId = FIELD.EligibilityCriteriaFieldId AND FIELD.IsActive = 1 AND CriteriaFieldName NOT IN (''FacilityId'', ''Comments'', ''securityId'')
				  JOIN corp.[DealDataCorrectionStatus] ST ON ST.DealDataCorrectionStatusId = DOP.DataCorrectionStatus
				  WHERE DOP.DealId = ' + cast(@dealId as varchar(100)) + '
				   AND DOP.AsAtDate = CAST(''' + cast(@vintageDate as varchar(100)) + ''' AS DATE)
				   AND ST.Status = ''' + @dealStatus + '''
				--ORDER BY DOP.DealOverrideParentId, DDCD.DealDataCorrectionDetailId
			) T
			PIVOT (Max([Value]) FOR FieldName IN (' + @sqlOverriddenCols + ')) as PT';

		EXEC(@sql3)

		-- Now get the original values from commonsp and add it to the temp table
		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100) 
		DECLARE @attList varchar(max) = N''
		DECLARE @sqlListActual varchar(max) = ''

		SELECT @sqlListActual = STUFF(
			(
				select ','+ cast(B.AttributeName as nvarchar(255)) 
				from @AttributeListActual B
				FOR XML PATH('')
			)
			,1,1,'')
		FROM @AttributeListActual A

		IF @entityType = 1	-- Facility entity type
		BEGIN
			INSERT INTO @AttributeListActual VALUES ('FacilityId')
			SET @attList = N'FacilityId,' + @sqlListActual
		END
		ELSE IF @entityType = 2		-- Security entity type
		BEGIN
			INSERT INTO @AttributeListActual Values('SecurityId')
			SET @attList = N'SecurityId,' + @sqlListActual
		END

		-- SELECT @ReqCols = ( 
			-- SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType FROM ps.EligibilityCriteriaField WHERE AssetClassId = 2
			-- AND CriteriaFieldSql IN (Select AttributeName From @AttributeListActual) 
			-- FOR XML PATH('Node'), ROOT('Root')
		-- )
		
		SELECT @ReqCols = ( 
			SELECT CriteriaFieldName from (	
				SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName  
				FROM ps.EligibilityCriteriaField   
				WHERE AssetClassId = 2
			AND CriteriaFieldSql IN (Select AttributeName From @AttributeListActual) 
				UNION
				SELECT 'RONA_Actual' AS CriteriaFieldName
				UNION
				SELECT 'MaturityDate_Actual' AS CriteriaFieldName
			) A
			FOR XML PATH('Node'), ROOT('Root')
		)

		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
					@VintageDate = @vintageDate,
					@DealKey	 = @dealId,
					@FacilityIds = NULL,
					@ReqColumns	 = @ReqCols,
					@OutputRowID = @RowID OUTPUT

		SELECT * INTO #tempOriginalValues FROM #tempAuditTrail WHERE 1 = 0

		DECLARE @sql4 varchar(max) = N'
		INSERT INTO #tempOriginalValues(DealOverrideParentId, FacilitySecurityId, ' + @sqlListActual + ')
		SELECT DISTINCT -1, ' + @attList + '
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = ''' + @RowID + ''''

		EXEC(@sql4)
		
		UPDATE OT SET RONA = STG.RONA_Actual, [MaturityDate] = STG.[MaturityDate_Actual]
		FROM #tempOriginalValues OT JOIN [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] STG ON OT.FacilitySecurityId = STG.FacilityId
		WHERE RowId = @RowID

		DELETE FROM #tempOriginalValues WHERE FacilitySecurityId NOT IN (SELECT FacilitySecurityId FROM #tempAuditTrail)
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		DECLARE @sql5 varchar(max) = N''
		SELECT @sql5 = STUFF(
			(
				select ',AT.'+ cast(B.AttributeName as nvarchar(255)) + ' = OT.' + cast(B.AttributeName as nvarchar(255))
				from @AttributeListActual B
				WHERE B.AttributeName NOT IN ('FacilityId', 'SecurityId')
				FOR XML PATH('')
			)
			,1,1,'')
		FROM @AttributeListActual A

		DECLARE @sql6 varchar(max) = N'
		UPDATE AT
		SET ' + @sql5 + '
		FROM #tempAuditTrail AT
		JOIN #tempOriginalValues OT
		ON AT.FacilitySecurityId = OT.FacilitySecurityId'

		Exec(@sql6)

		Select * From #tempAuditTrail

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetOverrideAuditTrail', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
