USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spCopyInitIpdDataOnWithdraw]') IS NOT NULL
	DROP PROCEDURE [cw].[spCopyInitIpdDataOnWithdraw]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================
--Author: Suresh Pandey
--Date:	01-09-2021
--Description:  To insert Initiate Ipd data for withdraw ipd

/*
DECLARE @pResultCode INT   
DECLARE @pNewDealIpdRunId INT        
  exec [cw].[spCopyInitIpdDataOnWithdraw]	3,'fm/pandsbl' ,@pNewDealIpdRunId OUTPUT ,@pResultCode OUTPUT
  Select @pNewDealIpdRunId,@pResultCode

*/
--================================== 

CREATE PROC [cw].[spCopyInitIpdDataOnWithdraw]
(
	@pOldDealIpdRunId SMALLINT,
	@pUserName	VARCHAR(80),
	@pNewDealIpdRunId INT OUTPUT,
	@pResultCode INT OUTPUT 

	/*
		@pResultCode
		1  : Success
		Else : Failed

		@pDealIpdRunId - Newly added run Id 

	*/
)
AS
BEGIN
	
	DECLARE
		@Message		VARCHAR(4000),
		@stepCode		VARCHAR(50)= 'WITHDRAW_INIT',
		@logStatus		VARCHAR(20) = 'STARTED',
		@logDescription	VARCHAR(1000),
		@inputParams	VARCHAR(100) = 'OldDealIpdRunId=' + CONVERT(VARCHAR(10) ,@pOldDealIpdRunId) ,
		@logExecutionId INT,
		@date			DATETIME = GETDATE(),
		@dealIpdWithdrawStatusId	SMALLINT;
	
	SET NOCOUNT ON

	BEGIN TRY
	    
		EXEC cw.spLogExecution @pOldDealIpdRunId, @stepCode, @logStatus,@inputParams, NULL,0,NULL, @pUserName,@logExecutionId OUT

		SELECT @dealIpdWithdrawStatusId = [cw].[fnGetWorkflowStepId]('Withdraw', 'Deal_Ipd')

		UPDATE cw.DealIpdRun
			SET IsCurrentVersion=0, ModifiedBy=@pUserName, ModifiedDate=@date
			WHERE RunID =@pOldDealIpdRunId
						

		INSERT INTO  cw.DealIpdRun(DealIpdId, Version, IsCurrentVersion, WorkflowStepId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
		SELECT DealIpdId,Version + 1 ,1,@dealIpdWithdrawStatusId,@pUserName, @date ,@pUserName, @date FROM [CW].DealIpdRun
			WHERE RunId=@pOldDealIpdRunId
				
		SET @pNewDealIpdRunId = (SELECT SCOPE_IDENTITY());

			
		INSERT INTO [CW].[NoteData_PreWF](DealIpdRunId,DealNoteId,BaseRate,Coupon,DeferredCoupon,DayCount,DayCountFactor,Principal_bf,Interest_bf,IntOnPrincipal,IntOnBfInt,
				TotalIntDue,OpeningPoolFactor,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)			
		SELECT @pNewDealIpdRunId,DealNoteId,BaseRate,Coupon,DeferredCoupon,DayCount,DayCountFactor,Principal_bf,Interest_bf,IntOnPrincipal,IntOnBfInt,
				TotalIntDue,OpeningPoolFactor,1,@date, @pUserName ,@date, @pUserName FROM [CW].[NoteData_PreWF]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY NoteData_PreWFId
		    
		
		INSERT INTO [CW].[VariableValue] (DealIpdRunId,VariableId,ValueFormat,Value,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy) 
		SELECT @pNewDealIpdRunId,VariableId,ValueFormat,Value,IsActive,@date,@pUserName,@date,@pUserName FROM [CW].[VariableValue] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY VariableValueId
			
		INSERT INTO [CW].[ExpressionValue] (DealIpdRunId,ExpressionId,Level,ValueFormat,Value,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)  
		SELECT @pNewDealIpdRunId,ExpressionId,Level,ValueFormat,Value,IsActive,@date,@pUserName,@date,@pUserName FROM [CW].[ExpressionValue] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY ExpressionValueId

		INSERT INTO [CW].[SubLoan_PreWF] (DealIpdRunId,DealSubloanId,DayCount,DayCountFactor,Principal_bf,BaseRate,Coupon,DeferredCoupon, Interest_bf,IntOnPrincipal,IntOnBfInt,
				TotalIntDue,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)
		SELECT @pNewDealIpdRunId,DealSubloanId,DayCount,DayCountFactor,Principal_bf,BaseRate,Coupon,DeferredCoupon, Interest_bf,IntOnPrincipal,IntOnBfInt,
				TotalIntDue,IsActive,@date,@pUserName,@date,@pUserName FROM [CW].[SubLoan_PreWF]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY SubLoan_PreWFId

		INSERT INTO cw.ReserveFund_PreWF (DealIpdRunId,ReserveFundId,ReserveFund_bF,ReserveFundRequiredAmount,ReserveFundDueAmount,ReserveResidualAmount,IsActive,   
                CreatedDate,CreatedBy, ModifiedDate,ModifiedBy)  	
		SELECT @pNewDealIpdRunId,ReserveFundId,ReserveFund_bF,ReserveFundRequiredAmount,ReserveFundDueAmount,ReserveResidualAmount,IsActive,   
                @date,@pUserName,@date,@pUserName FROM [CW].[ReserveFund_PreWF]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY ReserveFund_PreWFId

			
		INSERT INTO cw.PDL_PreWF (DealIpdRunId,ArrearsPDL,Losses,WarehouseLoanAmount,PDLAllocationForCurrentIPD,PDLSettledTillDate,PDEForCurrentIPD,   
				PDLToBePaidInCurrentIPD,OpeningBalance,IsActive, CreatedDate,CreatedBy, ModifiedDate,ModifiedBy)
		SELECT @pNewDealIpdRunId,ArrearsPDL,Losses,WarehouseLoanAmount,PDLAllocationForCurrentIPD,PDLSettledTillDate,PDEForCurrentIPD,   
				PDLToBePaidInCurrentIPD,OpeningBalance,IsActive,@date,@pUserName,@date,@pUserName FROM [CW].[PDL_PreWF]
			WHERE DealIpdRunId=@pOldDealIpdRunId  
			ORDER BY PDL_PreWFId
	        
		INSERT INTO [CW].pdlledger_prewf (DealIpdRunId, DealNoteId,OutstandingAmount,IsPDL_Gt_OutstandingAmount,PDLAllocated,PDLToBeCreditedInWaterfall,PDLToBeDisplayed, 
				OpeningBalance,isActive, CreatedDate, CreatedBy,ModifiedDate, ModifiedBy)  
		SELECT @pNewDealIpdRunId, DealNoteId,OutstandingAmount,IsPDL_Gt_OutstandingAmount,PDLAllocated,PDLToBeCreditedInWaterfall,PDLToBeDisplayed, 
				OpeningBalance,isActive,@date,@pUserName,@date,@pUserName FROM [CW].[pdlledger_prewf]
			WHERE DealIpdRunId=@pOldDealIpdRunId 
			ORDER BY PdlLedger_PreWFId 
				
		INSERT INTO [CW].[InterimWaterfallFee] (DealIpdRunId,InvoiceCategoryTypeId,InvoiceCategoryId,Amount,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate) 	
		SELECT @pNewDealIpdRunId,InvoiceCategoryTypeId,InvoiceCategoryId,Amount,IsActive,@pUserName,@date,@pUserName,@date FROM [CW].[InterimWaterfallFee]
			WHERE DealIpdRunId=@pOldDealIpdRunId 
			ORDER BY InterimWaterfallFeeId 	
			
						
			
		INSERT INTO cw.MiscLedger_PreWF(DealIpdRunId, DealMiscLedgerId, LedgerAmount_bf, ResidualAmount, IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  
		SELECT @pNewDealIpdRunId, DealMiscLedgerId, LedgerAmount_bf, ResidualAmount, IsActive, @pUserName,@date,@pUserName,@date FROM [CW].[MiscLedger_PreWF]
			WHERE DealIpdRunId=@pOldDealIpdRunId 
			ORDER BY MiscLedgerPreWFId

		INSERT INTO cw.DealIpdTriggerResult(DealIpdRunId, DealTriggerMapId, OutcomeSummary, IsBreached, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate) 
		SELECT @pNewDealIpdRunId, DealTriggerMapId, OutcomeSummary, IsBreached,@pUserName,@date,@pUserName,@date FROM [CW].[DealIpdTriggerResult]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdTriggerResultId

		INSERT INTO cw.DealIpdTriggerRatingResult(DealIpdRunId, DealTriggerRatingMapId, ThresholdRating, CurrentRating, IsBreached, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  
		SELECT @pNewDealIpdRunId, DealTriggerRatingMapId, ThresholdRating, CurrentRating, IsBreached,@pUserName,@date,@pUserName,@date FROM [CW].[DealIpdTriggerRatingResult]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdTriggerRatingResultId

			INSERT INTO cw.CashWaterfallDealConfigValue (DealIpdRunId,CashWaterfallDealConfigId,Value
													,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CashWaterfallDealConfigId,Value,1,@pUserName, @date, @pUserName, @date FROM cw.CashWaterfallDealConfigValue 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY CashWaterfallDealConfigId	
			
		INSERT INTO cw.WaterfallLineItemAmount (DealIpdRunId,WaterfallLineItemId,ExpressionId,ToolTipValue,ToolTipFormatType,RequiredAmount,AdjustedAmount,TotalRequiredAmount,   
				ValueFormat,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy,AdjustmentBy,AdjustmentDate) 
		SELECT @pNewDealIpdRunId,WaterfallLineItemId,ExpressionId,ToolTipValue,ToolTipFormatType,RequiredAmount,AdjustedAmount,TotalRequiredAmount,   
				ValueFormat,IsActive,@date,@pUserName,null,null,null,null FROM [CW].[WaterfallLineItemAmount]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY WaterfallLineItemAmountId		

		INSERT INTO cw.DealIpdConditionCriteriaTest (DealIpdRunId,DealConditionCriteriaId,ExpectedStatus,ResultedStatus,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,DealConditionCriteriaId,ExpectedStatus,ResultedStatus,@pUserName, @date, @pUserName, @date FROM cw.DealIpdConditionCriteriaTest 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdConditionCriteriaTestId	

		INSERT INTO cw.DealIpdConditionTest (DealIpdRunId,DealConditionId,ExpectedStatus,ResultedStatus,LoanCount,LoanAmount,RepurchaseAmount,Comment,CreatedBy,
			CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,DealConditionId,ExpectedStatus,ResultedStatus,LoanCount,LoanAmount,RepurchaseAmount,Comment,@pUserName, @date, 
			@pUserName, @date FROM cw.DealIpdConditionTest 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdConditionTestId  

		INSERT INTO [cw].[DealIpdSummaryLineItemStatus](DealIpdRunId, DealIpdSummaryLineItemId, [Status], CreatedBy, CreatedDate, ModifiedBy, ModifiedDate) 
		SELECT @pNewDealIpdRunId, DealIpdSummaryLineItemId, [Status], @pUserName, @date, @pUserName, @date FROM [CW].[DealIpdSummaryLineItemStatus]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdSummaryLineItemStatusId
										

		--Existing workflowprocess record
		INSERT INTO cw.WorkflowProcess(ProcessReferenceId,WorkflowStepId,Comment,ActionedBy,ActionedDate,CreatedDate)
		SELECT @pNewDealIpdRunId,wfp.WorkflowStepId,wfp.Comment,wfp.ActionedBy,wfp.ActionedDate,wfp.CreatedDate FROM   cw.workflowprocess wfp  
		  JOIN  cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId  
		  JOIN  cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId  
		  WHERE wft.[Name] = 'Deal_IPD' AND wfp.ProcessReferenceId = @pOldDealIpdRunId   
		  ORDER BY wfp.ActionedDate
			

			
		EXEC cw.spLogExecution @pOldDealIpdRunId, @stepCode, 'SUCCESS',@inputParams, NULL,0,NULL, @pUserName,@logExecutionId OUT	  

		SET @pResultCode = 1
		
	END TRY
	BEGIN CATCH
		
		DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			 @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cw.spCopyInitIpdDataOnWithdraw', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		EXEC cw.spLogExecution @pOldDealIpdRunId, @stepCode, 'FAILED',@inputParams, @Message,0,NULL, @pUserName,@logExecutionId OUT
		SET @pResultCode = 0
		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )

		
	END CATCH

	
END

GO

