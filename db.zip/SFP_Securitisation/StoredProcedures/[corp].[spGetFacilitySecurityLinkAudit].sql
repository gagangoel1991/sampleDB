USE SFP_Securitisation
GO

IF OBJECT_ID('[corp].[spGetFacilitySecurityLinkAudit]') IS NOT NULL
	DROP PROCEDURE corp.[spGetFacilitySecurityLinkAudit]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--================================================
-- Author: Sakthivel Loganathan
-- Date:	24 Oct 2022
-- Description:  To get the facility-security audit report detail
-- EXEC [corp].[spGetFacilitySecurityLinkAudit] 1, NULL, 'LOGASLL'
--================================================

CREATE PROCEDURE [corp].[spGetFacilitySecurityLinkAudit]
	@pDealId INT, 	
	@pAsAtDate DATE = null,
	@pUserName VARCHAR(50)
AS
BEGIN
	BEGIN TRY 

			DECLARE @StatusId INT = (SELECT [DealDataCorrectionStatusId] FROM [corp].[DealDataCorrectionStatus] WHERE [STATUS] = 'Authorised')

			SELECT DISTINCT FacilityId, SecurityId, CradleSecurityId INTO 
			#TouchedItemsTbl
			FROM [corp].[DealOverrideParent] DOP
				 INNER JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId AND EntityTypeId = 3
				 INNER JOIN [corp].[DealDataCorrectionLinkage] LNK ON DDC.DealDataCorrectionId = LNK.DealDataCorrectionId
			WHERE DOP.DealId = @pDealId and IsLinked = 1 AND DOP.DataCorrectionStatus = @StatusId

			SELECT --DOP.DealOverrideParentId,DDC.DealDataCorrectionId,LNK.DealDataCorrectionLinkageId
					 LNK.SecurityId AS 'Security ID'
					,LNK.CradleSecurityId AS 'Cradle Security ID'
					,LNK.FacilityId AS 'Facility ID'
					,CASE WHEN LNK.IsLinked = '1' THEN 'Relinked' ELSE 'Unlinked' END AS 'Action'
					,DDC.CreatedBy AS 'Override by'
					,DOP.ModifiedBy AS 'Authorised by'
					,DDC.CreatedDate AS 'Override date'
					,DOP.ModifiedDate AS 'Authorisation date'				   
			FROM [corp].[DealOverrideParent] DOP
				 INNER JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId AND EntityTypeId = 3
				 INNER JOIN [corp].[DealDataCorrectionLinkage] LNK ON DDC.DealDataCorrectionId = LNK.DealDataCorrectionId
				 INNER JOIN #TouchedItemsTbl tmp ON LNK.FacilityId = tmp.FacilityId AND LNK.CradleSecurityId = tmp.CradleSecurityId AND LNK.SecurityId = tmp.SecurityId
			WHERE DOP.DealId = @pDealId AND DOP.DataCorrectionStatus = @StatusId
			ORDER BY LNK.FacilityId, LNK.SecurityId, DDC.ModifiedDate 
	END TRY
	
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION SFP_Sec_SaveAdhocReportTemplate
		END
		EXEC app.SaveErrorLog 2, 1, 'spGetFacilitySecurityLinkAudit', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage, @errorSeverity,  @errorState )
	END CATCH;
End

GO
--EXEC [corp].[spGetFacilitySecurityLinkAudit] 8, NULL, 'LOGASLL'