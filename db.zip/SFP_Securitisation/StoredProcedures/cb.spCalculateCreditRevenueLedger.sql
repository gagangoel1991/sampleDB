USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spCalculateCreditRevenueLedger]') IS NOT NULL
	DROP PROCEDURE [cb].[spCalculateCreditRevenueLedger]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spCalculateCreditRevenueLedger] 
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  04.03.2022 
 *   Description:  Calculate override sql of Credit Revenue Ledger for a  line item  of RPP
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 * 
 *   DECLARE @ret_value DECIMAL(38,16)
 *   EXEC cb.spCalculateCreditRevenueLedger 1034,'fm\shriyad' ,@ret_value  OUTPUT
 *   SELECT @ret_value   
 *         
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80),
@oValue DECIMAL(38,16) OUTPUT
)
AS
BEGIN
		BEGIN TRY

		--DECLARE @pDealIpdRunId INT = 1034, @pUserName	VARCHAR(80),@oValue DECIMAL(38,16) 

		DECLARE @IsBreached BIT,  @ARR_TotalRequiredAmount decimal(38,16), @RPP_SumOfTotalRequiredAmount decimal(38,16)

		SELECT @IsBreached = IsBreached FROM [CW].[vwDealIpdTriggerResult] WHERE dealipdrunid=@pDealIpdRunId
		AND TriggerInternalName='IssuerEventOfDefault' 

		SELECT @ARR_TotalRequiredAmount= wlia.TotalRequiredAmount FROM cfgcw.waterfallSource wfs
		JOIN cw.expressionValue ev ON wfs.ExpressionId=ev.expressionId AND ev.DealIpdRunId=@pDealIpdRunId
		JOIN cfgcw.waterfallLineItem wli ON ev.expressionId=wli.expressionId 
		JOIN cw.waterfallLineItemAMount wlia ON wli.waterfallLineItemId=wlia.waterfallLineItemId AND wlia.DealIpdRunId=1034
		WHERE SourceType='PreAvailableRevenueReceipts'

		SELECT @RPP_SumOfTotalRequiredAmount=sum(wlia.TotalRequiredAmount) FROM 
		cfgcw.waterfallLineItem wli
		JOIN cw.waterfallLineItemAMount wlia ON wli.waterfallLineItemId=wlia.waterfallLineItemId 
		JOIN cfgcw.WaterfallCategory wc ON wli.WaterfallCategoryId=wc.WaterfallCategoryId AND wc.InternalName='RevenuePriorityofPayments'
		WHERE wli.Rank<=7 AND wlia.DealIpdRunId=@pDealIpdRunId

			SELECT @oValue = IIF(@IsBreached=1,@ARR_TotalRequiredAmount-@RPP_SumOfTotalRequiredAmount,0 );
		END TRY
		BEGIN CATCH
			DECLARE 
				@errorMessage     NVARCHAR(MAX),
				@errorSeverity    INT,
				@errorNumber      INT,
				@errorLine        INT,
				@errorState       INT;

			SELECT 
				@errorMessage = ERROR_MESSAGE()
				,@errorSeverity = ERROR_SEVERITY()
				,@errorNumber = ERROR_NUMBER()
				,@errorLine = ERROR_LINE()
				,@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'spCalculateCreditRevenueLedger', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
			RAISERROR (@errorMessage,
				 @errorSeverity,
				 @errorState )
		END CATCH


	END

GO