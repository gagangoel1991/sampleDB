USE [SFP_Securitisation]

GO

IF OBJECT_ID('cb.spProcessDealDailyCollectionControlCheck') IS NOT NULL
	DROP PROCEDURE cb.spProcessDealDailyCollectionControlCheck
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure cb.spProcessDealDailyCollectionControlCheck    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	30.08.2022
 * Description:  Daily Collection ControlCheck lineitem save data.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
	
exec cb.spProcessDealDailyCollectionControlCheck @pAsAtDate ='14-OCT-2022', @pdealName='Deimos', @pUserName ='kumavnb'
 * -------------------------------------------------------
*/    
        
        
CREATE PROC [cb].[spProcessDealDailyCollectionControlCheck]
@pAsAtDate DateTime,
@pdealName varchar(255),
@pUserName varchar(255) = null 
AS        
BEGIN  
	
	BEGIN TRY  
		
		Declare @dealId INT
		, @dailyCollectionSummaryId INT
		, @prevDailyCollectionSummaryId INT
		, @calendarStartDt			DATE
		, @calendarEndDt			DATE
		, @collectionEndDt			DATE
		, @prevIpdDate				DATE
		, @dealIpdRunId				INT
		, @prevDealIpdRunId				INT
		, @currentMonthIpd    DATE
		, @intCalStartDt        DATE
		, @intCalEndDt        DATE
		, @collBusinessStartDt DATE
		, @CrntDealIpdRunId INT
		, @adviceDate Date;

		DECLARE @dealRegionCode VARCHAR(10);  


		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  
		SELECT @adviceDate = [cw].[fnGetBusinessDate] (@pAsAtDate, @dealRegionCode, 1, 1)

		SELECT  Top 1 
		  @collectionEndDt = did.CollectionBusinessEnd,
		  @calendarStartDt = did.CollectionCalendarStart,
		  @calendarEndDt = did.CollectionCalendarEnd,
		  @prevIpdDate = did.PreviousIPD,
		  @dealIpdRunId = dir.DealIpdRunId,
		  @prevDealIpdRunId = dir.PrevRunId
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		JOIN cw.vwDealIPDDates did ON did.DealIpdId = di.DealIpdId
		WHERE   
			deal.DealName = @pDealName  
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)<= @pAsAtDate   
			AND dir.IpdSequence <> 0  
			Order by ipdDt.CollectionBusinessEnd DESC
			

		
		

		SELECT @currentMonthIpd = IPD, @collBusinessStartDt = CollectionBusinessStart FROM cw.vwDealIpdDates
		WHERE MONTH(CAST(IPD AS DATE)) = MONTH(@adviceDate) AND YEAR(CAST(IPD AS DATE)) = YEAR(@adviceDate)
		AND DealId = @dealId

		Select @CrntDealIpdRunId = MIN(DealIpdRunId) from cw.vwDealIpdRun where DealId = @dealId and PrevRunId>=@prevDealIpdRunId

		IF @adviceDate >=@currentMonthIpd
		BEGIN
			SET @intCalStartDt = [cw].[fnGetBusinessDate](DATEADD(MONTH, -1, DATEADD(DAY, 1, EOMONTH(@pAsAtDate))) , @dealRegionCode, 0, 0)
			SET @intCalEndDt = @pAsAtDate
			SET @prevIpdDate=@currentMonthIpd
			SET @prevDealIpdRunId = @CrntDealIpdRunId
		END
		ELSE
		BEGIN
			SET @intCalStartDt =  @collBusinessStartDt
			SET @intCalEndDt = @pAsAtDate

			IF @intCalStartDt > @calendarEndDt
				SET @prevDealIpdRunId = @CrntDealIpdRunId

		END 

		IF ( Select Count(*) From  [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId ) = 0 
		BEGIN
				INSERT INTO [CW].[DailyCollectionSummary]
				(CollectionDate, DealId, WorkFlowStepId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				Select @pAsAtDate, @dealId, Null, 'System', GetDate(), 'System', GetDate()
		END

		SELECT @dailyCollectionSummaryId = DailyCollectionSummaryId From  [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId 
		SELECT Top 1 @prevDailyCollectionSummaryId =  DailyCollectionSummaryId From  [CW].[DailyCollectionSummary] where CollectionDate < @pAsAtDate and DealId=@dealId order by CollectionDate desc

		Select * INTO #DailyCollectionSummaryLevelData FROM [CW].[DailyCollectionSummaryLevelData] 
		where Convert(datetime, BusinessDate, 103) = @pAsAtDate and DealName = @pdealName

		Select * INTO #PrevDailyCollectionSummaryLevelData FROM [CW].[DailyCollectionSummaryLevelData] 
		where Convert(datetime, BusinessDate, 103) = (Select max(Convert(datetime, BusinessDate, 103)) FROM [CW].[DailyCollectionSummaryLevelData]  where DealName = @pdealName and Convert(datetime, BusinessDate, 103) < @pAsAtdate )
		and DealName=@pdealName
		

		--- Deal Summary - ControlCheck
		Select DailyCollectionLineItemId, LineItem  INTO #ControlCheckLineItems from cw.vwDailyCollectionLineItems where dealId= @dealId and DailyCollectionCategory='Deal Summary - ControlCheck'
		IF (Select Count(*) FROM [CW].[DailyCollectionLineItemValue]
				where DailyCollectionSummaryId =  @dailyCollectionSummaryId
				and DailyCollectionLineItemId in ( Select [DailyCollectionLineItemId] from #ControlCheckLineItems ) )  = 0 
		BEGIN
			Insert INTO [CW].[DailyCollectionLineItemValue]
			(DailyCollectionSummaryId, DailyCollectionLineItemId, Value, Comments, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			Select @dailyCollectionSummaryId, liv.DailyCollectionLineItemId, Null, Null, @pUserName, getDate(), @pUserName, getDate()
			FROM #ControlCheckLineItems liv
		END

		Select * INTO #DailyCollectionLineItemValue from cw.vwDailyCollectionLineItemValue  where DailyCollectionSummaryId=@dailyCollectionSummaryId

		Select * INTO #PrevDailyCollectionLineItemValue from cw.vwDailyCollectionLineItemValue  where DailyCollectionSummaryId=@prevDailyCollectionSummaryId

		Declare @collectionDay INT=1, @postCollectionPeriod varchar(10), @value float

		SET @collectionDay=Datediff(d, @calendarEndDt, @pAsAtDate)

		SET @postCollectionPeriod = CASE WHEN  @collectionDay>0 and @collectionDay <5 Then 'YES' ELSE 'NO' END

		Declare @BalanceinAccrualPeriod float, @InterestRolledonIpd float, @GeneralReserveFund float

		SELECT @BalanceinAccrualPeriod = CAST(SUM(ISNULL(amount, 0)) AS DECIMAL(18,2)) 
		FROM
		(
			SELECT SUM(CAST(IsNull(Value,0) as DECIMAL(38,2))) AS amount FROM cw.vwDailyCollectionLineItemValue WHERE CollectionDate>=@intCalStartDt AND CollectionDate<=@intCalEndDt and LineItemInternalName ='Daily Cash Movement_3.000' and isNull(IsEstimationData,0)=0 and DealId=@dealID
			UNION 
			SELECT SUM(CAST(IsNull(Value,0) as DECIMAL(38,2))) AS amount FROM cw.vwDailyCollectionLineItemValue WHERE CollectionDate>=@intCalStartDt AND CollectionDate<=@intCalEndDt and LineItemInternalName ='Est_Daily Cash Movement_3.000' and isNull(IsEstimationData,0)=1  and DealId=@dealID
		) AS t1

		--ReserveInterest 
		Select @InterestRolledonIpd = sum(InterestAmount) from cb.ReserveInterest where depositdate>=@intCalStartDt and depositdate<=@intCalEndDt
		SET @InterestRolledonIpd = IsNull(@InterestRolledonIpd,0) + IsNull((Select sum(InterestAmount) as CollectionInterest from cb.sfpCollectionInterest where depositdate>=@intCalStartDt and depositdate<=@intCalEndDt),0)

		--ReserveInterest 
		Select @GeneralReserveFund = IsNull(ReserveFund_cf,0) from cb.ReserveFund_PostWF where dealipdrunid = @prevDealIpdRunId


		Update dcliv
		SET dcliv.Value= CAST(CAST(@BalanceinAccrualPeriod as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Balance in Accrual Period_1.000' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value= CAST(CAST(@InterestRolledonIpd as DECIMAL(38,2)) as VARCHAR) 
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Interest Rolled on IPD_2.000' and tdcliv.dealId = @dealId 
		
		Update dcliv
		SET dcliv.Value= CAST(CAST(@GeneralReserveFund as DECIMAL(38,2)) as VARCHAR) 
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='General Reserve Fund_3.000' and tdcliv.dealId = @dealId 
		
		Declare @TotalValue float
		SET @TotalValue = (IsNull(@BalanceinAccrualPeriod,0) + IsNull(@InterestRolledonIpd,0) + IsNull(@GeneralReserveFund,0) )
		Update dcliv
		SET dcliv.Value= CAST(CAST(@TotalValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Total_4.000' and tdcliv.dealId = @dealId 
		
		Declare @SoftLimitCredit float
		SET @SoftLimitCredit=(Select CAST(isNull(Value,0) as decimal(38,2)) FROM [CW].[vw_DealLookup] where TypeCode='DailyCollection_Deimos' and Name='SoftCredit_Limit')
		
		Update dcliv
		SET dcliv.Value= CAST(CAST(@TotalValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Total_5.100' and tdcliv.dealId = @dealId 
		
		Update dcliv
		SET dcliv.Value= CAST(CAST(@InterestRolledonIpd as DECIMAL(38,2)) as VARCHAR) 
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Interest Rolled on IPD_5.200' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value= CAST(CAST(@GeneralReserveFund as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='General Reserve Fund_5.300' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value=   CAST(CAST(@SoftLimitCredit as DECIMAL(38,2)) as VARCHAR) 
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Soft Credit Limit_5.400' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value = CASE WHEN @TotalValue < @SoftLimitCredit THEN 'PASS' ELSE 'FAIL' END
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Soft Credit Limit Check_5.000' and tdcliv.dealId = @dealId 



		
		---========================================

		Update dcliv
		SET dcliv.Value= CAST(CAST(@TotalValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Total_6.100' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value= CAST(CAST(@InterestRolledonIpd as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Interest Rolled on IPD_6.200' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value= CAST(CAST(@GeneralReserveFund as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='General Reserve Fund_6.300' and tdcliv.dealId = @dealId 

		Declare @HardCreditLimit float
		SET @HardCreditLimit=(Select CAST(isNull(Value,0) as decimal(38,2)) FROM [CW].[vw_DealLookup] where TypeCode='DailyCollection_Deimos' and Name='HardCredit_Limit')
		Update dcliv
		SET dcliv.Value=  CAST(CAST(@HardCreditLimit as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Hard Credit Limit_6.400' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value=CASE WHEN @TotalValue < @HardCreditLimit THEN 'PASS' ELSE 'FAIL' END
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Hard Credit Limit check_6.000' and tdcliv.dealId = @dealId 
		
		--=======================================

		SET @Value = ISNULL((SELECT SUM(CrntTrueBalance) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='True Balance_7.000' and tdcliv.dealId = @dealId 
		
		SET @Value = ISNULL((SELECT SUM(CrntCapitalInArrears) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Capital In Arrears_8.000' and tdcliv.dealId = @dealId 

		SET @Value = ISNULL((SELECT SUM(CrntPrepayments) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Prepayments_9.000' and tdcliv.dealId = @dealId 

		SET @Value = ISNULL((SELECT SUM(CrntTotalCapitalBalanceOutstanding) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Total Capital Balance Outstanding_10.000' and tdcliv.dealId = @dealId 

		--===============================
		
		--======================================================================================
				
		SET @Value = ISNULL((SELECT SUM(CrntTotalCapitalBalanceOutstanding) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Total Capital Balance Outstanding_11.099' and tdcliv.dealId = @dealId
		
		
		SET @Value = ISNULL((SELECT SUM([CrntFeesInArrears]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Fees In Arrears_11.100' and tdcliv.dealId = @dealId

		SET @Value = ISNULL((SELECT SUM([CrntFinesInArrears]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Fine In Arrears_11.200' and tdcliv.dealId = @dealId

		SET @Value = ISNULL((SELECT SUM([CrntInterestInArrears]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Interest In Arrears_11.300' and tdcliv.dealId = @dealId

		SET @Value = ISNULL((SELECT SUM([CrntArrearsInsurance]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Arrears Insurance_11.400' and tdcliv.dealId = @dealId

		SET @Value = ISNULL((SELECT SUM([CrntInterestEarnedNotApplied]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Interest Earned Not Applied_11.500' and tdcliv.dealId = @dealId

		SET @Value = ISNULL((SELECT SUM([CrntTrueInterestAfterWorkingCalendarDate]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='True Interest After Working Calendar Date_11.600' and tdcliv.dealId = @dealId

		SET @Value =ISNULL((SELECT SUM([CrntTrueBalance]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='True Balance_11.700' and tdcliv.dealId = @dealId

		
		

		SET @Value = ISNULL((SELECT SUM([CrntControlBreak]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Cumulative Control Break_11.000 ' and tdcliv.dealId = @dealId

		--======================================================================================

		---===============================
		SET @Value = ISNULL((SELECT SUM(NetPrincipalReceiptsCurrentvspreviousBusinessDay) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Net Principal Receipts_12.000' and tdcliv.dealId = @dealId 

		SET @Value = ISNULL((SELECT SUM(NetRevenueReceipts) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Net Revenue Receipts_13.000' and tdcliv.dealId = @dealId 

		SET @Value = ISNULL((SELECT SUM(OverallVariance) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Overall Variance_14.000' and tdcliv.dealId = @dealId 

		SET @Value = ISNULL((SELECT SUM(Variance) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Variance_15.000' and tdcliv.dealId = @dealId 

		
		
		--=====================================

		SET @Value = ISNULL((SELECT SUM(OverallControlBreak) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Daily Control Break Check_16.000' and tdcliv.dealId = @dealId 


		---===================================

		Declare @CLosingPrincipalBalance float, @OpeningPrincipalBalance float
		SET @OpeningPrincipalBalance = IsNULL((SELECT SUM(PrevTotalCapitalBalanceOutstanding) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@OpeningPrincipalBalance as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Opening Principal Balance_17.000' and tdcliv.dealId = @dealId 

		SET @CLosingPrincipalBalance = IsNULL((SELECT SUM(CrntTotalCapitalBalanceOutstanding) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@CLosingPrincipalBalance as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Closing Principal Balance_18.000' and tdcliv.dealId = @dealId 

		
		--====================================
		Declare @AdjustmentValue float
		SET @AdjustmentValue = (Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem In ('Flagging/Deflagging Adjustment', 'Principal Receipts Adjustment (Control Break)',
									'Principal Receipts Adjustment')
									and DailyCollectionCategory='Deal Summary - Adjustments'
								)
		
		Update dcliv
		SET dcliv.Value= CAST(CAST(@AdjustmentValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Principal Adjustment_19.200' and tdcliv.dealId = @dealId 

		SET @Value = ( @OpeningPrincipalBalance - @CLosingPrincipalBalance)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Principal Collections_19.100' and tdcliv.dealId = @dealId 

		Declare @NetPrincipalCollections float
		SET @NetPrincipalCollections  = IsNull((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DailyCollectionLineItemValue where LineItemInternalName ='Net Principal Collections_1.000' and IsNull(IsEstimationData,0)=0),0)
		SET @NetPrincipalCollections  = @NetPrincipalCollections + IsNull((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DailyCollectionLineItemValue where LineItemInternalName ='Est_Net Principal Collections_1.000' and IsNull(IsEstimationData,0)=1),0)

		Update dcliv
		SET dcliv.Value= CASE WHEN CAST(@Value + @AdjustmentValue as DECIMAL(38,2)) = CAST(@NetPrincipalCollections as DECIMAL(38,2)) THEN 'PASS' ELSE 'FAIL' END 
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Principal Movement Rec_19.000' and tdcliv.dealId = @dealId 

		--========================================================

		Declare @CumulativePrincipalValue float
		--#NetPrincipleReceipt - Principal Receipts adjustment - Principal Receipts adjustment(control Vreak)- Flaggin/deflaggin Adjustment
		SET @CumulativePrincipalValue = ISNULL((Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue 
		where CollectionDate<=@pAsAtDate and dealId=@dealId and LineItemInternalName ='Net Principal Collections_1.000' and IsNull(IsEstimationData,0)=0 ),0)


		SET @CumulativePrincipalValue = @CumulativePrincipalValue + ISNULL((Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue 
		where CollectionDate<=@pAsAtDate and dealId=@dealId and LineItemInternalName ='Est_Net Principal Collections_1.000' and IsNull(IsEstimationData,0) = 1 ),0)


		Declare @HitoricalPrincipalValue float, @HistoricalTopUpAmount as float, @HistoricalAdjustmentValue float

		--one time enrty adjustment
		SET @HitoricalPrincipalValue = CAST(7446739303.16 as decimal(38,2)) 
		SET @HistoricalTopUpAmount =  CAST(-2999395807.26 -236201.3 as decimal(38,2))
		SET @HistoricalAdjustmentValue = CAST(-8178 -360 as decimal(38,2))

		SET @CumulativePrincipalValue = ( @CumulativePrincipalValue + @HitoricalPrincipalValue ) + @HistoricalTopUpAmount + @HistoricalAdjustmentValue
		
		/*-Not Required for now-*/
		--SET @CumulativePrincipalValue = @CumulativePrincipalValue - ISNULL((Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue 
		--where CollectionDate<=@pAsAtDate and dealId=@dealId 
		--and LineItemInternalName in ('Principal Receipts Adjustment_6.000', 'Principal Receipts Adjustment (Control Break)_5.000')),0)
		
		--SET @CumulativePrincipalValue = @CumulativePrincipalValue - ISNULL((Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue 
		--where CollectionDate<='21-FEB-2020' and dealId=@dealId 
		--and LineItemInternalName = 'Flagging/Deflagging Adjustment_4.000'),0)
		/*---*/
		
		Declare @TopupAdjustmentValue float, @CutOffDate Date ='01-OCT-2022'
		SET @TopupAdjustmentValue=ISNull((Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue where CollectionDate>@CutOffDate and CollectionDate<=@pAsAtDate and dealId=@dealId and LineItemInternalName ='Top Up Amount_2.000'),0)
	
		SET @CumulativePrincipalValue = @CumulativePrincipalValue + @TopupAdjustmentValue

		Update dcliv
		SET dcliv.Value= CAST(CAST(@CumulativePrincipalValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Cumulative Principal_20.100' and tdcliv.dealId = @dealId 

		Declare @LossAdjustmentValue float
		SET @LossAdjustmentValue=(Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue where CollectionDate<=@pAsAtDate and dealId=@dealId and LineItemInternalName ='Loss Adjustment_3.000')

		Update dcliv
		SET dcliv.Value= CAST(CAST(@LossAdjustmentValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Cumulative Loss_20.200' and tdcliv.dealId = @dealId 

		--Historical Value
		Declare @HitoricalPoolChangeValue float
		SET @TopupAdjustmentValue=ISNull((Select SUM(CAST(isNull(Value,0) as decimal(38,2))) FROM cw.vwDailyCollectionLineItemValue where CollectionDate<=@pAsAtDate and dealId=@dealId and LineItemInternalName ='Top Up Amount_2.000'),0)
		SET @TopupAdjustmentValue = @TopupAdjustmentValue + CAST(2976171405.38 as DECIMAL(38,2))
		SET @HitoricalPoolChangeValue = CAST(12071608084.34 as DECIMAL(38,2))


		SET @value =  CAST(@HitoricalPoolChangeValue - @CLosingPrincipalBalance + @TopupAdjustmentValue as DECIMAL(38,2))
		Update dcliv
		SET dcliv.Value= CAST(CAST(@value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Cumulative Pool Change_20.300' and tdcliv.dealId = @dealId 

		SET @AdjustmentValue = (Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem In ('Flagging/Deflagging Adjustment', 'Principal Receipts Adjustment')
									and DailyCollectionCategory='Deal Summary - Adjustments'
								)
		
		Update dcliv
		SET dcliv.Value= CAST(CAST(@AdjustmentValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Principal Adjustment/Top Up Amount_20.400' and tdcliv.dealId = @dealId 

		SET @value = IsNull(@CumulativePrincipalValue,0) + IsNull(@LossAdjustmentValue,0) - ISNull(@value,0) - IsNull(@AdjustmentValue,0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId 
		Where tdcliv.LineItemInternalName ='Check_20.000' and tdcliv.dealId = @dealId 

		
		--===============================================================
		Declare @ClosingTrueBalance float
		SET @ClosingTrueBalance = ISNULL((SELECT SUM(ClosingTrueBalance) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@ClosingTrueBalance as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Closing True Balance_21.100' and tdcliv.dealId = @dealId 

		
		SET @Value = ISNULL((SELECT SUM([OpeningCustomerStatementBalanceDerived] + [TotalBalanceMovements] + [ClosingAccruedInterest] + [VarianceClosingTrueBalancevsClosingTrueBalanceDerived]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Closing True Balance Derived_21.200' and tdcliv.dealId = @dealId

		Update dcliv
		SET dcliv.Value= CAST(CAST(@ClosingTrueBalance - @Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Check_21.000' and tdcliv.dealId = @dealId 

		---=====================================================

		
		Declare @OpeningTrueBalance float
		SET @OpeningTrueBalance = ISNULL((SELECT SUM([OpeningTrueBalance]) FROM #DailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@OpeningTrueBalance as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Opening True Balance_22.100' and tdcliv.dealId = @dealId 

		SET @Value = ISNULL((SELECT SUM(ClosingTrueBalance) FROM #PrevDailyCollectionSummaryLevelData),0)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@Value as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Closing True Balance Prev Day_22.200' and tdcliv.dealId = @dealId 

		Update dcliv
		SET dcliv.Value= CASE WHEN  @OpeningTrueBalance = @Value THEN 'PASS' ELSE 'FAIL' END
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Opening/ Closing Balance Check_22.000' and tdcliv.dealId = @dealId 
		
		
		SET @value = ISNULL((SELECT SUM([TotalDeflaggedBalance]) FROM #DailyCollectionSummaryLevelData),0)
		SET @AdjustmentValue = (Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem = 'Principal Receipts Adjustment (Control Break)'
									and DailyCollectionCategory='Deal Summary - Adjustments'
								)
		Update dcliv
		SET dcliv.Value= CAST(CAST(@value - @AdjustmentValue as DECIMAL(38,2)) as VARCHAR)
		FROM [CW].[DailyCollectionLineItemValue] dcliv
		INNER JOIN #DailyCollectionLineItemValue tdcliv on dcliv.DailyCollectionLineItemValueId = tdcliv.DailyCollectionLineItemValueId
		Where tdcliv.LineItemInternalName ='Deflagging Adjustment Control Break_22.300' and tdcliv.dealId = @dealId 

 		
	END TRY  
	BEGIN CATCH  

		
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE() + ' For Date ' + Convert(varchar(10), @pAsAtDate, 103) , @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cb.spProcessDealDailyCollectionControlCheck',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH   
	
END

GO

