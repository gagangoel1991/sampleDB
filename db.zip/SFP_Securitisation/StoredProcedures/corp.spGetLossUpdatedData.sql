USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spGetLossUpdatedData]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spGetLossUpdatedData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Sushmita
Creation Date  : 18-01-2023
Description    : This will return Updated Loss Data
Execution      : EXEC [corp].[spGetLossUpdatedData] 'Europa\sushzsx'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spGetLossUpdatedData]
	@pUserName VARCHAR(50)
	AS
BEGIN
	
	BEGIN TRY

	/* SELECT THE Required Data */ 
		SELECT 
			LM.LossManagementId AS [LossManagementId]
			,LM.DefaultedNotional AS [DefaultedNotional]
			,LM.FacilitySharePercent AS [FacilitySharePercent]
			,LM.CreditEventNoticeDate AS [CreditEventNoticeDate]
			,LM.EvidenceSentDate AS [EvidenceSentDate]
			,LM.CreditEventVerifiedDate AS [CreditEventVerifiedDate]
			,LM.WaterfallDateClaimed AS [WaterfallDateClaimed]
			,LM.FxRateDate AS [FxRateDate]
			,LM.DefaultDate AS [DefaultDate]
			,LM.CreditEventTypeId AS [CreditEventTypeId]
			,LM.ExposureAtDefault AS [ExposureAtDefault]
			,LM.CurrentExposure AS [CurrentExposure]
			,LM.InitialLossPercent AS [InitialLossPercent]
			,LM.InitialLossAmount AS [InitialLossAmount]
			,LM.FinalLossAmount AS [FinalLossAmount]
			,LM.InitialVerifiedLossAmount AS [InitialVerifiedLossAmount]
			,LM.RealisedRecoveries AS [RealisedRecoveries]
			,LM.AdjustedRecoveries AS [AdjustedRecoveries]
			,LM.FinalEstimatedRecoveries AS [FinalEstimatedRecoveries]
			,LM.TotalAdjustedRecoveries AS [TotalAdjustedRecoveries]
			,LM.TotalLossAmount AS [TotalLossAmount]
			,LM.FinalWaterfallCalculationNumber AS [FinalWaterfallCalculationNumber]
			,LM.CreditLossEventAmount AS [CreditLossEventAmount]
			,LM.RestructuredPrincipalAmount AS [RestructuredPrincipalAmount]
			,LM.FinalVerificationDate AS [FinalVerificationDate]
			,LM.WaterfallDate AS [WaterfallDate]
			,LM.WorkflowStepId AS [Status]
			,LM.Comments AS [Comments]
			,LM.ModifiedBy AS [ModifiedBy]	
			,lastAction.Comment AS [LastAuditComment]	
			,lastAction.ActionedDate AS [LastUpdateTimestamp]
			,LM.AccountStatus AS [AccountStatus]
			,LM.DefaultReason AS [DefaultReason]
			,LM.MGS27DefaultAmount AS [MGS27DefaultAmount]
			,LM.RecoverySource AS [RecoverySource]
			

		FROM [corp].[LossManagement] LM 
		INNER JOIN [cw].[vwWorkFlowLastAction] lastAction ON WorkflowTypeName = 'Loss_Management' AND LM.LossManagementId = lastAction.ProcessReferenceId
		WHERE LM.IsActive = 1

END TRY
BEGIN CATCH	
DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetLossUpdatedData',
			@errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO