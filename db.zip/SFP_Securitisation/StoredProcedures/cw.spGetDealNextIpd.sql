USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetDealNextIpd]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealNextIpd]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetDealNextIpd]
/*
 * Author: Kapil Sharma
 * Date:	25.17.2020
 * Description:  This will return the next IPDs of a deal
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealId				INT,		
@pUserName				VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		DECLARE
			@currentIpdDate				DATETIME,
			@currentIpdWorkflowStepId	SMALLINT,
			@currentDealIpdId			INT

		SELECT @currentIpdDate = IpdDate, @currentIpdWorkflowStepId = WorkflowStepId, @currentDealIpdId = di.DealIpdId FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		WHERE di.IsCurrentIPD = 1 AND dir.IsCurrentVersion = 1
		AND di.DealId = @pDealId

		IF NOT EXISTS(SELECT TOP 1 * FROM cfgcw.WorkflowStep wfs 
			JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
			WHERE wft.Name = 'Deal_IPD' AND wfs.StepName NOT IN ('SendForAuthorisation', 'Authorise')
			AND wfs.WorkflowStepID = @currentIpdWorkflowStepId)
		BEGIN
			SELECT @currentIpdDate = NextIPD FROM cw.vwDealIpdDates WHERE DealIpdId = @currentDealIpdId AND DealId = @pDealId
		END

		SELECT 
			CAST(ipd.IpdDate AS DATE) AS IpdDate, 
			ipd.DealId 
		FROM 
			cw.DealIpd ipd
		JOIN cw.vw_ActiveDeal deal ON ipd.DealId = deal.DealId		
		WHERE 
			ipd.DealId = @pDealId 
			AND ipd.IpdDate>= @currentIpdDate
			AND NOT (ipd.IpdDate > EarlyRedemptionDate AND [DealStatus] IN ('Collapse','Terminate')) --Remove all ipd dates which are greater then EarlyRedemptionDate

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetDealNextIpd', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END

GO
