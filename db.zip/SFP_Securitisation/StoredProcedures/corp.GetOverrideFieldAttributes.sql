USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[GetOverrideFieldAttributes]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[GetOverrideFieldAttributes]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
	CREATED BY : Sakthivel
	DATE	   : 10-Aug-2022
	NOTES	   : To get the list of attributes to override
	-- EXEC corp.GetOverrideFieldAttributes 'FACILITY'
*/

CREATE PROC corp.GetOverrideFieldAttributes
(
	@pEntityTypeName VARCHAR(50)
)
AS
BEGIN

	DECLARE @EntityTypeId INT = (SELECT DealDataCorrectionEntityId FROM [corp].[DealDataCorrectionEntity] WHERE EntityName = @pEntityTypeName)
	DECLARE @AssetClassId INT = (SELECT AssetClassId FROM ps.AssetClass WHERE Code = 'CL')

	--DECLARE @TemplateName VARCHAR(100)
	--IF(@pEntityTypeName = 'facility')
	--BEGIN
	--	SELECT @TemplateName = 'FacilityOverrideTemplate'
	--END
	--ELSE
	--BEGIN 
	--	SELECT @TemplateName = 'SecurityOverrideTemplate'
	--END

	SELECT 
		COLUMN_NAME,
		DATA_TYPE,
		CHARACTER_MAXIMUM_LENGTH,
		NUMERIC_PRECISION,
		NUMERIC_PRECISION_RADIX,
		NUMERIC_SCALE 
	INTO #Tmp_Staging_Schema
	FROM [corp].[syn_SfpModelCorporate_vw_CorporateStagingTblSchema]

	SELECT	
			row_number() over (ORDER BY EligibilityCriteriaFieldId) SeqNumber,
			field.EligibilityCriteriaFieldId AS AttributeId,
			field.CriteriaFieldName AS AttributeName,
			--CASE WHEN field.CriteriaFieldName in( 'FacilityId', 'SecurityID') THEN field.CriteriaFieldName ELSE field.FieldDescription END AS DisplayName, 
			--field.CriteriaFieldName AS DisplayName,
			CASE WHEN dt.[Type] = 'Date' THEN field.CriteriaFieldName + ' (dd-mm-yyyy)' ELSE field.CriteriaFieldName END AS DisplayName,
			field.FieldDescription AS Description,
			@EntityTypeId AS EntityTypeId,
			0 AS AttributeObjectId,
			0 AS AttributeObjectName,
			CASE WHEN field.CriteriaFieldName IN ('FACILITYID','SECURITYID') THEN 'Integer' ELSE dt.[Type] END AS DataType,
			CASE WHEN field.CriteriaFieldName IN ('FACILITYID','SECURITYID') THEN 'False' ELSE 'True' END AS IsEditable,
			0 AS IsChecked,
			0 AS IsHideAllowed,
			field.IsActive AS IsActive ,
			Stg.DATA_TYPE as StageDataType,
			Stg.NUMERIC_SCALE, 
			ISNULL(Stg.NUMERIC_PRECISION,0) - ISNULL(Stg.NUMERIC_SCALE ,0) AS StageMaxAllowedDigits
	INTO #tbl_Fields
	FROM [ps].[EligibilityCriteriaField] field 
	INNER JOIN ps.fielddatatype dt ON field.FieldDataType = dt.FieldDataTypeId
	LEFT JOIN #Tmp_Staging_Schema Stg ON field.CriteriaFieldSql = Stg.COLUMN_NAME
	WHERE field.IsActive = 1 AND field.isOverrideAllowed = 1
		  AND CriteriaFieldTable = CASE WHEN field.CriteriaFieldName ='FACILITYID' THEN 'FACILITY' ELSE @pEntityTypeName END
		  AND field.AssetClassId= @AssetClassId
	ORDER BY field.CriteriaFieldName

	SELECT SeqNumber,AttributeId, AttributeName,DisplayName,Description,EntityTypeId,AttributeObjectId,
		   AttributeObjectName,DataType,IsEditable,IsChecked,IsHideAllowed,IsActive,
		   ISNULL(StageDataType, 'varchar') AS StageDataType,
		   ISNULL(StageMaxAllowedDigits, 0) AS StageMaxAllowedDigits,
		   ISNULL(NUMERIC_SCALE,0) AS StageMaxprecision
	FROM (
	SELECT * FROM #tbl_Fields
	UNION
	SELECT 
			99,
			EligibilityCriteriaFieldId,
			CriteriaFieldName,
			FieldDescription,
			FieldDescription,
			@EntityTypeId AS EntityTypeId,
			0 AS AttributeObjectId,
			0 AS AttributeObjectName,
			'Text' AS DataType,
			'True' AS IsEditable,
			0 AS IsChecked,
			0 AS IsHideAllowed,
			IsActive ,
			'varchar' StageDataType, 
		    NULL NUMERIC_SCALE,
		    NULL StageMaxAllowedDigits
	 FROM [ps].[EligibilityCriteriaField] WHERE CriteriaFieldName = 'COMMENTS') A
	 ORDER BY SeqNumber
END
GO
--EXEC corp.GetOverrideFieldAttributes 'FACILITY'
 