USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spDealaggreegatePostWFData') IS NOT NULL
	DROP PROC cw.spDealaggreegatePostWFData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*--====================================================================
 * Author: Ravindra Singh
 * Date: 10-11-2021   
 * Description: This will return the PostWaterfall Data for excel report
 * EXEC cw.spDealaggreegatePostWFData '2022-11-30','DUNMORE1','bhasaaa' 	
 * EXEC cw.spDealaggreegatePostWFData '2022-01-31','DEIMOS','bhasaaa' 	
--==================================================================== */
CREATE PROCEDURE cw.spDealaggreegatePostWFData @pAsAtDate datetime,
 @pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY

	DECLARE @PreviousIPDCollectionBusinessEnd varchar(40)
		,@collectionBusinessStart varchar(40)
		,@collectionBusinessEnd varchar(40)
		,@ipdMinus1BusinessDay varchar(40)
		,@nextCollectionStartDate varchar(40)
		,@HolidayCount varchar(40)
		,@sfpRevAdjustment DECIMAL(38, 18)
		,@sfpPrinAdjustment DECIMAL(38, 18),
		@dealIpdRunId  INT,  
        @dealId    SMALLINT,  
		@dealName VARCHAR(20),
        @ipdDate   DATETIME,  
        @dealIpdRunVersion SMALLINT  

		SELECT   
	  @dealIpdRunId = dir.DealIpdRunId  
	  , @dealId = dir.DealId  
	  , @dealName =dir.dealName
	  , @ipdDate = ipddate  
	  , @dealIpdRunVersion = DealIpdRunVersion
	  ,@collectionBusinessStart = dt.CollectionBusinessStart
	  ,@collectionBusinessEnd = dt.CollectionBusinessEnd
		,@ipdMinus1BusinessDay = dt.[IPD-1BusinessDay]
		,@ipdDate = dt.IPD
	 FROM cw.vwDealIpdDates dt  
	 INNER JOIN cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId AND dir.DealId = dt.DealId  
	 WHERE  dir.InternalDealName = @pDealName  AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)   

		--Todo -- Need to change and pick the value from view cw.vwDealIpdDates
	SELECT @nextCollectionStartDate = CONVERT(varchar,DATEADD(MONTH, - 1, DATEADD(DAY, 1, EOMONTH(@ipdDate))), 23)



	
	--Deal Aggregated Data Start

		SELECT
 		   CAST(CorrelatedDate AS DATE) AS MonthEndDate,
		   @dealName AS DealName,
		   LoanBalance,	
		   ISNULL(agd.LoanCount,'-') AS LoanCount,	
		   agf.Description
		   FROM cw.DealAggregatedData agd
	JOIN cfgCW.DealAggregatedField agf
		ON agd.DealAggregatedFieldId =agf.DealAggregatedFieldId
		WHERE agd.DealId = @DealId
		AND CAST(CorrelatedDate AS DATE) =CAST(@collectionBusinessEnd AS DATE)
		--AND @collectionBusinessEnd
		
		AND FieldName IN ('TotalMortgageCapitalBalanceCF', 'mortgagesize')

	ORDER BY CorrelatedDate,agf.Description DESC
	--Deal Aggregated Data End
	 
	 

END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cw.spDealaggreegatePostWFData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO