USE [SFP_Securitisation]

GO


IF OBJECT_ID('[cw].[spGetDailyCollectionDateListEstimation]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDailyCollectionDateListEstimation]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--/*  
--Author: Ravindra Singh  
--Date:    31.10.2022  
--Description:  This will return latest 5 dates status based on date passed.  
--Usage : [cw].[spGetDailyCollectionDateListEstimation]  '2022-05-31','Dunmore1'        
--go
/*
    Declare @dates  [cw].[utdDateList]
	Insert @dates ([dates]) values ('29-Nov-2022')
	Insert @dates ([dates]) values ('28-Nov-2022')
	Insert @dates ([dates]) values ('25-Nov-2022')
	Insert @dates ([dates]) values ('24-Nov-2022')
	Insert @dates ([dates]) values ('23-Nov-2022')
	
	exec cw.spGetDailyCollectionDateListEstimation @pCollectionDates = @dates, @pDealName='Deimos',  @pUserName = 'kumavnb'   
--Change History  
----------------  
--Author              Date                 Description  
---------------------------------------------------------  
--*/  

CREATE PROCEDURE [cw].[spGetDailyCollectionDateListEstimation]    
   @pCollectionDates [cw].[utdDateList] ReadOnly
  ,@pDealName VARCHAR(255)
  ,@pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
BEGIN TRY  
    DECLARE 
   		    @dailyCollectionSummaryId	INT,
		 	@dealId				INT,
			@dealRegionCode VARCHAR(10);  

			

	 		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  
	
			Select ISNULL(IsEstimationData,'false') as IsEstimationData
			FROM @pCollectionDates dt
			LEFT JOIN [CW].[DailyCollectionSummary]  dcs on dcs.CollectionDate = dt.dates 
			and dcs.dealId=@dealId

END TRY
		BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionDateListEstimation', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH

END

GO