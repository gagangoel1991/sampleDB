USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spLoadDeimosExtraFieldAggrData]') IS NOT NULL 
	DROP PROCEDURE [cb].[spLoadDeimosExtraFieldAggrData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spLoadDeimosExtraFieldAggrData]
/*
 * Author: Kapil Sharma
 * Date:	21.02.2022
 * Description:  This will Load the additional deimos deal aggregated fields
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * Usages:
 * [cb].[spLoadDeimosExtraFieldAggrData] 6, '2021-05-28'
 * 
 * SELECT * FROM [cw].[DealAggregatedDataStg]
 * 
 * truncate table [cw].[DealAggregatedDataStg]
 * -------------------------------------------------------
*/
(  
	@pDealId					INT,
	@pVintageDate				DATETIME
)  
AS   
BEGIN   

    DECLARE 
        @mortgageDealId						INT,
        @fromCollectionDate					DATETIME,
		@toCollectionDate					DATETIME,
		@partitionId						INT,
		@aggregatedFieldId					SMALLINT,
		@aggregatedFieldId1					SMALLINT,
		@prevMonthCorrelatedDate			DATETIME,
		@prev2MonthCorrelatedDate			DATETIME,
		@dailyColFieldName					VARCHAR(100),
		@value1								DECIMAL(38,16),
		@value2								DECIMAL(38,16),
		@dealRegionCode						VARCHAR(10),
		@loanCount							INT,
		@dealPoolTotal						DECIMAL(38,16)

	BEGIN TRY  
	
		--As batch will be run on first day of each month for prev month
		SET @toCollectionDate = @pVintageDate
		
		--check temp table if exists
		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult_Deimos') IS NOT NULL DROP TABLE #tmpMortgageLoanResult_Deimos
		
		SELECT * INTO #tmpMortgageLoanResult_Deimos FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1
		
		SELECT DISTINCT @mortgageDealId = MortgageDealId, @dealRegionCode = DealRegionCode FROM [cw].[vw_ActiveDeal] WHERE DealId = @pDealId
  
		--Get the partition id, and last working date of the month
		SET @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), @pVintageDate, 112)) 

		---Get the first working day of the month
		SELECT 
			TOP 1 @fromCollectionDate = AsAtDate
		FROM 
			sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			Month = Month(@pVintageDate) AND year = Year(@pVintageDate)  
			AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
		ORDER BY	
			AsAtDate ASC  

		-----(Previous-1) month last business date i.e. if we are fetching data for May 2020 then we need the last business day of Apr2020
		SELECT 
			TOP 1 @prevMonthCorrelatedDate =  AsAtDate
		FROM 
			sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			Month = Month(DATEADD(DD,1 ,EOMONTH(@pVintageDate,-2))) AND year = Year(DATEADD(DD,1 ,EOMONTH(@pVintageDate,-2)))  
			AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
		ORDER BY	
			AsAtDate DESC

		-----(Previous-2) month last business date i.e. if we are fetching data for May 2020 then we need the last business day of Apr2020
		SELECT 
			TOP 1 @prev2MonthCorrelatedDate =  AsAtDate
		FROM 
			sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			Month = Month(DATEADD(DD,1 ,EOMONTH(@pVintageDate,-3))) AND year = Year(DATEADD(DD,1 ,EOMONTH(@pVintageDate,-3))) 
			AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
		ORDER BY	
			AsAtDate DESC

		PRINT 'Step 1'
		PRINT '@vintageDate'
		PRINT @pVintageDate
		PRINT '@mortgageDealId'
		PRINT @mortgageDealId
		--Checking and loading the mortgage field data into the base table from SFP
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @pVintageDate, @mortgageDealId
		INSERT INTO #tmpMortgageLoanResult_Deimos   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @mortgageDealId
		PRINT 'Step 2'
		--Set the toal loan count and deal pool total
		SELECT @loanCount = COUNT(*) FROM #tmpMortgageLoanResult_Deimos
		SELECT @dealPoolTotal = SUM(ISNULL(OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) FROM #tmpMortgageLoanResult_Deimos
		
		----Data on Mortgage Level
		IF OBJECT_ID('tempdb..#tmpAggr_Deimos') IS NOT NULL DROP TABLE #tmpAggr_Deimos
		SELECT LOAN_IDENTIFIER, SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT) AS OUTSTANDNG_CAPITAL_BALANCE_AMT, MAX(MONTHS_IN_ARREARS) AS MONTHS_IN_ARREARS, MAX(PCT_CHANGE_IN_INDEX) AS PCT_CHANGE_IN_INDEX,
		MAX(INDEXED_LTV) INDEXED_LTV
		INTO #tmpAggr_Deimos  FROM #tmpMortgageLoanResult_Deimos GROUP BY LOAN_IDENTIFIER

		SET @aggregatedFieldId = NULL;
		SET @value1 = 0;
		SET @value2 = 0;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'ArrearsAdjustedCapitalBalance' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			SELECT [MortgageSubAccountKey]		
             , CASE WHEN MONTHS_IN_ARREARS < 3 THEN CASE WHEN OUTSTANDNG_CAPITAL_BALANCE_AMT < PCT_CHANGE_IN_INDEX * 0.75 THEN OUTSTANDNG_CAPITAL_BALANCE_AMT		
                                                                ELSE PCT_CHANGE_IN_INDEX * 0.75		
                                                        END		
               ELSE CASE WHEN PCT_CHANGE_IN_INDEX * 0.4 < OUTSTANDNG_CAPITAL_BALANCE_AMT THEN PCT_CHANGE_IN_INDEX * 0.4		
						ELSE OUTSTANDNG_CAPITAL_BALANCE_AMT		
					END		
               END AS 'HaircutMorethan75'		
             , CASE		
                   WHEN MONTHS_IN_ARREARS < 3 THEN CASE	WHEN OUTSTANDNG_CAPITAL_BALANCE_AMT < PCT_CHANGE_IN_INDEX THEN OUTSTANDNG_CAPITAL_BALANCE_AMT		
                                                        ELSE PCT_CHANGE_IN_INDEX		
                                                    END		
               ELSE CASE WHEN PCT_CHANGE_IN_INDEX * 0.4 < OUTSTANDNG_CAPITAL_BALANCE_AMT THEN PCT_CHANGE_IN_INDEX * 0.4		
						ELSE OUTSTANDNG_CAPITAL_BALANCE_AMT		
					END		
               END AS 'IndexValuationCalc'		
			INTO #tmpHaircutAndIndexCal		
			FROM   
				#tmpMortgageLoanResult_Deimos	
		
			 --Loans where Indexed Valuation < True Balance (Total Outstanding Capital Balance to be used going forward)		
			SELECT   @value1 = ISNULL(@dealPoolTotal, 0) -		
			(		
				SELECT SUM(ISNULL(IndexValuationCalc, 0))		
				FROM   #tmpHaircutAndIndexCal		
			);		
		
			--Haircut for Over 75 % Indexed LTV cases		
			SELECT   @value2 = ISNULL(@dealPoolTotal, 0) -		
			(		
				SELECT SUM(ISNULL(HaircutMorethan75, 0))		
				FROM   #tmpHaircutAndIndexCal		
			);	

			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, (@dealPoolTotal - ISNULL(@value2, 0))  AS LoanBalance, NULL, NULL, NULL, NULL 

			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'ArrearsAdjustedCapitalBalancePreAssetPercentage' AND DealId = @pDealId
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, (@dealPoolTotal - ISNULL(@value1, 0))  AS LoanBalance, NULL, NULL, NULL, NULL 
		END
		PRINT 'step-3'
		--TopUp_Cumulative
		SET @dailyColFieldName = 'TopupBalance'
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'TopUpCurrent' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId,  SUM(CAST(dc.DailyCollectionValue AS DECIMAL(38, 16))) AS LoanBalance, NULL, NULL, NULL, NULL 
			FROM 
				cw.vwDailyCollection dc
			WHERE 
				dc.DailyCollectionFieldColumnName = @dailyColFieldName 
				AND dc.DailyCollectionFieldDealId = @pDealId
				AND CAST(dc.CollectionDate AS DATE) >= CAST(@fromCollectionDate AS DATE) 
				AND CAST(dc.CollectionDate AS DATE) <= CAST(@toCollectionDate AS DATE)
		END

		--AdjustedCapitalBalance
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AdjustedCapitalBalance' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, 
				SUM(ISNULL(CASE WHEN OUTSTANDNG_CAPITAL_BALANCE_AMT<=0 THEN 0 ELSE CASE WHEN INDEXED_LTV>80 THEN CAST(PCT_CHANGE_IN_INDEX*0.800 AS FLOAT) ELSE OUTSTANDNG_CAPITAL_BALANCE_AMT END END, 0))  AS LoanBalance, 
				NULL, NULL, NULL, NULL 
			FROM 
				#tmpAggr_Deimos tmp
		END
		PRINT 'AmortisationTrueBalance'
		--AmortisationTrueBalance
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AmortisationTrueBalance' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			
			ALTER TABLE #tmpAggr_Deimos ADD AmortisationTrueBalance1 DECIMAL(19,2)
			ALTER TABLE #tmpAggr_Deimos ADD AmortisationTrueBalance2 DECIMAL(19,2)	
			
			UPDATE #tmpAggr_Deimos SET AmortisationTrueBalance1 = CASE WHEN MONTHS_IN_ARREARS<=3 THEN OUTSTANDNG_CAPITAL_BALANCE_AMT ELSE CASE WHEN MONTHS_IN_ARREARS>3 THEN OUTSTANDNG_CAPITAL_BALANCE_AMT*0.70 ELSE 0 END END
			UPDATE #tmpAggr_Deimos SET AmortisationTrueBalance2 = CASE WHEN MONTHS_IN_ARREARS<=3 THEN PCT_CHANGE_IN_INDEX ELSE CASE WHEN MONTHS_IN_ARREARS>3 THEN PCT_CHANGE_IN_INDEX*0.70 ELSE 0 END END

			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, SUM(ISNULL(IIF(AmortisationTrueBalance1>AmortisationTrueBalance2, AmortisationTrueBalance2, AmortisationTrueBalance1), 0)),
				NULL, NULL, NULL, NULL 
			FROM 
				#tmpAggr_Deimos tmp
			
		END

		--CapitalBalanceGT0
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'CapitalBalanceGT0' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, 
				SUM(CASE WHEN OUTSTANDNG_CAPITAL_BALANCE_AMT<=0 THEN 0 ELSE OUTSTANDNG_CAPITAL_BALANCE_AMT END)  AS LoanBalance, NULL, NULL, NULL, NULL 
			FROM 
				#tmpAggr_Deimos tmp
		END

		--MonthlyCDR, QuarterlyCDR and AnnualisedCDR will be set to default value as 0
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'MonthlyCDR' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, 0 AS LoanBalance, NULL, NULL, NULL, NULL 
		END

		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'QuarterlyCDR' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, 0 AS LoanBalance, NULL, NULL, NULL, NULL 
		END

		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AnnualisedCDR' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, 0 AS LoanBalance, NULL, NULL, NULL, NULL 
		END
		
		--SetOffPercentage_Biannual
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'SetOffPercentage_Biannual' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			SELECT @aggregatedFieldId1 = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'SetOffPercentage_Moodys' AND DealId = @pDealId
			SET @value1 = 0;
			IF MONTH(@pVintageDate) IN (6, 12)
			BEGIN
				SELECT @value1 = LoanBalance FROM #tmpAggregatedData 
				WHERE CorrelatedDate = @pVintageDate AND FieldId = @aggregatedFieldId1 AND DealId = @pDealId
			END
			ELSE
			BEGIN
				SELECT @value1 = dad.LoanBalance FROM cw.DealAggregatedData dad
				WHERE dad.CorrelatedDate = @prevMonthCorrelatedDate
				AND dad.DealAggregatedFieldId = @aggregatedFieldId
				AND dad.DealId = @pDealId
			END

			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, @value1  AS LoanBalance, NULL, NULL, NULL, NULL 
		END

		--Monthly PPR
		SET @aggregatedFieldId = NULL;
		SET @value1 =0
		SET @value2 =0
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'MonthlyPPR' AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			DECLARE
				@totalMortgageCapitalBalanceBF	DECIMAL(36, 16),
				@monthlyPPR						DECIMAL(36, 16)

			SELECT @aggregatedFieldId1 = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'TotalMortgageCapitalBalanceBF' AND DealId = @pDealId
			SELECT @totalMortgageCapitalBalanceBF = LoanBalance FROM #tmpAggregatedData 
			WHERE CorrelatedDate = @pVintageDate AND FieldId = @aggregatedFieldId1 AND DealId = @pDealId

			SELECT @value1 = SUM(CASE WHEN dcf.Columnname ='PrincipalReceipts' THEN ABS(CAST(dc.Value AS FLOAT)) ELSE CAST(dc.Value AS FLOAT) END) FROM cw.dailycollection dc
			JOIN cfgcw.DailyCollectionField dcf ON dcf.DailyCollectionFieldId = dc.DailyCollectionFieldId
			WHERE dc.CollectionDate>= @fromCollectionDate AND  dc.CollectionDate<= @toCollectionDate 
			AND dcf.Columnname IN ('PrincipalReceipts', 'OtherPrincipalMovements', 'FeesChargedCapitalised', 'ScheduledPrincipalReductions')
			AND dcf.DealId = @pDealId

			SET @value2 = (1- POWER(CAST((1-CAST(@value1 AS FLOAT)/@totalMortgageCapitalBalanceBF) AS FLOAT), 12.00))
			SET @monthlyPPR = (1-POWER((1-@value2), 1/12.0))

			--Monthly PPR
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT 
				@pVintageDate, @pDealId, @aggregatedFieldId, @monthlyPPR AS LoanBalance, NULL, NULL, NULL, NULL 
			
			--Annualised PPR
			SET @aggregatedFieldId = NULL
			SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AnnualisedPPR' AND DealId = @pDealId
			IF @aggregatedFieldId IS NOT NULL
			BEGIN
				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@pVintageDate, @pDealId, @aggregatedFieldId, @value2 AS LoanBalance, NULL, NULL, NULL, NULL 
			END

			---Quarterly PPR
			SET @aggregatedFieldId1 = NULL
			SET @value1 = 0
			SELECT @aggregatedFieldId1 = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'QuarterlyPPR' AND DealId = @pDealId
			IF @aggregatedFieldId1 IS NOT NULL
			BEGIN
				SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName = 'AnnualisedPPR' AND DealId = @pDealId
				SELECT @value1 = SUM(ISNULL(dad.LoanBalance, 0)) FROM cw.DealAggregatedData dad
				WHERE dad.CorrelatedDate IN (@prevMonthCorrelatedDate, @prev2MonthCorrelatedDate)
				AND dad.DealAggregatedFieldId = @aggregatedFieldId
				AND dad.DealId = @pDealId

				INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
				SELECT 
					@pVintageDate, @pDealId, @aggregatedFieldId1, CAST((ISNULL(@value2, 0) + ISNULL(@value1, 0)) AS FLOAT)/3.00  AS LoanBalance, NULL, NULL, NULL, NULL 
			END
		END

		IF OBJECT_ID('tempdb..#TBLProduct') IS NOT NULL DROP TABLE #TBLProduct
				
		SELECT PRODUCT, sum(OUTSTANDNG_CAPITAL_BALANCE_AMT)  AS SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT
		,  sum(OUTSTANDNG_CAPITAL_BALANCE_AMT * CURRENT_INTEREST_RATE) AS CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT
		INTO #TBLProduct
		FROM #tmpMortgageLoanResult
		WHERE MONTHS_IN_ARREARS <3
		AND OUTSTANDNG_CAPITAL_BALANCE_AMT >0
		AND MATURITY_DATE> BUSINESS_DATE 
		--AND PROCESS_STATUS =2
		GROUP BY PRODUCT
				
				
		SET @dailyColFieldName = 'SVRSwap'
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= @dailyColFieldName AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT  @pVintageDate, @pDealId, @aggregatedFieldId, CAST(sum(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(38,24)) , NULL, NULL
			, sum(CAST(CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT AS DECIMAL(38,24)))  / sum(CAST(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT AS DECIMAL(38,4)) ), NULL
			FROM #TBLProduct
			WHERE Product = 'SVR'
		END

		SET @dailyColFieldName = 'TrackerSwap'
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= @dailyColFieldName AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT @pVintageDate, @pDealId, @aggregatedFieldId, CAST(sum(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(38,24)) , NULL, NULL
			, sum(CAST(CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT AS DECIMAL(38,24)))  / sum(CAST(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT AS DECIMAL(38,4)) ), NULL
			FROM #TBLProduct
			WHERE Product IN ('TRACKER', 'LIFETIMETRACKER' )
		END

		SET @dailyColFieldName = 'FixedSwap'
		SET @aggregatedFieldId = NULL;
		SELECT @aggregatedFieldId = DealAggregatedFieldId FROM cfgCW.DealAggregatedField WHERE FieldName= @dailyColFieldName AND DealId = @pDealId
		IF @aggregatedFieldId IS NOT NULL
		BEGIN
			INSERT INTO #tmpAggregatedData (CorrelatedDate, DealId, FieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
			SELECT @pVintageDate, @pDealId, @aggregatedFieldId, CAST(sum(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT) AS DECIMAL(38,24)) , NULL, NULL
			, sum(CAST(CURRENT_INTEREST_RATE_CAPITAL_BALANCE_AMT AS DECIMAL(38,24)))  / sum(CAST(SUM_OUTSTANDNG_CAPITAL_BALANCE_AMT AS DECIMAL(38,4)) ), NULL
			FROM #TBLProduct
			WHERE Product IN ('FIXED', 'LIFETIMEFIXED' )
		END


		PRINT 'Inserting the data into DealAggregatedDataStg - Deimos'
		--Inserting data into stage table		
		INSERT INTO [cw].[DealAggregatedDataStg](CorrelatedDate, DealId, DealAggregatedFieldId, LoanBalance, MinBalance, MaxBalance, WeightedAvgBalance, LoanCount)
		SELECT CorrelatedDate, DealId, FieldId, ISNULL(LoanBalance, 0), MinBalance, MaxBalance, WeightedAvgBalance, LoanCount FROM #tmpAggregatedData

		PRINT 'Completed............'

		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult_Deimos') IS NOT NULL DROP TABLE #tmpMortgageLoanResult_Deimos
		IF OBJECT_ID('tempdb..#tmpAggr_Deimos') IS NOT NULL DROP TABLE #tmpAggr_Deimos

	END TRY  

	BEGIN CATCH   
		
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  

		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  

		EXEC app.SaveErrorLog 1, 1, 'cb.spLoadDeimosExtraFieldAggrData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
		, 'System'  

		RAISERROR (@errorMessage,  
		@errorSeverity,  
		@errorState )  

	END CATCH  

END
GO