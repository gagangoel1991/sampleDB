USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetEmploymentStatus') IS NOT NULL
	DROP PROC CW.spGetEmploymentStatus;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:    01.06.2020
 * Description:  This will return Employment Status for Investor report.
 * Usage : CW.spGetEmploymentStatus @pAsAtDate  ='30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetEmploymentStatus @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY  
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
				
				
BEGIN TRY

	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	 , @totalNumberofSubAccounts float
	 , @totalOutstandingCapitalBalance float
	 , @totalTrueBalance float

	SELECT @totalNumberofSubAccounts = COUNT(ISNULL(VMS.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(VMS.TotalOutstandingCapitalBalance, 0)) 
		, @totalTrueBalance  = SUM(ISNULL(VMS.TrueBalance, 0)) 
	FROM CW.VwMortgageSubAccount VMS
	WHERE PartitionID = (@partitionID_AsAtDate)  
		AND DealName = @pDealName  
	GROUP BY MortgageDealKey, BusinessDate 

	/* Check with Aditya */
	SELECT  RLD.ReportValue AS EmploymentType, DealName, MortgageDealKey, BusinessDate , VMS.MortgageSubAccountKey, TotalOutstandingCapitalBalance , TrueBalance
	INTO #temp
	FROM CW.VwMortgageSubAccount VMS
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeCustomerSubAccountGroup h ON h.customersubaccountgroupkey = VMS.customersubaccountgroupkey  
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeCustomerSubAccount csa ON h.customersubaccountkey = csa.customersubaccountkey AND csa.HolderPosition = 1  
	INNER JOIN sfp.syn_SfpModel_tbl_Customer c ON csa.Customerkey = c.customerkey  
	LEFT JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 RLD ON  c.EmploymentType = RLD.LookUpValue  AND RLD.LookUpName = 'EmploymentType'
		AND RLD.LookUpName = 'EmploymentType'  AND RLD.ReportTemplateName = 'INVESTOR'   
	WHERE PartitionID = @partitionID_AsAtDate  
	AND DealName = @pDealName  
	
	
	SELECT isNull(EmploymentType,'')  'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalNumberofSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Float) , 0) 'TotalOutCapitalBalance' 
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent  
	, ISNULL(CAST(sum(TrueBalance) AS Float) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) * 100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0)  TrueBalancePercent  
	FROM #temp
	GROUP BY EmploymentType

	
	
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetEmploymentStatus', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			

END

GO
