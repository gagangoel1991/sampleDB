USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculatePrincipalWaterfallPayment') IS NOT NULL
	DROP PROCEDURE cw.spCalculatePrincipalWaterfallPayment
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculatePrincipalWaterfallPayment(
@pDealIpdRunId INT, 
@pUserName	VARCHAR(80)
/* 
 * Author: Aditya Shrivastava 
 * Date:  07.07.2020 
 * Description:  Calculate principal waterfall payment 
 *      
 * Change History 
 * -------------- 
 * Author    Date    Description 
 * ------------------------------------------------------- 
 * AS      31.03.2021    Commented sourceid while inserting into waterfall payment summary in the end
 * 
 * exec cw.spCalculatePrincipalWaterfallPayment 2,'fm\shriyad' 
 * 
 * exec cw.spCalculatePrincipalWaterfallPayment 3,'fm\shriyad'
 * 
*/ 
) 
AS 
  BEGIN 

  
	SET NOCOUNT ON

	DECLARE @Message VARCHAR(4000)

	BEGIN TRY
      --declare  
      -- @pDealIpdRunId int=3
      --,@pUserName varchar(20)='fm\shriyad'; 

	  DECLARE @dealId  SMALLINT
		SELECT @dealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId

      IF( Object_id('tempdb..#temp') IS NOT NULL ) 
        DROP TABLE #temp 

      IF( Object_id('tempdb..#tempAvailableSourceType') IS NOT NULL ) 
        DROP TABLE #tempAvailableSourceType 

      CREATE TABLE #tempAvailableSourceType 
        ( SourceType VARCHAR(200) ) 

      INSERT INTO #tempAvailableSourceType (SourceType) 
      VALUES     ('PostAvailablePrincipalReceipts') 

      CREATE TABLE #temp 
        ( 
           Id                       INT, 
           DealId                   INT, 
           CategoryName             VARCHAR(500), 
           DisplayName              VARCHAR(500), 
           SourceId                 INT, 
           SourceName               VARCHAR(200), 
           Priority                 INT, 
           WaterfallExpressionValue DECIMAL(38, 16), 
           SourceExpressionValue    DECIMAL(38, 16), 
           FormatType               VARCHAR(500), 
           Sortorder                DECIMAL(38, 16) 
        ) 

     

	  INSERT INTO #temp
	SELECT wli.WaterfallLineItemId Id, 
             wc.DealId, 
             wc.DisplayName          CategoryName, 
             wli.DisplayName, 
             ws.WaterfallSourceId    AS SourceId, 
             ws.SourceName, 
             ws.Priority, 
			 wlia.WaterfallLineItemTotalRequiredAmount	AS WaterfallExpressionValue,
			 ev.Value					AS SourceExpressionValue,
             wli.FormatType, 
             wli.Sortorder  
			FROM   cfgcw.WaterfallLineItem wli 
             JOIN cfgcw.WaterfallCategory wc 
               ON wli.WaterfallCategoryId = wc.WaterfallCategoryId 
             JOIN cw.vwDealIpdRun dir 
               ON dir.DealId = wc.DealId 
			JOIN cw.vwWaterfallLineItemAmount wlia
				ON wli.WaterfallLineItemId=wlia.WaterfallLineItemId AND dir.DealIpdRunId=wlia.DealIpdRunId
            JOIN  cfgcw.WaterfallSource ws ON dir.DealId = ws.DealId 
                  AND dir.DealIpdRunId=@pDealIpdRunId
          --   JOIN cw.vwDealIpdRun dir1 
               
			JOIN #tempAvailableSourceType temp
				ON ws.SourceType=temp.SourceType
             LEFT JOIN cw.ExpressionValue ev
                    ON ws.ExpressionId = ev.ExpressionId 
					AND dir.DealIpdRunId=ev.DealIpdRunId
      WHERE  wc.InternalName = 'PrincipalPriorityofPayments' 
             AND wli.isactive = 1 
             AND ws.DealId = wc.DealId 
			AND dir.DealIpdRunId=@pDealIpdRunId
      ORDER  BY 
	  ws.Priority, 
                wli.Sortorder

				-- update post principal receipts amount from wlia
	IF( Object_id('tempdb..#tempPostAvailablePrincipalReceipts') IS NOT NULL ) 
        DROP TABLE #tempPostAvailablePrincipalReceipts 

	SELECT ws.WaterfallSourceId, TotalRequiredAmount 
	INTO #tempPostAvailablePrincipalReceipts
	FROM cfgcw.WaterfallCategory wc 
	JOIN cfgcw.WaterfallLineItem wli ON wli.WaterfallCategoryId = wc.WaterfallCategoryId AND WLI.WaterfallLineItemOperatorInTotal IS NULL
	JOIN cfgcw.WaterfallSource ws ON ws.SourceType = wc.InternalName AND ws.DealId = wc.DealId
	JOIN cw.vwdealipdrun dir ON dir.dealid = wc.dealid AND iscurrentipd=1 AND IsCurrentVersion = 1
	JOIN cw.waterfallLineitemAmount wlia ON wlia.WaterfallLineItemId = wli.WaterfallLineItemId AND dir.DealIpdRunId = wlia.DealIpdRunId
	WHERE wc.InternalName='PostAvailablePrincipalReceipts'
	AND wc.dealid=@dealId

	UPDATE #temp
	SET SourceExpressionValue = #tempPostAvailablePrincipalReceipts.TotalRequiredAmount
	FROM #temp,#tempPostAvailablePrincipalReceipts
	WHERE #temp.sourceid = #tempPostAvailablePrincipalReceipts.WaterfallSourceId


      --select * from #temp order by Priority,Sortorder 
      IF( Object_id('tempdb..#TblCalculate') IS NOT NULL ) 
        DROP TABLE #TblCalculate 

      IF( Object_id('tempdb..#tempSourceTbl') IS NOT NULL ) 
        DROP TABLE #tempSourceTbl 

      IF( Object_id('tempdb..#calculatedSourceTbl') IS NOT NULL ) 
        DROP TABLE #calculatedSourceTbl 

      CREATE TABLE #TblCalculate 
        ( 
           rowNum                INT, 
           DisplayName           VARCHAR(2000),-- tbdel 
           WaterfallLineItemId   INT, 
           TotaldueAmount        DECIMAL(38, 16), 
           SourceTotalAmount     DECIMAL(38, 16), 
           SourceId              INT, 
           SourceName            VARCHAR(200), 
           Priority              INT, 
           IsEligible            BIT, 
           SortOrder             DECIMAL(38, 16), 
           SourceCurrentAmount   DECIMAL(38, 16), 
           DueAmount             DECIMAL(38, 16), 
           AmountPaidFromSource  DECIMAL(38, 16), 
           SourceRemainingAmount DECIMAL(38, 16), 
           TotalPaidAmount       DECIMAL(38, 16), 
           RemainingDueAmount    DECIMAL(38, 16) 
        ) 

      CREATE TABLE #tempSourceTbl 
        ( 
           rowNum                INT, 
           DisplayName           VARCHAR(2000),-- tbdel 
           WaterfallLineItemId   INT, 
           TotaldueAmount        DECIMAL(38, 16), 
           SourceTotalAmount     DECIMAL(38, 16), 
           SourceId              INT, 
           SourceName            VARCHAR(200), 
           Priority              INT, 
           IsEligible            BIT, 
           SortOrder             DECIMAL(38, 16), 
           SourceCurrentAmount   DECIMAL(38, 16), 
           DueAmount             DECIMAL(38, 16), 
           AmountPaidFromSource  DECIMAL(38, 16), 
           SourceRemainingAmount DECIMAL(38, 16), 
           TotalPaidAmount       DECIMAL(38, 16), 
           RemainingDueAmount    DECIMAL(38, 16) 
        ) 

      CREATE TABLE #calculatedSourceTbl 
        ( 
           rowNum                INT, 
           DisplayName           VARCHAR(2000),-- tbdel 
           WaterfallLineItemId   INT, 
           TotaldueAmount        DECIMAL(38, 16), 
           SourceTotalAmount     DECIMAL(38, 16), 
           SourceId              INT, 
           SourceName            VARCHAR(200), 
           Priority              INT, 
           IsEligible            BIT, 
           SortOrder             DECIMAL(38, 16), 
           SourceCurrentAmount   DECIMAL(38, 16), 
           DueAmount             DECIMAL(38, 16), 
           AmountPaidFromSource  DECIMAL(38, 16), 
           SourceRemainingAmount DECIMAL(38, 16), 
           TotalPaidAmount       DECIMAL(38, 16), 
           RemainingDueAmount    DECIMAL(38, 16) 
        ) 

      INSERT INTO #TblCalculate 
      SELECT row_number() 
               OVER( 
                 ORDER BY SourceId ASC, t.SortOrder ASC, eligiblewaterfallsourceid DESC) rowNum,
             wli.DisplayName, 
             t.id                                                                        AS WaterfallLineItemId,
             WaterfallExpressionValue                                                    AS TotaldueAmount,
             SourceExpressionValue                                                       AS SourceTotalAmount,
             SourceId                                                                    AS SourceId,
             SourceName, 
             Priority, 
             CASE 
               WHEN EligibleWaterfallSourceId IS NULL THEN 0 
               ELSE 1 
             END                                                                         AS IsEligible,
             t.SortOrder, 
             0.0                                                                         AS SourceCurrentAmount,
             0.0                                                                         AS DueAmount,
             0.0                                                                         AS AmountPaidFromSource,
             0.0                                                                         AS SourceRemainingAmount,
             0.0                                                                         AS TotalPaidAmount,
             0.0                                                                         AS RemainingDueAmount
      FROM   #temp t 
             LEFT JOIN cfgcw.WaterfallSourceEligibility wse 
                    ON t.SourceId = wse.EligibleWaterfallSourceId 
                       AND t.id = wse.WaterfallLineItemId 
             LEFT JOIN cfgcw.WaterfallLineItem wli 
                    ON wli.WaterfallLineItemId = t.Id 
      ORDER  BY Priority ASC, 
                SortOrder ASC, 
                EligibleWaterfallSourceId DESC 

      --select * from #TblCalculate order by Priority asc,SortOrder asc 
      DECLARE @tempId                         INT, 
              @previousId                     INT, 
              @sourceRemainingAmount_Priority DECIMAL(38, 16); 
      DECLARE @previousWaterfallSourcePriority DECIMAL(9, 3), 
              @previousWaterfallSourceId       INT, 
              @isEligible                      BIT; 
      DECLARE @waterfallSourcePriority DECIMAL(9, 3) =(SELECT TOP 1 priority 
        FROM   cfgCW.WaterfallSource ws, 
               #tempAvailableSourceType tast 
        WHERE  tast.SourceType = ws.SourceType 
               AND DealId = @dealId 
        ORDER  BY priority); 
      DECLARE @waterfallSourceId INT =(SELECT WaterfallSourceId 
        FROM   cfgCW.WaterfallSource ws 
               JOIN #tempAvailableSourceType tast ON tast.SourceType = ws.SourceType
        WHERE   
               priority = @waterfallSourcePriority 
               AND DealId = @dealId); 
      DECLARE @firstWaterfallSourceId INT =@waterfallSourceId; 

      SET @previousWaterfallSourcePriority =@waterfallSourcePriority; 
      SET @previousWaterfallSourceId =@waterfallSourceId; 

      WHILE ( @waterfallSourceId > 0 ) 
        BEGIN 
            DELETE FROM #tempSourceTbl 

            --putting rows for sourceid to pay from 
            INSERT INTO #tempSourceTbl 
                        (rowNum, 
                         DisplayName -- tbdel 
                         , 
                         WaterfallLineItemId, 
                         TotaldueAmount, 
                         SourceTotalAmount, 
                         SourceId, 
                         SourceName, 
                         Priority, 
                         IsEligible, 
                         SortOrder, 
                         SourceCurrentAmount, 
                         DueAmount, 
                         AmountPaidFromSource, 
                         SourceRemainingAmount, 
                         TotalPaidAmount, 
                         RemainingDueAmount) 
            SELECT rowNum, 
                   DisplayName, -- tbdel 
                   WaterfallLineItemId, 
                   TotaldueAmount, 
                   SourceTotalAmount, 
                   SourceId, 
                   SourceName, 
                   Priority, 
                   IsEligible, 
                   SortOrder, 
                   SourceCurrentAmount, 
                   DueAmount, 
                   AmountPaidFromSource, 
                   SourceRemainingAmount, 
                   TotalPaidAmount, 
                   RemainingDueAmount 
            FROM   #TblCalculate 
            WHERE  SourceId = @waterfallSourceId; 

            --select * from #tempSourceTbl 
            UPDATE #tempSourceTbl 
            SET    SourceCurrentAmount = SourceTotalAmount 

            --select * from #tempSourceTbl 
            --updating dueAmount as TotalDueAmount for prioritySource 1 
            IF( @firstWaterfallSourceId = @waterfallSourceId ) 
              BEGIN 
                  UPDATE #tempSourceTbl 
                  SET    dueAmount = totalDueAMount 
              END 
            ELSE 
              BEGIN 
                  --updating dueAmount as RemainingDueAmount for previous priority waterfall 
                  UPDATE ts 
                  SET    DueAmount = cs.RemainingDueAmount 
                  FROM   #tempSourceTbl ts 
                         JOIN #calculatedSourceTbl cs 
                           ON ts.WaterfallLineItemId = cs.WaterfallLineItemId 
                              AND cs.sourceid = @previousWaterfallSourceId 
              END 

            --select * from #tempSourceTbl 
            DECLARE @tempRowNum INT; 

            SET @tempRowNum =(SELECT TOP 1 rowNum 
                              FROM   #tempSourceTbl 
                              ORDER  BY rowNum ASC) 

            SET @tempId =(SELECT WaterfallLineItemId 
                          FROM   #tempSourceTbl 
                          WHERE  rowNum = @tempRowNum); 

            WHILE( @tempRowNum > 0 ) 
              BEGIN 
                  --print @tempId 
                  SET @isEligible=(SELECT iseligible 
                                   FROM   #tempSourceTbl 
                                   WHERE  WaterfallLineItemId = @tempId); 

                  IF( @isEligible = 1 ) 
                    BEGIN 
                        UPDATE #tempSourceTbl 
                        SET    AmountPaidFromSource = CASE 
                                                        WHEN ( SourceCurrentAmount - DueAmount ) >= 0 THEN DueAmount
                                                        ELSE SourceCurrentAmount 
                                                      END 
                        WHERE  WaterfallLineItemId = @tempId 

                        UPDATE #tempSourceTbl 
                        SET    SourceRemainingAmount = CASE 
                                                         WHEN ( SourceCurrentAmount - AmountPaidFromSource ) >= 0 THEN (
                                                         SourceCurrentAmount - AmountPaidFromSource )
                                                         ELSE SourceCurrentAmount 
                                                       END 
                        WHERE  WaterfallLineItemId = @tempId 
                    END 
                  ELSE 
                    BEGIN 
                        UPDATE #tempSourceTbl 
                        SET    SourceRemainingAmount = SourceCurrentAmount 
                        WHERE  WaterfallLineItemId = @tempId 
                    END 

                  UPDATE #tempSourceTbl 
                  SET    TotalPaidAmount = AmountPaidFromSource 
                                           + COALESCE((SELECT TotalPaidAmount 
														FROM #calculatedSourceTbl 
														WHERE
														WaterfallLineItemId= @tempId 
														AND sourceid=@previousWaterfallSourceId)
											, 0) 
                  WHERE  WaterfallLineItemId = @tempId 

                  UPDATE #tempSourceTbl 
                  SET    RemainingDueAmount = DueAmount - AmountPaidFromSource 
                  WHERE  WaterfallLineItemId = @tempId 

                  --select * from #tempSourceTbl 
                  SET @previousId=@tempId; 
                  SET @tempRowNum =(SELECT TOP 1 rowNum 
                                    FROM   #tempSourceTbl 
                                    WHERE  rowNum > @tempRowNum 
                                    ORDER  BY rowNum ASC) 

                  SET @tempId =(SELECT WaterfallLineItemId 
                                FROM   #tempSourceTbl 
                                WHERE  rowNum = @tempRowNum) 

                  ---if next row exists 
                  IF EXISTS(SELECT * 
                            FROM   #tempSourceTbl 
                            WHERE  WaterfallLineItemId = @tempId) 
                    BEGIN 
                        --select @previousId,@tempId 
                        UPDATE #tempSourceTbl 
                        SET    SourceCurrentAmount = (SELECT SourceRemainingAmount 
                                                      FROM   #tempSourceTbl 
                                                      WHERE  WaterfallLineItemId = @previousId)
                        WHERE  WaterfallLineItemId = @tempId 
                    --select * from #tempSourceTbl 
                    END 
                  ELSE 
                    BEGIN 
                        SELECT @sourceRemainingAmount_Priority = SourceRemainingAmount 
                        FROM   #tempSourceTbl 
                        WHERE  WaterfallLineItemId = @previousId 
                    END 
              END 

            --print 'MESSAGE: '+convert(varchar(max),@waterfallSourceId)+' is paid'; 
            INSERT INTO #calculatedSourceTbl 
            SELECT * 
            FROM   #tempSourceTbl 

            SET @previousWaterfallSourcePriority =@waterfallSourcePriority; 

            SET @previousWaterfallSourceId =@waterfallSourceId; 

            SET @waterfallSourcePriority =(SELECT TOP 1 priority 
                                           FROM   cfgCW.WaterfallSource ws
                                                  JOIN #tempAvailableSourceType tast ON tast.SourceType = ws.SourceType 
                                           WHERE  
                                                  DealId = @dealId 
                                                  AND priority > @waterfallSourcePriority 
                                           ORDER  BY priority); 

            SET @waterfallSourceId =(SELECT WaterfallSourceId 
                                     FROM   cfgCW.WaterfallSource ws
                                            JOIN #tempAvailableSourceType tast ON tast.SourceType = ws.SourceType 
                                     WHERE  
                                            DealId = @dealId 
                                            AND priority = @waterfallSourcePriority); 
        END 

    --  select * from #calculatedSourceTbl
	   
      DELETE FROM cw.PrincipalWaterfallPayment 
      WHERE  DealIpdRunId = @pDealIpdRunId; 

      ---------EligibleRequiredAmount is for principal waterfall as it is using this coloumn 
      INSERT INTO cw.PrincipalWaterfallPayment 
                  (DealIpdRunId, 
                   WaterfallLineItemId, 
                   TotalDueAmount, 
                   SourceTotalAmount, 
                   SourceId, 
                   SourceName, 
                   IsEligible, 
                   Priority, 
                   SortOrder, 
                   SourceCurrentAmount, 
                   DueAmount, 
                   EligibleRequiredAmount, 
                   AmountPaidFromSource, 
                   SourceRemainingAmount, 
                   RemainingDueAmount, 
                   TotalPaidAmount, 
                   CreatedDate, 
                   CreatedBy, 
                   ModifiedDate, 
                   ModifiedBy) 
      SELECT @pDealIpdRunId, 
             WaterfallLineItemId, 
             TotalDueAmount, 
             SourceTotalAmount, 
             SourceId, 
             SourceName, 
             IsEligible, 
             Priority, 
             SortOrder, 
             SourceCurrentAmount, 
             DueAmount, 
             ( IsEligible * DueAmount ) EligibleRequiredAmount, 
             AmountPaidFromSource, 
             SourceRemainingAmount, 
             RemainingDueAmount, 
             TotalPaidAmount, 
             Getdate(), 
             @pUserName, 
             Getdate(), 
             @pUserName 
      FROM   #calculatedSourceTbl 

      DELETE FROM cw.PrincipalWaterfallPaymentSummary 
      WHERE  DealIpdRunId = @pDealIpdRunId; 

      INSERT INTO cw.PrincipalWaterfallPaymentSummary 
                  (WaterfallLineItemId, 
                   DealIpdRunId, 
                   RequiredAmount, 
                   AdjustedAmount, 
                   TotalRequiredAmount, 
                   TotalPaidAmount, 
                   RemainingDueAmount) 
      SELECT wli.WaterfallLineItemId, 
             pwp.DealIpdRunId, 
             pwli.WaterfallLineItemRequiredAmount, 
             pwli.WaterfallLineItemAdjustedAmount, 
             pwli.WaterfallLineItemTotalRequiredAmount, 
             pwp.TotalPaidAmount, 
             pwp.RemainingDueAmount 
      FROM   cw.PrincipalWaterfallPayment pwp
             JOIN cw.vwWaterfallLineItemAmount pwli ON pwli.WaterfallLineItemId = pwp.WaterfallLineItemId 
             JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = pwli.DealIpdRunId 
										AND dir.DealIpdRunId = pwp.DealIpdRunId 
             JOIN cfgcw.WaterfallLineItem wli ON  wli.WaterfallLineItemId = pwli.WaterfallLineItemId 
												AND pwp.WaterfallLineItemId = wli.WaterfallLineItemId 
      WHERE 
			dir.DealIpdRunId = @pDealIpdRunId 
      ORDER  BY wli.Sortorder 

	  
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spCalculatePrincipalWaterfallPayment', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )

		
	END CATCH
  END 

GO 