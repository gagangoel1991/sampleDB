USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetUpstreamDataAuthWorkflowStatus]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetUpstreamDataAuthWorkflowStatus] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

  
--==================================      
--Author: GUNJAN CHANDOLA      
--Date: 09-05-2021     
--Description: mange automated data auth workflow     
--[cw].[spGetUpstreamDataAuthWorkflowStatus] 'Automated_Data_Cash_Ladder',6,1032,''    
--==================================       
CREATE PROCEDURE [cw].[spGetUpstreamDataAuthWorkflowStatus]     
(
   @pWorkflowType   VARCHAR(100),       
   @pDealId			INT,        
   @pIPDRunId		INT,    
   @pUserName		VARCHAR(80)    
)
AS      
BEGIN      
	BEGIN TRY       
		DECLARE 
			@processReferenceId		INT,
			@dealType				VARCHAR(20),
			@dealId					SMALLINT,    
			@businessStartDate		DATE,    
			@businessEndDate		DATE ,  
			@rateDate				DATE,
			@currentIpdDate			DATE,
			@prevIpdDate			DATE,
			@dealRegionCode			VARCHAR(20)
		
		SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))
		SET @processReferenceId=(SELECT [cw].[fnGetWorkflowProcessReferenceId](@pWorkflowType,@pIPDRunId))    
		
		--Getting the dealid, Business Start and End Date for the speciifed run id    
		SELECT     
			@dealId = di.DealId,     
			@businessStartDate = did.CollectionBusinessStart,     
			@businessEndDate = did.CollectionBusinessEnd ,  
			@rateDate = did.[RateResetDate],
			@currentIpdDate = did.Ipd, 
			@prevIpdDate= did.PreviousIPD,
			@dealRegionCode = deal.DealRegionCode
		FROM cw.DealIpd di    
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId    
		JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId    
		WHERE dir.RunId = @pIPDRunId    
    
		IF @pWorkflowType='Automated_Data_Collection_Ledger' --Collection Ledger    
		BEGIN    
			SELECT     
				TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,    
				wfs.WorkflowStepName AS StepName,    
				clw.[Status],    
				wfs.Comment,    
				wfs.ActionedBy AS ActionBy,    
				wfs.ActionedDate AS ActionDate ,    
				clw.CreatedBy ,    
				wfs.WorkflowStepName     
			FROM [cw].[vwWorkFlowLastAction] wfs    
			LEFT JOIN cw.CollectionLedger_WIP clw ON clw.ProcessReferenceId = wfs.ProcessReferenceId    
			WHERE DealId = @dealId AND wfs.WorkflowTypeName = 'Automated_Data_Collection_Ledger'    
			AND CollectionDate>=@businessStartDate AND CollectionDate<=@businessEndDate 
			ORDER BY wfs.ActionedDate DESC    
		END    
		ELSE IF @pWorkflowType='Automated_Data_Daily_Collection' --Daily Collection    
		BEGIN    
			SELECT     
				TOP 1  wfs.WorkflowStepDisplayName AS StepDescription,    
				wfs.WorkflowStepName AS StepName,    
				dcw.[Status],    
				wfs.Comment,    
				wfs.ActionedBy AS ActionBy,    
				wfs.ActionedDate AS ActionDate ,    
				dcw.CreatedBy ,    
				wfs.WorkflowStepName     
			FROM [cw].[vwWorkFlowLastAction] wfs    
			LEFT JOIN cw.DailyCollection_WIP dcw ON dcw.ProcessReferenceId = wfs.ProcessReferenceId    
			WHERE DealId = @dealId AND wfs.WorkflowTypeName = 'Automated_Data_Daily_Collection'    
			AND CollectionDate>=@businessStartDate AND CollectionDate<=@businessEndDate  
			ORDER BY wfs.ActionedDate DESC    
		END    
		ELSE IF @pWorkflowType='Automated_Data_Interest_Rates' --Interest Rates    
		BEGIN    
			DECLARE @tblDealBenchmarkCode AS TABLE(RICCode		VARCHAR(100))

			IF (@dealType='Covered Bond')
			BEGIN
				DECLARE
					@resetLeadDays		INT

				SELECT @resetLeadDays = CAST([Value] AS INT) FROM [cfgcb].[SoniaResetLeadDays] WHERE IsActive = 1
				SELECT @businessStartDate = [CW].[fnGetBusinessDate](@prevIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
				SELECT @businessEndDate = [CW].[fnGetBusinessDate](@currentIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)

				INSERT INTO @tblDealBenchmarkCode(RICCode)
				SELECT DISTINCT dlv.Value AS RicCode FROM cfgcb.DealNote dn1 
				JOIN cb.DealNote_Wf dnDF ON dnDF.DealNoteId = dn1.DealNoteId
				JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = dn1.BenchmarkId
				JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
				WHERE dn1.DealId = @pDealId AND dlt.Name = 'Benchmark' 
			END
			ELSE IF(@dealType='RMBS')
			BEGIN
				INSERT INTO @tblDealBenchmarkCode(RICCode)
				SELECT DISTINCT dlv.Value AS RicCode FROM cfgcw.DealNote dn1 
				JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = dn1.BenchmarkId
				JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
				WHERE dn1.DealId = @pDealId AND dlt.Name = 'Benchmark' 
			END
			
			SELECT     
				TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,    
				wfs.WorkflowStepName AS StepName,    
				irw.[Status],    
				wfs.Comment,    
				irw.CreatedBy,    
				wfs.ActionedBy AS ActionBy,    
				wfs.ActionedDate AS ActionDate     
			FROM [cw].[vwWorkFlowLastAction] wfs    
			LEFT JOIN cw.InterestRate_WIP irw ON irw.ProcessReferenceId = wfs.ProcessReferenceId    
			JOIN cw.InterestRate ir ON irw.InterestRateId = ir.InterestRateId   
			JOIN @tblDealBenchmarkCode dealRC ON ir.RICCode = dealRC.RicCode
			WHERE 
				(
					(@dealType = 'Covered Bond' AND CAST(ir.BaseDate AS DATE)>=@businessStartDate AND CAST(ir.BaseDate AS DATE)<=@businessEndDate)
					OR
					(@dealType = 'RMBS' AND (CAST(ir.BaseDate AS DATE)=CAST(@rateDate AS DATE)))
				)
				AND wfs.WorkflowTypeName = 'Automated_Data_Interest_Rates'    
			ORDER BY wfs.ActionedDate DESC    
		END  
		ELSE IF @pWorkflowType='Automated_Data_Cash_Ladder' --Collection Ledger    
		BEGIN    
			SELECT     
				TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,    
				wfs.WorkflowStepName AS StepName,    
				clw.[Status],    
				wfs.Comment,    
				wfs.ActionedBy AS ActionBy,    
				wfs.ActionedDate AS ActionDate ,    
				clw.CreatedBy ,    
				wfs.WorkflowStepName     
			FROM [cw].[vwWorkFlowLastAction] wfs    
			LEFT JOIN cw.CashLadder_WIP clw ON clw.ProcessReferenceId = wfs.ProcessReferenceId    
			WHERE DealId = @dealId AND wfs.WorkflowTypeName = 'Automated_Data_Cash_Ladder'    
			--AND CollectionDate>=@businessStartDate AND CollectionDate<=@businessEndDate 
			ORDER BY wfs.ActionedDate DESC    
		END  
	END TRY      
	BEGIN CATCH      
		DECLARE       
			@errorMessage     NVARCHAR(MAX),      
			@errorSeverity    INT,      
			@errorNumber      INT,      
			@errorLine        INT,      
			@errorState       INT;      
      
		SELECT       
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()      
      
		EXEC app.SaveErrorLog 1, 1, 'cw.spGetUpstreamDataAuthWorkflowStatus', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName      
        
		RAISERROR (@errorMessage,      
			@errorSeverity,      
			@errorState )      
	END CATCH      
END
GO