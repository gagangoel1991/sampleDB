USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spSaveCashLadderData]') IS NOT NULL
	DROP PROCEDURE [cb].[spSaveCashLadderData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: RAVINDRA SINGH
--Date: 31-01-2022 
--Description:  To insert or update  modified values is
--not authorized 
--==================================   
CREATE PROCEDURE [cb].[spSaveCashLadderData] 
   @pIPDRunId   INT,
   @pCashLadderId   INT,    
   @pRate DECIMAL(38, 18),  
   @pInflowAmount  DECIMAL(38, 18),  
   @pOutflowAmount  DECIMAL(38, 18),  
   @pFlowSubTotal DECIMAL(38, 18),
   @pReason  VARCHAR(500)='',  
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   
    DECLARE @dealId	SMALLINT, @collectionDate	VARCHAR(20), @processReferenceId INT
    DECLARE @workflowType VARCHAR(100)='Automated_Data_Cash_Ladder',@stepName VARCHAR(50)='Edited',@feedRunLogId INT,
	@correspondentAccountNumber VARCHAR(150),@dealReference VARCHAR(100),@Product VARCHAR(100),@subProduct VARCHAR(100),
	@counterParty VARCHAR(100),@contextName VARCHAR(100),@maturityDate  datetime,@Currency VARCHAR(3)

    SELECT  @dealId=DealId,@collectionDate=CollectionDate ,@feedRunLogId =FeedRunLogId,@correspondentAccountNumber =CorrespondentAccountNumber,
	@dealReference =DealReference,@Product =Product,@subProduct =SubProduct,@counterParty =CounterParty,@contextName =ContextName,
	@maturityDate=MaturityDate,@Currency=Currency
	
	FROM cw.CashLadder
    WHERE CashLadderId=@pCashLadderId

    SET @processReferenceId=(SELECT [cw].[fnGetWorkflowProcessReferenceId](@workflowType,@pIPDRunId))
    IF EXISTS (SELECT 1 FROM cw.CashLadder_WIP WHERE CashLadderId=@pCashLadderId AND [Status] IN (1,4,5) AND IsActive=1) --DRAFT
    BEGIN
       EXEC [cw].[spManageUpstreamDataAuthWorkflow] @pWorkflowType=@workflowType, @pDealId=@dealId,@pIPDRunId =@pIPDRunId,@pStatus=1,@pStepName=@stepName, @pUserName=@pUserName

        UPDATE cw.CashLadder_WIP  SET Rate = @pRate,InflowAmount= @pInflowAmount,
        OutflowAmount=@pOutflowAmount,FlowSubTotal = @pFlowSubTotal,ChangeReason=@pReason
        WHERE CashLadderId=@pCashLadderId

         --delete if value change to original 
     DELETE FROM cw.CashLadder_WIP
     WHERE Id IN (
     SELECT
       Id
     FROM
       cw.CashLadder_WIP AS wip
     WHERE
       EXISTS
       (
         SELECT
           *
         FROM
          cw.CashLadder AS cl
          
         WHERE
           cl.CashLadderId =     wip.CashLadderId
           AND cl.Rate    =wip.Rate
           AND Cl.InflowAmount         =wip.InflowAmount
           AND cl.OutflowAmount           =wip.OutflowAmount
           AND cl.FlowSubTotal       =wip.FlowSubTotal
       )
     )
    END
    ELSE
      BEGIN
        INSERT INTO cw.CashLadder_WIP(
         [CashLadderId]
		 ,[FeedRunLogId]
        ,[DealId]
		,[CollectionDate]
        ,[CorrespondentAccountNumber]
		,[DealReference]
		,[Product]
		,[SubProduct]
		,[CounterParty]
		,[ContextName]
        ,[Rate]
        ,[MaturityDate]
        ,[Currency]
        ,[InflowAmount]
		,[OutflowAmount]
		,[FlowSubTotal]
		,[Version]
        ,[ChangeReason]
        ,[CreatedBy]
        ,[CreatedDate]
		,[IsActive]
        ,[ProcessReferenceId]
        ) VALUES(@pCashLadderId,@feedRunLogId,@dealId,@collectionDate,@correspondentAccountNumber,@dealReference,@Product,@subProduct,@counterParty,
		@contextName,@pRate,@maturityDate,@Currency,@pInflowAmount,@pOutflowAmount,@pFlowSubTotal,'',@pReason,@pUserName,GETDATE(),1,@processReferenceId)

        EXEC [cw].[spManageUpstreamDataAuthWorkflow] @pWorkflowType=@workflowType, @pDealId=@dealId,@pIPDRunId =@pIPDRunId,@pStatus=1,@pStepName=@stepName, @pUserName=@pUserName
      END    
END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'cb.spSaveCashLadderData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END
GO
