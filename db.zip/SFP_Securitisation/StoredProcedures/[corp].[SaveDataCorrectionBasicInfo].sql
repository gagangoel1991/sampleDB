USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[SaveDataCorrectionBasicInfo]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [corp].[SaveDataCorrectionBasicInfo]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[SaveDataCorrectionBasicInfo]
(
	@pDate DATE,
	@pDealId INT,
	@pEntityId INT,
	@pFsId VARCHAR(20) = NULL,
	@pStatusId INT = NULL,
	@pUserName VARCHAR(20),	
	@pResult INT OUTPUT,
	@pDealDataCorrectionId INT OUTPUT
)
AS
BEGIN
	BEGIN TRY		
		
		DECLARE @IsActive BIT = 1		

		 -- DELETE IF EXISTING DETAILS AVAILABLE FOR STATUS : 'Draft', 'Rejected', 'Recalled'  
		DECLARE @LastDealDataCorrectionId INT = (SELECT MAX(DealDataCorrectionId) FROM [corp].[DealDataCorrection]   
				  WHERE AsAtDate = @pDate AND DealId = @pDealId   
					 AND EntityTypeId = @pEntityId)  
		--DECLARE @LastStatusID INT = (SELECT DataCorrectionStatus FROM [corp].[DealDataCorrection] WHERE DealDataCorrectionId = @LastDealDataCorrectionId)  

		DECLARE @MaxDealOverrideParentId INT = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent]   
				  WHERE AsAtDate = @pDate AND DealId = @pDealId)  
		DECLARE @LastStatusID INT = (SELECT DataCorrectionStatus FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @MaxDealOverrideParentId) 

		  --IF EXISTS(SELECT 1 FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled')   
			--AND DealDataCorrectionStatusId = @LastStatusID AND @LastDealDataCorrectionId IS NOT NULL) 
		  IF EXISTS(SELECT 1 FROM [corp].[DealDataCorrection] ddc
						INNER JOIN [corp].[DealOverrideParent] dop ON ddc.AsAtDate = dop.AsAtDate AND ddc.DealId = dop.DealID AND ddc.DealOverrideParentId = dop.DealOverrideParentId
						WHERE ddc.AsAtDate = @pDate AND ddc.DealId = @pDealId AND ddc.EntityTypeId = @pEntityId  
						AND dop.DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))
						AND dop.DealOverrideParentId = @MaxDealOverrideParentId )
		  BEGIN
				UPDATE [corp].[DealDataCorrection]   
				SET DataCorrectionStatus = 1, ModifiedBy = @pUserName, ModifiedDate = Getdate()   
				WHERE DealDataCorrectionId = @LastDealDataCorrectionId   
  
				DELETE FROM [corp].[DealDataCorrectionDetail] WHERE DealDataCorrectionId = @LastDealDataCorrectionId  

				UPDATE [corp].[DealOverrideParent] 
				SET DataCorrectionStatus = 1, ModifiedBy = @pUserName, ModifiedDate = Getdate() 
				WHERE DealOverrideParentId = @MaxDealOverrideParentId
  
				 SET @pResult = 102  
				 SET @pDealDataCorrectionId = @LastDealDataCorrectionId
		  END
		  --

		--ELSE IF NOT EXISTS(SELECT 1 FROM [corp].[DealDataCorrection] WHERE AsAtDate = @pDate AND DealId = @pDealId AND EntityTypeId = @pEntityId
		--															  AND DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId 
		--																							FROM corp.[DealDataCorrectionStatus] 
		--																							WHERE STATUS IN ('Draft', 'Rejected', 'Recalled')))  
		ELSE IF NOT EXISTS(SELECT 1 FROM [corp].[DealDataCorrection] ddc
						INNER JOIN [corp].[DealOverrideParent] dop ON ddc.AsAtDate = dop.AsAtDate AND ddc.DealId = dop.DealID 
						WHERE ddc.AsAtDate = @pDate AND ddc.DealId = @pDealId AND ddc.EntityTypeId = @pEntityId  AND ddc.DealOverrideParentId = dop.DealOverrideParentId
						AND dop.DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))
						AND dop.DealOverrideParentId = @MaxDealOverrideParentId ) 
		BEGIN 
			  IF NOT EXISTS(SELECT 1 FROM [corp].[DealOverrideParent] dop 
					WHERE dop.AsAtDate = @pDate 
						  AND dop.DealID = @pDealId 
						  AND DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))) 
				BEGIN
					INSERT INTO [corp].[DealOverrideParent]
					(
						DealId,
						AsAtDate,
						DataCorrectionStatus,
						IsActive,
						CreatedBy,
						CreatedDate,
						ModifiedBy,
						ModifiedDate
					)
					VALUES
					(
						@pDealId,
						@pDate, 
						@pStatusId,  
						@IsActive,  
						@pUserName,  
						Getdate(),  
						@pUserName,  
						Getdate()
					)
				END

				SELECT @MaxDealOverrideParentId = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent] 
													WHERE AsAtDate = @pDate AND DealId = @pDealId 
													AND DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))) 

			   INSERT INTO [corp].[DealDataCorrection]  
			   (  
				AsAtDate,  
				DealId,  
				EntityTypeId,      
				DataCorrectionStatus,    
				IsActive,  
				CreatedBy,  
				CreatedDate,  
				ModifiedBy,  
				ModifiedDate ,
				DealOverrideParentId
			   )  
			   VALUES  
			   (  
				@pDate,  
				@pDealId,  
				@pEntityId,  
				@pStatusId,  
				@IsActive,  
				@pUserName,  
				Getdate(),  
				@pUserName,  
				Getdate()  ,
				@MaxDealOverrideParentId
			   )  
			   SET @pResult = 101  
			   SET @pDealDataCorrectionId = (SELECT MAX(DealDataCorrectionId) FROM [corp].[DealDataCorrection] )  --@@IDENTITY (this won't work after trigger added)  
  
			   DECLARE @workflowType VARCHAR(50)='DealDataCorrection'  
			   DECLARE @stepName VARCHAR(50)='Draft'  
			   DECLARE @NewDdcComment  VARCHAR(250)='DealDataCorrection created'  
			   DECLARE @DraftStatusId INT = 1   
			   DECLARE @DealDataCorrectionFilterId  INT; 

			   -- INSERTING WORKFLOW TABLE --  
			   EXEC [ps].[spManageAuthWorkflow] @pWorkflowType=@workflowType,@pPsId=@MaxDealOverrideParentId,@pStatus=@DraftStatusId,@pStepName=@stepName,  
				  @pComment=@NewDdcComment,@pUserName=@pUserName       
			   -- WORKFLOW ENDS -- 
		END 
		--ELSE
		--BEGIN
		--	SET @pResult = 1011
		--	SET @pDealDataCorrectionId = (SELECT DealDataCorrectionId FROM [corp].[DealDataCorrection] WHERE AsAtDate = @pDate AND DealId = @pDealId AND EntityTypeId = @pEntityId
		--																									AND DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId 
		--																																 FROM corp.[DealDataCorrectionStatus] 
		--																																 WHERE STATUS NOT IN ('Submitted', 'Authorised')))  
		--	UPDATE [corp].[DealDataCorrection] 
		--	SET DataCorrectionStatus = @pStatusId,
		--		ModifiedDate = GETUTCDATE(), ModifiedBy = @pUserName 
		--	WHERE DealDataCorrectionId = @pDealDataCorrectionId
		--END
END TRY
	BEGIN CATCH	                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
        
		SET @pResult = -101     

		EXEC app.SaveErrorLog 2, 1, 'SaveDataCorrectionBasicInfo', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                    
                      
		RAISERROR (@errorMessage, @errorSeverity, @errorState)
	END CATCH
END
GO