USE [SFP_Securitisation]
GO

IF OBJECT_ID('cb.spManageDealNoteWorkflowProcess') IS NOT NULL
	DROP PROC cb.spManageDealNoteWorkflowProcess
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Ravindra Singh
 * Date:	11.07.2022
 * Description:  This will manage the deal Note workflow auth process
 * DECLARE  @code TINYINT 
 * EXEC [cb].spManageDealNoteWorkflowProcess   6, 59, '','FM\kumavnb','2021-06-22',	@code	 OUTPUT
 * Select @code 
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
CREATE PROCEDURE [cb].spManageDealNoteWorkflowProcess (
     @dealId INT
	 ,@pWorkFlowStepId INT = NULL
	,@pAuthorizerComment VARCHAR(max) = NULL
	,@pUserName VARCHAR(100) = NULL
	,@pReturnCode SMALLINT = 1 OUTPUT
	)
AS
BEGIN
	BEGIN TRY
		DECLARE @currentWorlflowStepId INT
			--,@dealId INT
			,@workflowProcessId INT
			,@dealAuthorisedStepId INT
			,@collapseStepId INT
			,@stepName VARCHAR(100)
			,@ipdDate DATE
			,@currentWorkflowStepId INT
			,@authoriseStatusId INT
			,@dealNoteId INT


			SELECT @stepName = StepName
		FROM cfgCW.WorkflowStep
		WHERE WorkflowStepId = @pWorkFlowStepId

		--Update Workflow Step
		IF EXISTS (
				SELECT 1
				FROM cfgcw.DealNote
				WHERE IsActive=1
				)
		BEGIN
			
			SELECT @dealId = DealId
			FROM cfgcb.DealNote
			WHERE DealId = 6

			SELECT @currentWorlflowStepId = (
					SELECT TOP 1 wfs.WorkflowStepId
					FROM cw.WorkflowProcess wfp
					JOIN cfgcw.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
					JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
					WHERE wfp.ProcessReferenceId = @dealId
						AND wft.Name = 'New_Deal_Onboarding'
					ORDER BY wfp.WorkflowProcessId DESC
					)

			IF ISNULL(@currentWorlflowStepId, 0) <> @pWorkFlowStepId
			BEGIN
				EXEC [cw].[spSaveWorkflowProcess] @dealId
					,@pWorkFlowStepId
					,@pAuthorizerComment
					,@pUserName
					,@workflowProcessId OUTPUT
			END

			IF @stepName in ( 'AuthorisedUpdateDeal','Recall')
			BEGIN

			UPDATE cfgcb.DealNote_WIP
			    SET isActive = 0
			--	NewRedemptionDate = NULL
				WHERE DealstatusId=@pWorkFlowStepId AND isActive=1

			END

		
		END

		SET @pReturnCode = 1;
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2
			,1
			,'spManageDealNoteWorkflowProcess'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)

		SET @pReturnCode = - 1
	END CATCH
END
GO


