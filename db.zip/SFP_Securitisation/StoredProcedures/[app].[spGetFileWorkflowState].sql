USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spGetFileWorkflowState]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[spGetFileWorkflowState]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spGetFileWorkflowState]
(	
	@pUserName VARCHAR(50),
	@pFileInfoId INT
)      
AS      
BEGIN      
	BEGIN TRY        
		SELECT
			TOP 10 
			fws.StatusName AS Status,
			fud.CreatedBy AS UploadedBy,
			fud.CreatedDate AS UploadedDate,
			CASE WHEN Upper(fws.StatusName) IN ('AWAITING', 'AWAITING-PUBLISH', 'INMODEL') THEN 
				fud.ModifiedBy
				ELSE 
				'' END AS RequestedBy,
			CASE WHEN Upper(fws.StatusName) IN ('AWAITING', 'AWAITING-PUBLISH', 'INMODEL') THEN 
				fud.ModifiedDate
				ELSE 
				NULL END AS RequestedDate,
			fud.AuthorizedBy,
			fud.AuthorizedDate,			
			fud.InModelDate 
		FROM       
		[app].[FileUploadDetail] fud 
		JOIN [app].[FileWorkflowStatus] fws
			ON  fud.FileWorkflowStatusId = fws.FileWorkflowStatusId
		WHERE FileInfoId = @pFileInfoId
		ORDER BY fud.FileUploadDetailId DESC;
			
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetFileWorkflowState', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO
