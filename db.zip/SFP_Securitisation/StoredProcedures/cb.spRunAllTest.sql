USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spRunAllTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunAllTest]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cb].[spRunAllTest]
/*
 * Author: Kapil Sharma
 * Date:	07.03.2022
 * Description:  This will RUN all test of Deimos in sequence
 * 
 * Example - 
 * [cb].[spRunAllTest] 34, 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		IF EXISTS(SELECT TOP 1 di.DealIpdId  FROM cw.DealIpd di 
			JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId 
			JOIN cw.WorkflowProcess wfp ON wfp.ProcessReferenceId = dir.RunId
			JOIN cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = wfp.WorkflowStepId
			JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
			WHERE dir.RunId = @pDealIpdRunId AND wft.[Name] = 'Deal_IPD' AND wfs.StepName = 'Draft')
		BEGIN
			EXEC cb.spRunAssetCoverageTest @pDealIpdRunId, @pUserName
			PRINT 'spRunAssetCoverageTest is completed'

			EXEC cb.spRunAmortisationTest @pDealIpdRunId, @pUserName
			PRINT 'spRunAmortisationTest is completed'

			EXEC cb.spRunICTTest @pDealIpdRunId, @pUserName
			PRINT 'spRunICTTest is completed'

			EXEC cb.spProcessForwardPoolData @pDealIpdRunId, @pUserName
			PRINT 'spProcessForwardPoolData is completed'

			EXEC cb.spICT12MonthForwardCalculation @pDealIpdRunId, @pUserName
			PRINT 'spICT12MonthForwardCalculation is completed'

			EXEC cb.spRunOCTTest @pDealIpdRunId, @pUserName
			PRINT 'spRunOCTTest is completed'

			EXEC cb.spRunInterestRateShortfallTest @pDealIpdRunId, @pUserName
			PRINT 'spRunInterestRateShortfallTest is completed'

			EXEC cb.spRunPreMaturityTest @pDealIpdRunId, @pUserName
			PRINT 'spRunPreMaturityTest is completed'

			EXEC cb.spRunCBMCResult @pDealIpdRunId, @pUserName
			PRINT 'spRunCBMCResult is completed'

		END
		ELSE
		BEGIN
			--Adding the default values
			IF EXISTS(SELECT TOP 1 DealIpdId FROM cw.DealIpdRun WHERE RunId = @pDealIpdRunId) AND
			NOT EXISTS(SELECT TOP 1 * FROM cb.DealIpdTestResult WHERE DealIpdRunId = @pDealIpdRunId)
			BEGIN
				DECLARE
					@testTypeId			INT,
					@internalName		VARCHAR(200),
					@defaultStatus		VARCHAR(40)

				DECLARE cursorTestType CURSOR FOR     
				SELECT DISTINCT TestTypeID, InternalName, DefaultStatus FROM cfgcb.TestType WHERE IsActive = 1 AND DefaultStatus IS NOT NULL
  
				OPEN cursorTestType    
  
				FETCH NEXT FROM cursorTestType INTO @testTypeId, @internalName, @defaultStatus
				WHILE @@FETCH_STATUS = 0    
				BEGIN 
					EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeId, @defaultStatus, @pUserName

					FETCH NEXT FROM cursorTestType INTO @testTypeId, @internalName, @defaultStatus
				END

				CLOSE cursorTestType;  
				DEALLOCATE cursorTestType; 
			END
		END
	END TRY
	BEGIN CATCH
		IF CURSOR_STATUS('global','cursorTestType') >= 0 
		BEGIN
			CLOSE cursorTestType;
			DEALLOCATE cursorTestType;	
		END

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spRunAllTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO


