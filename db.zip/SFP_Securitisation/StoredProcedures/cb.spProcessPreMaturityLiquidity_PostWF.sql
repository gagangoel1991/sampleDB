USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessPreMaturityLiquidity_PostWF]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessPreMaturityLiquidity_PostWF]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessPreMaturityLiquidity_PostWF] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  16.03.2022
 *   Description:  Fill PreMaturityLiquidity_PostWF CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *     
 *   exec cb.[spProcessPreMaturityLiquidity_PostWF] 35,'fm\shriyad'
 *    select * from [Cb].[PreMaturityLiquidity_PostWF] where dealipdrunid=35           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 
      BEGIN TRY 
          --declare @pDealIpdRunId int=35, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @CreditReceived_RPP decimal(38,16),  @CreditReceived_PPP decimal(38,16)

				SELECT @CreditReceived_RPP = RevenueWaterfallTotalPaidAmount
				FROM [CW].[vwRevenueWaterfallPaymentSummary]
				WHERE DealIpdRUnId = @pDealIpdRunId AND WaterfallLineItemInternalName='RevenuePriorityofPayments_7.000'

				SELECT @CreditReceived_PPP = PrincipalWaterfallTotalPaidAmount
				FROM [CW].[vwPrincipalWaterfallPaymentSummary]
				WHERE DealIpdRUnId = @pDealIpdRunId AND WaterfallLineItemInternalName='PrincipalPriorityofPayments_1.000'

                
          DELETE FROM [Cb].[PreMaturityLiquidity_PostWF] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[PreMaturityLiquidity_PostWF] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,CreditReceivedRPP
						,ShortfallAfterRPP
						,CreditReceivedPPP
						,PreMaturityLiquidity_cf
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
          SELECT   @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,@CreditReceived_RPP
						,IIF(COALESCE(DueAmount,0)- COALESCE(@CreditReceived_RPP,0)>0
								, COALESCE(DueAmount,0)- COALESCE(@CreditReceived_RPP,0)
								, 0)
						,@CreditReceived_PPP
						,COALESCE(PreMaturityLiquidity_bF,0)+COALESCE(CapitalContribution,0)-COALESCE(ResidualAmount,0)
							-@CreditReceived_RPP+@CreditReceived_PPP
						,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM	cfgcb.CoveredBondFund cbf
						JOIN cb.PreMaturityLiquidity_PreWF pml_preWF ON pml_preWF.CoveredBondFundId = cbf.CoveredBondFundId
								AND pml_preWF.DealIpdRunId = @pDealIpdRunId
                WHERE  cbf.InternalName = 'PreMaturityLiquidityFund' 
		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessPreMaturityLiquidity_PostWF', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO