USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spConditionActionRepurchase') IS NOT NULL
	DROP PROCEDURE cw.spConditionActionRepurchase
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spConditionActionRepurchase
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  10.08.2021
 *   Description:  
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *      
 * 	 cw.spConditionActionRepurchase 32,'fm\shriyad'
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80)
)
AS
BEGIN
	BEGIN TRY
		--DECLARE @pDealIpdRunId INT = 32, @pUserName	VARCHAR(80) ='fm\shriyad'

		DECLARE @dealId  INT, 
		 @CollectionBusinessEndDate   datetime, 
		 @LoanCount decimal(38,16) , 
		 @CapitalBalanceValue decimal(38,16),
		 @TrueBalanceValue decimal(38,16)


		SELECT @dealId = DealId FROM  cw.vwDealIpdRun WHERE  DealIpdRunId = @pDealIpdRunId 

		SET @CollectionBusinessEndDate=(SELECT DealDateValue 
									  FROM   cw.vwDealDate 
									  WHERE  DealIpdRunId=@pDealIpdRunId 
											 AND DealDateKeyInternalName = 'CollectionBusinessEnd') 

		SELECT 
		@LoanCount = SUM(QuarterlyLoanCount),
		@CapitalBalanceValue = SUM(QuarterlyCapitalBalanceValue),
		@TrueBalanceValue  = SUM(QuarterlyTrueBalanceValue)
			FROM
			[cw].[DealProductSwitchData] psd
			JOIN  [cfgCW].[ProductSwitchType] pst ON psd.ProductSwitchTypeId = pst.ProductSwitchTypeId AND pst.IsActive = 1
			WHERE
			dealid=@dealId
			AND CorrelatedDate =@CollectionBusinessEndDate
			AND pst.Name IN ('FIXEDHIGH-FIXEDLOW', 'SVR-FIXED', 'DISCOUNT-FIXED')


		UPDATE ct
		SET LoanCount = @LoanCount, 
			LoanAmount = @CapitalBalanceValue, 
			RepurchaseAmount = @TrueBalanceValue
		FROM cw.DealIpdConditionTest ct, cfgcw.DealCondition dc
		WHERE ct.DealConditionId = dc.DealConditionId
		AND dc.DealId = @dealId
		AND ct.DealIpdRunId = @pDealIpdRunId
		AND dc.ActionStoredProcedure = 'cw.spConditionActionRepurchase'

		END TRY 

      BEGIN CATCH 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spConditionActionRepurchase', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

END 


	GO