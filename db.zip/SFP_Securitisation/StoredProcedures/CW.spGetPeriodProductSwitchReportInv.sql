USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetPeriodProductSwitchReportInv') IS NOT NULL
	DROP PROC CW.spGetPeriodProductSwitchReportInv
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Product Switch Data for Investor report.
 * Usage : CW.spGetPeriodProductSwitchReportInv @pAsAtDate  = '30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1' 
 * 		,@pUserName = NULL    		
 * 		
 * 		CW.spGetPeriodProductSwitchReportInv @pAsAtDate  = '31-Aug-2020'
 * 		,@pDealName  = 'DUNMORE1' 
 * 		,@pUserName = NULL   
 * 		                                            
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetPeriodProductSwitchReportInv @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
			
	
BEGIN TRY
  
  SET NOCOUNT ON;
  
  DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	, @previous_asatdate DATE = ( SELECT CW.SynFnPreviousReportDate(@pAsAtDate, 3)  )
	, @totalSubAccounts float
	, @totalOutstandingCapitalBalance float
	, @partitionID_Previous_AsAtDate INT
	, @totalTrueBalance float;
	SET @partitionID_Previous_AsAtDate = CONVERT(INT, CONVERT(VARCHAR(8), @previous_asatdate, 112))  
	
	 
	------------------ Fact_Mortgage for Current Business Reporting Date ------------------------------------------------------------      
	SELECT DISTINCT VMS.LoanId, VMS.SubAccountNumber, VMS.MortgageSubAccountKey, TotalOutstandingCapitalBalance, TrueBalance
	,ProductCode, dicc.InterestControlCode, InterestRateType, GrossInterestRate, BaseRateCode, InterestRateCode
	INTO #CurrentMortgage 
	FROM CW.VwMortgageSubAccount VMS  
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeInterestRateRevesionGroup birrg ON VMS.InterestRateRevisionGroupKey = birrg.InterestRateRevisionGroupKey  
	INNER JOIN sfp.syn_SfpModel_tbl_InterestRate dir ON birrg.InterestRateKey = dir.InterestRateKey  
	LEFT OUTER JOIN sfp.syn_SfpModel_tbl_dim_InterestControlCode dicc ON VMS.InterestControlCodeKey = dicc.InterestControlCodeKey  
	WHERE VMS.partitionid = @partitionID_AsAtDate  
	AND VMS.DealName = @pDealName  
	AND birrg.RevisionNumber = 0
	AND VMS.InterestRateRevisionGroupKey <> -1  
	
	
	CREATE CLUSTERED INDEX INDXLI ON #CurrentMortgage  (LoanId, SubAccountNumber);     


	-------------------- Fact_Mortgage for Previous Business Reporting Date --------------------------------------------------------------  
	SELECT DISTINCT VMS.LoanId, VMS.SubAccountNumber, VMS.MortgageSubAccountKey, TotalOutstandingCapitalBalance, TrueBalance
	,ProductCode, dicc.InterestControlCode, InterestRateType, GrossInterestRate, BaseRateCode, InterestRateCode
	INTO #PreviousMortgage 
	FROM CW.VwMortgageSubAccount VMS  
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeInterestRateRevesionGroup birrg ON VMS.InterestRateRevisionGroupKey = birrg.InterestRateRevisionGroupKey  
	INNER JOIN sfp.syn_SfpModel_tbl_InterestRate dir ON birrg.InterestRateKey = dir.InterestRateKey  
	LEFT OUTER JOIN sfp.syn_SfpModel_tbl_dim_InterestControlCode dicc ON VMS.InterestControlCodeKey = dicc.InterestControlCodeKey  
	WHERE VMS.partitionid = @partitionID_Previous_AsAtDate  
	AND VMS.DealName = @pDealName  
	AND birrg.RevisionNumber = 0
	AND VMS.InterestRateRevisionGroupKey <> -1  
 
	CREATE CLUSTERED INDEX INDXLI ON #PreviousMortgage  (LoanId, SubAccountNumber); 
	
	---------------------------------------------------------------------------------------------

  -- This table mostly contains all the calculated columns except 1 (Ineligible Product Switch) for the report -   
  -- Merging Current and Previous date calculations   
	SELECT  
	c.LoanID,  
	c.SubAccountNumber,  
	c.MortgageSubAccountKey,
	CRNTTotalOutstandingCapitalBalance = c.TotalOutstandingCapitalBalance,  
	CRNTTrueBalance = c.TrueBalance,     
	CRNTProductCode = c.ProductCode,  
	CRNTInterestControlCode = c.InterestControlCode,  
	CRNTInterestRateType = c.InterestRateType ,  
	CRNTGrossInterestRate = c.GrossInterestRate,    
	CRNTBaseRateCode = c.BaseRateCode ,  
	CRNTInterestRateCode = c.InterestRateCode,  
	PREVTotalOutstandingCapitalBalance = P.TotalOutstandingCapitalBalance,  
	PREVTrueBalance = P.TrueBalance,     
	PREVProductCode = P.ProductCode,  
	PREVInterestControlCode = P.InterestControlCode,  
	PREVInterestRateType = P.InterestRateType ,  
	PREVGrossInterestRate = P.GrossInterestRate,    
	PREVBaseRateCode = P.BaseRateCode ,  
	PREVInterestRateCode = P.InterestRateCode,  
	ProductSwitchDescription = CASE  
	WHEN @pDealName = 'DUNMORE1' THEN  
		CASE  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode = 'ZERO' AND p.GrossInterestRate < c.GrossInterestRate THEN 'FIX Low to FIX High'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode = 'ZERO' AND p.GrossInterestRate > c.GrossInterestRate THEN 'FIX High to FIX Low'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode = 'ZERO' AND p.GrossInterestRate = c.GrossInterestRate AND p.InterestControlCode <> c.InterestControlCode THEN 'FIX to FIX'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND c.BaseRateCode = 'ZERO' THEN 'SVR to FIX'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode IN ('SVR', 'TSTSVR') THEN 'FIX to SVR'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND c.BaseRateCode IN ('SVR', 'TSTSVR') THEN 'No Change'  
		WHEN p.BaseRateCode = 'ZERO' AND (c.BaseRateCode NOT IN ('ZERO', 'SVR', 'TSTSVR') OR c.InterestRateType = 'TRACKER') THEN 'FIX to OTHER'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND (c.BaseRateCode NOT IN ('ZERO', 'SVR', 'TSTSVR') OR c.InterestRateType = 'TRACKER') THEN 'SVR to OTHER'  
		WHEN (p.InterestControlCode = c.InterestControlCode AND p.InterestRateCode = c.InterestRateCode OR (p.BaseRateCode = '' OR p.BaseRateCode IS NULL)) THEN 'No Change'  
		WHEN p.InterestRateType = 'TRACKER' AND c.BaseRateCode = 'ZERO' THEN 'Tracker to FIX'  
		WHEN p.InterestRateType = 'TRACKER' AND c.BaseRateCode = 'ECBR' THEN 'Tracker to SVR'  
		WHEN p.BaseRateCode = 'ECBR' AND c.InterestRateType = 'TRACKER' THEN 'SVR to Tracker'  
		WHEN p.BaseRateCode = 'ZERO' AND c.InterestRateType = 'TRACKER' THEN 'FIX to Tracker'  
		WHEN p.InterestRateType = 'TRACKER' AND c.BaseRateCode NOT IN ('ZERO', 'SVR', 'TSTSVR') AND c.InterestRateType <> 'TRACKER' THEN 'Tracker to Other'  
		WHEN p.BaseRateCode NOT IN ('ZERO', 'SVR', 'TSTSVR') AND c.BaseRateCode = 'ZERO' THEN 'OTHER to FIX'  
		WHEN p.BaseRateCode NOT IN ('ZERO', 'SVR', 'TSTSVR') AND c.BaseRateCode IN ('SVR', 'TSTSVR') THEN 'OTHER to SVR'  
		WHEN p.BaseRateCode NOT IN ('ZERO', 'SVR', 'TSTSVR') AND c.InterestRateType = 'TRACKER' THEN 'OTHER to Tracker'  
		ELSE 'No Change'  
		END  
	ELSE  
	CASE  
		WHEN c.InterestRateType = 'TRACKER' THEN 'Tracker'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode = 'ZERO' AND p.GrossInterestRate < c.GrossInterestRate THEN 'FIX Low to FIX High'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode = 'ZERO' AND p.GrossInterestRate > c.GrossInterestRate THEN 'FIX High to FIX Low'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode = 'ZERO' AND p.GrossInterestRate = c.GrossInterestRate AND p.InterestControlCode <> c.InterestControlCode THEN 'FIX to FIX'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND c.BaseRateCode = 'ZERO' THEN 'SVR to FIX'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode IN ('SVR', 'TSTSVR') THEN 'FIX to SVR'  
		WHEN p.BaseRateCode IN ('BTL', 'BTLV') AND c.BaseRateCode = 'ZERO' THEN 'BTL to FIX'  
		WHEN p.BaseRateCode = 'ZERO' AND c.BaseRateCode IN ('BTL', 'BTLV') THEN 'FIX to BTL'  
		WHEN p.BaseRateCode IN ('BTL', 'BTLV') AND c.BaseRateCode IN ('SVR', 'TSTSVR') THEN 'BTL to SVR'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND c.BaseRateCode IN ('BTL', 'BTLV') THEN 'SVR to BTL'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND c.BaseRateCode IN ('SVR', 'TSTSVR') THEN 'No Change'  
		WHEN p.BaseRateCode = 'ZERO' AND (c.BaseRateCode NOT IN ('ZERO', 'BTL', 'BTLV','SVR', 'TSTSVR') OR c.InterestRateType = 'TRACKER') THEN 'FIX to OTHER'  
		WHEN p.BaseRateCode IN ('SVR', 'TSTSVR') AND (c.BaseRateCode NOT IN ('ZERO', 'BTL', 'BTLV','SVR', 'TSTSVR') OR c.InterestRateType = 'TRACKER') THEN 'SVR to OTHER'  
		WHEN p.BaseRateCode IN ('BTL', 'BTLV') AND (c.BaseRateCode NOT IN ('ZERO', 'BTL', 'BTLV','SVR', 'TSTSVR') OR c.InterestRateType = 'TRACKER') THEN 'BTL to OTHER'  
		WHEN (p.InterestControlCode = c.InterestControlCode AND p.InterestRateCode = c.InterestRateCode OR (p.BaseRateCode = '' OR p.BaseRateCode IS NULL)) THEN 'No Change'  
		ELSE 'No Change'  
		END  
	END  
  , IneligibleProductSwitch= Cast('' AS varchar(100))
  , ProductSwitchType = Cast('' AS varchar(100))
    INTO #Inter
  FROM #CurrentMortgage C
  LEFT OUTER JOIN #PreviousMortgage P ON c.LoanID = p.LoanID AND c.SubAccountNumber = p.SubAccountNumber;  
  
  
  
  
	--=FOR % of Total Current pool of Mortgage
	SELECT @totalSubAccounts = COUNT(M.MortgageSubAccountKey)  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0)) 
		, @totalTrueBalance  = ISNULL(SUM(M.TrueBalance), 0) 
	FROM   #CurrentMortgage M

	
	/*----==========================#TempLookup for Morgage SubAccount ( Will remove this comment section once report data tested
	--- This table mostly contains all the calculated columns for the report but more calculation is required for IneligiblePRoductSwitch  
	Update #Inter
	Set ProductSwitchType = CASE  
    WHEN @pDealName = 'DUNMORE1' THEN  
		   CASE   
            WHEN ProductSwitchDescription IN ('FIX Low to FIX High','FIX High to FIX Low','FIX to FIX') THEN 'AA Fixed Rate to New Fixed Rate'  
            WHEN ProductSwitchDescription IN ('SVR to FIX','Tracker to FIX','OTHER to FIX') THEN 'BB Conversion to Fixed Rate'  
            WHEN ProductSwitchDescription IN ('FIX to SVR','FIX to OTHER','FIX to Tracker') THEN 'CC Conversion from Fixed Rate'  
            WHEN ProductSwitchDescription IN ('Tracker to SVR','SVR to Tracker') THEN 'DD ECB Tracker to SVR / SVR  to ECB Tracker'  
            WHEN ProductSwitchDescription IN ('SVR to OTHER','Tracker to Other','OTHER to SVR','OTHER to Tracker') THEN 'EE Other'  
            ELSE 'No Change'  
          END   
	ELSE  
			CASE   
			WHEN ProductSwitchDescription IN ('Tracker', 'FIX High to FIX Low', 'SVR to FIX',  'FIX to BTL', 'SVR to BTL', 'FIX to OTHER', 'SVR to OTHER', 'BTL to OTHER') THEN 'Yes'   
            ELSE 'No Change'  END  
    END  		
		
	Create Table #TempLookup (SortNo int, ProductSwitchType varchar(100))
	Insert into #TempLookup (SortNo, ProductSwitchType)
	Values 
		(1,'AA Fixed Rate to New Fixed Rate'),
		(2,'BB Conversion to Fixed Rate'),
		(3,'CC Conversion from Fixed Rate'),
		(4,'DD ECB Tracker to SVR / SVR  to ECB Tracker'),
		(5,'EE Other')
	

	Select T.SortNo, T.ProductSwitchType, count(*) [MortgageLoans]
	,ISNULL(SUM([CRNTTotalOutstandingCapitalBalance]),0) 'TotalOutCapitalBalance' 
	,ISNULL(Cast( (sum([CRNTTotalOutstandingCapitalBalance]) / @totalOutstandingCapitalBalance ) *100 as Decimal(10,2)),0) TotalOutCapitalBalancePercent 
	From #TempLookup T
	Left Join #Inter I ON T.ProductSwitchType = I.ProductSwitchType
	Group by T.ProductSwitchType, T.SortNo
	Order by T.SortNo
	*/
	
	

	SELECT ROW_NUMBER() OVER( ORDER BY ProductSwitchDescription ) AS SortNo, I.ProductSwitchDescription, count(*) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum([CRNTTotalOutstandingCapitalBalance]) AS Float) , 0) 'TotalOutCapitalBalance' 
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum([CRNTTotalOutstandingCapitalBalance]) / @totalOutstandingCapitalBalance ) *100 AS Decimal(10,2))  ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent  
	, ISNULL(CAST(sum(CRNTTrueBalance) AS Float) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(CRNTTrueBalance) / @totalTrueBalance) * 100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TrueBalancePercent 
	
	FROM #Inter I
	GROUP BY I.ProductSwitchDescription
	
	
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetPeriodProductSwitchReportInv', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END

GO
