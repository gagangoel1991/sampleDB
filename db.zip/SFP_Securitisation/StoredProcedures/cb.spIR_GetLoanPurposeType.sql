USE SFP_Securitisation
GO

IF OBJECT_ID('cb.spIR_GetLoanPurposeType') IS NOT NULL
	DROP PROC cb.spIR_GetLoanPurposeType
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-----------------------------------------------------
--Author: Arun 
--Date:	09-Feb-2022
--Description: This SP is Used to Get Covid-19-related Payment Holidays

--EXEC cb.spIR_GetLoanPurposeType '2021-04-30','DEIMOS'
--go
--EXEC cb.spIR_GetLoanPurposeType '2021-05-28','DEIMOS'

-----------------------------------------------------


CREATE PROCEDURE cb.spIR_GetLoanPurposeType
(
	 @pAsAtDate DATETIME
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
)

AS

BEGIN
	BEGIN TRY  

		DECLARE @dealId int;
		DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		DECLARE @totalSubAccounts float, @totalOutstandingCapitalBalance float

		SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
		SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
		
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
		INSERT INTO #VwMortgageSubAccount   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId

		

		SELECT @totalOutstandingCapitalBalance = sum(Outstandng_Capital_Balance_Amt)
		, @totalSubAccounts = count(*)
		FROM #VwMortgageSubAccount 

		CREATE INDEX Indx_ProductKey ON #VwMortgageSubAccount(ProductKey)
		CREATE INDEX Indx_PropertyKey ON #VwMortgageSubAccount(PropertyKey)
		CREATE INDEX Indx_MortgageSubAccountKey ON #VwMortgageSubAccount(MortgageSubAccountKey)
		

		SELECT fmsa.*
			, prod.ProductType
			, prop.PropertyUsageCode
			, vmsa.SubAccountNumber
			, vmsa.AccountPurposeCode
			, hc.HoldCode 
		INTO   
			#MortgageTemp      
		FROM   
			#VwMortgageSubAccount fmsa  
			LEFT JOIN [sfp].[syn_SfpModel_vw_Product_v1] prod ON prod.ProductKey = fmsa.ProductKey
			LEFT JOIN [sfp].[syn_SfpModel_vw_Property_v1] prop ON prop.PropertyKey = fmsa.PropertyKey
			LEFT JOIN [sfp].[syn_SfpModel_vw_MortgageSubAccount_v1] vmsa  WITH(NOLOCK) ON fmsa.MortgageSubAccountKey = vmsa.MortgageSubAccountKey
			LEFT JOIN [sfp].[syn_SfpModel_vw_HoldCode_v1] hc ON hc.HoldCodeGroupKey=fmsa.HoldCodeGroupKey
		
		SELECT fmsa.*
		INTO #Moodycommon 
		FROM  #MortgageTemp fmsa
		

		SELECT DISTINCT c.MortgageSubAccountKey
					 , c.LOAN_IDENTIFIER
					 , irr.BaseRateCode  
		INTO #MoodyInterestRatecomm
					 FROM #Moodycommon     C
		INNER JOIN [sfp].[syn_SfpModel_vw_InterestRateRevision_v1] irr WITH(NOLOCK)
					ON c.InterestRateRevisionGroupKey = irr.InterestRateRevisionGroupKey
				WHERE  c.SubAccountNumber = 1
					   AND (c.ProductType = 'BTL'
							OR c.HoldCode = 'B2L'
							OR irr.BaseRateCode = 'BTL')
	
		SELECT DISTINCT A.MortgageSubAccountKey,  A.OUTSTANDNG_CAPITAL_BALANCE_AMT, A.CURRENT_LTV
			INTO #MoodyBTLType
			FROM #Moodycommon A 
			LEFT OUTER JOIN #MoodyInterestRatecomm AS D ON D.LOAN_IDENTIFIER = A.LOAN_IDENTIFIER     WHERE PropertyUsageCode = '4' OR D.LOAN_IDENTIFIER IS NOT NULL

		

		DELETE A
				FROM #Moodycommon AS A
					 JOIN #MoodyBTLType O
						  ON A.MortgageSubAccountKey = O.MortgageSubAccountKey;


		SELECT DISTINCT A.MortgageSubAccountKey, A.OUTSTANDNG_CAPITAL_BALANCE_AMT, A.CURRENT_LTV
		INTO #MoodyRightToBuyType FROM #Moodycommon A JOIN #MortgageTemp B	ON  A.LOAN_IDENTIFIER = B.LOAN_IDENTIFIER     WHERE B.AccountPurposeCode = 'RB' 

		

		DELETE A
				FROM #Moodycommon AS A
					 JOIN #MoodyRightToBuyType O
						  ON A.MortgageSubAccountKey = O.MortgageSubAccountKey;


		SELECT DISTINCT A.MortgageSubAccountKey, A.OUTSTANDNG_CAPITAL_BALANCE_AMT, A.CURRENT_LTV
		INTO #MoodyOwnerOccupiedType 
		FROM #Moodycommon  A   WHERE PropertyUsageCode IN ('1', '2', '3', '5', '6');

		

		 DELETE A
				FROM #Moodycommon AS A
					 JOIN #MoodyOwnerOccupiedType O
						  ON A.MortgageSubAccountKey = O.MortgageSubAccountKey;


		 SELECT DISTINCT A.MortgageSubAccountKey, A.OUTSTANDNG_CAPITAL_BALANCE_AMT, A.CURRENT_LTV
				INTO #MoodySecondHomeType
				FROM   #Moodycommon AS A
				WHERE  A.SubAccountNumber = 1
					   AND A.AccountPurposeCode = 'SP';

		 

		  DELETE A
				FROM #Moodycommon AS A
					 JOIN #MoodySecondHomeType O
						  ON A.MortgageSubAccountKey = O.MortgageSubAccountKey;


		INSERT INTO #MoodyBTLType
				SELECT A.MortgageSubAccountKey, A.OUTSTANDNG_CAPITAL_BALANCE_AMT, A.CURRENT_LTV
				FROM   #Moodycommon A;

		
		SELECT 1 AS SortOrder, count(*) AS LoanCount, CASE WHEN @totalSubAccounts >0 THEN Cast( count(*) /  @totalSubAccounts AS Decimal(38,8)) END AS TotalLoanCountPercent 
		, IsNull(sum(OUTSTANDNG_CAPITAL_BALANCE_AMT),0) AS TotalOutstandingCapitalBalance  
		, CASE WHEN @totalOutstandingCapitalBalance >0 THEN Cast( sum(OUTSTANDNG_CAPITAL_BALANCE_AMT)/  @totalOutstandingCapitalBalance AS Decimal(38,8)) END AS TotalOutstandingCapitalPercent 
		INTO #LoanPurposeData
		FROM #MoodyOwnerOccupiedType
		UNION ALL
		SELECT 2 AS SortOrder, count(*) AS LoanCount, CASE WHEN @totalSubAccounts >0 THEN Cast( count(*) /  @totalSubAccounts AS Decimal(38,8)) END AS TotalLoanCountPercent 
		,  IsNull(sum(OUTSTANDNG_CAPITAL_BALANCE_AMT),0) AS TotalOutstandingCapitalBalance  
		, CASE WHEN @totalOutstandingCapitalBalance >0 THEN Cast( sum(OUTSTANDNG_CAPITAL_BALANCE_AMT)/  @totalOutstandingCapitalBalance AS Decimal(38,8)) END AS TotalOutstandingCapitalPercent 
		FROM #MoodyBTLType
		UNION ALL
		SELECT 3 AS SortOrder, count(*) AS LoanCount, CASE WHEN @totalSubAccounts >0 THEN Cast( count(*) /  @totalSubAccounts AS Decimal(38,8)) END AS TotalLoanCountPercent 
		,  IsNull(sum(OUTSTANDNG_CAPITAL_BALANCE_AMT),0) AS TotalOutstandingCapitalBalance 
		, CASE WHEN @totalOutstandingCapitalBalance >0 THEN Cast( sum(OUTSTANDNG_CAPITAL_BALANCE_AMT)/  @totalOutstandingCapitalBalance AS Decimal(38,8)) END AS TotalOutstandingCapitalPercent 
		FROM #MoodyRightToBuyType
		UNION ALL
		SELECT 4 AS SortOrder, count(*) AS LoanCount, CASE WHEN @totalSubAccounts >0 THEN Cast( count(*) /  @totalSubAccounts AS Decimal(38,8)) END AS TotalLoanCountPercent 
		,  IsNull(sum(OUTSTANDNG_CAPITAL_BALANCE_AMT),0) AS TotalOutstandingCapitalBalance 
		, CASE WHEN @totalOutstandingCapitalBalance >0 THEN Cast( sum(OUTSTANDNG_CAPITAL_BALANCE_AMT)/  @totalOutstandingCapitalBalance AS Decimal(38,8)) END AS TotalOutstandingCapitalPercent 
		FROM #MoodySecondHomeType

		CREATE TABLE #LoanPurposeType(SortOrder INT , TypeName varchar(100))
		INSERT INTO #LoanPurposeType
		SELECT 1, 'Owner-occupied'
		UNION ALL
		SELECT 2, 'Buy-to-let'
		UNION ALL
		SELECT 3, 'Right to Buy'
		UNION ALL
		SELECT 4, 'Second home'
		
		SELECT ISNULL(TypeName,'Total') AS '~HeaderText'
		,  ISNULL((SUM(CP.LoanCount)),0) AS 'Number'
		,  ISNULL(CAST(SUM(CP.TotalLoanCountPercent) AS decimal(38,8)),0) AS '% of Total Number'
		,  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalBalance) AS decimal(38,2)),0) AS 'Amount (GBP)'
		,  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalPercent) AS decimal(38,8)),0) AS '% of Total Amount'
		FROM #LoanPurposeType P
		LEFT JOIN #LoanPurposeData CP ON CP.SortOrder = P.SortOrder
		GROUP BY P.TypeName WITH rollup   
		 ORDER BY SUM(P.SortOrder)  

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetLoanPurposeType', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   

END

Go


