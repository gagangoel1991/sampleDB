
USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratFinalVerifiedLossDetermination]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratFinalVerifiedLossDetermination]
GO


SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------------------------------------------------------------  
  
  --Author: Mukesh Sharma
  --Date: 2023-01-27
  --Description:  Generating Strats for Details of Final Verified Loss Determination
  --exec  [corp].[spStratFinalVerifiedLossDetermination] @pAsAtDate='2023-01-31',@pDealId=1,@pUserName=null
------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [corp].[spStratFinalVerifiedLossDetermination]
(    @pAsAtDate DATE,
	 @pDealId INT ,
	 @pUserName VARCHAR(100)=NULL
)
AS
BEGIN
            
            DECLARE 
             @msgtxt VARCHAR(100) = ''
			,@DealIdS INT
			,@DealName Varchar(50)
		    ,@DealIdCommonSP INT
			,@ReqCols XML 
		    ,@RowID Varchar(100)   
			,@COUNT INT
			,@Initialze INT=1
			,@EffDate DATE
			,@BeforeDefaultdate DATE


    BEGIN TRY
    SET @msgtxt = 'Calculating variables  ' + CONVERT(VARCHAR(20), getdate(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	SET @DealIdCommonSP                    = @pDealId
	SET @DealName                          =(SELECT DealName from[corp].[syn_SfpModelCorporate_vw_dimCorporateDeal]		
											 WHERE DealId=@pDealId  AND IsActive='Y')
	SET @DealIdS                           =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)

   -- Storing  data from loss managment into temp dataset
	
	SELECT 
	 CASE WHEN FacilitySourceId = 2 THEN FacilityId + '\P' ELSE FacilityId END  AS [Reference Obligation ID]
	,@pDealId AS DealID
	,CONVERT(VARCHAR(50),NULL) AS [Reference Entity ID]
	,CONVERT(VARCHAR(50),NULL) AS [Reference Entity Group ID]
	,NULL AS [Reference Entity Sector]
	,CONVERT(DATE,NULL) AS [Reference Obligation Start Date]
	,DefaultDate AS [Reference Obligation Default Date]
	,CreditEventNoticeDate AS [Date of Credit Event Notice]
	,CreditEventVerifiedDate AS [Initial Verification Date]
	,FinalVerificationDate  AS [Final Verification Date]
	,CreditEventTypeId 
	,CONVERT(VARCHAR(50),CreditEventTypeId) AS [Type of Credit Event]
	,CONVERT(DECIMAL(23,2),NULL) AS [Initial Reference Obligation Notional Amount]
	,CONVERT(DECIMAL(23,2),DefaultedNotional) AS [Defaulted Notional Amount]
	,CONVERT(DECIMAL(23,2),NULL) AS [Reference Obligation Notional Amount at Liquidation]
	,CONVERT(DECIMAL(23,2),RealisedRecoveries) AS [Realised Recoveries] 
	,CONVERT(DECIMAL(23,2),FinalEstimatedRecoveries) AS [Final Estimated Recoveries]  
	,CONVERT(DECIMAL(23,2),TotalAdjustedRecoveries) AS [Total Recoveries] 
	,CONVERT(DECIMAL(23,2),InitialLossAmount) AS [Initial Loss Amount]
	,CONVERT(DECIMAL(23,2),InitialVerifiedLossAmount) AS  [Verified Loss Amount]
	,CONVERT(DECIMAL(23,2),TotalLossAmount) AS [Total Loss Amount] 
	,CONVERT(DECIMAL(23,2),CreditLossEventAmount) AS [Credit loss event Amount] 
	,CONVERT(DECIMAL(23,2),RestructuredPrincipalAmount) AS [Restructured Principal Amount] 
	,CONVERT(DECIMAL(10,4),NULL) AS [Final Loss %]
	INTO #Templossdata  
	FROM [corp].[LossManagement]
	WHERE dealid=@DealIdS 
	AND IsActive=1 AND WorkflowStepId IN(95,98)
	
	--- Updating Initial Rona and intial date of flagging

	UPDATE T
	SET 
	[Reference Obligation Start Date]=CONVERT(DATE,AssetCorp.OriginationDateAtFlagging)
	,[Initial Reference Obligation Notional Amount]=AssetCorp.RonaAtFlagging

	FROM #Templossdata AS T
	INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactCorporateAssetPool]  AS AssetCorp
	ON T.[Reference Obligation ID]=AssetCorp.FacilityId
    WHERE AssetCorp.PoolDeflaggingDateKey IS NULL

  --- Updating credit event type description

	UPDATE T
	SET 
	[Type of Credit Event]=LK.Reportvalue
	FROM #Templossdata AS T
	INNER JOIN [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  AS LK  
	ON T.CreditEventTypeId=LK.LookUpValue
	WHERE LK.ReportTemplateName='SFP+' and LK.LookUpName like 'CB Credit Event Type%'
		
		
---  Calculating Rona for each FinalVerificationdate
	SELECT DISTINCT [Reference Obligation ID],[Final Verification Date]
	INTO #TemRona 
	FROM #Templossdata 
	WHERE [Final Verification Date] IS NOT NULL

	SELECT ROW_NUMBER() OVER ( ORDER BY [Final Verification Date] ) AS RN,[Final Verification Date] 
	INTO #TempEffectivedates  
	FROM  (SELECT DISTINCT  [Final Verification Date]  FROM  #TemRona) AS R

	SET @COUNT =(SELECT COUNT(1) FROM #TempEffectivedates)

	WHILE (@COUNT >0)

	  BEGIN 
		SET	 @effdate=(SELECT [Final Verification Date] FROM #TempEffectivedates  WHERE RN=@initialze)
		UPDATE  T
		SET [Reference Obligation Notional Amount at Liquidation]=FinalResult.Rona
		FROM 
	    #Templossdata  AS T

		INNER JOIN
		(

		SELECT  DISTINCT tr.[Reference Obligation ID],bfd.Rona ,@effdate AS [Final Verification Date] FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] ff 
		INNER  JOIN ( SELECT [Reference Obligation ID] FROM  #TemRona  WHERE [Final Verification Date]= @effdate) AS tr
		ON ff.facilityid=tr.[Reference Obligation ID]  
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey  
		INNER JOIN  [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON ff.FacilityKey = dfac.FacilityKey
		WHERE bfd.DealKey =@pDealId and ff.PartitionId =CONVERT(VARCHAR(8),CAST(@effdate AS DATE),112)

		) AS FinalResult
		ON T.[Reference Obligation ID]=FinalResult.[Reference Obligation ID] AND T.[Final Verification Date]=FinalResult.[Final Verification Date]

		SET @COUNT=@COUNT-1
		SET @initialze=@initialze+1
 
	  END


	  ---  Calculating TTC_LGD for each DefaultDate
	SELECT DISTINCT [Reference Obligation ID],[Reference Obligation Default Date]
	INTO #TempDefault 
	FROM #Templossdata 
	WHERE [Reference Obligation Default Date] IS NOT NULL

	SELECT ROW_NUMBER() OVER ( ORDER BY [Reference Obligation Default Date] ) AS RN,[Reference Obligation Default Date]
	INTO #TempDefaultEffectivedates  
	FROM  (SELECT DISTINCT [Reference Obligation Default Date]  FROM  #TempDefault) AS R


	

  SET @COUNT =(SELECT COUNT(1) FROM #TempDefaultEffectivedates)
  SET @initialze=1

	WHILE (@COUNT >0)

	  BEGIN 
		SET	 @effdate=(SELECT [Reference Obligation Default Date] FROM #TempDefaultEffectivedates  WHERE RN=@initialze)
	    SET  @BeforeDefaultdate= (SELECT DATEADD(MONTH,-1,asatdate)FROM [sfp].[syn_SfpModel_vw_Calendar_v1]  WHERE asatdate=@effdate AND Regioncode='UK')
	    SET @BeforeDefaultdate=(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]   WHERE IsWorkingDay=1 AND MONTH(asatdate)=MONTH(@BeforeDefaultdate) AND YEAR(asatdate)=YEAR(@BeforeDefaultdate) AND Regioncode='UK')


		UPDATE  T
		SET [Final Loss %]=FinalResult.TTC_LGD
		FROM 
	    #Templossdata  AS T

		INNER JOIN
		(

		SELECT  DISTINCT tr.[Reference Obligation ID],cfd.TTC_LGD ,@effdate AS [Reference Obligation Default Date] FROM [corp].[syn_SfpModelCorporate_vw_CorpFacilityDetail] cfd 
		INNER  JOIN ( SELECT [Reference Obligation ID] FROM  #TempDefault  WHERE [Reference Obligation Default Date]= @effdate) AS tr
		ON cfd.facilityid=tr.[Reference Obligation ID]  
		WHERE  cfd.PartitionId =CONVERT(VARCHAR(8),CAST(@BeforeDefaultdate AS DATE),112)

		) AS FinalResult
		ON T.[Reference Obligation ID]=FinalResult.[Reference Obligation ID] AND T.[Reference Obligation Default Date]=FinalResult.[Reference Obligation Default Date]

		SET @COUNT=@COUNT-1
		SET @initialze=@initialze+1
 
	  END


	



		/*List of required Columns*/   
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','RiskParentCisCode','CIS') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId
			  ,RiskParentCisCode
			  ,CIS
		INTO #CommonSPdata
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

	--- Updating CIS and RiskParentCisCode

		UPDATE T
		SET 
		[Reference Entity ID]=CPData.CIS
		,[Reference Entity Group ID]=CPData.RiskParentCisCode
		FROM #Templossdata AS T
		INNER JOIN #CommonSPdata AS CPData
		ON REPLACE(T.[Reference Obligation ID],'\P','')=CPData.FacilityId


		CREATE TABLE #strats( 

        [Reference Obligation ID]  VARCHAR(50)
		,[Reference Entity ID] VARCHAR(50)
		,[Reference Entity Group ID] VARCHAR(50)
		,[Reference Entity Sector] VARCHAR(50)
		,[Reference Obligation Start Date] DATE
		,[Reference Obligation Default Date] DATE
		,[Date of Credit Event Notice] DATE
		,[Initial Verification Date] DATE
		,[Final Verification Date] DATE 
		,[Type of Credit Event]  VARCHAR(50)
		,[Initial Reference Obligation Notional Amount] DECIMAL(23,2)
		,[Defaulted Notional Amount] DECIMAL(23,2)
		,[Reference Obligation Notional Amount at Liquidation] DECIMAL(23,2)
		,[Realised Recoveries] DECIMAL(23,2)
		,[Final Estimated Recoveries]  DECIMAL(23,2)
		,[Total Recoveries] DECIMAL(23,2) 
		,[Initial Loss Amount] DECIMAL(23,2)
		,[Verified Loss Amount] DECIMAL(23,2)
		,[Total Loss Amount] DECIMAL(23,2)
		,[Credit loss event Amount]  DECIMAL(23,2)
		,[Restructured Principal Amount]  DECIMAL(23,2)
		,[Final Loss %]DECIMAL(10,4)

		)


		INSERT INTO #strats
		SELECT 
		[Reference Obligation ID]
		,[Reference Entity ID]
		,[Reference Entity Group ID]
		,[Reference Entity Sector]
		,[Reference Obligation Start Date]
		,[Reference Obligation Default Date]
		,[Date of Credit Event Notice]
		,[Initial Verification Date]
		,[Final Verification Date]
		,[Type of Credit Event]
		,[Initial Reference Obligation Notional Amount]
		,[Defaulted Notional Amount]
		,[Reference Obligation Notional Amount at Liquidation]
		,[Realised Recoveries]
		,[Final Estimated Recoveries] 
		,[Total Recoveries] 
		,[Initial Loss Amount]
		,[Verified Loss Amount]
		,[Total Loss Amount] 
		,[Credit loss event Amount] 
		,[Restructured Principal Amount] 
		,[Final Loss %]
		
		FROM #Templossdata  
		ORDER BY [Type of Credit Event]


		SELECT * FROM #strats ORDER BY [Type of Credit Event]

	   DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID


         /* Droping and creating temp tables */
  	IF OBJECT_ID('tempdb..#Templossdata') IS NOT NULL DROP TABLE #Templossdata
	IF OBJECT_ID('tempdb..#CommonSPdata') IS NOT NULL DROP TABLE #CommonSPdata

	IF OBJECT_ID('tempdb..#TemRona') IS NOT NULL DROP TABLE #TemRona
	IF OBJECT_ID('tempdb..#TempEffectivedates') IS NOT NULL DROP TABLE #TempEffectivedates
	IF OBJECT_ID('tempdb..#TempDefaultEffectivedates') IS NOT NULL DROP TABLE #TempDefaultEffectivedates
    IF OBJECT_ID('tempdb..#TempDefault') IS NOT NULL DROP TABLE #TempDefault
	IF OBJECT_ID('tempdb..#strats') IS NOT NULL DROP TABLE #strats


	SET @msgtxt = 'End of strats generation : ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	 END TRY
     BEGIN CATCH                  
     DECLARE       
	 @errorMessage     NVARCHAR(MAX),      
	 @errorSeverity    INT,      
	 @errorNumber      INT,      
	 @errorLine        INT,      
     @errorState       INT;  
	 DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
     EXEC app.SaveErrorLog 2, 1, 'spStratLossesCreditEventNotification', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName   
     RAISERROR (@errorMessage,  @errorSeverity,  @errorState )              
     END CATCH   

  END
GO


