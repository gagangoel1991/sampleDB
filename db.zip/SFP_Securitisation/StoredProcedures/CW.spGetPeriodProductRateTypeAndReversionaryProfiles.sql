USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetPeriodProductRateTypeAndReversionaryProfiles') IS NOT NULL
	DROP PROC CW.spGetPeriodProductRateTypeAndReversionaryProfiles
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
Author: Arun
Date:    26.05.2020
Description:  This will return Product Type and Reesion Profiles for Investor report.
Usage : CW.spGetPeriodProductRateTypeAndReversionaryProfiles @pAsAtDate  = '30-Nov-2020'
		,@pDealName  = 'DUNMORE1'  
		,@pUserName = NULL    		
		
		CW.spGetPeriodProductRateTypeAndReversionaryProfiles @pAsAtDate  = '30-Sep-2019'
		,@pDealName  = 'DUNMORE1'  
		,@pUserName = NULL   
		                                               
Change History
--------------
Author              Date                 Description
-------------------------------------------------------
*/
Create Proc CW.spGetPeriodProductRateTypeAndReversionaryProfiles @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
				
BEGIN TRY
  
  DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	, @totalSubAccounts float
	, @totalOutstandingCapitalBalance float
	, @totalTrueBalance float

	
	------------------ Fact_Mortgage for Current Business Reporting Date ------------------------------------------------------------      
	SELECT Distinct LoanId, SubAccountNumber, MortgageSubAccountKey, TotalOutstandingCapitalBalance, TrueBalance
	INTO #Mortgage 
	FROM CW.VwMortgageSubAccount VMS  
	WHERE VMS.partitionid = @partitionID_AsAtDate  
	AND VMS.DealName = @pDealName  

	CREATE CLUSTERED INDEX INDXLI ON #Mortgage  (LoanId, SubAccountNumber);     


	-------------------- Interest Rate Revesion --------------------------------------------------------------  
	Select  Distinct LoanId, SubAccountNumber, BaseRateCode, RevisionNumber, InterestRateKey
	into #InterestRate
	from sfp.syn_SfpModel_vw_InterestRateRevision
	where dealname = @pDealName  
	AND partitionid = @partitionID_AsAtDate   
	
	CREATE CLUSTERED INDEX INDXILI ON #InterestRate  (LoanId, SubAccountNumber);  
	---------------------------------------------------------------------------------------------

	
	---=FOR % of Total Current pool of Mortgage
	SELECT @totalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0))
		, @totalTrueBalance  = ISNULL(SUM(M.TrueBalance), 0)  
	FROM   #Mortgage M
	
	
	--==========================#TempLookup for Morgage SubAccount
	Create Table #TempLookup (ProductType varchar(100), LookupValue varchar(100))
	Insert into #TempLookup (ProductType, LookupValue)
	Values 
		('Fixed Rate', 'ZERO'),
		('SVR', 'SVR'),
		('ECB Tracker', 'ECBR'),
		('Other', Null)


	Select ProductType, count(M.MortgageSubAccountKey) AS MortgageCount
	, ISNULL(CAST( Case when @totalSubAccounts > 0 Then  Cast( (COUNT(MortgageSubAccountKey) / @totalSubAccounts  * 100) as Decimal(10,2)) Else 0 End as Float) , 0) as MortgageLoansPercent  
	, ISNULL(sum(M.TotalOutstandingCapitalBalance),0) AS TotalOutstandingCapitalBalance 
	, ISNULL(Cast( Case when @totalOutstandingCapitalBalance > 0 Then  Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) *100 as Decimal(10,2)) Else 0 End  as Float)  ,0) TotalOutCapitalBalancePercent
	, IsNull(sum(M.TrueBalance),0) AS TrueBalance 
	, ISNULL(Cast( Case when @totalTrueBalance > 0 Then (sum(TrueBalance) / @totalTrueBalance ) *100 Else 0 End  as Decimal(10,2)),0) TrueBalancePercent
	From #TempLookup T
	Left Join #InterestRate I ON T.LookupValue = Case When T.LookupValue is not null Then  I.BaseRateCode
														Else T.LookupValue End
	Left join #Mortgage M on M.LoanId = I.LoanId AND M.SubAccountNumber = i.SubAccountNumber 
	Where I.RevisionNumber = 0  
	Group by All ProductType
	
    
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetPeriodProductRateTypeAndReversionaryProfiles', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END

GO
