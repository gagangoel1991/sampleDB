USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetForberanceMonthsInArrear', 'P') IS NOT NULL
 DROP PROC  CW.spGetForberanceMonthsInArrear;

GO
  
/*  
 * Author: Arun  
 * Date:    26.05.2020  
 * Description:  This will return Forbearance - Month In Arrears for Investor report.  
 * Usage : CW.spGetForberanceMonthsInArrear @pAsAtDate  = '26-FEB-2021'  
 *   ,@pDealName  = 'DUNMORE1' 
 *   ,@pUserName = NULL                                                    
 * Change History  
 * --------------  
 * Author              Date                 Description  
 * -------------------------------------------------------  
*/   
CREATE PROC CW.spGetForberanceMonthsInArrear @pAsAtDate DATE  
  ,@pDealName VARCHAR(255) 
  ,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY   
  ,@pUserName VARCHAR(50) = NULL    
  
AS  
BEGIN  
      
      
BEGIN TRY  
  
       
 DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))  
 ,@ipdStartDate DATE    
 ,@ipdEndDate DATE        
 ,@ipdTemp DATE    
 ,@ipdDaysTemp INT    
 ,@totalSubAccounts float, @totalOutstandingCapitalBalance float, @totalTrueBalance float
 ,@currentTotalSubAccounts float, @currentTotalOutstandingCapitalBalance float , @currentTotalTrueBalance float 
 ,@cameOutTotalSubAccounts float, @cameOutTotalOutstandingCapitalBalance float , @cameOutTotalTrueBalance float 
 ,@neverTotalSubAccounts float, @neverTotalOutstandingCapitalBalance float  , @neverTotalTrueBalance float 
 ,@dealId INT;
  


	--Drop temp tabe if exist
	IF OBJECT_ID('tempdb..#Forbearance')			 IS NOT NULL DROP TABLE #Forbearance
	IF OBJECT_ID('tempdb..#CurrentFB')			 IS NOT NULL DROP TABLE #CurrentFB
	IF OBJECT_ID('tempdb..#CameOutFB')			 IS NOT NULL DROP TABLE #CameOutFB
	IF OBJECT_ID('tempdb..#NeverFB')				 IS NOT NULL DROP TABLE #NeverFB
	IF OBJECT_ID('tempdb..#TempCurrentFB')		 IS NOT NULL DROP TABLE #TempCurrentFB
	IF OBJECT_ID('tempdb..#TempNeverFB')			 IS NOT NULL DROP TABLE #TempNeverFB
	IF OBJECT_ID('tempdb..#FinalCurrentFB')		 IS NOT NULL DROP TABLE #FinalCurrentFB
	IF OBJECT_ID('tempdb..#FinalCameOutFB')		 IS NOT NULL DROP TABLE #FinalCameOutFB
	IF OBJECT_ID('tempdb..#FinalNeverFB')			 IS NOT NULL DROP TABLE #FinalNeverFB



	--get our partition id's that we are interested in            
	SET @partitionID_AsAtDate = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112));      
	SET @ipdTemp = sfp.syn_SfpModel_FnPreviousReportDate (@pAsAtDate,2)     
	SET @ipdDaysTemp = day(@ipdTemp)    
	SET @ipdStartDate = dateadd(dd,-(@ipdDaysTemp-1), @ipdTemp)     
	SET @ipdEndDate = sfp.syn_SfpModel_FnPreviousReportDate (@pAsAtDate,0)   
     
 
	SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1 

	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId

 

	SELECT MortgageSubAccountKey, ForbearanceKey, FORBEARANCE_TYPE AS ForbearanceType, FORBEARANCE_COUNTER AS ForbearanceCounter, FORBEARANCE_STATUS AS forbearanceStatus
	, CURRENT_CAPITALISATION_DATE AS CapitalisationDate, CURRENT_TERM_EXT_DATE AS TermExtensionDate
	, FIRST_FORBEARANCE_START_DATE AS FirstForbearanceStartDate, CURRENT_FORBEARANCE_END_DATE AS CurrentForbearanceEndDate, Forbearance_AsAtDateFrom AS AsAtDateFrom, Forbearance_AsAtDateTo AS AsAtDateTo
	, Outstandng_Capital_Balance_Amt AS TotalOutstandingCapitalBalance, True_Balance_Amt AS TrueBalance
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MONTHS_IN_ARREARS ) AS BandRange  
	INTO #Forbearance 
	FROM #VwMortgageSubAccount	
	   

	CREATE CLUSTERED INDEX FB ON #Forbearance  (forbearancekey);       

	---=For Currently in Forbearance ---    
	SELECT MortgageSubAccountKey, ForbearanceKey, FirstForbearanceStartDate, CurrentForbearanceEndDate, forbearanceStatus, ForbearanceCounter 
	INTO #CurrentFB    
	FROM #Forbearance f  
	WHERE f.ForbearanceStatus = 'L'  AND f.ForbearanceCounter > 0    
	--AND f.AsAtDateFrom <= @pAsAtDate  AND f.AsAtDateTo > @pAsAtDate    
	--AND f.ForbearanceKey <> - 1    
	AND FirstForbearanceStartDate <= @pAsAtDate
	AND CurrentForbearanceEndDate >= @pAsAtDate 
	 
	CREATE CLUSTERED INDEX CR ON #CurrentFB  (forbearancekey);       
	  
	---=For Came out of Forbearance ----    

	SELECT MortgageSubAccountKey, ForbearanceKey, FirstForbearanceStartDate, CurrentForbearanceEndDate, forbearanceStatus, ForbearanceCounter 
	INTO #CameOutFB   
	FROM #Forbearance f   
	WHERE f.ForbearanceStatus IN ('S', 'C') AND f.ForbearanceCounter > 0    
--	AND f.ForbearanceKey <> - 1    
	 
	CREATE CLUSTERED INDEX CO ON #CameOutFB   (forbearancekey);       
	  
	/*    
	Verifying and inserting (came out of forbearance), if any loan enters and exits forbearance within the same period    
	as it should not appear as being in forbearance i.e. Currently in forbearance    
	*/    
	
	INSERT INTO #CameOutFB   
	(MortgageSubAccountKey, ForbearanceKey, FirstForbearanceStartDate, CurrentForbearanceEndDate, forbearanceStatus, ForbearanceCounter)          
	SELECT MortgageSubAccountKey, ForbearanceKey, FirstForbearanceStartDate, CurrentForbearanceEndDate, forbearanceStatus, ForbearanceCounter    
	FROM  #Forbearance f     
	WHERE ForbearanceCounter > 0  AND forbearanceStatus= 'L'      
	AND FirstForbearanceStartDate <= @pAsAtDate
	AND CurrentForbearanceEndDate < @pAsAtDate 
	


 
	--- For Never in Forbearance ---    
	SELECT MortgageSubAccountKey, ForbearanceKey, FirstForbearanceStartDate, CurrentForbearanceEndDate, forbearanceStatus, ForbearanceCounter 
	INTO #NeverFB  
	FROM #Forbearance f
	WHERE ForbearanceCounter = 0 

	CREATE CLUSTERED INDEX NV ON #NeverFB   (forbearancekey);   

	--Select * From #CurrentFB  
	--=FOR % of Total pool of assets  
	SELECT @totalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @totalOutstandingCapitalBalance = SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0))  
	, @totalTrueBalance  = ISNULL(SUM(FB.TrueBalance), 0)  
	FROM   #Forbearance FB  

	---=For Currently in Forbearance ============================================================  
	SELECT @currentTotalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @currentTotalOutstandingCapitalBalance = SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0)) 
	, @currentTotalTrueBalance  = ISNULL(SUM(FB.TrueBalance), 0)    
	FROM   #Forbearance FB  
			   INNER JOIN #CurrentFB AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey   
	             
	--Select * From #CameOutFB  
	---=For Came out of Forbearance ============================================================  
	SELECT @cameOutTotalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @cameOutTotalOutstandingCapitalBalance = SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0))    
	, @cameOutTotalTrueBalance  = ISNULL(SUM(FB.TrueBalance), 0) 
	FROM   #Forbearance FB  
			   INNER JOIN #CameOutFB AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey    

	--Select * From #NeverFB  
	---=For Never in Forbearance ============================================================  
	SELECT @neverTotalSubAccounts = COUNT(ISNULL(FB.MortgageSubAccountKey, 0))    
	, @neverTotalOutstandingCapitalBalance = SUM(ISNULL(FB.TotalOutstandingCapitalBalance, 0)) 
	, @neverTotalTrueBalance  = ISNULL(SUM(FB.TrueBalance), 0)    
	FROM   #Forbearance FB  
			   INNER JOIN #NeverFB AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey    



	SELECT @pDealName AS DealName, FB.ForbearanceKey, FB.MortgageSubAccountKey, FB.TotalOutstandingCapitalBalance AS TotalOutstandingCapitalBalance, TrueBalance  
	, BandRange  
	INTO #TempCurrentFB  
	FROM   #Forbearance FB  
			   INNER JOIN #CurrentFB AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey  
	             
	SELECT @pDealName AS DealName, FB.ForbearanceKey, FB.MortgageSubAccountKey, FB.TotalOutstandingCapitalBalance AS TotalOutstandingCapitalBalance, TrueBalance  
	, BandRange  
	INTO #TempCameOutFB  
	FROM   #Forbearance FB  
			   INNER JOIN #CameOutFB AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey                 

	SELECT @pDealName AS DealName, FB.ForbearanceKey, FB.MortgageSubAccountKey, FB.TotalOutstandingCapitalBalance AS TotalOutstandingCapitalBalance, TrueBalance  
	, BandRange  
	INTO #TempNeverFB  
	FROM   #Forbearance FB  
			   INNER JOIN #NeverFB AS CFB ON FB.MortgageSubAccountKey = CFB.MortgageSubAccountKey    
	             

	SELECT SortOrder,dans.DisplayName 'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]  
	, ISNULL(CAST( CASE WHEN @currentTotalSubAccounts> 0 THEN  Cast( ( count(MortgageSubAccountKey) / @currentTotalSubAccounts  ) AS Decimal(38,18)) ELSE 0 END  AS Decimal(38,8) ) , 0)  AS MortgageLoansPercent    
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2) ) , 0) 'TotalOutCapitalBalance'   
	, ISNULL(CAST( CASE WHEN @currentTotalOutstandingCapitalBalance> 0 THEN  Cast( (sum(TotalOutstandingCapitalBalance) / @currentTotalOutstandingCapitalBalance )  AS Decimal(38,18)) ELSE 0 END  AS Decimal(38,8) ) , 0) TotalOutCapitalBalancePercent    
	, ISNULL(CAST(Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance )  AS Decimal(38,18)) AS Decimal(38,8) ) , 0) [TotalAssetPoolAmountPercent]  
	, ISNULL(CAST(sum(TrueBalance) AS Decimal(38,2) ) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @currentTotalTrueBalance> 0 THEN  Cast( (sum(TrueBalance) / @currentTotalTrueBalance)  AS Decimal(38,18))  ELSE 0 END  AS Decimal(38,8) ) , 0) TrueBalancePercent  
	INTO #FinalCurrentFB  
	FROM @pStratRangeData dans   
	LEFT JOIN #TempCurrentFB T ON T.BandRange = dans.DisplayName   
	GROUP BY dans.DisplayName , dans.SortOrder   
	ORDER BY dans.SortOrder;  


	SELECT SortOrder,dans.DisplayName 'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]  
	, ISNULL(CAST(  CASE WHEN @cameOutTotalSubAccounts> 0 THEN Cast( ( count(MortgageSubAccountKey) / @cameOutTotalSubAccounts ) AS Decimal(38,18)) ELSE 0 END   AS Decimal(38,8) ) , 0)  AS MortgageLoansPercent    
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2) ) , 0) 'TotalOutCapitalBalance'     
	, ISNULL(CAST(  CASE WHEN @cameOutTotalOutstandingCapitalBalance> 0 THEN Cast( (Sum(TotalOutstandingCapitalBalance) / @cameOutTotalOutstandingCapitalBalance )  AS Decimal(38,18)) ELSE 0 END  AS Decimal(38,8) ) , 0) TotalOutCapitalBalancePercent    
	, ISNULL(CAST(  CASE WHEN @totalOutstandingCapitalBalance> 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance )  AS Decimal(38,18))  ELSE 0 END AS Decimal(38,8) ) , 0) [TotalAssetPoolAmountPercent]  
	, ISNULL(CAST(sum(TrueBalance) AS Decimal(38,2) ) , 0)  TrueBalance
	, ISNULL(CAST(  CASE WHEN @cameOutTotalTrueBalance> 0 THEN  Cast( (sum(TrueBalance) / @cameOutTotalTrueBalance)  AS Decimal(38,18))  ELSE 0 END  AS Decimal(38,8) ) , 0) TrueBalancePercent  
	INTO #FinalCameOutFB  
	FROM @pStratRangeData dans   
	LEFT JOIN #TempCameOutFB T ON T.BandRange = dans.DisplayName   
	GROUP BY dans.DisplayName , dans.SortOrder   
	ORDER BY dans.SortOrder;  

	SELECT SortOrder,dans.DisplayName 'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]  
	, ISNULL(CAST(  CASE WHEN @neverTotalSubAccounts> 0 THEN Cast( ( count(MortgageSubAccountKey) / @neverTotalSubAccounts ) AS Decimal(38,18))  ELSE 0 END  AS Decimal(38,8) ) , 0)  AS MortgageLoansPercent    
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Decimal(38,2) ) , 0) 'TotalOutCapitalBalance'    
	, ISNULL(CAST(  CASE WHEN @neverTotalOutstandingCapitalBalance> 0 THEN  Cast( (Sum(TotalOutstandingCapitalBalance) / @neverTotalOutstandingCapitalBalance )  AS Decimal(38,18)) ELSE 0 END  AS Decimal(38,8) ) , 0) TotalOutCapitalBalancePercent    
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance> 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance )  AS Decimal(38,18))  ELSE 0 END AS Decimal(38,8) ) , 0) [TotalAssetPoolAmountPercent]  
	, ISNULL(CAST(sum(TrueBalance) AS Decimal(38,2) ) , 0)  TrueBalance
	, ISNULL(CAST(  CASE WHEN @neverTotalTrueBalance> 0 THEN Cast( (sum(TrueBalance) / @neverTotalTrueBalance) AS Decimal(38,18))  ELSE 0 END  AS Decimal(38,8) ) , 0) TrueBalancePercent  
	INTO #FinalNeverFB  
	FROM @pStratRangeData dans   
	LEFT JOIN #TempNeverFB T ON T.BandRange = dans.DisplayName   
	GROUP BY dans.DisplayName , dans.SortOrder   
	ORDER BY dans.SortOrder;    

	SELECT 
	IIF(CRNT.HeaderText IS NULL, 'Total',( IIF(CRNT.HeaderText = '<=0','Current', CRNT.HeaderText+' Months in Arrears'))) AS '~HeaderText',
	SUM(CRNT.[MortgageLoans]) AS 'Number of Mortgage Loans~CurrentlyInForbearance', 
	CAST(SUM(CRNT.TotalOutCapitalBalance) AS Float) AS 'Amount (EUR)~CurrentlyForbearance', 
	--CRNT.TotalOutCapitalBalancePercent, 
	CAST(SUM(CRNT.[TotalAssetPoolAmountPercent]) AS Float) AS 'Amount as % of total pool assets~CurrentlyInForbearance', 
	SUM(CMO.[MortgageLoans]) AS 'Number of Mortgage Loan~CameOutOfForbearances', 
	CAST(SUM(CMO.TotalOutCapitalBalance)AS Float)  AS 'Amount (EUR)~CameOutOfForbearances', 
	--CMO.TotalOutCapitalBalancePercent,
	CAST(SUM(CMO.[TotalAssetPoolAmountPercent]) AS Float) AS 'Amount as % of total pool assets~CameOutOfForbearances', 
	SUM(NVR.[MortgageLoans]) AS 'Number of Mortgage Loans~NeverInForbearance', 
	CAST(SUM(NVR.TotalOutCapitalBalance)AS Float)  AS 'Amount (EUR)~NeverInForbearance', 
	--NVR.TotalOutCapitalBalancePercent, 
	CAST(SUM(NVR.[TotalAssetPoolAmountPercent])AS Float)  AS 'Amount as % of total pool assets~NeverInForbearance', 
	CAST(SUM(CRNT.[TotalAssetPoolAmountPercent])+SUM(CMO.[TotalAssetPoolAmountPercent])+SUM(NVR.[TotalAssetPoolAmountPercent])AS Float)  AS 'Amount as % of total pool assets~Total' 
	FROM #FinalCurrentFB CRNT  
	INNER JOIN #FinalCameOutFB CMO ON CRNT.HeaderText = CMO.HeaderText  
	INNER JOIN #FinalNeverFB NVR ON CRNT.HeaderText = NVR.HeaderText
	GROUP BY CRNT.HeaderText WITH ROLLUP
	ORDER BY SUM(CRNt.SortOrder)+SUM(CMO.SortOrder)+SUM(NVR.SortOrder)


END TRY  
BEGIN CATCH  
    DECLARE   
                @errorMessage     NVARCHAR(MAX),  
                @errorSeverity    INT,  
                @errorNumber      INT,  
                @errorLine        INT,  
                @errorState       INT;  
  
    SELECT   
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()  
  
    EXEC app.SaveErrorLog 1, 1, 'spGetForberanceMonthsInArrear', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
    RAISERROR (@errorMessage,  
                @errorSeverity,  
                @errorState )  
END CATCH     
END  

GO