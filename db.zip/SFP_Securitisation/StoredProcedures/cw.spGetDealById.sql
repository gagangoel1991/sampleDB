USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cw].[spGetDealById]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealById]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetDealById] 
  
--==================================  
--Author: Gunjan Chandola  
--Date: 10-01-2021  
--Description:  Get Deal By Deal Id  
  
  -- [cw].[spGetDealById] 15,''
--==================================  
       @pDealId INT,  
       @pUserName VARCHAR(80)  
AS  
BEGIN  
 BEGIN TRY    
   SELECT   
		   d.[DealId] 
		  ,[DealName]  
		  ,[DealPublicName]  
		  ,[InternalDealName]  
		  ,d.[Description] 
		  ,[OwnerName]  
		  ,[BusinessAreaId]  
		  ,[DealTypeId]  
		  ,[DealStatusId]
		  ,wrkStp.DisplayName AS [DealStatus]
		  ,[ClosingDate]  
		  ,[DealMaturityDate]  
		  ,IsNull([FirstIpdDate] ,'1900-01-01') AS [FirstIpdDate]
		  ,[CashCollectionStartDate]  
		  ,[IpdFrequencyId]  
		  ,[DealCurrencyId]  
		  ,[JurisdictionMarkerId]  
		  ,[FurtherAdvancesAutoTopUpFlagId]  
		  ,[BalanceTransferAutoTopUpFlagId]  
		  ,[MortgageAutoTopUpFlagId]   
		  ,[DealAccountingTypeId]
		  ,act.Comment AS AuthorizerComment
		  ,act.ActionedBy AS WorkflowActionedBy
		  ,act.ActionedDate AS WorkflowActionedDate
		  ,d.ModifiedBy
		  ,d.ModifiedDate
		  ,d.CreatedBy
		  ,d.EarlyRedemptionDate
		  ,CAST(IIF(cwDeal.DealId IS NULL,0,1) AS BIT) IsCwDeal	
		  ,RedactedFacilityIds
		  ,RiskRetentionPercent 
		  ,RiskRetentionMethodId 
		  ,RiskRetentionHolderId 
		  ,RonaCalculatedBasedOnId
		  ,FxRateDate
		  ,FacilitySharingAllowedId
		  ,EnableHistoricFlaggingId
		  ,FacilityPercentChangeAllowedId
		  ,LegalRetentionPercent
		  ,CashReportingFlagId
		  ,DealInitialSize
		  ,TopupEndDate
		  ,TopupFlagId
		  ,AssetClassId
		 ,d.ReportingContactTelephone as ReportingEntityContactTelephone
		 ,d.ReportingContactPerson as ReportingEntityContactPerson
		 ,d.ReportingContactEmail as ReportingEntityContactEmail
		FROM 
			[cfg].[Deal] d
		JOIN	
			cfgCW.WorkflowStep wrkStp ON d.DealStatusId = wrkStp.WorkflowStepId
		JOIN 
			cfgCW.WorkflowType wrkType ON wrkStp.WorkflowTypeId = wrkType.WorkflowTypeId  
		LEFT JOIN
			[cw].[vwWorkFlowLastAction] act ON act.WorkflowStepId = wrkStp.WorkflowStepId 
			AND act.WorkflowTypeName = wrkType.Name AND act.ProcessReferenceId = d.DealId
		LEFT JOIN 
			cfgCW.CashWaterfallDeal cwDeal ON cwDeal.DealId = d.DealId
		WHERE 
			d.DealId = @pDealId 
			AND wrkType.Name='New_Deal_Onboarding'  
 END TRY  
 BEGIN CATCH  
  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  IF @@TRANCOUNT > 0  
  EXEC app.SaveErrorLog 2, 1, 'cw.spGetDealById', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH;  
END  
GO
