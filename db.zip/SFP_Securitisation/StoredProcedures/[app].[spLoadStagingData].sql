USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spLoadStagingData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[spLoadStagingData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spLoadStagingData]
(	
	@pUserName VARCHAR(50),
	@pFileInfoId INT,
	@pReturnValue INT = 0 OUTPUT
)      
AS      
BEGIN      
	BEGIN TRY  
		DECLARE @StagingProcName VARCHAR(1000) = (SELECT LoadStagingOnUIProcName FROM app.FileWorkFlowConfig 
											WHERE FileInfoId = @pFileInfoId);		
		DECLARE @Sql NVARCHAR(MAX);

		IF (@StagingProcName <> '')
		BEGIN
			SET @Sql = N'EXEC ' +@StagingProcName;			
			EXEC sp_executesql @Sql;
		END
		ELSE
		BEGIN
			SET @pReturnValue = -1;
		END 
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spLoadStagingData', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO
