USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spResetDealIpd') IS NOT NULL
	DROP PROCEDURE cb.spResetDealIpd
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spResetDealIpd]
(
	@pDealId SMALLINT,  
	@pIpdDate  DATETIME, 
	@pUserName	VARCHAR(80),
	@pResultCode INT OUTPUT 
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  23.03.2022
 *   Description:  Reset IPD. 
 *   NOTE: THIS MUST BE SAME AS INITIATE IPD. ANY CHANGE IN INITIATE MUST BE ANALYSED HERE AS WELL.
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *    
 *   DECLARE @pResultCode INT         
 *   exec cb.spResetDealIpd	6,'2021-05-24','fm\shriyad',@pResultCode OUTPUT
 *   Select @pResultCode
 *              
  */ 
)         
AS    
BEGIN   
 BEGIN TRY   
  DECLARE  
   @dealIpdRunId   INT,  
   @dealIpdId    INT  
  
  SELECT @dealIpdRunId = dir.RunId, @dealIpdId = di.DealIpdId FROM cw.DealIpd di  
  JOIN cw.DealIpdRun dir ON dir.DealIpdId = di.DealIpdId  
  WHERE  
   di.DealId = @pDealId  
   AND di.IpdDate = @pIpdDate  
   AND dir.IsCurrentVersion = 1  
  
  IF (SELECT ISNULL(IsIpdRunning,0) FROM cw.DealIPDRun WHERE Runid = @dealIpdRunId)<>0 
    BEGIN 
      SET @pResultCode=112 --Reset in progress
      RETURN 
    END

  --Firstly update the IPD status as Reset    
  UPDATE cw.DealIPDRun SET IsIpdRunning = 1, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE Runid = @dealIpdRunId

  -- Step 1 - Reset the IPD Summary Line Items  
  UPDATE disls SET disls.[Status] = disl.[DefaultStatus], ModifiedBy = @pUserName, ModifiedDate=GETDATE() FROM [cw].[DealIpdSummaryLineItemStatus] disls       
  JOIN [cfgCW].[DealIpdSummaryLineItem] disl ON disl.DealIpdSummaryLineItemId = disls.DealIpdSummaryLineItemId      
  WHERE disl.DealId = @pDealId AND disls.DealIpdRunId = @dealIpdRunId  
  
  --Step 2 - Removed IR entry from IR Location table  
  DELETE FROM cw.DealIpdIrLocation WHERE DealIpdId = @dealIpdId  
  
  -- Step 3 - Reset the Adjustments  
  UPDATE cw.WaterfallLineItemAmount SET AdjustedAmount = 0, TotalRequiredAmount = RequiredAmount, AdjustmentBy=NULL, AdjustmentDate=NULL,
  ModifiedBy=NULL , ModifiedDate=NULL  
  WHERE DealIpdRunId = @dealIpdRunId  
  
  --Step 4 - Reset the Automated Data/Ratings  
  EXEC [cw].[spResetModifiedAutomatedData] @pWorkflowType='',@pIPDRunId =@dealIpdRunId, @pUserName = @pUserName
 
  --Step 5 - Reset Non Rating Triggers
  EXEC [cw].[spResetNonratingTriggers] @pDealId,@dealIpdRunId,@pUserName

   --Step 6- Clear Waterfall Output 
  EXEC [cb].[spClearWaterfallOutput] @pDealId, @pIpdDate, @dealIpdRunId, @pUserName

  --Step 7 - Now reinitiate the IPD  
  EXEC [cb].[spInitiateIpd] @pDealId, @pIpdDate, @pUserName,'Reset', @pResultCode OUTPUT 

  --Step 8 - Updating the IPD Summary line item status
  EXEC [cw].[spUpdateIpdSummaryLineItemStatus] @dealIpdRunId, '', @pUserName

   EXEC [cw].[spReCalculateIpd] @dealIpdRunId, @pUserName, @pResultCode OUTPUT

   UPDATE cw.DealIPDRun SET IsIpdRunning = 0, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE RunId = @dealIpdRunId

 END TRY      
 BEGIN CATCH    
  IF @@TRANCOUNT > 0  
    ROLLBACK TRAN

    UPDATE cw.DealIPDRun SET IsIpdRunning = 0, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE Runid = @dealIpdRunId  
  DECLARE     
   @errorMessage     NVARCHAR(MAX),    
   @errorSeverity    INT,    
   @errorNumber      INT,    
   @errorLine        INT,    
   @errorState       INT;    
    
  SELECT     
  @errorMessage = ERROR_MESSAGE()
  ,@errorSeverity = ERROR_SEVERITY()
  ,@errorNumber = ERROR_NUMBER()
  ,@errorLine = ERROR_LINE()
  ,@errorState = ERROR_STATE()    
    
  EXEC app.SaveErrorLog 1, 1, '[cb].[spResetDealIpd]', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName    
      
  RAISERROR (@errorMessage, @errorSeverity,@errorState )    
 END CATCH    
END
GO