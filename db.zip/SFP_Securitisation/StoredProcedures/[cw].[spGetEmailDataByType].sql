USE SFP_Securitisation 

GO


IF OBJECT_ID('[cw].[spGetEmailDataByType]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetEmailDataByType]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Rajesh Sahu  
Date:    19.09.2022  
Description:  This will return Email data by email type.  
Usage : Exec [cw].[spGetEmailDataByType]  '1',''         

Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  
CREATE PROCEDURE [cw].[spGetEmailDataByType] 
   @pEmailTypeId INT,
   @pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
	BEGIN TRY
		SELECT 
			TOP 1
			ec.EmailConfigId
			,ec.EmailTypeId
			,et.DisplayName AS EmailType
			,ec.InternalName
			,ec.DisplayName
			,ec.EmailFrom
			,ec.EmailTo
			,ec.EmailCC
			,ec.EmailBCC
			,ec.EmailSubject
			,ec.EmailBody
			,ec.EmailImportance
			,CASE WHEN ec.EmailImportance=1 THEN 'High' ELSE 'Normal' END AS EmailImportanceText
			,ec.EmailFormat
			,ec.Attachment
			,CASE WHEN ec.Attachment=1 THEN 'Yes' ELSE 'No' END AS AttachmentText
			,ec.IsActive
			,CASE WHEN ec.IsActive=1 THEN 'Active' ELSE 'Inactive' END AS ActiveStatus
			,ec.CreatedBy
			,ec.CreatedDate
			,ec.ModifiedBy
			,ec.ModifiedDate
				
		FROM [cfg].[EmailConfiguration] ec
			INNER JOIN [cfg].EmailType et
			ON et.EmailTypeId=ec.EmailTypeId
		WHERE ec.IsActive = 1 AND ec.EmailTypeId = @pEmailTypeId
	END TRY
	
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetEmailDataByType', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH

END

GO
