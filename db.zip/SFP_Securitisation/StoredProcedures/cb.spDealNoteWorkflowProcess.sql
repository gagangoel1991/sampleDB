USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spDealNoteWorkflowProcess]') IS NOT NULL
	DROP PROCEDURE [cb].[spDealNoteWorkflowProcess]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--================================== 
/* 
--Author: RAVINDRA SINGH  
--Date: 10-07-2022 
--Description:  update  WorkflowStep in DealNote WIP
DECLARE  @pReturnCode TINYINT 
EXEC [cb].[spDealNoteWorkflowProcess] 68,'Test Approve' ,'Europa\singrfr'
Select @pReturnCode
--not authorized 

*/
--==================================   
CREATE PROCEDURE [cb].[spDealNoteWorkflowProcess]
	 @pDealStatusId TINYINT
	 ,@pAuthorizerComment VARCHAR(max) = NULL
	 ,@pUserName VARCHAR(256)
	 ,@pReturnCode SMALLINT = - 1 OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @workflowType VARCHAR(100) = 'New_Deal_Onboarding'
			,@stepName VARCHAR(50)
			,@dealId INT
			,@NewRedemptionDate DATE
			,@NewRedemptionDateIpd DATE
		SELECT @stepName = StepName
		FROM cfgCW.WorkflowStep
		WHERE WorkflowStepId = @pDealStatusId

		DECLARE @dealStatusID INT = cw.fnGetWorkflowStepId(@stepName, @workflowType)

		SELECT TOP 1   @dealId = DealId FROM cfgcb.DealNote	WHERE DealId = 6

		IF EXISTS (
				SELECT 1
				FROM cfgcb.DealNote_WIP
				WHERE  IsActive = 1
				) --DRAFT
		BEGIN
			UPDATE cfgcb.DealNote_WIP
			SET DealStatusId = @pDealStatusId
				,ChangeReason = @pAuthorizerComment
				,ModifiedDate = GETDATE()
				,ModifiedBy= @pUserName
			WHERE  isActive=1

			IF @stepName = 'AuthorisedUpdateDeal'
				BEGIN

				SELECT @NewRedemptionDate = NewRedemptionDate from cfgcb.DealNote_WIP WHERE DealStatusId = @pDealStatusId

				SELECT @NewRedemptionDateIpd = cw.fnGetBusinessDate(datefromparts(year(DATEADD(month, -1, @NewRedemptionDate)), month(DATEADD(month, -1, @NewRedemptionDate)),22),'UK',0,0) 
				
					UPDATE dn
						SET dn.NewRedemptionDate =  wp.NewRedemptionDate
						,dn.NewRedemptionIpd = @NewRedemptionDateIpd
						,dn.ModifiedBy=wp.ModifiedBy
						,dn.ModifiedDate=wp.ModifiedDate
					FROM cfgcb.DealNote	dn JOIN cfgcb.DealNote_WIP wp
						on dn.DealNoteId	= wp.DealNoteId
						and DealStatusId = @pDealStatusId AND wp.isActive=1

			
				END

			IF @stepName = 'Recall'
				BEGIN	
				
					UPDATE wp
						SET   wp.NewRedemptionDate =dn.NewRedemptionDate
							,wp.ModifiedBy = dn.ModifiedBy
							,wp.ModifiedDate = dn.ModifiedDate
					FROM cfgcb.DealNote_WIP wp JOIN cfgcb.DealNote	dn 
							on dn.DealNoteId	= wp.DealNoteId
							AND wp.isActive=1				
				END

			EXEC [cb].[spManageDealNoteWorkflowProcess] 
			     @dealId =@dealId
				 ,@pWorkFlowStepId = @pDealStatusID
				,@pAuthorizerComment = @pAuthorizerComment
				,@pUserName = @pUserName
				,@pReturnCode = @pReturnCode OUT
		END


		
	  SET @pReturnCode = 1
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spDealNoteWorkflowProcess'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)

		SET @pReturnCode = - 1
	END CATCH
END
GO


