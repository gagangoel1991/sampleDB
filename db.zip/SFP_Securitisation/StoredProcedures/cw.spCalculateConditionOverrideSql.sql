USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculateConditionOverrideSql') IS NOT NULL
	DROP PROCEDURE cw.spCalculateConditionOverrideSql
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculateConditionOverrideSql
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  09.08.2021
 *   Description:  
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *      
 * 	 
 * 	 cw.spCalculateConditionOverrideSql32,'fm\shriyad'
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80)
)
AS
BEGIN
	BEGIN TRY
		--DECLARE @pDealIpdRunId INT = 32, @pUserName	VARCHAR(80) ='fm\shriyad'

		DECLARE @DealId smallInt,
		@tempId INT,
		@dynsql nvarchar(500)  ,
		@params nvarchar(500), 
		@returnValue AS BIT,
		@spName VARCHAR(MAX)

		SET @DealId  = (SELECT DealId FROM cw.vwdealipdrun WHERE DealIpdRunId = @pDealIpdRunId);

		IF OBJECT_ID('tempdb..#temp') IS NOT NULL DROP TABLE #temp

		SELECT DealConditionCriteriaId, dcc.OverrideSQL,
		CONVERT(BIT,NULL) AS ResultedStatus
		INTO #temp 
		FROM 
		cfgcw.DealCondition dc 
		JOIN cfgcw.DealConditionCriteria dcc ON dc.DealConditionId = dcc.DealConditionId
		AND dc.DealId = @Dealid
		AND dcc.OverrideSQL IS NOT NULL

		SET @tempId = (SELECT TOP 1 DealConditionCriteriaId FROM #temp ORDER BY DealConditionCriteriaId ASC);
		SET @spName = (SELECT OverrideSQL FROM #temp WHERE DealConditionCriteriaId =  @tempId);

		SET @params='@RunId int,@pUserName	VARCHAR(80), @ret_value BIT OUTPUT'

		WHILE(@tempId IS NOT NULL)
		BEGIN
			IF(@spName IS NOT NULL)
			BEGIN
				SET @dynsql='exec '+@spName+' @RunId,@pUserName, @ret_value OUTPUT'

				PRINT '@dynsql'
				PRINT @dynsql
				
				EXEC sp_executesql @dynsql, @params, @RunId=@pDealIpdRunId, @pUserName = @pUserName, @ret_value=@returnValue OUTPUT
				
				UPDATE #temp
				SET ResultedStatus = @returnValue
				WHERE DealConditionCriteriaId = @tempId;
			END


			SET @tempId  = (SELECT TOP 1 DealConditionCriteriaId FROM #temp WHERE DealConditionCriteriaId> @tempId ORDER BY DealConditionCriteriaId ASC);
			SET @spName = (SELECT overrideSQL FROM #temp WHERE DealConditionCriteriaId =  @tempId);

		END

		DELETE FROM cw.DealIpdConditionCriteriaTest 
		WHERE DealIpdRunId = @pDealIpdRunId 
		AND DealConditionCriteriaId IN (SELECT DealConditionCriteriaId FROM #temp);

		INSERT INTO cw.DealIpdConditionCriteriaTest (
		DealIpdRunId,DealConditionCriteriaId,ExpectedStatus,ResultedStatus,
		CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pDealIpdRunId, DealConditionCriteriaId, NULL, ResultedStatus
		, @pUserName, GetDate(),@pUserName, GetDate()
		FROM #temp

		UPDATE dcct
		SET dcct.ExpectedStatus= dcc.ExpectedStatus
		FROM cw.DealIpdConditionCriteriaTest dcct 
		JOIN #temp temp ON temp.DealConditionCriteriaId= dcct.DealConditionCriteriaId
		JOIN cfgcw.DealConditionCriteria dcc ON dcct.DealConditionCriteriaId= dcc.DealConditionCriteriaId AND dcct.DealIpdRunId = @pDealIpdRunId;

		END TRY
		BEGIN CATCH
			DECLARE 
				@errorMessage     NVARCHAR(MAX),
				@errorSeverity    INT,
				@errorNumber      INT,
				@errorLine        INT,
				@errorState       INT;

			SELECT 
				@errorMessage = ERROR_MESSAGE()
				,@errorSeverity = ERROR_SEVERITY()
				,@errorNumber = ERROR_NUMBER()
				,@errorLine = ERROR_LINE()
				,@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'spCalculateConditionOverrideSql', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
			RAISERROR (@errorMessage,
				 @errorSeverity,
				 @errorState )

		END CATCH


	END



	GO