USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetCherryPickInclusionReasons]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetCherryPickInclusionReasons]
GO

-- Exec [corp].[spGetCherryPickInclusionReasons]
CREATE PROCEDURE [corp].[spGetCherryPickInclusionReasons]
As
Begin
	SELECT CAST(LookUpValue AS INT) AS InclusionId, LookUpValueDescription AS InclusionValue
	FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1] 
	WHERE ReportTemplateName = 'CHERRYPICK' AND LookUpName = 'InclusionReasons'
	ORDER BY 1 ASC
END
GO
