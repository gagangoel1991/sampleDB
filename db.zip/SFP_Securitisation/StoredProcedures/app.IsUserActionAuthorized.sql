USE [SFP_Securitisation]
GO
IF OBJECT_ID('[app].[IsUserActionAuthorized]') IS NOT NULL
	DROP PROCEDURE [app].[IsUserActionAuthorized]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[IsUserActionAuthorized]
/*
 * Author: Kapil Sharma
 * Date:	28.04.2020
 * Description:  This will validate the user access authorization
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * [app].[GetUserAndMenuData] 'FM\Sharapi', 'FM\G USR - ROL GTT Development Support'
*/
@userName			VARCHAR(80),
@adGroupName		VARCHAR(256),
@permissionName		VARCHAR(128),
@acessTypeId		SMALLINT,
@result				BIT OUTPUT
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		--Returning the user detail
		DECLARE 
			@roleId			SMALLINT;

		DECLARE
			@tblADGroup TABLE ([Value] [varchar] (500));

		DECLARE
			@tblRole TABLE ([RoleId] smallint);

		INSERT INTO @tblADGroup
		SELECT [Value] FROM app.[udfSplitString](@adGroupName, '|') 

		INSERT INTO @tblRole(RoleId)
		SELECT r.RoleId FROM [app].[RoleADGroupMap] agm 
		JOIN [app].[Role] r ON agm.RoleId = r.RoleId
		JOIN [app].[ADGroup] grp ON grp.ADGroupId = agm.ADGroupId
		JOIN	
			@tblADGroup userGrp ON userGrp.[Value] = grp.[Name]
		WHERE
			grp.IsActive = 1 AND agm.IsActive = 1 AND r.IsActive = 1; 

		IF EXISTS(
			SELECT 
				TOP 1 * 
			FROM 
				[app].[Permission] per
			JOIN 
				[app].[RolePermissionAccessMap] rpam ON rpam.PermissionID = per.PermissionId
			JOIN  
				[app].[Role] r ON r.RoleId = rpam.RoleId
			JOIN 
				[app].[PermissionAccessType] pat ON pat.PermissionAccessTypeId = rpam.PermissionAccessTypeId
			JOIN	
				@tblRole userRole ON userRole.RoleId = r.RoleId
			WHERE 
				pat.PermissionAccessTypeId = @acessTypeId
				AND per.PermissionName = @permissionName
				AND rpam.IsActive = 1 AND per.IsActive = 1
				AND r.IsActive = 1 AND pat.IsActive = 1
		)
		BEGIN
			SET @result = 1
		END
		ELSE
		BEGIN
			SET @result = 0;
		END
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'IsUserActionAuthorized', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @userName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO


