USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingTradesInformation]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingTradesInformation] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 07-07-2022 
--Description: GET DealNote Data 
--[cb].[spGetBookingTradesInformation] 6,61,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingTradesInformation] 
   @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  
  
BEGIN TRY

  SELECT
		bg.InternalName As GroupName,
		CASE WHEN bl.InternalName like '%Principal%'  THEN  'PRINCIPAL' ELSE 'INTEREST' END as LineItemInternalName,
		bl.DisplayName as LineItem,
		bv.Value as Value,
		bv.DealIpdRunId as DealIpdRunId,
		bg.SortOrder as GroupSortOrder,
		bl.SortOrder as SortOrder
		INTO #Bookings

		FROM 
		 cfgcb.BookingGroup bg
			JOIN cfgcb.BookingLineItem bl ON bg.BookingGroupId =bl.BookingGroupId
			JOIN cb.BookingLineItemValue bv ON bl.BookingLineItemId =bv.BookingLineItemId
			LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
		WHERE 
			bg.InternalName in ('Maturing_Trades','New_GIC_Loan_Information')
			AND dir.DealIpdRunId =@pIPDRunId AND dir.DealId= @pDealId

		Select DealIpdRunId, GroupName, LineItem, PRINCIPAL, INTEREST ,GroupSortOrder,SortOrder
		FROM #Bookings		
		PIVOT (  
				MAX(Value) FOR LineItemInternalName IN (PRINCIPAL, INTEREST)
			  ) pvtbl
		ORDER BY GroupSortOrder,SortOrder


  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetDealNoteInformation', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO
