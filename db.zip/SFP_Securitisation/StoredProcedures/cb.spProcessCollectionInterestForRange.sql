USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spProcessCollectionInterestForRange]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessCollectionInterestForRange]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spProcessCollectionInterestForRange]
/*-----------------------------------------------------
 * Author: Kapil Sharma
 * Date:	25.01.2022
 * Description:  This will calculate the interest on collection for a range of date
 * 
 * Example: 
 * [cb].[spProcessCollectionInterestForRange] '2021-04-01', '2021-04-30'
 * 				
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
(
	@pFromDate				DATE,
	@pToDate				DATE
)
AS
BEGIN
	BEGIN TRY
	
		DECLARE
			@date		DATE = @pFromDate
			 
		WHILE @date <= @pToDate
		BEGIN
			EXEC [cb].[spCalculateOneDayCollectionInterest] @date
			SET @date = DATEADD(DD, 1, @date)
		END

	END TRY
	BEGIN CATCH

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spProcessCollectionInterestForRange', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO