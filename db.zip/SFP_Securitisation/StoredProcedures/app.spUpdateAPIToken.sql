USE [SFP_Securitisation]
GO

IF OBJECT_ID('app.spUpdateAPIToken') IS NOT NULL
	DROP PROCEDURE app.spUpdateAPIToken
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Saurabh Bhatia
--Date: 18-06-2022 
--Description: UPDATE API Token by Key 
--EXEC app.spUpdateAPIToken 'abc','FM\bhasaaa'
--================================== 
CREATE PROCEDURE app.spUpdateAPIToken 
	 @pKey VARCHAR(2000) 
	,@pToken UNIQUEIDENTIFIER 
	,@pFromIsProcessRunning BIT 
	,@pToIsProcessRunning BIT 
	,@pUserName VARCHAR(80) 
	 ---------
	,@pOutIsTokenUpdated BIT OUTPUT
	,@pOutUpdatedToken UNIQUEIDENTIFIER OUTPUT
	,@pOutIsProcessRunning INT OUTPUT	
AS
BEGIN

	BEGIN TRY

		DECLARE @APIToken TABLE (Token UNIQUEIDENTIFIER);
		--No Read from app.APIToken before update 
		UPDATE app.APIToken
		SET Token = NEWID()
			,ModifiedDate = GETDATE()
			,ModifiedBy = @pUserName
			,IsProcessRunning = @pToIsProcessRunning
		OUTPUT inserted.Token
		INTO @APIToken
		WHERE [Key] = @pKey
			AND Token = @pToken
			AND IsProcessRunning = @pFromIsProcessRunning

		DECLARE @pEffectedRowsCount INT = @@ROWCOUNT;

		IF ((Select COUNT(1) FROM @APIToken)>0)
		BEGIN
			SET @pOutIsTokenUpdated = 1
			SET @pOutUpdatedToken = (SELECT TOP 1 Token FROM @APIToken)
			SET @pOutIsProcessRunning = @pToIsProcessRunning;
		END
		ELSE
		BEGIN
			SET @pOutIsTokenUpdated = 0
			SET @pOutUpdatedToken = NULL
			--Check if the process is running 
			SELECT @pOutIsProcessRunning = IsProcessRunning
			FROM app.APIToken
			WHERE [Key] = @pKey
		END

	END TRY
	BEGIN CATCH

		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'app.spUpdateAPIToken'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO
