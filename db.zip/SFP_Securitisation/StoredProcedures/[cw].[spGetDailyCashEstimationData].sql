USE SFP_Securitisation

GO


IF OBJECT_ID('[cw].[spGetDailyCashEstimationData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDailyCashEstimationData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Arun  
Date:    07.07.2022  
Description:  This will return daily cash estimation data.  
Usage : [cw].[spGetDailyCashEstimationData]  '2022-05-30','Deimos'              
Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  
CREATE PROCEDURE [cw].[spGetDailyCashEstimationData] 
   @pAsAtDate DATE = null 
  ,@pDealName VARCHAR(255)
  ,@pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
BEGIN TRY  
   
		DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))  
		DECLARE @dealId INT, @mortgageDealKey INT, @dealCurrency VARCHAR(10);  
		Declare @CollectionDate Date = @pAsAtDate
   
		SELECT @dealId = dealId, @mortgageDealKey= MortgageDealId, @dealCurrency = C.Name  
		FROM [cw].[vw_ActiveDeal]  D  
		LEFT JOIN [cfgCW].[Currency] C ON D.DealCurrencyId= C.CurrencyId  
		WHERE DealName=@pDealName  
  		
		Select CollectionDate
		into #Last31Days
		From [CW].[DailyCollection]
		Where DealId=@dealId
		and CollectionDate >=DATEADD(D, -31, @pAsAtDate)
		and CollectionDate <=dateadd(D,-1,@pAsAtDate)
		Group by CollectionDate

		Select 'Daily' as EstimationType, L.CollectionDate, df.ColumnName,  BrandId, B.Name as BrandName, CASE WHEN CAST(D.Value as float) <0 THEN ABS(D.VALUE) ELSE CAST(D.VALUE as float) * -1 END as Value
		INTO #Last31DaysData
		From 
		#Last31Days L
		INNER JOIN [CW].[DailyCollection] D on D.CollectionDate= L.CollectionDate
		INNER JOIN [cfgCW].[DailyCollectionField] df on df.DailyCollectionFieldId = D.DailyCollectionFieldId and ColumnName in ('TotalRevenueReceipts', 'PrincipalReceipts') and D.DealId=Df.DealId
		LEFT JOIN [cfgCW].[DealBrand] B on B.DealBrandId = D.BrandId
		Where D.DealId=@dealId
		order by L.CollectionDate desc
		

		SET @pAsAtDate = dateadd( m, -1, @pAsAtDate)

		Declare @startDate Date =DATEADD(month, DateDiff(month , 0,   dateadd( m, -11, @pAsAtDate)), 0)
		;with CTE
		AS
		(
			Select @pAsAtDate as 'Dates'
			Union ALL
			Select DateAdd(MONTH, -1, [Dates]) From CTE Where Dates > DateAdd(MONTH, 1, @startDate )
		)
		Select Dates into #Last1yrMonthDates from CTE

		Select DateAdd(D, 1, Dates) as CollectionDate, month(dates) as Month, Year(dates) as YEar, Row_Number() OVER ( Order by DateAdd(D, 1, Dates) desc)  as MonthRowNum INTO #Last1yrDates from #Last1yrMonthDates
		UNION ALL
		Select Dates as CollectionDate, month(dates) as Month, Year(dates) as YEar, Row_Number() OVER ( Order by Dates desc) as MonthRowNum from #Last1yrMonthDates
		UNION ALL
		Select DateAdd(D, -1, Dates) as CollectionDate, month(dates) as Month, Year(dates) as YEar, Row_Number() OVER ( Order by  DateAdd(D, -1, Dates) desc) as MonthRowNum from #Last1yrMonthDates
		
		Select CollectionDate, BrandId, RowNum-1 as RowNum, MonthRowNum
		INTO #Last3DaysOfMonthForYear
		FROM (
				Select CollectionDate, BN.BrandId,   L.Month, L.Year, Row_Number() OVER ( Partition By BN.BrandId, L.Month,  L.Year Order by CollectionDate Desc) as RowNum, L.MonthRowNum
				From #Last1yrDates L
				CROSS JOIN (Select distinct BrandId  from #Last31DaysData) BN
			 )  tbl
		where RowNum<=3
		Order by CollectionDate desc

		

		Select Distinct 'Monthly' as EstimationType, ldmfy.CollectionDate, ColumnName, ldmfy.BrandId, B.Name as BrandName, dcv.Value
		INTO #Last3DaysOfMonthForYearData
		From 
		#Last3DaysOfMonthForYear ldmfy
		INNER JOIN [cfgCW].[DealBrand] B on B.DealBrandId = ldmfy.BrandId
		LEFT JOIN (	Select d.CollectionDate, df.ColumnName, D.BrandId, CASE WHEN CAST(D.Value as float)<0 THEN ABS(D.VALUE) ELSE CAST(D.VALUE as Float) * -1 END as Value
					FROM 
					#Last1yrDates l
					INNER JOIN [CW].[DailyCollection] D on D.CollectionDate= L.CollectionDate 
					INNER JOIN [cfgCW].[DailyCollectionField] df on df.DailyCollectionFieldId = D.DailyCollectionFieldId and ColumnName in ('TotalRevenueReceipts', 'PrincipalReceipts') and D.DealId=Df.DealId
					Where D.DealId=@dealId
				  ) dcv on dcv.CollectionDate = ldmfy.CollectionDate and B.DealBrandId=dcv.BrandId
		order by ldmfy.CollectionDate desc

		

		Declare @AverageDays INT = ( Select count(*) from #Last31Days )


		Select EstimationType, CollectionDate, BrandName, CAST([PrincipalReceipts] as DECIMAL(38, 18)) as [Principal], CAST([TotalRevenueReceipts]  as DECIMAL(38, 18)) as [Revenue]
		INTO #Last31DaysOutcome
		From
		#Last31DaysData
		PIVOT (  
				MAX(Value) FOR ColumnName IN (PrincipalReceipts, TotalRevenueReceipts)
			  ) tbl

		
		Declare @BrandCount INT =1
		SET @BrandCount = (Select count(distinct BrandId) from #Last31DaysData)
		Declare @BrandColumns varchar(max) 

		Select 'Daily' as EstimationType, 'Daily Average (last 31 days)' as LineItem, Null as CollectionDate, BrandName, SUM([Principal])/@AverageDays as Principal, SUM([Revenue])/@AverageDays as Revenue, (SUM([Principal])/@AverageDays) + (SUM([Revenue])/@AverageDays) as [Total] 
		INTO #DailyAverage
		from #Last31DaysOutcome
		Group by EstimationType, BrandName

		
		Select 1 as IsParent, 'Daily' as EstimationType, 'Maximum (last 31 days)' as LineItem,  Null as CollectionDate, BrandName, MAX([Principal]) as Principal, MAX([Revenue]) as Revenue, MAX([Principal]) + MAX([Revenue]) as [Total] 
		INTO #MinMaxLast31DaysOutcome 
		from #Last31DaysOutcome
		Group by EstimationType, BrandName
		Union ALL
		Select 1 as IsParent, 'Daily', 'Minimum (last 31 days)',  Null, BrandName, MIN([Principal]) as Principal, MIN([Revenue]) as Revenue, MIN([Principal]) + MIN([Revenue]) as [Total] from #Last31DaysOutcome
		Group by EstimationType, BrandName

		IF @BrandCount > 1
		BEGIN
			SELECT @BrandColumns= COALESCE(@BrandColumns + ' + ', '')  + '[' + BrandName + ']' FROM ( SELECT DISTINCT BrandName FROM #Last31DaysData ) TBL 

			INSERT INTO #MinMaxLast31DaysOutcome
			Select 1 as IsParent, 'Daily' as EstimationType, LineItem,  Null as CollectionDate, @BrandColumns as BrandName, SUM([Principal]) as Principal, SUM([Revenue]) as Revenue, SUM([Principal]) + SUM([Revenue]) as [Total] 
			FROM #MinMaxLast31DaysOutcome 
			GROUP BY EstimationType, LineItem

			Insert INTO #DailyAverage
			Select EstimationType, LineItem, Null as CollectionDate, @BrandColumns as BrandName, SUM([Principal]), SUM([Revenue]), SUM([Principal]) + SUM([Revenue]) From #DailyAverage
			GROUP BY EstimationType, LineItem
			
			INSERT INTO #Last31DaysOutcome
			Select EstimationType, CollectionDate, @BrandColumns as BrandName, SUM([Principal]), SUM([Revenue]) From #Last31DaysOutcome
			GROUP BY EstimationType, CollectionDate
		END

		
		----===============Monthly================================
	
		Select EstimationType, CollectionDate, BrandName, BrandId, CAST(IsNull([PrincipalReceipts],0) as DECIMAL(38, 18)) as [Principal], CAST(IsNull([TotalRevenueReceipts],0)  as DECIMAL(38, 18)) as [Revenue]
		INTO #Last3DaysOfMonthForYearOutCome
		From
		#Last3DaysOfMonthForYearData
		PIVOT (  
				MAX(Value) FOR ColumnName IN (PrincipalReceipts, TotalRevenueReceipts)
			  ) tbl
	

		IF @BrandCount > 1
		BEGIN
			INSERT INTO #Last3DaysOfMonthForYear
			SELECT Distinct CollectionDate, 0, RowNum, MonthRowNum FROM #Last3DaysOfMonthForYear

			INSERT INTO #Last3DaysOfMonthForYearOutCome
			Select EstimationType, CollectionDate, @BrandColumns as BrandName, 0 as BrandId, SUM([Principal]), SUM([Revenue]) From #Last3DaysOfMonthForYearOutCome
			GROUP BY EstimationType, CollectionDate
		END

		Select Row_Number() Over (Order by RowNum,  LO.CollectionDate desc) as SortOrder, 0 as IsParent, EstimationType
		, L.RowNum, 'T' + Case When L.RowNum >0 Then '-' + Cast(RowNum as varchar) Else '' End  + '--' + CAST(L.MonthRowNum as varchar) + 'M' 	as LineItem
		, LO.CollectionDate, BrandName, [Principal], [Revenue],  [Principal] + [Revenue] as [Total] 
		INTO #Last3DaysOfMonthForYearOutComeSorted
		from #Last3DaysOfMonthForYearOutCome LO
		Inner join #Last3DaysOfMonthForYear L on L.CollectionDate =LO.CollectionDate and L.BrandId=LO.BrandId
		Order by RowNum,  Lo.CollectionDate desc

		SET @AverageDays = ( Select count(distinct CollectionDate) From #Last3DaysOfMonthForYearOutCome	where Principal <> 0)

		Select 'Monthly' as EstimationType, 'Collection Day (+/-1) Monthly Average' as LineItem, Null as CollectionDate, BrandName, SUM([Principal])/@AverageDays as Principal, SUM([Revenue])/@AverageDays as Revenue, (SUM([Principal])/@AverageDays) + (SUM([Revenue])/@AverageDays) as [Total] 
		into #MonthlyAverage
		from #Last3DaysOfMonthForYearOutCome
		Group by EstimationType, BrandName
	
	
		------Group Average
		Select 'Daily' as EstimationType, 'Daily Estimate (Rounded)' as LineItem, Null as CollectionDate, BrandName, [cw].[fnGetRoundUpValue](SUM([Principal])/2, 5) as Principal, [cw].[fnGetRoundUpValue](SUM([Revenue])/2, 5) as Revenue,  ([cw].[fnGetRoundUpValue](SUM([Principal])/2, 5) +  [cw].[fnGetRoundUpValue](SUM([Revenue])/2, 5) ) as [Total] 
		INTO #TblAvgOfAvgerages
		FROM 
		(
		Select BrandName, [Principal], [Revenue],  [Total] from #MonthlyAverage
		Union ALL
		Select BrandName, [Principal], [Revenue],  [Total] from #DailyAverage
		) TblAvgOfAvg
		Group by BrandName


		
				
		----=Final Outcome================================================================
		Select 1 as IsParent, EstimationType,	LineItem,  @CollectionDate as CollectionDate, BrandName, [Principal], [Revenue],  [Total] from #TblAvgOfAvgerages  
		Union ALL
		Select 2 as IsParent, 'Daily' as EstimationType, 'Last 31 days' as LineItem,  Null, BrandName, 0, 0,  0 from #TblAvgOfAvgerages
		Union ALL
		Select 0 as IsParent, EstimationType, 'T-' + CAST( DENSE_RANK()  Over ( Order by CollectionDate desc) +1 as VARCHAR) as LineItem,  CollectionDate, BrandName, [Principal], [Revenue],  [Principal] + [Revenue] as [Total] from #Last31DaysOutcome
		Union ALL
		Select 1 as IsParent, 'Daily', 'Maximum (last 31 days)',  Null, BrandName, MAX([Principal]) as Principal, MAX([Revenue]) as Revenue, MAX([Principal]) + MAX([Revenue]) as [Total] from #MinMaxLast31DaysOutcome
		Group by EstimationType, BrandName
		Union ALL
		Select 1 as IsParent, 'Daily', 'Minimum (last 31 days)',  Null, BrandName, MIN([Principal]) as Principal, MIN([Revenue]) as Revenue, MIN([Principal]) + MIN([Revenue]) as [Total] from #MinMaxLast31DaysOutcome
		Group by EstimationType, BrandName
		Union ALL
		Select 1 as IsParent, EstimationType,	LineItem,  Null, BrandName, [Principal], [Revenue],  [Total] from #DailyAverage

		Union ALL
		Select 2 as IsParent, EstimationType,	LineItem,  CollectionDate, BrandName, [Principal], [Revenue],  [Total] from #MonthlyAverage  
		Union ALL
		Select 0 as IsParent, EstimationType,  LineItem,  CollectionDate, BrandName, [Principal], [Revenue],  [Total] 
		from #Last3DaysOfMonthForYearOutComeSorted

	END TRY
	
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCashEstimationData', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH

END

GO

