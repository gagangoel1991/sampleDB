USE SFP_Securitisation
GO
IF OBJECT_ID('cw.spDeleteUploadedRatingData') IS NOT NULL
	DROP PROCEDURE cw.spDeleteUploadedRatingData 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--====================================================
--Author: Saurabh Bhatia
--Date: 18-May-2021
--Description: To Delete Uploaded Rating Data 
--from user CP/Bond table. Note- This proc is
--also getting called from cw.spSaveUploadedRatingData
--====================================================
CREATE PROCEDURE cw.spDeleteUploadedRatingData 
	 @RatingUploadDetailId int
	,@UserName VARCHAR(80)	
AS
BEGIN
	BEGIN TRY 
		BEGIN TRAN 
		
			DELETE
			FROM cw.UserCounterpartyRating
			WHERE [RatingUploadDetailId] = @RatingUploadDetailId;
		
			DELETE
			FROM cw.UserBondRating
			WHERE [RatingUploadDetailId] = @RatingUploadDetailId;
			
			DECLARE @deletedDealId TABLE(DealId varchar(40),CollectionDate DateTime)		
			DELETE
			FROM cw.RatingUploadDetail
			OUTPUT Deleted.DealId,Deleted.CollectionDate INTO @deletedDealId
			WHERE [RatingUploadDetailId] = @RatingUploadDetailId;			

			DECLARE @DealId int = (SELECT TOP 1 DealId FROM @deletedDealId);
			DECLARE @CollectionDate DateTime = (SELECT TOP 1 CollectionDate FROM @deletedDealId);

			DECLARE
			@dealIpdRunId		INT,
			@resultCode			INT
			SELECT TOP 1 @dealIpdRunId = RunId FROM cw.DealIpd di
			JOIN cw.DealIpdRun dir ON dir.DealIpdId = di.DealIpdId AND dir.IsCurrentVersion = 1
			JOIN cw.vwDealIpdDates ipdDt ON ipdDt.DealIpdId = di.DealIpdId AND di.DealId = ipdDt.DealId
			WHERE 
				di.DealId = @DealId
				AND CAST(ipdDt.CollectionBusinessEnd AS DATE) = @CollectionDate 

			IF @dealIpdRunId IS NOT NULL
			BEGIN
			    --Updating the Triggers data 
				EXEC [cw].[spProcessTriggersOnIpdInit] @dealIpdRunId, @UserName
				--Now update the summary status
				EXEC [cw].[spUpdateIpdSummaryLineItemStatus]  @pDealIpdRunId= @dealIpdRunId, @lineItemCode='AutomatedData_CounterpartyRating', @pUserName=@UserName;
				EXEC [cw].[spUpdateIpdSummaryLineItemStatus]  @pDealIpdRunId= @dealIpdRunId, @lineItemCode='AutomatedData_BondRating', @pUserName=@UserName;
				EXEC [cw].[spUpdateIpdSummaryLineItemStatus]  @pDealIpdRunId= @dealIpdRunId, @lineItemCode='TriggersConditions_RatingTriggers', @pUserName=@UserName;				
			END

		COMMIT TRAN 
	END TRY   
	BEGIN CATCH
	  IF @@TRANCOUNT > 0
	        ROLLBACK TRAN
	
	  DECLARE   
	   @errorMessage     NVARCHAR(MAX),  
	   @errorSeverity    INT,  
	   @errorNumber      INT,  
	   @errorLine        INT,  
	   @errorState       INT;  
	  SELECT   
	   @errorMessage = ERROR_MESSAGE()
	   ,@errorSeverity = ERROR_SEVERITY()
	   ,@errorNumber = ERROR_NUMBER()
	   ,@errorLine = ERROR_LINE()
	   ,@errorState = ERROR_STATE()  
	  
	  EXEC app.SaveErrorLog 2, 1, 'cw.spDeleteUploadedRatingData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
	  , @UserName  
	    
	  RAISERROR (@errorMessage,  
	             @errorSeverity,  
	             @errorState )  
	END CATCH  
END


