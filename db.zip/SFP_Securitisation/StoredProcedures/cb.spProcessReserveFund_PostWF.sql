USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessReserveFund_PostWF]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessReserveFund_PostWF]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessReserveFund_PostWF] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  16.03.2022
 *   Description:  Fill ReserveFund_PostWF CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *     
 *   exec cb.[spProcessReserveFund_PostWF] 35,'fm\shriyad'
 *    select * from [Cb].[ReserveFund_PostWF] where dealipdrunid=35           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 
      BEGIN TRY 
          --declare @pDealIpdRunId int=35, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @CreditReceived decimal(38,16)

				SELECT @CreditReceived = RevenueWaterfallTotalPaidAmount
				FROM [CW].[vwRevenueWaterfallPaymentSummary]
				WHERE DealIpdRUnId = @pDealIpdRunId AND WaterfallLineItemInternalName='RevenuePriorityofPayments_9.000'

                
          DELETE FROM [Cb].[ReserveFund_PostWF] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[ReserveFund_PostWF] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,CreditReceived
						,ReserveFund_cf
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
          SELECT   @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,@CreditReceived
						,COALESCE(ReserveFund_bF,0)- COALESCE(ResidualAmount,0) +@CreditReceived
						,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM	cfgcb.CoveredBondFund cbf
						JOIN cb.ReserveFund_PreWF rf_preWF ON rf_preWF.CoveredBondFundId = cbf.CoveredBondFundId
								AND rf_preWF.DealIpdRunId = @pDealIpdRunId
                WHERE  cbf.InternalName = 'ReserveFund' 
		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessReserveFund_PostWF', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO