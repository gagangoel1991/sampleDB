USE SFP_Securitisation

GO


IF OBJECT_ID('cb.[spDailyCollectionOutput]') IS NOT NULL
	DROP PROCEDURE cb.[spDailyCollectionOutput]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Arun  
Date:    07.07.2022  
Description:  This will return daily cash estimation data.  
Usage : cb.[spDailyCollectionOutput]  @pAsStartDate= '2022-04-26', @pAsAtDate = '2022-04-28', @pDealName='Deimos'            
Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  
CREATE PROCEDURE cb.[spDailyCollectionOutput] 
	@pAsStartDate DATE = null,  
	@pAsAtDate DATE = null,
	@pDealName VARCHAR(255) ='Deimos',
	@pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
	BEGIN TRY  
   
   		DECLARE @dealId INT, @dealRegionCode VARCHAR(10);  
	 	SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  

		Select Convert(datetime, BusinessDate, 103) as [CashCollectionDate], 
		([ScheduledPrincipalReductions] 
		+ [PartialPrepayments]
		+ [Overpayments]
		+ [FullRedemptionPayments]
		+ [FeesChargedCapitalised]
		+ [OtherPrincipalMovements]) * -1 as [GrossPrincipalCollectionsFeesandOtherMovements]
		

		,[FurtherStageAdvances] * -1 as [LessPrincipalElementofFurtherAdvances]

		,[PrincipalReceiptsDeflagged] * -1 as [PlusRepurchaseAmounts]

		,(-[TotalPrincipalReceipts] - [PrincipalReceiptsDeflagged])  as [NetPrincipalCollections]

		,(-[TotalRevenueReceipts] - [RevenueReceiptsDeflagged])  as [RevenueCollections]

		INTO #DailyCollectionSummaryLevelData FROM [CW].[DailyCollectionSummaryLevelData] 
		where  Convert(datetime, BusinessDate, 103)>=@pAsStartDate and Convert(datetime, BusinessDate, 103) <= @pAsAtDate 
		and DealName = @pdealName


		SELECT [cw].[fnGetBusinessDate] ([CashCollectionDate], @dealRegionCode, 1, 1) as AdviceDate, 
		dcsld.[CashCollectionDate],
		dcsld.[GrossPrincipalCollectionsFeesandOtherMovements],
		dcsld.[LessPrincipalElementofFurtherAdvances],
		dcsld.[PlusRepurchaseAmounts],
		dcsld.[NetPrincipalCollections],
		dcsld.[RevenueCollections],
		dcsld.[NetPrincipalCollections] + dcsld.[RevenueCollections] as [DailyCashMovement]
		FROM #DailyCollectionSummaryLevelData dcsld
		ORDER BY dcsld.[CashCollectionDate]

	END TRY
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetAdviceDateList', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH

END

GO

