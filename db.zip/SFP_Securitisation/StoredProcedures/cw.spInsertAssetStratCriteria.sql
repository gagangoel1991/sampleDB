USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spInsertAssetStratCriteria') IS NOT NULL
	DROP PROC  cw.spInsertAssetStratCriteria
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC cw.spInsertAssetStratCriteria
@pStratId int,
@pFromOperatorId int = NULL,
@pFromValue float = NULL,
@pToOperatorId int = NULL,
@pToValue float = NULL,
@pSortOrder tinyint,
@pIsActive bit=1,
@pCreatedBy varchar(80) ='System' ,
@pReportTypeName VARCHAR(50) = ''
AS  
BEGIN  

 BEGIN TRY  
   
  DECLARE @AssetStratFieldMapId int
  
  DECLARE @ReportTypeId INT;
  SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
  SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName

  SELECT @AssetStratFieldMapId = AssetStratId FROM  cfgCW.IR_AssetStrat WHERE StratId=@pStratId   AND ReportTypeId = @ReportTypeId
  
  INSERT INTO [cfgCW].IR_AssetStratCriteria(AssetStratFieldMapId, FromOperatorId, FromValue, ToOperatorId, ToValue,
	SortOrder, IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  

  VALUES (@AssetStratFieldMapId, @pFromOperatorId, @pFromValue, @pToOperatorId, @pToValue,
   @pSortOrder ,@pIsActive, @pCreatedBy, GetDate(), @pCreatedBy, GetDate() )
  
 END TRY  
  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2, 1, 'spInsertAssetStratCriteria', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pCreatedBy  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
  
END  
GO
