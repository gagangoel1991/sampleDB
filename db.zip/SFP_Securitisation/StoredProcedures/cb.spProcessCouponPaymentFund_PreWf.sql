USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessCouponPaymentFund_PreWf]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessCouponPaymentFund_PreWf]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessCouponPaymentFund_PreWf] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  28.01.2022
 *   Description:  Fill CouponPaymentFund_PreWf CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   AS		10.03.2022	changed column name	TestTypeId
 * 						change result string to FAIL from FALSE
 *   
 *   exec cb.[spProcessCouponPaymentFund_PreWf] 1034,'fm\shriyad'
 *    select * from [Cb].[CouponPaymentFund_PreWf] where dealipdrunid=1034           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=35, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @dealId  INT, 
				  @ipdDate DATE,
				  @couponPayment_bF decimal(38,16),
				  @requiredAmount1 decimal(38,16),
				  @capitalContribution decimal(38,16)

          SELECT @dealId = DealId, 
				@ipdDate = IpdDate
          FROM   cw.vwDealIpdRun dir
          WHERE  DealIpdRunId = @pDealIpdRunId 
		  

		  DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

          IF Object_id('tempdb..#CouponPaymentFund_PreWf') IS NOT NULL 
            DROP TABLE #CouponPaymentFund_PreWf

          CREATE TABLE #CouponPaymentFund_PreWf
            ( 
				[DealIpdRunId] [int] NOT NULL,
				[CoveredBondFundId] [smallint] NOT NULL,
				[CouponPayment_bF] [decimal](38, 16) NULL,
				[RequiredAmount1] [decimal](38, 16) NULL,
				[FinalRequiredAmount] [decimal](38, 16) NULL,
				[CapitalContribution] [decimal](38, 16) NULL,
				[DueAmount] [decimal](38, 16) NULL,
				[ResidualAmount] [decimal](38, 16) NULL
            ) 

				SELECT @couponPayment_bF = CouponPayment_cf
				FROM cb.CouponPaymentFund_PostWf cpf_postwf
					JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = cpf_postwf.CoveredBondFundId
					AND  cbf.InternalName = 'CouponPaymentFund'
				WHERE DealIpdRUnId = @dealPreviousIpdRunId

				SELECT @requiredAmount1 = SUM(EstimatedOneMonthInterest_GBP)
				FROM cfgcb.DealNote dn 
						JOIN cb.DealNote_Wf dn_Wf ON dn.DealNoteId = dn_Wf.DealNoteId
							AND dn.IsSwapLinked = 0
							AND ValidFrom<=GETDATE() AND ValidTo>=GETDATE()
							AND DealIpdRUnId = @pDealIpdRunId

				SELECT @requiredAmount1 = @requiredAmount1 + SUM(PayAmount)
				FROM cfgcb.NoteSwap ns  
						 JOIN cb.NoteSwap_Wf ns_Wf ON ns.NoteSwapId = ns_Wf.NoteSwapId
							AND ns_Wf.DealIpdRUnId = @pDealIpdRunId
							AND ns.ValidFrom<=GETDATE() AND ns.ValidTo>=GETDATE()

				
				SET @capitalContribution=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
												WHERE ManualFieldInternalName  
														IN ('CouponPaymentLedger_CashCapitalContribution'
														,'CouponPaymentLedger_CashCapitalShortfallContribution')
												AND ManualFieldGroupInternalName = 'CouponPaymentLedger'
												AND DealIpdRunId = @pDealIpdRunId);

                INSERT INTO #CouponPaymentFund_PreWf 
                            (DealIpdRunId
							,CoveredBondFundId
							,CouponPayment_bF
							,RequiredAmount1
							,FinalRequiredAmount
							,CapitalContribution
							,DueAmount
							,ResidualAmount
							) 
                 SELECT @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,COALESCE(@couponPayment_bF,0) CouponPayment_bF
						,COALESCE(@requiredAmount1,0) RequiredAmount1
						,COALESCE(IIF(tr.IsBreached = 0, 0, @requiredAmount1),0) FinalRequiredAmount
						,COALESCE(@capitalContribution,0) CapitalContribution
						,NULL DueAmount
						,NULL ResidualAmount 
                FROM	cfgcb.CoveredBondFund cbf
						LEFT JOIN [cw].[vwDealIpdTriggerResult] tr ON cbf.ApplicableId = tr.TriggerId AND tr.DealIpdRunId = @pDealIpdRunId
                WHERE  cbf.InternalName = 'CouponPaymentFund' 


                UPDATE #CouponPaymentFund_PreWf 
                SET		DueAmount = IIF(FinalRequiredAmount - (CouponPayment_bF + CapitalContribution) > 0
										, FinalRequiredAmount - (CouponPayment_bF + CapitalContribution)
										, 0)
						,ResidualAmount = COALESCE(CouponPayment_bF + CapitalContribution - FinalRequiredAmount,0)


			--select * from #CouponPaymentFund_PreWf

          DELETE FROM [Cb].[CouponPaymentFund_PreWf] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[CouponPaymentFund_PreWf] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,CouponPayment_bF
						,RequiredAmount1
						,FinalRequiredAmount
						,CapitalContribution
						,DueAmount
						,ResidualAmount
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
          SELECT DealIpdRunId
						,CoveredBondFundId
						,CouponPayment_bF
						,RequiredAmount1
						,FinalRequiredAmount
						,CapitalContribution
						,DueAmount
						,ResidualAmount
						 ,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM   #CouponPaymentFund_PreWf 
		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessCouponPaymentFund_PreWf', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO