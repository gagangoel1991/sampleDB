USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[PS].[spGetSFPPlusCompletedPools]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [PS].[spGetSFPPlusCompletedPools]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 *   Author: Sakthivel Loganathan
 *   Date:  23-Feb-2023
 *   Description: To get Retail's completed pool data for dashboard (being called from the sp:[ps].[spGetSFPPlusDashBoardCompletedPools])
 *   Change History 
 *   ---------------------------------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   exec [ps].[spGetSFPPlusCompletedPools] '1 jan 2023','1 feb 2023','System', 1
*/

CREATE PROCEDURE [ps].[spGetSFPPlusCompletedPools]  
(        
 @pFromDate DATE,  
 @pToDate DATE,  
 @pUserName VARCHAR(50),
 @pAssetClassID INT
)        
AS        
BEGIN        
 BEGIN TRY        
  
	DECLARE @PoolStatusCompleteId INT  
	DECLARE @PoolStatusAuthorisedId INT  
	DECLARE @PoolPurposeIDRepurchase INT  
  
    SELECT @PoolStatusCompleteId = MAX(IIF(status = 'Complete',poolstatusid ,0)) , @PoolStatusAuthorisedId = MAX(IIF(status = 'Authorised',poolstatusid ,0)  )
    FROM   ps.poolstatus 
	WHERE  status in( 'Authorised','Complete')
  
    SELECT @PoolPurposeIDRepurchase = PoolPurposeId  
    FROM   ps.PoolPurpose  
    WHERE  PoolPurpose = 'Repurchase';  
  
    DECLARE @poolPartitionMap_Tbl TABLE (poolid INT, hypopoolpartitionid INT)  
  
    INSERT INTO @poolPartitionMap_Tbl (poolid, hypopoolpartitionid)  
    SELECT poolid,  CONVERT(VARCHAR, vintagedate, 112)  
    FROM   ps.pool  
    WHERE ( ((batchprocessingdate BETWEEN @pFromDate AND @pToDate AND PoolStatusId = @PoolStatusCompleteId)  
      OR (EffectiveDate BETWEEN @pFromDate AND @pToDate AND PoolStatusId = @PoolStatusAuthorisedId))  )
	  AND AssetClassId = @pAssetClassID
      
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#sourcePoolDetail') AND type = 'U')  
		DROP TABLE #sourcepooldetail  
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#PoolBuildDetail')  AND type = 'U')  
		DROP TABLE #poolbuilddetail  
	IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#sourceDetails') AND type = 'U')  
		DROP TABLE #sourcedetails  
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#sourceDetails_1')   AND type = 'U')  
		DROP TABLE #sourcedetails_1  
	IF EXISTS (SELECT 1  FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#closedLoans')  AND type = 'U')  
		DROP TABLE #closedLoans  
  
    SELECT pbd.poolid,  
		   pbd.mortgageaccountkey,  
		   pbd.mortgagesubaccountkey  
    INTO   #poolbuilddetail  
    FROM   ps.poolbuilddetail pbd  
    WHERE  pbd.poolid IN (SELECT poolid FROM   @poolPartitionMap_Tbl)  
		   AND pbd.IsActive = 1  
  
    SELECT fmsa_E.mortgagedealkey,  
        tmppart.poolid,  
        fmsa_E.mortgageaccountkey,  
        fmsa_E.mortgagesubaccountkey,  
        dmsa.ACCOUNT_CLOSURE_DATE AccountClosureDate  
    INTO   #sourcepooldetail  
    FROM   #poolbuilddetail pbd  
        INNER JOIN sfp.syn_sfpmodel_vw_factmortgagesubaccountentity fmsa_E  
        INNER JOIN @poolPartitionMap_Tbl tmppart  
            ON fmsa_E.partitionid = tmppart.hypopoolpartitionid  
            ON pbd.mortgageaccountkey = fmsa_E.mortgageaccountkey  
				AND fmsa_E.mortgagesubaccountkey = pbd.mortgagesubaccountkey  
				AND pbd.poolid = tmppart.poolid  
        INNER JOIN sfp.[syn_sfpmodel_vw_mortgagesubaccountentity] dmsa  
            ON dmsa.mortgageaccountkey_interim = fmsa_E.mortgageaccountkey  
				AND dmsa.mortgagesubaccountkey_interim = fmsa_E.mortgagesubaccountkey  
				AND dmsa.account_inception_date <> '0001-01-01'  
				AND dmsa.process_status NOT IN ( '0', '1' )   
  
    SELECT 
		 source.mortgagedealkey,  
         source.poolid,  
         source.mortgageaccountkey,  
         source.mortgagesubaccountkey,  
         mtga.loanid  
     INTO   #sourcedetails_1  
     FROM   #sourcepooldetail source  
         INNER JOIN [sfp].[syn_sfpmodel_vw_mortgageaccountentity] mtga ON mtga.mortgageaccountkey = source.mortgageaccountkey  
  
     SELECT source.loanid,source.poolid  
     INTO   #closedloans  
     FROM   #sourcedetails_1 source  
         INNER JOIN sfp.syn_sfpmodel_vw_flaggingassetclosedloanhistory cl  
           ON source.poolid = cl.poolid AND source.loanid = cl.loanid  
  
     SELECT source.mortgagedealkey,  
         source.poolid,  
         Count(DISTINCT source.mortgageaccountkey)    AS AccountCount,  
         Count(DISTINCT source.mortgagesubaccountkey) AS SubAccountCount,  
         Count(DISTINCT cl.loanid)                    AS ClosedLoanCount  
     INTO   #sourcedetails  
     FROM   #sourcedetails_1 source  
         INNER JOIN ps.pool p  ON source.poolid = p.poolid  
         LEFT JOIN #closedloans cl ON cl.poolid = source.poolid  
     WHERE  ( ( p.poolpurposeid <> @PoolPurposeIDRepurchase  
          AND source.loanid NOT IN (SELECT loanid  
               FROM   #closedloans) )  
          OR p.poolpurposeid = @PoolPurposeIDRepurchase )  
     GROUP  BY source.mortgagedealkey, source.poolid;   
  
    SELECT p.poolid,  
        PoolName = p.NAME,  
        Purpose = purpose.poolpurpose,  
        SourceDeal = sourceDeal.dealname,  
        TargetDeal = TargetDeal.dealname,  
        NumberOfLoans = source.accountcount,  
        NumberOfSubAccounts = source.subaccountcount,  
        ClosedLoanCount = source.ClosedLoanCount,  
        PoolStatus = pstatus.Status,  
        EffectiveDate = CASE WHEN p.PoolStatusId = @PoolStatusAuthorisedId THEN p.EffectiveDate ELSE p.BatchProcessingDate END  ,
		null VintageDate,
		null CashReportingFlag
    FROM   [ps].[pool] p  
    INNER JOIN [ps].[poolpurpose] purpose ON p.poolpurposeid = purpose.poolpurposeid  
    INNER JOIN [ps].[PoolStatus] pstatus ON p.PoolStatusId = pstatus.PoolStatusId  
    INNER JOIN #sourcedetails source ON source.poolid = p.poolid  
    INNER JOIN sfp.syn_SfpModel_vw_MortgageDeal_v1 sourceDeal ON sourceDeal.mortgagedealkey = source.mortgagedealkey  
    INNER JOIN sfp.syn_SfpModel_vw_MortgageDeal_v1 TargetDeal ON TargetDeal.mortgagedealkey = p.targetpoolid  
    ORDER BY p.EffectiveDate DESC,p.NAME ASC;  
  

	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#sourcePoolDetail') AND type = 'U')  
		DROP TABLE #sourcepooldetail  
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#PoolBuildDetail')  AND type = 'U')  
		DROP TABLE #poolbuilddetail  
	IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#sourceDetails') AND type = 'U')  
		DROP TABLE #sourcedetails  
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#sourceDetails_1')   AND type = 'U')  
		DROP TABLE #sourcedetails_1  
	IF EXISTS (SELECT 1  FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#closedLoans')  AND type = 'U')  
		DROP TABLE #closedLoans 
                
 END TRY                      
 BEGIN CATCH                      
  DECLARE                       
  @errorMessage     NVARCHAR(MAX),                      
  @errorSeverity    INT,                      
  @errorNumber      INT,                      
  @errorLine        INT,                      
  @errorState       INT;                      
  SELECT                       
  @errorMessage = ERROR_MESSAGE()  
  ,@errorSeverity = ERROR_SEVERITY()  
  ,@errorNumber = ERROR_NUMBER()  
  ,@errorLine = ERROR_LINE()  
  ,@errorState = ERROR_STATE()                      
                      
  EXEC app.SaveErrorLog 2, 1, 'spGetSFPPlusDashBoardCompletedPools', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''                      
                        
  RAISERROR (@errorMessage,                      
     @errorSeverity,                      
     @errorState )                      
 END CATCH        
END

GO
--EXEC [ps].[spGetSFPPlusDashBoardCompletedPools] '13-JAN-2023','13-FEB-2023' , 'LOGA', 1