USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[ps].[spGetArithmeticOperators]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [ps].[spGetArithmeticOperators]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGetArithmeticOperators]
AS             
BEGIN            
BEGIN TRY
	SELECT 
		[OperatorId],
		[Title],
		[Operator]
	FROM ps.Operator
	WHERE IsActive = 1
		AND Operator IN ('+', '-', '/', '*')		
END TRY            
BEGIN CATCH            
  DECLARE             
   @errorMessage     NVARCHAR(MAX),            
   @errorSeverity    INT,            
   @errorNumber      INT,            
   @errorLine        INT,            
   @errorState       INT;            
  SELECT             
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()            
            
 EXEC app.SaveErrorLog 2, 1, 'spGetArithmeticOperators', @errorNumber, @errorSeverity, @errorLine, @errorMessage, USER_NAME
              
  RAISERROR (@errorMessage,            
             @errorSeverity,            
             @errorState)            
 END CATCH            
END

GO