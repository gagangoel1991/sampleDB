USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetNoteStaticAttributes]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetNoteStaticAttributes] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 07-05-2021 
--Description: GET Note static attributes
--[cw].[spGetNoteStaticAttributes] 15,84,''
--==================================   
CREATE PROCEDURE [cw].[spGetNoteStaticAttributes] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   

   SELECT  
		dn.DealNoteId,CONVERT(VARCHAR(10),ipd.IpdDate,105) AS IPDDate,dn.Series AS DealNote,
		CASE dlv.[Value] WHEN 'FIXED' THEN 'N/A' ELSE CAST(pre.BaseRate AS VARCHAR(300)) END AS BaseRate ,
		dn.ISIN,dn.IssuanceAmount,
		dn.MaturityDate,dn.Margin,
		CASE dlv.[Value] WHEN 'FIXED' THEN 'N/A' ELSE CAST(dlv.[Value] AS VARCHAR(50)) END AS RateType,
		dn.CouponFloor AS CouponFloor
	FROM 
		cfgcw.DealNote dn
	JOIN 
		cw.NoteData_PreWF pre ON dn.DealNoteId=pre.DealNoteId
	JOIN 
		cw.dealipdrun dir ON  dir.RunId=pre.DealipdRunid 
	JOIN 
		cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
	JOIN 
		cfgCW.DealLookupValue dlv ON dn.RateTypeId=dlv.LookupValueId 
	WHERE
		dir.RunId=@pIPDRunId  
		AND ipd.DealId=@pDealId 
		--AND dn.IsNote=1  
    
END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'cw.spGetNoteStaticAttributes', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END
GO
