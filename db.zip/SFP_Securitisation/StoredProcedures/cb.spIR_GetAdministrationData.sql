USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spIR_GetAdministrationData]') IS NOT NULL
	DROP PROCEDURE [cb].[spIR_GetAdministrationData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spIR_GetAdministrationData] 
(
	@pAsAtDate			DATE, 
	@pDealName			VARCHAR(100),
	@pUserName			VARCHAR(80) = NULL
)
/* 
 *   Author: Ravindra Singh
 *   Date:  02.03.2022
 *   Description:  Get the Administration data based on deal and AsAtDate
 *   
 *   Example - EXEC [cb].[spIR_GetAdministrationData] '2021-04-30', 'Deimos', 'System'
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
*/ 
AS 
BEGIN 
	 BEGIN TRY 

		 DECLARE 
			@dealIpdRunId                  INT,
			@dealId                        SMALLINT,
			@IPD                           DATE,
			@CollectionBusinessStart       DATE,
			@CollectionBusinessEnd         DATE

		SELECT   
		  @dealIpdRunId = dir.DealIpdRunId  
		  , @dealId = dir.DealId  
		  , @IPD =ipdDt.IPD
		  ,@CollectionBusinessStart=ipdDt.CollectionCalendarStart
		  ,@CollectionBusinessEnd=ipdDt.CollectionCalendarEnd
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		WHERE   
			deal.DealName = @pDealName  
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
			AND dir.IpdSequence <> 0  



		SELECT 
			dconf.DisplayName,
			CAST(Replace(dconf.Value, '?', '�') AS Nvarchar(max)) AS Value
		FROM 
			cfgcw.CashWaterfallDealConfig dconf
		WHERE 
			Dealid=@dealId
		UNION
		 SELECT 
			'Date of form submission',
			CAST(@IPD AS VARCHAR(10))
		UNION
		 SELECT 
			'Start Date of reporting period',
			CAST(@CollectionBusinessStart AS VARCHAR(10))
		UNION
		 SELECT 
			'End Date of reporting period',
			CAST(@CollectionBusinessEnd AS VARCHAR(10))
		UNION ALL
		SELECT 'Reporting Period Header' AS HeaderText, 'Monthly Investor Report ' + FORMAT(CAST(@IPD AS date), 'MMMM') + ' ' + CAST(YEAR(CAST(@IPD AS date)) AS VARCHAR)	

		

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetAdministrationData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH   
END 
GO
