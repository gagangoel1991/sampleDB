USE [SFP_Securitisation]

IF OBJECT_ID('cb.spGetReservesInterestData') IS NOT NULL
	DROP PROC  cb.spGetReservesInterestData

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 *   Author: Saurabh Bhatia
 *   Date:  28-Jan-2022
 *   Description:  To Get Collection Data 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.spGetReservesInterestData 1034,'europa\bhasaaa'
 *    
*/
CREATE PROC cb.spGetReservesInterestData
	 @pDealIpdRunId INT
	,@pUserName VARCHAR(20)
AS
BEGIN
	BEGIN TRY		
		
		DECLARE @DealId INT;
		DECLARE @IpdDate DATETIME;

		SELECT @DealId = DealId
			,@IpdDate = IpdDate
		FROM [cw].[vwDealIpdRun]
		WHERE DealIpdRunId = @pDealIpdRunId;
			
		SELECT TOP 4 DealIpdId
			,IpdDate
		INTO #DealRunDetail
		FROM [cw].[vwDealIpdRun]
		WHERE IpdDate <= @IpdDate
			AND DealId = @DealId
			AND IpdSequence > 131
		ORDER BY IpdDate DESC;
			

		SELECT 		
			 d.DealId
			,d.DealIpdId
			,CAST(d.Ipd  AS DATE) AS IpdDate
			,CAST(d.CollectionCalendarStart AS DATE) CollectionCalendarStart
			,CAST(d.CollectionCalendarEnd AS DATE) CollectionCalendarEnd
			,CAST(d.CollectionBusinessEnd AS DATE) CollectionBusinessEnd
		INTO #IpdData
		FROM cw.vwDealIpdDates d
		JOIN #DealRunDetail r			
		ON CAST(d.IPD AS DATE) = r.IpdDate
			AND d.DealIpdId =r.DealIpdId
		ORDER BY CAST(d.Ipd  AS DATE) DESC
				
		SELECT IpdDate
			,CollectionCalendarStart
			,CollectionCalendarEnd
			,DepositDate AS [AdviceDate]
			,CollectionDate
			,SoniaRate
			,DepositDate
			,MaturityDate
			,RequiredAmount
			,StartingCumulativeInterest
			,CumulativeInterest
			,InterestAmount
		FROM cb.ReserveInterest CollReserve
		RIGHT JOIN #IpdData ipd ON CollectionDate BETWEEN ipd.CollectionCalendarStart	AND ipd.CollectionCalendarEnd
		OR MaturityDate BETWEEN ipd.CollectionCalendarStart	AND ipd.CollectionCalendarEnd
		ORDER BY IpdDate DESC,CollectionDate DESC;


	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spGetReservesInterestData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


