USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetDealIpdSummary]') IS NOT NULL	
	DROP PROCEDURE [cw].[spGetDealIpdSummary]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Suresh Pandey 
--Date: 07-07-2021 
--Description: Get Deal Ipd Summary Line Item and status

-- exec [cw].[spGetDealIpdSummary] 6,64,''

--  exec [cw].[spGetDealIpdSummary] 15,57,''
--==================================   
CREATE PROCEDURE [cw].[spGetDealIpdSummary] 
 @pDealId INT,
 @pIpdRunId INT,
 @pUserName VARCHAR(80)
AS  
BEGIN  
  
BEGIN TRY   

	DECLARE @collectionStartDate VARCHAR(10)
			,@collectionEndDate VARCHAR(10)
			,@dealType	VARCHAR(20)
			,@prevIpdDate DATE
			,@currentIpdDate DATE
			,@dealRegionCode VARCHAR(20)
			,@startDt DATE
			,@endDt DATE
			,@interestRateDate DATE
			,@previousIPDCollectionBusinessStart DATE
			,@previousIPDCollectionBusinessEnd DATE
			,@prevIpdRunId INT


	SELECT 
			@currentIpdDate = dit.Ipd, 
			@prevIpdDate= dit.PreviousIPD,
			@dealRegionCode = deal.DealRegionCode,
			@collectionStartDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessStart AS DATE),23),   
			@collectionEndDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessEnd AS DATE),23),
			@previousIPDCollectionBusinessStart = CONVERT(VARCHAR(10),CAST(PreviousIPDCollectionBusinessStart AS DATE),23),
			@previousIPDCollectionBusinessEnd = CONVERT(VARCHAR(10),CAST(PreviousIPDCollectionBusinessEnd AS DATE),23), 
			@prevIpdRunId =dir.prevRunId
	FROM cw.vwDealIpdRun dir
	JOIN cw.vw_ActiveDeal deal ON deal.DealId = dir.DealId
	JOIN cw.vwDealIpdDates dit ON dir.DealIpdId = dit.DealIpdId
	WHERE dir.DealIpdRunId = @pIPDRunId
	

	SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

	IF OBJECT_ID('tempdb..#tmpSummarizedInformation') IS NOT NULL DROP TABLE #tmpSummarizedInformation

	CREATE TABLE #tmpSummarizedInformation(
		DealIpdSummaryLineItemId INT,
		SummarizedInformation VARCHAR(max)
		)

	

	--############# SFP Collection
	SELECT * INTO #tempDailyCollection FROM cw.DailyCollection_WIP WHERE IsActive=1
	
	SELECT Sortorder, ColumnName,sum([Collection]) as [Collection] 
	INTO #tempSFPCollection 
	FROM(
		SELECT 
			dc.DailyCollectionId,
			CASE  dcf.ColumnName WHEN 'PrincipalReceipts' then 'Principal'  WHEN 'InterestReceived' THEN 'Interest' ELSE 'Further Advances' END AS ColumnName,
			db.[Name] AS Brand,
			ROW_NUMBER() OVER(PARTITION BY dc.CollectionDate,dcf.ColumnName,db.[Name] ORDER BY Id DESC) AS RowNum ,
			CAST(IIF(wip.DailyCollectionId IS NOT NULL, ROUND(WIP.Value,4), ROUND(dc.Value,4))AS DECIMAL(30,8)) AS [Collection],
			CASE  dcf.ColumnName WHEN 'PrincipalReceipts' then 1 WHEN 'InterestReceived' THEN 2 ELSE 3 END AS SortOrder
		FROM [cw].[DailyCollection] dc
			LEFT JOIN [cfgCW].[DailyCollectionField] dcf ON dc.[DailyCollectionFieldId]=dcf.[DailyCollectionFieldId]  
			LEFT JOIN [cfgCW].[DealBrand] db ON dc.[BrandId]=db.DealBrandId
			LEFT JOIN #tempDailyCollection wip ON dc.DailyCollectionId = wip.DailyCollectionId
		WHERE dcf.ColumnName IN('PrincipalReceipts','InterestReceived','FurtherStageAdvances')
			AND dcf.DealId = @pDealId
			AND dc.CollectionDate Between @collectionStartDate AND @collectionEndDate
		) d 
	WHERE d.RowNum=1
	Group by ColumnName, Sortorder
	
	INSERT INTO #tmpSummarizedInformation
	SELECT IIF(@dealType='Covered Bond', 53, 22) AS DealIpdSummaryLineItemId,
			'|text|' + STUFF((SELECT ', ' + ColumnName + ' : ' +  FORMAT([Collection], 'N')   [text()]
		FROM #tempSFPCollection  order by  Sortorder 
		FOR XML PATH(''), TYPE).value('.','NVARCHAR(max)'),1,2,' ') AS SummarizedInformation
	
	
	--############# Storm Collection
	
	SELECT * INTO #tempCollectionLedger FROM cw.CollectionLedger_WIP WHERE IsActive=1
	
	 
	SELECT 
		ROW_NUMBER() OVER(PARTITION BY cl.CollectionDate ORDER BY Id DESC) AS RowNum 
		,CAST(IIF(wip.CollectionLedgerId IS NOT NULL, ROUND(WIP.NetPrincipalCollections,4), ROUND(CL.NetPrincipalCollections,4)) AS DECIMAL(30,8)) AS NetPrincipalCollections
		,CAST(IIF(wip.CollectionLedgerId IS NOT NULL, ROUND(WIP.FinanceCollections,4), ROUND(CL.FinanceCollections,4)) AS DECIMAL(30,8)) AS FinanceCollections
	INTO #tempStormCollection
	FROM cw.CollectionLEdger cl
		LEFT JOIN #tempCollectionLedger wip ON cl.CollectionLedgerId = wip.CollectionLedgerId
	WHERE cl.DealId =@pDealId 
		AND CAST(cl.CollectionDate AS DATE) BETWEEN @collectionStartDate AND @collectionEndDate 

	INSERT INTO #tmpSummarizedInformation
	SELECT IIF(@dealType='Covered Bond', 54, 23) AS DealIpdSummaryLineItemId,
			'|text|' + STUFF((SELECT ', ' + 'Principal : ' +  FORMAT(SUM(NetPrincipalCollections), 'N') + ', Revenue : ' + FORMAT(SUM(FinanceCollections), 'N') [text()]
		FROM #tempStormCollection  
		FOR XML PATH(''), TYPE).value('.','NVARCHAR(max)'),1,2,' ') AS SummarizedInformation

	 

	--############# Storm Cash Ladder
	SELECT * INTO #tempCashLadder FROM cw.CashLadder_WIP WHERE IsActive=1
	
	INSERT INTO #tmpSummarizedInformation
	SELECT 55 AS DealIpdSummaryLineItemId,	'Inflow Amount(P+I) |currency|' +  CONVERT(VARCHAR(100), SUM(InflowAmount)) AS SummarizedInformation
        FROM (
        SELECT 
			ROW_NUMBER() OVER(PARTITION BY cl.CollectionDate ORDER BY Id DESC) AS RowNum,
			CAST(IIF(wip.CashLadderId IS NOT NULL, ROUND(WIP.InflowAmount,4), ROUND(CL.InflowAmount,4))AS DECIMAL(30,8)) AS InflowAmount			
          FROM cw.CashLadder cl
          LEFT JOIN #tempCashLadder wip ON cl.CashLadderId = wip.CashLadderId
           WHERE cl.DealId =@pDealId 
           AND CAST(cl.CollectionDate AS DATE) BETWEEN @collectionStartDate AND @collectionEndDate
		)l  
           WHERE l.RowNum=1



	--############# Interest Rates
	DECLARE @tblDealBenchmarkCode AS TABLE(RICCode		VARCHAR(100))
			

	--fetching the RICCode based on the deal type
	IF (@dealType='Covered Bond')
	BEGIN
		INSERT INTO #tmpSummarizedInformation
		SELECT 56 AS DealIpdSummaryLineItemId, 
			'SONIA Compounding Rate |percent|' + CAST(cb.fnGetSoniaCompoundingCouponRate(ds.PayDayCountMethodId,dswf.PayDayCountFactor,dswf.PayCouponPeriodStart,dswf.PayCouponPeriodEnd) AS VARCHAR) AS SummarizedInformation
		FROM cb.DealSwap_Wf dswf
		JOIN cfgcb.DealSwap ds ON ds.DealSwapId=dswf.DealSwapId
		JOIN cw.dealipdrun dir ON dir.RunId=dswf.DealIpdRunId
		JOIN cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN [CW].[vwDealIpdDates] vdid ON vdid.IPD=ipd.IpdDate
		where dir.RunId =@pIPDRunId AND ds.SwapName='Fixed'

	END
	ELSE IF(@dealType='RMBS')
	BEGIN
		INSERT INTO @tblDealBenchmarkCode(RICCode)
		SELECT DISTINCT dlv.Value AS RicCode FROM cfgcw.DealNote dn1 
		JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = dn1.BenchmarkId
		JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
		WHERE dn1.DealId = @pDealId AND dlt.Name = 'Benchmark' 
		

		SELECT * INTO #tempInterestRate FROM cw.InterestRate_wip WHERE IsActive=1

		SELECT
			@interestRateDate = CAST(ipdDt.RateResetDate AS DATE)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
    

		INSERT INTO #tmpSummarizedInformation
		SELECT TOP 1 24 AS DealIpdSummaryLineItemId, 'EURIBOR 3M Interest rate |percent|' + CONVERT(VARCHAR(100), SUM(InterestRate)) AS SummarizedInformation
		FROM 
		(
			SELECT
				ROW_NUMBER() OVER(PARTITION BY ir.InterestRateId ORDER BY ID DESC) AS RowNum    
				,CAST(IIF(wip.InterestRateId IS NOT NULL, ROUND(WIP.Rate,4), ROUND(ir.Rate,4)) AS DECIMAL(30,8)) AS InterestRate
			FROM 
				cw.InterestRate ir
			JOIN
				@tblDealBenchmarkCode dealRC ON ir.RICCode = dealRC.RicCode
			LEFT JOIN 
				#tempInterestRate wip ON ir.InterestRateId = wip.InterestRateId
			WHERE 
					@dealType = 'RMBS' AND (CAST(ir.BaseDate AS DATE)=CAST(@interestRateDate AS DATE))
				
		)t  
		WHERE	
			t.RowNum=1 

	END

	--############### Bond Rating
	DECLARE @RatingDate DATE , @prevRatingDate Date

	SET @RatingDate = ISNULL((
				SELECT CAST(MAX(br.RatingDate) AS DATE)
				FROM CW.vwBondRating br
				JOIN [cfgCW].[DealNote] dn ON dn.ISIN = br.ISIN
				WHERE CAST(br.RatingDate AS DATE) BETWEEN @collectionStartDate
						AND @collectionEndDate
					AND dn.DealId = @pDealId
				), @collectionEndDate)

	SET @prevRatingDate = ISNULL((
				SELECT CAST(MAX(br.RatingDate) AS DATE)
				FROM CW.vwBondRating br
				JOIN [cfgCW].[DealNote] dn ON dn.ISIN = br.ISIN
				WHERE CAST(br.RatingDate AS DATE) BETWEEN @previousIPDCollectionBusinessStart
						AND @previousIPDCollectionBusinessEnd
					AND dn.DealId = @pDealId
				), @previousIPDCollectionBusinessEnd)
		
	IF object_id('tempdb..##TempRatingMasterData') IS NOT NULL
		DROP TABLE #TempRatingMasterData

		
	CREATE TABLE #TempRatingMasterData (
		[UniqueIdentifier] VARCHAR(200)
		,[CRAId] INT
		,[CRA] VARCHAR(200)
		,[RatingTypeId] INT
		,[RatingType] VARCHAR(200)
		,[Rating] VARCHAR(200)
		,[Type] VARCHAR(200)
		);
		 
	IF (@dealType='Covered Bond')
	BEGIN
	 	INSERT INTO #TempRatingMasterData
		EXEC cb.spGetRatingMasterData @pDealId
	END
	ELSE IF(@dealType='RMBS')
	BEGIN
		INSERT INTO #TempRatingMasterData
		EXEC cw.spGetRatingMasterData @pDealId
	END

	DELETE
	FROM #TempRatingMasterData
	WHERE [Type] <> 'Bond'


 
	IF OBJECT_ID('tempdb..#tempBondResult') IS NOT NULL DROP TABLE #tempBondResult
	CREATE TABLE #tempBondResult (
		[ISIN] VARCHAR(200)
		,[CRAId] INT
		,[CRA] VARCHAR(200)
		,[CurrentRating] VARCHAR(200)
		,[PreviousRating] VARCHAR(200)			
		);

	IF (@dealType='Covered Bond')
	BEGIN
		INSERT INTO #tempBondResult
		SELECT curr.ISIN,curr.CRAId,curr.RatingAgency,curr.Rating AS CurrRating, prev.Rating AS PreviousRating  
			from (
					SELECT DISTINCT tempBondData.[UniqueIdentifier] AS ISIN
						,tempBondData.CRAId
						,tempBondData.CRA AS RatingAgency
						,ISNULL(br.Rating, '') AS Rating
					FROM #TempRatingMasterData tempBondData
					INNER JOIN [cfgcb].[DealNote] dn ON tempBondData.[UniqueIdentifier] = dn.ISIN  AND dn.DealId = @pDealId 
					INNER JOIN cb.DealNote_Wf dnwf ON dnwf.DealNoteId = dn.DealNoteId AND dnwf.DealIpdRunId = @pIPDRunId 
					LEFT JOIN cw.vwBondRating br ON CAST(br.RatingDate AS DATE) = @RatingDate
						AND tempBondData.[UniqueIdentifier] = br.ISIN
						AND tempBondData.CRAId = br.CRAId
						AND tempBondData.RatingTypeId = br.RatingTypeId
						) curr

				JOIN 
				(
					SELECT DISTINCT tempBondData.[UniqueIdentifier] AS ISIN
						,tempBondData.CRAId
						,tempBondData.CRA AS RatingAgency
						,ISNULL(br.Rating, '') AS Rating
					FROM #TempRatingMasterData tempBondData
					INNER JOIN [cfgcb].[DealNote] dn ON tempBondData.[UniqueIdentifier] = dn.ISIN  AND dn.DealId = @pDealId 
					INNER JOIN cb.DealNote_Wf dnwf ON dnwf.DealNoteId = dn.DealNoteId AND dnwf.DealIpdRunId = @prevIpdRunId 
					LEFT JOIN cw.vwBondRating br ON CAST(br.RatingDate AS DATE) = @prevRatingDate
						AND tempBondData.[UniqueIdentifier] = br.ISIN
						AND tempBondData.CRAId = br.CRAId
						AND tempBondData.RatingTypeId = br.RatingTypeId
						) prev
				ON curr.ISIN=prev.ISIN and curr.CRAId=prev.CRAId and curr.Rating<>prev.Rating
	END
	ELSE IF(@dealType='RMBS')
	BEGIN
		INSERT INTO #tempBondResult
		SELECT curr.ISIN,curr.CRAId,curr.RatingAgency,curr.Rating AS CurrRating, prev.Rating AS PreviousRating  
			from (
					SELECT DISTINCT tempBondData.[UniqueIdentifier] AS ISIN
						,tempBondData.CRAId
						,tempBondData.CRA AS RatingAgency
						,ISNULL(br.Rating, '') AS Rating
					FROM #TempRatingMasterData tempBondData
					INNER JOIN [cfgCW].[DealNote] dn ON tempBondData.[UniqueIdentifier] = dn.ISIN  AND dn.DealId = @pDealId  
					LEFT JOIN cw.vwBondRating br ON CAST(br.RatingDate AS DATE) = @RatingDate
						AND tempBondData.[UniqueIdentifier] = br.ISIN
						AND tempBondData.CRAId = br.CRAId
						AND tempBondData.RatingTypeId = br.RatingTypeId
						) curr

				JOIN 
				(
					SELECT DISTINCT tempBondData.[UniqueIdentifier] AS ISIN
						,tempBondData.CRAId
						,tempBondData.CRA AS RatingAgency
						,ISNULL(br.Rating, '') AS Rating
					FROM #TempRatingMasterData tempBondData
					INNER JOIN [cfgCW].[DealNote] dn ON tempBondData.[UniqueIdentifier] = dn.ISIN  AND dn.DealId = @pDealId  
					LEFT JOIN cw.vwBondRating br ON CAST(br.RatingDate AS DATE) = @prevRatingDate
						AND tempBondData.[UniqueIdentifier] = br.ISIN
						AND tempBondData.CRAId = br.CRAId
						AND tempBondData.RatingTypeId = br.RatingTypeId					
						) prev
				ON curr.ISIN=prev.ISIN and curr.CRAId=prev.CRAId and curr.Rating<>prev.Rating
	END

	INSERT INTO #tmpSummarizedInformation
	SELECT  IIF(@dealType='Covered Bond', 58, 26) AS DealIpdSummaryLineItemId,
			'|text|' + STUFF((SELECT ', ' + [CRA] + ' ' +  ISIN + ' '+ PreviousRating + ' --> '+ [CurrentRating]  [text()]
					FROM #tempBondResult
						FOR XML PATH(''), TYPE).value('.','NVARCHAR(max)'),1,2,' ') AS SummarizedInformation
		
	--############### Counter Party Rating
		
	DECLARE @counterpartyRatingDate date
	SET @counterpartyRatingDate =ISNULL((
				SELECT CAST(MAX(cr.RatingDate) AS DATE)
				FROM CW.vwCounterpartyRating cr
				JOIN #TempRatingMasterData tcr ON tcr.[CRAId]=cr.[CRAId] AND tcr.[RatingTypeId]=cr.[RatingTypeId]
				WHERE CAST(cr.RatingDate AS DATE) BETWEEN @collectionStartDate
						AND @collectionEndDate					
				), @collectionEndDate);

				DECLARE @prevCounterpartyRatingDate date
	SET @prevCounterpartyRatingDate = ISNULL((
				SELECT CAST(MAX(cr.RatingDate) AS DATE)
				FROM CW.vwCounterpartyRating cr
				JOIN #TempRatingMasterData tcr ON tcr.[CRAId]=cr.[CRAId] AND tcr.[RatingTypeId]=cr.[RatingTypeId]
				WHERE CAST(cr.RatingDate AS DATE) BETWEEN @previousIPDCollectionBusinessStart
						AND @previousIPDCollectionBusinessEnd					
				), @previousIPDCollectionBusinessEnd);
		 
	CREATE TABLE #tempCpRatingMasterData (
		[UniqueIdentifier] VARCHAR(200)
		,[CRAId] INT
		,[CRA] VARCHAR(200)
		,[RatingTypeId] INT
		,[RatingType] VARCHAR(200)
		,[Rating] VARCHAR(200)
		,[Type] VARCHAR(200)
		);

	IF (@dealType='Covered Bond')
	BEGIN
	 	INSERT INTO #tempCpRatingMasterData
		EXEC cb.spGetRatingMasterData @pDealId
	END
	ELSE IF(@dealType='RMBS')
	BEGIN
		INSERT INTO #tempCpRatingMasterData
		EXEC cw.spGetRatingMasterData @pDealId
	END
		
	DELETE
	FROM #tempCpRatingMasterData
	WHERE [Type] <> 'Counterparty'
		
		
	IF OBJECT_ID('tempdb..#tempCpRating') IS NOT NULL DROP TABLE #tempCpRating
	CREATE TABLE #tempCpRating (
		CisCode VARCHAR(200)
		,[CRAId] INT
		,[CRA] VARCHAR(200)
		,[CurrentRating] VARCHAR(200)
		,[PreviousRating] VARCHAR(200)	
		,RatingType VARCHAR(200)
		);
	

	INSERT INTO #tempCpRating
	SELECT curr.CisCode, curr.CRAId,curr.RatingAgency,curr.Rating AS CurrRating, prev.Rating AS PreviousRating ,curr.RatingType 
		from (
				SELECT DISTINCT 
					tempBondData.[UniqueIdentifier] AS CisCode
					,tempBondData.CRAId
					,tempBondData.CRA AS RatingAgency
					,ISNULL(cpr.Rating, '') AS Rating
					,tempBondData.[RatingType] AS RatingType
				FROM #tempCpRatingMasterData tempBondData
				INNER JOIN cfgcw.DealCounterparty dcp ON tempBondData.[UniqueIdentifier] = dcp.CisCode  AND dcp.DealId = @pDealId  
				JOIN [CW].[vw_DealLookup] dlv ON dlv.LookupValueId = dcp.DealCounterpartyTypeId AND dlv.Name <> 'Booking'
				LEFT JOIN cw.vwCounterpartyRating cpr ON CAST(cpr.RatingDate AS DATE) = @counterpartyRatingDate
					AND tempBondData.[UniqueIdentifier] = cpr.CisCode
					AND tempBondData.CRAId = cpr.CRAId
					AND tempBondData.RatingTypeId = cpr.RatingTypeId
					) curr
		JOIN 
		(
				SELECT DISTINCT 
							tempBondData.[UniqueIdentifier] AS CisCode
							,tempBondData.CRAId
							,tempBondData.CRA AS RatingAgency
							,ISNULL(cpr.Rating, '') AS Rating
							,tempBondData.[RatingType] AS RatingType
						FROM #tempCpRatingMasterData tempBondData
						INNER JOIN cfgcw.DealCounterparty dcp ON tempBondData.[UniqueIdentifier] = dcp.CisCode  AND dcp.DealId = @pDealId  
						JOIN [CW].[vw_DealLookup] dlv ON dlv.LookupValueId = dcp.DealCounterpartyTypeId AND dlv.Name <> 'Booking'
						LEFT JOIN cw.vwCounterpartyRating cpr ON CAST(cpr.RatingDate AS DATE) = @prevCounterpartyRatingDate
							AND tempBondData.[UniqueIdentifier] = cpr.CisCode
							AND tempBondData.CRAId = cpr.CRAId
							AND tempBondData.RatingTypeId = cpr.RatingTypeId
							) prev
			ON curr.CisCode=prev.CisCode 
				AND curr.CRAId=prev.CRAId 
				AND curr.RatingAgency=prev.RatingAgency 
				AND curr.RatingType=prev.RatingType 
				AND curr.Rating<>prev.Rating


		 
	INSERT INTO #tmpSummarizedInformation
	SELECT  
			IIF(@dealType='Covered Bond', 59, 27) AS DealIpdSummaryLineItemId, 
			'|text|' + STUFF((SELECT ', ' + [CRA] + ' ' + RatingType + ' ' +  CisCode + ' '+ PreviousRating + ' --> '+ [CurrentRating]  [text()]
					FROM #tempCpRating
						FOR XML PATH(''), TYPE).value('.','NVARCHAR(max)'),1,2,' ') AS SummarizedInformation


	--############### Invoice
	INSERT INTO #tmpSummarizedInformation
	SELECT 
			IIF(@dealType='Covered Bond', 61, 28) AS DealIpdSummaryLineItemId , 
			IIF(ISNULL(SUM(invoice.Amount),0)<>0, 'Total |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(invoice.Amount),0) AS decimal(38,16))),'') AS SummarizedInformation
	FROM
		[CW].[InvoiceData] invoice
	JOIN
		[cfgCW].[InvoiceCategory] IC ON IC.InvoiceCategoryId = invoice.InvoiceCategoryId
	JOIN
		[cfgCW].[InvoiceCategoryType] ICType ON IC.InvoiceCategoryTypeId = ICType.InvoiceCategoryTypeId
	JOIN 
		[cw].[vw_ActiveDeal] deal ON invoice.DealId = deal.DealId
	JOIN 
		[cw].[vw_ActiveDealCounterparty] dcp ON dcp.DealCounterpartyId = invoice.DealCounterpartyId
	JOIN  
		cfgcw.DealLookupValue dlv ON dlv.LookupValueId=invoice.InvoiceStatusId
	JOIN  
		cfgcw.DealLookupType dlt ON dlt.LookupTypeId=dlv.LookupTypeId
	WHERE
		(@pDealId = 0 OR invoice.DealId = @pDealId) AND (CAST(invoice.DealIpdDate AS DATE)=CAST(@currentIpdDate AS DATE))
		AND dlt.TypeCode = 'InvoiceStatus'

	--############### Adjustment
	INSERT INTO #tmpSummarizedInformation
	SELECT 
		IIF(@dealType='Covered Bond', 63, 30) AS DealIpdSummaryLineItemId, 
		IIF(AdjustedAmount <>0, 'Total Adjustments |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(AdjustedAmount,0) AS decimal(38,16))),'') AS SummarizedInformation
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'PreAvailableRevenueReceipts' AND wli.InternalName=IIF(@dealType='Covered Bond','PreAvailableRevenueReceipts_10.000','PreAvailableRevenueReceipts_12.000')

	INSERT INTO #tmpSummarizedInformation
	SELECT 
		IIF(@dealType='Covered Bond', 64, 31) AS DealIpdSummaryLineItemId,  
		IIF(AdjustedAmount <>0, 'Total Adjustments |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(AdjustedAmount,0) AS decimal(38,16))),'') AS SummarizedInformation
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'PreAvailablePrincipalReceipts' AND wli.InternalName=IIF(@dealType='Covered Bond','PreAvailablePrincipalReceipts_8.000','PreAvailablePrincipalReceipts_6.000')

	INSERT INTO #tmpSummarizedInformation
	SELECT 
		IIF(@dealType='Covered Bond', 65, 32) AS DealIpdSummaryLineItemId,  
		IIF(SUM(IsNull(AdjustedAmount,0)) <>0, 'Total Adjustments |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(AdjustedAmount),0) AS decimal(38,16))),'') AS SummarizedInformation
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'RevenuePriorityofPayments' 

	INSERT INTO #tmpSummarizedInformation
	SELECT 
		IIF(@dealType='Covered Bond', 66, 33) AS DealIpdSummaryLineItemId,  
		IIF(SUM(IsNull(AdjustedAmount,0)) <>0, 'Total Adjustments |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(AdjustedAmount),0) AS decimal(38,16))),'') AS SummarizedInformation
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'PrincipalPriorityofPayments' 


	--############### Triggers

	INSERT INTO #tmpSummarizedInformation
	SELECT  
			IIF(@dealType='Covered Bond', 68, 37) AS DealIpdSummaryLineItemId,  
			'Breached |text|' + STUFF((SELECT ', ' + t.DisplayName [text()]
					FROM cw.DealIpdTriggerResult tr 
						JOIN 
							cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId
						JOIN 
							cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId
						JOIN
							cfgcw.TriggerActionType tat ON tam.TriggerActionTypeId =tat.TriggerActionTypeId
						JOIN 
							cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId AND t.DealId = tm.DealId
						JOIN 
							cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId
					WHERE tr.DealIpdRunId=@pIpdRunId 
							AND tm.DealId=@pDealId
							AND tr.IsBreached=1
							AND tt.InternalName = 'RatingTrigger'
						FOR XML PATH(''), TYPE).value('.','NVARCHAR(max)'),1,2,' ') AS SummarizedInformation

	INSERT INTO #tmpSummarizedInformation
	SELECT  
			IIF(@dealType='Covered Bond', 69, 38) AS DealIpdSummaryLineItemId,  
			'Breached |text|' + STUFF((SELECT ', ' + t.DisplayName [text()]
					FROM cw.DealIpdTriggerResult tr 
						JOIN cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId
						JOIN cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId
						JOIN cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId AND t.DealId = tm.DealId
						JOIN cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId
					WHERE tr.DealIpdRunId=@pIpdRunId 
							AND tm.DealId=@pDealId
							AND tr.IsBreached=1
							AND tt.InternalName IN ('NonRatingTrigger','ConditionTrigger')
						FOR XML PATH(''), TYPE).value('.','NVARCHAR(max)'),1,2,' ') AS SummarizedInformation


	--############### Test Result

	INSERT INTO #tmpSummarizedInformation
	SELECT  
			70 AS DealIpdSummaryLineItemId,  
			'Failed Test |text|' + STUFF((SELECT ', ' + [Description] [text()]
					FROM [cb].[DealIpdTestResult] dtr
						join cfgcb.TestType tt ON dtr.TestTypeId=tt.TestTypeID
					WHERE dtr.DealIpdRunId = @pIpdRunId AND Result='FAILED'
						FOR XML PATH(''), TYPE).value('.','NVARCHAR(1000)'),1,2,' ') AS SummarizedInformation

	
	--############### Pre Waterfall Controls 

	IF OBJECT_ID('tempdb..#tempPreWaterFallData') IS NOT NULL DROP TABLE #tempPreWaterFallData
	CREATE TABLE #tempPreWaterFallData(
	StormRevCashCollPeriod				DECIMAL(38, 18),
	StormRevCashCollPostIpdPeriod		DECIMAL(38, 18),	
	SfpRevCashCollPeriod				DECIMAL(38, 18),	
	SfpRevCashCollPostIpdPeriod			DECIMAL(38, 18),
	StormPrinCashCollPeriod				DECIMAL(38, 18),
	StormPrinCashCollPostIpdPeriod		DECIMAL(38, 18),	
	SfpPrinCashCollPeriod				DECIMAL(38, 18),
	SfpPrinCashCollPostIpdPeriod		DECIMAL(38, 18),
	SfpRevAdjustment					DECIMAL(38, 18),	
	SfpPrinAdjustment					DECIMAL(38, 18),
	SfpRevDeflaggedReceipts				DECIMAL(38, 18),
	SfpPrinDeflaggedReceipts			DECIMAL(38, 18),	
	SfpPrinFurtherAdvances				DECIMAL(38, 18)
	)


	INSERT INTO #tempPreWaterFallData
	EXEC cw.spGetAutomatedStormVsSfpData @pDealId,@pIpdRunId,@pUserName 
	 
	SELECT * INTO #tempVariance FROM(
	SELECT ISNULL((StormRevCashCollPeriod + SfpRevCashCollPeriod) + (StormPrinCashCollPeriod + SfpPrinCashCollPeriod),0) AS Variance , 'Receipts' AS VarianceText, 1 AS SortOrder FROM #tempPreWaterFallData
	UNION
	SELECT ISNULL(SfpRevDeflaggedReceipts + SfpPrinDeflaggedReceipts,0)  AS Variance , 'Deflagged Receipts' AS VarianceText, 2 AS SortOrder FROM #tempPreWaterFallData
	UNION
	SELECT ISNULL(SfpPrinFurtherAdvances,0)  AS Variance , 'Further Advances' AS VarianceText, 3 AS SortOrder FROM #tempPreWaterFallData
	UNION
	SELECT ISNULL(SfpRevAdjustment + SfpPrinAdjustment,0) AS Variance , 'Adjustments' AS VarianceText, 4 AS SortOrder FROM #tempPreWaterFallData) d
	
	
	IF EXISTS(SELECT * FROM #tempVariance WHERE Variance <>0)
	BEGIN
		INSERT INTO #tmpSummarizedInformation
		SELECT IIF(@dealType='Covered Bond', 72, 35)  AS DealIpdSummaryLineItemId,  
			'|text|' + STUFF((SELECT ', ' + VarianceText + ' : ' + FORMAT(Variance, 'N') [text()]
									FROM #tempVariance WHERE Variance <>0 ORDER BY SortOrder										 
									FOR XML PATH(''), TYPE).value('.','NVARCHAR(1000)'),1,2,' ') AS SummarizedInformation
	END
	ELSE
		INSERT INTO #tmpSummarizedInformation
		SELECT IIF(@dealType='Covered Bond', 72, 35)  AS DealIpdSummaryLineItemId,  
			 '|text| Variance:Nil' AS SummarizedInformation

	

	--############### cash waterflow

	INSERT INTO #tmpSummarizedInformation
	SELECT 
		IIF(@dealType='Covered Bond', 76, 46) AS DealIpdSummaryLineItemId, 
		'|currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(TotalRequiredAmount,0) AS decimal(38,16))) AS SummarizedInformation
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'PreAvailableRevenueReceipts' AND wli.InternalName=IIF(@dealType='Covered Bond','PreAvailableRevenueReceipts_10.000','PreAvailableRevenueReceipts_12.000')
		
	INSERT INTO #tmpSummarizedInformation
	SELECT 
		IIF(@dealType='Covered Bond', 75, 44) AS DealIpdSummaryLineItemId, 
		'|currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(TotalRequiredAmount,0) AS decimal(38,16))) AS SummarizedInformation
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = 'PreAvailablePrincipalReceipts' AND wli.InternalName=IIF(@dealType='Covered Bond','PreAvailablePrincipalReceipts_8.000','PreAvailablePrincipalReceipts_6.000')
		 
	IF(@dealType='Covered Bond')
	BEGIN
		INSERT INTO #tmpSummarizedInformation
		SELECT 
				77 AS DealIpdSummaryLineItemId , 'Total Paid |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(TotalRequiredAmount),0) AS decimal(38,16))) AS SummarizedInformation
		FROM 
			cfgCW.WaterfallCategory wc
		INNER JOIN 
			cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
		LEFT JOIN
			(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
		LEFT JOIN 
			cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
		WHERE
				dealId=@pDealId
				AND wc.InternalName = 'RevenuePriorityofPayments'
	END 
	ELSE 
	BEGIN 
		INSERT INTO #tmpSummarizedInformation
		SELECT 
			48 AS DealIpdSummaryLineItemId , 'Total Paid |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(TotalPaidAmount),0) AS decimal(38,16))) AS SummarizedInformation
		FROM 
			cfgCW.WaterfallCategory wc
		INNER JOIN 
			cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
		LEFT JOIN
			(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
		LEFT JOIN 
			cw.RevenueWaterfallPayment pwp ON pwp.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
		WHERE
				dealId=@pDealId
				AND wc.InternalName = 'RevenuePriorityofPayments'
				AND pwp.IsEligible=1 and pwp.SourceName='Pre Available Revenue Receipts'
	END

	IF(@dealType='Covered Bond')
	BEGIN
		INSERT INTO #tmpSummarizedInformation
		SELECT 
				78 AS DealIpdSummaryLineItemId , 
				'Total Paid |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(TotalRequiredAmount),0) AS decimal(38,16))) AS SummarizedInformation
		FROM 
			cfgCW.WaterfallCategory wc
		INNER JOIN 
			cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
		LEFT JOIN
			(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
		LEFT JOIN 
			cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
		WHERE
			dealId=@pDealId
			AND wc.InternalName = 'PrincipalPriorityofPayments'
	END
	ELSE
	BEGIN 
		INSERT INTO #tmpSummarizedInformation
		SELECT   	
			50 AS DealIpdSummaryLineItemId , 
			'Total Paid |currency|' +  CONVERT(VARCHAR(100),CAST(IsNull(SUM(TotalPaidAmount),0) AS decimal(38,16))) AS SummarizedInformation
		FROM 
			cfgCW.WaterfallCategory wc
		INNER JOIN 
			cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
		LEFT JOIN
			(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
		LEFT JOIN 
			cw.PrincipalWaterfallPayment pwp ON pwp.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pIpdRunId
		WHERE
				dealId=@pDealId
				AND wc.InternalName = 'PrincipalPriorityofPayments'
				AND pwp.IsEligible=1 and pwp.SourceName='Post Available Principal Receipts'
	END


	--Retrun result
	

	SELECT 
    li.DealId,
    di.IpdDate,
    dir.DealIpdId,
    lis.DealIpdRunId,
    lis.DealIpdSummaryLineItemId,
    lis.DealIpdSummaryLineItemStatusId,
    lis.[Status],
    CASE lis.[Status] WHEN 'Edited' THEN 'Edited'
    WHEN 'SendForAuthorisation' THEN 'Pending Authorisation'
    WHEN 'Authorise' THEN 'Authorised'
    WHEN 'Reject' THEN 'Rejected' 
    WHEN 'Recall' THEN 'Recalled'
    WHEN 'Reset' THEN 'Not Edited'
    ELSE lis.[Status] END AS StepDescription,
    li.CodeName,
    li.DisplayName,
    li.DefaultStatus,
    li.SeqOrder,
    li.ParentId,
    li.IsAuthRequired,
    lis.ModifiedBy AS ActionBy,
	
	ISNULL(tsi.SummarizedInformation,'') As SummaryInfo,
    CASE li.CodeName 
		WHEN 'CashWaterfallSummary-AvailablePrincipalReceipts' THEN '/cashwaterfall/ipdrunprocess/{0}/{1}/cashwaterfall_output/apr' 
		WHEN 'CashWaterfallSummary-AvailableRevenueReceipts' THEN '/cashwaterfall/ipdrunprocess/{0}/{1}/cashwaterfall_output' 
		WHEN 'CashWaterfallSummary-RevenuePriorityOfPayments' THEN '/cashwaterfall/ipdrunprocess/{0}/{1}/cashwaterfall_output/rpp' 
		WHEN 'CashWaterfallSummary-PrincipalPriorityOfPayments' THEN '/cashwaterfall/ipdrunprocess/{0}/{1}/cashwaterfall_output/ppp' 
		ELSE dnm.RouterLink END  AS RouterLink
	 FROM 	[cw].[DealIpdSummaryLineItemStatus] lis
		INNER JOIN [cfgCW].[DealIpdSummaryLineItem] li
			ON lis.DealIpdSummaryLineItemId=li.DealIpdSummaryLineItemId       
		INNER JOIN [cw].[DealIpdRun] dir 
			ON dir.RunId=lis.DealIpdRunId
		INNER JOIN [cw].[DealIpd] di 
			ON di.DealIpdId=dir.DealIpdId
		LEFT JOIN [cfgCW].[DealNavbarMenu] dnm
			ON dnm.MenuName=li.DisplayName 
				AND dnm.dealID = @pDealId 
				AND dnm.DealId = li.DealId
		LEFT JOIN #tmpSummarizedInformation tsi
			ON li.DealIpdSummaryLineItemId=tsi.DealIpdSummaryLineItemId
	WHERE dir.RunId = @pIpdRunId 
		AND di.DealId=@pDealId
	ORDER BY li.SeqOrder 
	
END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1,1,'cw.spGetDealIpdSummary',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END

GO
