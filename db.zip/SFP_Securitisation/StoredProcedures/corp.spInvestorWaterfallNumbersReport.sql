USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'corp.spInvestorWaterfallNumbersReport') AND type in (N'P',N'PC'))
   DROP PROCEDURE corp.spInvestorWaterfallNumbersReport
GO

--SET ANSI_NULLS ON
--GO
SET QUOTED_IDENTIFIER ON
GO

	
-----------------------------------------------------------------------------------------------  
  /*
  Author: Mukesh Sharma
  Date: 2022-10-05
  Description:  Generating Strats from  Investor waterfall number report  
  Changes           13-Feb-2023: Mukesh Added Max Reference Portfolio Notional Amount logic 
					15-March-2023:Mukesh Added extra workflowids and chnage logic for final loss amount
 */--exec  [corp].[spInvestorWaterfallNumbersReport] '2022-12-30',1,null
------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [corp].[spInvestorWaterfallNumbersReport]
(
	 @pAsAtDate DATE ,
	 @pDealId INT = NULL,
	 @pUserName VARCHAR(100)=NULL
)
AS
BEGIN
	
            
            DECLARE 
	        @PartitionId BIGINT,
            @ReportTemplateName varchar(100),
            @ReportTemplateName1 varchar(100),
            @msgtxt VARCHAR(100) = '',
			@DealIdS INT,
			@DealName Varchar(50),
		    @DealIdCommonSP INT,
		    @Recoveries DECIMAL(23,2),
			@DealSize FLOAT,
			@PreviousQuarter DATE,
			@PreviousQuarterAsAtDate DATE,
		    @RowId VARCHAR(100) ,
			@CurrentQuarterRona FLOAT,
		    @PreviousQuarterRona FLOAT,
			@DefaultedNotionalamount FLOAT,
		    @ReqCols XML,
			@MaxPartitionID VARCHAR (10),
			@MaxBusinessDate VARCHAR(10),
			@InitialLossAmount FLOAT,
			@InitialFlaggingDate DATE,
			@InitialReferencePortfolioNotionalAmount FLOAT,
			@InitialLossAmount_Claimed  FLOAT,
			@FinalLossAmount_Claimed  FLOAT,
			@MaxReferencePortfolioNotionalAmount FLOAT,
			@AmortisationAmount  FLOAT,
			@TopUpFlag INT

    BEGIN TRY
    SET @msgtxt = 'Calculating variables  ' + CONVERT(VARCHAR(20), getdate(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	SET @DealIdCommonSP                                   = @pDealId
	SET @DealName                                         =(SELECT DealName from [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealId=@pDealId  AND IsActive='Y')
	SET @DealIdS                                          =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)
	SET @PreviousQuarter                                  =(SELECT DATEADD(MONTH,-3,asatdate)FROM [sfp].[syn_SfpModel_vw_Calendar_v1] WHERE asatdate=@pAsAtDate AND Regioncode='UK')
	SET @PreviousQuarterAsAtDate                          =(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]   WHERE IsWorkingDay=1 AND MONTH(asatdate)=MONTH(@PreviousQuarter) AND YEAR(asatdate)=YEAR(@PreviousQuarter) AND Regioncode='UK')
	SET @Recoveries                                       =(SELECT SUM(RealisedRecoveries) FROM [corp].[LossManagement] WHERE DealId= @DealIdS)
	SET @DealSize                                         =(SELECT  DealInitialSize FROM [cfg].[Deal] WHERE DealId=  @DealIdS and isactive=1)
	SET @MaxPartitionID                                   =(SELECT MAX(partitionid) FROM [corp].[syn_Corporate_tbl_dw.Fact_Facility])  
    SET @MaxBusinessDate                                  =CONVERT(CHAR(10), CONVERT(datetime, @MaxPartitionID), 120)  
	--SET @InitialFlaggingDate                              =(SELECT MIN(poolFlaggingDateKey) FROM [corp].[syn_SfpModelCorporate_vw_FactCorporateAssetPool] WHERE DealId = @pDealId)
	--SET @InitialReferencePortfolioNotionalAmount          =(SELECT SUM(ISNULL(RonaAtFlagging,0.00)) FROM [corp].[syn_SfpModelCorporate_vw_FactCorporateAssetPool] WHERE DealId = @pDealId AND poolFlaggingDateKey = @InitialFlaggingDate)
	SET @TopUpFlag										  =(SELECT Count(1) from [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal]  WHERE DealId =@pDealId  AND IsActive='Y' AND TopupFlag='Y')
	SET @InitialReferencePortfolioNotionalAmount          =ISNULL(@DealSize,0.00)


	 /* CONVERT REQUIRED COLUMN NAMES TO XML FORMAT */  
    SET @ReqCols                                        =(SELECT CriteriaFieldName  
                                                         FROM (Values
												         ('FacilityId')  
                                                        ,('DealName')  
                                                        ,('RONA')  
                                                        ,('B2_APP_EAD_PRE_CRM_AMT')  
                                                        ,('MasterGradingScore')) Field(CriteriaFieldName)  
                                                         FOR XML PATH('Node'), ROOT('Root') )
		 
         /* Droping and crating temp tables */
  	IF OBJECT_ID('tempdb..#investorwaterfallnumbersdata') IS NOT NULL DROP TABLE #investorwaterfallnumbersdata
	IF OBJECT_ID('tempdb..#investorwaterfallnumbersdataUnpivot') IS NOT NULL DROP TABLE #investorwaterfallnumbersdataUnpivot
	IF OBJECT_ID('tempdb..#LossesData') IS NOT NULL DROP TABLE #LossesData  
    IF OBJECT_ID('tempdb..#Facilities') IS NOT NULL DROP TABLE #Facilities  

    

	 SET @msgtxt = 'Invoking common sp to fetch RONA for CurrentQuarterRona  ' + CONVERT(VARCHAR(20), getdate(), 121)
     RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	/** Calculating  Rona for current quarter **/
	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]  
	 @VintageDate                                     = @pAsAtDate
	,@DealKey                                         = @pDealId
	,@OutputRowID                                     = @RowID OUTPUT 
	
    SET @CurrentQuarterRona                           =(SELECT SUM(CurRona.RONA)	FROM	
	                                                   (SELECT DISTINCT FACILITYID,RONA FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging]
                                                        WHERE RowId = @RowID)CurRona)


	SELECT DISTINCT FacilityId 
	INTO #Facilities FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging]
    WHERE RowId = @RowID

	SET @InitialLossAmount_Claimed                    =(SELECT  SUM(ISNULL(InitialLossAmount,0.0))  FROM corp.LossManagement 
	                                                    WHERE workflowstepid IN (90, 93, 94, 96,97) AND FacilityId IN(SELECT DISTINCT FacilityId FROM #Facilities)  
														AND DealID=@DealIdS  AND IsActive=1)

	                                                    

	SET @FinalLossAmount_Claimed                     =(SELECT  SUM(ISNULL(FinalLossAmount,0.0))  FROM corp.LossManagement 
	                                                   WHERE workflowstepid IN(95,98) AND FacilityId IN(SELECT DISTINCT FacilityId FROM #Facilities)  
													   AND DealID=@DealIdS  AND IsActive=1)
													   
	SET @FinalLossAmount_Claimed					= CASE WHEN @FinalLossAmount_Claimed<0 THEN 0 ELSE @FinalLossAmount_Claimed END
												   

	SET @AmortisationAmount							= CASE WHEN @TopUpFlag>0 THEN 0.00
													  ELSE ISNULL(@InitialReferencePortfolioNotionalAmount,0.00)-ISNULL(@CurrentQuarterRona,0.00)
													  END

    SET @MaxReferencePortfolioNotionalAmount		=ISNULL(@InitialReferencePortfolioNotionalAmount,0.00)-ISNULL(@InitialLossAmount_Claimed,0.00)-ISNULL(@FinalLossAmount_Claimed,0.00)-ISNULL(@AmortisationAmount,0.00)

    DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

	SET @msgtxt = 'Invoking common sp to fetch RONA for PreviousQuarterRona  ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	/** Calculating Rona for previous quarter **/
    EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
	 @VintageDate                                 =@PreviousQuarterAsAtDate
	,@DealKey                                     =@pDealId
	,@OutputRowID                                 =@RowID OUTPUT 
	 
    SET @PreviousQuarterRona                      =ISNULL((SELECT SUM(PrevRona.RONA)FROM	
	                                              (SELECT DISTINCT FACILITYID,RONA FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging]
                                                   WHERE RowId = @RowID)PrevRona),0.00)


	 SET @msgtxt = 'Invoking common sp to fetch [DefaultedNotional] ' + CONVERT(VARCHAR(20), GETDATE(), 121)
     RAISERROR(@msgtxt, 10, 1) WITH NOWAIT
	  	/** Calculating Defaulted Notional **/
	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
	 @VintageDate                                   =@MaxBusinessDate
	,@DealKey                                       =@pDealId
	,@ReqColumns                                    =@ReqCols,  
     @OutputRowID                                   =@RowID OUTPUT   

	 SELECT   
     DL.Dealid AS [DealId]  
    ,CONVERT(INT, LossData.FacilityId) AS [FacilityId]  
    ,CASE  
     WHEN LossData.RONA < ISNULL(LossData.EAD, 0.00) * Dl.RiskRetentionPercent THEN LossData.RONA  
     ELSE ISNULL(LossData.EAD, 0.00) * Dl.RiskRetentionPercent  
     END AS [DefaultedNotional]  
	 INTO  #LossesData
	 FROM
	 (SELECT DISTINCT   
     DealName  
    ,FacilityId  
    ,RONA  
    ,B2_APP_EAD_PRE_CRM_AMT AS [EAD]  
    FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID AND MasterGradingScore = '27' 
    ) AS
    LossData  
    INNER JOIN [cfg].[Deal] DL ON DL.DealName = LossData.DealName 
  
  
   SET @InitialLossAmount                       =(SELECT  SUM(InitialLossAmountData.InitialLossAmount)
	                                             FROM ( SELECT LossmanagementData.FacilityId
	                                             ,LossData.[DefaultedNotional] *LossmanagementData.InitialLossPercent AS InitialLossAmount 
		                                         ,LossmanagementData.DealId FROM #LossesData  AS LossData INNER  JOIN 
                                                 (SELECT FacilityId
		                                         ,DealId
		                                         ,InitialLossPercent
		                                         ,DefaultDate FROM [corp].[LossManagement] WHERE DefaultDate<@pAsAtDate AND IsActive=1 AND DealId=@DealIdS) AS LossmanagementData 
								                  ON LossmanagementData.FacilityId=LossData.FacilityId)
                                                  AS InitialLossAmountData GROUP BY InitialLossAmountData.DealId)

    DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID 
     
 

	SELECT  * 
	INTO #investorwaterfallnumbersdata
	FROM [corp].[syn_SfpStaging_tbl_Import_Investor_Report_Waterfall_Number] AS STAGE where STAGE.DEAL_ID=@DealName
	AND STAGE.Date=@pAsAtDate


	SET @DefaultedNotionalamount                  =ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Defaulted Notional amount'),0.00)

	   
    SET @msgtxt = 'Report Generation Started ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT   
 
	  SELECT 
	  [Defaulted Notional amount]                             = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Defaulted Notional amount'),0.00))
	 ,[Failure to pay restructuring]                          = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Failure to pay restructuring'),0.00))
	 ,[Restructured principal amount]                         = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Restructured principal amount'),0.00))
	 ,[credit loss event amount (loss on restructuring)]      = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='credit loss event amount (loss on restructuring)'),0.00))
     ,[Guarantee Fee Component Amount]                        = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Guarantee Fee Component Amount'),0.00))
	 ,[Make-Up Guarantee Spread Amount]                       = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Make-Up Guarantee Spread Amount'),0.00))
	 ,[Guarantee Fee Shortfall Amount]                        = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Guarantee Fee Shortfall Amount'),0.00))
	 ,[Collateral Shortfall Amount]                           = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Collateral Shortfall Amount'),0.00))
	 ,[Outstanding Shortfall Amount]                          = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Outstanding Shortfall Amount'),0.00))
	 ,[Guarantee Fee Amount]                                  = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Guarantee Fee Amount'),0.00))
	 ,[Collateral Securities Income]                          = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Collateral Securities Income'),0.00))
	 ,[Collateral Securities Income Top-Up Amount]            = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Collateral Securities Income Top-Up Amount'),0.00))
	 ,[Interest Shortfall Amount]                             = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Interest Shortfall Amount'),0.00))
	 ,[Brought Forward Protected Tranche Notional Amount]     = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Brought Forward Protected Tranche Notional Amount'),0.00))
	 ,[Protected Tranche Amortisation Amount]                 = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Protected Tranche Amortisation Amount'),0.00))
	 ,[Loss Balance]                                          = CONVERT(DECIMAL(23,2),ISNULL(@InitialLossAmount,0.00))
	 ,[Credit Loss Event Amount]                              = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Credit Loss Event Amount'),0.00))
	 ,[Carried Forward Protected Tranche Notional Amount]     = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Carried Forward Protected Tranche Notional Amount'),0.00))
	 ,[Protection Payment Amount]                             = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Protection Payment Amount'),0.00))
	 ,[Protection Payment Adjustment Amount]                  = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Protection Payment Adjustment Amount'),0.00))
	 ,[Paid Loss]                                             = CONVERT(DECIMAL(23,2),ISNULL((SELECT VALUE FROM #investorwaterfallnumbersdata WHERE RTRIM(LTRIM(ATTRIBUTE))='Paid Loss'),0.00))
	 ,[Current Month RONA]                                    = CONVERT(DECIMAL(23,2),ISNULL(@CurrentQuarterRona,0.00))
	 ,[Previous Quarter RONA]                                 = CONVERT(DECIMAL(23,2),ISNULL(@PreviousQuarterRona,0.00))
	 ,[Recoveries]                                            =CONVERT(DECIMAL(23,2),ISNULL(@Recoveries,0.00))
	 ,[Deal Size]                                             =CONVERT(DECIMAL(23,2),ISNULL(@DealSize,0.00))
	 ,[Default amount off Max RONA]                           =CONVERT(DECIMAL(23,2),IIF(@CurrentQuarterRona>@DefaultedNotionalamount, @DefaultedNotionalamount, ISNULL(@CurrentQuarterRona,0.00)))
	 ,[Max Reference Portfolio Notional Amount]				  =CONVERT(DECIMAL(23,2),@MaxReferencePortfolioNotionalAmount)
	  INTO #investorwaterfallnumbersdataUnpivot

	 SELECT [Attributes],Value as [Values]
	 FROM #investorwaterfallnumbersdataUnpivot
	 UNPIVOT 
	 ( 
	 Value FOR [Attributes] IN ( 
	 [Defaulted Notional amount]
	,[Failure to pay restructuring]
	,[Restructured principal amount]
	,[credit loss event amount (loss on restructuring)]
	,[Guarantee Fee Component Amount]
	,[Make-Up Guarantee Spread Amount]
	,[Guarantee Fee Shortfall Amount]
	,[Collateral Shortfall Amount]
	,[Outstanding Shortfall Amount]
	,[Guarantee Fee Amount]
	,[Collateral Securities Income]
	,[Collateral Securities Income Top-Up Amount]
	,[Interest Shortfall Amount]
	,[Brought Forward Protected Tranche Notional Amount]
	,[Protected Tranche Amortisation Amount]
	,[Loss Balance]
	,[Credit Loss Event Amount]
	,[Carried Forward Protected Tranche Notional Amount]
	,[Protection Payment Amount]
	,[Protection Payment Adjustment Amount]
	,[Paid Loss]
	,[Current Month RONA]
	,[Previous Quarter RONA]
	,[Deal Size]
	,[Default amount off Max RONA]
	,[Max Reference Portfolio Notional Amount]

	)
	) 
	AS UnpivotTable


	SET @msgtxt = 'End of Report generation : ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	END TRY
     BEGIN CATCH                  
     DECLARE       
	 @errorMessage     NVARCHAR(MAX),      
	 @errorSeverity    INT,      
	 @errorNumber      INT,      
	 @errorLine        INT,      
     @errorState       INT;      
     DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
     SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()     
     EXEC app.SaveErrorLog 2, 1, 'spStratificationDelinquencyData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName   
     RAISERROR (@errorMessage,  @errorSeverity,  @errorState )              
     END CATCH   

  END

