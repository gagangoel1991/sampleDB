USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetReserveFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetReserveFund]
GO

/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 19-07-2022 09:30:19 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 17-05-2021 
-- Change History
-- A.S.		06-07-2022		Removed dependency of table for display items.
--							Added child for two items
--Description: GET Reserve Fund 
--[cb].[spGetReserveFund] 6,60,''
--==================================   
CREATE PROCEDURE [cb].[spGetReserveFund] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
			DECLARE @colsUnpivot AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX);
			DECLARE @RequiredAmount1_Tooltip AS NVARCHAR (MAX);
			DECLARE @RequiredAmount2_Tooltip AS NVARCHAR (MAX);

			SET @RequiredAmount1_Tooltip = '(i) If the Issuer''s short-term, unsecured, unsubordinated and unguaranteed debt obligations are not rated at least F1+ by Fitch, an amount equal to the Sterling Equivalent of amounts of interest due on each Series of Covered Bonds in the immediately following three months, together with an amount equal to three-twelfths of the anticipated aggregate annual amount payable in respect of the items specified in paragraphs (a) to (c) of the Pre-Acceleration Revenue Priority of Payments, plus '+CHAR(0128)+'7,000,000 or such other amount (not less than amount equal to the Sterling Equivalent of one month''s interest due on each Series of Covered Bonds together with an amount equal to one-twelfth of the anticipated aggregate annual amount payable in respect of the items specified in paragraphs (a) to (c) of the Pre-Acceleration Revenue Priority of Payments, plus '+CHAR(0128)+'7,000,000) as notified by RBS to Fitch from time to time; and'
	        SET @RequiredAmount2_Tooltip = '(ii) If the Issuer''s short-term, unsecured, unsubordinated and unguaranteed debt obligations are not rated at least P-1 by Moody''s, an amount equal to the Sterling Equivalent of one month''s interest due on each Series of Covered Bonds together with an amount equal to one-twelfth of the anticipated aggregate annual amount payable in respect of the items specified in paragraphs (a) to (c) of the Pre-Acceleration Revenue Priority of Payments plus '+CHAR(0128)+'7,000,000.'

			IF( Object_id('tempdb..#temp') IS NOT NULL )				DROP TABLE #temp
			IF( Object_id('tempdb..#tempTransposed') IS NOT NULL )		DROP TABLE #tempTransposed
			IF( Object_id('tempdb..#tempLineItemConfig') IS NOT NULL)	DROP TABLE #tempLineItemConfig

				  CREATE TABLE #tempTransposed ( 
						[IpdDate] [date] NULL,
						[ColumnName] [varchar](100) NULL,
						[LineItemValue] varchar(200) )

				  CREATE TABLE #tempLineItemConfig ( 
						[Id] [int] NULL,
						[ParentId] [int] NULL,
						[ColumnName] [varchar](100) NULL,
						[DisplayName] [varchar](500) NULL,
						[LineItemTooltip] [nvarchar](MAX) NULL)

					insert into #tempLineItemConfig 
					values
					 (1,NULL,'TestResult','Reserve Fund Establishment Trigger Result', NULL)
					,(2,NULL,'ReserveFund_bF','Reserve Ledger B/F', NULL)
					,(3,NULL,'FinalRequiredAmount','Final Required Amount', NULL)
					,(4,3,'RequiredAmount1','Required Amount1', @RequiredAmount1_Tooltip)
					,(5,4,'RequiredAmount1_1','Three-twelfth of the 12 months rolling amount of (a) to (c ) of ARR', NULL)
					,(6,4,'RequiredAmount1_2','Reserve Fund Provision Value', NULL)
					,(7,4,'RequiredAmount1_3','Estimated 3 months Total Note Interest', NULL)
					,(8,3,'RequiredAmount2','Required Amount2', @RequiredAmount2_Tooltip)
					,(9,8,'RequiredAmount2_1','12 months rolling fees', NULL)
					,(10,8,'RequiredAmount2_2','Reserve Fund Provision Value', NULL)
					,(11,8,'RequiredAmount2_3','Estimated 1 months Total Note Interest', NULL)
					,(12,NULL,'DueAmount','Due Amount', NULL)
					,(13,NULL,'ResidualAmount','Residual Amount', NULL)
					,(14,NULL,'ReleaseToARR','Release To ARR', NULL)
					,(15,NULL,'CreditReceived','Credit Received', NULL)
					,(16,NULL,'ReserveFund_cf','Reserve Ledger C/F', NULL)

					  DECLARE @dealId  INT, 
				  @ipdDate DATE,
				  @twelveMonthsRollingFeesForCRpp decimal(38,16),
				  @sumOfEstimatedThreeMonthInterest_GBP decimal(38,16),
				  @sumOfEstimatedOneMonthInterest_GBP decimal(38,16),
				  @requiredAmount1_1 decimal(38,16),
				  @requiredAmount1_2 decimal(38,16),
				  @requiredAmount2_1 decimal(38,16),
				  @requiredAmount2_2 decimal(38,16),
				  @IPD_12months datetime

          SELECT @dealId = DealId, 
				@ipdDate = IpdDate
          FROM   cw.vwDealIpdRun dir
          WHERE  DealIpdRunId = @pIPDRunId 
		  
		   SET @IPD_12months=(SELECT DealDateValue 
                              FROM   cw.vwDealDate 
                              WHERE  DealIpdRunId=@pIPDRunId 
                                     AND DealDateKeyInternalName = 'IPD-12months')

				SET @twelveMonthsRollingFeesForCRpp = (SELECT COALESCE(SUM(waterfallAmount),0) FROM cb.WaterfallLineItemCAmount 
														WHERE ipdDate>=@IPD_12months AND ipdDate<@ipdDate);

				SET @twelveMonthsRollingFeesForCRpp = (SELECT COALESCE(SUM(WaterfallLineItemTotalRequiredAmount),0)+@twelveMonthsRollingFeesForCRpp
														FROM [CW].[vwWaterfallLineItemAmount]
														WHERE WaterfallCategoryInternalName='RevenuePriorityofPayments'
															AND WaterfallLineItemRank=3
															AND DealIpdRunId IN (
																		SELECT max(DealIpdRunId) 
																		FROM cw.vwDealIpdRUn
																		WHERE ipddate>(SELECT max(ipddate) FROM cb.WaterfallLineItemCAmount) 
																		AND dealid=@dealId AND ipddate<@ipdDate AND ipdDate>=@IPD_12months 
																		GROUP BY ipddate))
				
				SET @twelveMonthsRollingFeesForCRpp = (SELECT COALESCE(SUM(WaterfallLineItemTotalRequiredAmount),0)
														+@twelveMonthsRollingFeesForCRpp
														FROM [CW].[vwWaterfallLineItemAmount]
														WHERE DealIpdRunId=@pIPDRunId
															AND WaterfallCategoryInternalName='RevenuePriorityofPayments'
															AND WaterfallLineItemRank=3)

				SELECT  @sumOfEstimatedThreeMonthInterest_GBP= SUM(EstimatedThreeMonthInterest_GBP)
						, @sumOfEstimatedOneMonthInterest_GBP= SUM(EstimatedOneMonthInterest_GBP)
						FROM Cb.DealNote_Wf 		
						WHERE DealIpdRunId = @pIPDRunId;

				SET @requiredAmount1_1 = (SELECT CONVERT(decimal(12,10),1.0)/4.0
										*(@twelveMonthsRollingFeesForCRpp + CONVERT(DECIMAL(38,16),Value))
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ExpectedThirdPartyExpenses')

				SET @requiredAmount1_2 = (SELECT 
										CONVERT(DECIMAL(38,16),Value)
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ReserveFundProvisionValue')

			SET @requiredAmount2_1 = (SELECT 
										CONVERT(decimal(12,10),1.0)/12.0
										*(@twelveMonthsRollingFeesForCRpp + CONVERT(DECIMAL(38,16),Value))
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ExpectedThirdPartyExpenses')
										
			SET @requiredAmount2_2 = (SELECT 
										CONVERT(DECIMAL(38,16),Value)
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ReserveFundProvisionValue')

		SELECT		dir.IpdDate
					,CAST(CASE tr.IsBreached WHEN 1 THEN 'FAIL' WHEN 0 THEN 'PASS' END as varchar(200)) AS TestResult
					,CAST(rf_preWf.ReserveFund_bF as varchar(200)) ReserveFund_bF
					,CAST(rf_preWf.FinalRequiredAmount as varchar(200)) FinalRequiredAmount
					,CAST(rf_preWf.RequiredAmount1 as varchar(200)) RequiredAmount1
					,CAST(@requiredAmount1_1 as varchar(200)) RequiredAmount1_1
					,CAST(@requiredAmount1_2 as varchar(200)) RequiredAmount1_2
					,CAST(@sumOfEstimatedThreeMonthInterest_GBP as varchar(200)) RequiredAmount1_3
					,CAST(rf_preWf.RequiredAmount2 as varchar(200)) RequiredAmount2
					,CAST(@requiredAmount2_1 as varchar(200)) RequiredAmount2_1
					,CAST(@requiredAmount2_2 as varchar(200)) RequiredAmount2_2
					,CAST(@sumOfEstimatedOneMonthInterest_GBP as varchar(200)) RequiredAmount2_3
					,CAST(rf_preWf.DueAmount as varchar(200)) DueAmount
					,CAST(rf_preWf.ResidualAmount as varchar(200)) ResidualAmount
					,CAST(rf_preWf.ReleaseToARR as varchar(200)) ReleaseToARR
					,CAST(ISNULL(rf_postWf.CreditReceived,0) as varchar(200)) CreditReceived
					,CAST(ISNULL(rf_postWf.ReserveFund_cf,0) as varchar(200)) ReserveFund_cf
					into #temp
				FROM cfgcb.CoveredBondFund cbf
				JOIN cb.ReserveFund_PreWF rf_preWf		ON cbf.CoveredBondFundId = rf_preWf.CoveredBondFundId AND rf_preWf.IsActive = 1
				JOIN cw.vwdealipdrun dir				ON dir.DealIpdRunId = rf_preWf.DealIpdRunId
				JOIN [cw].[vwDealIpdTriggerResult] tr	ON cbf.ApplicableId = tr.TriggerId AND tr.DealIpdRunId = dir.DealIpdRunId
				LEFT JOIN cb.ReserveFund_PostWF rf_postWf ON cbf.CoveredBondFundId = rf_postWf.CoveredBondFundId
					AND rf_postWf.IsActive = 1
					and dir.DealIpdRunId = rf_postWf.DealIpdRunId
					where  cbf.CoveredBondFundId=2
					and dir.DealIpdRunId IN (
						SELECT RunId
						FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId, 4)
						)
						order by dir.IpdDate desc

				   set @colsUnpivot='[TestResult],[ReserveFund_bF],[FinalRequiredAmount],[RequiredAmount1],[RequiredAmount1_1],[RequiredAmount1_2],[RequiredAmount1_3],[RequiredAmount2],[RequiredAmount2_1],[RequiredAmount2_2],[RequiredAmount2_3],[DueAmount],[ResidualAmount],[ReleaseToARR],[CreditReceived],[ReserveFund_cf]'

		set @query 
		  = 'select IpdDate,
			   ColumnName,
			   LineItemValue
			 from #temp
			 unpivot
			 (
				LineItemValue
				for ColumnName in ('+ @colsunpivot +')
			 ) u'

		INSERT into #tempTransposed execute ('exec sp_executesql N''''' + @query +'')
		select CAST(IpdDate as date) as IpdDate, Id as TestLineItemId, ParentId as ParentTestLineItemId, 
		DisplayName, LineItemValue, LineItemTooltip from #tempTransposed t join #tempLineItemConfig l ON t.ColumnName = l.ColumnName
		Order by IpdDate,Id

	END TRY
	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetReserveFund'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END