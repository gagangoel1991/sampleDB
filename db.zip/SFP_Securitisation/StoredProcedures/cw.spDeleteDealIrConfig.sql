USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spDeleteDealIrConfig]') IS NOT NULL
	DROP PROCEDURE [cw].[spDeleteDealIrConfig]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [cw].[spDeleteDealIrConfig]
/*
 * Author: Kapil Sharma
 * Date:	17.12.2020
 * Description:  This will delete the Deal Ir Config
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIrConfigId			INT,
@pUserName					VARCHAR(80),
@pResult					INT OUTPUT --This will return the outcome the action. 1 - Success, -1 - Locked
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		BEGIN TRANSACTION 
	
		IF EXISTS(SELECT TOP 1 * FROM cfgCW.IR_DealIRConfig WHERE DealIRConfigId = @pDealIrConfigId AND IsLocked = 0)
		BEGIN
			-- Mapped Fields Delete
			DECLARE @OutputTblPoolAdhocReportFieldMapId TABLE (PoolAdhocReportFieldMapId INT);
			DELETE fieldMap 
			OUTPUT deleted.PoolAdhocReportFieldMapId INTO @OutputTblPoolAdhocReportFieldMapId(PoolAdhocReportFieldMapId) 
			FROM [ps].[PoolAdhocReportFieldMap] fieldMap
			JOIN ps.EligibilityCriteriaField ec 
				ON fieldMap.EligibilityCriteriaFieldId = ec.EligibilityCriteriaFieldId
			JOIN [cfgCW].[IR_DealIrStratMap]  smap 
				ON smap.StratId = fieldMap.StratId	             
            AND smap.DealIrConfigId = @pDealIrConfigId  

			-- Mapping Delete
			DECLARE @OutputTblStratId TABLE (StratId INT);
			DELETE FROM	[cfgCW].[IR_DealIrStratMap]
			OUTPUT deleted.StratId INTO @OutputTblStratId(StratId) 
			WHERE DealIrConfigId = @pDealIrConfigId 

			--Dynamic Strat Delete 
			IF((SELECT COUNT(1) FROM @OutputTblPoolAdhocReportFieldMapId) > 0 )
			BEGIN

				-- Dynamic Misc Strat Delete
				DELETE MiscStrat 
				FROM cfgCW.IR_MiscStrat MiscStrat 
				JOIN @OutputTblStratId StIds
					 ON MiscStrat.StratId = StIds.StratId

				--Dynamic Strat Delete
				DELETE strat 
				FROM cfgCW.IR_Strat strat 
				JOIN @OutputTblStratId StIds
					 ON strat.StratId = StIds.StratId
			END
			
			
			DELETE FROM [cfgCW].[IR_DealIrConfig]  WHERE DealIrConfigId	= @pDealIrConfigId;

			-----Releasing the locked record --==================================
			SELECT DISTINCT TemplateId INTO #Template FROM [cfgCW].[IR_DealIrConfig] dic  Where TemplateId IS NOT NULL
			Update T 	SET IsLocked =1 	FROM #Template tmpT 	INNER JOIN cfgCW.IR_Template T on T.TemplateId=tmpT.TemplateId
			Update T	SET IsLocked =0 	FROM cfgCW.IR_Template T 	Where T.TemplateId not in (Select TemplateId FROM #Template)



			SET @pResult = 1
		END
		ELSE
			SET @pResult = -1 --Record is locked

		COMMIT TRANSACTION     	
	END TRY
	BEGIN CATCH
		IF @@trancount > 0 ROLLBACK TRANSACTION; 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spDeleteDealIrConfig', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
