USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetProductSwitchReport') IS NOT NULL
	DROP PROC CW.spGetProductSwitchReport
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Product switch for Investor report.
 * Usage : CW.spGetProductSwitchReport @pAsAtDate  = '30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetProductSwitchReport @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN			
	BEGIN TRY
		DECLARE @previous_AsAtdate DATE = ( SELECT sfp.syn_SfpModel_FnPreviousReportDate(@pAsAtDate, 3)  )
		DECLARE @dealId int;
		DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		, @partitionID_AsAtDate_Prior INT  = CONVERT(INT, CONVERT(VARCHAR(8), @previous_AsAtdate, 112)) 
	
		DECLARE @totalSubAccounts float, @totalOutstandingCapitalBalance float
		, @capitalBalanceAtFlagged float
		, @mortgagedealstart DATE 
		, @dealkey INT
		, @lookupName varchar(100)
		, @paymentHoliday varchar(100) ='Payment Holiday (Current)'
	
	
		SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
		SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
		SELECT * INTO #VwMortgageSubAccountPrior  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1 
	
	
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
		INSERT INTO #VwMortgageSubAccount   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId

		EXEC [CW].[spCheckAndLoadMortgageFieldData] @previous_AsAtdate, @dealId
		INSERT INTO #VwMortgageSubAccountPrior   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate_Prior AND MortgageDealKey = @dealId
 
 
		CREATE TABLE #ProductSwitchGroup(SortOrder INT IDENTITY (1,1), ProductSwitchGroup varchar(255))
		CREATE TABLE #ProductSwitchType(ProductSwitchTypeId INT, Name varchar(255), ProductSwitchGroup varchar(255))
	
		SET @lookupName = 'PRODUCT_SWITCH'

		SELECT @dealId = dealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName

		INSERT INTO #ProductSwitchGroup (ProductSwitchGroup)
		SELECT DISTINCT ld.LookupValueDescription  
		FROM  [cfgCW].[ProductSwitchType] pt
		INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 ld ON ld.LookUpValue=pt.Name 
		AND ReportTemplateName='SFP+' AND LookupName=@lookupName
		UNION 
		SELECT @paymentHoliday AS 'ProductSwitchGroup'


		INSERT INTO #ProductSwitchType
		SELECT pt.ProductSwitchTypeId, pt.Name, ld.LookupValueDescription  FROM  [cfgCW].[ProductSwitchType] pt
		INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 ld ON ld.LookUpValue=pt.Name 
		AND ReportTemplateName='SFP+' AND LookupName=@lookupName
	
	
		SELECT @totalOutstandingCapitalBalance = sum(Outstandng_Capital_Balance_Amt)
		FROM #VwMortgageSubAccount
	
	
	
		SELECT ProductSwitchGroup,  SUM(QuarterlyLoanCount)  AS [MortgageLoans], SUM(QuarterlyCapitalBalanceValue) AS TotalOutstandingCapitalBalance
		, CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast((sum(QuarterlyCapitalBalanceValue) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
		INTO #CrntProduct
		FROM [cw].[DealProductSwitchData] pd
		JOIN  #ProductSwitchType  pt ON pd.ProductSwitchTypeId=pt.ProductSwitchTypeId
		WHERE pd.DealId=@dealId AND CorrelatedDate=@pAsAtDate
		GROUP BY ProductSwitchGroup

		UNION ALL

		SELECT @paymentHoliday AS [ProductSwitchGroup], count(PaymentOverride_Amount)  AS [MortgageLoans], sum(Outstandng_Capital_Balance_Amt) AS TotalOutstandingCapitalBalance
		, CASE WHEN sum(Outstandng_Capital_Balance_Amt) > 0 THEN Cast((sum(Outstandng_Capital_Balance_Amt) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
		FROM #VwMortgageSubAccount 
		WHERE PaymentOverride_StartDate <=  @pAsAtDate AND PaymentOverride_EndDate >= @pAsAtDate
		AND PaymentOverride_Amount IS NOT NULL


	
		SELECT @totalOutstandingCapitalBalance = IsNull(sum(Outstandng_Capital_Balance_Amt),0)
		FROM #VwMortgageSubAccountPrior   

	
	
		SELECT ProductSwitchGroup, SUM(QuarterlyLoanCount) AS [MortgageLoans] , SUM(QuarterlyCapitalBalanceValue) AS TotalOutstandingCapitalBalance
		, CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast((sum(QuarterlyCapitalBalanceValue) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
		INTO #PrevProduct
		FROM [cw].[DealProductSwitchData] pd
		JOIN  #ProductSwitchType  pt ON pd.ProductSwitchTypeId=pt.ProductSwitchTypeId
		WHERE pd.DealId=@dealId AND CorrelatedDate=@previous_AsAtdate
		GROUP BY ProductSwitchGroup
	
		UNION ALL

		SELECT @paymentHoliday AS [ProductSwitchGroup], count(PaymentOverride_Amount)  AS [MortgageLoans], sum(Outstandng_Capital_Balance_Amt) AS TotalOutstandingCapitalBalance
		, CASE WHEN sum(Outstandng_Capital_Balance_Amt) > 0 THEN Cast((sum(Outstandng_Capital_Balance_Amt) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
		FROM #VwMortgageSubAccountPrior 
		WHERE PaymentOverride_StartDate <=  @previous_AsAtdate AND PaymentOverride_EndDate >= @previous_AsAtdate
		AND PaymentOverride_Amount IS NOT NULL
	
	
		SELECT ISNULL(P.ProductSwitchGroup,'Total') AS '~HeaderText'
		,  ISNULL(CAST(SUM(CP.[MortgageLoans]) AS decimal(38,2)),0) AS 'Number of Mortgage Loans~CRNT',  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalBalance) AS decimal(38,2)),0) AS 'Amount (EUR)~CRNT',  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalPercent) AS decimal(38,8)),0) AS '% of Total Amount~CRNT'
		,  ISNULL(CAST(SUM(PP.[MortgageLoans]) AS decimal(38,2)),0)  AS 'Number of Mortgage Loans~PREV',  ISNULL(CAST(SUM(PP.TotalOutstandingCapitalBalance) AS decimal(38,2)),0) AS 'Amount (EUR)~PREV',  ISNULL(CAST(SUM(PP.TotalOutstandingCapitalPercent) AS decimal(38,8)),0) AS '% of Total Amount~PREV'
		 FROM #ProductSwitchGroup P
		 LEFT JOIN #CrntProduct CP ON CP.ProductSwitchGroup = P.ProductSwitchGroup
		 LEFT JOIN #PrevProduct PP ON PP.ProductSwitchGroup  = P.ProductSwitchGroup 
		 GROUP BY P.ProductSwitchGroup WITH rollup   
		ORDER BY SUM(P.SortOrder) 
  

	END TRY
	BEGIN CATCH
		DECLARE 
					@errorMessage     NVARCHAR(MAX),
					@errorSeverity    INT,
					@errorNumber      INT,
					@errorLine        INT,
					@errorState       INT;

		SELECT 
					@errorMessage = ERROR_MESSAGE()
					,@errorSeverity = ERROR_SEVERITY()
					,@errorNumber = ERROR_NUMBER()
					,@errorLine = ERROR_LINE()
					,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetProductSwitchReport', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
		RAISERROR (@errorMessage,
					@errorSeverity,
					@errorState )
	END CATCH			
END
			   
GO

