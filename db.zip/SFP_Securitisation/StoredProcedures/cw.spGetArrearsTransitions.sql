USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetArrearsTransitions') IS NOT NULL
DROP PROC CW.spGetArrearsTransitions
GO
/*
 * Author: Arun
 * Date:    20.05.2020
 * Description:  This will return MonthInArrear for Investor report.
 * Usage : CW.spGetArrearsTransitions @pAsAtDate  ='31-JUL-2019'
 * 		,@pDealName  = 'ARDMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/


CREATE PROC cw.spGetArrearsTransitions @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY 
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN

BEGIN TRY

	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	 , @partitionID_AsAtDate_Prior DATE  = DATEADD(DAY, 0, EOMONTH(@pAsAtDate, - 3)) 
	 , @partitionID_AsAtWorkingDate_Prior INT 
	 , @totalNumberofSubAccounts float
	 , @totalOutstandingCapitalBalance float
	 , @totalTrueBalance float

	 -- Temp Tables dropped if exist
	 IF OBJECT_ID('tempdb..#VwMortgageSubAccount')		 IS NOT NULL DROP TABLE #VwMortgageSubAccount
	 IF OBJECT_ID('tempdb..#VwMortgageSubAccountPrior')	 IS NOT NULL DROP TABLE #VwMortgageSubAccountPrior
	 IF OBJECT_ID('tempdb..#VwMortgageSubAccount')		 IS NOT NULL DROP TABLE #VwMortgageSubAccount
	 IF OBJECT_ID('tempdb..#ArrearsTransitions_current') IS NOT NULL DROP TABLE #ArrearsTransitions_current
	 IF OBJECT_ID('tempdb..#VwMortgageSubAccountPrior')	 IS NOT NULL DROP TABLE #VwMortgageSubAccountPrior
	 IF OBJECT_ID('tempdb..#ArrearsTransitions_Prior')	 IS NOT NULL DROP TABLE #ArrearsTransitions_Prior
	 IF OBJECT_ID('tempdb..#ArrearsTransitions')		 IS NOT NULL DROP TABLE #ArrearsTransitions
	 IF OBJECT_ID('tempdb..#TBL')						 IS NOT NULL DROP TABLE #TBL
	 IF OBJECT_ID('tempdb..#ArrearTransition')			 IS NOT NULL DROP TABLE #ArrearTransition

	

	SELECT @partitionID_AsAtDate_Prior=LastIPDEndBusinessDate, @partitionID_AsAtWorkingDate_Prior = CONVERT(INT, CONVERT(VARCHAR(8), ( LastIPDEndBusinessDate), 112))   
     FROM sfp.syn_SfpModel_FnGetDealsIPDDetails(@pAsAtDate) WHERE DealName=@pDealName  
     
 
      
	DECLARE @dealId int;
	SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
	SELECT * INTO #VwMortgageSubAccountPrior  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1 
	
	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId
    
	SELECT d.DealName, MortgageSubAccountKey,  loan_identifier AS LoanID,  Outstandng_Capital_Balance_Amt AS TotalOutstandingCapitalBalance, True_Balance_Amt AS TrueBalance, MONTHS_IN_ARREARS AS NumberOfMonthsInArrears 
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MONTHS_IN_ARREARS) AS DisplayCurrentmonthinArrear  
	INTO #ArrearsTransitions_current
	FROM #VwMortgageSubAccount v
	INNER JOIN cw.[vw_ActiveDeal] d ON d.MortgageDealId=v.MortgageDealKey
	WHERE d.DealName=@pDealName
		AND PartitionID = (@partitionID_AsAtDate)


	EXEC [CW].[spCheckAndLoadMortgageFieldData] @partitionID_AsAtDate_Prior, @dealId
	INSERT INTO #VwMortgageSubAccountPrior   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtWorkingDate_Prior AND MortgageDealKey = @dealId
    			
	SELECT d.DealName, MortgageSubAccountKey,  loan_identifier AS LoanID,  Outstandng_Capital_Balance_Amt AS TotalOutstandingCapitalBalance, True_Balance_Amt AS TrueBalance, MONTHS_IN_ARREARS AS NumberOfMonthsInArrears 
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MONTHS_IN_ARREARS) AS DisplayPriormonthinArrear
	INTO #ArrearsTransitions_Prior
	FROM #VwMortgageSubAccountPrior v
	INNER JOIN cw.[vw_ActiveDeal] d ON d.MortgageDealId=v.MortgageDealKey
	WHERE d.DealName=@pDealName
		AND PartitionID = (@partitionID_AsAtWorkingDate_Prior)		  


	SELECT A.DealName, A.LoanID, A.MortgageSubAccountKey, A.TotalOutstandingCapitalBalance, A.TrueBalance
	   ,A.NumberOfMonthsInArrears AS CurrentmonthinArrear,  DisplayCurrentmonthinArrear 
	   ,COALESCE(b.NumberOfMonthsInArrears, 0) AS PriormonthinArrear , DisplayPriormonthinArrear  
	  INTO #ArrearsTransitions  
	  FROM #ArrearsTransitions_current a  
	  LEFT OUTER JOIN #ArrearsTransitions_prior b ON a.LoanID = b.LoanID  
	 
	SELECT @totalNumberofSubAccounts = ISNULL(COUNT(DISTINCT VMS.MortgageSubAccountKey), 0)
		, @totalOutstandingCapitalBalance = ISNULL(SUM(VMS.TotalOutstandingCapitalBalance), 0)
		, @totalTrueBalance  = ISNULL(SUM(VMS.TrueBalance), 0)
		FROM #ArrearsTransitions VMS

	SELECT  isNull(T.DisplayCurrentmonthinArrear,'')  'HeaderText', isNull(T.DisplayPriormonthinArrear,'') AS 'SubHeaderText'
	, count(DISTINCT T.MortgageSubAccountKey) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT( DISTINCT T.MortgageSubAccountKey) / @totalNumberofSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Float) , 0) 'TotalOutCapitalBalance' 
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent  
	, ISNULL(CAST(sum(TrueBalance) AS Float) , 0)  TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) * 100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TrueBalancePercent  
	INTO #TBL
	FROM #ArrearsTransitions T 
	WHERE T.DisplayCurrentmonthinArrear IS NOT NULL
	GROUP BY T.DisplayCurrentmonthinArrear , T.DisplayPriormonthinArrear
	
	
	SELECT HeaderText, [<=0], [>0-<1], [>=1-<2], [>=2-<3], [>=3-<6], [>=6-<9], [>=9-<12], [>=12]
	INTO #ArrearTransition
	FROM ( SELECT HeaderText, SubHeaderText, [MortgageLoans]
			FROM 	#TBL ) AS t
	PIVOT(
			Avg([MortgageLoans])
			FOR SubHeaderText IN ( [<=0], [>0-<1], [>=1-<2], [>=2-<3], [>=3-<6], [>=6-<9], [>=9-<12], [>=12] )
		  ) AS PivotTable



	
	SELECT ISNULL(Replace(dans.DisplayName,'<=0','Current'), 'Total') AS 'Current Period', 
		  SUM(ISNULL([<=0],0)) AS 'Current' , 
		  SUM(ISNULL([>0-<1],0)) AS '>0 - <1 Months In Arrears', 
		  SUM(ISNULL([>=1-<2],0)) AS '>=1 - <2 Months In Arrears',
		  SUM(ISNULL([>=2-<3],0)) AS '>=2 - <3 Months In Arrears', 
		  SUM(ISNULL([>=3-<6],0)) AS '>=3 - <6 Months In Arrears', 
		  SUM(ISNULL([>=6-<9],0)) AS  '>=6 - <9 Months In Arrears',
	      SUM(ISNULL([>=9-<12],0)) AS '>=9 - <12 Months In Arrears', 	 
	      SUM(ISNULL([>=12],0)) AS '>=12 Months in Arrears',
	      SUM(ISNULL([<=0],0)) + SUM(ISNULL([>0-<1],0)) + SUM(ISNULL([>=1-<2],0)) + SUM(ISNULL([>=2-<3],0)) + SUM(ISNULL([>=3-<6],0)) + SUM(ISNULL([>=6-<9],0)) + SUM(ISNULL([>=9-<12],0)) + SUM(ISNULL([>=12],0)) AS [Total]
	FROM @pStratRangeData dans 
		LEFT JOIN #ArrearTransition A 
			ON dans.DisplayName=A.HeaderTExt
	GROUP BY dans.DisplayName WITH rollup
	ORDER BY sum(dans.SortOrder)

END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

	SELECT @errorMessage
	
    EXEC app.SaveErrorLog 1, 1, 'spGetArrearsTransitions', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			

END

GO
