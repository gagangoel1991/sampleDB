
USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spValidateSubmittedFacilities]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spValidateSubmittedFacilities]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[spValidateSubmittedFacilities]  
 @pPoolId INT,  
 @pUserName VARCHAR(50)  
AS  
 BEGIN  
  
  DECLARE @PoolId INT   
  SET @PoolId = @pPoolId  
  
  DECLARE @UserName VARCHAR(50)   
  SET @UserName = @pUserName  
  
  DECLARE @PoolStatusSubmitted VARCHAR(20) = 'Submitted'  
  DECLARE @PoolStatusAuthorised VARCHAR(20) = 'Authorised'  
  DECLARE @PoolStatusLock VARCHAR(20) = 'Lock'  
  DECLARE @PoolStatusDraft VARCHAR(20) = 'Draft'  
  DECLARE @Active BIT = 1  
  DECLARE @InActive BIT = 0  
  DECLARE @LoanIdNotAvailableCode INT = -4  
  DECLARE @LoanInvalidReturnCode INT = -2  
  DECLARE @LoanMovedReturnCode INT = -3  
  DECLARE @ValidReason VARCHAR(25) = 'VALID'  
  DECLARE @InValidReason VARCHAR(25) = 'INVALID'  
  DECLARE @MovedReason VARCHAR(25) = 'MOVED'  
  DECLARE @ClosedReason VARCHAR(25) = 'CLOSED'  
  DECLARE @ReasonAlreadyInTarget VARCHAR(25) = 'Already In Target Deal'  
  DECLARE @InvalidInceptionDate DATE = '0001-01-01'  
  DECLARE @DeflagPurposeCode VARCHAR(10) = 'DF'  
  DECLARE @AnalysisPoolPurposeCode VARCHAR(10) = 'NP'  
  DECLARE @TargetDealKey INT  
  DECLARE @NormalProcessStatusCode VARCHAR(3) = '2'  
  DECLARE @RedeemedProcessStatusCode VARCHAR(3) = '3'  
  DECLARE @ClosedLoanStatus VARCHAR(10) = 'Y'  
  DECLARE @NotClosedStatus VARCHAR(10) = 'N'  
    
  DECLARE @HypoPoolPartitionId INT  
  
  DECLARE @LatestPartitionId INT = (SELECT TOP 1 PartitionId  
   FROM [corp].[syn_SfpModelCorporate_vw_FactFacility]  
   ORDER BY PartitionId DESC)  
  
  DECLARE @PoolPurposeCode VARCHAR(10)  
  SELECT @PoolPurposeCode = Purpose.Code  
   , @HypoPoolPartitionId = CONVERT(VARCHAR, psPool.VintageDate, 112)  
   , @TargetDealKey = psPool.TargetPoolId  
  FROM ps.[pool] psPool  
  INNER JOIN ps.PoolPurpose Purpose   
   ON Purpose.PoolPurposeId = psPool.PoolPurposeId  
  WHERE psPool.PoolId = @PoolId  
   AND psPool.IsActive = @Active  
   AND Purpose.IsActive = @Active  
  
  BEGIN TRY  

   -- Disabled the below validation logic as per comment in SFPT-14092
   -- Have added dummy logic below that will not return any failed loans
   
   SELECT [Name], [Status], [MatchedLoanId]
   FROM (VALUES ('DUMMY', 0, 100)) T([Name], [Status], [MatchedLoanId])
   WHERE 1 = 0 

   SELECT LoanId, Reason
   FROM (VALUES (100, 'DUMMY')) T(LoanId, Reason)
   WHERE 1 = 0
 
 /*
   SELECT PoolDetails.[Name], PoolStatus.[Status], Booked.LoanId AS MatchedLoanId FROM   
   (  
    SELECT DISTINCT LoanId   
    FROM [ps].[PoolBuildDetail] Proposed   
    WHERE Proposed.PoolId = @PoolId  
	 AND Proposed.IsActive = 1
   ) Proposed  
   INNER JOIN  
   (  
    SELECT DISTINCT Booked.LoanId, Booked.PoolId  
    FROM ps.PoolBuildDetail Booked  
    INNER JOIN [ps].[Pool] [Pool]   
     ON [Pool].PoolId = Booked.PoolId  
    INNER JOIN ps.PoolStatus PoolStatus   
     ON [Pool].PoolStatusId = PoolStatus.PoolStatusId  
    WHERE [Pool].IsActive = @Active   
     AND [PoolStatus].IsActive = @Active   
     AND [Pool].PoolId != @PoolId  
     AND [PoolStatus].[Status] IN (@PoolStatusSubmitted, @PoolStatusAuthorised, @PoolStatusLock)  
	 AND Booked.IsActive = 1
   ) Booked   
   ON Proposed.LoanId = Booked.LoanId  
   INNER JOIN ps.[Pool] PoolDetails   
    ON PoolDetails.PoolId = Booked.PoolId  
   INNER JOIN ps.[PoolStatus] PoolStatus  
    ON PoolStatus.PoolStatusId = PoolDetails.PoolStatusId  
   ORDER BY PoolDetails.[Name], PoolStatus.[Status]  
  
   ------------------------------------------------ VALIDATE WITH SFP  | START  
   -- Get Deal Key | For Vintage Date  
    SELECT DISTINCT PoolBuild.LoanId  
    , PoolBuild.MortgageAccountKey  
    , PoolBuild.MortgageSubAccountKey  
    , 0 AS SubAccountId  
    , bfd.DealKey AS MortgageDealKey 
    , @NotClosedStatus AS AccountClosed  
    , @ValidReason AS Reason  
   INTO #ProposedPoolAssetDetails  
   FROM [ps].[PoolBuildDetail] PoolBuild   
   INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] ff  
	--ON CASE WHEN ff.SourceId = 2 THEN CONVERT(VARCHAR(10),PoolBuild.LoanId) + '\P' ELSE CONVERT(VARCHAR(10),PoolBuild.LoanId) END  = ff.FacilityId 
	ON PoolBuild.LoanId  = REPLACE(ff.FacilityId , '\P', '')
   INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd 
	ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey 
   WHERE ff.PartitionId = @HypoPoolPartitionId  
    AND PoolBuild.PoolId = @PoolId  
	AND PoolBuild.IsActive = 1
 
  
   -- Get Facility keys | For latest Partition Id  
    SELECT DISTINCT Proposed.LoanId  
    , Proposed.SubAccountId  
    , FF.FacilityKey AS MortgageAccountKey  
    , 0 AS MortgageSubAccountKey  
    , CASE WHEN ExpiryDate < GETDATE() THEN 'Y' ELSE 'N' END AS AccountClosed   
    , bfd.DealKey AS MortgageDealKey
   INTO #LatestPoolAssetDetails  
   FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] FF  
    INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd 
		ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey 
    INNER JOIN #ProposedPoolAssetDetails Proposed  
		--ON CASE WHEN FF.SourceId = 2 THEN CONVERT(VARCHAR(10),Proposed.LoanId) + '\P'  ELSE CONVERT(VARCHAR(10),Proposed.LoanId) END  = ff.FacilityId 
		ON Proposed.LoanId  = REPLACE(ff.FacilityId , '\P', '')
	AND Proposed.MortgageAccountKey = FF.FacilityKey 
   WHERE ff.PartitionId = @LatestPartitionId 

  
   -- MOVED inbetween | check for loan/sub-account ID  
   -- if facility has moved to different deal by now - done  
   UPDATE #ProposedPoolAssetDetails  
   SET Reason = @MovedReason  
   FROM #ProposedPoolAssetDetails Proposed  
   INNER JOIN #LatestPoolAssetDetails Latest  
      ON Proposed.LoanId = Latest.LoanId AND Proposed.SubAccountId = Latest.SubAccountId  
   WHERE Proposed.MortgageDealKey <> Latest.MortgageDealKey  
  

   -- BELOW 2 SECTIONS WILL BE ENABLED ONCE RISHAB CONFIRM THE AccountClosed logic for CB.
   -- Ignore closed for deflag | Otherwise identify closed loans  
 --  IF (@PoolPurposeCode != @DeflagPurposeCode)   
 --  BEGIN  
 --   -- SET Closed facility Status | For Vintage Date, if any  
 --   UPDATE #ProposedPoolAssetDetails  
 --    SET AccountClosed = CASE WHEN ExpiryDate < GETDATE() THEN 'Y' ELSE 'N' END   
 --   FROM #ProposedPoolAssetDetails Proposed   
	--INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] FF
	--	  ON Proposed.MortgageAccountKey = FF.FacilityKey 
 --   WHERE FF.PartitionId = @HypoPoolPartitionId
 --  END  

 --  IF (@PoolPurposeCode != @DeflagPurposeCode)   
 --  BEGIN  
 --   -- SET Closed Loan Status | For Vintage Date, if any  
 --   UPDATE #ProposedPoolAssetDetails  
 --    SET AccountClosed = CASE WHEN ExpiryDate < GETDATE() THEN 'Y' ELSE 'N' END  
 --   FROM #ProposedPoolAssetDetails Proposed  
 --   INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] FF  
 --     ON FF.FacilityKey = Proposed.MortgageAccountKey  
 --   WHERE FF.PartitionId = @HypoPoolPartitionId
 --  END
  
   IF (@PoolPurposeCode != @AnalysisPoolPurposeCode)  
   BEGIN  
    -- Loans already in Target Deal  
    UPDATE #ProposedPoolAssetDetails  
     SET Reason = @ReasonAlreadyInTarget  
    WHERE Reason = @ValidReason  
     AND MortgageDealKey = @TargetDealKey  
   END  
  
   SELECT DISTINCT LoanId, Reason  
   FROM #ProposedPoolAssetDetails  
   WHERE Reason != @ValidReason 

*/ 
  
   ------------------------------------------------ VALIDATE WITH SFP  | END  
  
  END TRY  
  BEGIN CATCH  
   DECLARE   
    @errorMessage     NVARCHAR(MAX),  
    @errorSeverity    INT,  
    @errorNumber      INT,  
    @errorLine        INT,  
    @errorState       INT;  
   SELECT   
    @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),  
    @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
   EXEC app.SaveErrorLog 2, 1, 'spValidateSubmittedFacilities',  
    @errorNumber, @errorSeverity, @errorLine, @errorMessage, @UserName  
      
   RAISERROR (@errorMessage,  
     @errorSeverity,  
     @errorState )  
  END CATCH  
  
 END

 GO
 --EXEC [corp].[spValidateSubmittedFacilities] 533, 'SAK'