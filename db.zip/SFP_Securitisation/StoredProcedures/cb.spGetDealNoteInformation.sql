USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetDealNoteInformation]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetDealNoteInformation] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 07-07-2022 
--Description: GET DealNote Data 
--[cb].[spGetDealNoteInformation] 6,''
--==================================   
CREATE PROCEDURE [cb].[spGetDealNoteInformation] 
   @pDealId   INT,
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   
   --  DECLARE @pDealId   INT=14,@pIPDRunId INT=4

   DECLARE	@IpdDate		DATE,
			@NewRedemptionDateNextIpd DATE

		SELECT @IpdDate=IpdDate
		 FROM cw.vwDealIpdRun WHERE DealId=@pDealId;

		 
		select @NewRedemptionDateNextIpd = cw.fnGetBusinessDate(datefromparts(year(DATEADD(month, 1, @IpdDate)), 
		month(DATEADD(month, 1, @IpdDate)),1),'UK',0,0) 

	--	select @NewRedemptionDateNextIpd

	SELECT 
	        dn.DealNoteId,
			dn.DealId,
			dn.Name,
			dn.ISIN, 
		    dn.ValidFrom,
			dn.ValidTo ,
			dn.MaturityDate,
	       IIF(wp.NewRedemptionDate IS NOT NULL,wp.NewRedemptionDate,dn.NewRedemptionDate) AS EarlyRedemptionDate,
		   IIF(wp.DealStatusId IS NOT NULL,wp.DealStatusId,0) AS DealStatusId,
		   IIF(wp.ModifiedBy IS NOT NULL AND wp.IsActive=1,wp.ModifiedBy,dn.ModifiedBy) AS ModifiedBy,
           IIF(wp.ModifiedDate IS NOT NULL AND wp.IsActive=1,wp.ModifiedDate,dn.ModifiedDate) AS ModifiedDate,
		   CAST(CASE
              WHEN wp.IsActive=1 THEN 1
              ELSE 0
            END AS BIT) AS isActive,
			@NewRedemptionDateNextIpd as EarlyRedemptionDateNextIpd,			
			IIF(DATENAME(dw, DATEADD(year,1,dn.MaturityDate)) = 'Saturday', DATEADD(day,2,DATEADD(year,1,dn.MaturityDate)),
			IIF(DATENAME(dw, DATEADD(year,1,dn.MaturityDate)) = 'Sunday', DATEADD(day,1,DATEADD(year,1,dn.MaturityDate)),
			DATEADD(year,1,dn.MaturityDate))) AS FinalMaturityDate
		   
		FROM cfgcb.DealNote	dn	
			LEFT JOIN cfgcb.DealNote_WIP wp ON wp.DealNoteId=dn.DealNoteId	--AND wp.IsActive=1
	WHERE dn.DealId = @pDealId 
	AND dn.ValidTo > Getdate()
	
	
  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetNonRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO
