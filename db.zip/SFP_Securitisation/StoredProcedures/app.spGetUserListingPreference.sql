USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[app].[spGetUserListingPreference]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [app].[spGetUserListingPreference]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spGetUserListingPreference]                            
	@pListingPageName VARCHAR(50),            
	@pUserName VARCHAR(20),
	@pReturnValue INT = -1 OUTPUT
AS             
BEGIN             
	BEGIN TRY
		DECLARE @UserListingMapId INT = -1
		DECLARE @Active BIT = 1

		SELECT @UserListingMapId = ulm.UserListingMapId FROM [app].[UserListingMap] ulm
			INNER JOIN [app].[ListingPage] lp ON lp.ListingPageId = ulm.ListingPageId
		WHERE lp.ListingPageName = @pListingPageName AND ulm.UserName = @pUserName
			AND lp.IsActive = @Active AND ulm.IsActive = @Active

		SELECT ColumnName FROM [app].[ListingHiddenColumnMap]
		WHERE UserListingMapId = @UserListingMapId AND IsActive = @Active

		SET @pReturnValue = @UserListingMapId
		            
	END TRY              
	BEGIN CATCH              
		DECLARE               
		@errorMessage     NVARCHAR(MAX),              
		@errorSeverity    INT,              
		@errorNumber      INT,              
		@errorLine        INT,              
		@errorState       INT;              
		SELECT               
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()              
              
		EXEC app.SaveErrorLog 2, 1, 'spGetUserListingPreference', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName            
                
		RAISERROR (@errorMessage,              
		@errorSeverity,              
		@errorState)      
	END CATCH              
END
GO
