USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spLoadCollectionLedgerData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadCollectionLedgerData]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spLoadCollectionLedgerData]
/*-------------------------------------------------------
 * Author: Kapil Sharma
 * Date:	12.09.2020
 * Description:  This will TRANSNFORM & LOAD data from staging into CW table for Collection Ledger
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
(
	@pFeedRunLogId			INT,
	@pAsAtDate				DATETIME
)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY

		BEGIN TRANSACTION

		IF @pFeedRunLogId IS NOT NULL
		BEGIN

			DECLARE 
				@dealId					SMALLINT,
				@dealName				VARCHAR(100), 
				@brand					VARCHAR(20),
				@dealBrandMapId			TINYINT,
				@adviceDate				VARCHAR(20),
				@collectionDate			VARCHAR(20),
				@netPrincipalCollections [decimal](38, 16),
				@financeCollections		[decimal](38, 16),
				@otherCollections		[decimal](38, 16),
				@totalDailyCashAmount	[decimal](38, 16),
				@versionId				SMALLINT,
				@fileName				VARCHAR(500),
				@relatedToDate			INT,
				@createdDate			DATETIME,
				@createdBy				VARCHAR(40);

			--Set parameters
			SET @createdDate = GETDATE();
			SET @createdBy = 'System';

			DECLARE cursorCollectionLedgerStg CURSOR
			FOR SELECT 
					deal.DealId,
					stg.[Deal],
					stg.[Brand],
					sbm.StormBrandMapId,
					stg.[AdviceDate],
					stg.[CollectionDate],
					stg.[NetPrincipalCollections],
					stg.[FinanceCollections],
					stg.[OtherCollections],
					stg.[TotalDailyCashAmount],
					stg.[FileName],
					stg.[RelatesToDate]
				FROM 
					[cw].[Syn_SfpStaging_tbl_CollectionLedger] stg
				JOIN
					[cw].[vw_ActiveDeal] deal ON deal.DealName = stg.Deal
				JOIN
					[cfgCw].[StormBrandMap] sbm ON stg.Brand = sbm.StormBrand

			OPEN cursorCollectionLedgerStg;
			FETCH NEXT FROM cursorCollectionLedgerStg INTO 
				@dealId, @dealName, @brand, @dealBrandMapId, @adviceDate, @collectionDate, @netPrincipalCollections, @financeCollections, 
				@otherCollections, @totalDailyCashAmount, @fileName, @relatedToDate

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @versionId = 1;

				IF EXISTS(SELECT TOP 1* FROM [cw].[CollectionLedger] WHERE DealId = @dealId AND CollectionDate = @collectionDate AND BrandMapId = @dealBrandMapId)
				BEGIN
					SELECT @versionId = MAX(Version) FROM [cw].[CollectionLedger] 
					WHERE DealId = @dealId AND CollectionDate = @collectionDate AND BrandMapId = @dealBrandMapId

					DELETE FROM [cw].[CollectionLedger]
					WHERE DealId = @dealId AND CollectionDate = @collectionDate AND BrandMapId = @dealBrandMapId

					SET @versionId = ISNULL(@versionId, 0) + 1
				END

				--Inserting data into [cw].[CollectionLedger] Table
				INSERT INTO [cw].[CollectionLedger] (FeedRunLogId, DealId, BrandMapId, AdviceDate, CollectionDate, NetPrincipalCollections, FinanceCollections, 
				OtherCollections, TotalDailyCashAmount, Version, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES(@pFeedRunLogId, @dealId, @dealBrandMapId, @adviceDate, @collectionDate, @netPrincipalCollections, @financeCollections,
				@otherCollections, @totalDailyCashAmount, @versionId, @createdBy, @createdDate, @createdBy, @createdDate);

				--Fetch record again from cursor
				FETCH NEXT FROM cursorCollectionLedgerStg INTO 
					@dealId, @dealName, @brand, @dealBrandMapId, @adviceDate, @collectionDate, @netPrincipalCollections, @financeCollections, 
					@otherCollections, @totalDailyCashAmount, @fileName, @relatedToDate
			END;
		END	
		CLOSE cursorCollectionLedgerStg;
		DEALLOCATE cursorCollectionLedgerStg;

		--Deleting the extra rows for the same date
		DELETE 
			cl
		FROM 
			[CW].[CollectionLedger] cl
		JOIN 
			[cw].[vw_ActiveDeal] deal ON deal.DealId = cl.DealId 
		JOIN
			[cfgCw].[StormBrandMap] sbm ON cl.BrandMapId = sbm.StormBrandMapId
		LEFT JOIN 
			[cw].[Syn_SfpStaging_tbl_CollectionLedger] stg ON stg.Deal = deal.DealName
			AND stg.Brand = sbm.StormBrand
			AND CAST(stg.AdviceDate AS DATE) = CAST(cl.AdviceDate AS DATE)
			AND CAST(stg.CollectionDate AS DATE) = CAST(cl.CollectionDate AS DATE)
			AND stg.NetPrincipalCollections = cl.NetPrincipalCollections
			AND stg.FinanceCollections = cl.FinanceCollections
			AND stg.OtherCollections = cl.OtherCollections
			AND stg.TotalDailyCashAmount = cl.TotalDailyCashAmount
		WHERE 
			cl.AdviceDate = @adviceDate
			AND cl.CollectionDate = @collectionDate
			AND stg.deal IS NULL

		UPDATE [CW].[FeedRunLog] SET FileName = @fileName WHERE FeedRunLogId = @pFeedRunLogId;

		COMMIT TRANSACTION;  
			
	END TRY
	BEGIN CATCH

		IF @@trancount > 0 ROLLBACK TRANSACTION;

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC [CW].[spUpdateFeedRunLog]	@pFeedRunLogId, '', 'Failed', 0

		EXEC app.SaveErrorLog 1, 1, 'cw.spLoadCollectionLedgerData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO