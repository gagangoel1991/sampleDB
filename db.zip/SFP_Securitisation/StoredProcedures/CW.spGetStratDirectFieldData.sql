USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetStratDirectFieldData') IS NOT NULL
	DROP PROC CW.spGetStratDirectFieldData;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:    20.05.2020
 * Description:  This will return direct field strat data for Investor report.
 * Usage : CW.spGetStratProcessedData @pAsAtDate  ='30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pFieldId =117 --132 --177
 * 		,@pStratName ='MIA_Ardmore'
 * 		,@pUserName = NULL       
 * 		
 * 	Declare @pStratRangeData1 as [cw].[udtStratRangeConfig]
 * 	Insert @pStratRangeData1
 * 	Select 1, '<=0', Null, 1, Null, Null, Null, 2
 * 	union all
 * 	Select 2, Null, 10, 20, Null, Null, 3, 2
 * 		                                   
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetStratDirectFieldData @pAsAtDate DATE
		,@pDealName VARCHAR(255) = NULL
		,@pFieldName varchar(255) = NULL
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY  
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN			
BEGIN TRY

	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	 , @dealId int
	 , @totalNumberofSubAccounts float
	 , @totalOutstandingCapitalBalance float
	 , @totalTrueBalance float
	 , @fieldDataType varchar(12) ='Text'
	 , @stratRangeData [cw].[udtStratRangeConfig]  
	 , @dealType varchar(50)
	
	DECLARE @parameteres nvarchar(max)
	DECLARE @sqlQuery nvarchar(max)


	SELECT @dealType = dl.Value, @dealId = MortgageDealId  
	FROM [CW].[vw_DealLookup] dl 
	INNER JOIN [cw].[vw_ActiveDeal] d ON d.DealTypeId=dl.LookupValueId
	WHERE TypeCode = 'DealType' 
	AND  d.DealName=@pDealName

		
	SELECT * INTO #VwMortgageSubAccount FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
	
    
	SELECT @fieldDataType= CASE WHEN dt.Name ='Reference' THEN 'TEXT' ELSE  dt.Name END 
	FROM  cfgCW.IR_AssetField  p
	 INNER JOIN cw.vw_DealLookup dt ON dt.lookupValueId = p.FieldDataType AND TypeCode='FieldDataType'
	 WHERE P.FieldName=@pFieldName
	 
	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId, @pUserName
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId
	

	IF @dealType='Covered Bond' AND @pFieldName='REMAINING_TERM'
	BEGIN
		UPDATE 	#VwMortgageSubAccount SET REMAINING_TERM= ROUND(CAST(DATEDIFF(day, @pAsAtDate, MATURITY_DATE) / 365.0  * 12.0  AS [decimal](7, 2)), 2) 
	END
	ELSE IF @dealType='Covered Bond' AND @pFieldName='INCOME_VERIF_FOR_PRIME_INCOME'
	BEGIN
		UPDATE 	#VwMortgageSubAccount SET INCOME_VERIF_FOR_PRIME_INCOME= 'Verified' WHERE INCOME_VERIF_FOR_PRIME_INCOME='N/A'
	END

	
	SET @parameteres= N'@partitionID_AsAtDate INT, @pDealName varchar(100),  @pStratRangeData [cw].[udtStratRangeConfig] ReadOnly' 

	CREATE TABLE #temp (DealName varchar(100), MortgageSubAccountKey varchar(100), TotalOutstandingCapitalBalance float, TrueBalance float, BandRange nvarchar(1000))
	
	CREATE INDEX INDX_BandRange ON #temp(BandRange)
	

	IF @fieldDataType='Text'
	BEGIN
	
		SET @sqlQuery = ' Insert Into #temp 
		Select DealName, MortgageSubAccountKey, Outstandng_Capital_Balance_Amt as TotalOutstandingCapitalBalance , True_Balance_Amt
		, ' + @pFieldName  + ' as BandRange
		From #VwMortgageSubAccount v
		INNER JOIN cw.[vw_ActiveDeal] d ON d.MortgageDealId=v.MortgageDealKey
		where d.DealName=@pDealName
		and v.PartitionID = @partitionID_AsAtDate '
		
		
		
		EXEC sp_executesql @sqlQuery, @parameteres,  @partitionID_AsAtDate = @partitionID_AsAtDate , @pDealName = @pDealName	
	END
	ELSE
	BEGIN
		SET @sqlQuery = ' Insert Into #temp 
		Select DealName, MortgageSubAccountKey, Outstandng_Capital_Balance_Amt as TotalOutstandingCapitalBalance , True_Balance_Amt
		, CW.fnGetStratConfigGroupName(@pStratRangeData, ' + @pFieldName  + ') as BandRange
		From #VwMortgageSubAccount v
		INNER JOIN cw.[vw_ActiveDeal] d ON d.MortgageDealId=v.MortgageDealKey
		where d.DealName=@pDealName
		and v.PartitionID = @partitionID_AsAtDate '
		EXEC sp_executesql @sqlQuery, @parameteres,  @partitionID_AsAtDate = @partitionID_AsAtDate , @pDealName = @pDealName, @pStratRangeData = @pStratRangeData
	END
	
	SELECT @totalNumberofSubAccounts = COUNT(ISNULL(VMS.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(VMS.TotalOutstandingCapitalBalance, 0)) 
		, @totalTrueBalance  = SUM(ISNULL(VMS.TrueBalance, 0)) 
	FROM #temp VMS


	CREATE TABLE #FinalData (HeaderText varchar(255), MortgageLoans int, MortgageLoansPercent float, TotalOutCapitalBalance float, TotalOutCapitalBalancePercent float)


	IF @fieldDataType='Text'
	BEGIN
	
		SELECT AssetStratFieldId, IsExcludedfromIR, ReportLookupName 
		, CASE WHEN @dealType='Covered Bond' AND @pFieldName='CUSTOMER_EMPLOYMENT_TYPE' AND ReportLookupName='Unemployed' AND ReportLookupValue='Other' THEN 'Unemployed' ELSE ReportLookupValue END AS ReportLookupValue
		INTO #IR_AssetStratGroupingLookupData 
		FROM cfgcw.IR_AssetStratGroupingLookupData

		INSERT INTO @stratRangeData (SortOrder, DisplayName)
		SELECT Row_Number() OVER(ORDER BY ReportLookupValue ASC), ReportLookupValue 
		FROM  #IR_AssetStratGroupingLookupData T
		INNER JOIN  cfgCW.IR_AssetField M ON M.AssetFieldId=T.AssetStratFieldId
		WHERE M.FieldName=@pFieldName AND isNull(IsExcludedfromIR,0)=CASE WHEN @dealType='Covered Bond' AND @pFieldName='NUTS_REGION_DESCRIPTION' THEN 1 ELSE 0 END
		GROUP BY ReportLookupValue
		
		
		INSERT INTO #FinalData	
		SELECT AL.ReportLookupValue, count(MortgageSubAccountKey) [MortgageLoans]
		, ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalNumberofSubAccounts  ) AS Decimal(38,18)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
		, ISNULL(CAST( sum(Cast(TotalOutstandingCapitalBalance AS decimal(38,18))) AS Float) , 0) 'TotalOutCapitalBalance' 
		, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance )  AS Decimal(38,18)) ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent  
		FROM #IR_AssetStratGroupingLookupData  AL 
		INNER JOIN  cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
		INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 L ON L.ReportTemplateName='SFP+' AND L.LookupValueDescription=AL.ReportLookupName AND L.LookupName =M.FieldName 
		INNER JOIN #temp  V ON V.BandRange  = ISNull(L.LookupValue, V.BandRange )
		WHERE M.FieldName=@pFieldName
		GROUP BY AL.ReportLookupValue
		

	END
	ELSE
	BEGIN
	
		INSERT INTO @stratRangeData
		SELECT * FROM @pStratRangeData
		
		INSERT INTO #FinalData
		SELECT dans.DisplayName  'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]
		, ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalNumberofSubAccounts  ) AS Decimal(38,18)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
		, ISNULL(CAST( sum(Cast(TotalOutstandingCapitalBalance AS decimal(38,2))) AS Float) , 0) 'TotalOutCapitalBalance' 
		, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance )  AS Decimal(38,18)) ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent  
		--, ISNULL(CAST( sum(Cast(TrueBalance as decimal(10,2))) as Float) , 0)  TrueBalance
		--, ISNULL(CAST( Case When @totalTrueBalance > 0 Then Cast( (sum(TrueBalance) / @totalTrueBalance)  as Decimal(10,2)) Else 0 End as Float) , 0) TrueBalancePercent  
		FROM @pStratRangeData dans 
		LEFT JOIN #temp T ON T.BandRange = dans.DisplayName 
		GROUP BY dans.DisplayName , dans.SortOrder	
		ORDER BY dans.SortOrder;
	
	END

	SELECT HeaderText, MortgageLoans, MortgageLoansPercent, TotalOutCapitalBalance, TotalOutCapitalBalancePercent
		FROM (
		SELECT DISTINCT 
			IsNull(dans.DisplayName,'Total') AS 'HeaderText',
			ISNULL(SUM(F.[MortgageLoans]),0) AS 'MortgageLoans', 
			ISNULL(CAST(CAST(SUM(F.MortgageLoansPercent)  AS decimal(38,12)) AS FLOAT),0) AS 'MortgageLoansPercent', 
			ISNULL(CAST(SUM(F.TotalOutCapitalBalance) AS FLOAT),0) AS 'TotalOutCapitalBalance', 
			ISNULL(CAST(CAST(SUM(F.TotalOutCapitalBalancePercent) AS decimal(38,12)) AS FLOAT),0) AS 'TotalOutCapitalBalancePercent' ,
			SUM(dans.SortOrder)  AS 'SortOrder'
		FROM @stratRangeData dans
		LEFT JOIN #FinalData F ON F.[HeaderText] = dans.DisplayName
		GROUP BY dans.DisplayName, dans.SortOrder WITH ROLLUP
		) AS Tbl 
		ORDER BY SortOrder
		
	
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetStratDirectFieldData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			

END

GO



