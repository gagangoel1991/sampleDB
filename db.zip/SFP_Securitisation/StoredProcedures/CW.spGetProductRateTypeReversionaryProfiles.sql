USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetProductRateTypeReversionaryProfiles') IS NOT NULL
	DROP PROC CW.spGetProductRateTypeReversionaryProfiles
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Product Type and Reesion Profiles for Investor report.
 * Usage : CW.spGetProductRateTypeReversionaryProfiles @pAsAtDate  = '30-NOV-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetProductRateTypeReversionaryProfiles @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN
BEGIN TRY
	DECLARE @previous_AsAtdate DATE = ( SELECT sfp.syn_SfpModel_FnPreviousReportDate(@pAsAtDate, 3)  )
	DECLARE @dealId int;
	SELECT @dealId = dealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	DECLARE @totalSubAccounts float, @totalOutstandingCapitalBalance float
	, @capitalBalanceAtFlagged float
	, @mortgagedealstart DATE 
	, @dealkey INT
	, @fieldName varchar(20)= 'PRODUCT'
	
	CREATE TABLE #ProductTypeGroup(SortOrder INT IDENTITY (1,1), ProductTypeGroup varchar(255))
	CREATE TABLE #ProductType(ProductTypeId INT, Name varchar(255), ProductTypeGroup varchar(255))
	
	INSERT INTO #ProductTypeGroup (ProductTypeGroup)
	SELECT DISTINCT ReportLookupValue AS LookupValueDescription  
	FROM cfgcw.IR_AssetStratGroupingLookupData AL 
	INNER JOIN cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
	WHERE M.FieldName=@fieldName
	
	INSERT INTO #ProductType
	SELECT pt.ProductTypeId, pt.Name, AL.ReportLookupValue AS LookupValueDescription 
	FROM cfgcw.IR_AssetStratGroupingLookupData AL 
	INNER JOIN cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
	INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 L ON L.ReportTemplateName='SFP+' 
		AND L.LookupValueDescription=AL.ReportLookupName AND L.LookupName =M.FieldName
	INNER JOIN [cfgCW].[ProductType] pt ON L.LookUpValue=pt.Name 		
	WHERE M.FieldName=@fieldName

	SELECT @totalOutstandingCapitalBalance = sum(CapitalBalanceValue)
	FROM [cw].[DealProductData] pd
	WHERE pd.DealId=@dealId AND CorrelatedDate=@pAsAtDate
	
	SELECT ProductTypeGroup, SUM(LoanCount)  AS [MortgageLoans], SUM(CapitalBalanceValue) AS TotalOutstandingCapitalBalance
	, CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast((sum(CapitalBalanceValue) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
	INTO #CrntProduct
	FROM [cw].[DealProductData] pd
	JOIN  #ProductType  pt ON pd.ProductTypeId=pt.ProductTypeId
	WHERE pd.DealId=@dealId AND CorrelatedDate=@pAsAtDate
	GROUP BY ProductTypeGroup
	
	SELECT @totalOutstandingCapitalBalance = sum(CapitalBalanceValue)
	FROM [cw].[DealProductData] pd
	WHERE pd.DealId=@dealId AND CorrelatedDate=@previous_AsAtdate
	
	SELECT ProductTypeGroup, SUM(LoanCount) AS [MortgageLoans] , SUM(CapitalBalanceValue) AS TotalOutstandingCapitalBalance
	, CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast((sum(CapitalBalanceValue) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
	INTO #PrevProduct
	FROM [cw].[DealProductData] pd
	JOIN  #ProductType  pt ON pd.ProductTypeId=pt.ProductTypeId
	WHERE pd.DealId=@dealId AND CorrelatedDate=@previous_AsAtdate
	GROUP BY ProductTypeGroup
	

	-----==========================StratLookup for Issusance
	SELECT @mortgagedealstart = DealStartDate, @dealkey = MortgageDealKey
	FROM [sfp].[syn_SfpModel_vw_MortgageDeal_v1]
	WHERE DealName = @pDealName 
	
	SELECT @totalSubAccounts=  count(MortgageSubAccountKey)
	 , @capitalBalanceAtFlagged = sum(CapitalBalanceAtFlagged)
	FROM sfp.syn_SfpModel_tbl_Fact_MortgageAssetPool ap   
	INNER JOIN sfp.syn_SfpModel_vw_Calendar_v1 C ON C.AsAtDateKey=  ap.FlaggedDateKey
	WHERE ap.IsFurtherAdvance = 0  
	AND ap.MortgageDealKey = @dealkey  
	AND C.AsAtDate = @mortgagedealstart  


	SELECT ProductTypeGroup, sum(Totalcount) AS IssuanceAccountCount  
	, CASE WHEN @totalSubAccounts > 0 THEN ISNULL(CAST( Cast( (sum(TotalCount) / @totalSubAccounts  ) AS Decimal(38,18)) AS Float) , 0) ELSE 0 END AS MortgageLoansPercent  
	, Cast(sum(TotalOutstandingCapitalBalance) AS Float) AS IssuanceAmount  
	, CASE WHEN @capitalBalanceAtFlagged > 0 THEN Cast((sum(TotalOutstandingCapitalBalance) / @capitalBalanceAtFlagged ) AS Float)  ELSE 0 END AS [IssuanceAmountPercent]
	INTO  #Issusance 
	FROM #ProductType S
	LEFT JOIN sfp.syn_SfpModel_tbl_InvestorInsuranceStrats I ON S.Name = I.StratificationLookUpName
	WHERE I.DealName = @pDealName  
	AND I.AsAtDate = @MortgageDealStart
	GROUP   BY ProductTypeGroup
	---=================================================================
	
	
	
	SELECT ISNULL(P.ProductTypeGroup,'Total') AS '~HeaderText'
	,  ISNULL((SUM(CP.[MortgageLoans])),0) AS 'Number of Mortgage Loans~CRNT',  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalBalance) AS decimal(38,2)),0) AS 'Amount (EUR)~CRNT',  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalPercent) AS decimal(38,8)),0) AS '% of Total Amount~CRNT'
	,  ISNULL((SUM(PP.[MortgageLoans])),0)  AS 'Number of Mortgage Loans~PREV',  ISNULL(CAST(SUM(PP.TotalOutstandingCapitalBalance) AS decimal(38,2)),0) AS 'Amount (EUR)~PREV', ISNULL(CAST(SUM(PP.TotalOutstandingCapitalPercent) AS decimal(38,8)),0) AS '% of Total Amount~PREV'
	,  ISNULL((SUM(I.IssuanceAccountCount)),0) AS 'Number of Mortgage Loans~Isu', ISNULL(CAST(SUM(I.IssuanceAmount) AS decimal(38,2)),0) AS 'Amount (EUR)~Isu', ISNULL(CAST(SUM(I.IssuanceAmountPercent) AS decimal(38,8)),0) AS '% of Total Amount~Isu'
     FROM #ProductTypeGroup P
     LEFT JOIN #CrntProduct CP ON CP.ProductTypeGroup = P.ProductTypeGroup
     LEFT JOIN #PrevProduct PP ON PP.ProductTypeGroup  = P.ProductTypeGroup 
     LEFT JOIN #Issusance I ON I.ProductTypeGroup  = P.ProductTypeGroup 
     GROUP BY P.ProductTypeGroup WITH rollup   
	 ORDER BY SUM(P.SortOrder)  
  
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetProductRateTypeReversionaryProfiles', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END
			   
GO