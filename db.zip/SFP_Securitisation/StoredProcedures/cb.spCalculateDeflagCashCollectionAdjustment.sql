USE [SFP_Securitisation]

GO

IF OBJECT_ID('cb.spCalculateDeflagCashCollectionAdjustment') IS NOT NULL
	DROP PROCEDURE cb.spCalculateDeflagCashCollectionAdjustment
GO


/****** Object:  StoredProcedure cb.spProcessBookingsReconData    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:	30.03.2023
 * Description:  Initiate Deflag Pool Cash Collection Adjustment 
 * @pType: Adjustment/Control Check/DeFlag Data Breakup
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
	
exec cb.spCalculateDeflagCashCollectionAdjustment @pType='Adjustment', @pPoolCashCollectionAdjustmentId=4, @pUserName ='kumavnb'
exec cb.spCalculateDeflagCashCollectionAdjustment @pType='Control Check', @pPoolCashCollectionAdjustmentId=4, @pUserName ='kumavnb'
exec cb.spCalculateDeflagCashCollectionAdjustment @pType='DeFlag Data Breakup', @pPoolCashCollectionAdjustmentId=4, @pUserName ='kumavnb'
 * -------------------------------------------------------
*/  
 
CREATE PROC [cb].spCalculateDeflagCashCollectionAdjustment
	@pType varchar(100)='Adjustment',
	@pPoolCashCollectionAdjustmentId INT = Null,
	@pUserName varchar(255) = null
AS        
BEGIN  
	
	BEGIN TRY
	
		DECLARE @dealId INT =6
			, @mortgageDealId INT
			, @partitionIdFrom INT
			, @partitionIdTo INT
			, @vintageDate Datetime


		SELECT @mortgageDealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealId=@dealId
		SELECT P.PoolId, P.vintagedate, CONVERT(VARCHAR, P.vintagedate, 112) as hypopoolpartitionid, CONVERT(VARCHAR, P.EffectiveDate, 112) as EffectiveDatePartionId   
		INTO #PoolList
		FROM   ps.pool  p
		INNER JOIN [CW].[PoolCashCollectionAdjustmentMap] pccam on p.PoolId=pccam.PoolId
		Where PoolCashCollectionAdjustmentId = IsNull(@pPoolCashCollectionAdjustmentId, PoolCashCollectionAdjustmentId)
		
		SELECT pbd.poolid,   pbd.mortgageaccountkey,  pbd.mortgagesubaccountkey, pbd.LoanId, pl.vintagedate
		INTO   #poolbuilddetail  
		FROM   ps.poolbuilddetail pbd  
		INNER JOIN #PoolList pl on pbd.PoolId = pl.PoolId
		Where pbd.IsActive = 1  


		CREATE TABLE #FinalDeflagAdjustment(PoolId INT, [TotalPrincipalReceipts] float, [TotalRevenueReceipts] float)

		--===============Process Pools Loan Data based on Vinatge and Effective Dates
		DECLARE cursorCWPoolDates CURSOR FOR     
			Select distinct vintagedate, hypopoolpartitionid, EffectiveDatePartionId from #PoolList
			OPEN cursorCWPoolDates    
  
			FETCH NEXT FROM cursorCWPoolDates INTO @vintagedate, @partitionIdFrom, @partitionIdTo
			WHILE @@FETCH_STATUS = 0    
			BEGIN 
	
				IF EXISTS (SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#deFlagLoans') AND type='U')
						DROP TABLE #deFlagLoans;	
			
				SELECT DISTINCT PoolId, loanId	INTO #deFlagLoans FROM #poolbuilddetail WHERE vintagedate=@vintagedate
				
				--Get the balances for all the days we require into a temp table
				IF EXISTS (SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#bal') AND type='U')
					drop TABLE #bal;
				
				IF @pType in ('Control Check', 'DeFlag Data Breakup')
				BEGIN
					SELECT
						 LoanId										=   msa.LoanID
						,BrandCode									=	b.BrandCode
						,MortgageDealKey							=	msab.MortgageDealKey
						,TotalOutstandingCapitalBalance				=	SUM((isnull(msab.TotalOutstandingCapitalBalance,0))	)
						,PartitionID								=	msab.PartitionID
						,PoolId										=	src.PoolId
					INTO 
						#bal
					FROM 
						[sfp].[syn_SfpModel_tbl_Dim_Brand] b
						INNER JOIN SFP_Model.dm.Fact_MortgageSubAccount msab ON msab.BrandKey = b.BrandKey
						INNER JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageAccount] ma ON msab.MortgageAccountKey = ma.MortgageAccountKey 
						INNER JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] msa ON	msab.MortgageSubAccountKey = msa.MortgageSubAccountKey	
						INNER JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] msa_c 
								ON	msa.BrandKey = msa_c.BrandKey
								AND msa.LoanID = msa_c.LoanID 
								AND msa.SubAccountNumber = msa_c.SubAccountNumber 
								AND msa_c.CurrentRecord=1	
						INNER JOIN [sfp].[syn_SfpModel_vw_Calendar_v1] cal ON	msab.AsAtDateKey = cal.AsAtDateKey		
						INNER JOIN [sfp].[syn_SfpModel_vw_Calendar_v1] cal_prev ON	cal.PreviousAsAtDate = cal_prev.AsAtDate AND cal.RegionCode = cal_prev.RegionCode 
						INNER JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageDeal] md ON	msab.MortgageDealKey =md.MortgageDealKey
						INNER JOIN #deFlagLoans src ON  src.LoanID = msa_c.LoanID 
					WHERE
						msab.PartitionID>= @partitionIdFrom AND msab.PartitionID<@partitionIdTo
						AND msab.MortgageDealKey = @mortgageDealId
						AND msa.InceptionDate <> '0001-01-01' 
						AND msa.ProcessStatus NOT IN ('0','1')
						AND msa_c.InceptionDate <> '0001-01-01' 
						AND msa_c.ProcessStatus NOT IN ('0','1')
					GROUP BY  msa.LoanID, b.BrandCode, msab.MortgageDealKey, msab.PartitionID, src.PoolId

				END	
						
			--Get the transec info INTO a temp TABLE
				IF EXISTS (SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#trans') AND type='U')
					DROP TABLE #trans;

				SELECT src.poolId, src.loanId, PartitionID
					  ,(
							((SUM(isnull(CapitalPaid,0))) * -1) 
						+ ((SUM(isnull(PartRedemptiONCapitalPaid,0))) *-1) 
						+ SUM((isnull(OverPayment,0)))
						+ (SUM((isnull(FullRedemptiONCapitalPaid,0))) *-1)
						) AS CommONBalsCalc1,
						(
							((SUM(isnull(CapitalPaid,0))) * -1) 
						+ ((SUM(isnull(PartRedemptiONCapitalPaid,0))) *-1) 
						+ (SUM((isnull(FullRedemptiONCapitalPaid,0))) * -1)
						+ (SUM((isnull(TrueCapitalBalance,0))) * -1)
						+ (SUM((isnull(CapitalBalanceInArrears,0))) * -1)
						) AS CommONBalsCalc2,
						(
							(SUM(isnull(InterestPaid,0)) * -1)
						+ (SUM(isnull(FeesPaid,0))	* -1)
						+ (SUM(isnull(FinesPaid,0)) * -1)
						) AS CommONBalsCalc3
				INTO #trans
				FROM 
						sfp.syn_SfpModel_tbl_Fact_MortgageSubAccountSecTransactiON msact
						INNER JOIN sfp.syn_SfpModel_tbl_Dim_MortgageAccount ma ON msact.MortgageAccountKey = ma.MortgageAccountKey 
						INNER JOIN sfp.syn_SfpModel_tbl_Dim_MortgageSubAccount msa ON msact.MortgageSubAccountKey = msa.MortgageSubAccountKey
						INNER JOIN sfp.syn_SfpModel_tbl_Dim_MortgageSubAccount msa_c 
							ON msa.BrandKey = msa_c.BrandKey 
							AND msa.LoanID = msa_c.LoanID 
							AND msa.SubAccountNumber = msa_c.SubAccountNumber 
							AND msa_c.CurrentRecord = 1
						INNER JOIN #deFlagLoans src ON  src.LoanID = msa_c.LoanID 
					WHERE 
						PartitiONID> @partitionIdFrom AND PartitiONID<@partitionIdTo
						AND MortgageDealKey <> -1
						AND msa.InceptionDate <> '0001-01-01' 
						AND msa.ProcessStatus NOT IN ('0','1')
						AND msa_c.InceptionDate <> '0001-01-01' 
						AND msa_c.ProcessStatus NOT IN ('0','1')
					GROUP BY src.poolId, src.loanId, PartitionID, msa_c.MortgageSubAccountKey ,AsAtDateKey


			--get the transec summary INTO a temp TABLE
				IF EXISTS (SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#trans_summary') AND type='U')
					DROP TABLE #trans_summary;

				SELECT src.poolId, src.loanId, PartitionID
						--,MortgageSubAccountKey	=	msa_c.MortgageSubAccountKey
						--,AsAtDateKey			=	msacts.AsAtDateKey
						,FurtherStageAdvances	=	sum(isnull(FurtherStageAdvances,0)) 
						,FeesChargedCapitalised	=	Sum(isnull(FeesChargedCapitalised,0)) 
					INTO
						#trans_summary
					FROM
						sfp.syn_SfpModel_tbl_Fact_MortgageSubAccountSecTransactiONSummary msacts
						INNER JOIN sfp.syn_SfpModel_tbl_Dim_MortgageAccount ma ON msacts.MortgageAccountKey = ma.MortgageAccountKey 
						INNER JOIN sfp.syn_SfpModel_tbl_Dim_MortgageSubAccount msa ON msacts.MortgageSubAccountKey = msa.MortgageSubAccountKey
						INNER JOIN sfp.syn_SfpModel_tbl_Dim_MortgageSubAccount msa_c 
							ON msa.BrandKey = msa_c.BrandKey 
							AND msa.LoanID = msa_c.LoanID 
							AND msa.SubAccountNumber = msa_c.SubAccountNumber 
							AND msa_c.CurrentRecord=1
						INNER JOIN #deFlagLoans src ON  src.LoanID = msa_c.LoanID 
					WHERE 
						PartitiONID> @partitionIdFrom AND PartitiONID<@partitionIdTo
						AND MortgageDealKey <> -1
						AND msa.InceptionDate <> '0001-01-01' 
						AND msa.ProcessStatus NOT IN ('0','1')
						AND msa_c.InceptionDate <> '0001-01-01' 
						AND msa_c.ProcessStatus NOT IN ('0','1')
					GROUP  BY src.poolId, src.loanId, PartitionID, msa_c.MortgageSubAccountKey, msacts.AsAtDateKey
			
				

				IF EXISTS (SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#DeflagAdjustment') AND type='U')
					DROP TABLE #DeflagAdjustment;

				Select src.poolId, src.loanId
				,'TotalPrincipalReceipts'						=    (
																					   isnull(msa_tx.CommONBalsCalc1,0)
																					+ (isnull(msa_tx_smry.FurtherStageAdvances,0)) 
																					+ (isnull(msa_tx_smry.FeesChargedCapitalised,0))
																					+
																						(
																							(
																								isnull(msa_tx.CommONBalsCalc2,0)
																							  +(isnull(msa_tx_smry.FurtherStageAdvances,0)) 
																							  + (isnull(msa_tx_smry.FeesChargedCapitalised,0)) 

																							 )
																						*-1)
																			  )
				,'TotalRevenueReceipts'					   =   isnull(msa_tx.CommONBalsCalc3,0)				
				INTO #DeflagAdjustment
				FROM 
				#deFlagLoans src
				LEFT JOIN (SELECT LoanId, PoolId, SUM(CommONBalsCalc1) as CommONBalsCalc1, SUM(CommONBalsCalc2) as CommONBalsCalc2, SUM(CommONBalsCalc3) as CommONBalsCalc3 from #trans Group by LoanId, PoolId) as msa_tx on src.loanId=msa_tx.loanId and src.PoolId=msa_tx.PoolId
				LEFT JOIN (SELECT LoanId, PoolId, SUM(FurtherStageAdvances) as FurtherStageAdvances, SUM(FeesChargedCapitalised) as FeesChargedCapitalised from #trans_summary Group by LoanId, PoolId) as msa_tx_smry on src.loanId=msa_tx_smry.loanId and src.PoolId=msa_tx_smry.PoolId
				

				INSERT INTO #FinalDeflagAdjustment
				Select src.poolId, SUM(TotalPrincipalReceipts) as [TotalPrincipalReceipts], SUM(TotalRevenueReceipts) as [TotalRevenueReceipts]
				from #DeflagAdjustment src
				Group by src.poolId

			
			FETCH NEXT FROM cursorCWPoolDates INTO @vintagedate, @partitionIdFrom, @partitionIdTo
		END

		CLOSE cursorCWPoolDates;  
		DEALLOCATE cursorCWPoolDates; 



		IF @pType ='Adjustment'
				Select PoolId, [TotalPrincipalReceipts], [TotalRevenueReceipts] FROM #FinalDeflagAdjustment
		ELSE IF @pType ='Control Check'
		BEGIN
				Declare @ActualRepurchase float, @BalanceasOnLastPartitionDate float
				Declare @FirstPartitionId int, @LastPartitionId INT
				Select @FirstPartitionId= MIN(PartitionId), @LastPartitionId= Max(PartitionId) from #bal

				Select @ActualRepurchase =SUM(TotalOutstandingCapitalBalance) from #bal Where PartitionId = @FirstPartitionId
				Select @BalanceasOnLastPartitionDate =SUM(TotalOutstandingCapitalBalance) from #bal Where PartitionId = @LastPartitionId

				Select @ActualRepurchase 'ActualRepurchase', @BalanceasOnLastPartitionDate 'BalanceasOnLastPartitionDate'
				, @BalanceasOnLastPartitionDate - @ActualRepurchase 'PostAdjustmentRepurchase'
		END
		ELSE IF @pType ='DeFlag Data Breakup'
		BEGIN

			Select Distinct df.PoolId, df.LoanId, TBL.PartitionID
			INTO #deFlagLoansBreakup
			From #deFlagLoans df , 
			(	Select PartitionID From #trans
			Union
			Select PartitionID From #trans_summary
			Union
			Select PartitionID From #bal 
			) as TBL


			SELECT distinct src.PoolId, src.LoanId, src.PartitionId
			,'TotalPrincipalReceipts'				=    (
																					isnull(msa_tx.CommONBalsCalc1,0)
																				+ (isnull(msa_tx_smry.FurtherStageAdvances,0)) 
																				+ (isnull(msa_tx_smry.FeesChargedCapitalised,0))
																				+
																					(
																						(
																							isnull(msa_tx.CommONBalsCalc2,0)
																							+(isnull(msa_tx_smry.FurtherStageAdvances,0)) 
																							+ (isnull(msa_tx_smry.FeesChargedCapitalised,0)) 

																							)
																					*-1)
																			)
			,'TotalRevenueReceipts'					 =   (isnull(msa_tx.CommONBalsCalc3,0)	)
			INTO #AdjustmentLoans
			FROM 
			#deFlagLoansBreakup src
			LEFT JOIN #trans msa_tx on msa_tx.PoolId=src.PoolId and msa_tx.LoanId=src.LoanId and msa_tx.PartitionID=src.PartitionID
			LEFT JOIN #trans_summary msa_tx_smry on msa_tx_smry.PoolId=src.PoolId and msa_tx_smry.LoanId=src.LoanId and msa_tx_smry.PartitionID=src.PartitionID

			Select  src.PoolId, src.LoanId, src.PartitionId, SUM(TotalPrincipalReceipts) as [TotalPrincipalReceipts], SUM(TotalRevenueReceipts) as [TotalRevenueReceipts]
			INTO #AdjustmentData
			FROM #AdjustmentLoans src
			GROUP BY src.PoolId, src.LoanId, src.PartitionId

			SELECT src.PoolId, bl.BrandCode, src.LoanId, src.PartitionId
			,'TotalOutstandingCapitalBalance'		 =	SUM(isNull(bl.TotalOutstandingCapitalBalance,0))
			INTO #CapitalBalanceData
			FROM #deFlagLoansBreakup src
			LEFT JOIN #bal bl on bl.PoolId=src.PoolId and bl.LoanId=src.LoanId and bl.PartitionID=src.PartitionID
			Group by src.PoolId, bl.BrandCode, src.LoanId, src.PartitionId
			Order By SRC.PoolId, SRC.PartitionID, SRC.LoanId

			Select src.PoolId, bl.BrandCode, src.LoanId, src.PartitionId, ad.TotalPrincipalReceipts, ad.TotalRevenueReceipts, bl.TotalOutstandingCapitalBalance
			FROM 
			#deFlagLoansBreakup src
			LEFT JOIN #CapitalBalanceData bl on bl.PoolId=src.PoolId and bl.LoanId=src.LoanId and bl.PartitionID=src.PartitionID
			LEFT JOIN #AdjustmentData ad on ad.PoolId=src.PoolId and ad.LoanId=src.LoanId and ad.PartitionID=src.PartitionID
			Order By SRC.PoolId, SRC.PartitionID, SRC.LoanId
		END


	END TRY  
	BEGIN CATCH  

		
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE() , @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cb.spCalculateDeflagCashCollectionAdjustment',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH  

END

GO




