USE [SFP_Securitisation]
GO


GO
IF OBJECT_ID('[CW].[spIR_GenerateExcelAuotomatedPostWFData]') IS NOT NULL
DROP PROC [CW].[spIR_GenerateExcelAuotomatedPostWFData]
GO


/****** Object:  StoredProcedure [CW].[spIR_GenerateExcelAuotomatedPostWFData]   Script Date: 16/11/2021 09:27:50 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	14.03.2021
 * Description:  Excel Framework Report Deal Mapping Logic for excel writing   
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
 * exec cw.[spIR_GenerateExcelAuotomatedPostWFData] 'DEIMOS',  '30-NOV-21'
 * exec cw.[spIR_GenerateExcelAuotomatedPostWFData] 'Ardmore1',  '29-JAN-21'
 * -------------------------------------------------------
*/    
        
CREATE PROC [CW].[spIR_GenerateExcelAuotomatedPostWFData]
@pDealName varchar(20),
@pAsAtdate DateTime = NULL ,
@pUserName varchar(50) = NULL
AS        
BEGIN 


 SET NOCOUNT ON  
  
 BEGIN TRY         
	
	DECLARE @dealIpdId INT
	, @irFileName varchar(255)
	, @defaultTemplateFile varchar(255)
	, @ipdFilePeriod varchar(50)
	, @irDatePeriod DateTime = DateAdd(m, 1, @pAsAtdate)
	, @irFormatColStartIndex INT=1
	, @irFormatColEndIndex INT=1
	, @irFormatRowStartIndex INT
	, @irFormatRowEndIndex INT
	, @dealId INT;
	
	SELECT   
	  @dealIpdId = dir.DealIpdId, 
	  @dealId = deal.dealId
	 FROM     
	  cw.vwDealIpdDates ipdDt  
	 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
	 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
	 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
	 WHERE   
	  deal.DealName = @pDealName  
	  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
	  AND dir.IpdSequence <> 0   
	  
    IF(@pDealName='DEIMOS')
	SELECT @defaultTemplateFile = Value FROM cw.vw_DealLookup WHERE TypeCode='IPD_CW_Control' AND Name='CBPstWFTemplate'
	ELSE
	SELECT @defaultTemplateFile = Value FROM cw.vw_DealLookup WHERE TypeCode='IPD_CW_Control' AND Name='RMBSPstWFTemplate'


	SELECT @irFileName = FileName FROM cw.DealIpdIrLocation WHERE  FormatType='Excel' AND DealIpdId=@dealIpdId

	SET @ipdFilePeriod= DateName(month, @irDatePeriod) + ' ' + Cast(YEAR(@irDatePeriod) AS varchar) + ' IPD.xlsx'

	
	SELECT NULL AS StratId, 'Deal Aggregated' AS StratName, NULL AS StratTypeId, NULL AS FieldId, 'Deal Aggregated' AS SheetName
	INTO  #TBLStrat 
	



	SELECT  @irFormatColStartIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='Start Column Index'
	SELECT  @irFormatColEndIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='End Column Index'
	SELECT  @irFormatRowStartIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='Start Row Index'
	SELECT  @irFormatRowEndIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='End Row Index'
	
	
	SELECT @pDealName AS DealName,  ST.FieldId, ST.StratName
	, ST.SheetName AS WorksheetName    
	, @defaultTemplateFile AS ExcelTemplateFile      
	, @pDealName + ' PCW Control - ' + @ipdFilePeriod   AS [ExcelOutputFile]
	, 2 AS RowStartIndex, 1 AS   ColumnStartIndex
	, @irFileName AS DownloadIrFileName
	, @irFormatColStartIndex AS IrFormatColStartIndex
	, @irFormatColEndIndex AS IrFormatColEndIndex
	, @irFormatRowStartIndex AS IrFormatRowStartIndex
	, @irFormatRowEndIndex AS IrFormatRowEndIndex
	FROM #TBLStrat ST 
	ORDER BY ST.StratTypeId, ST.StratName

 END TRY  
  
 BEGIN CATCH  
  DECLARE @errorMessage NVARCHAR(MAX)  
   ,@errorSeverity INT  
   ,@errorNumber INT  
   ,@errorLine INT  
   ,@errorState INT;  
  
  SELECT @errorMessage = ERROR_MESSAGE()  
   ,@errorSeverity = ERROR_SEVERITY()  
   ,@errorNumber = ERROR_NUMBER()  
   ,@errorLine = ERROR_LINE()  
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1     ,1      ,'cw.spIR_GenerateExcelAuotomatedPostWFData'      ,@errorNumber  
   ,@errorSeverity      ,@errorLine      ,@errorMessage      ,@pUserName     
  
  RAISERROR (      @errorMessage       ,@errorSeverity       ,@errorState      )  
 
 END CATCH      
END

GO

