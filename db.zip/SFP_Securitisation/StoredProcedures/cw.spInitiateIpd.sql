USE SFP_Securitisation
GO

IF OBJECT_ID('CW.spInitiateIpd') IS NOT NULL
	DROP PROCEDURE CW.spInitiateIpd
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--========================================
--Author: Suresh Pandey
--Date:	22-03-2022
--Description:  This is the parent sp to call initiate Ipd sp based on deal type
--DECLARE @pResultCode INT
--Exec CW.spInitiateIpd 6,'2021-05-24 00:00:00.000' ,'System','Initiate',@pResultCode OUTPUT
--Select @pResultCode
--========================================
CREATE PROCEDURE CW.spInitiateIpd (	
	@pDealId SMALLINT,
	@pIpdDate  DATETIME,
	@pUserName	VARCHAR(80),
	@pAuthStepName VARCHAR(50),
	@pResultCode INT OUTPUT 
)
AS
BEGIN
	DECLARE @dealType VARCHAR(100);

	SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

	IF (@dealType='Covered Bond')
	BEGIN
		EXEC [cb].[spInitiateIpd] @pDealId, @pIpdDate, @pUserName, @pAuthStepName, @pResultCode OUTPUT 
	END
	ELSE IF(@dealType='RMBS')	
	BEGIN
		EXEC [cw].[spRMBSInitiateIpd] @pDealId, @pIpdDate, @pUserName, @pAuthStepName, @pResultCode OUTPUT 
	END

	SELECT @pResultCode

END
GO


