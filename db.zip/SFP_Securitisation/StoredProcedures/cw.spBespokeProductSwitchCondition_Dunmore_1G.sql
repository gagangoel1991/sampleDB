USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spBespokeProductSwitchCondition_Dunmore_1G') IS NOT NULL
	DROP PROCEDURE cw.spBespokeProductSwitchCondition_Dunmore_1G
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spBespokeProductSwitchCondition_Dunmore_1G ( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  09.08.2020 
 *   Description: 
 *   
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *    
 *   exec cw.spBespokeProductSwitchCondition_Dunmore_1G	32,'fm\shriyad'
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20),
  @oValue BIT OUTPUT
)
AS 
BEGIN 
	 DECLARE @dealId  INT, @CollectionBusinessEndDate   datetime

	SELECT @dealId = DealId FROM  cw.vwDealIpdRun WHERE  DealIpdRunId = @pDealIpdRunId 

	SET @CollectionBusinessEndDate=(SELECT DealDateValue 
								  FROM   cw.vwDealDate 
								  WHERE  DealIpdRunId=@pDealIpdRunId 
										 AND DealDateKeyInternalName = 'CollectionBusinessEnd') 

		SELECT
		 @oValue = CASE WHEN SUM(QuarterlyCapitalBalanceValue)!=0 THEN 0 ELSE 1 END
		FROM
		[cw].[DealProductSwitchData] psd
		JOIN  [cfgCW].[ProductSwitchType] pst ON psd.ProductSwitchTypeId = pst.ProductSwitchTypeId AND pst.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductType] pt1 ON pst.ProductTypeId1 = pt1.ProductTypeId AND pt1.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductType] pt2 ON pst.ProductTypeId2 = pt2.ProductTypeId AND pt2.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductRateOfInterestType] prit1 ON pst.ProductRateOfInterestTypeId1 = prit1.ProductRateOfInterestTypeId AND prit1.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductRateOfInterestType] prit2 ON pst.ProductRateOfInterestTypeId2 = prit2.ProductRateOfInterestTypeId AND prit2.IsActive = 1
		WHERE
		dealid=@dealId
		AND CorrelatedDate =@CollectionBusinessEndDate
		AND pst.Name IN ('SVR-FIXED','DISCOUNT-FIXED','LIFETIMETRACKER-FIXED', 'TRACKER-FIXED')

		SELECT @oValue
END

GO