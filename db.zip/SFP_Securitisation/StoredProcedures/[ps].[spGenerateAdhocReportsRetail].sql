USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGenerateAdhocReportsRetail]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGenerateAdhocReportsRetail]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGenerateAdhocReportsRetail]  
 @pPoolAdhocReportTemplateId INT,  
 @pPoolID INT,  
 @pUserName VARCHAR(50),  
 @pLinkedFieldList [ps].[AdhocReportField] ReadOnly,  
 @IsDebug INT = 1   
AS               
 BEGIN              
  BEGIN TRY  
   --TO CHECK IF WE NEED FOLLOWING FIELDS FROM COMMON SP  
   DECLARE @isSecondaryBorrowerReq INT = 0  
   DECLARE @isSecondaryBorrowerIncomeReq INT = 0  
   DECLARE @isRiskFieldReq INT = 0  
   DECLARE @isPaymentScheduleFieldReq BIT = 0  
   DECLARE @isCovidFieldReq INT = 0  
   DECLARE @isFactTransactionFieldReq INT = 0   
   DECLARE @isInterestRateRevisionFieldReq INT = 0   
   DECLARE @isPropertyValuationFieldReq  INT = 0  
  
   --  
   DECLARE @FieldSelectColumn VARCHAR(MAX) = '';  
   DECLARE @AddFieldsColumn VARCHAR(MAX);   
   DECLARE @Active BIT = 1;  
   DECLARE @CustomFieldTypeId INT = (SELECT FieldTypeId FROM ps.FieldType WHERE TypeName = 'Custom');  
  
   DECLARE @PartitionKey VARCHAR(20) = (SELECT CONVERT(VARCHAR, VintageDate, 112)    
             FROM PS.Pool    
             WHERE PoolId=@pPoolID)   
   DECLARE @VintageDate VARCHAR(20) = (SELECT REPLACE(CONVERT(VARCHAR, VintageDate, 106) , ' ', '-')   
            FROM PS.Pool  
            WHERE PoolId= @pPoolID)  
   DECLARE @Query NVARCHAR(MAX) = ''  
  
   IF OBJECT_ID('tempdb.dbo.#tempReportFields', 'U') IS NOT NULL                    
    DROP TABLE #tempReportFields;    
  
   IF OBJECT_ID('tempdb.dbo.#AccountKeys', 'U') IS NOT NULL                    
    DROP TABLE #AccountKeys                           
  
   IF OBJECT_ID('tempdb.dbo.#tempCustomReportFields', 'U') IS NOT NULL  
    DROP TABLE #tempCustomReportFields  
  
   IF OBJECT_ID('tempdb.dbo.#CustomFieldUpdatedSQL', 'U') IS NOT NULL  
    DROP TABLE #CustomFieldUpdatedSQL  
  
   IF OBJECT_ID('tempdb.dbo.#CustomECFields', 'U') IS NOT NULL  
    DROP TABLE #CustomECFields  
     
   IF OBJECT_ID('tempdb.dbo.#tempWithCustomFieldsData', 'U') IS NOT NULL  
    DROP TABLE #tempWithCustomFieldsData  
  
   CREATE TABLE #AccountKeys                                
   (    
    MortgageAccountKey BIGINT,                                                             
    MortgageSubAccountKey BIGINT    
   );  
   SELECT   
     field.EligibilityCriteriaFieldId,  
     field.CriteriaFieldTable,  
     field.FieldDataType,  
     field.FieldType,        
     field.CriteriaFieldName,   
     field.CriteriaFieldSql,    
     field.SourceFieldsUsed,  
     (CASE WHEN templateFields.EligibilityCriteriaFieldId IS NOT NULL THEN   
     templateFields.FieldOrderId   
     WHEN linkedFields.FieldId IS NOT NULL THEN   
     linkedFields.FieldOrderId END) AS FieldOrderId,  
     (CASE WHEN templateFields.EligibilityCriteriaFieldId IS NOT NULL THEN   
     templateFields.DisplayFieldName   
     WHEN linkedFields.FieldId IS NOT NULL THEN   
     field.CriteriaFieldName END) AS DisplayFieldName,   
     ROW_NUMBER() OVER (PARTITION BY field.EligibilityCriteriaFieldId ORDER BY field.EligibilityCriteriaFieldId) RowNumber ,  
     templateFields.AggregationTypeId,  
     templateFields.AggregationName AS OperatorName  
   INTO #tempReportFields  
   FROM ps.EligibilityCriteriaField field   
   LEFT  JOIN   
   (SELECT fieldMap.EligibilityCriteriaFieldId, fieldMap.FieldOrderId, fieldMap.DisplayFieldName, AggregationTypeId, Agrtn.AggregationName FROM [ps].[PoolAdhocReportTemplate] art  
     JOIN [ps].[PoolAdhocReportFieldMap] fieldMap  
      ON art.PoolAdhocReportTemplateId  = fieldMap.PoolAdhocReportTemplateId  
      AND fieldMap.IsActive = @Active  
      AND art.PoolAdhocReportTemplateId = @pPoolAdhocReportTemplateId  
       LEFT JOIN [ps].[FieldAggregation] Agrtn ON Agrtn.AggregationId = fieldMap.AggregationTypeId AND Agrtn.IsActive = @Active) AS templateFields  
      ON templateFields.EligibilityCriteriaFieldId = field.EligibilityCriteriaFieldId  
   LEFT JOIN  @pLinkedFieldList linkedFields  
        ON linkedFields.FieldId = field.EligibilityCriteriaFieldId  
   WHERE (templateFields.EligibilityCriteriaFieldId IS NOT NULL OR linkedFields.FieldId IS NOT NULL)  
    AND field.IsActive = @Active  
   ORDER BY field.EligibilityCriteriaFieldId     
                
   SELECT   
    ecf.EligibilityCriteriaFieldId,  
    ecf.CriteriaFieldSql,  
    sp.*,  
    ecfs.CriteriaFieldName 'Replace_From_Name',  
    ecfs.CriteriaFieldSQL 'Replace_TO_Name',   
    ROW_NUMBER() OVER (PARTITION BY ecf.EligibilityCriteriaFieldId ORDER BY ecfs.EligibilityCriteriaFieldId) RowNumber   
     INTO #tempCustomReportFields   
   FROM #tempReportFields ecf  
    CROSS APPLY [app].[udfSplitString](SourceFieldsUsed, ',') sp  
    INNER JOIN  ps.EligibilityCriteriaField ecfs  
     ON sp.value = ecfs.EligibilityCriteriaFieldId  
   WHERE ecf.FieldType = @CustomFieldTypeId   
     
   -- Replacing brackets and commas with leading and trailing space   
   -- so that it can be considered as a whole word for replacement  
   UPDATE #tempCustomReportFields  
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '(', '( '), ')', ' )');  
  
   UPDATE #tempCustomReportFields  
   SET CriteriaFieldSql  = replace(CriteriaFieldSql, ',', ' , ');  
  
   UPDATE #tempCustomReportFields  
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '[', '[ '), ']', ' ]');  
  
   ;WITH UpdatedEligibilitySQLf(RowID,EligibilityCriteriaFieldId, Expression)                                
   AS                                
   (                      
    SELECT RowNumber,                     
     EligibilityCriteriaFieldId,                                
     Expression = [ps].[fn_ReplaceWholeWord](CriteriaFieldSql, Replace_From_Name, Replace_TO_Name )  
    FROM #tempCustomReportFields WHERE RowNumber = 1                                
                                                                                                         
   UNION ALL                                              
                                                                                                         
    SELECT RowNumber,                     
     t.EligibilityCriteriaFieldId,         
     Expression = [ps].[fn_ReplaceWholeWord](c.Expression, Replace_From_Name,Replace_TO_Name)                          
    FROM UpdatedEligibilitySQLf c                        
     INNER JOIN #tempCustomReportFields t ON t.EligibilityCriteriaFieldId = c.EligibilityCriteriaFieldId                        
    WHERE RowNumber = RowID + 1                        
   )     
   
   SELECT EligibilityCriteriaFieldId,                     
   Expression AS FinalExpression    
   INTO #CustomFieldUpdatedSQL  
   FROM UpdatedEligibilitySQLf                                              
   WHERE RowID IN                                               
   (                                              
    SELECT MAX(RowID) AS RowID     
    FROM UpdatedEligibilitySQLf tbl     
    WHERE UpdatedEligibilitySQLf.EligibilityCriteriaFieldId = tbl.EligibilityCriteriaFieldId                                                                                        
   )    
   GROUP BY RowID, EligibilityCriteriaFieldId, Expression                                           
   ORDER BY EligibilityCriteriaFieldId     
  
   UPDATE te  
   SET te.CriteriaFieldSQL = cf.FinalExpression  
   FROM #tempReportFields te  
    INNER JOIN #CustomFieldUpdatedSQL cf  
   ON te.EligibilityCriteriaFieldId = cf.EligibilityCriteriaFieldId  
     
   /*fetch custom fields with base columns names as comma seperated in single row*/  
   DECLARE @fields VARCHAR(MAX)  
   SELECT @fields =   ISNULL(@fields+', ','') + t.SourceFieldsUsed  
   FROM (SELECT DISTINCT SourceFieldsUsed FROM #tempReportFields WHERE SourceFieldsUsed IS NOT NULL ) t  
     
   /*Now split custom fields list into a temp tabel in multiple rows*/  
   SELECT CONVERT(INT,Value) AS fieldId INTO #CustomECFields FROM [app].[udfSplitString](@fields,',')       
     
   /*Added CriteriaFieldName in temp table for both custom and non custom fields*/  
   SELECT DISTINCT CriteriaFieldSql, CriteriaFieldTable, FieldDataType  
   INTO #tempWithCustomFieldsData   
   FROM (  
     SELECT CriteriaFieldSql, CriteriaFieldTable, FieldDataType FROM ps.EligibilityCriteriaField WHERE EligibilityCriteriaFieldId IN (SELECT fieldId FROM #CustomECFields) AND IsActive = 1  
     )x  
  
   UNION   
    SELECT DISTINCT CriteriaFieldSql, CriteriaFieldTable, FieldDataType FROM #tempReportFields WHERE SourceFieldsUsed IS NULL     
  
   /*Mandatory Eligibility Criteria Fields Which are exposed on UI as well */  
   UNION   
    SELECT CriteriaFieldSql, CriteriaFieldTable, FieldDataType FROM ps.EligibilityCriteriaField WHERE CriteriaFieldSql IN ('LOAN_IDENTIFIER','OUTSTANDNG_CAPITAL_BALANCE_AMT','TRUE_BALANCE_AMT')  
  
   /*Mandatory Eligibility Criteria Fields Which are not exposed on UI */  
   UNION  
    SELECT 'MortgageAccountKey','FactMortgageSubAccountEntity', 2  
   UNION  
    SELECT 'MortgageSubAccountKey','FactMortgageSubAccountEntity', 2  
     
  
   --Check Which Fields are used  
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'PropertyValuationField')   
   SET @isPropertyValuationFieldReq = 1  
    
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'RiskField')   
   SET @isRiskFieldReq = 1  
  
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'PaymentScheduleField')   
   SET @isPaymentScheduleFieldReq = 1   
  
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'Customer2Entity')   
   SET @isSecondaryBorrowerReq = 1    
  
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'CovidField')   
   SET @isCovidFieldReq = 1   
    
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'Customer2IncomeField')   
   SET @isSecondaryBorrowerIncomeReq = 1     
  
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'FactTransactionField')   
   SET @isFactTransactionFieldReq = 1   
  
   IF EXISTS(SELECT 1 FROM #tempWithCustomFieldsData WHERE CriteriaFieldTable = 'InterestRateRevisionField')   
   SET @isInterestRateRevisionFieldReq = 1  
  
     
   -- Reverting square brackets to its previous state so that sql can evaluate expression value within brackets.  
   UPDATE #tempReportFields  
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '( ', '('), ' )', ')');  
  
   UPDATE #tempReportFields  
   SET CriteriaFieldSql  = replace(CriteriaFieldSql, ' , ', ',');      
      
   UPDATE #tempReportFields  
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '[ ', '['), ' ]', ']');  
  
  
   
  
   DECLARE @XmlData XML = NULL  
   DECLARE @ReqCols XML = NULL  
   DECLARE @RowID Varchar(50) = ''         
   SELECT @XmlData = ( SELECT fmsa.MortgageAccountKey, fmsa.MortgageSubAccountKey   
        FROM sfp.syn_SfpModel_vw_FactMortgageSubAccountEntity fmsa WITH (NOLOCK)   
        INNER JOIN sfp.syn_SfpModel_vw_MortgageAccountEntity ma WITH (NOLOCK)  
         ON fmsa.MortgageAccountKey = ma.MortgageAccountKey   
        INNER JOIN (  
           SELECT DISTINCT LoanId   
           FROM ps.PoolBuildDetail pld               
            WHERE pld.poolId = @pPoolID   
            AND pld.IsActive = 1  
           ) ln             
         ON ln.LoanId = ma.LoanId           
        WHERE fmsa.PartitionId = @PartitionKey  
        --AND ( (fmsa.MortgageDealKey != -1) OR (fmsa.MortgageDealKey=-1 AND ma.IsLoanClosed!='Closed'))         
        FOR XML PATH('Node'), ROOT('Root')  
        )  
   
            
   SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  FROM #tempWithCustomFieldsData FOR XML PATH('Node'), ROOT('Root'))   
     
   EXEC  [app].[spInsertExecutionLog] @pPoolId, 'SP rpt.uspMortgageLoanEntity Start'      
  
   EXEC sfp.syn_SfpModel_sp_rpt_uspMortgageLoanEntity  
    @VintageDate = @VintageDate,  
    @DealKey = '',   
    @BrandKey = '',  
    @XmlData = @XmlData,   
    @ReqColumns = @ReqCols,  
    @IsPropertyValuationFieldReq = @isPropertyValuationFieldReq,  
    @IsRiskFieldReq = @isRiskFieldReq,   
    @IsPaymentScheduleFieldReq = @isPaymentScheduleFieldReq,   
    @IsSecondaryCustomerFieldReq = @isSecondaryBorrowerReq,   
    @IsCovidFieldReq = @isCovidFieldReq,   
    @IsSecondaryCustomerIncomeFieldReq = @isSecondaryBorrowerIncomeReq,   
    @IsFactTransactionFieldReq = @isFactTransactionFieldReq,   
    @IsInterestRateRevisionFieldReq = @isInterestRateRevisionFieldReq,  
    @OutputRowID = @RowID OUTPUT  
  
  
   EXEC  [app].[spInsertExecutionLog] @pPoolId, 'SP rpt.uspMortgageLoanEntity End'  
      
  
   PRINT 'Data Population in #MortgageData Ended'    
    
   PRINT 'Query Execution Started'       
  
  
      
  
   --SELECT * FROM #tempReportFields   
   DECLARE @ReportTypeId INT, @MortgageLevelReportId INT, @PoolLimitAnalysisDbColumnName Varchar(50)  
   SELECT @ReportTypeId = ReportTypeId FROM [ps].[PoolAdhocReportTemplate] WHERE PoolAdhocReportTemplateId = @pPoolAdhocReportTemplateId  
   SELECT @ReportTypeId = ISNULL(@ReportTypeId, (SELECT AdhocReportTypeId FROM [ps].[AdhocReportType] WHERE ReportTypeName = 'SubAccount Level') )  
   SELECT @MortgageLevelReportId = AdhocReportTypeId FROM [ps].[AdhocReportType] WHERE ReportTypeName = 'Mortgage Level'  
   --RETURN  
  
   --SELECT @ReportTypeId = 1  
   IF EXISTS(SELECT 1 FROM #tempReportFields)      
   BEGIN   
  
   IF(@ReportTypeId = @MortgageLevelReportId)  
   BEGIN   
    PRINT 'Account level'  
  
    SELECT @PoolLimitAnalysisDbColumnName = LimitField.DbColumnName  
    FROM ps.Pool [Pool]   
    JOIN ps.PoolLimitAnalysisField LimitField ON [Pool].PoolLimitAnalysisFieldId = LimitField.PoolLimitAnalysisFieldId AND LimitField.IsActive = 1  
    WHERE [Pool].PoolId = @pPoolID  
    SELECT @PoolLimitAnalysisDbColumnName =  ISNULL(LTRIM(RTRIM(@PoolLimitAnalysisDbColumnName)),'')  
  
    SELECT @FieldSelectColumn = @FieldSelectColumn +   
      CASE    
       WHEN OperatorName ='MINIMUM' THEN 'MIN(' + CriteriaFieldSql + ')'  
       WHEN OperatorName ='MAXIMUM' THEN 'MAX(' + CriteriaFieldSql + ')'  
       WHEN OperatorName ='AVERAGE' THEN 'AVG(' + CriteriaFieldSql + ')'  
       WHEN OperatorName ='SUM'     THEN 'SUM(' + CriteriaFieldSql + ')'   
       WHEN OperatorName ='Weighted Average' THEN   
        ' CASE WHEN '''+ @PoolLimitAnalysisDbColumnName +''' = '''' OR SUM(ISNULL('+ @PoolLimitAnalysisDbColumnName +',0)) = 0 THEN AVG(ISNULL('+ CriteriaFieldSql +',0))  
         ELSE SUM(ISNULL('+ CriteriaFieldSql +',0) * ISNULL('+ @PoolLimitAnalysisDbColumnName +',0)) / SUM(ISNULL('+ @PoolLimitAnalysisDbColumnName +',0)) END'  
  
       WHEN OperatorName ='Value of Latest Subaccount' THEN   
       '(SELECT ' + CriteriaFieldSql + ' FROM sfp.syn_SfpModel_tbl_SfpPlusMortgageStaging A WHERE RowId = '''+ @RowID +''' AND A.MortgageSubAccountKey = MAX(query.MortgageSubAccountKey))'  
       WHEN OperatorName ='Value of Oldest Subaccount' THEN   
       '(SELECT ' + CriteriaFieldSql + ' FROM sfp.syn_SfpModel_tbl_SfpPlusMortgageStaging A WHERE RowId = '''+ @RowID +''' AND A.MortgageSubAccountKey = MIN(query.MortgageSubAccountKey))'  
       ELSE -- IF NO OPERATOR SPECIFIED THEN TAKE LATEST VALUE  
       '(SELECT ' + CriteriaFieldSql + ' FROM sfp.syn_SfpModel_tbl_SfpPlusMortgageStaging A WHERE RowId = '''+ @RowID +''' AND A.MortgageSubAccountKey = MAX(query.MortgageSubAccountKey))'  
       END   
       + ' AS '''  + CAST(DisplayFieldName AS VARCHAR(100))  + ''', '             
     FROM #tempReportFields  ORDER BY FieldOrderId ASC      
    SET @FieldSelectColumn = ','+@FieldSelectColumn  
    
    --Alter #AccountKeys Table to add Fields as columns    --Alter Table #AccountKeys DROP COLUMN MortgageSubAccountKey    
    SET @AddFieldsColumn  = ' ALTER TABLE #AccountKeys ADD '    
    SELECT @AddFieldsColumn = @AddFieldsColumn +  '[' + CAST(DisplayFieldName AS VARCHAR(100))  + '] VARCHAR(MAX), ' FROM #tempReportFields        
      ORDER BY FieldOrderId ASC      
    SET @AddFieldsColumn = (SUBSTRING(@AddFieldsColumn, 0, LEN(@AddFieldsColumn)))   
  
    --SELECT @FieldSelectColumn   
    --RETURN  
    EXEC (@AddFieldsColumn)   
  
    SET @QUERY= 'Insert into #AccountKeys   
    SELECT MortgageAccountKey,  1 MortgageSubAccountKey   
    '+ SUBSTRING(@FieldSelectColumn, 0, LEN(@FieldSelectColumn))+'           
    FROM  ( SELECT * FROM sfp.syn_SfpModel_tbl_SfpPlusMortgageStaging WHERE RowId = '''+@RowID+''' ) query GROUP BY MortgageAccountKey  '   
  
   END  
   ELSE  
   BEGIN  
    PRINT 'Sub-Account level'  
  
    SELECT @FieldSelectColumn = @FieldSelectColumn + CriteriaFieldSql + ' AS '''  + CAST(DisplayFieldName AS VARCHAR(100))  + ''', '             
     FROM #tempReportFields  ORDER BY FieldOrderId ASC      
    SET @FieldSelectColumn = ','+@FieldSelectColumn          
          
    --Alter #AccountKeys Table to add Fields as columns      
    SET @AddFieldsColumn  = 'Alter Table #AccountKeys ADD '      
    SELECT @AddFieldsColumn = @AddFieldsColumn +  '[' + CAST(DisplayFieldName AS VARCHAR(100))  + '] VARCHAR(MAX), ' FROM #tempReportFields        
      ORDER BY FieldOrderId ASC      
    SET @AddFieldsColumn = (SUBSTRING(@AddFieldsColumn, 0, LEN(@AddFieldsColumn)))  
    EXEC (@AddFieldsColumn)  
  
    SET @QUERY= 'Insert into #AccountKeys                                      
     SELECT MortgageAccountKey              
     ,MortgageSubAccountKey                 
     '+ SUBSTRING(@FieldSelectColumn, 0, LEN(@FieldSelectColumn))+'           
     FROM  ( SELECT * FROM sfp.syn_SfpModel_tbl_SfpPlusMortgageStaging WHERE RowId = '''+@RowID+''' ) query '  
   END          
   END   
                                 
   IF(@IsDebug = 1)                                
   PRINT CAST(@query AS NTEXT)                                    
    EXEC(@query)                                
        
   PRINT 'Query Execution Ended'   
  
   EXEC  [app].[spInsertExecutionLog] @pPoolId, 'Data Inserted in #AccountKeys Table'  
         
   DELETE FROM sfp.syn_SfpModel_tbl_SfpPlusMortgageStaging WHERE RowId = @RowID    
   EXEC  [app].[spInsertExecutionLog] @pPoolId, 'Data Deleted From SfpPlusMortgageStaging'   
     
   --output     
   DECLARE @LoanIdentifier_FieldColumnName VARCHAR(50) = (SELECT '['+DisplayFieldName+']' FROM #tempReportFields WHERE CriteriaFieldSql = 'LOAN_IDENTIFIER')  
      DECLARE @SubAccountId_FieldColumnName VARCHAR(50) = (SELECT '['+DisplayFieldName+']' FROM #tempReportFields WHERE CriteriaFieldSql = 'SUB_ACCOUNT_ID')  
      DECLARE @SortColumns VARCHAR(100) = ISNULL(@LoanIdentifier_FieldColumnName,'') +','+ ISNULL(@SubAccountId_FieldColumnName,'')  
   
   IF (SUBSTRING(@SortColumns, 1, 1) = ',')  
   BEGIN   
    SELECT @SortColumns = RIGHT(@SortColumns, LEN(@SortColumns)-1)  
   END  
   IF (SUBSTRING(@SortColumns, LEN(@SortColumns), 1) = ',')  
   BEGIN   
      SELECT @SortColumns = LEFT(@SortColumns, LEN(@SortColumns)-1)   
   END  
   IF(NULLIF(@SortColumns,'') IS NOT NULL)  
   BEGIN  
    EXEC('SELECT * FROM #AccountKeys ORDER BY '+ @SortColumns)  
   END  
   ELSE  
   BEGIN  
    SELECT * FROM #AccountKeys;    
   END  
  
  END TRY              
  BEGIN CATCH              
   DECLARE   
     @errorMessage     NVARCHAR(MAX),  
     @errorSeverity    INT,  
     @errorNumber      INT,  
     @errorLine        INT,  
     @errorState       INT;  
   SELECT   
    @errorMessage = ERROR_MESSAGE()  
    ,@errorSeverity = ERROR_SEVERITY()  
    ,@errorNumber = ERROR_NUMBER()  
    ,@errorLine = ERROR_LINE()  
    ,@errorState = ERROR_STATE()  
  
   EXEC app.SaveErrorLog 2, 1, 'spGenerateAdhocReportsRetail', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
   RAISERROR (@errorMessage,  
     @errorSeverity,  
     @errorState )          
   END CATCH              
 END
 GO
