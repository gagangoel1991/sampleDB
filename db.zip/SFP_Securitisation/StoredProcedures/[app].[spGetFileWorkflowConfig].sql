USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spGetFileWorkflowConfig]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[spGetFileWorkflowConfig]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spGetFileWorkflowConfig]
(	
	@pFileInfoId INT,
	@pUserName VARCHAR(50)
)      
AS      
BEGIN      
	BEGIN TRY        
		SELECT
			ModelStoredProcName as ModelProcName,
			PublishTriggerFileName as PublishFileName
		FROM       
		[app].[FileWorkflowConfig]
		WHERE FileInfoId = @pFileInfoId
		 AND IsActive = 1;

	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetFileWorkflowConfig', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO
