USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spValidateDrillThroughReport]') AND type IN (N'P', N'PC'))
DROP PROCEDURE [ps].[spValidateDrillThroughReport]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 11225, 11161
-- [ps].[spValidateDrillThroughReport] 11161, 'kothpaj'
CREATE PROCEDURE [ps].[spValidateDrillThroughReport]
	@pPoolId int,
	@pUserName VARCHAR(50),
	@pReturnValue INT = 1 OUTPUT
AS
BEGIN		
	BEGIN TRY

		DECLARE @ECCount INT; 
		SELECT @ECCount = COUNT(1) FROM PS.PoolEligibilityBuildDetail WHERE PoolId = @pPoolId AND EligibilityCriteriaId <> -1;

		DECLARE @CTCount INT; 
		SELECT @CTCount = COUNT(1) FROM PS.PoolCTMap WHERE PoolId = @pPoolId;
		
		-- Check whether any EC or CT applied on Pool or not		
		IF (@ECCount > 0 OR @CTCount > 0)		
			SET @pReturnValue = 1;		
		ELSE
			SET @pReturnValue = -1;
		RETURN @pReturnValue;
   END TRY
	BEGIN CATCH		
		SET @pReturnValue  = -2;
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spValidateDrillThroughReport', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RETURN @pReturnValue;

		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
