USE [SFP_Securitisation]
GO

-- EXEC [corp].[spGetOverrideVintageDateList] @pDealId = 1, @pUserName = 'kumasdt'
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetOverrideVintageDateList]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetOverrideVintageDateList]
GO

CREATE PROCEDURE [corp].[spGetOverrideVintageDateList]
	@pDealId INT,
	@pUserName VARCHAR(50)
AS
BEGIN

	BEGIN TRY
		SELECT DISTINCT CAST(DOP.AsAtDate AS DATE) AS VintageDate
		FROM [corp].[DealOverrideParent] DOP
		JOIN corp.[DealDataCorrectionStatus] ST ON ST.DealDataCorrectionStatusId = DOP.DataCorrectionStatus
		WHERE DOP.DealId = @pDealId
		AND ST.Status = 'Authorised'
		AND DOP.IsActive = 1
		AND ST.IsActive = 1
		ORDER BY 1 DESC
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetOverrideVintageDateList', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
End
GO