USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spCalculateDailySoniaCompounding]') IS NOT NULL
	DROP PROCEDURE [cb].[spCalculateDailySoniaCompounding]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spCalculateDailySoniaCompounding]
/*-------------------------------------------------------
 * Author: Kapil Sharma
 * Date:	16.12.2021
 * Description:  This will calculate the SONIA compounding on a daily basis
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * 
 * EXEC [cb].[spCalculateDailySoniaCompounding] '2021-11-30'
*/
(
	@pAsAtDate				DATETIME
)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		--*******************Checking whether the interest rate data is exist or not*********************************
		IF NOT EXISTS(SELECT TOP 1 * FROM [cw].[vwInterestRate] WHERE  RICCode = 'SONIAOSR=' AND BaseDate = @pAsAtDate)
		BEGIN
			PRINT 'Specified date data is not exists in the Interest Rate table - ' +  CONVERT(VARCHAR(10), @pAsAtDate, 111)
		END
		ELSE
		BEGIN
			BEGIN TRANSACTION

				DECLARE 
					@resetLeadDays			SMALLINT,
					@accrualStartDate		DATETIME,
					@accrualEndDate			DATETIME,
					@accrualDtDiffdays		INT,
					@days					INT,
					@interestRate			DECIMAL(20, 16),
					@accrualRate			DECIMAL(38, 16),
					@soniaCompoundingRateId	INT,
					@accrualBasisTypeId		TINYINT,
					@accrualValue			INT,
					@daysInCurrYear			INT,
					@soniaResetLeadDaysId	TINYINT,
					@leadDaysCounter		INT,
					@totalLeadDays			INT,
					@dayCountMethodCounter		INT,
					@totalDayCountMethodTypes		INT,
					@createdDate			DATETIME,
					@createdBy				VARCHAR(40);

				DECLARE	@tblSoniaResetLeadDays TABLE(Id INT IDENTITY(1,1), SoniaResetLeadDaysId TINYINT, [Value] SMALLINT);
				DECLARE	@tblDayCountMethod TABLE(Id SMALLINT IDENTITY(1,1), AccrualBasisTypeId SMALLINT, [Value] DECIMAL(38,16))

				--Set parameters
				SET @createdDate = GETDATE();
				SET @createdBy = 'System';

				INSERT INTO @tblSoniaResetLeadDays(SoniaResetLeadDaysId, [Value])
				SELECT SoniaResetLeadDaysId, CAST([Value] AS INT) AS [Value] FROM [cfgcb].[SoniaResetLeadDays] WHERE IsActive = 1

				INSERT INTO @tblDayCountMethod(AccrualBasisTypeId, [Value])
				SELECT LookupValueId, CAST([Value] AS DECIMAL(38,16)) AS [Value] FROM cw.vw_DealLookup 
				WHERE TypeCode = 'DayCountMethod'

				SELECT @totalLeadDays = COUNT(*) FROM @tblSoniaResetLeadDays
				SELECT @totalDayCountMethodTypes = COUNT(*) FROM @tblDayCountMethod
				SET @leadDaysCounter = 1
				SET @dayCountMethodCounter = 1

				WHILE @leadDaysCounter <= @totalLeadDays
				BEGIN
					SELECT @soniaCompoundingRateId = SoniaResetLeadDaysId, @resetLeadDays = [Value] FROM @tblSoniaResetLeadDays 
					WHERE Id = @leadDaysCounter

					PRINT '@soniaCompoundingRateId'
					PRINT @soniaCompoundingRateId
					PRINT '@resetLeadDays'
					PRINT @resetLeadDays

					---Calculate the accrual start and end date
					;WITH cteAccrualStartDt AS
					(
						SELECT TOP 100 ROW_NUMBER() OVER (ORDER BY AsAtDate ASC) AS RowNo, AsAtDate 
						FROM [sfp].[syn_SfpModel_vw_Calendar_v1]  
						WHERE RegionCode = 'UK' AND IsWeekend = 0 AND IsHoliday = 0 AND AsAtDate > @pAsAtDate
						ORDER BY AsAtDate 
					)
					SELECT @accrualStartDate = AsAtDate FROM cteAccrualStartDt 
					WHERE RowNo = @resetLeadDays

					;WITH cteAccrualEndDt AS
					(
						SELECT TOP 100 ROW_NUMBER() OVER (ORDER BY AsAtDate ASC) AS RowNo, AsAtDate 
						FROM [sfp].[syn_SfpModel_vw_Calendar_v1]  
						WHERE RegionCode = 'UK' AND IsWeekend = 0 AND IsHoliday = 0 AND AsAtDate > @pAsAtDate
						ORDER BY AsAtDate 
					)
					SELECT @accrualEndDate = AsAtDate FROM cteAccrualEndDt 
					WHERE RowNo = @resetLeadDays + 1 

					--Fetch the interest rate for the SONIA Compounding 
					SELECT @interestRate = Rate FROM [cw].[vwInterestRate] WHERE  RICCode = 'SONIAOSR=' AND BaseDate = @pAsAtDate

					---Get days in the current year - Accrual Start Date
					SELECT @daysInCurrYear = DATEDIFF(DAY,DATEFROMPARTS(YEAR(@pAsAtDate),1,1), DATEFROMPARTS(YEAR(@pAsAtDate)+1,1,1))
					SELECT @accrualDtDiffdays = DATEDIFF(DAY, @accrualStartDate, @accrualEndDate)

					--Inserting SONIA Rate in cb.SoniaRate table
					IF EXISTS(SELECT TOP 1 * FROM [cb].[SoniaCompoundingRate] WHERE SoniaResetLeadDaysId = @soniaCompoundingRateId AND CAST(ResetDate AS DATE) = CAST(@pAsAtDate AS DATE))
					BEGIN
						PRINT 'Update Sonia rate'
						UPDATE [cb].[SoniaCompoundingRate] SET SoniaResetLeadDaysId = @soniaCompoundingRateId, SoniaRate = @interestRate, AccrualStartDate = @accrualStartDate, AccrualEndDate = @accrualEndDate
						WHERE CAST(ResetDate AS DATE) = CAST(@pAsAtDate AS DATE) AND SoniaResetLeadDaysId = @soniaCompoundingRateId
					END
					ELSE
					BEGIN
						PRINT 'add Sonia rate'
						INSERT INTO [cb].[SoniaCompoundingRate](ResetDate, SoniaResetLeadDaysId, AccrualStartDate, AccrualEndDate, SoniaRate, CreatedBy, CreatedDate)
						VALUES(@pAsAtDate, @soniaCompoundingRateId, @accrualStartDate, @accrualEndDate, @interestRate, @createdBy, @createdDate)
					END

					SELECT @soniaCompoundingRateId = [SoniaCompoundingRateId] FROM [cb].[SoniaCompoundingRate] 
					WHERE CAST(ResetDate AS DATE) = CAST(@pAsAtDate AS DATE) AND SoniaResetLeadDaysId = @soniaCompoundingRateId

			
					SET @dayCountMethodCounter = 1 --Reset the counter
					WHILE @dayCountMethodCounter <= @totalDayCountMethodTypes
					BEGIN

						SELECT @accrualBasisTypeId = AccrualBasisTypeId, @accrualValue = [Value] FROM @tblDayCountMethod WHERE Id = @dayCountMethodCounter

						SELECT @days = CASE WHEN @accrualValue = -1 THEN @daysInCurrYear ELSE @accrualValue END
		
						SELECT @accrualRate = 1+ (@interestRate/100.00)*@accrualDtDiffdays/@days

						IF EXISTS(SELECT TOP 1 * FROM [cb].[SoniaCompoundingAccrualRate] WHERE [SoniaCompoundingRateId] = @soniaCompoundingRateId AND AccrualBasisTypeId = @accrualBasisTypeId)
						BEGIN
							UPDATE [cb].[SoniaCompoundingAccrualRate] SET Rate = @accrualRate WHERE [SoniaCompoundingRateId] = @soniaCompoundingRateId AND AccrualBasisTypeId = @accrualBasisTypeId
						END
						ELSE
						BEGIN
							INSERT INTO [cb].[SoniaCompoundingAccrualRate]([SoniaCompoundingRateId], AccrualBasisTypeId, Rate, CreatedBy, CreatedDate)
							VALUES(@soniaCompoundingRateId, @accrualBasisTypeId, @accrualRate, @createdBy, @createdDate)
						END

						SET @dayCountMethodCounter = @dayCountMethodCounter + 1
					END;
					SET @leadDaysCounter = @leadDaysCounter + 1
				END;

			COMMIT TRANSACTION; 
		END
			
	END TRY
	BEGIN CATCH

		IF @@trancount > 0 ROLLBACK TRANSACTION; 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spCalculateDailySoniaCompounding', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO