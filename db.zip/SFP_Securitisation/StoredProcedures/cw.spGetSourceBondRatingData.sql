USE SFP_Securitisation
GO
IF OBJECT_ID('[cw].[spGetSourceBondRatingData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetSourceBondRatingData]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spGetSourceBondRatingData]   
/*  
 * Author: Gunjan Chandola  
 * Date: 19.01.2021  
 * Description:  This will return unmodified bond rating for collection business date and IPD Run ID 
 * [cw].[spGetSourceBondRatingData] 14,4,'Test'
 * Change History  
 * --------------  
 * Author: Saurabh Bhatia  
 * Date: 22.06.2021  
 * -------------------------------------------------------  
*/  
@pDealId  INT,   
@pIPDRunId INT,
@pUserName  VARCHAR(80)  
AS  
BEGIN  
  
 SET NOCOUNT ON  
 
 BEGIN TRY  
      DECLARE @cols AS NVARCHAR(MAX), @collectionStartDate DATE,  @collectionEndDate DATE, @query VARCHAR(MAX), @latestRatingDate DATE
      SELECT  @cols = STUFF((SELECT DISTINCT ',' + CAST(ISIN AS NVARCHAR(20)) 
        FROM [cfgCW].[DealNote] WHERE IsActive=1 AND DealId=@pDealId AND IsNote = 1
        FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'')
		

			SELECT @collectionStartDate = CAST(CollectionBusinessStart AS DATE)
			,@collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
		FROM [cw].[vwDealIpdDates] ipdDt
		JOIN cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE ipdRun.RunId = @pIPDRunId
		
        SET @latestRatingDate=(SELECT CAST(MAX(cpr.RatingDate) AS DATE) FROM [cw].[SourceBondRating] cpr WHERE cpr.RatingDate
		BETWEEN @collectionStartDate AND @collectionEndDate 
		)
          
      
      IF OBJECT_ID('tempdb..#tempBondRating') IS NOT NULL DROP TABLE #tempBondRating
      
      SELECT  rt.Name AS RatingType
      ,CASE WHEN sbr.RatingDate=@collectionEndDate THEN 0 ELSE 1 END AS IsPostCollectionEndDate
      ,sbr.ISIN
      ,cra.Name AS RatingAgency
      ,rt.RatingTypeId
      ,cra.CRAId
      ,sbr.RatingDate
      ,sbr.Rating
      ,NULL AS ModifiedBy
      ,NULL AS ModifiedDate INTO #tempBondRating
      FROM [cw].[SourceBondRating] sbr
        JOIN cfgcw.RatingType rt ON rt.RatingTypeId = sbr.RatingTypeId AND rt.IsActive = 1
        JOIN cfgcw.CreditRatingAgency cra ON cra.CRAId = sbr.CRAId AND cra.IsActive = 1
        JOIN cfgcw.DealSubjectCRAMap dscm ON dscm.CRAId = cra.CRAId AND dscm.DealId = @pDealId AND dscm.IsActive = 1	
		JOIN cfgcw.DealSubjectType dst ON dst.DealSubjectTypeId = dscm.DealSubjectTypeId AND dst.[Name] = 'Note' AND dst.IsActive=1	
		WHERE CAST(sbr.RatingDate AS DATE)=@latestRatingDate  

    
    
    SET @query = 
                'SELECT * FROM 
                (
                    SELECT RatingDate, IsPostCollectionEndDate, CRAId ,RatingTypeId,ISIN, RatingType, RatingAgency, Rating, ModifiedBy, ModifiedDate FROM #tempBondRating
                ) src
                pivot 
                (
                    MAX(Rating) for ISIN in (' + @cols + ')
                ) piv'

    EXECUTE(@query)


 END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'cw.spGetSourceBondRatingData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END
GO