USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spLoadFXRateData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadFXRateData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [CW].[spLoadFXRateData]
	/*-------------------------------------------------------      
 * Author: Gunjan Chandola      
 * Date: 07.10.2020      
 * Description:  This will LOAD data from staging into CW table for FX Rate      
 *           
 * Change History      
 * --------------      
 * Author  Date  Description      
 * -------------------------------------------------------      
*/
	(
	@pFeedRunLogId INT
	,@pAsAtDate DATETIME
	)
AS
BEGIN    
    
	SET NOCOUNT ON    
    
	BEGIN TRY    

		IF @pFeedRunLogId IS NOT NULL    
		BEGIN    
			BEGIN TRANSACTION    

			DECLARE  
				@fromCurrency			INT ,
				@toCurrency				INT ,
				@rate					DECIMAL(29, 11),
				@priceLevelScheme		VARCHAR(20) ,
				@rateDate				DATETIME ,
				@ratePeriod				VARCHAR(20) ,
				@ratePeriodMultiplier	DECIMAL(9, 6),
				@quoteBasis				VARCHAR(50) ,
				@loadDate				VARCHAR(20) ,
				@sourceSystemName		VARCHAR(100) ,  
				@version				SMALLINT=1,    
				@fileName				VARCHAR(500),    
				@relatesToDate			VARCHAR(20),    
				@createdDate			DATETIME,    
				@createdBy				VARCHAR(80),
				@relatesRateDate		DATE
    
			--Set parameters    
			SET @createdDate = GETDATE();    
			SET @createdBy = 'System';  
		   
			DECLARE cursorFXRateStg CURSOR
				FOR SELECT 
				fromC.CurrencyId
				,toC.CurrencyId			
				,[Rate]
				,[PriceLevelScheme]
				,[RateDate]
				,[RatePeriod]
				,[RatePeriodMultiplier]
				,[QuoteBasis]
				,[LoadDate]
				,[SourceSystemName]
				,[FileName]
				,[RelatesToDate]
			FROM 
				cw.Syn_SfpStaging_tbl_FXRate r  
			LEFT JOIN cfgCW.Currency fromC ON fromC.Code = r.FromCurrency   
			LEFT JOIN cfgCW.Currency toC ON toC.Code = r.ToCurrency

			OPEN cursorFXRateStg;
			FETCH NEXT FROM cursorFXRateStg INTO 
				@fromCurrency, @toCurrency, @rate,@priceLevelScheme,@rateDate, @ratePeriod, @ratePeriodMultiplier, @quoteBasis,
				@loadDate, @sourceSystemName, @fileName, @relatesToDate

    		WHILE @@FETCH_STATUS = 0
			BEGIN		          
				SET @version = 1;
				--SET @relatesRateDate = CAST(STUFF(STUFF(@relatesToDate, 5, 0, '-'), 8, 0, '-') AS DATE)
				---FOr GBP to GBP
				IF  EXISTS (SELECT 1 FROM [CW].[FXRate] WHERE FromCurrencyId=@fromCurrency AND ToCurrencyId=@toCurrency AND CONVERT(DATE, RateDate)=CONVERT(DATE, @rateDate)
				AND CONVERT(DATE, RelatesRateDate)=CONVERT(DATE, @pAsAtDate)) 
				BEGIN
					SELECT @version = MAX(Version) FROM [CW].[FXRate] WHERE FromCurrencyId=@fromCurrency AND ToCurrencyId=@toCurrency AND CONVERT(DATE, RateDate)=CONVERT(DATE, @rateDate)
                  
					DELETE FROM [CW].[FXRate] WHERE FromCurrencyId=@fromCurrency AND ToCurrencyId=@toCurrency AND CONVERT(DATE, RateDate)=CONVERT(DATE, @rateDate)

					SET @version = ISNULL(@version, 0) + 1
				END

				--Inserting data into CW.FXRate Table
				INSERT INTO CW.FXRate([FeedRunLogId],[FromCurrencyId],[ToCurrencyId],[Rate],[PriceLevelScheme],[RateDate],[RatePeriod],[RatePeriodMultiplier]
				,[QuoteBasis],[Version],[CreatedBy],[CreatedDate],[ModifiedBy],[ModifiedDate], [RelatesRateDate])
				VALUES(@pFeedRunLogId, @fromCurrency, @toCurrency, @rate, @priceLevelScheme,
				@rateDate, @ratePeriod, @ratePeriodMultiplier, @quoteBasis, @version, @createdBy, @createdDate, @createdBy, @createdDate, @pAsAtDate);

				--Fetch record again from cursor
				FETCH NEXT FROM cursorFXRateStg INTO @fromCurrency, @toCurrency, @rate,@priceLevelScheme,@rateDate, @ratePeriod, @ratePeriodMultiplier, @quoteBasis,
								@loadDate, @sourceSystemName, @fileName, @relatesToDate
			END
			CLOSE cursorFXRateStg;
			DEALLOCATE cursorFXRateStg;   

			UPDATE [CW].[FeedRunLog] SET FileName = @fileName WHERE FeedRunLogId = @pFeedRunLogId;    
    
			COMMIT TRANSACTION;   
		END        
		   
       
	END TRY    
	BEGIN CATCH    
    
        IF @@trancount > 0 ROLLBACK TRANSACTION;    
    
        DECLARE     
			@errorMessage     NVARCHAR(MAX),    
			@errorSeverity    INT,    
			@errorNumber      INT,    
			@errorLine        INT,    
			@errorState       INT;    
    
        SELECT     
         @errorMessage = ERROR_MESSAGE()
         ,@errorSeverity = ERROR_SEVERITY()
         ,@errorNumber = ERROR_NUMBER()
         ,@errorLine = ERROR_LINE()
         ,@errorState = ERROR_STATE()    
    
        EXEC [CW].[spUpdateFeedRunLog] @pFeedRunLogId, '', 'Failed', 0    
    
        EXEC app.SaveErrorLog 1, 1, 'cw.spLoadFXRateData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage    
        , 'System'    
      
        RAISERROR (@errorMessage,    
                   @errorSeverity,    
                   @errorState )    
	END CATCH    
END
GO


