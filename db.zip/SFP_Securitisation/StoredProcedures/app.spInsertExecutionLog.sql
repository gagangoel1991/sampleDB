USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spInsertExecutionLog]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [app].[spInsertExecutionLog]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spInsertExecutionLog]	
	@ObjectIdentityId INT,
	@StepName VARCHAR(100),
	@ObjectName VARCHAR(100) = NULL,
	@Remarks VARCHAR(500) = NULL
AS
BEGIN
	SET NOCOUNT ON
	
	INSERT app.ExecutionLog
			(SPId
			,ObjectName
			,ObjectIdentityId
			,Remarks
			,StepName
			,Timestamp
			,HostName
			,UserName
			)
	SELECT @@spid
		  ,@ObjectName
		  ,@ObjectIdentityId
		  ,@Remarks
		  ,@StepName
		  ,GETUTCDATE()
		  ,HOST_NAME()
		  ,USER_NAME()
END
GO
