USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetDealConditionTestData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealConditionTestData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 10-06-2021 
--Description: GET DealConditionTest Data 
--[cw].[spGetDealConditionTestData] 14,52,''
--==================================   
CREATE PROCEDURE [cw].[spGetDealConditionTestData] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   
   --  DECLARE @pDealId   INT=14,@pIPDRunId INT=4

	SELECT 
			ipd.DealIpdConditionTestId AS Id,
			dc.DisplayName AS Condition, 
		   IIF(ipd.ResultedStatus=1,'PASS','FAIL') AS [Status], 
	       ipd.Comment AS [Comment], ipd.LoanCount AS [Number],
	       ipd.LoanAmount AS [Amount],
		   dc.ConsequencesComment AS [Consequences],
	       ipd.RepurchaseAmount AS [RepurchaseAmount],
		   wfs.DisplayName AS DealStatus,
		   ipd.PreviousRepurchaseDate AS PreviousRepurchaseDate,
     ipd.ModifiedBy,
     ipd.ModifiedDate
			FROM cw.DealIpdConditionTest ipd
			JOIN cfgcw.DealCondition dc ON dc.DealConditionId = ipd.DealConditionId
			JOIN cw.dealipdrun dir ON ipd.DealIpdRunId = dir.runId
			LEFT JOIN	cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
	WHERE DealIpdRunId = @pIPDRunId 
	ORDER BY dc.SortOrder
	
  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetNonRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO
