USE [SFP_Securitisation]
GO

GO

IF OBJECT_ID('[cw].[spGetSelectLookupListFilterBased]') IS NOT NULL
	DROP PROCEDURE [cw].spGetSelectLookupListFilterBased
GO


/****** Object:  StoredProcedure [CW].[[spGetSelectLookupListFilterBased]]    Script Date: 17/02/2022 11:00:01 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:	14.04.2021
 * Description:  Stored proc to get lookup list based on filter ids.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 	Declare @listId  cw.udtSelectLookupList
 * 	Insert @listId (ListId) values (1)
 * 
 * 	Declare @FilterId  cw.udtSelectLookupList
 * 	Insert @FilterId (ListId) values (25)
 * 	Insert @FilterId (ListId) values (26)
 * 
 * 	exec cw.[spGetSelectLookupListFilterBased]  @listId, @FilterId
 * -------------------------------------------------------
*/    


CREATE PROCEDURE [CW].[spGetSelectLookupListFilterBased]
@ListId cw.udtSelectLookupList READONLY
, @FilterId cw.udtSelectLookupList READONLY
AS
BEGIN

  
 SELECT 1 AS ListId, D.DealId AS Value, D.DealName AS Text  
 INTO #List  
	 FROM app.vwActiveDeal D 
	 INNER JOIN @ListId S ON S.ListId=1  
	 WHERE DealTypeId IN ( SELECT ListId FROM @FilterId)
    
 SELECT ListId, Value, Text FROM #List ORDER BY ListId, Text      
 
 END

 Go