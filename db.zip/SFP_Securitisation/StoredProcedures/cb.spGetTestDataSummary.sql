USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spGetTestDataSummary]') IS NOT NULL
	DROP PROCEDURE [cb].spGetTestDataSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cb].[spGetTestDataSummary] 
(
	@pDealId INT
	, @pIPDRunId INT
	, @pUserName			VARCHAR(80) = NULL
)
/* 
 *   Author: Arun 
 *   Date:  21.02.2021 
 *   Description:  Get the test data summary
 *   
 *   Example - EXEC [cb].[spGetTestDataSummary]  6, 68,  'System'
 *   EXEC [cb].[spGetTestDataSummary]  6, 68,  'System'
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
*/ 
AS 
BEGIN 
	 BEGIN TRY 
						
		DECLARE @IpdDate DATETIME;

		SELECT @IpdDate = IpdDate
		FROM [cw].[vwDealIpdRun]
		WHERE DealIpdRunId = @pIPDRunId;

		-- Current and Previous 3 ipd run id 
		SELECT TOP 4 DealIpdRunId
			,IpdDate
		INTO #DealRunDetail
		FROM [cw].[vwDealIpdRun]
		WHERE IpdDate <= @IpdDate
			AND DealId = @pDealId
			AND IpdSequence > 131
		ORDER BY IpdDate DESC;

		SELECT P.ParentTestTypeId AS ParentTestLineItemId
			,P.TestTypeID AS TestLineItemId
			,'Summary' AS InternalName
			,P.DisplayName
			,IIF(P.ParentTestTypeId IS NOT NULL,C.InternalName, P.InternalName) AS InternalTestLineItem
			--,P.UITabName
			,IIF(P.UITabName IS NULL,C.UITabName, P.UITabName) AS UITabName
			--,C.UITabName C_UITabName
			,P.SortOrder
			INTO #TestSummaryData
		FROM cfgcb.TestType P
		LEFT JOIN cfgcb.TestType C ON P.ParentTestTypeId = C.TestTypeID;
		
		--Select * from #TestSummaryData

		SELECT 
			tt.ParentTestLineItemId,
			tt.TestLineItemId,
			tt.InternalName,
			tt.DisplayName,
			tt.InternalTestLineItem,
			tt.UITabName,
			ttr.Result AS LineItemValue,
			r.DealIpdRunId,		
			r.IpdDate			
		FROM 
			#DealRunDetail r
			CROSS JOIN  #TestSummaryData tt
			LEFT JOIN [cb].[DealIpdTestResult] ttr ON ttr.TestTypeId = tt.TestLineItemId AND r.DealIpdRunId = ttr.DealIpdRunId	
		ORDER BY tt.DisplayName, tt.SortOrder			

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.[spGetTestDataSummary]', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH   
END

GO
