USE [SFP_Securitisation]
GO

IF OBJECT_ID('cb.spUpdateManualFieldData') IS NOT NULL
	DROP PROCEDURE cb.spUpdateManualFieldData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
 *   Author: Saurabh Bhatia
 *   Date:  28-Jan-2022
 *   Description:  To Get CB Manual Values Data 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   -------------------------------------------------------    
  */
CREATE PROCEDURE cb.spUpdateManualFieldData  
	 @pManualFieldsKeyValue [cw].[udtKeyValueArray] READONLY,
	 @pManualFieldGroupTypeId	INT,
	 @pUserName VARCHAR(20)
AS
BEGIN
	BEGIN TRY


	UPDATE v
	SET v.[Value] = uv.[Value]
		,v.ModifiedBy = @pUserName
		,ModifiedDate = GETDATE()
	FROM cb.ManualFieldValue v
	JOIN cfgcb.ManualField mf ON mf.ManualFieldId = v.ManualFieldId
	JOIN cfgcb.ManualFieldGroup mfg ON mfg.ManualFieldGroupId = mf.ManualFieldGroupId
	JOIN cfgcb.ManualFieldGroupType mfgt ON mfgt.ManualFieldGroupTypeId = mfg.ManualFieldGroupTypeId
	JOIN @pManualFieldsKeyValue uv ON v.ManualFieldValueId = uv.[key]
	WHERE 
		mfgt.ManualFieldGroupTypeId = @pManualFieldGroupTypeId
		AND v.[Value] <> uv.[Value];

	IF @pManualFieldGroupTypeId = (SELECT TOP 1 ManualFieldGroupTypeId FROM cfgcb.ManualFieldGroupType WHERE InternalName = 'CashwaterfallField')
	BEGIN
		DECLARE @DealIpdRunId int =(SELECT DealIpdRunId FROM cb.vwManualfield
									WHERE ManualFieldValueId = (SELECT TOP 1 [key] FROM @pManualFieldsKeyValue))

		DECLARE @pResultCode INT			
		EXEC CW.spReCalculateIpd @DealIpdRunId, @pUserName,@pResultCode OUTPUT

		EXEC [cw].[spUpdateIpdSummaryLineItemStatus] @DealIpdRunId,'Manual_Field',@pUserName
	END

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spUpdateManualFieldData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


