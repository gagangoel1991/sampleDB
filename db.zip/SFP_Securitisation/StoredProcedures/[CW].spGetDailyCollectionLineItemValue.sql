USE [SFP_Securitisation]
GO


GO

IF OBJECT_ID('[cw].[spGetDailyCollectionLineItemValue]') IS NOT NULL
	DROP PROCEDURE [cw].spGetDailyCollectionLineItemValue
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [CW].spGetDailyCollectionLineItemValue    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	30.08.2022
 * Description:  Daily Collection  lineitem for multiples dates
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 

	Declare @dates  [cw].[utdDateList]
	Insert @dates ([dates]) values ('28-NOV-2022')
	--Insert @dates ([dates]) values ('30-MAY-2022')
	
	exec cw.spGetDailyCollectionLineItemValue @pCollectionDates = @dates, @pDealName='Deimos', @pDailyCollectionCategory='Deal Summary - Output',@pViewType='hover', @pUserName = 'kumavnb'
	exec cw.spGetDailyCollectionLineItemValue @pCollectionDates = @dates, @pDealName='Deimos', @pDailyCollectionCategory='Deal Summary - Output', @pUserName = 'kumavnb'
	exec cw.spGetDailyCollectionLineItemValue @pCollectionDates = @dates, @pDealName='Dunmore1', @pDailyCollectionCategory='Deal Summary - Adjustments', @pUserName = 'kumavnb'
	exec cw.spGetDailyCollectionLineItemValue @pCollectionDates = @dates, @pDealName='Dunmore1', @pDailyCollectionCategory='Deal Summary - ControlCheck', @pUserName = 'kumavnb'
	exec cw.spGetDailyCollectionLineItemValue @pCollectionDates = @dates, @pDealName='Dunmore1', @pDailyCollectionCategory='Deal Summary - ControlCheck', @pUserName = 'kumavnb'

 * -------------------------------------------------------
*/    
        
        
CREATE PROC [CW].[spGetDailyCollectionLineItemValue]
	@pCollectionDates [cw].[utdDateList] ReadOnly,
	@pDealName varchar(100),
	@pDailyCollectionCategory varchar(255) = Null,
	@pViewType varchar(20) = 'Default',
	@pUserName varchar(255) = NULL
AS        
BEGIN  
	
	BEGIN TRY  
		DECLARE
			@dailyCollectionSummaryId	INT,
			@dealId				INT,
			@dealRegionCode VARCHAR(10);  

			

	 		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  
	
			Select [cw].[fnGetBusinessDate] (dt.dates, @dealRegionCode, -1, 1)  as CollectionDate, @dealId as dealId, dcs.DailyCollectionSummaryId
			INTO #SummaryTable
			FROM @pCollectionDates dt
			INNER JOIN [CW].[DailyCollectionSummary]  dcs on dcs.CollectionDate = [cw].[fnGetBusinessDate] (dt.dates, @dealRegionCode, -1, 1) and dcs.dealId=@dealId


			Select [cw].[fnGetBusinessDate] (dt.dates, @dealRegionCode, -1, 1)  as CollectionDate, @dealId as dealId, Null as DailyCollectionSummaryId
			INTO #CollectionSummaryTable
			FROM @pCollectionDates dt
			
			Update CT
			SET CT.DailyCollectionSummaryId=ST.DailyCollectionSummaryId
			FROM #CollectionSummaryTable CT
			INNER JOIN #SummaryTable ST on CT.CollectionDate=ST.CollectionDate

			Select vdcli.DailyCollectionSummaryId, vdcli.CollectionDate, vdcli.DailyCollectionLineItemId, vdcli.LineItemInternalName, vdcli.Value 
			INTO #EstimatedValue
			from cw.vwDailyCollectionLineItemValue vdcli
			INNER JOIN #CollectionSummaryTable CST on CST.CollectionDate = vdcli.CollectionDate and CST.DailyCollectionSummaryId = vdcli.DailyCollectionSummaryId
			Where DailyCollectionCategory ='Deal Summary Estimation - Output'
			AND vdcli.dealId=@dealId
		
			Select CST.DealId, CST.CollectionDate, dcliv.DailyCollectionSummaryId, vdcli.DailyCollectionCategory
			, dcliv.DailyCollectionLineItemValueId
			, CASE WHEN wliParent.ParentDailyCollectionLineItemId IS NOT NULL THEN wliParent.ParentDailyCollectionLineItemId ELSE ISNULL(vdcli.ParentDailyCollectionLineItemId, 0) END AS ParentDailyCollectionLineItemId
			, CASE WHEN wliParent.ParentDailyCollectionLineItemId IS NOT NULL THEN 1 ELSE 0 END AS IsSubLineItems
			, vdcli.DailyCollectionLineItemId, vdcli.LineItem
			, CASE WHEN IsEstimationData =1 AND @pViewType ='Default' Then 
					
					CASE 
						WHEN vdcli.LineItemInternalName ='Net Principal Collections_1.000' Then 
							(Select CAST(SUM(CAST(EV.Value as DECIMAL(38,2))) as VARCHAR) From #EstimatedValue EV Where EV.DailyCollectionSummaryId=CST.DailyCollectionSummaryId and EV.LineItemInternalName IN ('Est_Net Principal Collections_1.000', 'Est_Net Principal Collections_UBR_1.100'))
						WHEN vdcli.LineItemInternalName ='Revenue Collections_2.000' Then 
							(Select CAST(SUM(CAST(EV.Value as DECIMAL(38,2))) as VARCHAR) From #EstimatedValue EV Where EV.DailyCollectionSummaryId=CST.DailyCollectionSummaryId and EV.LineItemInternalName IN ('Est_Revenue Collections_2.000', 'Est_Revenue Collections_UBR_2.100'))
						WHEN vdcli.LineItemInternalName ='Daily Cash Movement_3.000' Then 
							(Select CAST(SUM(CAST(EV.Value as DECIMAL(38,2))) as VARCHAR) From #EstimatedValue EV Where EV.DailyCollectionSummaryId=CST.DailyCollectionSummaryId and EV.LineItemInternalName IN ('Est_Daily Cash Movement_3.000', 'Est_Daily Cash Movement_UBR_3.100'))
						ELSE   
							dcliv.Value 
					END

			  Else dcliv.Value End as Value
			, dcliv.Comments, dcliv.ModifiedBy, dcliv.ModifiedDate
			From 
			#CollectionSummaryTable CST
			LEFT JOIN cw.vwDailyCollectionLineItems vdcli on CST.dealId= vdcli.dealId
			LEFT JOIN cw.vwDailyCollectionLineItemValue dcliv on dcliv.DailyCollectionLineItemId = vdcli.DailyCollectionLineItemId and CST.CollectionDate = dcliv.CollectionDate and CST.DailyCollectionSummaryId = dcliv.DailyCollectionSummaryId 
			LEFT JOIN (SELECT DISTINCT ParentDailyCollectionLineItemId, DealId FROM cw.vwDailyCollectionLineItems) AS wliParent ON  wliParent.ParentDailyCollectionLineItemId = vdcli.DailyCollectionLineItemId and wliparent.dealId = CST.dealId
			Where vdcli.DailyCollectionCategory = isNull(@pDailyCollectionCategory, vdcli.DailyCollectionCategory)
			and vdcli.dealId = @dealId
			Order By CST.CollectionDate desc, vdcli.Sortorder

			

	END TRY  
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionLineItemValue',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH   
	
END

GO
