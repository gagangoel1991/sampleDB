USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetNoteSummary]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetNoteSummary] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 17-05-2021 
--Description: GET NoteSummary Details 
--(PRE and Post)

--[cw].[spGetNoteSummary] 14,56,''
--==================================   
CREATE PROCEDURE [cw].[spGetNoteSummary] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
	BEGIN TRY   
		SELECT  
			dn.DealNoteId,CONVERT(VARCHAR(10),ipd.IpdDate,103) AS IPDDate,
			CASE dlv.[Value] WHEN 'FIXED' THEN 'N/A' ELSE CAST(pre.BaseRate AS VARCHAR(300)) END AS BaseRate ,
			pre.OpeningPoolFactor,
			dn.IsNote,
			pre.Coupon * 100.0 AS TotalRate,
			pre.DayCount AS DaysInInterestPeriod,pre.Principal_bf,			pre.TotalIntDue AS InterestDue,pre.Interest_bf AS UnpaidInterest_bf, pre.IntOnBfInt AS InterestOnUnpaidInterest_bf,
			post.InterestPaid, post.Interest_Cf AS UnpaidInterest_cf, post.PrincipalPaid ,post.Principal_Cf AS Principal_cf,post.ClosingPoolFactor
		FROM 
			cfgcw.DealNote dn
		JOIN 
			cw.NoteData_PreWF pre ON dn.DealNoteId=pre.DealNoteId
		JOIN 
			cw.dealipdrun dir ON  dir.RunId=pre.DealipdRunid 
		JOIN 
			cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN 
			cfgCW.DealLookupValue dlv ON dn.RateTypeId=dlv.LookupValueId 
		LEFT JOIN  
			cw.NoteData_postWF post ON  pre.DealipdRunid=post.DealipdRunid AND pre.DealNoteId = post.DealNoteId
		WHERE 
			dir.RunId IN(SELECT RunId FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId,4))
			ORDER BY ipd.IpdDate DESC
		    
	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'spGetNoteSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH  
END
GO