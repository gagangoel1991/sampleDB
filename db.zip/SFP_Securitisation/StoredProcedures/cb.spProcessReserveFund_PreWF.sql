USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessReserveFund_PreWF]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessReserveFund_PreWF]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessReserveFund_PreWF] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  08.02.2022
 *   Description:  Fill ReserveFund CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessReserveFund_PreWF] 36,'fm\shriyad'
 *    select * from [Cb].[ReserveFund_PreWf] where dealipdrunid=36           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=35, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @dealId  INT, 
				  @ipdDate DATE,
				  @reserveFund_bF decimal(38,16),
				  @twelveMonthsRollingFeesForCRpp decimal(38,16),
				  @sumOfEstimatedThreeMonthInterest_GBP decimal(38,16),
				  @sumOfEstimatedOneMonthInterest_GBP decimal(38,16),
				  @requiredAmount1 decimal(38,16),
				  @requiredAmount2 decimal(38,16),
				  @IPD_12months datetime

          SELECT @dealId = DealId, 
				@ipdDate = IpdDate
          FROM   cw.vwDealIpdRun dir
          WHERE  DealIpdRunId = @pDealIpdRunId 
		  
		   SET @IPD_12months=(SELECT DealDateValue 
                              FROM   cw.vwDealDate 
                              WHERE  DealIpdRunId=@pDealIpdRunId 
                                     AND DealDateKeyInternalName = 'IPD-12months')

		  DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

          IF Object_id('tempdb..#ReserveFund_PreWF') IS NOT NULL 
            DROP TABLE #ReserveFund_PreWF

          CREATE TABLE #ReserveFund_PreWF
            ( 
				[DealIpdRunId] [int] NULL,
				[CoveredBondFundId] [smallint] NULL,
				[ReserveFund_bF] [decimal](38, 16) NULL,
				[TwelveMonthsRollingFeesForAToCRPP] [decimal](38, 16) NULL,
				[RequiredAmount1] [decimal](38, 16) NULL,
				[RequiredAmount2] [decimal](38, 16) NULL,
				[FinalRequiredAmount] [decimal](38, 16) NULL,
				[DueAmount] [decimal](38, 16) NULL,
				[ResidualAmount] [decimal](38, 16) NULL,
				[ReleaseToARR] [decimal](38, 16) NULL
            ) 

				SELECT @reserveFund_bF = ReserveFund_cf
				FROM cb.ReserveFund_PostWF rf_postwf
					JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = rf_postwf.CoveredBondFundId
					AND  cbf.InternalName = 'ReserveFund'
				WHERE DealIpdRUnId = @dealPreviousIpdRunId

				SET @twelveMonthsRollingFeesForCRpp = (SELECT COALESCE(SUM(waterfallAmount),0) FROM cb.WaterfallLineItemCAmount 
														WHERE ipdDate>=@IPD_12months AND ipdDate<@ipdDate);

				SET @twelveMonthsRollingFeesForCRpp = (SELECT COALESCE(SUM(WaterfallLineItemTotalRequiredAmount),0)+@twelveMonthsRollingFeesForCRpp
														FROM [CW].[vwWaterfallLineItemAmount]
														WHERE WaterfallCategoryInternalName='RevenuePriorityofPayments'
															AND WaterfallLineItemRank=3
															AND DealIpdRunId IN (
																		SELECT max(DealIpdRunId) 
																		FROM cw.vwDealIpdRUn
																		WHERE ipddate>(SELECT max(ipddate) FROM cb.WaterfallLineItemCAmount) 
																		AND dealid=@dealId AND ipddate<@ipdDate AND ipdDate>=@IPD_12months GROUP BY ipddate))

																		
				
				SET @twelveMonthsRollingFeesForCRpp = (SELECT COALESCE(SUM(WaterfallLineItemTotalRequiredAmount),0)
																		+@twelveMonthsRollingFeesForCRpp
														FROM [CW].[vwWaterfallLineItemAmount]
														WHERE DealIpdRunId=@pDealIpdRunId
															AND WaterfallCategoryInternalName='RevenuePriorityofPayments'
															AND WaterfallLineItemRank=3)

				SELECT  @sumOfEstimatedThreeMonthInterest_GBP= SUM(EstimatedThreeMonthInterest_GBP)
						, @sumOfEstimatedOneMonthInterest_GBP= SUM(EstimatedOneMonthInterest_GBP)
				FROM Cb.DealNote_Wf 		
				WHERE DealIpdRunId = @pDealIpdRunId;

				SET @requiredAmount1 = (SELECT CONVERT(decimal(12,10),1.0)/4.0
										*(@twelveMonthsRollingFeesForCRpp + CONVERT(DECIMAL(38,16),Value))
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ExpectedThirdPartyExpenses')
										+ (SELECT 
										CONVERT(DECIMAL(38,16),Value)
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ReserveFundProvisionValue')
										+ @sumOfEstimatedThreeMonthInterest_GBP


				SET @requiredAmount2 = (SELECT 
										CONVERT(decimal(12,10),1.0)/12.0
										*(@twelveMonthsRollingFeesForCRpp + CONVERT(DECIMAL(38,16),Value))
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ExpectedThirdPartyExpenses')
										+ (SELECT 
										CONVERT(DECIMAL(38,16),Value)
										FROM [cfgCW].[CashWaterfallDealConfig] WHERE dealid=@dealId
										AND DealKey = 'ReserveFundProvisionValue')
										+ @sumOfEstimatedOneMonthInterest_GBP


                INSERT INTO #ReserveFund_PreWF 
                            (DealIpdRunId
							,CoveredBondFundId
							,ReserveFund_bF
							,TwelveMonthsRollingFeesForAToCRPP
							,RequiredAmount1
							,RequiredAmount2
							,FinalRequiredAmount
							,DueAmount
							,ResidualAmount
							,ReleaseToARR
							) 
                 SELECT @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,COALESCE(@reserveFund_bF,0) ReserveFund_bF
						,COALESCE(@twelveMonthsRollingFeesForCRpp,0) TwelveMonthsRollingFeesForAToCRPP
						,COALESCE(@requiredAmount1,0) RequiredAmount1
						,COALESCE(@requiredAmount2,0) RequiredAmount2
						,COALESCE(IIF(tr.IsBreached = 0, 0, (SELECT MAX(tempRequiredAmount) FROM 
																(VALUES (@requiredAmount1),(@requiredAmount2)) 
														AS AllRequiredAmounts(tempRequiredAmount))),0) FinalRequiredAmount
						,NULL DueAmount
						,NULL ResidualAmount 
						,NULL ReleaseToARR 
                FROM	cfgcb.CoveredBondFund cbf
						LEFT JOIN [cw].[vwDealIpdTriggerResult] tr ON cbf.ApplicableId = tr.TriggerId AND tr.DealIpdRunId = @pDealIpdRunId
                WHERE  cbf.InternalName = 'ReserveFund' 

                UPDATE #ReserveFund_PreWF 
                SET		DueAmount = IIF(FinalRequiredAmount - @reserveFund_bF > 0
										, FinalRequiredAmount - @reserveFund_bF
										, 0)
						,ResidualAmount = IIF(@reserveFund_bF - FinalRequiredAmount > 0
										, @reserveFund_bF - FinalRequiredAmount
										, 0)
				
				--WRONG NAME OF TRIGGER
				UPDATE #ReserveFund_PreWF 
                SET		ReleaseToARR = (SELECT IIF(IsBreached =0,  0, SUM(WaterfallLineItemTotalRequiredAmount))  
										FROM [CW].[vwDealIpdTriggerResult]  tr
										JOIN [CW].[vwWaterfallLineItemAmount] wlia ON  tr.DealIpdRunId = wlia.DealIpdRunId
										AND TriggerInternalName='IssuerEventofDefault' 
										AND tr.DealIpdRunId=@pDealIpdRunId
										AND WaterfallCategoryInternalName='RevenuePriorityofPayments'
										AND WaterfallLineItemRank=3
										GROUP BY IsBreached)


			--select * from #ReserveFund_PreWF

          DELETE FROM [Cb].[ReserveFund_PreWF] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[ReserveFund_PreWF] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,ReserveFund_bF
						,TwelveMonthsRollingFeesForAToCRPP
						,RequiredAmount1
						,RequiredAmount2
						,FinalRequiredAmount
						,DueAmount
						,ResidualAmount
						,ReleaseToARR
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
			SELECT  DealIpdRunId
						,CoveredBondFundId
						,ReserveFund_bF
						,TwelveMonthsRollingFeesForAToCRPP
						,RequiredAmount1
						,RequiredAmount2
						,FinalRequiredAmount
						,DueAmount
						,ResidualAmount
						,ReleaseToARR
						 ,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM   #ReserveFund_PreWF 

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessReserveFund_PreWF', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO