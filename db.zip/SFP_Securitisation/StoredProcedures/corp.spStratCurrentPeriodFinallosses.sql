USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratCurrentPeriodFinallosses]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratCurrentPeriodFinallosses]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

-----------------------------------------------------------------------------------------------  
  
  --Author: Mukesh Sharma
  --Date: 2023-01-27
  --Description:  Generating Strats for Current Period Final losses
  --exec  [corp].[spStratCurrentPeriodFinallosses] @pAsAtDate='2023-01-31',@pDealId=1,@pUserName=null
------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [corp].[spStratCurrentPeriodFinallosses]
(
	 @pAsAtDate DATE ,
	 @pDealId INT ,
	 @pUserName VARCHAR(100)=NULL
)
AS
BEGIN
            
            DECLARE 
			@Asatdate DATE
            ,@msgtxt VARCHAR(100) = ''
			,@DealIdS INT
			,@DealName Varchar(50)
		    ,@DealIdCommonSP INT
			,@PreviousQuarterDate Date
	        ,@CurrentQuarterMinDate Date


    BEGIN TRY
    SET @msgtxt = 'Calculating variables  ' + CONVERT(VARCHAR(20), getdate(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	SET @DealIdCommonSP                    = @pDealId
	SET @DealName                          =(SELECT DealName from[corp].[syn_SfpModelCorporate_vw_dimCorporateDeal]		
											 WHERE DealId=@pDealId  AND IsActive='Y')
	SET @DealIdS                           =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)
	SET @Asatdate						   = @pAsAtDate
	SET  @PreviousQuarterDate			   = (SELECT DATEADD(MONTH,-3,asatdate)FROM [sfp].[syn_SfpModel_vw_Calendar_v1] 
											  WHERE asatdate=@Asatdate AND Regioncode='UK')

	SET @PreviousQuarterDate			   =(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]  
											 WHERE IsWorkingDay=1 AND MONTH(asatdate)=MONTH(@PreviousQuarterDate) 
											 AND YEAR(asatdate)=YEAR(@PreviousQuarterDate) AND Regioncode='UK')
	SET @CurrentQuarterMinDate			   =(SELECT DATEADD(MONTH, DATEDIFF(MONTH,0,DATEADD(MONTH,1,@PreviousQuarterDate)),0))

   -- Storing aggregated data from loss managment into temp dataset
	SELECT CreditEventTypeId
	,COUNT(facilityid) AS [Loan Volume]
	,CONVERT(DECIMAL(23,2),SUM(CurrentExposure)) AS Exposure
	,CONVERT(DECIMAL(23,2),SUM(RealisedRecoveries)) AS [RealisedRecoveries]  
	,CONVERT(DECIMAL(23,2),SUM(FinalEstimatedRecoveries)) AS [FinalEstimatedRecoveries]  
	,CONVERT(DECIMAL(23,2),SUM(TotalAdjustedRecoveries)) AS [TotalAdjustedRecoveries] 
	,CONVERT(DECIMAL(23,2),SUM(InitialVerifiedLossAmount)) AS [InitialVerifiedLossAmount] 
	,SUM(TotalLossAmount) AS [TotalLossAmount] 
	,SUM(IIF (TotalLossAmount > InitialVerifiedLossAmount, TotalLossAmount - InitialVerifiedLossAmount, 0)) AS [TotalAdditionalClaims] 
	INTO #Templossdata 
	FROM [corp].[LossManagement]
	WHERE dealid=@DealIdS  AND CreditEventTypeId  NOT IN(3,4) 
	AND IsActive=1 AND (FinalVerificationDate BETWEEN @CurrentQuarterMinDate AND EOMONTH (@Asatdate))
	AND WorkflowStepId IN(95,98)
	GROUP BY CreditEventTypeId

	--- joining with report lookup table to show all CreditEventTypeId description as these are fixed in template

	SELECT * INTO #Result
	FROM
	(
	SELECT LK.Reportvalue AS [Credit event]
	,loss.[Loan Volume] AS [Loan Volume]
	,loss.[Exposure] AS Exposure
	,loss.[RealisedRecoveries]  AS [Realised Recoveries] 
	,loss.[FinalEstimatedRecoveries]  AS [Final Estimated Recoveries] 
	,[TotalAdjustedRecoveries] AS [Total Recoveries] 
	,loss.[InitialVerifiedLossAmount]  AS [Verified Loss Amount] 
	,CONVERT(DECIMAL(23,2), loss.[TotalLossAmount])  AS [Total Loss Amount] 
	,CONVERT(DECIMAL(23,2), loss.[TotalAdditionalClaims])  AS [Total Additional Claims]
	,CONVERT(DECIMAL(23,2), (loss.TotalLossAmount - loss.InitialVerifiedLossAmount - loss.TotalAdditionalClaims))  AS [Total Add Back Amount]
	,Lk.LookUpValue 
	FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  AS LK
	LEFT JOIN  #Templossdata AS Loss
	ON LK.LookUpvalue=Loss.CreditEventTypeId
	WHERE LK.ReportTemplateName='SFP+' and LK.LookUpName like 'CB Credit Event Type%'

	) AS RESULT


	 SELECT 
	 [Credit event]
	,[Loan Volume]
	,[Exposure]
	,[Realised Recoveries] 
	,[Final Estimated Recoveries] 
	,[Total Recoveries]
	,[Verified Loss Amount] 
	,[Total Loss Amount] 
	,[Total Additional Claims]
	,[Total Add Back Amount]
	 FROM #Result
	 WHERE LookUpValue NOT IN(3,4)
	 ORDER BY [Credit event]



         /* Droping and creating temp tables */
  	IF OBJECT_ID('tempdb..#Templossdata') IS NOT NULL DROP TABLE #Templossdata
	IF OBJECT_ID('tempdb..#Result') IS NOT NULL DROP TABLE #Result


	SET @msgtxt = 'End of strats generation : ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	 END TRY
     BEGIN CATCH                  
     DECLARE       
	 @errorMessage     NVARCHAR(MAX),      
	 @errorSeverity    INT,      
	 @errorNumber      INT,      
	 @errorLine        INT,      
     @errorState       INT;      
     SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()     
     EXEC app.SaveErrorLog 2, 1, 'spStratCurrentPeriodFinallosses', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName   
     RAISERROR (@errorMessage,  @errorSeverity,  @errorState )              
     END CATCH   

  END
GO


