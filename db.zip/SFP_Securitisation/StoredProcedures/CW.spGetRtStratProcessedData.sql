USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetRtStratProcessedData') IS NOT NULL
DROP PROC CW.spGetRtStratProcessedData
GO
/*
 * Author: Arun
 * Date:    25.11.2020
 * Description:  This will return strat config base data for Investor report and strat preview.
 * 
 * Usage : 
 * Declare @pStratRangeData as [cw].[udtStratRangeConfig]
 * Insert @pStratRangeData 
 * Select 1, Null, Null, 10, Null, Null, Null, 2
 * union all
 * Select 2, Null, 10, 20, Null, Null, 3, 2
 * 
 * Select SortOrder
 * 	, (CASE   WHEN FromValue is not null and ToValue is not null  THEN SC.Name+CONVERT(VARCHAR(20),CONVERT(INT,FromValue))+'-'+ST.Name+CONVERT(VARCHAR(20),CONVERT(INT,ToValue))    
 * 			  WHEN FromValue is null  THEN ST.Name+CONVERT(VARCHAR(20),CONVERT(INT,ToValue))    
 * 			  WHEN ToValue is null  THEN SC.Name+CONVERT(VARCHAR(20),CONVERT(INT,FromValue))    
 * 	  END)  as  DisplayName
 *     , FromValue, ToValue, SC.Name as FromOperator, ST.Name as ToOperator, SC.ConditionalOperatorId  , ST.ConditionalOperatorId 
 *     from @pStratRangeData C
 * 	LEFT join cfgCW.ConditionalOperator SC on SC.ConditionalOperatorId=C.FromOperatorId  
 * 	LEFT join cfgCW.ConditionalOperator ST on ST.ConditionalOperatorId=C.ToOperatorId
 * 	
 * CW.spGetRtStratProcessedData @pAsAtDate  ='30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pFieldId =20 --132 --177
 * 		,@pStratName ='Arrears Transitions'
 * 		,@pUserName = NULL     
 * 
 * Select * From cw.VwGetGroupNameByStratName		  where StratAttributeId =1                                           
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE Proc [CW].[spGetRtStratProcessedData] @pAsAtDate Date
		,@pDealName VARCHAR(255)
		,@pFieldId int = NULL
		,@pStratRangeData [cw].[udtStratRangeConfig] ReadOnly 
		,@pStratName varchar(255) = NULL
		,@pHeader bit = 0
		,@pUserName VARCHAR(50) = NULL    
		,@pReportTypeName VARCHAR(50) = ''
AS
BEGIN
	BEGIN TRY
		DECLARE @storedProcName varchar(255) = NULL
		,@selectedStratDataType varchar(15)
		,@rangeCount int=0
		,@stratRangeData [cw].[udtStratRangeConfig]  
		,@executeProc nvarchar(max)
		,@parameteres nvarchar(max)
		,@stratDataType varchar(15) ='TEXT'
		,@isDirectFieldStrat varchar(10)= 'N'
		,@fieldName varchar(100) = NULL
		,@miscStratType int = 3
		,@liabilityStratType int = 2
		,@pSearchCriteria varchar(255) = NULL
		,@isHTTReportStrat char(1)='N'
		,@skipHTTReportStrat char(1)='N'

		DECLARE @ReportLookupDbId INT 
		DECLARE @ReportTypeId INT;
		SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
		SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 
		
		--Misc Strats
		SELECT  @storedProcName = MappedProcedure, @selectedStratDataType = 'TEXT', @ReportLookupDbId = M.ReportLookupDbId
		, @isHTTReportStrat = CASE WHEN @pReportTypeName = 'HTT' THEN 'Y' ELSE 'N' END 
		FROM [cfgCW].[IR_Strat] I  
		INNER JOIN cfgCW.IR_MiscStrat M ON M.StratId=I.StratId  --AND I.ReportTypeId = M.ReportTypeId
		WHERE StratTypeId=@miscStratType AND I.Name=@pStratName  --AND I.ReportTypeId = @ReportTypeId

		

		IF @pStratName='Asset Coverage Test'
			SET @pSearchCriteria='AssetCoverageTest'
	
		----Liability Strats
		SELECT  @storedProcName = MappedProcedure, @selectedStratDataType = 'TEXT', @ReportLookupDbId = L.ReportLookupDbId
		FROM [cfgCW].[IR_Strat] I  
		INNER JOIN cfgCW.IR_LiabilityStrat L ON L.StratId=I.StratId --AND L.ReportTypeId = I.ReportTypeId
		WHERE StratTypeId=@liabilityStratType AND I.Name=@pStratName  --AND I.ReportTypeId = @ReportTypeId
	

		----BEspoke Strats 
		IF @storedProcName IS NULL  
		BEGIN
			SELECT @storedProcName = RelatedStoredProc, @selectedStratDataType = dt.Name
			FROM cfgCW.IR_BeSpokeStrat SA 
			INNER JOIN cw.vw_DealLookup dt ON dt.LookupValueId = SA.FieldDataTypeLookupId
			WHERE BespokeStratID=@pFieldId AND SA.IsActive=1 AND SA.Name=@pStratName
					--AND SA.ReportTypeId = @ReportTypeId

			SELECT @ReportLookupDbId = ReportLookupDbId FROM [cfgCW].[IR_AssetStrat] Asrt
			INNER JOIN cfgCW.IR_BeSpokeStrat SA ON Asrt.ReportTypeId = SA.ReportTypeId  AND Asrt.BespokeStratId = SA.BespokeStratId
			WHERE SA.BespokeStratID = @pFieldId AND SA.Name=@pStratName --AND Asrt.ReportTypeId = @ReportTypeId

		END

		

		IF @storedProcName IS NULL
		BEGIN
			SET @isDirectFieldStrat='Y'
			SELECT @fieldName = FieldName 
			FROM  cfgCW.IR_AssetField  p WHERE AssetFieldId=@pFieldId
		END

		
		IF(@pReportTypeName = 'Moodys' ) AND @isDirectFieldStrat='N' AND @pSearchCriteria IS NULL  
		BEGIN
				DECLARE @DBCode1 VARCHAR(20) = (SELECT LookupDbName FROM [cfgCW].[IR_ReportLookupDB] 
											WHERE ReportLookupDbId = @ReportLookupDbId) 
				
				IF(@DBCode1='securitisation')
				BEGIN
					SET @executeProc = 'Exec ' +  @storedProcName  + ' @AsAtDate , @DealName, @DealType'      
					SET @parameteres= N'@AsAtDate date, @DealName  varchar(100), @DealType  varchar(20)'      
				END
				ELSE 
				BEGIN
					SET @executeProc = 'Exec sfp.syn_SfpModel_sp_spGetProcessedData'  + ' @pQueryToExecute, @pAsAtDate , @pDealName, @pDealType'      
					SET @parameteres= N'@pQueryToExecute varchar(300), @pAsAtDate date, @pDealName varchar(100), @pDealType varchar(20)'      
		 
				END

				SET @skipHTTReportStrat='Y'
				 
		END
		ELSE IF @pSearchCriteria IS NOT NULL  
		BEGIN
			SET @executeProc = 'Exec ' +  @storedProcName  + ' @pAsAtDate , @pDealName, @pSearchCriteria'
			SET @parameteres= N'@pAsAtDate date, @pDealName varchar(100), @pSearchCriteria varchar(max)'
			SET @skipHTTReportStrat='Y'
		END
		ELSE IF @stratDataType=@selectedStratDataType
		BEGIN
			SET @executeProc = 'Exec ' +  @storedProcName  + ' @pAsAtDate , @pDealName'
			SET @parameteres= N'@pAsAtDate date, @pDealName varchar(100)'
		END
		ELSE
		BEGIN
			SET @executeProc = 'Exec ' +  @storedProcName  + ' @pAsAtDate , @pDealName, @pStratRangeData'
			SET @parameteres= N'@pAsAtDate date, @pDealName varchar(100), @pStratRangeData [cw].[udtStratRangeConfig] ReadOnly'
		END

		INSERT @stratRangeData 
		SELECT SortOrder
			, (CASE   WHEN FromValue IS NOT NULL AND ToValue IS NOT NULL  THEN SC.Name+CONVERT(VARCHAR(20),CONVERT(INT,FromValue))+'-'+ST.Name+CONVERT(VARCHAR(20),CONVERT(INT,ToValue))    
				  WHEN FromValue IS NULL  THEN ST.Name+CONVERT(VARCHAR(20),CONVERT(INT,ToValue))    
				  WHEN ToValue IS NULL  THEN SC.Name+CONVERT(VARCHAR(20),CONVERT(INT,FromValue))    
		  END)   AS  DisplayName
		, FromValue, ToValue, SC.Name AS FromOperator, ST.Name AS ToOperator, SC.ConditionalOperatorId AS FromOperatorId , ST.ConditionalOperatorId AS ToOperatorId
		FROM @pStratRangeData C
		LEFT JOIN cfgCW.ConditionalOperator SC ON SC.ConditionalOperatorId=C.FromOperatorId  
		LEFT JOIN cfgCW.ConditionalOperator ST ON ST.ConditionalOperatorId=C.ToOperatorId
	
		
		-------Condition Added for For IR-Excel Export
		SELECT @rangeCount  = count(*) FROM @stratRangeData	
		IF @rangeCount=0 
		BEGIN
			INSERT @stratRangeData 
			SELECT SortOrder, DisplayName,  minValue, maxValue, minOp, maxOp, FromOperatorId, ToOperatorId
			FROM CW.VwGetGroupNameByStratName WHERE FieldId=@pFieldId AND StratInternalName = isNull(@pStratName, StratInternalName)
		END   
   
		
		IF @isHTTReportStrat ='Y' AND @storedProcName='cb.spProcessHTTMortgageAssetStrats'
		BEGIN
			EXEC cb.spProcessHTTMortgageAssetStrats 
			@pAsAtDate =@pAsAtDate, 
			@pDealName =@pDealName,
			@pStratName= @pStratName,
			@pUserName	=@pUserName
		END
		ELSE IF(@pReportTypeName = 'Moodys') AND @isDirectFieldStrat='N'
		BEGIN   
				
				DECLARE @DBCode VARCHAR(20) = (SELECT LookupDbName FROM [cfgCW].[IR_ReportLookupDB] WHERE ReportLookupDbId = @ReportLookupDbId)  
				-- BELOW SP WILL CALL GIVEN PROCEDURE FROM RESPECTIVE DATABASE
				

				EXEC sfp.spGetReportProcessedData 
						@storedProcName = @storedProcName,
						@pAsAtDate = @pAsAtDate,
						@pDealName = @pDealName,
						@pReportTypeName = @pReportTypeName,
						@DBCode = @DBCode,
						@pUserName = @pUserName
		
		END
		ELSE IF @fieldName='CapitalBalanceAtFlagged'  
			EXEC CW.spGetMortgageOrigination @pAsAtDate  =@pAsAtDate
			,@pDealName  = @pDealName
			,@pStratRangeData = @stratRangeData 
			,@pUserName = NULL
		ELSE IF @pStratName = 'Deal Aggregated'
			EXEC CW.spDealaggreegatePostWFData @pAsAtDate  =@pAsAtDate
				,@pDealName  = @pDealName
				,@pUserName = NULL 
		ELSE IF @isDirectFieldStrat='Y'
		BEGIN
		
			EXEC CW.spGetStratDirectFieldData @pAsAtDate  =@pAsAtDate
				,@pDealName  = @pDealName
				,@pFieldName = @fieldName
				,@pStratRangeData=@stratRangeData
				,@pUserName = NULL 
			
			
		END
		ELSE IF @pSearchCriteria IS NOT NULL
		BEGIN
			EXEC sp_executesql @executeProc, @parameteres,  @pAsAtDate = @pAsAtDate , @pDealName = @pDealName, @pSearchCriteria = @pSearchCriteria 
		END
		ELSE IF @stratDataType=@selectedStratDataType
			EXEC sp_executesql @executeProc, @parameteres,  @pAsAtDate = @pAsAtDate , @pDealName = @pDealName 
		ELSE
			EXEC sp_executesql @executeProc, @parameteres,  @pAsAtDate = @pAsAtDate , @pDealName = @pDealName , @pStratRangeData=@stratRangeData			


		IF(@pHeader = 1 AND @pFieldId IS NOT NULL)
		BEGIN
			SELECT 
			Header,
			ColumnNo,
			ColumnSpan 
			FROM [cfgCW].[IR_Header] H
			JOIN [cfgCW].[IR_AssetStrat] A
			ON H.StratId = A.StratId  AND A.ReportTypeId = @ReportTypeId
			WHERE BespokeStratId = @pFieldId  
		END
		
		PRINT @storedProcName
	END TRY
	BEGIN CATCH
		DECLARE 
					@errorMessage     NVARCHAR(MAX),
					@errorSeverity    INT,
					@errorNumber      INT,
					@errorLine        INT,
					@errorState       INT;

		SELECT 
					@errorMessage = ERROR_MESSAGE()
					,@errorSeverity = ERROR_SEVERITY()
					,@errorNumber = ERROR_NUMBER()
					,@errorLine = ERROR_LINE()
					,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetRtStratProcessedData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
		RAISERROR (@errorMessage,
					@errorSeverity,
					@errorState )
	END CATCH
END

Go