USE [SFP_Securitisation]
GO

IF Object_Id('cw.spGetSelectLookupList') is Not Null 
	Drop PROCEDURE cw.spGetSelectLookupList
	
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
	
/*
	Drop PROCEDURE cw.spGetSelectedListItems
	Drop Type cw.udtSelectLookupList

	CREATE TYPE cw.udtSelectLookupList
	AS TABLE
	(
		ListId int
	);

	Declare @listId  cw.udtSelectLookupList
	Insert @listId (ListId) values (14)
	--Insert @listId (ListId) values (18)
	--Insert @listId (ListId) values (17)
	exec cw.spGetSelectLookupList  @listId

	
*/

CREATE PROCEDURE cw.spGetSelectLookupList
(
	@ListId cw.udtSelectLookupList READONLY,
	@pAssetClassId INT = 1
)
AS
BEGIN
 DECLARE @TmpPartitionid VARCHAR(10)
		,@MinFactDate VARCHAR(10)
		,@dealName VARCHAR(50)

	DECLARE @LookupTypeId_RiskRetentionMethod INT = (SELECT LookupTypeId FROM [cfgCW].[DealLookupType] WHERE TypeCode = 'RiskRetentionMethod')
	DECLARE @LookupTypeId_RiskRetentionHolder INT = (SELECT LookupTypeId FROM [cfgCW].[DealLookupType] WHERE TypeCode = 'RiskRetentionHolder')

 IF OBJECT_ID('tempdb..#tmpBusinessDate') IS NOT NULL
	DROP TABLE #tmpBusinessDate

CREATE TABLE #tmpBusinessDate (BusinessDate DATE, DspText VARCHAR(10))
IF EXISTS(SELECT 1 FROM @ListId WHERE ListId IN (15, 16, 20, 21))
BEGIN
	SELECT @TmpPartitionid = MIN(partitionid) FROM [corp].[syn_Corporate_tbl_dw.Fact_Facility] WHERE FactFacilityKey <> -1
	SELECT @MinFactDate = CONVERT(CHAR(10), CONVERT(datetime, @TmpPartitionid), 120)
	INSERT INTO #tmpBusinessDate
	EXEC PS.spGetBusinessDates @MinFactDate, 0
END


 Select 1 as ListId, D.DealId as Value, D.DealName as Text  
 INTO #List  
	 FROM app.vwActiveDeal D  
	 INNER JOIN @ListId S on S.ListId=1  
   
 UNION ALL  
   
 
 Select 2 as ListId, AssetFieldId as Value, FieldDescription as Text  
	From  cfgCW.IR_AssetField  p
	INNER JOIN @ListId S on S.ListId=2 
	WHERE AssetClassId = @pAssetClassId 
 UNION ALL  
   
 Select 3 as ListId, M.ConditionalOperatorId as Value, M.Name as Text  
	 FROM cfgCW.ConditionalOperator M  
	 INNER JOIN @ListId S on S.ListId=3  
	 Where M.Name in ( '>', '>=')
   
   
 UNION ALL  
 
 Select 4 as ListId, M.ConditionalOperatorId as Value, M.Name as Text  
	 FROM cfgCW.ConditionalOperator M  
	 INNER JOIN @ListId S on S.ListId=4 
	 Where M.Name in ( '<', '<=')
   
 UNION ALL  
   

 Select 5 as ListId, AssetFieldId as Value, Case when dt.Name ='Reference' OR dt.Name ='Bool' Then 'TEXT' Else  dt.Name End as Text 
	From  cfgCW.IR_AssetField  p
	 INNER JOIN cw.vw_DealLookup dt on dt.lookupValueId = p.FieldDataType and TypeCode='FieldDataType'
	 INNER JOIN @ListId S on S.ListId=5
 	
   
   UNION ALL      
     
 SELECT 6 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=6   WHERE dlt.LookupTypeId=10    
   UNION ALL      
 SELECT 7 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=7   WHERE dlt.LookupTypeId=11    
   UNION ALL      
 SELECT 8 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=8   WHERE dlt.LookupTypeId=1    
    UNION ALL      
 SELECT 9 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=9   WHERE dlt.LookupTypeId=7    
    UNION ALL      
 SELECT 10 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=10   WHERE dlt.LookupTypeId=8    
   UNION ALL      
 SELECT 11 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=11   WHERE dlt.LookupTypeId=8    
   UNION ALL      
 SELECT 12 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=12   WHERE dlt.LookupTypeId=8    
   UNION ALL      
 SELECT 13 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt     
   INNER JOIN     
  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN @ListId S on S.ListId=13   WHERE dlt.LookupTypeId=9   
  UNION ALL   
   SELECT 14 as ListId, c.CurrencyId AS LookupValueId,c.code as DisplayText FROM cfgcw.Currency c  
   INNER JOIN @ListId S on S.ListId=14 
 --  UNION ALL   
 -- SELECT 15 as ListId, dlv.DealId,dlv.CollectionBusinessEnd 
	--FROM cw.vwDealIpdDates dlv     
 --  INNER JOIN @ListId S on S.ListId=15
  
  -- List Id 15 Start : Deal Business End Date
	DECLARE
		@startDealId		INT = 1,
		@maxDealId			INT		

	SELECT @maxDealId= MAX(DealId) FROM app.vwActiveDeal -- WHERE DealId in (14,15)

	WHILE(@startDealId <= @maxDealId)
	BEGIN 
		IF EXISTS (SELECT DealName FROM corp.vwActiveDeal WHERE DealId =  @startDealId)
		BEGIN
			INSERT INTO #List
			SELECT 15 AS ListId, @startDealId, BusinessDate
			FROM  #tmpBusinessDate
			INNER JOIN @ListId S ON S.ListId=15
		END
		ELSE
		BEGIN
			INSERT INTO #List
			SELECT 15 AS ListId, di.DealId, dt.CollectionBusinessEnd 
				FROM cw.DealIPD di 
				JOIN cw.vwDealIpdDates dt ON dt.DealIpdId = di.DealIpdId   
				INNER JOIN @ListId S ON S.ListId=15
			WHERE di.IpdDate<=
			(
					SELECT Top 1  CASE WHEN wfs.StepName NOT IN ('Authorise') THEN dt1.PreviousIPD ELSE CAST(di1.Ipddate AS DATE) END 
						FROM cw.DealIpd di1 
						JOIN cw.vwDealIpdDates dt1 ON dt1.DealIpdId = di1.DealIpdId
						JOIN cw.DealIPDRun dir ON dir.DealIPDId = di1.DealIpdId AND dir.IsCurrentVersion =1 AND di1.IsCurrentIPD = 1
						JOIN cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
						JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
						WHERE wft.Name = 'Deal_IPD' AND di1.DealId = @startDealId
				) 
				AND di.IpdDate > = DateAdd(yy, -2 , getdate()) -- as only last 2 year data is available for asset strats.
				AND di.DealId = @startDealId
				Order by di.IpdDate desc
		END
		SET @startDealId = @startDealId +1

	END
  --List ID 15 END

  -- List Id 16 Start : Deal IPD
	SET @startDealId= 1;
	WHILE(@startDealId <= @maxDealId)
	BEGIN 
		IF EXISTS (SELECT DealName FROM corp.vwActiveDeal WHERE DealId =  @startDealId)
		BEGIN
			INSERT INTO #List
			SELECT 16 AS ListId, @startDealId, BusinessDate
			FROM  #tmpBusinessDate
			INNER JOIN @ListId S ON S.ListId=16
		END
		ELSE
		BEGIN
			INSERT INTO #List
			SELECT 16 AS ListId, di.DealId, dt.IPD 
				FROM cw.DealIPD di  
				JOIN cw.vwDealIpdDates dt ON dt.DealIpdId = di.DealIpdId   
				INNER JOIN @ListId S ON S.ListId=16 
			WHERE di.IpdDate<=
			(
					SELECT Top 1  CASE WHEN wfs.StepName NOT IN ('Authorise') THEN dt1.PreviousIPD ELSE CAST(di1.Ipddate AS DATE) END 
						FROM cw.DealIpd di1 
						JOIN cw.vwDealIpdDates dt1 ON dt1.DealIpdId = di1.DealIpdId
						JOIN cw.DealIPDRun dir ON dir.DealIPDId = di1.DealIpdId AND dir.IsCurrentVersion =1 AND di1.IsCurrentIPD = 1
						JOIN cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
						JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
						WHERE wft.Name = 'Deal_IPD' AND di1.DealId = @startDealId
				) 
				AND di.DealId = @startDealId
				Order by di.IpdDate desc
		END
			
		SET @startDealId = @startDealId +1

	END
 --List ID 16 END 

  --List Id 17 Start
   BEGIN 
		INSERT INTO #List
		SELECT 17 AS ListId, di.DealId, dt.IPD 
			FROM cw.DealIPD di  
			JOIN cw.vwDealIpdDates dt ON dt.DealIpdId = di.DealIpdId   
			INNER JOIN @ListId S ON S.ListId=17 
		 

	END

 --List Id 18 All Initated IPD dates
 INSERT INTO #List
 SELECT 18 AS ListId, di.DealId, dt.CollectionBusinessEnd 
		FROM cw.DealIPD di  
		JOIN cw.vwDealIpdDates dt ON dt.DealIpdId = di.DealIpdId  
		JOIN app.vwActiveDeal vad ON vad.DealId=di.DealId
		INNER JOIN @ListId S ON S.ListId=18
		where IpdDate <= (SELECT  di.IpdDate FROM  app.vwActiveDeal ad JOIN  cw.DealIPD di ON ad.DealId=di.DealId AND ad.DealName='DEIMOS' WHERE IsCurrentIPD=1) 
			AND vad.DealName='DEIMOS'
			AND IpdDate > = DateAdd(yy, -2 , getdate())
 
 
 INSERT INTO #List
 SELECT 19 AS ListId, 1 as Value, 'Monthly Deal Aggregation' Text From @ListId S where S.ListId=19
 union all
 SELECT 19 AS ListId, 2 as Value, 'Monthly Product Data Load' Text From @ListId S where S.ListId=19
			

 -- List Id 20 Business Dates for CB
 IF EXISTS(SELECT 1 FROM @ListId Where ListId=20 )
 BEGIN
	IF(@TmpPartitionid IS NOT NULL)
	BEGIN
		SELECT @MinFactDate = CONVERT(CHAR(10), CONVERT(datetime, @TmpPartitionid), 120)

		INSERT INTO #List 
		SELECT 20 AS ListId,0, BusinessDate from #tmpBusinessDate tmp 
		INNER JOIN @ListId S on S.ListId=20
	END

  END
	 --List Id 21 for ESMA Report  
 INSERT INTO #List  
 SELECT 21 AS ListId, di.DealId, dt.CollectionBusinessEnd   
  FROM cw.DealIPD di    
  JOIN cw.vwDealIpdDates dt ON dt.DealIpdId = di.DealIpdId    
  JOIN app.vwActiveDeal vad ON vad.DealId=di.DealId  
  INNER JOIN @ListId S ON S.ListId=21  
  WHERE  IpdDate <= (SELECT  MAX(di.IpdDate) FROM  app.vwActiveDeal ad JOIN  cw.DealIPD di ON ad.DealId=di.DealId   WHERE IsCurrentIPD=1)   
   AND IpdDate > = DateAdd(yy, -2 , getdate())  
    UNION ALL        
	SELECT 21 as ListId, deal.DealId, tmp.BusinessDate from #tmpBusinessDate tmp 
	INNER JOIN [cfg].[Deal] deal ON 1 = 1    
	INNER JOIN @ListId S on S.ListId = 21   WHERE deal.AssetClassId = 2
    
	--UNION ALL     
	INSERT INTO #List
	SELECT 22 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=22   WHERE dlt.LookupTypeId=8 
	--UNION ALL 
	INSERT INTO #List
	SELECT 23 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=23   WHERE dlt.LookupTypeId=8 
  
  

	--UNION ALL 
	INSERT INTO #List
	SELECT 24 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=24   WHERE dlt.LookupTypeId = @LookupTypeId_RiskRetentionMethod 
	--UNION ALL   
	INSERT INTO #List
	SELECT 25 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=25   WHERE dlt.LookupTypeId= @LookupTypeId_RiskRetentionHolder

 --List Id 26 for Email Type
 INSERT INTO #List    
 SELECT 26 AS ListId,et.EmailTypeId,et.DisplayName
 FROM cfg.EmailType et
 INNER JOIN @ListId S ON S.ListId=26  

 -- BUSINESS AREA - ASSET CLASS MAP
  INSERT INTO #List  
 SELECT  27 as ListId, dlv.LookupValueId , CONVERT(VARCHAR(10),ast.AssetClassId) AS AssetClassId  
  FROM [cfgCW].[DealLookupType] dlt         
  INNER JOIN [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId    
  INNER JOIN ps.AssetClass ast ON replace( replace(dlv.[Value],'Mortgage', 'Retail') , ' ','') = replace(ast.Class, ' ','')  
  INNER JOIN @ListId S on S.ListId=27   
  WHERE dlt.LookupTypeId=10 

-- List Id 28: Rona Calculated Based on Fields
  INSERT INTO #List  
  SELECT  28 as ListId, lmt.PoolLimitAnalysisFieldId , lmt.LimitAnalysisFieldName  
  FROM ps.PoolLimitAnalysisField lmt          
  INNER JOIN @ListId S on S.ListId=28   
  WHERE lmt.AssetClassId = 2 AND lmt.LimitAnalysisFieldName NOT LIKE '%,%'

-- List Id 29: Facility Sharing Allowed
	INSERT INTO #List
	SELECT 29 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=29   WHERE dlt.LookupTypeId=40

-- List Id 30: Historical Flagging Allowed
	INSERT INTO #List
	SELECT 30 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=30   WHERE dlt.LookupTypeId=41

-- List Id 31: Facility Allocation Percent Change Allowed
	INSERT INTO #List
	SELECT 31 as ListId, dlv.LookupValueId,dlv.DisplayText FROM [cfgCW].[DealLookupType] dlt       
	INNER JOIN  [cfgCW].[DealLookupValue] dlv ON dlt.LookupTypeId=dlv.LookupTypeId      
	INNER JOIN @ListId S on S.ListId=31   WHERE dlt.LookupTypeId=42

 Select ListId, Value, Text From #List Order by ListId, Text      
 
 END
 GO
 
