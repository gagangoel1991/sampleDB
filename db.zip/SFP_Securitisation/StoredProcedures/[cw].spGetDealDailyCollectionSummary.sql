USE SFP_Securitisation

GO

IF OBJECT_ID('[cw].[spGetDealDailyCollectionSummary]') IS NOT NULL
	DROP PROCEDURE [cw].spGetDealDailyCollectionSummary
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Arun  
Date:    26.08.2022  
Description:  Fetch the Deal Daily Collection data
Usage : cw.spGetDealDailyCollectionSummary @pAsAtDate= '2022-10-10'
Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  

CREATE PROC cw.spGetDealDailyCollectionSummary
@pAsAtDate DateTime,
@pUserName varchar(255) = null 
as
BEGIN
	SET NOCOUNT  ON
	BEGIN TRY	
		
		Declare @NetPrincipalCollections float, @RevenueReceipt as float, @DailyCashMovement as float
		Declare @LossAdjustment float, @TotalDeflaggedAmount as float
		Declare @pAdviceDate DateTime = @pAsAtDate
		Declare @pUserInputDate DateTime = @pAsAtDate

		Declare @SecuritisationName varchar(100)
		Declare @Alias varchar(20)
		Declare @DataSource varchar(50)
		Declare @dealName varchar(100)
		DECLARE @dealRegionCode VARCHAR(3)  
		Declare @dealId INT
		Declare @IsEstimationDataLoaded INT =0

		SET @DataSource ='GMS' 
		SET @dealName ='Deimos'
		SET @SecuritisationName ='Deimos Covered Bond Programme' 
		SET @Alias ='GTNW' 
		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @dealName  
		SET @pAsAtDate =  (SELECT [cw].[fnGetBusinessDate] (@pAdviceDate, @dealRegionCode, -1, 1))

		Select * INTO #DeimosDailyCollectionLineItemValue from cw.vwDailyCollectionLineItemValue  
		where CollectionDate=@pAsAtDate and dealName = @dealName

		SELECT @IsEstimationDataLoaded = IsNull(IsEstimationData,0) From  [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId 

		IF @IsEstimationDataLoaded=1 
		BEGIN
			SET @DataSource ='Cash Estimation' 
			SET @NetPrincipalCollections = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Est_Net Principal Collections_1.000' )), 0)
			SET @RevenueReceipt = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Est_Revenue Collections_2.000' )), 0)
			SET @DailyCashMovement = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Est_Daily Cash Movement_3.000' )), 0)
		END
		ELSE
		BEGIN
			SET @NetPrincipalCollections = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Net Principal Collections_1.000' )), 0)
			SET @RevenueReceipt = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Revenue Collections_2.000' )), 0)
			SET @DailyCashMovement = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Daily Cash Movement_3.000' )), 0)
		END
		SET @LossAdjustment = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Loss Adjustment_3.000' )), 0)
		SET @TotalDeflaggedAmount = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DeimosDailyCollectionLineItemValue where LineItemInternalName =  'Total Deflagged Amount_3.000' )), 0)

		
		Select @pAdviceDate as AdviceDate, @pAsAtDate as CollectionDate, @SecuritisationName as [ContextName], @Alias as [Originator]
		, IsNull(@NetPrincipalCollections,0) as [PrincipalReceipts], @RevenueReceipt as [RevenueReceipts], 0 as [OtherCollections], @NetPrincipalCollections + @RevenueReceipt as [TotalDailyCash]
		, @dealName as [DealName], @DailyCashMovement as [DailyCashMovement]
		,  CASE WHEN CAST(@DailyCashMovement as decimal(38,2))= CAST( (@NetPrincipalCollections + @RevenueReceipt)  as decimal(38,2)) THEN 'OK' ELSE 'ERROR' END as [Compare], @DataSource as [DataSource]
		, ( @DailyCashMovement + @TotalDeflaggedAmount) - (@NetPrincipalCollections + @RevenueReceipt) as [Difference], @LossAdjustment as [LossProcessedPreviousDay], @TotalDeflaggedAmount as [FlaggingDeflaggingAdjustment]
		, (( @DailyCashMovement + @TotalDeflaggedAmount) - (@NetPrincipalCollections + @RevenueReceipt)) + @LossAdjustment + @TotalDeflaggedAmount as [ResidualDifference]
		INTO #TBL

		DECLARE @earlyRedemptionDate DateTime; 
		SET @earlyRedemptionDate = (SELECT EarlyRedemptionDate FROM [cw].[vw_ActiveDeal] WHERE DealName = 'DUNMORE1')

		SET @SecuritisationName ='DUNMORE SECURITIES NO 1 (Nephin)' 
		SET @dealName ='Dunmore1'
		SET @Alias ='ULSTER' 
		SET @DataSource ='GMS' 

		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @dealName  
		SET @pAsAtDate =  (SELECT [cw].[fnGetBusinessDate] (@pAdviceDate, @dealRegionCode, -1, 1))

		Select * INTO #DunmoreDailyCollectionLineItemValue from cw.vwDailyCollectionLineItemValue  
		where CollectionDate=@pAsAtDate and dealName = @dealName

		SELECT @IsEstimationDataLoaded = IsNull(IsEstimationData,0) From  [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId 

		IF @IsEstimationDataLoaded=1 
		BEGIN
			SET @DataSource ='Cash Estimation' 
			SET @NetPrincipalCollections = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName in (   'Est_Net Principal Collections_1.000', 'Est_Net Principal Collections_UBR_1.100') )),0)
			SET @RevenueReceipt = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName in (   'Est_Revenue Collections_2.000', 'Est_Revenue Collections_UBR_2.100') )), 0)
			SET @DailyCashMovement = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName in (  'Est_Daily Cash Movement_3.000', 'Est_Daily Cash Movement_UBR_3.100') )), 0)
		END
		ELSE
		BEGIN
			SET @NetPrincipalCollections = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName =  'Net Principal Collections_1.000' )),0)
			SET @RevenueReceipt = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName =  'Revenue Collections_2.000' )), 0)
			SET @DailyCashMovement = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName =  'Daily Cash Movement_3.000' )), 0)
		END

		SET @LossAdjustment = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName =  'Loss Adjustment_3.000' )), 0)
		SET @TotalDeflaggedAmount = ISNULL(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) ) FROM #DunmoreDailyCollectionLineItemValue where LineItemInternalName =  'Total Deflagged Amount_5.000' )), 0)


		IF @pUserInputDate <= @earlyRedemptionDate 
		BEGIN
		INSERT INTO #TBL
		Select @pAdviceDate as AdviceDate, @pAsAtDate as CollectionDate, @SecuritisationName as [ContextName], @Alias as [Originator]
		, IsNull(@NetPrincipalCollections,0) as [PrincipalReceipts], @RevenueReceipt as [RevenueReceipts], 0 as [OtherCollections], @NetPrincipalCollections + @RevenueReceipt as [TotalDailyCash]
		, @dealName as [DealName], @DailyCashMovement + @TotalDeflaggedAmount as [DailyCashMovement]
		, CASE WHEN CAST(@DailyCashMovement as decimal(38,2))= CAST( (@NetPrincipalCollections + @RevenueReceipt)  as decimal(38,2)) THEN 'OK' ELSE 'ERROR' END as [Compare], @DataSource as [DataSource]
		,  ( @DailyCashMovement + @TotalDeflaggedAmount) - (@NetPrincipalCollections + @RevenueReceipt) as [Difference], @LossAdjustment as [LossProcessedPreviousDay], @TotalDeflaggedAmount as [FlaggingDeflaggingAdjustment]
		, (( @DailyCashMovement + @TotalDeflaggedAmount) - (@NetPrincipalCollections + @RevenueReceipt)) + @LossAdjustment + @TotalDeflaggedAmount as [ResidualDifference]
		END

		SELECT * FROM #TBL

	END TRY  
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDealDailyCollectionSummary',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH  

END

GO
