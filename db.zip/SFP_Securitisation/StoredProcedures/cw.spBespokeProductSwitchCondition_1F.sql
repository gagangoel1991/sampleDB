USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spBespokeProductSwitchCondition_1F') IS NOT NULL
	DROP PROCEDURE cw.spBespokeProductSwitchCondition_1F
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spBespokeProductSwitchCondition_1F ( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  09.08.2020 
 *   Description: 
 *   
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *    Declare @oValue bit
 *   exec cw.spBespokeProductSwitchCondition_1F	32,'fm\shriyad', @oValue
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20),
  @oValue BIT OUTPUT
)
AS 
BEGIN 
	 DECLARE @dealId  INT, @CollectionBusinessEndDate   datetime

	SELECT @dealId = DealId FROM  cw.vwDealIpdRun WHERE  DealIpdRunId = @pDealIpdRunId 

	SET @CollectionBusinessEndDate=(SELECT DealDateValue 
								  FROM   cw.vwDealDate 
								  WHERE  DealIpdRunId=@pDealIpdRunId 
										 AND DealDateKeyInternalName = 'CollectionBusinessEnd') 

										 PRINT @CollectionBusinessEndDate

		SELECT
		 @oValue = CASE WHEN SUM(LOANCOUNT)!=0 THEN 0 ELSE 1 END
		FROM
		[cw].[DealProductSwitchData] psd
		JOIN  [cfgCW].[ProductSwitchType] pst ON psd.ProductSwitchTypeId = pst.ProductSwitchTypeId AND pst.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductType] pt1 ON pst.ProductTypeId1 = pt1.ProductTypeId AND pt1.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductType] pt2 ON pst.ProductTypeId2 = pt2.ProductTypeId AND pt2.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductRateOfInterestType] prit1 ON pst.ProductRateOfInterestTypeId1 = prit1.ProductRateOfInterestTypeId AND prit1.IsActive = 1
		LEFT JOIN  [cfgCW].[ProductRateOfInterestType] prit2 ON pst.ProductRateOfInterestTypeId2 = prit2.ProductRateOfInterestTypeId AND prit2.IsActive = 1
		WHERE
		dealid=@dealId
		AND CorrelatedDate =@CollectionBusinessEndDate
		AND pt2.Name NOT IN ('FIXED','SVR','DISCOUNT','LIFETIMEFIXED') AND pt1.Name NOT IN ('FIXED','SVR','DISCOUNT','LIFETIMEFIXED') -- LoanCount
		--and pst.Name IN ('SVR-FIXED','DISCOUNT-FIXED') -- QuarterlyCapitalBalanceValue
		--and pst.Name IN ('FIXEDHIGH-FIXEDLOW') -- QuarterlyCapitalBalanceValue

		SELECT @oValue
END

GO