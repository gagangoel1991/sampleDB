USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculateCWOverrideSql') IS NOT NULL
	DROP PROCEDURE cw.spCalculateCWOverrideSql
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculateCWOverrideSql
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  28.06.2020 
 *   Description:  Calculate override sql of waterfallLinetItem 
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *    
 *   exec cw.spCalculateCWOverrideSql 32,'fm\shriyad'
 *   select * from cw.waterfallLineItemAmount where dealipdrunid = 12 and waterfallLineItemid=90
 *   select * from cw.waterfallLineItemAmount where dealipdrunid = 12 and waterfallLineItemid=101
 *              
  */ 
  @pDealIpdRunId INT,
  @pUserName	VARCHAR(80)
)
AS
BEGIN
		--DECLARE @pDealIpdRunId INT = 6;			
		
		BEGIN TRY		

		DECLARE @DealId smallInt,
		@tempId INT,
		@dynsql nvarchar(500)  ,
		@params nvarchar(500), 
		@returnValue AS DECIMAL(38,16),
		@spName VARCHAR(MAX)

		SET @DealId  = (SELECT DealId FROM cw.vwdealipdrun WHERE DealIpdRunId = @pDealIpdRunId);

		IF OBJECT_ID('tempdb..#temp') IS NOT NULL DROP TABLE #temp

		SELECT WaterfallLineItemId, overrideSQL,AdjustedAmountOverrideSQL,
		CONVERT(DECIMAL(38,16),NULL) AS RequiredAmount ,  CONVERT(DECIMAL(38,16),NULL) AS AdjustedAmount 
		INTO #temp 
		FROM 
		cfgcw.waterfallLineitem wli 
		JOIN cfgcw.WaterfallCategory wc ON wli.WaterfallCategoryId = wc.WaterfallCategoryId
		AND wc.DealId = @Dealid
		AND (overrideSQL IS NOT NULL OR AdjustedAmountOverrideSQL IS NOT NULL)

		SET @tempId = (SELECT TOP 1 WaterfallLineItemId FROM #temp ORDER BY WaterfallLineItemId ASC);
		SET @spName = (SELECT overrideSQL FROM #temp WHERE WaterfallLineItemId =  @tempId);

		SET @params='@RunId int,@pUserName	VARCHAR(80), @ret_value DECIMAL(38,16) OUTPUT'

		WHILE(@tempId IS NOT NULL)
		BEGIN
			IF(@spName IS NOT NULL)
			BEGIN
				SET @dynsql='exec '+@spName+' @RunId,@pUserName, @ret_value OUTPUT'
				
				EXEC sp_executesql @dynsql, @params, @RunId=@pDealIpdRunId, @pUserName = @pUserName, @ret_value=@returnValue OUTPUT
				
				UPDATE #temp
				SET RequiredAmount = @returnValue
				WHERE WaterfallLineItemId = @tempId;
			END

			--Adjusted Amount
			SET @spName = (SELECT AdjustedAmountOverrideSQL FROM #temp WHERE WaterfallLineItemId =  @tempId);
			IF(@spName IS NOT NULL)
			BEGIN
				SET @dynsql='exec '+@spName+' @RunId,@pUserName, @ret_value OUTPUT'
				
				EXEC sp_executesql @dynsql, @params, @RunId=@pDealIpdRunId, @UserName = @pUserName, @ret_value=@returnValue OUTPUT
				
				UPDATE #temp
				SET AdjustedAmount = @returnValue
				WHERE WaterfallLineItemId = @tempId;
			END

			SET @tempId  = (SELECT TOP 1 WaterfallLineItemId FROM #temp WHERE WaterfallLineItemId> @tempId ORDER BY WaterfallLineItemId ASC);
			SET @spName = (SELECT overrideSQL FROM #temp WHERE WaterfallLineItemId =  @tempId);

		END

		
		UPDATE wlia
		SET RequiredAmount = temp.RequiredAmount
		, AdjustedAmount = temp.AdjustedAmount
		FROM cw.WaterfallLineItemAmount wlia JOIN #temp temp ON wlia.WaterfallLineItemId = temp. WaterfallLineItemId
		AND wlia.DealIpdRunId = @pDealIpdRunId
		

		DECLARE @WaterfallCategoryId int = 
		(SELECT TOP 1 WaterfallCategoryId FROM cfgcw.WaterfallCategory WHERE DealId = @DealId ORDER BY WaterfallCategoryId ASC)

		WHILE(@WaterfallCategoryId IS NOT NULL)
		BEGIN
			UPDATE wlia
			SET WaterfallLineItemRequiredAmount = (
							SELECT 
								sum(CASE 
										WHEN WaterfallLineItemOperatorInTotal='ADD' THEN WaterfallLineItemRequiredAmount
										WHEN WaterfallLineItemOperatorInTotal='LESS' THEN -WaterfallLineItemRequiredAmount
										WHEN WaterfallLineItemOperatorInTotal='MULTIPLY' THEN 1*WaterfallLineItemRequiredAmount
									END )
							FROM cw.vwWaterfallLineItemAmount wlia  
							JOIN cw.vwDealIpdRun dir ON wlia.DealIpdRunId = dir.DealIpdRunId
									AND WaterfallLineItemOperatorInTotal IS NOT NULL
									AND WaterfallCategoryID  = @WaterfallCategoryId
							WHERE dir.DealIpdRunId = @pDealIpdRunId)
			FROM cw.vwWaterfallLineItemAmount wlia  
			JOIN cw.vwDealIpdRun dir ON wlia.DealIpdRunId = dir.DealIpdRunId
					AND WaterfallLineItemOperatorInTotal IS NULL
					AND WaterfallCategoryID  = @WaterfallCategoryId
			WHERE dir.DealIpdRunId = @pDealIpdRunId

	
				SET @WaterfallCategoryId = 
				(SELECT TOP 1 WaterfallCategoryId 
				FROM cfgcw.WaterfallCategory 
				WHERE DealId = @DealId AND WaterfallCategoryId> @WaterfallCategoryId ORDER BY WaterfallCategoryId ASC)

		END



		UPDATE pwla
		SET TotalRequiredAmount=COALESCE(AdjustedAmount,0)+COALESCE(RequiredAmount,0)
		--, ModifiedDate = GETDATE()
		--, ModifiedBy = @pUserName
		FROM cw.WaterfallLineItemAmount pwla JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId=pwla.DealIpdRunId AND dir.DealIpdRunId=@pDealIpdRunId

		 

		END TRY
		BEGIN CATCH
			DECLARE 
				@errorMessage     NVARCHAR(MAX),
				@errorSeverity    INT,
				@errorNumber      INT,
				@errorLine        INT,
				@errorState       INT;

			SELECT 
				@errorMessage = ERROR_MESSAGE()
				,@errorSeverity = ERROR_SEVERITY()
				,@errorNumber = ERROR_NUMBER()
				,@errorLine = ERROR_LINE()
				,@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'spCalculateCWOverrideSql', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
			RAISERROR (@errorMessage,
				 @errorSeverity,
				 @errorState )

			
		END CATCH


	END



	GO