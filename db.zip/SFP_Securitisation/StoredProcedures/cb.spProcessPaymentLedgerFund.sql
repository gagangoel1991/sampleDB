USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cb].[spProcessPaymentLedgerFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessPaymentLedgerFund]
GO

/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 11/17/2022 10:05:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessPaymentLedgerFund] 
( 
  /* 
 *   Author: Arun 
 *   Date:  24.11.2022
 *   Description:  Fill Principal ledger Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessPaymentLedgerFund] 33,'fm\shriyad'
 *    select * from [Cb].[SwapCollateralFund] where dealipdrunid=33           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
        

			DECLARE @dealId  INT, 
			@calendarStartDt			DATE,
			@calendarEndDt			DATE,
			@coveredBondFundId INT,
			@ipdDate DATE, @prevIpdDate DATE, 
			@PaymentLedgerFund_bF decimal(38,16),
			@CreditofARR  decimal(38,16),
			@CreditofAPR  decimal(38,16),
			@CreditofMoniesDepositAccount decimal(38,16),
			@PaymentDuePreAccelerationRPP decimal(38,16),
			@PaymentDuePreAccelerationPPP decimal(38,16),
			@PaymentDueGuranteePPP decimal(38,16),
			@PaymentDueMoniesDistributionRepaid decimal(38,16),
			@PaymentLedgerFund_cf  decimal(38, 16)


			SELECT 	@dealId = d.DealId, @ipdDate = Ipd
			, @calendarStartDt = CAST(d.CollectionCalendarStart AS DATE) 
			, @calendarEndDt= CAST(d.CollectionCalendarEnd AS DATE) 			
			FROM cw.vwDealIpdDates d
			JOIN cw.vwDealIpdRun r			
			ON CAST(d.IPD AS DATE) = r.IpdDate
				AND d.DealIpdId =r.DealIpdId
			Where DealIpdRunId=@pDealIpdRunId

		  
			DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

			SELECT @prevIpdDate = IpdDate FROM cw.vwDealIpdRun dir WHERE  DealIpdRunId = @dealPreviousIpdRunId 

			Select @coveredBondFundId = CoveredBondFundId FROM	cfgcb.CoveredBondFund cbf
                WHERE  cbf.InternalName = 'PaymentLedgerFund' 

			SELECT @PaymentLedgerFund_bF = PaymentLedgerFund_cf
			FROM cb.[PaymentLedgerFund] scf
			JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
			AND  cbf.InternalName = 'PaymentLedgerFund'
			WHERE DealIpdRUnId = @dealPreviousIpdRunId

		
			Select @CreditofARR = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='PreAvailableRevenueReceipts_10.000'
			and DealIpdRunId=@pDealIpdRunId

			Select @CreditofAPR = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='PreAvailablePrincipalReceipts_8.000'
			and DealIpdRunId=@pDealIpdRunId

			SET @CreditofMoniesDepositAccount =	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='CreditMoniesDepsit'
									AND ManualFieldGroupInternalName = 'PaymentLedger'
									AND DealIpdRunId = @pDealIpdRunId);
			
			Select @PaymentDuePreAccelerationRPP = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallCategoryInternalName ='RevenuePriorityofPayments'
			and DealIpdRunId=@pDealIpdRunId

			Select @PaymentDuePreAccelerationPPP = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallCategoryInternalName ='PrincipalPriorityofPayments'
			and DealIpdRunId=@pDealIpdRunId

			
			SET @PaymentDueGuranteePPP=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='PaymentGuaranteePriority'
									AND ManualFieldGroupInternalName = 'PaymentLedger'
									AND DealIpdRunId = @pDealIpdRunId);
			
			SET @PaymentDueMoniesDistributionRepaid=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='PayDistributionMonies'
									AND ManualFieldGroupInternalName = 'PaymentLedger'
									AND DealIpdRunId = @pDealIpdRunId);

			
			SET @PaymentLedgerFund_cf = IsNull(@PaymentLedgerFund_bF,0) + @CreditofARR + @CreditofAPR + @CreditofMoniesDepositAccount
			- ( @PaymentDuePreAccelerationRPP + @PaymentDuePreAccelerationPPP + @PaymentDueGuranteePPP + @PaymentDueMoniesDistributionRepaid)

			DELETE FROM cb.[PaymentLedgerFund] WHERE DealIpdRunId = @pDealIpdRunId 

			INSERT INTO cb.[PaymentLedgerFund] 
						  ( DealIpdRunId,
							CoveredBondFundId,
							PaymentLedgerFund_bF,
							CreditofARR,
							CreditofAPR,
							CreditofMoniesDepositAccount,
							PaymentDuePreAccelerationRPP,
							PaymentDuePreAccelerationPPP,
							PaymentDueGuranteePPP,
							PaymentDueMoniesDistributionRepaid,
							PaymentLedgerFund_cf,
							IsActive,
							CreatedBy,
							CreatedDate,
							ModifiedBy,
							ModifiedDate) 
			SELECT @pDealIpdRunId
							,@coveredBondFundId
							,@PaymentLedgerFund_bF
							,@CreditofARR
							,@CreditofAPR
							,@CreditofMoniesDepositAccount
							,@PaymentDuePreAccelerationRPP
							,@PaymentDuePreAccelerationPPP
							,@PaymentDueGuranteePPP
							,@PaymentDueMoniesDistributionRepaid
							,@PaymentLedgerFund_cf
							 ,1, 
							 @pUserName, 
							 Getdate(), 
							 @pUserName ,
							 Getdate()

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessPaymentLedgerFund', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END