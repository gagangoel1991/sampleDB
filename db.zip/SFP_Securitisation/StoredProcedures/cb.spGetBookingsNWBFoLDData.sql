USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingsNWBFoLDData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingsNWBFoLDData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 06-Feb-2023 
--Description: GET Booking NWB FO Fees Data 
--[cb].[spGetBookingsNWBFoLDData] 6,71,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingsNWBFoLDData] 
   @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  

	Declare @NextIpd	DATE

BEGIN TRY  

	SELECT 	@NextIpd = d.NextIPD
			FROM cw.vwDealIpdDates d
			JOIN cw.vwDealIpdRun r			
			ON CAST(d.IPD AS DATE) = r.IpdDate
				AND d.DealIpdId =r.DealIpdId
			Where DealIpdRunId=@pIPDRunId

    SELECT
		   bv.AccountTypeLookupName AS TradeType,
		   bv.BookName  AS Book,
		   Replace(bv.CounterpartyName,'NATWEST BK TREASURY STM C7T','NatWest Bk Treasury STM C7T') AS Counterparty,
		   CONVERT(VARCHAR(30), dir.IpdDate,103) AS ValueDate,
		   dir.IpdDate,
		   CONVERT(VARCHAR(30), @NextIpd,103) as MaturityDate,
		   ABS(CAST(bv.[Value] AS DECIMAL(38, 2))) as PrincipalAmount,
		   'Index' AS RateType,
		   'LIBOR' AS [Index],
		   '1m' AS IndexRateTenor,
		   '0' AS Margin,
		   '' AS AllinRate,
		   bv.Currency,
		   '' AS Interest,
		   'Act/365 Fixed' AS DayCountConvention,
		   bv.LineItem AS [Description],
		   'FALSE' AS FlipIndicator,
		   '' AS FlipCounterparty,
		   '' AS FlipBook,
		   'FALSE' AS GTCollection
	FROM 
	 	    [cb].[vwBookingLineItems] bg
			LEFT JOIN [cb].[vwBookingLineItemValue] bv ON bg.BookingLineItemId =bv.BookingLineItemId
			LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
	WHERE 
			bg.BookingGroupInternalName  IN ('NW_Collections_Account-(4607236 - LDNAWELO-GBP)')
			AND bg.Dealname='Deimos' 
			AND bv.DealIpdRunId = @pIPDRunId AND bg.DealId = @pDealId
			AND bv.LineItemInternalName in ('New_NT9_Funding_Trade_NCA1_32')
  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetBookingsNWBFoLDData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END

GO

