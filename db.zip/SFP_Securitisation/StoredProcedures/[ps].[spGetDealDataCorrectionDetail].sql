USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetDealDataCorrectionDetail]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetDealDataCorrectionDetail]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================  
--Author: Sakthivel Loganathan 
--Date: 03-05-2022
--Description: Get details of deal data correction main 
--EXEC [ps].[spGetDealDataCorrectionDetail]  '2022-01-31',1,2,'LOGASLL'
--==================================   
CREATE PROCEDURE [ps].[spGetDealDataCorrectionDetail]    
(    
	@pDate DATE,
	@pDealId INT, 
	@pEntityId INT,
	@pUserName VARCHAR(50)  
)    
As     
BEGIN    
BEGIN TRY    
 Declare @DraftStatus VARCHAR(20) = 'Draft'  
 Declare @RejectStatus VARCHAR(20) = 'Rejected'  
 Declare @RecallStatus VARCHAR(20) = 'Recalled'  
 Declare @SubmitStatus VARCHAR(20) = 'Submitted'  
  
 SELECT ddc.DealDataCorrectionId As Id, 
  ddc.DataCorrectionStatus as [StatusId],  
  CASE WHEN ddcStatus.[Status] = @SubmitStatus THEN 'Pending Authorisation'  
  ELSE IIF(ddcStatus.[Status]= @DraftStatus OR ddcStatus.[Status]= @RecallStatus,   
     @DraftStatus, ddcStatus.[Status]) END AS Status,  
  ddc.CreatedBy,  
  ddc.AuthorizedBy,  
  ddc.AuthorizedDate
 FROM [corp].[DealDataCorrection] ddc
 INNER JOIN [corp].[DealDataCorrectionStatus] ddcStatus ON ddcStatus.DealDataCorrectionStatusId  = ddc.DataCorrectionStatus  
 WHERE ddc.AsAtDate = @pDate AND ddc.DealId = @pDealId AND ddc.EntityTypeId = @pEntityId 
END TRY  
BEGIN CATCH    
  DECLARE     
   @errorMessage     NVARCHAR(MAX),    
   @errorSeverity    INT,    
   @errorNumber      INT,    
   @errorLine        INT,    
   @errorState       INT;    
  SELECT     
   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()    
    
  EXEC app.SaveErrorLog 2, 1, 'spGetDealDataCorrectionDetail', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''    
      
  RAISERROR (@errorMessage,    
             @errorSeverity,    
             @errorState )    
 END CATCH    
END
GO
