USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spAnnex12ESMAUnderlyingExposureReport]') AND type in (N'P', N'PC'))
DROP PROCEDURE [corp].[spAnnex12ESMAUnderlyingExposureReport]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

	
-----------------------------------------------------------------------------------------------  
  /*
  Author: Mukesh Sharma
  Date: 2022-10-05
  Description:  Generating data for ESMA_12  report 
  Exec [corp].[spAnnex12ESMAUnderlyingExposureReport] '2022-09-30',1,NULL
  05-Dec-2022: Mukesh- Did change to make few columns deal spefic for more information , refer SFTP-13943
  13-March-2023: Mukesh- Didchnage he logic for ACR for more information , refer SFTP-13921
  12-April-2023: Mukesh- Fix bug for ACR , refer SFTP-14704

  */
------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [corp].[spAnnex12ESMAUnderlyingExposureReport]
(
	 @pAsAtDate DATE ,
	 @pDealId INT = NULL,
	 @pUserName VARCHAR(100)=NULL
)
AS  
BEGIN  
   
        DECLARE @PartitionId BIGINT,  
		@ReportTemplateName varchar(100),  
		@ReportTemplateName1 varchar(100),  
		@msgtxt VARCHAR(100) = '',  
		@DealIdS INT,  
		@DealName Varchar(50),  
		@LastQtrPartitionId INT,  
		@UniqueIdentifier VARCHAR(50)='',  
		@Geography VARCHAR(30),  
		@CurrentYear INT,  
		@CurrentQuater INT,  
		@DealIdCommonSP INT,  
		@FacilityCurrencyCode VARCHAR(10),  
		@PreviousQuarter DATE,  
		@PrincipalCollectionsMonth1 DATE,  
		@PrincipalCollectionsMonth2 DATE,  
		@PrincipalCollectionsMonth3 DATE,  
		@UtilisationMonth1 FLOAT,  
		@UtilisationMonth2 FLOAT,  
		@UtilisationMonth3 FLOAT,  
		@ACPRUtilisation FLOAT,  
		@ACPRUtilisationMonth1 FLOAT,  
		@ACPRUtilisationMonth2 FLOAT,  
		@ACPRUtilisationMonth3 FLOAT,  
		@PeriodicCPR DECIMAL(20,7),  
		@GrossChargeOff DECIMAL(23,4),  
		@AsAtDate  DATE,  
		@PrincipalRecoveriesInThePeriod DECIMAL(23,2) ,
		@TotalRonaCurrent FLOAT,
		@RonaMsg27Current FLOAT,
		@RestructuredExposures FLOAT,
		@ReqCols xml,
		@RecoveriesDate DATE,
		@Previous2months DATE,
		@ReqColsACR XML,
		@TotalPrepayments DECIMAL(38,10),
		@TotalACRUtilisation DECIMAL(38,10)
    
    
	BEGIN TRY  
	SET @ReportTemplateName           ='ESMA_12_CB'  
	SET @ReportTemplateName1          ='ESMA_CB'  
	SET @DealIdCommonSP               = @pDealId  
	SET @DealName                     =(SELECT DealName from [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealId=@pDealId  AND IsActive='Y')  
	SET @UniqueIdentifier             =(SELECT UniqueIdentifier FROM [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealId = @DealIdCommonSP AND IsActive='Y')  
	SET @DealIdS                      =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)  
	SET @AsAtDate                     =(SELECT TOP 1 LastDayOfMonth FROM [sfp].[syn_SfpModel_vw_Calendar_v1] WHERE AsAtDate = @pAsAtDate)  
	SET @CurrentYear                  =DATEPART(YEAR, @pAsAtDate)  
	SET @CurrentQuater                =DATEPART(QUARTER, @pAsAtDate) 
  	SET @Previous2months              =(SELECT  DATEADD(MONTH,-2,asatdate)FROM [sfp].[syn_SfpModel_vw_Calendar_v1] WHERE asatdate=@pAsAtDate AND Regioncode='UK')
	SET @RecoveriesDate               =(SELECT MIN(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]   WHERE IsWorkingDay=1 AND MONTH(asatdate)=MONTH(@Previous2months) AND YEAR(asatdate)=YEAR(@Previous2months) AND Regioncode='UK')  
	SET @PreviousQuarter              =(SELECT  DATEADD(MONTH,-3,asatdate)FROM [sfp].[syn_SfpModel_vw_Calendar_v1] WHERE asatdate=@pAsAtDate AND Regioncode='UK')  
	SET @PrincipalCollectionsMonth1   =(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]   WHERE IsWorkingDay=1 AND MONTH(asatdate)=MONTH(@PreviousQuarter) AND YEAR(asatdate)=YEAR(@PreviousQuarter) AND Regioncode='UK')  
	SET @PrincipalCollectionsMonth2   =(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]   WHERE IsWorkingDay=1 AND  MONTH(asatdate)=MONTH(DATEADD(MONTH,1,@PrincipalCollectionsMonth1))   
										AND  YEAR(asatdate)=YEAR(DATEADD(MONTH,1,@PrincipalCollectionsMonth1)) AND Regioncode='UK')  
	SET @PrincipalCollectionsMonth3   =(SELECT MAX(asatdate) FROM [sfp].[syn_SfpModel_vw_Calendar_v1]  WHERE IsWorkingDay=1 AND  MONTH(asatdate)=MONTH(DATEADD(MONTH,1,@PrincipalCollectionsMonth2))   
										AND  YEAR(asatdate)=YEAR(DATEADD(MONTH,1,@PrincipalCollectionsMonth2)) AND Regioncode='UK')  
	
	IF OBJECT_ID('tempdb..#reflookupdata') IS NOT NULL DROP TABLE #reflookupdata  
	IF OBJECT_ID('tempdb..#reflookupdataESMA') IS NOT NULL DROP TABLE #reflookupdataESMA   
	IF OBJECT_ID('tempdb..#dealdata') IS NOT NULL DROP TABLE #dealdata  
	IF OBJECT_ID('tempdb..#deallookupdata') IS NOT NULL DROP TABLE #deallookupdata  
	IF OBJECT_ID('tempdb..#lossmanagementdata') IS NOT NULL DROP TABLE #lossmanagementdata  
	IF OBJECT_ID('tempdb..#RealisedRecoveries') IS NOT NULL  DROP TABLE #RealisedRecoveries  
	IF OBJECT_ID('tempdb..#CommonSPdata') IS NOT NULL  DROP TABLE #CommonSPdata  
	IF OBJECT_ID('tempdb..#Reportdata') IS NOT NULL  DROP TABLE #Reportdata  
	IF OBJECT_ID('tempdb..#CurrentOverAll') IS NOT NULL  DROP TABLE #CurrentOverAll  
	IF OBJECT_ID('tempdb..#PrincipalCollectionsDataMonth1') IS NOT NULL  DROP TABLE #PrincipalCollectionsDataMonth1  
	IF OBJECT_ID('tempdb..#PrincipalCollectionsDataMonth2') IS NOT NULL  DROP TABLE #PrincipalCollectionsDataMonth2  
	IF OBJECT_ID('tempdb..#PrincipalCollectionsDataMonth3') IS NOT NULL  DROP TABLE #PrincipalCollectionsDataMonth3  
	IF OBJECT_ID('tempdb..#WriteOffData') IS NOT NULL  DROP TABLE #WriteOffData  
    IF OBJECT_ID('tempdb..#fxRates') IS NOT NULL  DROP TABLE #fxRates 
	IF OBJECT_ID('tempdb..#Scaler') IS NOT NULL  DROP TABLE #Scaler
	IF OBJECT_ID('tempdb..#refLookupFXRateChowa') IS NOT NULL  DROP TABLE #refLookupFXRateChowa
    IF OBJECT_ID('tempdb..#CurrentOverAll') IS NOT NULL  DROP TABLE #CurrentOverAll
	IF OBJECT_ID('tempdb..#reflookupdatadealspecific') IS NOT NULL DROP TABLE #reflookupdatadealspecific  
	IF OBJECT_ID('tempdb..#TempPreviousquater') IS NOT NULL DROP TABLE #TempPreviousquater 
	IF OBJECT_ID('tempdb..#TempACR') IS NOT NULL DROP TABLE #TempACR 


	SET @msgtxt = 'Before INSERT INTO #reflookupdata ' + CONVERT(VARCHAR(20), GETDATE(), 121)  
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT  
        
     /*Populating default values from reportlookup data*/   

	 SELECT DISTINCT  
	 ReportTemplateName  
	,LookUpName 
	,LookUpValue
	,LookUpValueDescription  
	,ReportValue  
	 INTO #reflookupdatadealspecific  
	 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
	 WHERE ReportTemplateName = @ReportTemplateName  AND LookUpName=@DealName
  
	SELECT DISTINCT  
	 ReportTemplateName  
	,LookUpName 
	,LookUpValue
	,LookUpValueDescription  
	,ReportValue  
	 INTO #reflookupdata  
	 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
	 WHERE ReportTemplateName = @ReportTemplateName  
  
    
      SELECT DISTINCT  
      ReportTemplateName 
     ,LookUpName 
     ,LookUpValue  
	 ,LookUpValueDescription
	 ,ReportValue  
      INTO #reflookupdataESMA  
      FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
      WHERE ReportTemplateName = @ReportTemplateName1    
         
	
	 SELECT  DISTINCT
	 ReportTemplateName
    ,LookUpName
    ,LookUpValue
    ,LookUpValueDescription
    ,ReportValue
     INTO #refLookupFXRateChowa
     FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1] 
     WHERE ReportTemplateName = 'RefReg_CB' AND LookUpName='CHOWA'

	 SELECT fx.FromCurrencyName AS [FromCurrency]  
    ,fx.Rate AS [Rate]  
     INTO #fxRates  
     FROM  [CW].[vw_FXRate]  fx   
     INNER JOIN [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] deal  
     ON deal.DealId =@pDealId  
     WHERE  CONVERT(DATE, fx.RelatesRateDate) = deal.FxRateDate  
     AND fx.ToCurrencyName = 'GBP'  
         
	/*Populating  WriteOffData */   
	 SELECT    
	 FacilityId  
	,SUM(ISNULL(Amount,0.00)*(CASE WHEN @pDealId=8 AND WA.FacilityId =refchowa.LookUpValue
						    THEN ISNULL(refchowa.reportvalue,1.00) ELSE FX.[Rate] END)) as ConvertedAmount
	 INTO  #WriteOffData FROM  [corp].[WriteOffData] AS WA LEFT JOIN  #fxRates AS FX ON WA.CCY=FX.FromCurrency
	 LEFT JOIN #refLookupFXRateChowa refchowa ON refchowa.LookUpValue=WA.FacilityId
	 GROUP BY WA.FacilityId
  
	SET @FacilityCurrencyCode=(SELECT TOP 1 ReportValue FROM #reflookupdataesma WHERE LookUpValue = 'FacilityCurrencyCode')  
	SET @msgtxt = 'Before INSERT INTO #dealdata ' + CONVERT(VARCHAR(20), GETDATE(), 121)  
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT  
	/*Populating deal data from securitiazation */   
  
	 SELECT DISTINCT  
	 DealId  
	,DealName  
	,DealPublicName  
	,DealAccountingTypeId  
	,RiskRetentionMethodId  
	,RiskRetentionHolderId  
	,BusinessAreaId  
	 INTO #dealdata  
	 FROM  [cfg].[Deal]  
	 WHERE DealId=@DealIdS  
  
    
     SET @msgtxt = 'Before INSERT INTO #deallookupdata ' + CONVERT(VARCHAR(20), GETDATE(), 121)  
     RAISERROR(@msgtxt, 10, 1) WITH NOWAIT  
  
   /*Populating lookvalues for deal data from securitiazation */   
	SELECT  DISTINCT  
	LookupValueId  
   ,Value  
	INTO  #deallookupdata  
	FROM  [cfgCW].[DealLookupValue]   
	WHERE IsActive=1  
  
  
    SET @msgtxt = 'Before Common SP Started ' + CONVERT(VARCHAR(20), GETDATE(), 121)  
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT    
	/*Calling common SP to get data output*/ 
	SET @ReqCols 				 =((SELECT CriteriaFieldName  
					                FROM (Values 
									('FacilityId')  
						           ,('ForbearanceStatusCode') 
						           ,('MasterGradingScore')
						           ,('RONA')
						           ,('UtilisationGBP_SecDate')
						           ,('CommittedExposure')
						            ) Field(CriteriaFieldName)  
						           FOR XML PATH('Node'), ROOT('Root') 
						           ))

	DECLARE @RowId VARCHAR(100)   
	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
	 @VintageDate              =@pAsAtDate
    ,@DealKey                  =@DealIdCommonSP
    ,@ReqColumns               =@ReqCols 
	,@OutputRowID              =@RowID OUTPUT   
  
	 SELECT DISTINCT
	 FacilityId
	,ForbearanceStatusCode
	,MasterGradingScore
	,RONA
	,UtilisationGBP_SecDate AS Utilisation
    ,CommittedExposure as TotalCreditLimit
	,@pAsAtDate as AsAtDate
	,@DealIdS as DealId  
	 INTO #CommonSPdata   
	 FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
     /*Delete data from staging table after storing it in a temp table*/  
     DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID 


	 
	 	 SET @ReqColsACR           =((SELECT CriteriaFieldName  
                                    FROM (Values
									  ('FacilityId')  
                                     ,('UtilisationGBP_SecDate') 
									 ,('Dealtype') 
		                              ,('FacilityScheduleAmt') 
									  ,('Holdingshare') 
									  ,('FacilityType') 
									   ,('MaturityDate')

                                      ) Field(CriteriaFieldName)  
                                     FOR XML PATH('Node'), ROOT('Root') 
		                              ))
    /* Calling common Sp for ACR calculation*/  
     EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
     @VintageDate               =@PrincipalCollectionsMonth1
    ,@DealKey                   =@DealIdCommonSP
	,@ReqColumns                =@ReqColsACR 
    ,@OutputRowID               =@RowID OUTPUT   
  
	SELECT  DISTINCT
	 FacilityId
	,UtilisationGBP_SecDate AS Utilisation
	,Dealtype
	,ISNULL(FacilityScheduleAmt,0.00) AS FacilityScheduleAmt
	,ISNULL(Holdingshare,0.00) AS Holdingshare
	,FacilityType
	,MaturityDate
	,@PrincipalCollectionsMonth1 as AsAtDate
	,@DealIdS as DealId  
	 INTO #TempPreviousquater 
	 FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging]WHERE RowId = @RowID  

     DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  


	 SELECT DISTINCT Pq.Utilisation
	 ,(Pq.Utilisation-ISNULL(Csp.Utilisation,0.00)) AS Reduction
	 , Pq.FacilityType
	 ,CONVERT(decimal(38,10),Pq.Holdingshare) /100 AS Holdingshare
	 ,CASE WHEN Pq.DealType='Bilateral' THEN CONVERT(DECIMAL(38,10),FacilityScheduleAmt) ELSE FacilityScheduleAmt*ISNULL(CONVERT(DECIMAL(38,10),Pq.Holdingshare)/100,0.00) END AS [Scheduled Repayment]
	 ,(Pq.Utilisation-ISNULL(Csp.Utilisation,0.00))-(CASE WHEN Pq.DealType='Bilateral' THEN CONVERT(DECIMAL(38,10),FacilityScheduleAmt) ELSE FacilityScheduleAmt*ISNULL(CONVERT(DECIMAL(38,10),Pq.Holdingshare)/100,0.00) END) AS Prepayment
	 ,Pq.MaturityDate 
	 ,Pq.DealType
	 ,Pq.FacilityScheduleAmt AS FacilityScheduleAmt
	 INTO #TempACR
	 FROM #TempPreviousquater AS Pq
	 LEFT JOIN  #CommonSPdata AS Csp ON Pq.FacilityId=Csp.FacilityId


	SET @TotalPrepayments= (SELECT  SUM(Prepayment)FROM #TempACR  WHERE FacilityType='Loan' AND  Prepayment>0  AND CONVERT(DATE,MaturityDate)>@pAsAtDate)

	SET @TotalACRUtilisation=(SELECT SUM(Utilisation) FROM #TempACR)

	SET @PeriodicCPR=@TotalPrepayments/NULLIF(@TotalACRUtilisation,0)
	SET @PeriodicCPR=1-ISNULL(@PeriodicCPR,0.0000)


	 SET @ReqCols                =((SELECT CriteriaFieldName  
                                    FROM (Values
									  ('FacilityId')  
                                     ,('UtilisationGBP_SecDate') 
                                      ) Field(CriteriaFieldName)  
                                     FOR XML PATH('Node'), ROOT('Root') 
		                              ))
    /* Calling common Sp for PrincipalCollectionsMonth1 calculation*/  
     EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
     @VintageDate               =@PrincipalCollectionsMonth1
    ,@DealKey                   =@DealIdCommonSP
	,@ReqColumns                =@ReqCols 
    ,@OutputRowID               =@RowID OUTPUT   
  
	SELECT  DISTINCT
	 FacilityId
	,UtilisationGBP_SecDate AS Utilisation
	,@PrincipalCollectionsMonth1 as AsAtDate
	,@DealIdS as DealId  
	 INTO #PrincipalCollectionsDataMonth1   
	 FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging]WHERE RowId = @RowID  
     DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
    /*Delete data from staging table after storing it in a temp table*/  
  
  
    /* Calling common Sp for PrincipalCollectionsMonth2 calculation*/  
    EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
	 @VintageDate               =@PrincipalCollectionsMonth2
	,@DealKey                   =@DealIdCommonSP
	,@ReqColumns                =@ReqCols 
	,@OutputRowID               =@RowID OUTPUT   
  
     SELECT DISTINCT 
	 FacilityId
	,UtilisationGBP_SecDate AS Utilisation
	,@PrincipalCollectionsMonth2 as AsAtDate
	,@DealIdS as DealId  
     INTO #PrincipalCollectionsDataMonth2   
     FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
     DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
    /*Delete data from staging table after storing it in a temp table*/  
  
    /* Calling common Sp for PrincipalCollectionsMonth2 calculation*/  
     EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
     @VintageDate              =@PrincipalCollectionsMonth3
    ,@DealKey                  =@DealIdCommonSP
	,@ReqColumns               =@ReqCols 
    ,@OutputRowID              =@RowID OUTPUT   
  
	 SELECT  DISTINCT 
	 FacilityId
	,UtilisationGBP_SecDate AS Utilisation
	,@PrincipalCollectionsMonth3 as AsAtDate
	,@DealIdS as DealId  
	 INTO #PrincipalCollectionsDataMonth3  
	 FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID 
  
    DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID  
    /*Delete data from staging table after storing it in a temp table*/  
  
	 SET @TotalRonaCurrent       =(SELECT SUM(TotalRona.RONA ) AS TotalRona
							       FROM  
							       (SELECT DISTINCT FacilityId,RONA FROM   #CommonSPdata)
							       AS TotalRona ) 

	 SET @RonaMsg27Current       =(SELECT SUM(RonaMsg27.RONA ) AS RonaMsg27 
					              FROM   
							      (SELECT DISTINCT FacilityId
							     ,RONA
							      FROM #CommonSPdata WHERE MasterGradingScore ='27'  )
							      AS RonaMsg27  )
     SET @RestructuredExposures  =(SELECT SUM(RestructuredExposures.RONA ) AS RestructuredExposures 
					              FROM   
							      (SELECT DISTINCT FacilityId
							     ,RONA
							      FROM  #CommonSPdata WHERE ForbearanceStatusCode IN('Y','FP','FNP')   )
							      AS RestructuredExposures  )

     SET @UtilisationMonth1     =(SELECT SUM(U.Diff) FROM  
                                 (SELECT P1.FacilityId  
                                 ,(P1.Utilisation -ISNULL(P2.Utilisation,0)) AS Diff  
                                 ,P1.AsAtDate  
                                  FROM #PrincipalCollectionsDataMonth1  AS P1 LEFT JOIN #PrincipalCollectionsDataMonth2 as P2 on P1.FacilityId=P2.FacilityId   
                                  WHERE (P1.Utilisation -ISNULL(P2.Utilisation,0))>0  ) AS U GROUP BY U.AsAtDate)  
  
    
     SET @UtilisationMonth2     =(SELECT SUM(U.diff) FROM   
                                 (SELECT P2.FacilityId  
                                 ,(P2.Utilisation -ISNULL(P3.Utilisation,0)) AS Diff  
                                 ,P2.AsAtDate  
                                  FROM #PrincipalCollectionsDataMonth2  AS P2 LEFT JOIN #PrincipalCollectionsDataMonth3 AS P3 on P2.FacilityId=P3.FacilityId   
                                  WHERE (P2.Utilisation -ISNULL(P3.Utilisation,0))>0) AS U GROUP BY U.AsAtDate )  
  
     SET @UtilisationMonth3     =(SELECT SUM(U.diff) FROM   
                                 (SELECT P3.FacilityId  
                                 ,(P3.Utilisation -ISNULL(P4.Utilisation,0)) AS Diff  
                                 ,P3.AsAtDate  
                                 FROM #PrincipalCollectionsDataMonth3  AS P3 LEFT JOIN 
								 (SELECT DISTINCT  FacilityId, Utilisation FROM #CommonSPdata) AS P4 on P3.FacilityId=P4.FacilityId   
                                  WHERE (P3.Utilisation -ISNULL(P4.Utilisation,0))>0) AS U GROUP BY U.AsAtDate)  
  
	 SELECT Currentoverall.FacilityId
	,ISNUll(Currentoverall.RONA,0.00) AS RONA
	,ISNULL(Currentoverall.Utilisation,0.00) as Utilisation
    ,CONVERT( DECIMAL(23,2),ISNULL(TotalCreditLimit,0.00)) AS TCE 
	,@DealIdS AS DealId  
	 INTO #Scaler FROM  
	 (SELECT DISTINCT
	 FacilityId
     ,RONA
     ,Totalcreditlimit
	 ,Utilisation 
	 FROM  #CommonSPdata) AS Currentoverall 

	 SELECT FacilityId,RONA,TCE
	 ,ISNULL((RONA/NULLIF(TCE,0.00)),0.00) AS Scaler
	 ,ISNULL(Utilisation*(RONA/NULLIF(TCE,0.00)),0.00)[ScaledUtilisation(GBP)]
	 ,DealId   INTO #CurrentOverAll FROM #Scaler

  
	SET @GrossChargeOff                  =ISNULL((SELECT SUM(C.GrossChargeOff) FROM  
										  (SELECT  CurrentOverAll.FacilityId 
										  ,CurrentOverAll.RONA
										  ,LEFT(CurrentOverAll.Scaler,8) AS Scaler
										  ,LEFT(CurrentOverAll.Scaler,8)*ConvertedAmount  AS GrossChargeOff 
										  ,CurrentOverAll.DealId  						
										   FROM #CurrentOverAll  AS CurrentOverAll INNER JOIN #WriteOffData AS WriteOffData   
										   ON WriteOffData.FacilityId=CurrentOverAll.FacilityId) AS C GROUP BY C.DealId),0.00)  
  
   
  
    SET @PrincipalRecoveriesInThePeriod  =(SELECT SUM(RealisedRecoveries) FROM [corp].[LossManagement]   
                                           WHERE FinalVerificationDate BETWEEN @RecoveriesDate AND @pAsAtDate  
                                           AND RealisedRecoveries IS NOT NULL and DealId= @DealIdS)  
  
  
  
      
    SET @msgtxt = 'Report Generation Started ' + CONVERT(VARCHAR(20), GETDATE(), 121)  
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT     
  
    
	 SELECT DISTINCT  
	 [Unique Identifier]                    =CAST(@UniqueIdentifier AS VARCHAR(100))  
	,[Securitisation Name]                  =CAST(DealPublicName AS VARCHAR(100))   
	,[Data Cut-Off Date]                    =ISNULL(CAST(FORMAT ( @AsAtDate, 'dd-MMM-yyyy') AS VARCHAR(100)),'1900-01-01')  
	,[Reporting Entity Name]                =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'ReportingEntityName') AS VARCHAR(100))  
	,[Reporting Entity Contact Person]      =CAST(ISNULL((SELECT TOP 1 ReportingContactPerson FROM [cfg].[Deal] WHERE DealName = @DealName),'')AS VARCHAR(100))   
	,[Reporting Entity Contact Telephone]   =CAST(ISNULL((SELECT TOP 1 ReportingContactTelephone FROM [cfg].[Deal] WHERE DealName = @DealName),'')AS VARCHAR(100))  
	,[Reporting Entity Contact Emails]      =CAST(ISNULL((SELECT TOP 1 ReportingContactEmail FROM [cfg].[Deal] WHERE DealName = @DealName),'')AS VARCHAR(100))  
	,[Risk Retention Method]                =CAST(CASE   
			                                     WHEN deallookupriskretentionmethod.VALUE='Vertical' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionMethodVertical')  
			                                     WHEN deallookupriskretentionmethod.VALUE='Seller''s share' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionMethodSellerShare')  
			                                     WHEN deallookupriskretentionmethod.VALUE='Randomly-selected exposures kept on balance sheet' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionMethodExposure')  
			                                     WHEN deallookupriskretentionmethod.VALUE='First loss tranche' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionMethodFirstLossTranche')  
			                                     WHEN deallookupriskretentionmethod.VALUE='First loss exposure in each asset' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionMethodFirstLossAsset')  
			                                     WHEN deallookupriskretentionmethod.VALUE='No compliance with risk retention requirements' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionMethodNoCompliance')  
			                                     ELSE (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'AllAttributeOther')  
		                                         END AS VARCHAR(100))  
  
	,[Risk Retention Holder]                =CAST(CASE   
			                                     WHEN deallookupriskretentionholder.VALUE IN('RBS','NWB') THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskRetentionHolderRBSNWB')  
			                                     ELSE (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'AllAttributeOther')  
			                                     END AS VARCHAR(100))  
  
	,[Underlying Exposure Type]             =CAST(CASE   
			                                     WHEN deallookupDealBusinessAreaId.VALUE='Commercial Real Estate - Commercial Mortgage' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'UnderlyingExposureTypeCommercialRealEstate')  
			                                     WHEN deallookupDealBusinessAreaId.VALUE='Mortgage - Residential Mortgage' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'UnderlyingExposureTypeMortgage')  
			                                     ELSE (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'AllAttributeOther')  
			                                     END AS VARCHAR(100))  
	,[Risk Transfer Method]                 =CAST(CASE   
			                                     WHEN deallookupDealAccountingTypeId.VALUE='True Sale' THEN (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskTransferMethodTrueSale')  
			                                     ELSE (SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskTransferMethodNoSale')  
		                                         END AS VARCHAR(100))  
  
	,[Trigger Measurements/Ratios]          =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'TriggerMeasurementsRatios')AS VARCHAR(100))  
	,[Revolving/ Ramp-Up Period End-Date]   =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RevolvingRampUpPeriodEndDate')AS VARCHAR(100))  
	,[Principal Recoveries In The Period]   =CAST((CAST(ISNULL(@PrincipalRecoveriesInThePeriod,0)AS VARCHAR(100))+@FacilityCurrencyCode) AS VARCHAR(100))  
	,[Interest Recoveries In The Period]    =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'InterestRecoveriesInThePeriod')AS VARCHAR(100))  
	,[Principal Collections In The Period]  =CAST((CAST(Format((ISNULL(@UtilisationMonth1,0)+ISNULL(@UtilisationMonth2,0)+ISNULL(@UtilisationMonth3,0)),'##,##0.00') AS VARCHAR(100))+@FacilityCurrencyCode) AS VARCHAR(100))    
	,[Interest Collections In The Period]   =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'InterestCollectionsInThePeriod')AS VARCHAR(100))  
	,[Drawings Under Liquidity Facility]    =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'DrawingsUnderLiquidityFacility')AS VARCHAR(100))  
	,[Securitisation Excess Spread]         =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'SecuritisationExcessSpread')AS VARCHAR(100))  
	,[Excess Spread Trapping Mechanism]     =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'ExcessSpreadTrappingMechanism')AS VARCHAR(100))  
	,[Current Overcollateralisation]        =CAST((CAST((CONVERT(DECIMAL(23,2),ISNULL(CurrentOverAll.TotalScaledUtil/NULLIF(CurrentOverAll.TotalRona,0),0)*100.00) ) AS VARCHAR(100))+'%') AS VARCHAR(100))   
	,[Annualised Constant Prepayment Rate]  =CAST((CAST((CONVERT(DECIMAL(23,2),(CONVERT(DECIMAL(23,4),1-( @PeriodicCPR*@PeriodicCPR*@PeriodicCPR*@PeriodicCPR)))*100)) AS VARCHAR(100))+'%') AS VARCHAR(100))  
	,[Dilutions]                            =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'Dilutions')AS VARCHAR(100))  
	,[Gross Charge Offs In The Period]      =CAST((CAST(CONVERT(DECIMAL(23,2),@GrossChargeOff) AS VARCHAR(100))+@FacilityCurrencyCode) AS VARCHAR(100))  
	,[Repurchased Exposures]                =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RepurchasedExposures')AS VARCHAR(100))  
	,[Restructured Exposures]               =CAST((CAST(CONVERT(DECIMAL(23,2),ISNULL(@RestructuredExposures,0.00)) AS VARCHAR(100))+@FacilityCurrencyCode) AS VARCHAR(100))  
	,[Risk Weight Approach]                 =CAST((SELECT Reportvalue FROM #reflookupdata WHERE lookupvalue = 'RiskWeightApproach')AS VARCHAR(100))  
	,[Annualised Constant Default Rate]     =CAST((CAST(CONVERT(DECIMAL(23,2),ISNULL(@RonaMsg27Current/NULLIF(@TotalRonaCurrent,0),0)) AS VARCHAR(100))+'%') AS VARCHAR(100))  
	,[Defaulted Exposures]                  =CAST((CAST(CONVERT(DECIMAL(23,2),ISNULL(@RonaMsg27Current,0)) AS VARCHAR(100))+@FacilityCurrencyCode) AS VARCHAR(100))  
	,[Defaulted Exposures CRR]              =CAST((CAST(CONVERT(DECIMAL(23,2),ISNULL(@RonaMsg27Current,0))  AS VARCHAR(100))+@FacilityCurrencyCode) AS VARCHAR(100))  
	 INTO #Reportdata  
	 FROM #dealdata AS deal  
	 LEFT JOIN #deallookupdata AS deallookupriskretentionmethod ON deallookupriskretentionmethod.LookupValueId=deal.RiskRetentionMethodId  
	 LEFT JOIN #deallookupdata AS deallookupriskretentionholder ON deallookupriskretentionholder.LookupValueId=deal.RiskRetentionHolderId  
	 LEFT JOIN #deallookupdata AS deallookupDealAccountingTypeId ON deallookupDealAccountingTypeId.LookupValueId=deal.DealAccountingTypeId  
	 LEFT JOIN #deallookupdata AS deallookupDealBusinessAreaId ON deallookupDealBusinessAreaId.LookupValueId=deal.BusinessAreaId      
	 LEFT JOIN (SELECT SUM(RONA) AS TotalRona,SUM([ScaledUtilisation(GBP)]) AS TotalScaledUtil,DealId FROM #CurrentOverAll  
	 GROUP BY DealId) AS CurrentOverAll ON   CurrentOverAll.DealId=deal.Dealid  
  
	SELECT FieldName,[Value]  
	FROM #Reportdata  
	UNPIVOT   
	(   
	 [Value] FOR FieldName IN (   
	 [Unique Identifier]  
	,[Data Cut-Off Date]  
	,[Securitisation Name]  
	,[Reporting Entity Name]  
	,[Reporting Entity Contact Person]  
	,[Reporting Entity Contact Telephone]  
	,[Reporting Entity Contact Emails]  
	,[Risk Retention Method]  
	,[Risk Retention Holder]  
	,[Underlying Exposure Type]  
	,[Risk Transfer Method]  
	,[Revolving/ Ramp-Up Period End-Date]  
	,[Excess Spread Trapping Mechanism]  
	,[Trigger Measurements/Ratios]  
	,[Drawings Under Liquidity Facility]  
	,[Principal Recoveries In The Period]  
	,[Interest Recoveries In The Period]  
	,[Principal Collections In The Period]  
	,[Interest Collections In The Period]  
	,[Securitisation Excess Spread]  
	,[Current Overcollateralisation]  
	,[Annualised Constant Prepayment Rate]  
	,[Dilutions]  
	,[Gross Charge Offs In The Period]  
	,[Repurchased Exposures]  
	,[Restructured Exposures]  
	,[Annualised Constant Default Rate]  
	,[Defaulted Exposures]  
	,[Defaulted Exposures CRR]  
	,[Risk Weight Approach]  
   
	)  
	)   
	AS UnpivotTable  
   
    SET @msgtxt = 'End of Report generation : ' + CONVERT(VARCHAR(20), GETDATE(), 121)  
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT  
  
  
  
    END TRY  
	BEGIN CATCH                    
	DECLARE         
	@errorMessage     NVARCHAR(MAX),        
	@errorSeverity    INT,        
	@errorNumber      INT,        
	@errorLine        INT,        
	@errorState       INT;        
     
	DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID    
	SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()       
	EXEC app.SaveErrorLog 2, 1, 'spStratificationDelinquencyData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName     
	RAISERROR (@errorMessage,  @errorSeverity,  @errorState )                
	END CATCH     
  
END
