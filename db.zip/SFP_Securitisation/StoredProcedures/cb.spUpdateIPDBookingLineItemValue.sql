USE [SFP_Securitisation]

GO

IF OBJECT_ID('cb.spUpdateIPDBookingLineItemValue') IS NOT NULL
	DROP PROCEDURE cb.spUpdateIPDBookingLineItemValue
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure cb.spUpdateIPDBookingLineItemValue    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	12.02.2023
 * Description:  Bookings lineitem save data.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
	
exec cb.spUpdateIPDBookingLineItemValue @pDealIpdRunId ='14-OCT-2022', @@pLineItemInternalName='Deimos', @pUserName ='kumavnb'
 * -------------------------------------------------------
*/    
        
        
CREATE PROC [cb].spUpdateIPDBookingLineItemValue
@pDealIpdRunId DateTime,
@pLineItemInternalName varchar(255),
@pValue varchar(255) = null 
AS        
BEGIN  
	
	BEGIN TRY  

		Update  bliv
		SET bliv.VALUE = @pValue
		FROM [cb].[BookingLineItemValue] bliv
		INNER JOIN [CB].[vwBookingLineItems] vbli On vbli.BookingLineItemId = bliv.BookingLineItemId
		Where bliv.DealIpdRunId = @pDealIpdRunId
		and vbli.LineItemInternalName =@pLineItemInternalName

	END TRY
	BEGIN CATCH  

		
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE() + ' For LineItem ' + @pLineItemInternalName + ' ' + @pValue, @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cb.spUpdateIPDBookingLineItemValue',@errorNumber,@errorSeverity,@errorLine,@errorMessage,'System'
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH 
END