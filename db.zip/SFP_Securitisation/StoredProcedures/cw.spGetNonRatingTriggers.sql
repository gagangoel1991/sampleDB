USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetNonRatingTriggers]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetNonRatingTriggers] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 26-05-2021 
--Description: GET NON Rating trigger 
--[cw].[spGetNonRatingTriggers] 6,1034,''
--==================================   
CREATE PROCEDURE [cw].[spGetNonRatingTriggers] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   
	
   SELECT 
    tr.DealIpdTriggerResultId AS Id, 
    t.DisplayName AS EventName,
    t.Consequences AS ConsequenceOfEvent,
    t.TriggerSummary,
	tr.IsBreached,
    tt.InternalName,
    tr.ModifiedBy,
    tr.ModifiedDate
   FROM cw.DealIpdTriggerResult tr 
    JOIN cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId
    JOIN cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId
    JOIN cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId AND t.DealId = tm.DealId
    JOIN cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId
   WHERE  tr.DealIpdRunId=@pIPDRunId 
    AND tm.DealId=@pDealId 
    AND tt.InternalName  IN ('NonRatingTrigger','ConditionTrigger')
END TRY 
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetNonRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO
