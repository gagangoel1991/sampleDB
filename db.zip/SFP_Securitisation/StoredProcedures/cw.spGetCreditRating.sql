USE SFP_Securitisation
GO
IF OBJECT_ID('[cw].[spGetCreditRating]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetCreditRating]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spGetCreditRating] 
/*
 * Author: Gunjan Chandola
 * Date:	20.01.2021
 * Description:  This will return the all active ratings
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
   BEGIN         
     SELECT CRAId,RatingTypeId,Rating FROM  [cfgCW].[CRARating]  WHERE IsActive=1  
   END
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetCreditRating', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
