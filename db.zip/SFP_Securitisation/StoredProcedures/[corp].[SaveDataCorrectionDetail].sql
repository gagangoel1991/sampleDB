USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[SaveDataCorrectionDetail]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [corp].[SaveDataCorrectionDetail]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[SaveDataCorrectionDetail]
(
	@pDealDataCorrectionId INT,
	@pDataCorrectionList AS [corp].[DataCorrectionKeyValue] READONLY,	
	@pUserName VARCHAR(20),	
	@pResult INT OUTPUT	
)
AS
BEGIN
	BEGIN TRY		
		
		DECLARE @IsActive BIT = 1
		DECLARE @IsUpdated BIT = 0
		DECLARE @Version INT = 0
		
		CREATE TABLE #DCDetail
		(
			[DealDataCorrectionId] INT, 
			[FacilitySecurityId] BIGINT, 
			[ConnectionId] INT,		
			[AttributeId] INT,  
			[Value] VARCHAR(100),  
			[IsUpdated] BIT,  
			[Version] INT,  
			[IsActive] INT,  
			[CreatedBy] VARCHAR(20),  
			[CreatedDate] DATETIME,  
			[ModifiedBy] VARCHAR(20),  
			[ModifiedDate] DATETIME,
			[FacilityID] BIGINT
		)
		
		INSERT INTO #DCDetail([FacilitySecurityId], [ConnectionId], [AttributeId], [Value], [FacilityID])
		SELECT [FacilitySecurityId], IIF([ConnectionId] = 0, NULL, [ConnectionId])  , [AttributeId], [Value] , [FacilityId]FROM @pDataCorrectionList
	
		UPDATE #DCDetail
		SET 
			[DealDataCorrectionId] = @pDealDataCorrectionId,
			[IsUpdated] = @IsUpdated,
			[Version] = @Version,
			[IsActive] = @IsActive,
			[CreatedBy] = @pUserName,
			[CreatedDate] = GETUTCDATE(),
			[ModifiedBy] = @pUserName,
			[ModifiedDate] = GETUTCDATE()
		
		-- Insert unique data in detail table
		INSERT INTO [corp].[DealDataCorrectionDetail]  
		(  
			[DealDataCorrectionId],  
			[FacilitySecurityId],
			[ConnectionId],
			[AttributeId],
			[Value],  
			[IsUpdated],  
			[Version],  
			[IsActive],  
			[CreatedBy],  
			[CreatedDate],  
			[ModifiedBy],  
			[ModifiedDate],
			[FacilityId]
		)  
		SELECT   
			tmp.[DealDataCorrectionId], 
			tmp.[FacilitySecurityId], 
			tmp.[ConnectionId],
			tmp.[AttributeId],  
			tmp.[Value],  
			tmp.[IsUpdated],  
			tmp.[Version],  
			tmp.[IsActive],  
			tmp.[CreatedBy],  
			tmp.[CreatedDate],  
			tmp.[ModifiedBy],  
			tmp.[ModifiedDate],
			tmp.[FacilityId]
		FROM #DCDetail tmp 
		LEFT JOIN [corp].[DealDataCorrectionDetail] dtl
		ON dtl.[DealDataCorrectionId] = tmp.DealDataCorrectionId   
			AND dtl.[AttributeId] = tmp.AttributeId 
			AND dtl.FacilitySecurityId = tmp.FacilitySecurityId
			AND dtl.FacilityId = tmp.FacilityID
			AND (ISNULL(tmp.ConnectionId, 0) = 0 
				OR dtl.ConnectionId = tmp.ConnectionId)
		WHERE dtl.[DealDataCorrectionId] IS NULL AND dtl.[AttributeId] IS NULL AND dtl.FacilitySecurityId IS NULL
			AND dtl.ConnectionId IS NULL
		-- Update existing data in detail table
		UPDATE dtl   
		SET      
			[Value] = tmp.Value,  
			[IsUpdated] = ~@IsUpdated,  
			[Version] = dtl.[Version] + 1,  
			[ModifiedBy] = tmp.[ModifiedBy],  
			[ModifiedDate] = tmp.[ModifiedDate]  
		FROM [corp].[DealDataCorrectionDetail] dtl
		INNER JOIN  #DCDetail tmp 
		ON dtl.[DealDataCorrectionId] = tmp.DealDataCorrectionId   
			AND dtl.[AttributeId] = tmp.AttributeId 
			AND dtl.FacilitySecurityId = tmp.FacilitySecurityId
			AND dtl.FacilityId = tmp.FacilityID
			AND (ISNULL(tmp.ConnectionId, 0) = 0 
				OR dtl.ConnectionId = tmp.ConnectionId)
			AND dtl.[Value] <> tmp.Value

		SET @pResult = 102
		
END TRY
	BEGIN CATCH	                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
        
		SET @pResult = -102   

		EXEC app.SaveErrorLog 2, 1, 'SaveDataCorrectionDetail', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                    
                      
		RAISERROR (@errorMessage, @errorSeverity, @errorState)
	END CATCH
END
GO