USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetDetailDrillThroughReportCB]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetDetailDrillThroughReportCB]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [corp].[spGetDetailDrillThroughReportCB] 651, 'kumasdt'
CREATE PROCEDURE [corp].[spGetDetailDrillThroughReportCB]	
	@pPoolId int,
	@pUserName VARCHAR(50),
	@pEcReportType varchar(50) = 'ineligible'
AS
BEGIN	
	DECLARE @ECID VARCHAR(MAX) = '';
	DECLARE @NewEcId VARCHAR(MAX)
	DECLARE @PivotResult NVARCHAR(MAX) = '';
	DECLARE @AddECColumn VARCHAR(4000);
	DECLARE @ExclusionId INT, @Active BIT = 1, @GlobalExclusion BIT = 1
	DECLARE @ApplicableECMethod INT
	DECLARE @EcTestsCount INT

	BEGIN TRY	
			IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL                                           
				DROP TABLE #Result

			SELECT @ApplicableECMethod = ApplicableECMethod FROM PS.Pool WHERE PoolId = @pPoolId
			SELECT @EcTestsCount = COUNT(1) FROM PS.PoolEcMap MAP WHERE MAP.PoolId = @pPoolId AND IsActive = 1

			IF @pEcReportType = 'ineligible'
			BEGIN
				-- For Ineligibility report, only pick the EC tests that any facility has failed to 
				-- reduce unwanted columns in the report
				SELECT @ECID =STUFF((SELECT DISTINCT ',' + QUOTENAME(ec.Name) 
					FROM ps.PoolEligibilityBuildDetail pebd
				INNER JOIN ps.EligibilityCriteria ec
					ON pebd.EligibilityCriteriaId  = ec.EligibilityCriteriaId
				WHERE PoolId = @pPoolId 
					AND pebd.EligibilityCriteriaId <> -1 
				GROUP BY ec.Name          
						FOR XML PATH(''), TYPE
						).value('.', 'NVARCHAR(MAX)') 
					,1,1,'')

				PRINT 'Fetched EC names for ineligibility report'
			END
			ELSE
			BEGIN
				-- For Eligibility report, pick all the applicable EC test names that have been applied
				SELECT @ECID = STUFF((
					SELECT DISTINCT ',' + QUOTENAME(ec.Name)
					FROM PS.PoolEcMap MAP
					JOIN PS.EligibilityCriteria EC
						ON MAP.EligibilityCriteriaId  = EC.EligibilityCriteriaId
					AND MAP.IsActive = 1
					AND EC.IsActive = 1
					--AND EC.AssetClassId = 2
					WHERE MAP.PoolId = @pPoolId
				GROUP BY EC.Name
				FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')

				PRINT 'Fetched EC names for eligibility report'
			END

			IF @ECID <> NULL OR @ECID <> ''
			BEGIN
				IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL                  
					DROP TABLE #Result;  

				CREATE TABLE #Result                              
				(  
					LoanId BIGINT				        
				)
				
				SET @NewEcId = REPLACE(@ECID, '],', ']~')
				
				SET @AddECColumn  = 'Alter Table #Result ADD '
				DECLARE @DefaultValue VARCHAR(50) = IIF(@pEcReportType = 'ineligible', '0 ', '1 ')
				SELECT @AddECColumn = @AddECColumn + STUFF((SELECT DISTINCT ', '+ ec.Value + ' int default ' + @DefaultValue
					FROM [app].[udfSplitString](@NewEcId,'~') ec
					GROUP BY ec.Value          
							FOR XML PATH(''), TYPE
							).value('.', 'NVARCHAR(MAX)') 
						,1,1,'')	
				SET @AddECColumn = @AddECColumn + ' ,[Exclusion] int default 0, [RandomSelection] int default 0';
				EXEC(@AddECColumn)

				
				IF @pEcReportType = 'ineligible'
				BEGIN
					--Getting Ec results for each loan 
					IF @ApplicableECMethod = 1
					BEGIN
						SET @PivotResult = '
							INSERT INTO #Result(LoanId,'+ CONVERT(VARCHAR(max), @ECID) + ')
							SELECT  *
							FROM 
							(
								SELECT LoanId, ec.Name, CASE WHEN Status = 0 THEN 1 ELSE 0 END AS status							
								FROM [ps].[PoolEligibilityBuildDetail] pebd 
								INNER JOIN ps.EligibilityCriteria ec 
									ON pebd.EligibilityCriteriaId = ec.EligibilityCriteriaId
								WHERE PoolId  = '+ CONVERT(VARCHAR, @pPoolId) + ' 
							) src
							pivot
							(
								Max(STATUS) FOR [Name] in ('+ @ECID + ') 					
							) as piv'
					
						EXEC(@PivotResult);
					END
					ELSE
					BEGIN
						SET @PivotResult = '
							INSERT INTO #Result(LoanId,'+ CONVERT(VARCHAR(max), @ECID) + ')
							SELECT  *
							FROM 
							(
								SELECT LoanId, Name, Case When Status = 0 then 1 else 0 end as status							
								FROM (
									SELECT LoanId, ec.Name, Status, COUNT(pebd.EligibilityCriteriaId) OVER(PARTITION BY LoanId) CT							
									FROM [ps].[PoolEligibilityBuildDetail] pebd 
									INNER JOIN ps.EligibilityCriteria ec 
										ON pebd.EligibilityCriteriaId = ec.EligibilityCriteriaId
									WHERE PoolId  = '+ CONVERT(VARCHAR, @pPoolId) + ' 
								) T
								WHERE T.CT = ' + CONVERT(VARCHAR, @EcTestsCount) + '
							) src
							pivot
							(
								Max(STATUS) FOR [Name] in ('+ @ECID + ') 					
							) as piv'
					
						EXEC(@PivotResult);
					END

					PRINT 'Fetched LoanIds that are failing due to EC failures'

					-- Updating existing records for exclusion or random selection
					UPDATE 
						#Result 
					SET 
						--#Result.Exclusion = CASE WHEN pebd.Status = -1 THEN 1 ELSE 0 END,
						#Result.RandomSelection = CASE WHEN pebd.Status = -2 THEN 1 ELSE 0 END		
					FROM 
						#Result 
						INNER  JOIN [ps].[PoolEligibilityBuildDetail] pebd 
						ON pebd.LoanId = #Result.LoanId
					WHERE pebd.PoolId = @pPoolID AND pebd.EligibilityCriteriaId = -1

					-- Inserting new records for exclusion or random selection if they are not part of existing record set
					INSERT INTO #Result(LoanId, Exclusion, RandomSelection)
					SELECT pebd.LoanId, 
					CASE WHEN pebd.Status = -1 THEN 1 ELSE 0 END,
					CASE WHEN pebd.Status = -2 THEN 1 ELSE 0 END
					FROM [ps].[PoolEligibilityBuildDetail] pebd
					LEFT JOIN #Result r 
					ON pebd.LoanId = r.LoanId			
					WHERE pebd.PoolId = @pPoolId AND pebd.Status in (-1,-2) AND r.LoanId IS NULL
				END
				ELSE
				BEGIN
					
					IF @ApplicableECMethod = 2
					BEGIN
						SET @PivotResult = '
							INSERT INTO #Result(LoanId,'+ CONVERT(VARCHAR(max), @ECID) + ')
							SELECT  *
							FROM 
							(
								SELECT LoanId, Name, Status
								FROM (
									SELECT LoanId, ec.Name, Status, COUNT(pebd.EligibilityCriteriaId) OVER(PARTITION BY LoanId) CT							
									FROM [ps].[PoolEligibilityBuildDetail] pebd 
									INNER JOIN ps.EligibilityCriteria ec 
										ON pebd.EligibilityCriteriaId = ec.EligibilityCriteriaId
									WHERE PoolId  = '+ CONVERT(VARCHAR, @pPoolId) + '
								) T
								WHERE T.CT <> ' + CONVERT(VARCHAR, @EcTestsCount) + '
							) src
							pivot
							(
								Max(STATUS) FOR [Name] in ('+ @ECID + ') 					
							) as piv'
						
						EXEC(@PivotResult);
					END

					-- Set all passing ECs to 1
					DECLARE @tmp VARCHAR(MAX) = 'update #Result SET '
					SELECT @tmp = @tmp + STUFF((
						SELECT DISTINCT ', ' + QUOTENAME(ec.Name) + ' = ISNULL(' + QUOTENAME(ec.Name) + ', 1)' 
						FROM PS.PoolEcMap MAP
						JOIN PS.EligibilityCriteria EC
							ON MAP.EligibilityCriteriaId  = EC.EligibilityCriteriaId
						AND MAP.IsActive = 1
						AND EC.IsActive = 1
						--AND EC.AssetClassId = 2
						WHERE MAP.PoolId = @pPoolID
						GROUP BY EC.Name
						FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') 
						,1,1,'')	

					EXEC(@tmp);

					-- If this pool has EC ALL selected, the passing facilities are passing in all ECs
					INSERT INTO #Result(LoanId)
					SELECT DISTINCT LoanId FROM PS.PoolBuildDetail
					WHERE PoolId = @pPoolID AND LoanID NOT In (SELECT LoanId FROM #Result)

					-- Delete the Facilities that have been removed by Exclusion and Random selection
					DELETE FROM #Result
					WHERE LoanId In (
						SELECT pebd.LoanId
						FROM [ps].[PoolEligibilityBuildDetail] pebd
						WHERE pebd.PoolId = @pPoolId AND pebd.Status IN (-1, -2)
					)
				END
				
				SELECT * FROM #Result ORDER BY LoanId
		END
   END TRY
	BEGIN CATCH		
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetDetailDrillThroughReportCB', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO