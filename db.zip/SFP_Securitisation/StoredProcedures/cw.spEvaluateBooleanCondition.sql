USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spEvaluateBooleanCondition') IS NOT NULL
	DROP PROCEDURE cw.spEvaluateBooleanCondition
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  07.07.2020 
 *   Description:  Return true if condition met
 *   Ex: 
 *   Declare @out bit;
 *   EXEC cw.[spEvaluateBooleanCondition] '''20.9'',greaterthanequal,''20.9''' ,@oResult = @out OUTPUT;
 *   SELECT @out  
 * 
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
CREATE PROC [cw].[spEvaluateBooleanCondition](@InputStr VARCHAR(max),@oResult bit OUTPUT) 
AS 
  BEGIN 
	--Declare @InputStr VARCHAR(max) = '1,equal,0' ,@oResult bit 
	--Declare @InputStr VARCHAR(max) = '''20.6'',greaterthanequal,''20.9''' ,@oResult bit 
      
	  DECLARE @operand1 varchar(500),@operand2 varchar(500), @operator varchar(50)
		DECLARE @tempStr             nVARCHAR(max)

      WHILE Len(@InputStr) > 0 
        BEGIN 
            DECLARE @num VARCHAR(100) 

            IF Charindex(',', @InputStr) > 0 
			BEGIN
              SET @num = Substring(@InputStr, 0, Charindex(',', @InputStr)) 
			   IF(@operand1 IS NULL)
					SET @operand1 = @num
				ELSE IF(@operator IS NULL)
					SET @operator = @num
			END
            ELSE 
              BEGIN 
                  SET @num = @InputStr 
				  SET @operand2 =@num;
                  SET @InputStr = '' 
              END 

            SET @InputStr = Replace(@InputStr, @num + ',', '') 
        END 

		IF(ISNUMERIC(replace(@operand1,'''','')) = 1)
			SET @operand1=replace(@operand1,'''','')
		IF(ISNUMERIC(replace(@operand2,'''','')) = 1)
			SET @operand2=replace(@operand2,'''','')
		
		SELECT @tempStr='select @oResult = case when '+@operand1+
							CASE WHEN @operator='greaterthanequal' THEN +'>= '+@operand2
								 WHEN @operator='lessthanequal' THEN +'<= '+@operand2
								 WHEN @operator='equal' THEN +'= '+@operand2
								 WHEN @operator='greaterthan' THEN +'> '+@operand2
								 WHEN @operator='lessthan' THEN +'< '+@operand2
							END + ' then 1 else 0 end'


			 EXEC sp_executesql @tempStr, N'@oResult bit out', @oResult out;

			 --select @oResult
  END 

GO