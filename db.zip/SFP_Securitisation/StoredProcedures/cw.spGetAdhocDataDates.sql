USE [SFP_Securitisation]
GO

IF Object_Id('cw.spGetAdhocDataDates') IS NOT NULL 
	DROP PROCEDURE cw.spGetAdhocDataDates
	
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
	
CREATE PROCEDURE cw.spGetAdhocDataDates
AS
BEGIN
	SELECT 20 AS ListId, Cast(DATEADD(mm, -m, GETDATE()) AS date) AS  Value,
		CAST(LEFT(DATENAME(mm,  DATEADD(mm, -m, GETDATE())), 3) AS VARCHAR) + ' '+ CAST(YEAR(DATEADD(mm, -m, GETDATE())) AS VARCHAR) Text
	FROM    (VALUES (1),(2),(3),(4),(5),(6)) t(m) 
 
END

GO
 