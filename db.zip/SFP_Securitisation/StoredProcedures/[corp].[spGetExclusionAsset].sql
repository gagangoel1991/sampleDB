USE [SFP_Securitisation]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetExclusionAsset]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetExclusionAsset]
GO


CREATE PROCEDURE [corp].[spGetExclusionAsset]             
AS 
     
BEGIN      
	BEGIN TRY  
		
	SELECT AsAtDate, FACILITY_ID, ACCOUNT_NUMBER, BRANCH_SORT_CODE, Reason, CAST(RelatesToDate AS VARCHAR) AS RelatesToDate, LoadDate, SourceFile 
	FROM  [corp].[syn_Staging_tbl_ExclusionAsset]

    END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;   
		
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetExclusionAsset', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO