USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spProcessDealSwap') IS NOT NULL
	DROP PROCEDURE cb.spProcessDealSwap
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessDealSwap] 
( 
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  30.11.2021
 *   Description:  Fill Deal Swap table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   Aditya    15-06-2022  Changed for using the current date if the current date is less than the IPD date while calculating the factor value
	Aditya		12-08-2022	Modified to incorporate provisioned pay rate
	Aditya		07-09-2022	fixed to make pay amount actual, receive daycountfactor actual, receive amount provisional
 *   exec cb.spProcessDealSwap 56,'fm\shriyad'
 
*/ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=72, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @dealId  INT, 
				  @ipdDate DATE,
				  @previousIPDCollectionBusinessEndDateName   VARCHAR(200)='PreviousIPDCollectionBusinessEnd', 
                  @previousIPDDateName VARCHAR(200)='PreviousIPD', 
                  @previousIPDDate DATETIME, 
                  @previousIPDCollectionBusinessEndDate DATETIME, 
                  @InterestBaseRate        DECIMAL(38, 16), 
                  @tempDealSwapId      INT, 
                  @payBenchmark         varchar(200), 
                  @brandcode            varchar(200), 
                  @baseRateCode         varchar(200),
                  @endDateForYearFrac	date

          SELECT @dealId = DealId, 
				@ipdDate = IpdDate
          FROM   cw.vwDealIpdRun 
          WHERE  DealIpdRunId = @pDealIpdRunId 

		  SELECT @previousIPDDate = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId = @pDealIpdRunId  AND DealDateKeyInternalName=@previousIPDDateName

		  SELECT @previousIPDCollectionBusinessEndDate = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId = @pDealIpdRunId  AND DealDateKeyInternalName=@previousIPDCollectionBusinessEndDateName

		  Declare @MaxInterestRateDate date= (select top 1 BaseDate FROM [cw].[vwInterestRate] where RICCode = 'SONIAOSR=' order by 1 desc);
		  SELECT @endDateForYearFrac = AccrualEndDate FROM cb.SoniaCompoundingRate WHERE ResetDate = @MaxInterestRateDate

			If(@endDateForYearFrac < @ipddate)
				SET @endDateForYearFrac= @endDateForYearFrac;
			else
				SET @endDateForYearFrac = @ipddate;
			--set @endDateForYearFrac= @MaxInterestRateDate;

          IF Object_id('tempdb..#DealSwap_Wf') IS NOT NULL 
            DROP TABLE #DealSwap_Wf

          CREATE TABLE #DealSwap_Wf
            ( 
				[DealIpdRunId] [int] NULL,
				[DealSwapId] [smallint] NULL,
				[PayCouponPeriodStart] [date] NULL,
				[PayCouponPeriodEnd] [date] NULL,
				[PayDayCountMethodId] INT,
				[PayDayCountFactor] [decimal](38, 16) NULL,
				[PayDayCountFactorToUse] [decimal](38, 16) NULL,
				[PayNotional] [decimal](38, 16) NULL,
				[PayBenchmark] [varchar](200) NULL,
				[PayBaseRate] [decimal](38, 16) NULL,
				[PayRate] [decimal](38, 16) NULL,
				[PayRateType] [varchar](200) NULL,
				[PayMarginDifferential] [decimal](38, 16) NULL,
				[PayAmount] [decimal](38, 16) NULL,
				[ReceiveCouponPeriodStart] [date] NULL,
				[ReceiveCouponPeriodEnd] [date] NULL,
				[ReceiveNotional] [decimal](38, 16) NULL,
				[ReceiveRateType] [varchar](200) NULL,
				[ReceiveBaseRate] [decimal](38, 16) NULL,
				[ReceiveRateForFixed] [decimal](38, 16) NULL,
				[ReceiveMargin] [decimal](38, 16) NULL,
				[ReceiveRate] [decimal](38, 16) NULL,
				[ReceivePaymentFrequency] [int] NULL,
				[ReceiveDayCountMethod] [varchar](300) NULL,
				[ReceiveDayCountFactor] [decimal](38, 16) NULL,
				[ReceiveAmount] [decimal](38, 16) NULL,
				[NetAmount] [decimal](38, 16) NULL
            ) 

          SET @tempDealSwapId =(SELECT TOP 1 DealSwapId 
                                FROM   cfgCb.DealSwap 
                                WHERE  DealId = @dealId 
                                ORDER  BY DealSwapId ASC) 

          WHILE( @tempDealSwapId > 0 ) 
            BEGIN 
				
                INSERT INTO #DealSwap_Wf 
                            (DealIpdRunId
							,DealSwapId
							,PayCouponPeriodStart
							,PayCouponPeriodEnd
							,PayDayCountMethodId
							,PayDayCountFactor
							,PayDayCountFactorToUse
							,PayNotional
							,PayBenchmark
							,PayBaseRate
							,PayRate
							,PayRateType
							,PayMarginDifferential
							,PayAmount
							,ReceiveCouponPeriodStart
							,ReceiveCouponPeriodEnd
							,ReceiveNotional
							,ReceiveRateType
							,ReceiveBaseRate
							,ReceiveRateForFixed
							,ReceiveMargin
							,ReceiveRate
							,ReceivePaymentFrequency
							,ReceiveDayCountMethod
							,ReceiveDayCountFactor
							,ReceiveAmount
							,NetAmount) 
               SELECT	@pDealIpdRunId,                       
						DealSwapId, 
						@previousIPDDate,
						@ipddate,
						PayDayCountMethodId AS PayDayCountMethodId,
						--[Cb].[fnYearFracValue] (@previousIPDDate,cb.fnEndDateForYearFrac(@ipddate), dlvDayCountMethod.Value),
						[Cb].[fnYearFracValue] (@previousIPDDate,@endDateForYearFrac, dlvDayCountMethod.Value),
						[Cb].[fnYearFracValue] (@previousIPDDate,@ipddate, dlvDayCountMethod.Value),
						IIF(CONVERT(decimal(38,16),mft.PayNotional)>0, CONVERT(decimal(38,16),mft.PayNotional), dd.LoanBalance) PayNotional, 
						dlvPay.Value PayBenchmark
						,NULL PayBaseRate
						,IIF(CONVERT(decimal(38,16),mft.Pay_Rate)>0, CONVERT(decimal(38,16),mft.Pay_Rate), dd.WeightedAvgBalance) PayRate
						,dlvPayRateType.Value PayRateType
						,NULL PayMarginDifferential
						,NULL PayAmount
						,@previousIPDDate ReceiveCouponPeriodStart
						,@ipddate ReceiveCouponPeriodEnd
						,IIF(CONVERT(decimal(38,16),mft.PayNotional)>0, CONVERT(decimal(38,16),mft.PayNotional), dd.LoanBalance) ReceiveNotional 
						,dlvBgsRateType.Value ReceiveRateType
						,NULL ReceiveBaseRate
						,ds.ReceiveRateForFixed
						,ds.ReceiveMargin
						,NULL ReceiveRate
						,dlvReceivePaymentFrequency.Value
						,dlvReceiveDayCountMethod.Value
						,NULL ReceiveDayCountFactor
						,NULL ReceiveAmount
						,NULL NetAmount 
                FROM   cfgcb.DealSwap ds 
					   LEFT JOIN CW.vw_DealLookup dlvPay ON ds.PayBenchmarkId = dlvPay.LookupValueId
					   AND  dlvPay.TypeCode = 'Benchmark'

					   LEFT JOIN cw.vw_DealLookup dlvReceive ON ds.ReceivedBenchmarkId = dlvReceive.LookupValueId
                       AND  dlvReceive.TypeCode = 'Benchmark'

					   LEFT JOIN cw.vw_DealLookup dlvDayCountMethod ON ds.PayDayCountMethodId = dlvDayCountMethod.LookupValueId
						AND  dlvDayCountMethod.TypeCode = 'DayCountMethod'

					    LEFT JOIN cw.vw_DealLookup dlvBgsRateType ON ds.ReceiveRateTypeId = dlvBgsRateType.LookupValueId
                       AND  dlvBgsRateType.TypeCode = 'BgsRateType'

					   LEFT JOIN cw.vw_DealLookup dlvReceivePaymentFrequency ON ds.ReceivePaymentFrequencyId = dlvReceivePaymentFrequency.LookupValueId
                       AND  dlvReceivePaymentFrequency.TypeCode = 'IpdFrequency'

					    LEFT JOIN cw.vw_DealLookup dlvReceiveDayCountMethod ON ds.ReceiveDayCountMethodId = dlvReceiveDayCountMethod.LookupValueId
                      AND  dlvReceiveDayCountMethod.TypeCode = 'DayCountMethod'

					    LEFT JOIN cw.vw_DealLookup dlvPayRateType ON ds.PayRateTypeId = dlvPayRateType.LookupValueId
                       AND  dlvPayRateType.TypeCode = 'BgsRateType'

					   JOIN cfgCW.DealAggregatedField df ON ds.DealId = df.DealId AND df.FieldName=CONCAT(dlvPayRateType.Value, 'Swap')
					   JOIN [CW].[DealAggregatedData] dd ON dd.DealAggregatedFieldId = df.DealAggregatedFieldId
						AND dd.CorrelatedDate=@previousIPDCollectionBusinessEndDate

						JOIN cb.vwManualField_transpose mft ON concat(ds.SwapName,'Swap') = mft.ManualFieldGroupInternalName 
						  AND mft.DealIpdRunId = @pDealIpdRunId
                WHERE  DealSwapId = @tempDealSwapId 
							

				SET @payBenchmark = (SELECT payBenchmark FROM #DealSwap_Wf WHERE DealSwapId = @tempDealSwapId)

				IF(@payBenchmark != '')
				BEGIN
						 IF Object_id('tempdb..#Resulttable') IS NOT NULL 
							DROP TABLE #Resulttable

						  SELECT [value], ROW_NUMBER() OVER(ORDER BY (SELECT NULL)) AS RowNumber
						  INTO #Resulttable
						  FROM [app].[udfSplitString](@payBenchmark,'-') 

						SET @brandcode = (SELECT [value] FROM #Resulttable WHERE RowNumber = 1)
						SET @baseRateCode = (SELECT [value] FROM #Resulttable WHERE RowNumber = 2);

						WITH cte AS (
							SELECT DISTINCT ir.brandkey,br.brandcode, BaseRateCode,InterestBaseRate ,BaseRateEffectiveDate, InterestRateEffectiveDate,InterestRateNewEffectiveDate
							,
							ROW_NUMBER() OVER (PARTITION BY ir.brandkey, BaseRateCode ORDER BY InterestRateNewEffectiveDate DESC, BaseRateEffectiveDate DESC) AS rownum
							FROM sfp.syn_SfpModel_tbl_Dim_InterestRate ir
							INNER JOIN
							sfp.syn_SfpModel_vw_Brand_v1 br ON br.brandkey=ir.brandkey
							WHERE 
							(InterestRateNewEffectiveDate<=@previousIPDCollectionBusinessEndDate 
							--AND InterestRateEffectiveDate<=@previousIPDCollectionBusinessEndDate
							)
							AND 
							brandcode=@brandcode AND BaseRateCode=@baseRateCode
							)
							SELECT DISTINCT @InterestBaseRate=  InterestBaseRate
							FROM Cte WHERE rownum = 1 
			
							PRINT @InterestBaseRate
							PRINT @brandcode
							PRINT @baseRateCode

				END
				ELSE
				BEGIN
					SET @brandcode = NULL;
					SET @baseRateCode = NULL;
					SET @InterestBaseRate = 0;
				END

                
                UPDATE #DealSwap_Wf 
                SET    PayBaseRate = @InterestBaseRate
                FROM   #DealSwap_Wf  
                WHERE DealSwapId = @tempDealSwapId 


				--need to remove round function in sonia rate
				UPDATE #DealSwap_Wf 
                SET    PayMarginDifferential = CASE WHEN PayRateType='TRACKER' THEN PayRate - PayBaseRate ELSE 0 END
					,    PayAmount = CONVERT(decimal(35,16),PayNotional) * 
											CONVERT(decimal(18,16),(PayRate/100)) * 
											CONVERT(decimal(18,16),PayDayCountFactorToUse)
					,    ReceiveBaseRate = CASE WHEN ReceiveRateType='FIXED' 
												THEN 0 
												ELSE Round([Cb].[fnGetSoniaCompoundingCouponRate]
														(PayDayCountMethodId, PayDayCountFactor, PayCouponPeriodStart, @endDateForYearFrac)*100,4)
											END
                FROM   #DealSwap_Wf  
                WHERE DealSwapId = @tempDealSwapId 


				UPDATE #DealSwap_Wf 
                SET    ReceiveRate = 
					(CASE WHEN ReceiveRateType='FIXED' THEN ReceiveRateForFixed ELSE ((ReceiveBaseRate/100)+(ReceiveMargin/10000)) END)*100
                FROM   #DealSwap_Wf  
                WHERE DealSwapId = @tempDealSwapId 

				UPDATE #DealSwap_Wf 
                SET    ReceiveDayCountFactor = CASE 
													WHEN ReceivePaymentFrequency=12 THEN 1 
													ELSE [Cb].[fnYearFracValue]  (ReceiveCouponPeriodStart, ReceiveCouponPeriodEnd, ReceiveDayCountMethod)
												END
                FROM   #DealSwap_Wf  
                WHERE DealSwapId = @tempDealSwapId

				UPDATE #DealSwap_Wf 
                SET ReceiveAmount = 
					CONVERT(decimal(35,16),ReceiveNotional) * CONVERT(decimal(18,16),(ReceiveRate/100)) * CONVERT(decimal(18,16),ReceiveDayCountFactor)
                FROM   #DealSwap_Wf  
                WHERE DealSwapId = @tempDealSwapId

				UPDATE #DealSwap_Wf 
                SET    NetAmount = ReceiveAmount - PayAmount 
                FROM   #DealSwap_Wf  
                WHERE DealSwapId = @tempDealSwapId

				   SET @tempDealSwapId =(SELECT TOP 1 DealSwapId 
                                FROM   cfgCb.DealSwap 
                                WHERE  DealId = @dealId 
								 AND DealSwapId > @tempDealSwapId 
                                ORDER  BY DealSwapId ASC) 
            END 


          DELETE FROM [Cb].[DealSwap_Wf] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[DealSwap_Wf] 
                      (  DealIpdRunId
						,DealSwapId
						,PayCouponPeriodStart
						,PayCouponPeriodEnd
						,PayDayCountFactor
						,PayNotional
						,PayBaseRate
						,PayRate
						,PayMarginDifferential
						,PayAmount
						,ReceiveCouponPeriodStart
						,ReceiveCouponPeriodEnd
						,ReceiveNotional
						,ReceiveBaseRate
						,ReceiveRate
						,ReceiveDayCountFactor
						,ReceiveAmount
						,NetAmount
						,IsActive
						,CreatedDate
						,CreatedBy
						,ModifiedDate
						,ModifiedBy) 
          SELECT  DealIpdRunId
						,DealSwapId
						,PayCouponPeriodStart
						,PayCouponPeriodEnd
						,PayDayCountFactor
						,PayNotional
						,PayBaseRate
						,PayRate
						,PayMarginDifferential
						,PayAmount
						,ReceiveCouponPeriodStart
						,ReceiveCouponPeriodEnd
						,ReceiveNotional
						,ReceiveBaseRate
						,ReceiveRate
						,ReceiveDayCountFactor
						,ReceiveAmount
						,NetAmount,
                 1, 
                 Getdate(), 
                 @pUserName, 
                 Getdate(), 
                 @pUserName 
          FROM   #DealSwap_Wf 

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessDealSwap', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 
END

GO