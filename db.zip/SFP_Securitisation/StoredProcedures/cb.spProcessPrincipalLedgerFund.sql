USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cb].[spProcessPrincipalLedgerFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessPrincipalLedgerFund]
GO

/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 11/17/2022 10:05:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessPrincipalLedgerFund] 
( 
  /* 
 *   Author: Arun 
 *   Date:  24.11.2022
 *   Description:  Fill Principal ledger Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessPrincipalLedgerFund] 96,'system'
 *    select * from [Cb].[SwapCollateralFund] where dealipdrunid=33           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
        

			DECLARE @dealId  INT, 
				@coveredBondFundId INT,
				@ipdDate DATE,
				@PrincipalLedgerFund_bF decimal(38,16),
				@PrincipalLedgerAmountReceived decimal(38,16),
				@PrincipalLedgerOthersReceived decimal(38, 16),
				@retainedPrincipalAmount decimal(38, 16),
				@releaseToAPR decimal(38, 16),
				@preAccelerationCredit decimal(38, 16),
				@PrincipalLedgerFund_cf  decimal(38, 16)

				  
			SELECT @dealId = DealId, 
			@ipdDate = IpdDate
			FROM   cw.vwDealIpdRun dir
			WHERE  DealIpdRunId = @pDealIpdRunId 
		  
			
			DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

			Select @coveredBondFundId = CoveredBondFundId FROM	cfgcb.CoveredBondFund cbf
                WHERE  cbf.InternalName = 'PrincipalLedgerFund' 

			SELECT @PrincipalLedgerFund_bF = PrincipalLedgerFund_cf
			FROM cb.[PrincipalLedgerFund] scf
			JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
			AND  cbf.InternalName = 'PrincipalLedgerFund'
			WHERE DealIpdRUnId = @dealPreviousIpdRunId

			
			Select @PrincipalLedgerAmountReceived = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName in ('PreAvailablePrincipalReceipts_1.100' , 'PreAvailablePrincipalReceipts_1.200')
			and DealIpdRunId=@pDealIpdRunId
		
			SET @PrincipalLedgerOthersReceived=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName   in ('ProceedTermAdvance', 'CashCapitalContributionsRecvdMember')
									AND ManualFieldGroupInternalName = 'AvailablePrincipalReceipts'
									AND DealIpdRunId = @pDealIpdRunId);
			
			Select @PrincipalLedgerOthersReceived = @PrincipalLedgerOthersReceived + IsNull(SUM(WaterFallLineItemRequiredAmount),0) --+  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='PreAvailablePrincipalReceipts_2.000'
			and DealIpdRunId=@pDealIpdRunId

			Select @releaseToAPR = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='PreAvailablePrincipalReceipts_8.000'
			and DealIpdRunId=@pDealIpdRunId

			

			SET @retainedPrincipalAmount=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='AmountretainedPrincipalLedger'
									AND ManualFieldGroupInternalName = 'AvailablePrincipalReceipts'
									AND DealIpdRunId = @pDealIpdRunId);

			Select @preAccelerationCredit = IsNull(SUM(WaterFallLineItemRequiredAmount),0) +  IsNull(SUM(WaterFallLineItemAdjustedAmount),0)
			From [CW].[vwWaterfallLineItemAmount]
			where WaterfallLineItemInternalName ='PrincipalPriorityofPayments_3.000'
			and DealIpdRunId=@pDealIpdRunId

			SET @PrincipalLedgerFund_cf = IsNull(@PrincipalLedgerFund_bF,0) + @PrincipalLedgerAmountReceived + @PrincipalLedgerOthersReceived
				-  @releaseToAPR + @retainedPrincipalAmount  + @preAccelerationCredit

			DELETE FROM cb.[PrincipalLedgerFund] WHERE DealIpdRunId = @pDealIpdRunId 

			INSERT INTO cb.[PrincipalLedgerFund] 
						  ( DealIpdRunId,
							CoveredBondFundId,
							PrincipalLedgerFund_bF,
							PrincipalLedgerReceiptsReceived,
							PrincipalLedgerOthersReceived,
							ReleaseToAPR,
							RetainedPrincipalAmount,
							PreAccelerationCredit,
							PrincipalLedgerFund_cf,
							IsActive,
							CreatedBy,
							CreatedDate,
							ModifiedBy,
							ModifiedDate) 
			SELECT @pDealIpdRunId
							,@coveredBondFundId
							,@PrincipalLedgerFund_bF
							,@PrincipalLedgerAmountReceived
							,@PrincipalLedgerOthersReceived
							,@releaseToAPR
							,@retainedPrincipalAmount
							,@preAccelerationCredit
							,@PrincipalLedgerFund_cf
							 ,1, 
							 @pUserName, 
							 Getdate(), 
							 @pUserName ,
							 Getdate()

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessPrincipalLedgerFund', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END