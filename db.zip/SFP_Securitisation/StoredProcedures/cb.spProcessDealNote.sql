USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessDealNote]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessDealNote]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessDealNote] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  10.01.2022
 *   Description:  Fill Deal Note table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date			Description 
 *   A.S.		06.06.2022		Add 2 columns i.e. CouponPaymentCalendarStartPeriod, CouponPaymentCalendarEndPeriod
 * 							Modified logic of CouponPaymentEndPeriod
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessDealNote] 49,'fm\shriyad'
 *    select * from [Cb].[DealNote_Wf] where dealipdrunid=49           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=65, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @dealId  INT, 
				  @ipdDate DATE,
                  @tempDealNoteId      INT, 
				  @PrincipalOutstanding_Ccy decimal(38,16),
				  @PrincipalOutstanding_GBP decimal(38,16),
				  @CollectionCalendarEnd datetime,
				  @IPDPlus12months datetime,
				  @PreviousIPD datetime,
				  @CouponPaymentStartPeriod datetime,
				  @CouponPaymentEndPeriod datetime,
				  @jurisdictionMarker varchar(200),
				  @CouponPaymentFrequency tinyint,
				  @LastCouponPaymentCalendarStartPeriod date,
				  @LastCouponPaymentCalendarEndPeriod date,
				  @CouponPaymentCalendarStartPeriod date,
				  @CalculationDate date,
				  @MaturityDate date,
				  @CouponPaymentCalendarEndPeriod date

          SELECT @dealId = DealId, 
				@ipdDate = IpdDate,
				@jurisdictionMarker = dlv.Value
          FROM   cw.vwDealIpdRun dir, cw.vw_DealLookup dlv
          WHERE  dlv.LookupValueId = dir.DealJurisdictionMarkerId AND DealIpdRunId = @pDealIpdRunId AND dlv.TypeCode= 'JurisdictionMarker'

		  SELECT @CollectionCalendarEnd = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId=@pDealIpdRunId AND DealDateKeyInternalName='CollectionCalendarEnd'

		  SELECT @IPDPlus12months = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId=@pDealIpdRunId AND DealDateKeyInternalName='IPD+12months'

		  SELECT @PreviousIPD = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId=@pDealIpdRunId AND DealDateKeyInternalName='PreviousIPD'

		  SELECT @CalculationDate = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId=@pDealIpdRunId AND DealDateKeyInternalName='CalculationDate'

		  DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

          IF Object_id('tempdb..#DealNote_Wf') IS NOT NULL 
            DROP TABLE #DealNote_Wf

          CREATE TABLE #DealNote_Wf
            ( 
				[DealIpdRunId] [int] NOT NULL,
				[DealNoteId] [int] NOT NULL,
				[PrincipalOutstanding_Ccy] [decimal](38, 16) NOT NULL,
				[PrincipalOutstanding_GBP] [decimal](38, 16) NOT NULL,
				[RemainingTermYears] [decimal](38, 16) NOT NULL,
				[FInalMaturityLTEq12MonthsOfCalculationForHardBullet] [bit] NOT NULL,
				[RequiredRedemptionForHardBullet] [bit] NULL,
				[ExtendedDueForExtendedBond_LTEq1yr] [bit] NULL,
				[RedemptionAmountForExtendedBond_LTEq1yr] [bit] NULL,
				[RedemptionAmountForExtendedBond_GT1yr] [bit] NULL,
				[RateForEstimation] [decimal](38, 16) NULL,
				[BaseRate] [decimal](38, 16) NULL,
				[Coupon] [decimal](38, 16) NULL,
				[CouponPaymentStartPeriod] [datetime] NULL,
				[CouponPaymentEndPeriod] [datetime] NULL,
				[DayCount] [int] NULL,
				[DayCountFactor] [decimal](38, 16) NULL,
				[InterestAmountDue_Ccy] [decimal](38, 16) NULL,
				[InterestAmountDue_GBP] [decimal](38, 16) NULL,
				[MaturityDate] datetime NULL,
				[EstimatedThreeMonthInterest_GBP] [decimal](38, 16) NULL,
				[DayCountMethodValue] varchar(200) NULL,
				[EstimatedOneMonthInterest_GBP] [decimal](38, 16) NULL,
				CouponPaymentCalendarStartPeriod date,
				CouponPaymentCalendarEndPeriod date,
				IsQuaterlyCouponFullyPayable INT
            ) 

          SET @tempDealNoteId =(SELECT TOP 1 DealNoteId 
                                FROM   cfgcb.DealNote dn
                                WHERE DealId = @dealId 
								AND ValidFrom<=GETDATE() AND ValidTo>=GETDATE()
								AND IssuanceDate<=@CalculationDate
                                ORDER  BY DealNoteId ASC) 

          WHILE( @tempDealNoteId > 0 ) 
            BEGIN 

				SELECT 
					  @PrincipalOutstanding_Ccy = PrincipalOutstanding_Ccy
					 ,@PrincipalOutstanding_GBP = PrincipalOutstanding_GBP
					 ,@CouponPaymentStartPeriod= IIF(@ipdDate < CouponPaymentEndPeriod
												OR	
														(MONTH(CouponPaymentEndPeriod)=MONTH(@ipdDate) AND YEAR(CouponPaymentEndPeriod)=YEAR(@ipdDate))
														, CouponPaymentStartPeriod
														, CouponPaymentEndPeriod)
					 ,@CouponPaymentFrequency=dlvCouponPaymentFrequency.Value 
					 ,@LastCouponPaymentCalendarStartPeriod=CouponPaymentCalendarStartPeriod
					 ,@LastCouponPaymentCalendarEndPeriod=CouponPaymentCalendarEndPeriod
					 ,@MaturityDate=ISNULL(NewRedemptionDate, MaturityDate) 
				FROM cb.DealNote_Wf dnwf
					JOIN cfgCb.DealNote dn ON dn.DealNoteId = dnwf.DealNoteId
					LEFT JOIN cw.vw_DealLookup dlvCouponPaymentFrequency ON dn.CouponPaymentFrequencyId = dlvCouponPaymentFrequency.LookupValueId
					AND  dlvCouponPaymentFrequency.TypeCode = 'IpdFrequency'
				WHERE dn.DealNoteId = @tempDealNoteId  
				AND DealIpdRUnId = @dealPreviousIpdRunId


				select @CouponPaymentCalendarStartPeriod = IIF (@IpdDate<@LastCouponPaymentCalendarEndPeriod
															OR	
														(MONTH(@LastCouponPaymentCalendarEndPeriod)=MONTH(@IpdDate) AND YEAR(@LastCouponPaymentCalendarEndPeriod)=YEAR(@IpdDate))
																	,@LastCouponPaymentCalendarStartPeriod 
																	,@LastCouponPaymentCalendarEndPeriod)
						,@CouponPaymentCalendarEndPeriod = NULL 
                FROM   cfgcb.DealNote dn 
					   LEFT JOIN cw.vw_DealLookup dlvCouponPaymentFrequency 
								ON dn.CouponPaymentFrequencyId = dlvCouponPaymentFrequency.LookupValueId
									AND  dlvCouponPaymentFrequency.TypeCode = 'IpdFrequency'
                WHERE  DealNoteId = @tempDealNoteId 
				

				select @CouponPaymentCalendarEndPeriod = IIF(@MaturityDate<IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
																, @MaturityDate
																, DATEADD(month
																			,@CouponPaymentFrequency
																			,@CouponPaymentCalendarStartPeriod) ), @MaturityDate, IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
																, @MaturityDate
																, DATEADD(month
																			,@CouponPaymentFrequency
																			,@CouponPaymentCalendarStartPeriod) ))
					, @CouponPaymentEndPeriod = IIF(IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
														, @MaturityDate
														, [cw].[fnGetBusinessDate](dateadd(day,1,dateadd(day,-1,dateadd(month,@CouponPaymentFrequency, @CouponPaymentCalendarStartPeriod))), @jurisdictionMarker, 0, 0) )< @MaturityDate
														
														,
														IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
														, @MaturityDate
														, [cw].[fnGetBusinessDate](dateadd(day,1,dateadd(day,-1,dateadd(month,@CouponPaymentFrequency, @CouponPaymentCalendarStartPeriod))), @jurisdictionMarker, 0, 0) )
														,
														@MaturityDate)
                FROM  cfgcb.DealNote dn 
                WHERE DealNoteId = @tempDealNoteId 

				--select @MaturityDate,@CouponPaymentCalendarStartPeriod, IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
				--												, @MaturityDate
				--												, DATEADD(month
				--															,@CouponPaymentFrequency
				--															,@CouponPaymentCalendarStartPeriod) ),
				--															IIF(@MaturityDate<IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
				--												, @MaturityDate
				--												, DATEADD(month
				--															,@CouponPaymentFrequency
				--															,@CouponPaymentCalendarStartPeriod) ), @MaturityDate, IIF(@MaturityDate <= @CouponPaymentCalendarStartPeriod
				--												, @MaturityDate
				--												, DATEADD(month
				--															,@CouponPaymentFrequency
				--															,@CouponPaymentCalendarStartPeriod) ))

				
                --FROM  cfgcb.DealNote dn 
                --WHERE DealNoteId = @tempDealNoteId 


                INSERT INTO #DealNote_Wf 
                            (DealIpdRunId
							,DealNoteId
							,PrincipalOutstanding_Ccy
							,PrincipalOutstanding_GBP
							,RemainingTermYears
							,FInalMaturityLTEq12MonthsOfCalculationForHardBullet
							,RequiredRedemptionForHardBullet
							,ExtendedDueForExtendedBond_LTEq1yr
							,RedemptionAmountForExtendedBond_LTEq1yr
							,RedemptionAmountForExtendedBond_GT1yr
							,RateForEstimation
							,BaseRate
							,Coupon
							,CouponPaymentStartPeriod
							,CouponPaymentEndPeriod
							,DayCount
							,DayCountFactor
							,InterestAmountDue_Ccy
							,InterestAmountDue_GBP
							,MaturityDate
							,EstimatedThreeMonthInterest_GBP
							,DayCountMethodValue
							,EstimatedOneMonthInterest_GBP
							,CouponPaymentCalendarStartPeriod
							,CouponPaymentCalendarEndPeriod
							,IsQuaterlyCouponFullyPayable
							) 
                 SELECT @pDealIpdRunId                       
						,DealNoteId 
						,IIF(@MaturityDate<=@CalculationDate ,0 ,@PrincipalOutstanding_Ccy) PrincipalOutstanding_Ccy
						,IIF(@MaturityDate<=@CalculationDate ,0 ,@PrincipalOutstanding_GBP) PrincipalOutstanding_GBP
						,IIF(@MaturityDate<@CollectionCalendarEnd,0
							,(DATEDIFF(day, @CollectionCalendarEnd, @MaturityDate))/CONVERT(decimal(38,12),365)) RemainingTermYears
						,IIF(dlvBullet.Value='Hard Bullet' AND @MaturityDate<@ipdDate,1,0) FInalMaturityLTEq12MonthsOfCalculationForHardBullet
						,NULL RequiredRedemptionForHardBullet
						,IIF(dlvBullet.Value='Soft Bullet' AND LegalFinalMaturityDate<@IPDPlus12months,1,0) ExtendedDueForExtendedBond_LTEq1yr
						,(dn.IssuanceAmount * ExtendedCoveredBond * IIF(dlvBullet.Value='Soft Bullet' AND LegalFinalMaturityDate<@IPDPlus12months,1,0))
								AS RedemptionAmountForExtendedBond_LTEq1yr
						,(dn.IssuanceAmount * ExtendedCoveredBond * IIF(dlvBullet.Value='Soft Bullet' AND LegalFinalMaturityDate<@IPDPlus12months,0,1))
								AS RedemptionAmountForExtendedBond_GT1yr
						,IIF(dlvRateType.Value='FIXED',CouponForFixed/100, COALESCE(ir.Rate,0)/100 + COALESCE(dn.Margin/10000,0)) RateForEstimation
						,IIF(dlvRateType.Value='FIXED',0,
							IIF(@ipdDate != @CouponPaymentEndPeriod,0
												,Round([Cb].[fnGetSoniaCompoundingCouponRate]
															(DayCountMethodId 
															-- DayCountFactor below
															,[Cb].[fnYearFracValue] (@CouponPaymentStartPeriod
																					,@CouponPaymentEndPeriod
																					,dlvDayCountMethod.Value)
															, @CouponPaymentStartPeriod
															, @CouponPaymentEndPeriod
															)
														,6)
								)
						) BaseRate
						,IIF(dlvRateType.Value='FIXED',CouponForFixed/100
							, --Base rate below
							IIF(dlvRateType.Value='FIXED',0,
								IIF(@ipdDate != @CouponPaymentEndPeriod,0
												,Round([Cb].[fnGetSoniaCompoundingCouponRate]
															(DayCountMethodId 
															-- DayCountFactor below
															,[Cb].[fnYearFracValue] (@CouponPaymentStartPeriod
																					,@CouponPaymentEndPeriod
																					,dlvDayCountMethod.Value)
															, @CouponPaymentStartPeriod
															, @CouponPaymentEndPeriod
															)
														,6)
								)
							)
							+ COALESCE(dn.Margin/10000,0)) 
							AS Coupon
						,@CouponPaymentStartPeriod CouponPaymentStartPeriod
						,@CouponPaymentEndPeriod CouponPaymentEndPeriod
						,DATEDIFF(day, @CouponPaymentCalendarStartPeriod, @CouponPaymentCalendarEndPeriod) DayCount
						,IIF(@CouponPaymentFrequency=12,1
								,[Cb].[fnYearFracValue] (@CouponPaymentCalendarStartPeriod,@CouponPaymentCalendarEndPeriod, dlvDayCountMethod.Value)) DayCountFactor
						,NULL InterestAmountDue_Ccy
						,NULL InterestAmountDue_GBP
						,@MaturityDate MaturityDate
						,NULL EstimatedThreeMonthInterest_GBP
						,dlvDayCountMethod.Value DayCountMethodValue
						,NULL EstimatedOneMonthInterest_GBP
						,@CouponPaymentCalendarStartPeriod CouponPaymentCalendarStartPeriod
						,@CouponPaymentCalendarEndPeriod CouponPaymentCalendarEndPeriod
						,dn.IsQuaterlyCouponFullyPayable
                FROM   cfgcb.DealNote dn 
						LEFT JOIN cw.vw_DealLookup dlvBullet ON dn.BulletId = dlvBullet.LookupValueId
					   AND  dlvBullet.TypeCode = 'Bullet'

					   LEFT JOIN cw.vw_DealLookup dlvRateType ON dn.RateTypeId = dlvRateType.LookupValueId
					   AND  dlvRateType.TypeCode = 'RateType'

					   LEFT JOIN cw.vw_DealLookup dlvDayCountMethod ON dn.DayCountMethodId = dlvDayCountMethod.LookupValueId
					   AND  dlvDayCountMethod.TypeCode = 'DayCountMethod'

					   LEFT JOIN cw.vw_DealLookup dlvBenchmark ON dn.BenchmarkId = dlvBenchmark.LookupValueId
					   AND  dlvBenchmark.TypeCode = 'Benchmark'

					   LEFT JOIN cw.vw_DealLookup dlvCouponPaymentFrequency ON dn.CouponPaymentFrequencyId = dlvCouponPaymentFrequency.LookupValueId
					   AND  dlvCouponPaymentFrequency.TypeCode = 'IpdFrequency'

					   LEFT JOIN cw.vwDealDate dd ON dd.DealIpdRunId = @pDealIpdRunId
					   AND  dd.DealDateKeyInternalName= 'CollectionBusinessEnd'

					   LEFT JOIN cw.interestRate ir ON ir.BaseDate = dd.DealDateValue
					   AND  ir.RICCode = dlvBenchmark.Value
                WHERE  DealNoteId = @tempDealNoteId 

                UPDATE #DealNote_Wf 
                SET		InterestAmountDue_Ccy = CONVERT(decimal(35,16),PrincipalOutstanding_Ccy)
												* CONVERT(decimal(18,16),Coupon) * CONVERT(decimal(18,16),DayCountFactor)
                ,		InterestAmountDue_GBP = CONVERT(decimal(35,16),PrincipalOutstanding_GBP)
												* CONVERT(decimal(18,16),Coupon) * CONVERT(decimal(18,16),DayCountFactor)
                FROM   #DealNote_Wf  
                WHERE DealNoteId = @tempDealNoteId 


				 UPDATE #DealNote_Wf 
                SET		EstimatedThreeMonthInterest_GBP = CONVERT(decimal(35,16),PrincipalOutstanding_GBP)
												* CONVERT(decimal(18,16),RateForEstimation) 
												* (CONVERT(decimal(18,16)
														,IIF(Round(((DATEDIFF(day, @ipdDate, MaturityDate)*12)/365.0),0)<3, 
																		Case When IsQuaterlyCouponFullyPayable =1  Then 
																			CASE WHEN DATEDIFF(day, @ipdDate, MaturityDate) > 0 THEN  3 ELSE 0 END
																			Else Round(((DATEDIFF(day, @ipdDate, MaturityDate)*12)/365.0),0) END
																	, 3)
															)
												/12)
                ,		EstimatedOneMonthInterest_GBP = CONVERT(decimal(35,16),PrincipalOutstanding_GBP)
														* CONVERT(decimal(18,16),RateForEstimation) 
														* IIF(@ipdDate>=@MaturityDate,0,CONVERT(decimal(18,16),[Cb].[fnYearFracValue]	(@PreviousIPD
																					,@ipdDate
																					,DayCountMethodValue)))
                FROM   #DealNote_Wf  
                WHERE DealNoteId = @tempDealNoteId 


				   SET @tempDealNoteId =(SELECT TOP 1 DealNoteId 
											FROM   cfgcb.DealNote dn
											WHERE DealId = @dealId 
											AND ValidFrom<=GETDATE() AND ValidTo>=GETDATE()
											AND DealNoteId > @tempDealNoteId 
											AND IssuanceDate<=@CalculationDate
											ORDER  BY DealNoteId ASC) 
            END 

			--select * from #DealNote_Wf

          DELETE FROM [Cb].[DealNote_Wf] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[DealNote_Wf] 
                      ( DealIpdRunId
						,DealNoteId
						,PrincipalOutstanding_Ccy
						,PrincipalOutstanding_GBP
						,RemainingTermYears
						,FInalMaturityLTEq12MonthsOfCalculationForHardBullet
						,RequiredRedemptionForHardBullet
						,ExtendedDueForExtendedBond_LTEq1yr
						,RedemptionAmountForExtendedBond_LTEq1yr
						,RedemptionAmountForExtendedBond_GT1yr
						,RateForEstimation
						,BaseRate
						,Coupon
						,CouponPaymentStartPeriod
						,CouponPaymentEndPeriod
						,DayCount
						,DayCountFactor
						,InterestAmountDue_Ccy
						,InterestAmountDue_GBP
						,EstimatedThreeMonthInterest_GBP
						,EstimatedOneMonthInterest_GBP
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate
						,CouponPaymentCalendarStartPeriod 
						,CouponPaymentCalendarEndPeriod) 
          SELECT  DealIpdRunId
				,DealNoteId
				,PrincipalOutstanding_Ccy
				,PrincipalOutstanding_GBP
				,RemainingTermYears
				,FInalMaturityLTEq12MonthsOfCalculationForHardBullet
				,RequiredRedemptionForHardBullet
				,ExtendedDueForExtendedBond_LTEq1yr
				,RedemptionAmountForExtendedBond_LTEq1yr
				,RedemptionAmountForExtendedBond_GT1yr
				,RateForEstimation
				,BaseRate
				,Coupon
				,CouponPaymentStartPeriod
				,CouponPaymentEndPeriod
				,DayCount
				,DayCountFactor
				,InterestAmountDue_Ccy
				,InterestAmountDue_GBP
				,EstimatedThreeMonthInterest_GBP
				,EstimatedOneMonthInterest_GBP
                 ,1, 
                 @pUserName, 
                 Getdate(), 
                 @pUserName ,
				 Getdate(),
				 CouponPaymentCalendarStartPeriod,
				CouponPaymentCalendarEndPeriod
          FROM   #DealNote_Wf 

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessDealNote', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO