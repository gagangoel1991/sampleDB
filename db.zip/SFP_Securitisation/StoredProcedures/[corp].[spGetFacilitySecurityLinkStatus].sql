USE SFP_Securitisation
GO

IF OBJECT_ID('[corp].[spGetFacilitySecurityLinkStatus]') IS NOT NULL
	DROP PROCEDURE corp.[spGetFacilitySecurityLinkStatus]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-------------------------------------------------------  
Author: Sakthivel Loganathan
Date: 24 Oct 2022  
Description: To fetch the list of Relinked/Unlinked facility-securityies.
EXEC [corp].[spGetFacilitySecurityLinkStatus] @pDealID = 1, @pAsAtDate= '2022-06-30',@pPreviousReportingDate = '2022-05-31', @pUserName = 'logasll'
*/

CREATE PROCEDURE [corp].[spGetFacilitySecurityLinkStatus]
	@pDealId INT, 	
	@pAsAtDate DATE,
	@pPreviousReportingDate DATE,
	@pUserName VARCHAR(50)
AS
BEGIN
	BEGIN TRY

		CREATE TABLE #TmpLinkageTable
		(
		 SecurityId VARCHAR(20), 
		 ConnectionId VARCHAR(20),
		 CradleSecurityId VARCHAR(50), 
		 FacilityId VARCHAR(10),  
		 SecurityKey VARCHAR(10),  
		 IsLinked INT 
		)

		INSERT INTO #TmpLinkageTable(SecurityId, ConnectionId, CradleSecurityId,FacilityId,SecurityKey)
		--EXEC [SFP_MODEL_CORPORATE].[RPT].[spGetFacilitySecurityLinkComparisionReport] @pDealID = @pDealId, @pAsAtDate= @pAsAtDate,@pPreviousReportingDate = @pPreviousReportingDate
		EXEC [corp].[syn_Corporate_sp_rpt_GetFacilitySecurityLinkCompare] @pDealID = @pDealId, @pAsAtDate= @pAsAtDate,@pPreviousReportingDate = @pPreviousReportingDate
  
		DECLARE @DealOverrideParentId INT = (SELECT MAX(DealOverrideParentId) 
											 FROM [corp].[DealOverrideParent] WHERE DealId = @pDealId AND AsAtDate = @pAsAtDate)

		SELECT lnk.FacilityId, lnk.SecurityId, lnk.CradleSecurityId , ConnectionId, SecurityKey, IsLinked  
		INTO #TmpLinkList  
		FROM [corp].[DealOverrideParent] DDP   
		INNER JOIN [corp].[DealDataCorrection] DDC ON DDP.DealOverrideParentId = DDC.DealOverrideParentId   
		INNER JOIN [corp].[DealDataCorrectionLinkage] lnk ON lnk.DealDataCorrectionId = DDC.DealDataCorrectionId  
		WHERE DDP.DealOverrideParentId = @DealOverrideParentId 


		UPDATE Src
		SET Src.IsLinked = 1 
		FROM #TmpLinkageTable Src 
		INNER JOIN #TmpLinkList linked
		 ON Src.FacilityId = linked.FacilityId   
		  AND Src.SecurityId = linked.SecurityId  
		  AND Src.ConnectionId = linked.ConnectionId
		  AND linked.IsLinked = 1  

		SELECT  * FROM #TmpLinkageTable ORDER BY IsLinked Desc, FacilityId, SecurityId, SecurityKey, CradleSecurityId

	END TRY
	
	BEGIN CATCH

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION SFP_Sec_SaveAdhocReportTemplate
		END

		EXEC app.SaveErrorLog 2, 1, 'spGetUpdateOverrideList', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
End

GO
-- EXEC [corp].[spGetFacilitySecurityLinkStatus] @pDealID = 1, @pAsAtDate= '2022-06-30',@pPreviousReportingDate = '2022-05-31', @pUserName = 'logasll'
