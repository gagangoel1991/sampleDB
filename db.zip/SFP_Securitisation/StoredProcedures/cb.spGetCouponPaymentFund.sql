USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetCouponPaymentFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetCouponPaymentFund]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 17-05-2021 
--Description: GET Coupon Payment Fund  
--[cb].[spGetCouponPaymentFund] 6,35,''
--==================================   
CREATE PROCEDURE [cb].[spGetCouponPaymentFund] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
		SELECT CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
			,CASE tr.IsBreached WHEN 1 THEN 'FAIL' WHEN 0 THEN 'PASS' END AS TestResult
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN wliParent.ParentLineItemId
				ELSE ISNULL(litem.ParentLineItemId, 0)
				END ParentId
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN 1
				ELSE 0
				END IsSubLineItems
			,litem.DisplayTextUI
			,litem.FieldName
			,cp_preWf.CouponPayment_bF AS CouponPayment_bf
			,cp_preWf.FinalRequiredAmount
			,cp_preWf.RequiredAmount1
			,cp_preWf.DueAmount
			,cp_preWf.ResidualAmount
			,cp_preWf.CapitalContribution
			,cp_postWf.CreditReceived
			,cp_postWf.CouponPayment_cf
		FROM cfgcb.CoveredBondFund cbf
		JOIN [cfgcb].[CoveredBondFundLineItemUI] litem ON cbf.CoveredBondFundId = litem.CoveredBondFundId
		LEFT JOIN (
			SELECT DISTINCT ParentLineItemId
			FROM [cfgcb].[CoveredBondFundLineItemUI]
			) AS wliParent ON wliParent.ParentLineItemId = litem.CoveredBondFundLineItemId
		JOIN cb.CouponPaymentFund_PreWf cp_preWf ON cbf.CoveredBondFundId = cp_preWf.CoveredBondFundId
			AND cp_preWf.IsActive = 1
		JOIN cw.vwdealipdrun dir ON dir.DealIpdRunId = cp_preWf.DealIpdRunId
		LEFT JOIN [cw].[vwDealIpdTriggerResult] tr ON cbf.ApplicableId = tr.TriggerId
			AND tr.DealIpdRunId = dir.DealIpdRunId
		LEFT JOIN cb.CouponPaymentFund_PostWf cp_postWf ON cbf.CoveredBondFundId = cp_postWf.CoveredBondFundId
			AND cp_postWf.IsActive = 1
			AND dir.DealIpdRunId = cp_postWf.DealIpdRunId
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
			AND cbf.InternalName = 'CouponPaymentFund'
			AND cbf.DealId = @pDealId
		ORDER BY dir.IpdDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetCouponPaymentFund'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO


