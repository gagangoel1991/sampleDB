USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetKeyValueLookupData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetKeyValueLookupData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetKeyValueLookupData]
	/*
Author: Kapil Sharma
Date:	18.12.2020
Description:  This will different types of data in key value format
				
Change History
--------------
Author		Date		Description
-------------------------------------------------------
*/
	@pKeyValueTypeIds VARCHAR(20)
	,@pUserName VARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @typeId VARCHAR(10)
		DECLARE @LookupTable TABLE (
			LookupTypeId INT
			,[Key] INT
			,Value VARCHAR(500)
			)

		DECLARE keyValueCursor CURSOR
		FOR
		SELECT Value
		FROM app.udfSplitString(@pKeyValueTypeIds, ',')

		OPEN keyValueCursor

		FETCH NEXT
		FROM keyValueCursor
		INTO @typeId

		WHILE @@FETCH_STATUS = 0
		BEGIN
			IF @typeId = '1' -- Active Deal Names
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,DealId
					,DealName
				FROM cw.vw_ActiveDeal WHERE AssetClassId = 1
			END
			ELSE IF @typeId = '2' -- IR Strat Template
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,StratTemplateId
					,Name
				FROM cfgCW.IR_StratTemplate
			END
			ELSE IF @typeId = '3' -- IR Report Layout
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,ReportLayoutId
					,Name
				FROM cfgCW.IR_ReportLayout
			END
			ELSE IF @typeId = '4' --Asset Strat List
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,StratId
					,strat.Name
				FROM cfgCW.IR_Strat strat
				JOIN cfgCW.IR_StratType st ON st.StratTypeId = strat.StratTypeId
				WHERE st.Name = 'Asset'
			END
			ELSE IF @typeId = '5' --Liability Strat List
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,StratId
					,strat.Name
				FROM cfgCW.IR_Strat strat
				JOIN cfgCW.IR_StratType st ON st.StratTypeId = strat.StratTypeId
				WHERE st.Name = 'Liability'
			END
			ELSE IF @typeId = '6' --Miscellaneous Strat List
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,StratId
					,strat.Name
				FROM cfgCW.IR_Strat strat
				JOIN cfgCW.IR_StratType st ON st.StratTypeId = strat.StratTypeId
				WHERE st.Name = 'Miscellaneous'
			END
			ELSE IF @typeId = '7' --Currency List  
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,c.CurrencyId
					,c.Code
				FROM cfgCW.Currency c
				WHERE c.IsActive = 1
			END
			ELSE IF @typeId = '8' -- REPLInes Report Deal
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,MortgageDealKey
					,DealName
				FROM [sfp].[syn_SfpModel_vw_MortgageDeal_v1]
			END
			ELSE IF @typeId = '9' -- deal currency
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,d.DealId
					,c.Code
				FROM cfg.Deal d
				JOIN cfgCw.Currency c ON d.DealCurrencyId = c.CurrencyId
				WHERE d.IsActive = 1
			END
			ELSE IF @typeId = '10' -- Reference Registry Report Deal  
		    	BEGIN  
				INSERT INTO @LookupTable (  
				 LookupTypeId  
				 ,[Key]  
				 ,Value  
				 )
				SELECT @typeId,deals.DealID, deals.DealName 
				FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] deals
				INNER JOIN PS.[DealReportTemplateMap] map ON deals.DealID = map.DealID
				where deals.IsActive = 'Y' and map.IsActive = 1
		   	END
		   	ELSE IF @typeId = '11' -- Reference Registry Report Template  
		   	BEGIN 
				DECLARE @AssetClassId int = (SELECT AssetClassId FROM ps.AssetClass WHERE CODE = 'CL')
				DECLARE @ReportTypeId INT = (SELECT AdhocReportTypeId FROM PS.AdhocReportType WHERE ReportTypeName = 'Reference registry')

				INSERT INTO @LookupTable (  
				 LookupTypeId  
				 ,[Key]  
				 ,Value  
				 )
				 SELECT @typeId,PoolAdhocReportTemplateId,ReportTemplateName 
				 FROM [ps].[PoolAdhocReportTemplate] where IsActive = 1 and AssetClassId = @AssetClassId and ReportTypeId = @ReportTypeId
		   	END
			ELSE IF @typeId = '12' -- Active Deal Names For ESMA Reports  
			BEGIN  
				INSERT INTO @LookupTable (  
					LookupTypeId  
					,[Key]  
					,Value  
					)  
				SELECT @typeId  
					,DealId  
					,DealName  
				FROM cw.vw_ActiveDeal where DealStatusDisplayName = 'Active' and AssetClassId = 1
			END
			ELSE IF @typeId = '13' -- Reference Registry Deals  
		   	BEGIN 
				INSERT INTO @LookupTable (  
				  LookupTypeId  
				 ,[Key]  
				 ,Value  
				 )
				SELECT @typeId
					,DealId
					,DealName
				FROM [corp].[vwActiveDeal]
				
					
				ORDER BY DealName;
		   	END
			ELSE IF @typeId = '14' -- CB Active Deal Names
			BEGIN
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,DealId
					,DealName
				FROM corp.vwActiveDeal
			END
			ELSE IF @typeId = '15' -- Active Brands
			BEGIN  
				INSERT INTO @LookupTable (  
					LookupTypeId  
					,[Key]  
					,Value  
					)  
					SELECT @typeId  
					,DealBrandId  
					,[Name]  
				FROM [cfgCW].[DealBrand] where IsActive = 1 
			END
			 ELSE IF @typeId = '16' -- Corporate Pools 
			 BEGIN    
				INSERT INTO @LookupTable ( LookupTypeId,[Key],Value)    
				SELECT @typeId,poolid,[Name]    
				FROM ps.pool 
				WHERE AssetClassId = 2
						AND PoolStatusId IN (SELECT PoolStatusId FROM ps.PoolStatus WHERE STATUS NOT IN ('Draft', 'Rejected')) 
						AND IsActive = 1
			  END
			   ELSE IF @typeId = '17' --- Provide All Collapse Deal Except ARDMORE1
			 BEGIN    
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,DealId
					,DealName
				FROM cw.vw_ActiveDeal WHERE DealStatus = 'Collapse' AND DealName <> 'ARDMORE1'
			  END
			  ELSE IF @typeId = '18' --- Provide EarlyRedemptionDate for the Collapse Deal
			 BEGIN    
				INSERT INTO @LookupTable (
					LookupTypeId
					,[Key]
					,Value
					)
				SELECT @typeId
					,DealId
					,EarlyRedemptionDate
				FROM cw.vw_ActiveDeal WHERE DealStatus = 'Collapse' AND DealName <> 'ARDMORE1'
			  END 

			FETCH NEXT
			FROM keyValueCursor
			INTO @typeId
		END

		CLOSE keyValueCursor;

		DEALLOCATE keyValueCursor;

		SELECT LookupTypeId
			,[Key]
			,Value
		FROM @LookupTable
		ORDER BY LookupTypeId
			,Value
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetKeyValueLookupData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO

