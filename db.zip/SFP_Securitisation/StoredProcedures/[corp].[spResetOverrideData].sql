USE SFP_Securitisation
GO

IF OBJECT_ID('[corp].[spResetOverrideData]') IS NOT NULL
	DROP PROCEDURE corp.[spResetOverrideData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[spResetOverrideData]  
(  
 @pDealOverrideParentId INT, 
 @pEntityName VARCHAR(20) = '',  
 @pDataOverrideResult INT OUTPUT  
)  
AS
BEGIN  
	DECLARE @pEntityId INT   
	SELECT @pEntityId = ( SELECT DealDataCorrectionEntityId FROM [corp].[DealDataCorrectionEntity] WHERE EntityName = @pEntityName)
  
	DELETE FROM [corp].[DealDataCorrectionDetail] 
	WHERE DealDataCorrectionId = (SELECT DealDataCorrectionId FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @pDealOverrideParentId 
			AND EntityTypeId = @pEntityId)

	DELETE FROM [corp].[DealDataCorrectionLinkage] 
	WHERE DealDataCorrectionId = (SELECT DealDataCorrectionId FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @pDealOverrideParentId 
			AND EntityTypeId = @pEntityId)

	DELETE FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @pDealOverrideParentId AND EntityTypeId = @pEntityId

	IF NOT EXISTS (SELECT 1 FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @pDealOverrideParentId)
	BEGIN
		DELETE FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @pDealOverrideParentId
	END

	SET @pDataOverrideResult = 1
END
GO
