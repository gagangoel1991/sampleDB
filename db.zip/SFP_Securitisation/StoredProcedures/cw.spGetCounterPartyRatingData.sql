USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetCounterPartyRatingData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetCounterPartyRatingData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetCounterPartyRatingData]
	/*  
 * Author: Gunjan Chandola  
 * Date: 26.03.2021  
 * Description:  This will return CP rating data based collection business date and IPD Run ID 
 * [cw].[spGetCounterPartyRatingData] 14,75,'Test'
 * Change History  
 * --------------  
 * Author | Date | Description 
 * Saurabh Bhatia | 22-06-2021 | Changes to get data from user tables 
 * --------------  
 * Author | Date | Description 
 * Saurabh Bhatia | 01-11-2021 | New Column IsPrevIpdRating added 
 * --------------  
 * Author | Date | Description 
 * Suresh Pandey | 03-02-2022 | Added logic to call cw or cb rating master data sp 
 * ----------------------------------------------------------------- 
*/
	@pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @ColsCisCodeWhere AS NVARCHAR(MAX)
			,@ColsCisCodeSelect AS NVARCHAR(MAX)
			,@collectionStartDate DATE
			,@collectionEndDate DATE
			,@query VARCHAR(MAX)
			,@RatingDate DATE
			,@seprator varchar(20) = ' | '
			,@dealType VARCHAR(100);

		SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

		SELECT @collectionStartDate = CAST(CollectionBusinessStart AS DATE)
			,@collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
		FROM [cw].[vwDealIpdDates] ipdDt
		JOIN cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE ipdRun.RunId = @pIPDRunId


		IF OBJECT_ID('tempdb..#tempCpRating') IS NOT NULL
			DROP TABLE #tempCpRating

		CREATE TABLE #tempCpRatingMasterData (
			[UniqueIdentifier] VARCHAR(200)
			,[CRAId] INT
			,[CRA] VARCHAR(200)
			,[RatingTypeId] INT
			,[RatingType] VARCHAR(200)
			,[Rating] VARCHAR(200)
			,[Type] VARCHAR(200)
			);

		IF (@dealType='Covered Bond')
		BEGIN
			INSERT INTO #tempCpRatingMasterData
			EXEC cb.spGetRatingMasterData @pDealId
		END
		ELSE IF(@dealType='RMBS')
		BEGIN
			INSERT INTO #tempCpRatingMasterData
			EXEC cw.spGetRatingMasterData @pDealId
		END

		DELETE
		FROM #tempCpRatingMasterData
		WHERE [Type] <> 'Counterparty'

		SET @RatingDate = ISNULL((
					SELECT CAST(MAX(cr.RatingDate) AS DATE)
					FROM CW.vwCounterpartyRating cr
					JOIN #tempCpRatingMasterData tcr ON tcr.[CRAId]=cr.[CRAId] AND tcr.[RatingTypeId]=cr.[RatingTypeId]
					WHERE CAST(cr.RatingDate AS DATE) BETWEEN @collectionStartDate
							AND @collectionEndDate						
					), @collectionEndDate);


		SELECT DISTINCT cpr.SourceCPRatingId
			,cpr.UserCounterpartyRatingId
			,CASE 
				WHEN @RatingDate = @collectionEndDate
					THEN 0
				ELSE 1
				END AS IsPostCollectionEndDate
			,tempBondData.[UniqueIdentifier] AS CisCode
			,dcp.CounterpartyName
			,tempBondData.CRAId
			,tempBondData.CRA AS RatingAgency
			,tempBondData.RatingTypeId
			,tempBondData.[RatingType] AS RatingType
			,ISNULL(cpr.Rating, '') AS Rating
			,CAST(@RatingDate AS DATE) AS RatingDate
			,IIF(SourceCPRatingId IS NOT NULL,NULL,cpr.ModifiedBy) AS ModifiedBy
			,IIF(SourceCPRatingId IS NOT NULL,NULL,cpr.ModifiedDate) AS ModifiedDate
			,cpr.IsPrevIpdRating
			,cpr.Comment			
		INTO #tempCpRating
		FROM #tempCpRatingMasterData tempBondData
		INNER JOIN cfgcw.DealCounterparty dcp ON tempBondData.[UniqueIdentifier] = dcp.CisCode  AND dcp.DealId = @pDealId  
		JOIN [CW].[vw_DealLookup] dlv ON dlv.LookupValueId = dcp.DealCounterpartyTypeId
		LEFT JOIN cw.vwCounterpartyRating cpr ON CAST(cpr.RatingDate AS DATE) = @RatingDate
			AND tempBondData.[UniqueIdentifier] = cpr.CisCode
			AND tempBondData.CRAId = cpr.CRAId
			AND tempBondData.RatingTypeId = cpr.RatingTypeId
		Where dlv.Name <> 'Booking' 

		SELECT @ColsCisCodeWhere = STUFF((
					SELECT DISTINCT ',' + CAST(CisCode AS NVARCHAR(20))
					FROM #tempCpRating
					FOR XML PATH('')
						,TYPE
					).value('.', 'NVARCHAR(MAX)'), 1, 1, '');

		SELECT @ColsCisCodeSelect = STUFF((
					SELECT DISTINCT ',MAX(' + CAST(CisCode AS NVARCHAR(20)) + ') as [' + CAST(CisCode AS NVARCHAR(20)) + @seprator + CounterpartyName + ']'
					FROM #tempCpRating
					FOR XML PATH('')
						,TYPE
					).value('.', 'NVARCHAR(MAX)'), 1, 1, '');
		
		
		SET @query = '	
				SELECT 
				 null as SourceCPRatingId
				,IsPostCollectionEndDate				
				,CRAId
				,RatingAgency
				,RatingTypeId
				,RatingType				
				,RatingDate				
				,MAX(IIF(row_num<>1,null, ModifiedBy)) as ModifiedBy
				,MAX(ModifiedDate) AS ModifiedDate
				,MAX(IIF(row_num<>1,null, Comment)) as Reason				
				,IIF( SUM(IIF(UserCounterpartyRatingId IS NOT NULL,1,0)) = SUM(IIF(UserCounterpartyRatingId IS NOT NULL and IsPrevIpdRating = 1,1,0)) AND SUM(IIF(UserCounterpartyRatingId IS NOT NULL and IsPrevIpdRating = 1,1,0)) <> 0,1,0 ) AS IsPrevIpdRating
				,' + @ColsCisCodeSelect + '
			FROM (			
					SELECT  
					ROW_NUMBER() OVER (
					     PARTITION BY CRAId,RatingTypeId
					     ORDER BY ModifiedDate desc
					  ) row_num,*
					FROM #tempCpRating
					PIVOT(MAX(Rating) FOR CisCode IN (' + @ColsCisCodeWhere + ')) AS Pivot_Table
			) AS x 
			GROUP BY				
				 IsPostCollectionEndDate				
				,CRAId
				,RatingAgency
				,RatingTypeId
				,RatingType				
						
				,RatingDate
				
		'

		PRINT @query

		EXECUTE (@query)
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'[cw].[spGetCPRatingData]'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


