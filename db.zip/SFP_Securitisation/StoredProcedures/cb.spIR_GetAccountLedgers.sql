USE SFP_Securitisation
GO

IF OBJECT_ID('cb.spIR_GetAccountLedgers') IS NOT NULL
	DROP PROC cb.spIR_GetAccountLedgers
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE cb.spIR_GetAccountLedgers
(
	 @pAsAtDate DATETIME
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
)


-----------------------------------------------------
--Author: Arun 
--Date:	09-Feb-2022
--Description: This SP is Used to Get Accounts and Ledgers

--EXEC cb.spIR_GetAccountLedgers '2021-04-30','DEIMOS'
--go
--EXEC cb.spIR_GetAccountLedgers '2021-05-28','DEIMOS'

-----------------------------------------------------


AS
BEGIN

	BEGIN TRY
		
		DECLARE @dealIpdRunId        INT,
		@previousDealIpdRunId		 INT,
		@previousIpdDate			 Date,
        @dealId              SMALLINT;
        

		SELECT 
			@dealIpdRunId = dir.DealIpdRunId
			, @previousIpdDate  = dt.PreviousIPD  
			, @dealId = dir.DealId
		FROM   
			cw.vwDealIpdDates dt
		JOIN
			cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId AND dir.DealId = dt.DealId
		WHERE	
			dir.InternalDealName = @pDealName
			AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)


		        
		SELECT @previousDealIpdRunId = RunId FROM cw.DealIpdRun dir  
		JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
		WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1  


		SELECT wc.InternalName AS InternalName, wli.DisplayName, wlia.TotalRequiredAmount
		INTO #TblCurrentPeriod
		FROM  [cfgCW].[WaterfallCategory] wc
		INNER JOIN [cfgCW].[WaterfallLineItem]  wli ON wli.WaterfallCategoryID = wc.WaterfallCategoryID
		INNER JOIN [CW].WaterfallLineItemAmount wlia  ON wli.WaterfallLineItemId = wlia.WaterfallLineItemId 
		WHERE wc.DealID=@dealId
		AND wli.DisplayName='Total'
		AND wc.InternalName IN ( 'PreAvailableRevenueReceipts', 'PreAvailablePrincipalReceipts' )
		AND wlia.DealIpdRunId = @dealIpdRunId
		UNION ALL
		SELECT 'Reserve Fund', 'Fund_Cf',  ReserveFund_cf
		FROM cb.ReserveFund_PostWF WHERE DealIpdRunId = @dealIpdRunId

	
		SELECT wc.InternalName AS InternalName, wli.DisplayName, wlia.TotalRequiredAmount 
		INTO #TblPreviousPeriod
		FROM  [cfgCW].[WaterfallCategory] wc
		INNER JOIN [cfgCW].[WaterfallLineItem]  wli ON wli.WaterfallCategoryID = wc.WaterfallCategoryID
		INNER JOIN [CW].WaterfallLineItemAmount wlia  ON wli.WaterfallLineItemId = wlia.WaterfallLineItemId 
		WHERE wc.DealID=@dealId
		AND wli.DisplayName='Total'
		AND wc.InternalName IN ( 'PreAvailableRevenueReceipts', 'PreAvailablePrincipalReceipts' )
		AND wlia.DealIpdRunId = @previousDealIpdRunId
		UNION ALL
		SELECT 'Reserve Fund', 'Fund_Cf',  ReserveFund_cf
		FROM cb.ReserveFund_PostWF WHERE DealIpdRunId = @previousDealIpdRunId
	

		CREATE TABLE #OutPut ( SortNo INT IDENTITY(1,1), Header varchar(max), SubHeaderValue nvarchar(max)) 
		INSERT INTO #OutPut
		SELECT 'Revenue Receipts', 'PreAvailableRevenueReceipts'
		UNION ALL
		SELECT 'Principal Receipts', 'PreAvailablePrincipalReceipts'
		UNION ALL
		SELECT 'Reserve Ledger', 'Reserve Fund'
		UNION ALL
		SELECT 'Revenue Ledger', 'Revenue Ledger'
		UNION ALL
		SELECT 'Principal Ledger', 'Principal Ledger'
		UNION ALL
		SELECT 'Pre-maturity Liquidity Ledger', 'Pre-maturity Liquidity Ledger'
	


		--Select O.Header, C.TotalRequiredAmount [Current Period (GBP)], P.TotalRequiredAmount [Previous Period (GBP)], Case When O.Header='Reserve Ledger' Then  IsNull(CAST(C.TotalRequiredAmount as Varchar(30)), 'N/A') Else 'N/A' End as [Targeted Value (GBP)]
		SELECT O.Header, CAST(isNull(C.TotalRequiredAmount,0) AS DECIMAL(38,4)) [Current Period (GBP)], CAST(isNull(P.TotalRequiredAmount,0) AS DECIMAL(38,4)) [Previous Period (GBP)], CASE WHEN O.Header='Reserve Ledger' THEN  IsNull(CAST(C.TotalRequiredAmount AS Varchar(30)), 'N/A') ELSE 'N/A' END AS [Targeted Value (GBP)]
		FROM #OutPut O
		LEFT JOIN #TblCurrentPeriod C ON C.InternalName = O.SubHeaderValue
		LEFT JOIN #TblPreviousPeriod P ON P.InternalName = O.SubHeaderValue
		ORDER BY SortNo

	END TRY 

    BEGIN CATCH  
		
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetAccountLedgers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  
END

Go



