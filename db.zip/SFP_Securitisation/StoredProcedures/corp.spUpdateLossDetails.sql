USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spUpdateLossDetails]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spUpdateLossDetails]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 06-Oct-2022
Description    : This will update Loss Management data
Execution      : EXEC [corp].[spUpdateLossDetails] 1, '2022-10-06', '2022-10-06', '2022-10-06', '2022-10-06', '2022-08-31', 1, 123, 0.2, 'Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spUpdateLossDetails]    
(                                  
	@pLossManagementId INT,
	@pCreditEventNoticeDate DATE = NULL,
	@pEvidenceSentDate DATE = NULL,
	@pCreditEventVerifiedDate DATE = NULL,
	@pWaterfallDateClaimed DATE = NULL,
	@pFxRateDate DATE = NULL,
	@pDefaultDate DATE = NULL,
	@pCreditEventTypeId INT = NULL,
	@pExposureAtDefault DECIMAL(19, 6) = NULL,
	@pCurrentExposure DECIMAL(19, 6) = NULL,
	@pInitialLossPercent DECIMAL(19, 6) = NULL,
	@pInitialLossAmount DECIMAL(19, 6) = NULL,
	@pFinalLossAmount DECIMAL(19, 6) = NULL,
	@pInitialVerifiedLossAmount DECIMAL(19, 6) = NULL,
	@pRealisedRecoveries DECIMAL(19, 6) = NULL,
	@pAdjustedRecoveries DECIMAL(19, 6) = NULL,
	@pFinalEstimatedRecoveries DECIMAL(19, 6) = NULL,
	@pTotalAdjustedRecoveries DECIMAL(19, 6) = NULL,
	@pTotalLossAmount DECIMAL(19, 6) = NULL,
	@pFinalWaterfallCalculationNumber DECIMAL(19, 6) = NULL,
	@pCreditLossEventAmount DECIMAL(19, 6) = NULL,
	@pRestructuredPrincipalAmount DECIMAL(19, 6) = NULL,
	@pFinalVerificationDate DATE = NULL,
	@pWaterfallDate DATE = NULL,
	@pUserName VARCHAR(50) = NULL,
	@pComments VARCHAR(500) = NULL,
	@pDefaultedNotional DECIMAL(19, 2) = NULL,
	@pFacilitySharePercent DECIMAL(15, 14) = NULL,
	@pAccountStatus Varchar(200) =NULL,
	@pRecoverySource INT =NULL,
	@pDefaultReason Varchar(200) =NULL,
	@pMGS27DefaultAmount DECIMAL(19, 6) = NULL,
	@pMGS27DefaultDate DATE = NULL
)
AS                                   
BEGIN                                   
	BEGIN TRY                   
	    
		UPDATE [corp].[LossManagement]
		SET [CreditEventNoticeDate] = @pCreditEventNoticeDate
			,[EvidenceSentDate] = @pEvidenceSentDate
			,[CreditEventVerifiedDate] = @pCreditEventVerifiedDate
			,[WaterfallDateClaimed] = @pWaterfallDateClaimed
			,[FxRateDate] = @pFxRateDate
			,[DefaultDate] = @pDefaultDate
			,[CreditEventTypeId] = @pCreditEventTypeId
			,[ExposureAtDefault] = @pExposureAtDefault
			,[CurrentExposure] = @pCurrentExposure
			,[InitialLossPercent] = @pInitialLossPercent
			,[InitialLossAmount] = @pInitialLossAmount
			,[FinalLossAmount] = @pFinalLossAmount
			,[InitialVerifiedLossAmount] = @pInitialVerifiedLossAmount
			,[RealisedRecoveries] = @pRealisedRecoveries
			,[AdjustedRecoveries] = @pAdjustedRecoveries
			,[FinalEstimatedRecoveries] = @pFinalEstimatedRecoveries
			,[TotalAdjustedRecoveries] = @pTotalAdjustedRecoveries
			,[TotalLossAmount] = @pTotalLossAmount
			,[FinalWaterfallCalculationNumber] = @pFinalWaterfallCalculationNumber
			,[CreditLossEventAmount] = @pCreditLossEventAmount
			,[RestructuredPrincipalAmount] = @pRestructuredPrincipalAmount
			,[FinalVerificationDate] = @pFinalVerificationDate
			,[WaterfallDate] = @pWaterfallDate
			,[ModifiedBy] = @pUserName
			,[Comments] = @pComments
			,[ModifiedDate] = GETDATE()
			,[DefaultedNotional] = @pDefaultedNotional
			,[FacilitySharePercent] = @pFacilitySharePercent
			,[AccountStatus] = @pAccountStatus
			,[RecoverySource] = @pRecoverySource
			,[DefaultReason] = @pDefaultReason
			,[MGS27DefaultAmount] = @pMGS27DefaultAmount
			,[MGS27DefaultDate] = @pMGS27DefaultDate
		WHERE [LossManagementId] = @pLossManagementId
                      
	END TRY                                    
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spUpdateLossDetails',
			@errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO