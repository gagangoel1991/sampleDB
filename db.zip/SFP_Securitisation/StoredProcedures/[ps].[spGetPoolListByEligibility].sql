USE [SFP_Securitisation]
GO
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetPoolListByEligibility]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetPoolListByEligibility]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- EXEC proc PS.spGetPoolListByEligibility 7, 'SAKK'
CREATE PROCEDURE [ps].[spGetPoolListByEligibility]
 @pEcId AS INT,  
 @pUserName AS VARCHAR(50)  
AS  
BEGIN              
  BEGIN TRY  

  SELECT pl.PoolId, pl.[Name] AS [Name], 
  CASE WHEN sts.[Status] = 'Submitted' THEN 'Pending Authorisation'  
       ELSE sts.[Status] END AS [Status] , 
  pl.BuiltDate, pl.CreatedDate AS CreationDate,
		pl.CreatedBy AS CreatedBy, pl.AuthorizedDate AS AuthorisationDate
   FROM ps.Pool pl                                              
   INNER JOIN ps.PoolEcMap ecMap ON pl.PoolId = ecMap.PoolId                                              
   INNER JOIN ps.EligibilityCriteria ec ON ecMap.EligibilityCriteriaId = ec.EligibilityCriteriaId   
   INNER JOIN ps.PoolStatus sts ON pl.PoolStatusId = sts.PoolStatusId
   WHERE  EC.EligibilityCriteriaId = @pEcId AND ecMAp.IsActive = 1 AND ec.IsActive = 1 AND PL.IsActive = 1
  
  END TRY              
  BEGIN CATCH              
   DECLARE   
     @errorMessage     NVARCHAR(MAX),  
     @errorSeverity    INT,  
     @errorNumber      INT,  
     @errorLine        INT,  
     @errorState       INT;  
   SELECT   
    @errorMessage = ERROR_MESSAGE()
    ,@errorSeverity = ERROR_SEVERITY()
    ,@errorNumber = ERROR_NUMBER()
    ,@errorLine = ERROR_LINE()
    ,@errorState = ERROR_STATE()  
  
   EXEC app.SaveErrorLog 2, 1, 'spGetPoolListByEligibility', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
   RAISERROR (@errorMessage,  
     @errorSeverity,  
     @errorState )          
   END CATCH              
 END
 GO