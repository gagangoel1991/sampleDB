USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spProcessForwardPoolData]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessForwardPoolData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spProcessForwardPoolData]
/*
 * Author: Kapil Sharma
 * Date:	04.03.2022
 * Description:  This will process the forward pool data 
 * 
 * Example - 
 * [cb].[spProcessForwardPoolData] 34, 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		IF EXISTS(SELECT TOP 1 * FROM cw.DealIpdRun WHERE RunId = @pDealIpdRunId)
		BEGIN
			DECLARE
				@dealId					INT,
				@collectionStartDt		DATE,
				@collectionEndDt		DATE,
				@dealIpdId				INT,
				@ipdDate				DATE,
				@adjustedCapitalBal		DECIMAL(20, 8),
				@netRevenueReceipt		DECIMAL(20, 8),
				@forwardPool			DECIMAL(20, 8),
				@netInterestRateSwapCal	DECIMAL(20, 8),
				@annualisedCPR			DECIMAL(38, 16),
				@annualisedCPRMonMinus1	DECIMAL(38, 16),
				@annualisedCPRMonMinus2	DECIMAL(38, 16),
				@monthlyCPR				DECIMAL(38, 18),
				@monthlyCPRMonMinus1	DECIMAL(38, 18),
				@monthlyCPRMonMinus2	DECIMAL(38, 18),
				@avgCPR					DECIMAL(38, 18),
				@oneMonthAvg			DECIMAL(28, 16) = 1.000/12.000,
				@correlatedDatePrev1	DATE, 
				@correlatedDatePrev2	DATE,
				@dealRegionCode			VARCHAR(10),
				@counter				INT,
				@createdBy				VARCHAR(80) = 'System',
				@createdDate			DATETIME = GETDATE()

			SELECT @dealId = di.DealId, 
				@collectionStartDt = did.CollectionBusinessStart, 
				@collectionEndDt = did.CollectionBusinessEnd,
				@dealIpdId = di.DealIpdId, @ipdDate = di.IpdDate,
				@dealRegionCode = deal.DealRegionCode
			FROM cw.DealIpd di
			JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
			JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
			JOIN [cw].[vw_ActiveDeal] deal ON deal.DealId = di.DealId
			WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1

			PRINT @collectionEndDt

			DECLARE @tblForwardMonth TABLE(Months INT, ForwardPool [decimal](38, 16), NetInterestRateSwap [decimal](38, 16))

			--Adjusted Capital Balance
			SELECT @adjustedCapitalBal = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'AdjustedCapitalBalance'), 0)
			--Net Revenue Receipt
			SELECT @netRevenueReceipt = CAST(tliv.Value AS decimal(36, 16)) FROM cfgcb.TestType tt
			JOIN cfgcb.TestLineItem tli ON tt.TestTypeID = tli.TestTypeID
			JOIN cb.TestLineItemValue tliv ON tliv.TestLineItemID = tli.TestLineItemID
			WHERE TT.InternalName = 'ICTMonthly' AND tli.InternalName = 'ICT_NetReceipts'
			AND tliv.DealIpdRunId = @pDealIpdRunId

			PRINT '@netRevenueReceipt'
			PRINT @netRevenueReceipt
			PRINT '@adjustedCapitalBal'
			PRINT @adjustedCapitalBal

			-------Calculate average CPR-------------------
			SELECT TOP 1 @correlatedDatePrev1 = AsAtDate FROM sfp.syn_SfpModel_vw_Calendar_v1
			WHERE 
				Month = Month(DATEADD(DD,1 ,EOMONTH(@collectionEndDt,-2))) AND year = Year(DATEADD(DD,1 ,EOMONTH(@collectionEndDt,-2)))  
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
			ORDER BY AsAtDate DESC

			SELECT TOP 1 @correlatedDatePrev2 = AsAtDate
			FROM sfp.syn_SfpModel_vw_Calendar_v1
			WHERE 
				[Month] = Month(DATEADD(DD,1 ,EOMONTH(@collectionEndDt,-3))) AND [year] = Year(DATEADD(DD,1 ,EOMONTH(@collectionEndDt,-3)))  
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
			ORDER BY AsAtDate DESC

			SELECT @annualisedCPR = CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'AnnualisedCPR'), 0) AS DECIMAL(16, 6))
			SELECT @annualisedCPRMonMinus1 = CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@correlatedDatePrev1, @dealId, 'AnnualisedCPR'), 0) AS DECIMAL(16, 6))
			SELECT @annualisedCPRMonMinus2 = CAST(ISNULL([cw].[fnGetDealAggregatedFieldValue](@correlatedDatePrev2, @dealId, 'AnnualisedCPR'), 0) AS DECIMAL(16, 6))
			
			SELECT @monthlyCPR = (1-POWER((1-@annualisedCPR), @oneMonthAvg))
			SELECT @monthlyCPRMonMinus1 = (1-POWER((1-@annualisedCPRMonMinus1), @oneMonthAvg))
			SELECT @monthlyCPRMonMinus2 = (1-POWER((1-@annualisedCPRMonMinus2), @oneMonthAvg))

			SET @avgCPR = CAST((@monthlyCPR + @monthlyCPRMonMinus1 + @monthlyCPRMonMinus2) AS FLOAT)/3.000000
			--PRINT '@monthlyCPR'
			--PRINT @monthlyCPR
			--PRINT '@monthlyCPRMonMinus1'
			--PRINT @monthlyCPRMonMinus1
			--PRINT '@monthlyCPRMonMinus2'
			--PRINT @monthlyCPRMonMinus2
			--PRINT '@avgCPR'
			--PRINT @avgCPR
			SET @counter = 1
			WHILE @counter <=12
			BEGIN
				SET @forwardPool = CAST(@adjustedCapitalBal AS FLOAT) * (POWER((1-@avgCPR), @counter))
				SET @netInterestRateSwapCal = (@forwardPool/@adjustedCapitalBal)*@netRevenueReceipt

				INSERT INTO @tblForwardMonth(Months, ForwardPool, NetInterestRateSwap)
				VALUES(@counter, @forwardPool, @netInterestRateSwapCal)

				SET @counter = @counter + 1
			END
			--------Now insert the test line item into the main table
		

			--Now merge the line item values into main table
			MERGE [cb].[ForwardPoolData] AS trg
			USING @tblForwardMonth AS src
			ON src.Months = trg.Months AND trg.DealIpdRunId = @pDealIpdrunID
			WHEN NOT MATCHED BY Target THEN
				INSERT (DealIpdRunId, Months, ForwardPool, NetInterestRateSwap, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES (@pDealIpdrunID, src.Months, src.ForwardPool, src.NetInterestRateSwap, @createdBy, @createdDate, @createdBy, @createdDate)
			WHEN MATCHED THEN UPDATE SET
				trg.[ForwardPool]	= src.ForwardPool,
				trg.NetInterestRateSwap	= src.NetInterestRateSwap,
				trg.ModifiedBy = @createdBy,
				trg.ModifiedDate = @createdDate;
		END
		ELSE
		BEGIN
			PRINT 'Specified Run Id is not exists'
		END
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spProcessForwardPoolData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO