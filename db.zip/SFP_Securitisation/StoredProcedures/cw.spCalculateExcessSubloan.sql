USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculateExcessSubloan') IS NOT NULL
	DROP PROCEDURE cw.spCalculateExcessSubloan
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculateExcessSubloan
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  28.06.2020 
 *   Description:  Calculate override sql ofexces subloan for a  line item  of Pre ARR
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 * 
 *   DECLARE @ret_value DECIMAL(38,16)
 *   EXEC cw.spCalculateExcessSubloan 12,'fm\shriyad' ,@ret_value  OUTPUT
 *   SELECT @ret_value   
 *         
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80),
@oValue DECIMAL(38,16) OUTPUT
)
AS
BEGIN
		--DECLARE @pDealIpdRunId INT = 6;
		BEGIN TRY

		DECLARE @IpdDate datetime, @IpdSequence smallINT;
		SELECT @IpdDate = IpdDate, @IpdSequence = IpdSequence FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId;
		
		IF(@IpdSequence = 2)
		BEGIN
			DECLARE @InitialAMount decimal(38,16), @SpentAmount decimal(38,16);

			SELECT @InitialAMount = InitialAmount-rPre.ReserveFundRequiredAmount 
			FROM   cfgcw.DealSubloan sl 
			JOIN cw.ReserveFund_PreWf rPre ON rPre.DealIpdRunId = @pDealIpdRunId AND  sl.InternalName='DUNMORE1_SubLoan00001'
			JOIN  cfgcw.DealReserveFund rf ON rf.DealReserveFundId= rPre.ReserveFundId AND rf.InternalName='DUNMORE1_GeneralReserve00001'

			SELECT @SpentAmount = sum(Amount) FROM cw.InvoiceData id
			JOIN cfgcw.InvoiceCategory ic ON ic.InvoiceCategoryId = id.InvoiceCategoryId
			JOIN cfgcw.InvoiceCategoryType ict ON ict.InvoiceCategoryTypeId = ic.InvoiceCategoryTypeId AND ict.InternalName='ClosingExpense'
			WHERE DealIpdDate<= @IpdDate
			
			SELECT @oValue = @InitialAMount - ISNULL(@SpentAmount,0)

		END
		ELSE
		BEGIN
			SELECT @oValue = 0;
		END

		END TRY
		BEGIN CATCH
			DECLARE 
				@errorMessage     NVARCHAR(MAX),
				@errorSeverity    INT,
				@errorNumber      INT,
				@errorLine        INT,
				@errorState       INT;

			SELECT 
				@errorMessage = ERROR_MESSAGE()
				,@errorSeverity = ERROR_SEVERITY()
				,@errorNumber = ERROR_NUMBER()
				,@errorLine = ERROR_LINE()
				,@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'spCalculateExcessSubloan', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
			RAISERROR (@errorMessage,
				 @errorSeverity,
				 @errorState )
		END CATCH


	END



	GO