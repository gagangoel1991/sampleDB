USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetRatingTriggers]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetRatingTriggers] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 26-05-2021 
--Description: GET rating trigger 
--[cw].[spGetRatingTriggers] 6,1034,''
--==================================   
CREATE PROCEDURE [cw].[spGetRatingTriggers] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
	BEGIN TRY 
	
		DECLARE @seprator varchar(20) = ' | ';  
		
		SELECT 
			t.DisplayName AS EventName,
			t.Consequences AS ConsequenceOfEvent,
			tr.OutcomeSummary AS CurrentRating,
			tm.SubjectId+@seprator+dcp.CounterpartyName AS CisCode, 
			tr.IsBreached,
			cw.fnGetTriggerThresholdRating(tr.DealIpdTriggerResultId) AS ThresholdRating,
			ISNULL(tr.ActionTaken, '') AS ActionTaken,
			t.TriggerSummary AS TriggerSummary,
			t.Reference AS Reference
		FROM 
			cw.DealIpdTriggerResult tr 
		JOIN 
			cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId
		JOIN 
			cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId
		JOIN
		    cfgcw.TriggerActionType tat ON tam.TriggerActionTypeId =tat.TriggerActionTypeId
		JOIN 
			cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId AND t.DealId = tm.DealId
		JOIN 
			cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId
		JOIN 
			[CW].[vw_ActiveDealCounterparty] dcp ON dcp.CisCode=tm.SubjectId AND dcp.DealId=@pDealId
		
		WHERE  
			tr.DealIpdRunId=@pIPDRunId AND tm.DealId=@pDealId 
			AND tt.InternalName = 'RatingTrigger'

	END TRY   
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spGetRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH  
END
GO
