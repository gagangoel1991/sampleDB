USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[GetDefaultAssetClass]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[GetDefaultAssetClass]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--------------------------------------------------------------------------------------------------------------
-- Author: Aditya Aggarwal
-- Date:	23.04.2022
-- Description:  This will return the user's default asset class
-- [app].[GetDefaultAssetClass] 'EUROPA\aggadi', 'EUROPA\rAppTSPDevelopmentSupport', @pReturnValue
--------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [app].[GetDefaultAssetClass] 
	@pUserName			VARCHAR(80),
	@pAdGroupName		VARCHAR(256),
	@pReturnValue 		INT = 1 OUTPUT
AS
BEGIN
	DECLARE
		@tblADGroup TABLE ([Value] [varchar] (500));
	
	DECLARE 
		@IsActive 			BIT = 1

	INSERT INTO @tblADGroup
	SELECT [Value] FROM app.[udfSplitString](@pAdGroupName, '|') 
	
	BEGIN TRY

		SELECT 
			TOP(1) @pReturnValue = ar.AssetClassId
		FROM [app].[ADGroup] ad
		JOIN 
			@tblADGroup userGrp ON userGrp.[Value] = ad.[Name]
		JOIN 
			[app].[RoleADGroupMap] rgm ON ad.ADGroupId = rgm.ADGroupId
		JOIN
			[app].[Role] ar ON ar.RoleId = rgm.RoleId
		WHERE
			ad.IsActive = @IsActive AND rgm.IsActive = @IsActive
			AND ar.IsActive = @IsActive
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'GetDefaultAssetClass', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END


GO