USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetPreMaturityLiquidityFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetPreMaturityLiquidityFund]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 17-05-2021 
--Description: GET Reserve Fund 
--[cb].[spGetPreMaturityLiquidityFund] 6,49,''
--==================================   
CREATE PROCEDURE [cb].[spGetPreMaturityLiquidityFund] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
		SELECT CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
			,CASE 
			    WHEN litem.FieldName = 'testResult'
				    THEN 'N/A'
					ELSE ttr.Result
					END AS TestResult
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN wliParent.ParentLineItemId
				ELSE ISNULL(litem.ParentLineItemId, 0)
				END ParentId
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN 1
				ELSE 0
				END IsSubLineItems
			,litem.DisplayTextUI
			,litem.FieldName
			,pml_preWf.PreMaturityLiquidity_bF AS PreMaturityLiquidity_bf
			,pml_preWf.RequiredAmount1
			,pml_preWf.FinalRequiredAmount
			,pml_preWf.DueAmount
			,pml_preWf.ResidualAmount
			,pml_preWf.CapitalContribution
			,pml_postWf.CreditReceivedRPP
			,pml_postWf.ShortfallAfterRPP
			,pml_postWf.CreditReceivedPPP
			,pml_postWf.PreMaturityLiquidity_cf
		FROM cfgcb.CoveredBondFund cbf
		JOIN [cfgcb].[CoveredBondFundLineItemUI] litem ON cbf.CoveredBondFundId = litem.CoveredBondFundId
		LEFT JOIN (
			SELECT DISTINCT ParentLineItemId
			FROM [cfgcb].[CoveredBondFundLineItemUI]
			) AS wliParent ON wliParent.ParentLineItemId = litem.CoveredBondFundLineItemId
		JOIN cb.PreMaturityLiquidity_PreWF pml_preWf ON cbf.CoveredBondFundId = pml_preWf.CoveredBondFundId
			AND pml_preWf.IsActive = 1
		JOIN cw.vwdealipdrun dir ON dir.DealIpdRunId = pml_preWf.DealIpdRunId
		LEFT JOIN [cb].[DealIpdTestResult] ttr ON cbf.ApplicableId = ttr.TestTypeID
      AND ttr.DealIpdRunId = dir.DealIpdRunId
			AND TriggerOrTestApplicable = 'TEST'
		LEFT JOIN cb.PreMaturityLiquidity_PostWF pml_postWf ON cbf.CoveredBondFundId = pml_postWf.CoveredBondFundId
			AND pml_postWf.IsActive = 1
			AND dir.DealIpdRunId = pml_postWf.DealIpdRunId
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
			AND cbf.InternalName = 'PreMaturityLiquidityFund'
			AND cbf.DealId = @pDealId
		ORDER BY dir.IpdDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetPreMaturityLiquidityFund'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


