USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[GetUserAndMenuData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[GetUserAndMenuData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
Author: Kapil Sharma
Date:	28.04.2020
Description:  This will return the user data and menu data
				
Change History
--------------
Author: Pankaj Kothari
Date: 23.03.2021
Description: Added sql to return user's permissions and accessType
-------------------------------------------------------
[app].[GetUserAndMenuData] 'FM\Sharapi', 'FM\G USR - ROL GTT Development Support' */
CREATE PROCEDURE [app].[GetUserAndMenuData] 
	@pUserName			VARCHAR(80),
	@pAdGroupName		VARCHAR(256),
	@pAssetId			INT = 1
AS
BEGIN

	SET NOCOUNT ON

	DECLARE
		@tblADGroup TABLE ([Value] [varchar] (500));

	DECLARE
		@userFullName		VARCHAR(200),
		@profileImg			VARCHAR(100),
		@userRole			VARCHAR(500)
	
	DECLARE 
		@IsActive 			BIT = 1

	INSERT INTO @tblADGroup
	SELECT [Value] FROM app.[udfSplitString](@pAdGroupName, '|') 
	
	BEGIN TRY

		--Returning the user detail	
		
		SELECT 
			@userFullName = usr.FirstName + ' ' + usr.LastName ,
			@profileImg = usr.ProfileImage 
		FROM
			[app].[User] usr
		WHERE
			usr.[UserName] = @pUserName

		;with RoleCTE as  
		(
			SELECT 
				DISTINCT ar.[Name]
				--@userRole = COALESCE(@userRole + ', ' + ar.[Name], ar.[Name])
			FROM
				[app].[ADGroup] ad
			JOIN	
				@tblADGroup userGrp ON userGrp.[Value] = ad.[Name]
			JOIN 
				[app].[RoleADGroupMap] rgm ON ad.ADGroupId = rgm.ADGroupId
			JOIN
				[app].[Role] ar ON ar.RoleId = rgm.RoleId
			LEFT JOIN 
				[app].[User] usr ON usr.[UserName] = @pUserName
			WHERE 
				ad.IsActive = 1 AND ar.AssetClassId = @pAssetId AND
				ar.IsActive = 1 AND rgm.IsActive = 1
		)
		SELECT @userRole = COALESCE(@userRole + ', ' + [Name], [Name]) FROM RoleCTE
		

		SELECT 
			@pUserName AS UserName,
			ISNULL(@userFullName, @pUserName) AS UserFullName,
			ISNULL(@profileImg, 'defaultUserImage.png') AS ProfileImage,
			@userRole as RoleName

		--Returning the Menu items
		SELECT 
			nbm.NavbarMenuId, 
			MenuName,
			nbm.RouterLink,
			anbMap.PathPrefix,
			Icon,
			ParentMenuId,
			SeqOrder,
			1 IsAccessible ,
			DefaultSelected Selected,
			DefaultExpanded Expanded
		FROM 
			[app].[NavbarMenu] nbm
		JOIN
			[app].[AssetNavbarMenuMap] anbMap ON anbMap.NavbarMenuId = nbm.NavbarMenuId
		WHERE
			nbm.IsActive = @IsActive AND anbMap.AssetClassId = @pAssetId 
			AND anbMap.IsActive = @IsActive
		ORDER BY 
			SeqOrder

		--Returning the User permissions
		SELECT 
			DISTINCT 
  			per.RoleId AS RoleId,
			permission.PermissionName As Permission, 
			accessType.AccessType As PermissionAccessType		
		FROM 
			app.ADGroup ad
		JOIN	
			@tblADGroup userGrp ON userGrp.[Value] = ad.[Name]
		JOIN [app].[RoleADGroupMap] rgm 
			ON ad.ADGroupId = rgm.ADGroupId		
		JOIN app.RolePermissionAccessMap per 
			ON per.RoleId = rgm.RoleId
		JOIN app.Permission  permission
			ON permission.PermissionId = per.PermissionId
		JOIN app.PermissionAccessType accessType
			ON accessType.PermissionAccessTypeId = per.PermissionAccessTypeId
		JOIN [app].[Role] ar 
			ON ar.RoleId = rgm.RoleId 
		WHERE 
			per.IsActive = @IsActive AND rgm.IsActive = @IsActive
			AND ad.IsActive = @IsActive AND ad.IsActive = @IsActive
			AND accessType.IsActive = @IsActive AND permission.IsActive = @IsActive
			AND ar.AssetClassId = @pAssetId
		ORDER BY Permission

		--Returning Current Asset class
		SELECT @pAssetId AS SelectedAssetClass

		--Return Accessible Asset Classes
		SELECT 
			DISTINCT
				ar.AssetClassId as ClassId, 
				ac.Class as ClassName, 
				ac.Description, 
				ac.Code 
		FROM [app].[ADGroup] ad
		JOIN 
			@tblADGroup userGrp ON userGrp.[Value] = ad.[Name]
		JOIN 
			[app].[RoleADGroupMap] rgm ON ad.ADGroupId = rgm.ADGroupId
		JOIN
			[app].[Role] ar ON ar.RoleId = rgm.RoleId
		JOIN 
			[ps].[AssetClass] ac ON ac.AssetClassId = ar.AssetClassId
		WHERE
			ad.IsActive = @IsActive AND rgm.IsActive = @IsActive
			AND ar.IsActive = @IsActive AND ac.IsActive = @IsActive
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'GetUserAndMenuData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END


GO