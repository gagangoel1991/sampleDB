USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[app].[spGetReportAndParamters]') and OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [app].[spGetReportAndParamters]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spGetReportAndParamters]
(
	@pReportId INT,
	@pUserName VARCHAR(50)
)
AS             
BEGIN            
BEGIN TRY
	EXEC sfp.syn_SfpModel_sp_app_spGetReport @pReportId
	EXEC sfp.syn_SfpModel_sp_app_spGetReportParameters @pReportId
	
END TRY            
BEGIN CATCH            
  DECLARE             
   @errorMessage     NVARCHAR(MAX),            
   @errorSeverity    INT,            
   @errorNumber      INT,            
   @errorLine        INT,            
   @errorState       INT;            
  SELECT             
   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()            
            
 EXEC app.SaveErrorLog 2, 1, 'spGetReportAndParamters', @errorNumber, @errorSeverity, @errorLine, @errorMessage, pUserName
              
  RAISERROR (@errorMessage,            
             @errorSeverity,            
             @errorState)            
 END CATCH            
END

GO