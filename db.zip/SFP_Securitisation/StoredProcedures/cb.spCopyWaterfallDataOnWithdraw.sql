USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spCopyWaterfallDataOnWithdraw]') IS NOT NULL
	DROP PROCEDURE [cb].[spCopyWaterfallDataOnWithdraw]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================
--Author: Aditya Shrivastava
--Date:	23.03.2022
--Description:  
/*

  DECLARE @pResultCode INT 
  exec cb.spCopyWaterfallDataOnWithdraw	3,10 ,'fm\pandsbl' ,@pResultCode OUTPUT
  Select @pResultCode

*/
--================================== 
CREATE PROC [cb].[spCopyWaterfallDataOnWithdraw] (
	@pOldDealIpdRunId INT
	,@pNewDealIpdRunId INT
	,@pUserName VARCHAR(200)
	,@pResultCode SMALLINT OUTPUT
	)
AS
BEGIN
	DECLARE @Message VARCHAR(4000)
		,@stepCode VARCHAR(50) = 'WITHDRAW_RUN'
		,@inputParams VARCHAR(100) = 'OldDealIpdRunId=' + CONVERT(VARCHAR(10), @pOldDealIpdRunId) + 'NewDealIpdRunId=' + CONVERT(VARCHAR(10), @pNewDealIpdRunId) + '; UserName=' + CONVERT(VARCHAR(10), @pUserName)
		,@logExecutionId INT
		,@date DATETIME = GETDATE()

	BEGIN TRY
		--BEGIN TRAN
		EXEC cw.spLogExecution @pNewDealIpdRunId
			,@stepCode
			,'STARTED'
			,@inputParams
			,NULL
			,0
			,NULL
			,@pUserName
			,@logExecutionId OUT

		--Insert Daily Collection
		INSERT INTO [CW].[DailyCollection_PostWF] (
			DealIpdRunId
			,DailyCollectionId
			,CollectionDate
			,DealId
			,BrandId
			,DailyCollectionFieldId
			,[Value]
			)
		SELECT @pNewDealIpdRunId
			,DailyCollectionId
			,CollectionDate
			,DealId
			,BrandId
			,DailyCollectionFieldId
			,[Value]
		FROM [CW].[DailyCollection_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		DELETE
		FROM [CW].[DailyCollection_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId


		--CashLadder_postWF
		INSERT INTO [CW].[CashLadder_postWF] (
			DealIpdRunId,CashLadderId,FeedRunLogId,DealId,CollectionDate,CorrespondentAccountNumber,DealReference
			,Product,SubProduct,CounterParty,ContextName,Rate,MaturityDate,Currency
			,InflowAmount,OutflowAmount,FlowSubTotal,Version,ChangeReason
			,Status,CreatedBy,CreatedDate,ApprovedBy,ApprovedDate,IsActive,ProcessReferenceId
			)
		SELECT @pNewDealIpdRunId, CashLadderId,FeedRunLogId,DealId,CollectionDate,CorrespondentAccountNumber,DealReference
			,Product,SubProduct,CounterParty,ContextName,Rate,MaturityDate,Currency
			,InflowAmount,OutflowAmount,FlowSubTotal,Version,ChangeReason
			,Status,@pUserName,@date,@pUserName,@date,IsActive,ProcessReferenceId
		FROM [CW].[CashLadder_postWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		DELETE
		FROM [CW].[CashLadder_postWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		--

		DELETE
		FROM [CW].[DailyCollection_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId


		--Insert Collection Ledger
		INSERT INTO [CW].[CollectionLedger_PostWF] (
			DealIpdRunId
			,[CollectionLedgerId]
			,CollectionDate
			,DealId
			,[BrandMapId]
			,[NetPrincipalCollections]
			,[FinanceCollections]
			,[OtherCollections]
			,[TotalDailyCashAmount]
			)
		SELECT @pNewDealIpdRunId
			,[CollectionLedgerId]
			,CollectionDate
			,DealId
			,[BrandMapId]
			,[NetPrincipalCollections]
			,[FinanceCollections]
			,[OtherCollections]
			,[TotalDailyCashAmount]
		FROM [CW].[CollectionLedger_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		DELETE
		FROM [CW].[CollectionLedger_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		--Insert Interest Rate
		INSERT INTO [CW].[InterestRate_PostWF] (
			[DealIpdRunId]
			,[InterestRateId]
			,[BaseDate]
			,[RICCode]
			,[Rate]
			)
		SELECT @pNewDealIpdRunId
			,[InterestRateId]
			,[BaseDate]
			,[RICCode]
			,[Rate]
		FROM [CW].[InterestRate_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		DELETE
		FROM [CW].[InterestRate_PostWF]
		WHERE DealIpdRunID = @pOldDealIpdRunId

		INSERT INTO cw.RevenueWaterfallPayment (
			DealIpdRunId
			,WaterfallLineItemId
			,TotalDueAmount
			,SourceTotalAmount
			,SourceId
			,SourceName
			,IsEligible
			,Priority
			,SortOrder
			,SourceCurrentAmount
			,DueAmount
			,EligibleRequiredAmount
			,AmountPaidFromSource
			,SourceRemainingAmount
			,RemainingDueAmount
			,TotalPaidAmount
			,CreatedDate
			,CreatedBy
			,ModifiedDate
			,ModifiedBy
			)
		SELECT @pNewDealIpdRunId
			,WaterfallLineItemId
			,TotalDueAmount
			,SourceTotalAmount
			,SourceId
			,SourceName
			,IsEligible
			,Priority
			,SortOrder
			,SourceCurrentAmount
			,DueAmount
			,EligibleRequiredAmount
			,AmountPaidFromSource
			,SourceRemainingAmount
			,RemainingDueAmount
			,TotalPaidAmount
			,@date
			,@pUserName
			,@date
			,@pUserName
		FROM cw.RevenueWaterfallPayment
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY RevenueWaterfallPaymentId

		INSERT INTO cw.RevenueWaterfallPaymentSummary (
			WaterfallLineItemId
			,DealIpdRunId
			,RequiredAmount
			,AdjustedAmount
			,TotalRequiredAmount
			,TotalPaidAmount
			,RemainingDueAmount
			)
		SELECT WaterfallLineItemId
			,@pNewDealIpdRunId
			,RequiredAmount
			,AdjustedAmount
			,TotalRequiredAmount
			,TotalPaidAmount
			,RemainingDueAmount
		FROM cw.RevenueWaterfallPaymentSummary
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY RevenueWaterfallPaymentSummaryId

		INSERT INTO cw.PrincipalWaterfallPayment (
			DealIpdRunId
			,WaterfallLineItemId
			,TotalDueAmount
			,SourceTotalAmount
			,SourceId
			,SourceName
			,IsEligible
			,Priority
			,SortOrder
			,SourceCurrentAmount
			,DueAmount
			,EligibleRequiredAmount
			,AmountPaidFromSource
			,SourceRemainingAmount
			,RemainingDueAmount
			,TotalPaidAmount
			,CreatedDate
			,CreatedBy
			,ModifiedDate
			,ModifiedBy
			)
		SELECT @pNewDealIpdRunId
			,WaterfallLineItemId
			,TotalDueAmount
			,SourceTotalAmount
			,SourceId
			,SourceName
			,IsEligible
			,Priority
			,SortOrder
			,SourceCurrentAmount
			,DueAmount
			,EligibleRequiredAmount
			,AmountPaidFromSource
			,SourceRemainingAmount
			,RemainingDueAmount
			,TotalPaidAmount
			,@date
			,@pUserName
			,@date
			,@pUserName
		FROM cw.PrincipalWaterfallPayment
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY PrincipalWaterfallPaymentId

		INSERT INTO cw.PrincipalWaterfallPaymentSummary (
			WaterfallLineItemId
			,DealIpdRunId
			,RequiredAmount
			,AdjustedAmount
			,TotalRequiredAmount
			,TotalPaidAmount
			,RemainingDueAmount
			,CreatedDate
			,CreatedBy
			)
		SELECT WaterfallLineItemId
			,@pNewDealIpdRunId
			,RequiredAmount
			,AdjustedAmount
			,TotalRequiredAmount
			,TotalPaidAmount
			,RemainingDueAmount
			,@date
			,@pUserName
		FROM cw.PrincipalWaterfallPaymentSummary
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY PrincipalWaterfallPaymentSummaryId

		INSERT INTO cb.CouponPaymentFund_PostWf 
		(DealIpdRunId,CoveredBondFundId,CreditReceived,CouponPayment_cf
			,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,CreditReceived,CouponPayment_cf
			,IsActive,@pUserName,@date,@pUserName,@date
		FROM cb.CouponPaymentFund_PostWf
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY CouponPaymentFund_PostWfId

		INSERT INTO cb.PreMaturityLiquidity_PostWF 
		(DealIpdRunId,CoveredBondFundId,CreditReceivedRPP,ShortfallAfterRPP,CreditReceivedPPP
		,PreMaturityLiquidity_cf
		,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,CreditReceivedRPP,ShortfallAfterRPP,CreditReceivedPPP
		,PreMaturityLiquidity_cf
			,1,@pUserName,@date,@pUserName,@date
		FROM cb.PreMaturityLiquidity_PostWF
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY PreMaturityLiquidity_PostWFId

		INSERT INTO cb.ReserveFund_PostWF 
		(DealIpdRunId,CoveredBondFundId,CreditReceived,ReserveFund_cf
		,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,CreditReceived,ReserveFund_cf
			,1,@pUserName,@date,@pUserName,@date
		FROM cb.ReserveFund_PostWF
		WHERE DealIpdRunId = @pOldDealIpdRunId
		ORDER BY ReserveFund_PostWFId

		--INSERT Adjustment  
		INSERT INTO [CW].[WaterfallLineItemAmount_PostWF] (
			[WorkflowProcessId]
			,[DealIpdRunId]
			,[WaterfallLineItemId]
			,[AdjustedAmount]
			)
		SELECT wft.newWorkFlowID
			,@pNewDealIpdRunId
			,wflta.[WaterfallLineItemId]
			,wflta.[AdjustedAmount]
		FROM [cw].[WaterfallLineItemAmount_PostWF] AS wflta
		JOIN (
			SELECT new.WorkflowProcessId AS newWorkFlowID
				,old.WorkflowProcessId AS oldWorkFlowID
			FROM (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pNewDealIpdRunId
				) AS new
			JOIN (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pOldDealIpdRunId
				) AS old ON new.WorkflowStepId = old.WorkflowStepId
				AND new.CreatedDate = old.CreatedDate
			) AS wft ON wflta.WorkflowProcessId = wft.oldWorkFlowID
		ORDER BY wflta.WaterfallLineItemAmountId

		--INSERT Rating Trigger  
		INSERT INTO [cw].[DealIpdTriggerResult_PostWF] (
			[WorkflowProcessId]
			,[DealIpdRunId]
			,[DealTriggerMapId]
			,[OutcomeSummary]
			,[IsBreached]
			)
		SELECT wft.newWorkFlowID
			,@pNewDealIpdRunId
			,dtr.[DealTriggerMapId]
			,dtr.[OutcomeSummary]
			,dtr.[IsBreached]
		FROM [cw].[DealIpdTriggerResult_PostWF] AS dtr
		JOIN (
			SELECT new.WorkflowProcessId AS newWorkFlowID
				,old.WorkflowProcessId AS oldWorkFlowID
			FROM (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pNewDealIpdRunId
				) AS new
			JOIN (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pOldDealIpdRunId
				) AS old ON new.WorkflowStepId = old.WorkflowStepId
				AND new.CreatedDate = old.CreatedDate
			) AS wft ON dtr.WorkflowProcessId = wft.oldWorkFlowID
		ORDER BY dtr.DealIpdTriggerResultId

		--InvoiceData
		INSERT INTO [CW].[InvoiceData_PostWF] (
			WorkflowProcessId
			,DealId
			,InvoiceCategoryId
			,DealCounterpartyId
			,Amount
			,PaidDate
			,DealIpdDate
			,ReferenceNumber
			,SpotRate
			,InvoiceDate
			,InvoiceCurrencyId
			,SpotRateDate
			)
		SELECT wft.newWorkFlowID
			,inv.DealId
			,inv.InvoiceCategoryId
			,inv.DealCounterpartyId
			,inv.Amount
			,inv.PaidDate
			,inv.DealIpdDate
			,inv.ReferenceNumber
			,inv.SpotRate
			,inv.InvoiceDate
			,inv.InvoiceCurrencyId
			,inv.SpotRateDate
		FROM [CW].[InvoiceData_PostWF] AS inv
		JOIN (
			SELECT new.WorkflowProcessId AS newWorkFlowID
				,old.WorkflowProcessId AS oldWorkFlowID
			FROM (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pNewDealIpdRunId
				) AS new
			JOIN (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pOldDealIpdRunId
				) AS old ON new.WorkflowStepId = old.WorkflowStepId
				AND new.CreatedDate = old.CreatedDate
			) AS wft ON inv.WorkflowProcessId = wft.oldWorkFlowID

		--UserBondRating
		INSERT INTO [CW].[UserBondRating_PostWF] (
			UserBondRatingId
			,WorkflowProcessId
			,ISIN
			,Series
			,CRAId
			,RatingTypeId
			,Rating
			,RatingDate
			)
		SELECT ubr.UserBondRatingId
			,wft.newWorkFlowID
			,ubr.ISIN
			,ubr.Series
			,ubr.CRAId
			,ubr.RatingTypeId
			,ubr.Rating
			,ubr.RatingDate
		FROM [CW].[UserBondRating_PostWF] AS ubr
		JOIN (
			SELECT new.WorkflowProcessId AS newWorkFlowID
				,old.WorkflowProcessId AS oldWorkFlowID
			FROM (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pNewDealIpdRunId
				) AS new
			JOIN (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pOldDealIpdRunId
				) AS old ON new.WorkflowStepId = old.WorkflowStepId
				AND new.CreatedDate = old.CreatedDate
			) AS wft ON ubr.WorkflowProcessId = wft.oldWorkFlowID

		--UserCounterpartyRating
		INSERT INTO [CW].[UserCounterpartyRating_PostWF] (
			UserCounterpartyRatingId
			,WorkflowProcessId
			,RatingDate
			,CisCode
			,CRAId
			,RatingTypeId
			,Rating
			)
		SELECT ucpr.UserCounterpartyRatingId
			,wft.newWorkFlowID
			,ucpr.RatingDate
			,ucpr.CisCode
			,ucpr.CRAId
			,ucpr.RatingTypeId
			,ucpr.Rating
		FROM [CW].[UserCounterpartyRating_PostWF] AS ucpr
		JOIN (
			SELECT new.WorkflowProcessId AS newWorkFlowID
				,old.WorkflowProcessId AS oldWorkFlowID
			FROM (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pNewDealIpdRunId
				) AS new
			JOIN (
				SELECT wfp.WorkflowProcessId
					,wfp.WorkflowStepId
					,wfp.CreatedDate
				FROM cw.workflowprocess wfp
				JOIN cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId
				JOIN cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.[Name] = 'Deal_IPD'
					AND wfp.ProcessReferenceId = @pOldDealIpdRunId
				) AS old ON new.WorkflowStepId = old.WorkflowStepId
				AND new.CreatedDate = old.CreatedDate
			) AS wft ON ucpr.WorkflowProcessId = wft.oldWorkFlowID
		
		INSERT INTO [cb].[ManualFieldValue_PostWF](
			ManualFieldValueId,ManualFieldId,DealIpdRunId,[Value]			
		)
		SELECT ManualFieldValueId,ManualFieldId,@pNewDealIpdRunId,[Value]			
		FROM [cb].[ManualFieldValue]
		WHERE DealIpdRunId = @pOldDealIpdRunId;

		DELETE FROM [cb].[ManualFieldValue]
		WHERE DealIpdRunId = @pOldDealIpdRunId;

		SET @Message = 'SUCCESS: Withdraw CashWaterfall is Completed!'

		EXEC cw.spLogExecution @pOldDealIpdRunId
			,@stepCode
			,'SUCCESS'
			,@inputParams
			,NULL
			,0
			,NULL
			,@pUserName
			,@logExecutionId OUT

		SET @pResultCode = 1
	END TRY

	BEGIN CATCH
		DECLARE @errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @Message = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spCopyWaterfallDataOnWithdraw'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@Message
			,@pUserName

		EXEC cw.spLogExecution @pOldDealIpdRunId
			,@stepCode
			,'FAILED'
			,@inputParams
			,@Message
			,0
			,''
			,@pUserName
			,@logExecutionId OUT

		SET @pResultCode = 0

		RAISERROR (
				@Message
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


