USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetSFPPlusDashBoardFutureDate]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetSFPPlusDashBoardFutureDate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGetSFPPlusDashBoardFutureDate]
(      
	@AsAtDate DATE,
	@pUserName VARCHAR(50)
)      
AS      
BEGIN      
	BEGIN TRY      

				DECLARE @PoolStatusAuthoriseId INT

				SELECT @PoolStatusAuthoriseId = poolstatusid
				FROM   ps.poolstatus
				WHERE  status = 'Authorised';

				DECLARE @poolPartitionMap_Tbl TABLE
				  (
					 poolid              INT,
					 hypopoolpartitionid INT
				  )

				INSERT INTO @poolPartitionMap_Tbl
							(poolid,
							 hypopoolpartitionid)
				SELECT poolid,
					   CONVERT(VARCHAR, vintagedate, 112)
				FROM   ps.pool
				WHERE  poolstatusid = @PoolStatusAuthoriseId
					   AND effectivedate = @AsAtDate;

				IF EXISTS (SELECT 1
						   FROM   tempdb.sys.objects
						   WHERE  object_id = Object_id(N'tempdb..#sourcePoolDetail')
								  AND type = 'U')
				  DROP TABLE #sourcepooldetail

				IF EXISTS (SELECT 1
						   FROM   tempdb.sys.objects
						   WHERE  object_id = Object_id(N'tempdb..#PoolBuildDetail')
								  AND type = 'U')
				  DROP TABLE #poolbuilddetail

				IF EXISTS (SELECT 1
						   FROM   tempdb.sys.objects
						   WHERE  object_id = Object_id(N'tempdb..#sourceDetails')
								  AND type = 'U')
				  DROP TABLE #sourcedetails

				SELECT pbd.poolid,
					   pbd.mortgageaccountkey,
					   pbd.mortgagesubaccountkey
				INTO   #poolbuilddetail
				FROM   ps.poolbuilddetail pbd
				WHERE  pbd.poolid IN (SELECT poolid
									  FROM   @poolPartitionMap_Tbl)
					AND pbd.IsActive = 1

				SELECT fmsa_E.mortgagedealkey,
					   tmppart.poolid,
					   fmsa_E.mortgageaccountkey,
					   fmsa_E.mortgagesubaccountkey
				INTO   #sourcepooldetail
				FROM   #poolbuilddetail pbd
					   INNER JOIN sfp.syn_sfpmodel_vw_factmortgagesubaccountentity fmsa_E
								  INNER JOIN @poolPartitionMap_Tbl tmppart
										  ON fmsa_E.partitionid = tmppart.hypopoolpartitionid
							   ON pbd.mortgageaccountkey = fmsa_E.mortgageaccountkey
								  AND fmsa_E.mortgagesubaccountkey = pbd.mortgagesubaccountkey
								  AND pbd.poolid = tmppart.poolid
					   INNER JOIN sfp.[syn_sfpmodel_vw_mortgagesubaccountentity] dmsa
							   ON dmsa.mortgageaccountkey_interim = fmsa_E.mortgageaccountkey
								  AND dmsa.mortgagesubaccountkey_interim =
									  fmsa_E.mortgagesubaccountkey
								  AND dmsa.account_inception_date <> '0001-01-01'
								  AND dmsa.process_status NOT IN ( '0', '1' )

				SELECT mortgagedealkey,
					   poolid,
					   COUNT(DISTINCT mortgageaccountkey)    AccountCount,
					   COUNT(DISTINCT mortgagesubaccountkey) SubAccountCount
				INTO   #sourcedetails
				FROM   #sourcepooldetail
				GROUP  BY mortgagedealkey,
						  poolid;

				SELECT pool.poolid,
					   pool.NAME              PoolName,
					   purpose.poolpurpose    Purpose,
					   sourceDeal.dealname    SourceDeal,
					   TargetDeal.dealname    TargetDeal,
					   source.accountcount    NumberOfLoans,
					   source.subaccountcount NumberOfSubAccounts
				FROM   [ps].[pool] pool
					   INNER JOIN [ps].[poolpurpose] purpose
							   ON pool.poolpurposeid = purpose.poolpurposeid
					   INNER JOIN #sourcedetails source
							   ON source.poolid = pool.poolid
					   INNER JOIN sfp.syn_SfpModel_vw_MortgageDeal_v1 sourceDeal
							   ON sourceDeal.mortgagedealkey = source.mortgagedealkey
					   INNER JOIN sfp.syn_SfpModel_vw_MortgageDeal_v1 TargetDeal
							   ON TargetDeal.mortgagedealkey = pool.targetpoolid
				ORDER  BY pool.NAME;

				DROP TABLE #sourcepooldetail

				DROP TABLE #poolbuilddetail

				DROP TABLE #sourcedetails 
              
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetSFPPlusDashBoardFutureDate', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''                    
                      
		RAISERROR (@errorMessage,                    
					@errorSeverity,                    
					@errorState )                    
	END CATCH      
END
GO