USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cw].[spIR_GetCounterPartyRatings]') IS NOT NULL
	DROP PROC [cw].[spIR_GetCounterPartyRatings]
	
GO

/****** Object:  StoredProcedure [cw].[spIR_GetCounterPartyRatings]    Script Date: 15/06/2021 17:55:57 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
--==================================    
--Author: Arun
--Date: 01-06-2021   
--Description: This will return the rating counter party detail for IR  
--[cw].[spIR_GetCounterPartyRatings]  '2020-04-30', 'ARDMORE1'  
--==================================     
CREATE PROCEDURE [cw].[spIR_GetCounterPartyRatings]   
(  
 @pAsAtDate datetime,   
 @pDealName  varchar(200)  
)       
AS    
BEGIN        
	BEGIN TRY     
		DECLARE   
			@dealIpdRunId		INT,  
			@dealId				SMALLINT,  
			@ipdDate			DATETIME,  
			@dealIpdRunVersion	SMALLINT,
			@dealType			VARCHAR(40)

		DECLARE
			@tblRating AS TABLE(RoleName VARCHAR(500), CRAName VARCHAR(500),RatingTypeAbbrv VARCHAR(500), RatingSection VARCHAR(500), RatingValue VARCHAR(500))
  
		
		Select  @dealId= dealId From [CW].[vw_ActiveDeal] where DealName=@pDealName

		SET @dealType =(SELECT [cw].[fnGetDealType] (@dealId))

		Select @pAsAtDate= max(Ratingdate) From  [cw].[vwCounterpartyRating] where Month(RatingDate) =  Month(@pAsAtDate) and Year(RatingDate)=Year(@pAsAtDate)

		Select cr.DisplayName AS RoleName, dc.CounterpartyName , dca.Address, dc.LegalEntityIdentifier, dc.CounterPartyType, dc.CountryEstablishment, dc.SourceLegalEntityIdentifier
		INTO #CounterParty
		From cfgcw.DealCounterparty dc
		JOIN [CW].[vw_DealLookup] dlv ON dlv.LookupValueId = dc.DealCounterpartyTypeId
		JOIN cfgcw.DealCounterpartyRoleMap dcr on dcr.DealCounterpartyId = dc.DealCounterpartyId
		JOIN cfgcw.DealCounterpartyAddress dca on dca.DealCounterpartyId = dc.DealCounterpartyId
		JOIN cfgcw.CounterpartyRole cr on cr.CounterpartyRoleId = dcr.CounterpartyRoleId
		WHERE dc.DealId = @dealId AND dlv.Name <> 'Booking'

		IF @dealType = 'RMBS'
		BEGIN
			Select cr.DisplayName AS RoleName, dc.CounterpartyName, dca.Address, cra.Name AS CRAName
			, rt.Name AS RatingType, case when rt.Name ='Long Term' Then 'LT' Else 'ST' END as RatingTypeAbbrv
			, cpRating.Rating AS CurrentRating, cpRating.RatingDate, dtrm.ThresholdRating AS TriggerRating 
			INTO #RatingData
			from [CW].[vw_ActiveDealCounterparty] dc			
			join cfgcw.DealCounterpartyRoleMap dcrm on dcrm.DealCounterpartyId = dc.DealCounterpartyId
			join cfgcw.CounterpartyRole cr on cr.CounterpartyRoleId = dcrm.CounterpartyRoleId
			join cfgcw.DealCounterpartyAddress dca on dca.DealCounterpartyId = dc.DealCounterpartyId
			join [cw].[vwCounterpartyRating] cpRating on cpRating.CisCode = dc.CisCode
			JOIN cfgcw.CreditRatingAgency cra on cra.CRAId = cpRating.CRAId
			JOIN cfgcw.RatingType rt ON rt.RatingTypeId = cpRating.RatingTypeId ANd rt.Name IN ('Long Term', 'Short Term')
			JOIN cfgCW.DealSubjectCRAMap dscm on dscm.DealId = dc.DealId AND dscm.CRAId = cra.CRAId AND dscm.DealSubjectTypeId = 2
			Left JOIN 
			(
				SELECT dtrm.ThresholdRating, dtm.SubjectId, dtm.DealId, dtrm.RatingTypeId, dtrm.DealSubjectCRAMapId FROM cfgcw.DealTriggerMap dtm 
				JOIN cfgcw.DealTriggerRatingMap dtrm on dtrm.DealTriggerMapId = dtm.DealTriggerMapId AND dtm.DealSubjectTypeId = 2 
			) dtrm
				ON dtrm.SubjectId = dc.CisCode AND dtrm.DealId = dc.DealId AND 
				dtrm.RatingTypeId = rt.RatingTypeId ANd dtrm.DealSubjectCRAMapId = dscm.DealSubjectCRAMapId
			WHERE dc.DealId = @dealId and cpRating.RatingDate=@pAsAtDate
			
			INSERT INTO @tblRating(RoleName, CRAName, RatingTypeAbbrv, RatingSection, RatingValue)
			Select distinct RoleName, CRANAme, RatingTypeAbbrv, CRANAme + ' Current Rating' as [RatingSection],  CurrentRating as RatingValue From #RatingData where CurrentRating is not NULL
			UNION ALL
			Select distinct RoleName, CRANAme, RatingTypeAbbrv, CRANAme + ' Rating Trigger', TriggerRating From #RatingData where TriggerRating is not NULL 
			
		END
		ELSE IF @dealType='Covered Bond'
		BEGIN
			Select cr.DisplayName AS RoleName, dc.CounterpartyName, dca.Address, cra.Name AS CRAName
			, rt.Name AS RatingType, 
			case when rt.Name ='Long Term' Then 'LT' when rt.Name ='Long Term Counterparty' THEN 'LT' Else 'ST' END as RatingTypeAbbrv
			, cpRating.Rating AS CurrentRating, cpRating.RatingDate, 
			CASE WHEN (dtcrm.ThresholdRating IS NULL OR dtcrm.ThresholdRating = 'N/A') THEN 'N/A' ELSE dtrm.ThresholdRating END AS TriggerRating,
			dtcrm.SeqOrder
			INTO #RatingData1
			from [CW].[vw_ActiveDealCounterparty] dc
			join cfgcw.DealCounterpartyRoleMap dcrm on dcrm.DealCounterpartyId = dc.DealCounterpartyId
			join cfgcw.CounterpartyRole cr on cr.CounterpartyRoleId = dcrm.CounterpartyRoleId
			join cfgcw.DealCounterpartyAddress dca on dca.DealCounterpartyId = dc.DealCounterpartyId
			join [cw].[vwCounterpartyRating] cpRating on cpRating.CisCode = dc.CisCode
			JOIN cfgcw.CreditRatingAgency cra on cra.CRAId = cpRating.CRAId
			JOIN cfgcw.RatingType rt ON rt.RatingTypeId = cpRating.RatingTypeId ANd rt.Name IN ('Long Term', 'Short Term', 'Long Term Counterparty')
			JOIN cfgCW.DealSubjectCRAMap dscm on dscm.DealId = dc.DealId AND dscm.CRAId = cra.CRAId AND dscm.DealSubjectTypeId = 2
			JOIN [cfgCW].[DealTriggerCPRoleRatingMap] dtcrm ON dtcrm.DealCounterpartyRoleMapId = dcrm.DealCounterpartyRoleMapId
			AND dtcrm.DealSubjectCRAMapId = dscm.DealSubjectCRAMapId 
			AND dtcrm.RatingTypeId = rt.RatingTypeId
			Left JOIN 
			(
				SELECT dtrm.ThresholdRating, dtm.SubjectId, dtm.DealId, dtrm.RatingTypeId, dtrm.DealSubjectCRAMapId, dtm.DealTriggerMapId
				FROM cfgcw.DealTriggerMap dtm 
				JOIN cfgcw.DealTriggerRatingMap dtrm on dtrm.DealTriggerMapId = dtm.DealTriggerMapId AND dtm.DealSubjectTypeId = 2 
			) dtrm
				ON dtrm.SubjectId = dc.CisCode AND dtrm.DealId = dc.DealId AND 
				dtrm.RatingTypeId = rt.RatingTypeId ANd dtrm.DealSubjectCRAMapId = dscm.DealSubjectCRAMapId
				AND dtcrm.DealTriggerMapId = dtrm.DealTriggerMapId
			WHERE dc.DealId = @dealId and cpRating.RatingDate=@pAsAtDate
			ORDER BY dtcrm.SeqOrder

			INSERT INTO @tblRating(RoleName, CRAName, RatingTypeAbbrv, RatingSection, RatingValue)
			SELECT RoleName, CRANAme, RatingTypeAbbrv, [RatingSection], RatingValue
			FROM
			(
				Select distinct RoleName, CRANAme, RatingTypeAbbrv, CRANAme + ' Current Rating' as [RatingSection],  CurrentRating as RatingValue, SeqOrder From #RatingData1 where CurrentRating is not NULL
				UNION ALL
				Select distinct RoleName, CRANAme, RatingTypeAbbrv, CRANAme + ' Rating Trigger', TriggerRating, SeqOrder From #RatingData1 where TriggerRating is not NULL 
			) AS t1
			ORDER BY SeqOrder 
			
		END
		
			
		Declare @PivotColumns varchar(max), @AppliedNullOnPivotColumns nvarchar(max)
			
		SELECT @PivotColumns= COALESCE(@PivotColumns + ',', '')  + '[' + RatingSection + ']' FROM ( SELECT DISTINCT RatingSection FROM @tblRating ) TBL ORDER BY RatingSection
		SELECT @AppliedNullOnPivotColumns= COALESCE(@AppliedNullOnPivotColumns + ',', '')  + '^' + RatingSection + '#'  + '[' + RatingSection + ']' FROM ( SELECT DISTINCT RatingSection FROM @tblRating ) TBL ORDER BY RatingSection
			
		IF @PivotColumns is NOT NULL
		BEGIN
			SELECT R.RoleName, R.[RatingSection],  STUFF( ( Select ' / ' + RatingTypeAbbrv + ' ' + CAST(RatingValue as VARCHAR(MAX))
												From @tblRating 
												where ( RoleName=R.RoleName and [RatingSection]=R.[RatingSection] )
												ORDER BY CASE WHEN RatingTypeAbbrv = 'ST' THEN 1 WHEN RatingTypeAbbrv = 'LT' THEN 2 ELSE 3 END ASC
												FOR XML PATH(''), TYPE).value('.', 'VARCHAR(MAX)'),1,2,'')  RatingValue
			INTO #TmpData
			From @tblRating R 
			where R.RatingValue is not NULL
			GROUP BY R.RoleName, R.[RatingSection]

			UPDATE #TmpData SET RatingValue = LTRIM(REPLACE(RatingValue, 'ST N/A / LT N/A', 'N/A'))
				
			Declare @HeaderColumns varchar(max) = REPLACE(Replace(   @AppliedNullOnPivotColumns, '^',  'IsNULL([' )  , '#', '] , ''N/A'') ')
			
			DECLARE @dealUniqueId  VARCHAR(255)  
			
			SELECT @dealUniqueId =(CASE WHEN @pDealName='Deimos' THEN [cw].[fnGetReportLookupValueByName]('ESMA','Deimos_UniqueId' ,'Deal_UniqueId')
												ELSE [cw].[fnGetReportLookupValueByName]('ESMA','Dunmore_UniqueId' ,'Deal_UniqueId') END)
			
			PRINT 'SELECT cp.RoleName, cp.CounterpartyName, cp.Address, ' +  @HeaderColumns + '
				, ''' + @dealUniqueId + ''' as DealUniqueId, cp.LegalEntityIdentifier, cp.CounterPartyType, cp.CountryEstablishment, cp.SourceLegalEntityIdentifier
				FROM #CounterParty cp
				LEFT JOIN 
					(
					Select RoleName, ' +  @PivotColumns + '
					FROM #TmpData td 
					PIVOT ( MAX(RatingValue) FOR [RatingSection] IN (' +  @PivotColumns + ' )) as TBL
					) data ON cp.RoleName=data.RoleName'
				

			EXEC( 'SELECT cp.RoleName, cp.CounterpartyName, cp.Address, ' +  @HeaderColumns + '
				, ''' + @dealUniqueId + ''' as DealUniqueId, cp.LegalEntityIdentifier, cp.CounterPartyType, cp.CountryEstablishment, cp.SourceLegalEntityIdentifier
				FROM #CounterParty cp
				LEFT JOIN 
					(
					Select RoleName, ' +  @PivotColumns + '
					FROM #TmpData td 
					PIVOT ( MAX(RatingValue) FOR [RatingSection] IN (' +  @PivotColumns + ' )) as TBL
					) data ON cp.RoleName=data.RoleName'
				)
	
		
		

		END 
		ELSE
			Select 'No Data is Available' as Message
			
	END TRY    
	BEGIN CATCH    
		DECLARE     
			@errorMessage     NVARCHAR(MAX),    
			@errorSeverity    INT,    
			@errorNumber      INT,    
			@errorLine        INT,    
			@errorState       INT;    
    
	 SELECT     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()    
    
	EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetCounterPartyRatings', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, 'System'    
      
	RAISERROR (@errorMessage,    
		@errorSeverity,    
        @errorState )    
	END CATCH    
END

GO
