USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetSubloanSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetSubloanSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC cw.spIR_GetSubloanSummary 
(
@pAsAtDate datetime,
 @pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL
) 
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get subloan summary for IR liability Strats
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
AS 
  BEGIN 
  	 BEGIN TRY 

   --Declare @pDealName varchar(200)='ARDMORE1'
	  --,@pAsAtDate datetime='2018-07-31'

     DECLARE @dealIpdRunId        INT,
        @dealId              SMALLINT,
        @ipdDate             DATETIME,
        @PreviousIPDDateName VARCHAR(200)='PreviousIPD',
		@PreviousRunNum      SMALLINT,
		@previousIpdDate      DATE,  
		@dealPreviousIpdRunId INT 

      IF( Object_id('tempdb..#tempCurrent') IS NOT NULL ) 
        DROP TABLE #tempCurrent 

      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL ) 
        DROP TABLE #tempPrevious 

      IF( Object_id('tempdb..#tempFinal') IS NOT NULL ) 
        DROP TABLE #tempFinal 

      IF( Object_id('tempdb..#tempPreviousInverted') IS NOT NULL ) 
        DROP TABLE #tempPreviousInverted 

		   SELECT   
	  @dealIpdRunId = dir.DealIpdRunId  
	  , @dealId = dir.DealId  
	  , @ipdDate = di.IpdDate  
	  , @previousIpdDate  = ipdDt.PreviousIPD  
	 FROM     
	  cw.vwDealIpdDates ipdDt  
	 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
	 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
	 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
	 WHERE   
	  deal.DealName = @pDealName  
	  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
	  AND dir.IpdSequence <> 0   
	        
	 SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
	 JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
	 WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1


      SELECT sl.DealSubLoanId, 
             sl.DisplayName, 
             sl.LimitAmount, 
             slPre.Principal_bf, 
             slPre.Interest_bf, 
             slPost.InterestPaid AS Coupon, 
             slPre.IntOnPrincipal, 
             slPre.IntOnBfInt, 
             slPost.Principal_cf, 
             slPost.Interest_cf 
      INTO   #tempCurrent 
      FROM   cfgcw.dealsubloan sl 
             JOIN cw.subloan_prewf slPre ON sl.DealSubLoanId = slPre.DealSubloanId 
             JOIN cw.subloan_postwf slPost ON  slPost.DealSubloanId = slPre.DealSubloanId 
					AND slPost.DealIpdRunId = slPre.DealIpdRunId            
             JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = slPre.DealIpdRunId 
      WHERE  
			 dir.DealIpdRunId = @dealIpdRunId 

      SELECT DisplayName  AS ReserveName, 
             LineItemName, 
             CurrentPeriodAmount, 
             CONVERT(DECIMAL(38, 16), NULL) PreviousPeriodAmount 
      INTO   #tempFinal 
      FROM   #tempCurrent 
             UNPIVOT ( CurrentPeriodAmount 
                     FOR LineItemName IN ( LimitAmount, 
                                           Principal_bf, 
                                           Interest_bf, 
                                           Coupon, 
                                           IntOnPrincipal, 
                                           IntOnBfInt, 
                                           Principal_cf, 
                                           Interest_cf) ) unpiv; 

      SELECT sl.DealSubLoanId, 
             sl.DisplayName, 
             sl.LimitAmount, 
             slPre.Principal_bf, 
             slPre.Interest_bf, 
             slPost.InterestPaid AS Coupon,  
             slPre.IntOnPrincipal, 
             slPre.IntOnBfInt, 
             slPost.Principal_cf, 
             slPost.Interest_cf 
      INTO   #tempPrevious 
      FROM   cfgcw.dealsubloan sl 
             JOIN cw.subloan_prewf slPre ON sl.DealSubLoanId = slPre.DealSubloanId 
             JOIN cw.subloan_postwf slPost ON  slPost.DealSubloanId = slPre.DealSubloanId 
					AND slPost.DealIpdRunId = slPre.DealIpdRunId            
             JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = slPre.DealIpdRunId 
      WHERE  
			 dir.DealIpdRunId = @DealPreviousIpdRunId 

      SELECT DisplayName AS ReserveName, 
             LineItemName, 
             PreviousPeriodAmount 
      INTO   #tempPreviousInverted 
      FROM   #tempPrevious 
             UNPIVOT ( PreviousPeriodAmount 
                     FOR LineItemName IN ( LimitAmount, 
                                           Principal_bf, 
                                           Interest_bf, 
                                           Coupon, 
                                           IntOnPrincipal, 
                                           IntOnBfInt, 
                                           Principal_cf, 
                                           Interest_cf) ) unpiv; 

      UPDATE #tempFinal 
      SET    #tempfinal.PreviousPeriodAmount = #temppreviousinverted.PreviousPeriodAmount 
      FROM   #tempFinal, 
             #tempPreviousInverted 
      WHERE  #tempfinal.ReserveName = #temppreviousinverted.ReserveName 
             AND #tempfinal.LineItemName = #temppreviousinverted.LineItemName 

      SELECT ReserveName, 
             LineItemName, 
             CONVERT(DECIMAL(38, 2), Round(CurrentPeriodAmount, 2))  CurrentPeriodAmount, 
             CONVERT(DECIMAL(38, 2), Round(PreviousPeriodAmount, 2)) PreviousPeriodAmount 
      FROM   #tempFinal 
      ORDER  BY ReserveName 
    END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetSubloanSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  END 

GO