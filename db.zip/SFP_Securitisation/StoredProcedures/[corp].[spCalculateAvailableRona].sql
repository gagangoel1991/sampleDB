USE SFP_Securitisation
GO



IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spCalculateAvailableRona]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spCalculateAvailableRona]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
ASSUMPTIONS:
- DealRegConstraint and DealLegalConstraint is storing 80% and not 20% as the value
- This logic will not be used in repurchase
- For Analysis pool, 100% of TCE will be used and the existing logic in poolbuild caters to that

DECLARE @FacilityIds corp.FacilityList
INSERT INTO @FacilityIds SELECT FacilityKey FROM (Values ('430691800')) T(FacilityKey)
exec CORP.spCalculateAvailableRona 767, '1', @FacilityIds, 'test'
*/

CREATE PROC CORP.spCalculateAvailableRona
(
	@PoolId INT = 0,  
	@DealKey varchar(500),
	@FacilityIds corp.FacilityList READONLY,
	@UserName VARCHAR(50),
	@EffectiveDate DATE = NULL,
	@TargetDealId INT = 0,
	@RowIDParam Varchar(50) = ''
)
AS
BEGIN
	DECLARE --@TargetDealId INT,
			@TargetDealName VARCHAR(50),
			@TargetDealRegConstraint DECIMAL(15, 14),
			@TargetDealLegalConstraint DECIMAL(15, 14),
			@TargetDealRonaBasedOnField VARCHAR(100),
			@VintageDate DATE, @TargetDate DATE,
			@DealIds varchar(500) = '';
			
	IF OBJECT_ID('tempdb..#FacilityDetails') IS NOT NULL
		DROP TABLE #FacilityDetails
	
	IF OBJECT_ID('tempdb..#FinalFacilityBalance') IS NOT NULL
		DROP TABLE #FinalFacilityBalance
	
	IF OBJECT_ID('tempdb..#FacilityGroupedDetails') IS NOT NULL
		DROP TABLE #FacilityGroupedDetails

	IF OBJECT_ID('tempdb..#FacilityFinalCalc') IS NOT NULL
		DROP TABLE #FacilityFinalCalc

	IF OBJECT_ID('tempdb..#FacilityIdList') IS NOT NULL
		DROP TABLE #FacilityIdList

	IF OBJECT_ID('tempdb..#tempFacilityIdwithP') IS NOT NULL
		DROP TABLE #tempFacilityIdwithP

	IF OBJECT_ID('tempdb..#tmpAllFacilities') IS NOT NULL
		DROP TABLE #tmpAllFacilities

	CREATE TABLE #FacilityDetails (
		FacilityId varchar(100) COLLATE Latin1_General_CI_AS, 
		FacilityKey bigint, 
		DealName varchar(40) COLLATE Latin1_General_CI_AS,
		CommittedExposure DECIMAL(18,2),
		Utilisation DECIMAL(18,2),
		RONA DECIMAL(18,2)
	);
		
	BEGIN TRY

		--IF (@PoolId > 0 AND @EffectiveDate IS NOT NULL )  
		--BEGIN  
		--	SELECT @TargetDealId = TargetPoolId, @VintageDate = VintageDate FROM PS.Pool WHERE PoolId = @PoolId And IsActive = 1   
			
		--	DECLARE @MaxPartitionID VARCHAR(10), @LastPartitionDate DATE  
		--	SELECT @MaxPartitionID =  max(partitionid) from [corp].[syn_SfpModelCorporate_vw_FactFacility]  
		--	SELECT @LastPartitionDate = CONVERT(DATE, @MaxPartitionID)

		--	IF(DATEDIFF(D, @EffectiveDate, @LastPartitionDate) < 0) -- IF Eff-Date IS GREATER THAN LAST PARTITION DATE THEN USE VINTAGE DATE OF POOL
		--	BEGIN 
		--		PRINT 'Rona calculated based on Vintage Date'
		--		SELECT @TargetDate = @VintageDate
		--	END
		--	ELSE
		--	BEGIN
		--		PRINT 'Rona calculated based on Effective Date'
		--		SELECT @TargetDate = @EffectiveDate
		--	END
		--END 
		--ELSE IF (@PoolId > 0)
		--BEGIN
		--	SELECT @TargetDealId = TargetPoolId, @TargetDate = VintageDate FROM PS.Pool WHERE PoolId = @PoolId And IsActive = 1  
		--END
		--ELSE
		--BEGIN
		--	SELECT @TargetDate = @EffectiveDate 
		--END

		--TO MATCH WITH ETL VALIDATION, HERE WE ARE CALCULATING RONA BASED ON TARGET DEAL'S FxRateDate, IF THIS IS NOT AVAILABLE THEN VINTAGE DATE : 26-APR-2023
		IF (@PoolId > 0)
		BEGIN
			SELECT @TargetDealId = TargetPoolId, @TargetDate = VintageDate FROM PS.Pool WHERE PoolId = @PoolId 
			DECLARE @FxRateDate DATETIME  = (SELECT FxRateDate FROM cfg.Deal
											 WHERE DealName = (SELECT DealName FROM [corp].[syn_SfpModelCorporate_vw_dimCorporateDeal] WHERE DealId = @TargetDealId))
			--IF(@FxRateDate IS NOT NULL)
			--BEGIN
			--	SELECT @TargetDate = @FxRateDate
			--END
		END
		ELSE
		BEGIN
			SELECT @TargetDate = @EffectiveDate 
		END
		
		-- Populate Target Deal details
		SELECT  @TargetDealName = CD.DealName,
				@TargetDealRegConstraint = ISNULL(CD.DealRetentionPercent, 1),
				@TargetDealLegalConstraint = ISNULL(CD.LegalRetentionPercent, 1),
				@TargetDealRonaBasedOnField = CD.RonaCalculatedBasedOn
		FROM [corp].[syn_SfpModelCorporate_vw_dimCorporateDeal] CD
		JOIN cfg.Deal D
			ON CD.DealName = D.DealName AND CD.IsActive = 'Y'
		WHERE CD.DealId = @TargetDealId
		
		-- Get Facility Details for calculation from common SP
		DECLARE @PartitionId INT = CONVERT(INT, CONVERT(VARCHAR(8),@TargetDate,112))
		SELECT FF.FacilityId AS FacilityKey 
		  INTO #tempFacilityIdwithP 
		  FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] FF
		  JOIN @FacilityIds FI
		    ON REPLACE(FI.FacilityKey, '\P', '') = REPLACE(FF.FacilityId, '\P', '')
		 WHERE FF.partitionid = @PartitionId
		
		

		DECLARE @ReqCols XML = NULL
		SELECT @ReqCols = ( 
			SELECT T.CriteriaFieldName
			FROM (
				VALUES ('FacilityId'), ('FacilityKey'), ('DealName'), ('CommittedExposure'), ('UtilisationGBP_ReportingDate'), ('RONA')
			) T(CriteriaFieldName)
			FOR XML PATH('Node'), ROOT('Root') 
		)
		
		SET @DealIds = ''
		DECLARE @XmlData XML = NULL

				
		SELECT DISTINCT PB.FacilityKey AS FacilityKey, ISNULL(FCAP.DealId, -1) AS DealId, CD.DealName
		INTO #tmpAllFacilities
		FROM #tempFacilityIdwithP PB
		LEFT JOIN [corp].[syn_SfpModelCorporate_vw_FactCorporateAssetPool] FCAP
			ON FCAP.FacilityId = PB.FacilityKey
		LEFT JOIN [corp].[syn_SfpModelCorporate_vw_dimCorporateDeal] CD
			ON ISNULL(FCAP.DealId, -1) = CD.DealId

		UPDATE #tmpAllFacilities SET FacilityKey = REPLACE(FacilityKey, '\P', '')

		DECLARE @CallCommonSP BIT = 1
		IF LEN(@RowIDParam) > 0
		BEGIN
			SELECT T.FacilityKey, T.DealId, T.DealName INTO #tmpFilteredList 
			FROM #tmpAllFacilities T
			JOIN (
				SELECT FacilityKey, DealName FROM #tmpAllFacilities
				EXCEPT
				SELECT DISTINCT FacilityId, DealName FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowIDParam
			) E
			ON T.FacilityKey = E.FacilityKey AND T.DealName = E.DealName

			IF (SELECT COUNT(1) FROM #tmpFilteredList) > 0
			BEGIN
				SELECT @XmlData = ( SELECT DISTINCT FacilityKey  FROM #tmpFilteredList FOR XML PATH('Node'), ROOT('Root'))
				SELECT @DealIds = @DealIds + ',' + CAST(FCAP.DealId AS VARCHAR(50)) FROM #tmpFilteredList FCAP GROUP BY FCAP.DealId ORDER BY FCAP.DealId
				SET @DealIds = STUFF(@DealIds, 1, 1, '')
			END
			ELSE
				SET @CallCommonSP = 0

			INSERT INTO #FacilityDetails(FacilityId, FacilityKey, DealName, CommittedExposure, Utilisation, RONA)
			SELECT DISTINCT FacilityId, FacilityKey, DealName, 
			   TRY_CAST(CommittedExposure AS DECIMAL(18,2)) AS CommittedExposure, 
			   TRY_CAST(UtilisationGBP_ReportingDate AS DECIMAL(18,8)) AS Utilisation, 
			   TRY_CAST(RONA AS DECIMAL(18,8)) AS RONA
			FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowIDParam
		END
		ELSE
		BEGIN
			SELECT @XmlData = ( SELECT DISTINCT FacilityKey  FROM #tmpAllFacilities FOR XML PATH('Node'), ROOT('Root'))
			SELECT @DealIds = @DealIds + ',' + CAST(FCAP.DealId AS VARCHAR(50)) FROM #tmpAllFacilities FCAP GROUP BY FCAP.DealId ORDER BY FCAP.DealId
			SET @DealIds = STUFF(@DealIds, 1, 1, '')
		END

		Declare @RowID Varchar(50) = '' 

		-- Call Common SP only when either no RowIDParam has been passed OR there are some facilities for which Common SP can be called.
		IF ( LEN(@RowIDParam) > 0 AND @CallCommonSP = 1 ) OR ( LEN(@RowIDParam) = 0 )
		BEGIN	
			EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
				@VintageDate = @TargetDate,    
				@DealKey  = @DealIds,    
				@FacilityIds = NULL,    
				@ReqColumns  = @ReqCols,    
				@XmlData = @XmlData,
				@FxRateDate = @FxRateDate,
				@OutputRowID = @RowID OUTPUT

			INSERT INTO #FacilityDetails(FacilityId, FacilityKey, DealName, CommittedExposure, Utilisation, RONA)
			SELECT DISTINCT FacilityId, FacilityKey, DealName, 
				TRY_CAST(CommittedExposure AS DECIMAL(18,2)) AS CommittedExposure, 
				TRY_CAST(UtilisationGBP_ReportingDate AS DECIMAL(18,8)) AS Utilisation, 
				TRY_CAST(RONA AS DECIMAL(18,8)) AS RONA
			FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

			DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
		END
		
		CREATE TABLE #FinalFacilityBalance (
			FacilityKey BIGINT,
			FacilityId BIGINT,
			TCE DECIMAL(19, 2),
			Utilisation DECIMAL(19, 2),
			DealName VARCHAR(100),
			RONA DECIMAL(19, 2),
			DealRegConstraint DECIMAL(15, 14),
			DealLegalConstraint DECIMAL(15, 14),
			DealRonaBasedOnField VARCHAR(100),
			MaxApplicableRonaForReg DECIMAL(34,16),
			MaxApplicableRonaForLegal DECIMAL(34,16),
			MinRonaForDeal DECIMAL(34,16),
		)
		
		CREATE TABLE #FacilityGroupedDetails (
			FacilityKey BIGINT,
			FacilityId BIGINT,
			TCE DECIMAL(19, 2),
			Utilisation DECIMAL(19, 2),
			MinRonaForAllocatedDeal DECIMAL(18, 5),
			TotalAllocatedRona DECIMAL(18, 5)
		)
		
		-- Insert Facilities that are part of some deal
		INSERT INTO #FinalFacilityBalance (
				FacilityKey, FacilityId, TCE, Utilisation, DealName, RONA, DealRegConstraint, DealLegalConstraint, 
				DealRonaBasedOnField, MaxApplicableRonaForReg, MaxApplicableRonaForLegal)
		SELECT FD.FacilityKey, 
			   FD.FacilityId,
			   FD.CommittedExposure AS TCE,
			   FD.Utilisation,
			   FD.DealName,
			   FD.RONA,
			   ISNULL(CD.DealRetentionPercent, 1), 
			   ISNULL(CD.LegalRetentionPercent, 1), 
			   CD.RonaCalculatedBasedOn,
			   CASE
					WHEN CD.RonaCalculatedBasedOn = 'TotalCreditLimit' 	THEN FD.CommittedExposure * ISNULL(CD.DealRetentionPercent, 1)
					WHEN CD.RonaCalculatedBasedOn = 'Utilisation'		THEN FD.Utilisation * ISNULL(CD.DealRetentionPercent, 1)
			   END AS MaxApplicableRonaForReg,
			   CASE
					WHEN CD.RonaCalculatedBasedOn = 'TotalCreditLimit' 	THEN FD.CommittedExposure * ISNULL(CD.LegalRetentionPercent, 1)
					WHEN CD.RonaCalculatedBasedOn = 'Utilisation'		THEN FD.Utilisation * ISNULL(CD.LegalRetentionPercent, 1)
			   END AS MaxApplicableRonaForLegal
		  FROM #FacilityDetails FD
		  JOIN cfg.Deal D
			ON D.DealName = FD.DealName AND D.IsActive = 1 AND D.AssetClassId = 2
		  JOIN [corp].[syn_SfpModelCorporate_vw_dimCorporateDeal] CD
		    ON CD.DealName = FD.DealName
		  
		-- Insert facilities that are part of No Deal
		INSERT INTO #FinalFacilityBalance (
			   FacilityKey, FacilityId, TCE, Utilisation, DealName, RONA, DealRegConstraint, DealLegalConstraint, 
			   DealRonaBasedOnField, MaxApplicableRonaForReg, MaxApplicableRonaForLegal)
		SELECT FD.FacilityKey, 
			   FD.FacilityId,
			   FD.CommittedExposure AS TCE,
			   FD.Utilisation,
			   FD.DealName,
			   FD.RONA,
			   @TargetDealRegConstraint, 
			   @TargetDealLegalConstraint, 
			   @TargetDealRonaBasedOnField,
			   CASE
					WHEN @TargetDealRonaBasedOnField = 'TotalCreditLimit' 	THEN FD.CommittedExposure * @TargetDealRegConstraint
					WHEN @TargetDealRonaBasedOnField = 'Utilisation'		THEN FD.Utilisation * @TargetDealRegConstraint
			   END AS MaxApplicableRonaForReg,
			   CASE
					WHEN @TargetDealRonaBasedOnField = 'TotalCreditLimit' 	THEN FD.CommittedExposure * @TargetDealLegalConstraint
					WHEN @TargetDealRonaBasedOnField = 'Utilisation'		THEN FD.Utilisation * @TargetDealLegalConstraint
			   END AS MaxApplicableRonaForLegal
		  FROM #FacilityDetails FD
		 WHERE FD.DealName = 'NA'
		
		UPDATE #FinalFacilityBalance
		   SET MinRonaForDeal = IIF( MaxApplicableRonaForReg < MaxApplicableRonaForLegal, MaxApplicableRonaForReg, MaxApplicableRonaForLegal )
		
		DECLARE @MinTargetDealConstraint DECIMAL(15,14)
		SET @MinTargetDealConstraint = IIF(@TargetDealRegConstraint < @TargetDealLegalConstraint, @TargetDealRegConstraint, @TargetDealLegalConstraint)
		
		INSERT INTO #FacilityGroupedDetails (FacilityKey, FacilityId, TCE, Utilisation, MinRonaForAllocatedDeal, TotalAllocatedRona)
		SELECT FFB.FacilityKey, 
			   FFB.FacilityId,
			   FFB.TCE,
			   FFB.Utilisation,
			   MIN( MinRonaForDeal ) AS MinRonaForAllocatedDeal,
			   SUM( RONA ) AS TotalAllocatedRona
		  FROM #FinalFacilityBalance FFB
	  GROUP BY FFB.FacilityKey, 
			   FFB.FacilityId,
			   FFB.TCE,
			   FFB.Utilisation
		
		SELECT T.FacilityId,
			   T.FacilityKey,
			   CASE
					WHEN @TargetDealRonaBasedOnField = 'TotalCreditLimit' THEN 
						IIF( (@MinTargetDealConstraint * TCE) < MinRonaForAllocatedDeal, (@MinTargetDealConstraint * TCE), MinRonaForAllocatedDeal ) - TotalAllocatedRona
					WHEN @TargetDealRonaBasedOnField = 'Utilisation' THEN 
						IIF( (@MinTargetDealConstraint * Utilisation) < MinRonaForAllocatedDeal, (@MinTargetDealConstraint * Utilisation), MinRonaForAllocatedDeal ) - TotalAllocatedRona
			   END AS AvailableRonaForAllocation
		  INTO #FacilityFinalCalc
		  FROM #FacilityGroupedDetails T
		  
		-- Set Calculated RONA to zero if it is negative or null
		SELECT FacilityId, FacilityKey, IIF(AvailableRonaForAllocation < 0 OR AvailableRonaForAllocation IS NULL, 0, AvailableRonaForAllocation)
		  FROM #FacilityFinalCalc
		
	END TRY     
    
	BEGIN CATCH    
		DECLARE     
			@errorMessage     NVARCHAR(MAX),    
			@errorSeverity    INT,    
			@errorNumber      INT,    
			@errorLine        INT,    
			@errorState       INT;    
		SELECT     
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()            

		EXEC app.SaveErrorLog 2, 1, 'spCalculateAvailableRona', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @UserName    

		RAISERROR (@errorMessage,    
			@errorSeverity,    
			@errorState )    
	END CATCH;    
END
GO
