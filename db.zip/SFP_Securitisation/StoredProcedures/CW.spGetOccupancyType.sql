USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetOccupancyType') IS NOT NULL
	DROP PROC CW.spGetOccupancyType;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:    20.05.2020
 * Description:  This will return Occupancy Type for Investor report.
 * Usage : CW.spGetOccupancyType @pAsAtDate  ='30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetOccupancyType @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY  
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
				
				
BEGIN TRY

	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	 , @totalNumberofSubAccounts float
	 , @totalOutstandingCapitalBalance float
	 , @totalTrueBalance float

	SELECT @totalNumberofSubAccounts = COUNT(ISNULL(VMS.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(VMS.TotalOutstandingCapitalBalance, 0)) 
		, @totalTrueBalance  = SUM(ISNULL(VMS.TrueBalance, 0)) 
	FROM CW.VwMortgageSubAccount VMS
	WHERE PartitionID = (@partitionID_AsAtDate)  
		AND DealName = @pDealName  
	GROUP BY MortgageDealKey, BusinessDate 

	---prepare base data se
	SELECT VMS.LoanID, VMS.SubAccountNumber, VMS.MortgageSubAccountKey, VMS.InterestRateRevisionGroupKey , VMS.TotalOutstandingCapitalBalance , VMS.TrueBalance
	, VMS.PropertyKey, VMS.ProductType
	, HD.HoldCode
	INTO #common
	FROM CW.VwMortgageSubAccount VMS
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeHoldCodeGroup AS HCD  ON VMS.[holdcodegroupkey] = HCD.[holdcodegroupkey]  
	INNER JOIN sfp.syn_SfpModel_tbl_HoldCode AS HD  ON HCD.[holdcodekey] = HD.[holdcodekey] 	
	WHERE PartitionID = (@partitionID_AsAtDate)  
		AND DealName = @pDealName  
	

	---interim table for BTL calculation  		
	SELECT C.MortgageSubAccountKey , C.LoanID  
    INTO #InterestRatecomm  
    FROM   #common AS C
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeInterestRateRevesionGroup AS birrg WITH(NOLOCK) ON c.InterestRateRevisionGroupKey = birrg.InterestRateRevisionGroupKey  
	INNER JOIN sfp.syn_SfpModel_tbl_InterestRate AS dir WITH(NOLOCK) ON birrg.InterestRateKey = dir.InterestRateKey  
	WHERE  c.SubAccountNumber = 1  
	AND ( C.ProductType = 'BTL'  OR C.HoldCode = 'B2L'  OR dir.BaseRateCode = 'BTL')
	

	SELECT DISTINCT  dp.PropertyUsageCode AS Header, C.MortgageSubAccountKey, C.TotalOutstandingCapitalBalance, C.TrueBalance
	INTO #BTLType  
	FROM   #common AS C
	INNER JOIN sfp.syn_SfpModel_tbl_BridgeInterestRateRevesionGroup AS birrg WITH(NOLOCK) ON c.InterestRateRevisionGroupKey = birrg.InterestRateRevisionGroupKey  
	INNER JOIN sfp.syn_SfpModel_tbl_InterestRate AS dir WITH(NOLOCK) ON birrg.InterestRateKey = dir.InterestRateKey  
	INNER JOIN sfp.syn_SfpModel_tbl_Property AS dp ON C.PropertyKey = dp.PropertyKey  
	LEFT JOIN #InterestRatecomm  AS D ON D.LoanID = C.LoanID  
	--WHERE  (dp.PropertyUsageCode = '4' ) OR ( D.LoanID is NOT NULL)
	--WHERE   D.LoanID is NOT NULL

	--Select * From #BTLType where Header=4
	--Select * From #BTLType where Header IN ('1', '2', '3', '5', '6')  
	
	 	
	SELECT O.Header  'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalNumberofSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Float) , 0) 'TotalOutCapitalBalance' 
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent  
	, ISNULL(CAST(sum(TrueBalance) AS Float) , 0) TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) * 100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TrueBalancePercent  
	FROM #BTLType O
	GROUP BY ALL O.Header 

		
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetOccupancyType', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			

END


GO
