USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetAutomatedStormVsSfpData') IS NOT NULL
	DROP PROC cw.spGetAutomatedStormVsSfpData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*--====================================================================
 * Author: Saurabh Bhatia
 * Date: 28-06-2021   
 * Description: This will return the Storm vs Sfp Data
 * EXEC cw.spGetAutomatedStormVsSfpData 14,8,'bhasaaa' 		
--==================================================================== */
CREATE PROCEDURE cw.spGetAutomatedStormVsSfpData @pDealId SMALLINT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @collectionBusinessStart DATE
			,@collectionBusinessEnd DATE
			,@ipdMinus1BusinessDay DATE
			,@ipdDate DATE
			,@nextCollectionStartDate DATE
		--Output Variables
		DECLARE @stormRevCashCollPeriod DECIMAL(38, 18)
			,@stormRevCashCollPostIpdPeriod DECIMAL(38, 18)
			,@sfpRevCashCollPeriod DECIMAL(38, 18)
			,@sfpRevCashCollPostIpdPeriod DECIMAL(38, 18)
			,@stormPrinCashCollPeriod DECIMAL(38, 18)
			,@stormPrinCashCollPostIpdPeriod DECIMAL(38, 18)
			,@sfpPrinCashCollPeriod DECIMAL(38, 18)
			,@sfpPrinCashCollPostIpdPeriod DECIMAL(38, 18)
			,@sfpRevAdjustment DECIMAL(38, 18)
			,@sfpPrinAdjustment DECIMAL(38, 18)
			,@sfpRevDeflaggedReceipts DECIMAL(38, 18)
			,@sfpPrinDeflaggedReceipts DECIMAL(38, 18)
			,@sfpPrinFurtherAdvances DECIMAL(38, 18)
			,@dealType	VARCHAR(40)

		SELECT @collectionBusinessStart = did.CollectionBusinessStart
			,@collectionBusinessEnd = did.CollectionBusinessEnd
			,@ipdMinus1BusinessDay = did.[IPD-1BusinessDay]
			,@ipdDate = did.IPD
		FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
		WHERE dir.RunId = @pIPDRunId

		SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

		--Todo -- Need to change and pick the value from view cw.vwDealIpdDates
		SELECT @nextCollectionStartDate = DATEADD(MONTH, - 1, DATEADD(DAY, 1, EOMONTH(@ipdDate)))

		--STORM Revenue -- Cash for Collection Period
		SELECT @stormRevCashCollPeriod = SUM(FinanceCollections)
		FROM cw.collectionledger
		WHERE DealId = @pDealId
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		--STORM Revenue -- Cash for Post IPD Period
		SELECT @stormRevCashCollPostIpdPeriod = SUM(FinanceCollections)
		FROM cw.collectionledger
		WHERE DealId = @pDealId
			AND CAST(CollectionDate AS DATE) BETWEEN @nextCollectionStartDate
				AND @ipdMinus1BusinessDay

		--SFP Revenue -- Cash for Collection Period
		SELECT @sfpRevCashCollPeriod = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(38, 18)))
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'TotalRevenueReceipts'
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		--SFP Revenue -- Cash for Post IPD Period
		SELECT @sfpRevCashCollPostIpdPeriod = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(38, 18)))
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'TotalRevenueReceipts'
			AND CAST(CollectionDate AS DATE) BETWEEN @nextCollectionStartDate
				AND @ipdMinus1BusinessDay

		--STORM Principal -- Cash for Collection Period
		SELECT @stormPrinCashCollPeriod = SUM(NetPrincipalCollections)
		FROM cw.collectionledger
		WHERE DealId = @pDealId
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		--STORM Principal -- Cash for Post IPD Period
		SELECT @stormPrinCashCollPostIpdPeriod = SUM(NetPrincipalCollections)
		FROM cw.collectionledger
		WHERE DealId = @pDealId
			AND CAST(CollectionDate AS DATE) BETWEEN @nextCollectionStartDate
				AND @ipdMinus1BusinessDay

		--SFP Principal -- Cash for Collection Period
		SELECT @sfpPrinCashCollPeriod = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(36, 18)))
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'PrincipalReceipts'
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		--SFP Principal -- Cash for Post IPD Period
		SELECT @sfpPrinCashCollPostIpdPeriod = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(36, 18)))
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'PrincipalReceipts'
			AND CAST(CollectionDate AS DATE) BETWEEN @nextCollectionStartDate
				AND @ipdMinus1BusinessDay

		--SFP Revenue - Adjustment
		SELECT @sfpRevAdjustment = (SUM(ISNULL(wla.AdjustedAmount, 0.0)) * - 1)
		FROM cfgCW.WaterfallCategory wc
		INNER JOIN cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId
		LEFT JOIN cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId
			AND DealIpdRunId = @pIPDRunId
		WHERE dealId = @pDealId
			AND wc.InternalName = 'PreAvailableRevenueReceipts'
			AND wli.InternalName = CASE WHEN @dealType = 'Covered Bond' THEN 'PreAvailableRevenueReceipts_1.000' ELSE 'PreAvailableRevenueReceipts_2.100' END;

		--SFP Principal - Adjustment
		SELECT @sfpPrinAdjustment = (SUM(ISNULL(wla.AdjustedAmount, 0.0)) * - 1)
		FROM cfgCW.WaterfallCategory wc
		INNER JOIN cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId
		LEFT JOIN cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId
			AND DealIpdRunId = @pIPDRunId
		WHERE dealId = @pDealId
			AND wc.InternalName = 'PreAvailablePrincipalReceipts'
			AND wli.InternalName IN ('PreAvailablePrincipalReceipts_1.100','PreAvailablePrincipalReceipts_1.200','PreAvailablePrincipalReceipts_1.300')

		--SFP Revenue Deflagged Receipts
		SELECT @sfpRevDeflaggedReceipts = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(36, 18)))
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'DeflaggedRevenueReceipts'
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		--SFP Principal Deflagged Receipts
		SELECT @sfpPrinDeflaggedReceipts = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(36, 18)))
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'DeflaggedPrincipalReceipts'
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		--SFP Further Stage Advances
		SELECT @sfpPrinFurtherAdvances = (SUM(CAST(ISNULL(dc.DailyCollectionValue, 0.0) AS DECIMAL(36, 18)))*-1)
		FROM [cw].[vwDailyCollection] dc
		WHERE dc.DealId = @pDealId
			AND dc.DailyCollectionFieldColumnName = 'FurtherStageAdvances'
			AND CAST(CollectionDate AS DATE) BETWEEN @collectionBusinessStart
				AND @collectionBusinessEnd

		SELECT @stormRevCashCollPeriod AS StormRevCashCollPeriod
			,@stormRevCashCollPostIpdPeriod AS StormRevCashCollPostIpdPeriod
			,@sfpRevCashCollPeriod AS SfpRevCashCollPeriod
			,@sfpRevCashCollPostIpdPeriod AS SfpRevCashCollPostIpdPeriod
			,@stormPrinCashCollPeriod AS StormPrinCashCollPeriod
			,@stormPrinCashCollPostIpdPeriod AS StormPrinCashCollPostIpdPeriod
			,@sfpPrinCashCollPeriod AS SfpPrinCashCollPeriod
			,@sfpPrinCashCollPostIpdPeriod AS SfpPrinCashCollPostIpdPeriod
			,@sfpRevAdjustment AS SfpRevAdjustment
			,@sfpPrinAdjustment AS SfpPrinAdjustment
			,@sfpRevDeflaggedReceipts AS SfpRevDeflaggedReceipts
			,@sfpPrinDeflaggedReceipts AS SfpPrinDeflaggedReceipts
			,@sfpPrinFurtherAdvances AS SfpPrinFurtherAdvances
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cw.spGetAutomatedStormVsSfpData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO

