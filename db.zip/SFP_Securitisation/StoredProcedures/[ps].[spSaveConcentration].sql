USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spSaveConcentration]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spSaveConcentration]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spSaveConcentration]
(
	@pCtId INT = NULL,
	@pCtName VARCHAR(100),	
	@pCtDescription VARCHAR(400) = NULL,	
	@pCtType INT,
	@pCtStatus INT,
	@pCtAssetType INT,
	@pFieldId INT = NULL,
	@pCtCriteriaFieldOperator INT  = NULL,
	@pCtExpectedValue VARCHAR(100) = NULL,
	@pCtLimitOperator INT,
	@pCtLimitPercentage DECIMAL(19, 2),
	@pCtExpression VARCHAR(MAX),
	@pCtExpressionSuperSet VARCHAR(MAX) = NULL,
	@pCtTag VARCHAR(50) = NULL,
	@pUserName VARCHAR(20),
	@pCTConditionsSuperset AS ps.CTCondition READONLY,
	@pCTConditionsSubset AS ps.CTCondition READONLY,
	@pIsSubSetReq BIT = 1,
	@pDMLType INT = 1,                                 
	@pReturnValue INT = 0 OUTPUT,
	@pReturnMessage VARCHAR(100) = NULL OUTPUT
)
AS
BEGIN                                   
	BEGIN TRY
		DECLARE @CurrentDateTime DATETIME = GETUTCDATE()
		DECLARE	@Active BIT = 1
		DECLARE @workflowType VARCHAR(50)='Concentration_Test'
		DECLARE @stepName VARCHAR(50)='Draft'
		DECLARE @NewCTComment  VARCHAR(250)='Concentration Test created'
		DECLARE @UpdateCTComment  VARCHAR(250)='Concentration Test updated'
		DECLARE @DraftStatusId INT = 1

		IF(@pDMLType = 1)
		BEGIN 
			IF NOT EXISTS(SELECT 1 FROM [ps].[ConcentrationTest] WHERE CriteriaName = @pCtName AND AssetClassId = @pCtAssetType AND IsActive = @Active)
			BEGIN 
				IF NOT EXISTS(SELECT 1 FROM [ps].[ConcentrationTest] WHERE CtExpression = @pCtExpression AND CtExpression_Superset = @pCtExpressionSuperSet AND LimitOperator = @pCtLimitOperator AND LimitPercentage = @pCtLimitPercentage AND IsActive = @Active)
				BEGIN
					INSERT INTO [ps].[ConcentrationTest]
					(
						CriteriaName,
						[Description],
						ConcentrationTestTypeId,
						StatusId,
						AssetClassId,
						AnalysisCriteriaFieldId,
						CriteriaFieldOperator,
						ExpectedValue,
						LimitOperator,
						LimitPercentage,
						isActive,
						CtExpression,
						CtExpression_Superset,
						ConcentrationTestTagId,
						CreatedBy,
						CreatedDate,
						ModifiedBy,
						ModifiedDate,
						IsSubsetRequired
					)
					VALUES
					(
						@pCtName,
						@pCtDescription,
						@pCtType,
						@pCtStatus,
						@pCtAssetType,
						@pFieldId,
						@pCtCriteriaFieldOperator,
						@pCtExpectedValue,
						@pCtLimitOperator,
						@pCtLimitPercentage,
						@Active,
						@pCtExpression,
						@pCtExpressionSuperSet,
						@pCtTag,
						@pUserName,
						@CurrentDateTime,
						@pUserName,
						@CurrentDateTime,
						@pIsSubSetReq
					)
					SET @pReturnValue= SCOPE_IDENTITY()
					EXEC [ps].[spManageAuthWorkflow] @pWorkflowType=@workflowType, @pPsId=@pReturnValue,@pStatus=@DraftStatusId,@pStepName=@stepName,@pComment=@NewCTComment,@pUserName=@pUserName
					
					/* Inserting Superset Conditions */ 
						
					INSERT INTO [ps].[ConcentrationTestCondition]
						([ConcentrationTestId]
						,[EligibilityCriteriaFieldId]
						,[ConcentrationTestSetId]
						,[Condition]
						,[CriteriaFieldOperator]
						,[ExpectedValue]
						,[IsActive]
						,[CreatedBy]
						,[CreatedDate]
						,[ModifiedBy]
						,[ModifiedDate])
					SELECT 
						@pReturnValue
						,[FieldId]
						,1
						,[Condition]
						,[Operator].[Operator]
						,[ConditionalValue]
						,@Active
						,@pUserName
						,@CurrentDateTime
						,@pUserName
						,@CurrentDateTime
					FROM @pCTConditionsSuperset CtCond
					LEFT JOIN ps.Operator Operator ON Operator.OperatorId = CtCond.ConditionalOperator
					ORDER BY CtCond.Id

					/* Inserting Subset Conditions */

					INSERT INTO [ps].[ConcentrationTestCondition]
						([ConcentrationTestId]
						,[EligibilityCriteriaFieldId]
						,[ConcentrationTestSetId]
						,[Condition]
						,[CriteriaFieldOperator]
						,[ExpectedValue]
						,[IsActive]
						,[CreatedBy]
						,[CreatedDate]
						,[ModifiedBy]
						,[ModifiedDate])
					SELECT 
						@pReturnValue
						,[FieldId]
						,2
						,[Condition]
						,[Operator].[Operator]
						,[ConditionalValue]
						,@Active
						,@pUserName
						,@CurrentDateTime
						,@pUserName
						,@CurrentDateTime
					FROM @pCTConditionsSubset CtCond
					LEFT JOIN ps.Operator Operator ON Operator.OperatorId = CtCond.ConditionalOperator
					ORDER BY CtCond.Id
				END
				ELSE
				BEGIN
					SET @pReturnValue = -3
					SET @pReturnMessage = (SELECT CriteriaName FROM [ps].[ConcentrationTest] WHERE CTExpression = @pCtExpression AND LimitOperator = @pCtLimitOperator AND LimitPercentage = @pCtLimitPercentage AND IsActive = @Active AND ConcentrationTestId <> @pCtId)
				END
			END
			ELSE
			BEGIN
				SET @pReturnValue = -2				
			END
		END
		ELSE
		BEGIN

					IF NOT EXISTS
					(
						SELECT 1
						FROM [ps].[ConcentrationTest]
						WHERE CriteriaName = @pCtName
							  AND AssetClassId = @pCtAssetType
							  AND IsActive = @Active
							  AND ConcentrationTestId <> @pCtId
					)
					BEGIN
						IF NOT EXISTS
						(
							SELECT 1
							FROM [ps].[ConcentrationTest]
							WHERE CtExpression = @pCtExpression
								  AND CtExpression_Superset = @pCtExpressionSuperSet
								  AND LimitOperator = @pCtLimitOperator 
								  AND LimitPercentage = @pCtLimitPercentage
								  AND IsActive = @Active
								  AND ConcentrationTestId <> @pCtId
						)
						BEGIN
							UPDATE [ps].[ConcentrationTest]
							SET CriteriaName = @pCtName,
								[Description] = @pCtDescription,
								ConcentrationTestTypeId = @pCtType,
								StatusId = @pCtStatus,
								AssetClassId = @pCtAssetType,
								AnalysisCriteriaFieldId = @pFieldId,
								CriteriaFieldOperator = @pCtCriteriaFieldOperator,
								ExpectedValue = @pCtExpectedValue,
								LimitOperator = @pCtLimitOperator,
								LimitPercentage = @pCtLimitPercentage,
								CtExpression = @pCtExpression,
								CtExpression_Superset = @pCtExpressionSuperSet,
								ConcentrationTestTagId = @pCtTag,
								ModifiedBy = @pUserName,
								ModifiedDate = @CurrentDateTime,
								IsSubsetRequired = @pIsSubSetReq
							WHERE ConcentrationTestId = @pCtId;

							SET @pReturnValue = @pCtId;
							EXEC [ps].[spManageAuthWorkflow] @pWorkflowType=@workflowType, @pPsId=@pCtId,@pStatus=@DraftStatusId,@pStepName=@stepName,@pComment=@UpdateCTComment,@pUserName=@pUserName


							/* Deactivating Old Conditons */

							UPDATE [ps].[ConcentrationTestCondition] 
							SET IsActive = 0
							WHERE [ConcentrationTestId] = @pCtId
							
							/* Inserting Superset Conditions */ 
						
							INSERT INTO [ps].[ConcentrationTestCondition]
								([ConcentrationTestId]
								,[EligibilityCriteriaFieldId]
								,[ConcentrationTestSetId]
								,[Condition]
								,[CriteriaFieldOperator]
								,[ExpectedValue]
								,[IsActive]
								,[CreatedBy]
								,[CreatedDate]
								,[ModifiedBy]
								,[ModifiedDate])
							SELECT 
								@pCtId
								,[FieldId]
								,1
								,[Condition]
								,[Operator].[Operator]
								,[ConditionalValue]
								,@Active
								,@pUserName
								,@CurrentDateTime
								,@pUserName
								,@CurrentDateTime
							FROM @pCTConditionsSuperset CtCond
							LEFT JOIN ps.Operator Operator ON Operator.OperatorId = CtCond.ConditionalOperator
							ORDER BY CtCond.Id

							/* Inserting Subset Conditions */

							INSERT INTO [ps].[ConcentrationTestCondition]
								([ConcentrationTestId]
								,[EligibilityCriteriaFieldId]
								,[ConcentrationTestSetId]
								,[Condition]
								,[CriteriaFieldOperator]
								,[ExpectedValue]
								,[IsActive]
								,[CreatedBy]
								,[CreatedDate]
								,[ModifiedBy]
								,[ModifiedDate])
							SELECT 
								@pReturnValue
								,[FieldId]
								,2
								,[Condition]
								,[Operator].[Operator]
								,[ConditionalValue]
								,@Active
								,@pUserName
								,@CurrentDateTime
								,@pUserName
								,@CurrentDateTime
							FROM @pCTConditionsSubset CtCond
							LEFT JOIN ps.Operator Operator ON Operator.OperatorId = CtCond.ConditionalOperator
							ORDER BY CtCond.Id
						END
						ELSE
						BEGIN
							SET @pReturnValue = -3
							SET @pReturnMessage =
							(
								SELECT CriteriaName
								FROM [ps].[ConcentrationTest]
								WHERE CTExpression = @pCtExpression AND LimitOperator = @pCtLimitOperator AND LimitPercentage = @pCtLimitPercentage AND IsActive = @Active AND ConcentrationTestId <> @pCtId
							)
						END
					END
					ELSE
					BEGIN
						SET @pReturnValue = -2
					END

		END
	END TRY
	BEGIN CATCH                                    
		DECLARE                                     
		@errorMessage     NVARCHAR(MAX),                                    
		@errorSeverity    INT,                                    
		@errorNumber      INT,                                    
		@errorLine        INT,                                    
		@errorState       INT;                                    
	
		SELECT                                     
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                                    
                                    
		EXEC app.SaveErrorLog 2, 1, 'spSaveConcentration',@errorNumber, @errorSeverity, @errorLine, @errorMessage , @pUserName                                 
		                           
		RAISERROR (@errorMessage,                                    
		 @errorSeverity,                                    
		 @errorState) 
	END CATCH
END