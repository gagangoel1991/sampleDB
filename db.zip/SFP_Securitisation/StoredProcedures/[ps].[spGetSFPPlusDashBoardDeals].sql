USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetSFPPlusDashBoardDeals]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetSFPPlusDashBoardDeals]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 *   Author: Sakthivel Loganathan
 *   Date:  23-Feb-2023
 *   Description: To get Retail/Corporate Deal data for dashboard.
 *   Change History 
 *   ---------------------------------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   exec [ps].[spGetSFPPlusDashBoardDeals] '31 jan 2023', 0, 'System', 2
*/

CREATE PROCEDURE [ps].[spGetSFPPlusDashBoardDeals]
(      	@pAsAtDate DATE,
		@pIsInitial BIT,	
		@pUserName VARCHAR(50),
		@pAssetClassID INT = 1
)      
AS      
BEGIN      
	BEGIN TRY      

	DECLARE @AssetClass_Retail INT = (SELECT AssetClassID FROM PS.AssetClass WHERE Code = 'RT')
	IF(@pAssetClassID = @AssetClass_Retail)
	BEGIN
		--EXEC [SFP_Model].[rpt].[spGetDashBoardDealFlagDeFlagData] @pAsAtDate, @pIsInitial
		EXEC sfp.syn_SfpModel_sp_rpt_GetDashBoardDealFlagDeFlagData @pAsAtDate, @pIsInitial;  
	END
	ELSE
	BEGIN
		EXEC [corp].[spGetDashBoardDealFlagDeFlagDataCorporate] @pAsAtDate, @pIsInitial;
	END
		
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                    
                    
		              
		RAISERROR (@errorMessage,                    
					@errorSeverity,                    
					@errorState )                    
	END CATCH      
END
GO