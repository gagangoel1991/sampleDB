USE SFP_Securitisation
GO
IF OBJECT_ID('[cw].[spGetISINs]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetISINs]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spGetISINs]   
/*  
 * Author: Gunjan Chandola  
 * Date: 23.03.2021  
 * Description:  This will return Active ISINs for a deal 
 * [cw].[spGetISINs] 15,'CHAGJGA'
 * Change History  
 * --------------  
 * Author  Date  Description  
 * -------------------------------------------------------  
*/  
@pDealId  INT, 
@pIPDRunId INT,
@pUserName  VARCHAR(80)  
AS  
BEGIN  
  
 SET NOCOUNT ON  
 
 BEGIN TRY 
   DECLARE @seprator varchar(20) = ' | '; 
   DECLARE @dealType VARCHAR(100);
   SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

    IF (@dealType='Covered Bond')
	BEGIN
		SELECT dn.ISIN + @seprator + dn.[Name] AS [ISIN] 
		FROM [cfgcb].[DealNote] dn 
		JOIN cb.vwDealNoteWf dnwf ON dn.DealNoteId = dnwf.DealNoteId AND dnwf.DealIpdRunId = @pIPDRunId
		WHERE dn.DealId= @pDealId AND dn.IsActive=1 AND dn.IsNote=1
	END
	ELSE IF(@dealType='RMBS')
	BEGIN
		SELECT ISIN + @seprator + [Name] AS [ISIN] FROM [cfgCW].[DealNote] dn WHERE dn.DealId= @pDealId AND dn.IsActive=1 AND IsNote=1
	END  
 END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'spGetISINs', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END  
GO


