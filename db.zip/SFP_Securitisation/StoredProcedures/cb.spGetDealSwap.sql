USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetDealSwap]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetDealSwap]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 17-05-2021 
--Description: GET Deal Swap Details 
--[cb].[spGetDealSwap] 6,108,''
--==================================   
CREATE PROCEDURE [cb].[spGetDealSwap] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
	Select * FROM
	(
		SELECT 
			ds.DealSwapId AS SwapId
			,cfgds.SwapName AS SwapName
			,CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
			,CONVERT(VARCHAR(10), ds.PayCouponPeriodStart, 103) PayCouponPeriodStart
			,CONVERT(VARCHAR(10), ds.PayCouponPeriodEnd, 103) PayCouponPeriodEnd
			,DATEDIFF(DAY, ds.PayCouponPeriodStart ,ds.PayCouponPeriodEnd ) PayAccrualDays
			,ds.PayNotional AS PayNotional
			,ds.PayBaseRate
			,ds.PayRate
			,ds.PayMarginDifferential
			,ds.PayAmount
			,CONVERT(VARCHAR(10), ds.ReceiveCouponPeriodStart, 103) ReceiveCouponPeriodStart
			,CONVERT(VARCHAR(10), ds.ReceiveCouponPeriodEnd, 103) ReceiveCouponPeriodEnd
			,DATEDIFF(DAY,  ds.ReceiveCouponPeriodStart ,ds.ReceiveCouponPeriodEnd ) ReceiveAccrualDays
			,ds.ReceiveNotional
			,ds.ReceiveBaseRate
			,ds.ReceiveRate
			,ds.ReceiveAmount
			--,IIF(ds.ReceiveAmount<ds.PayAmount,ds.PayAmount-ds.ReceiveAmount,0) AS PayNetAmount
			--,IIF(ds.ReceiveAmount>ds.PayAmount,ds.ReceiveAmount-ds.PayAmount,0) AS ReceiveNetAmount
			, (ds.ReceiveRate - ds.ReceiveBaseRate) AS ReceiveMarginDifferential
			,0 as PayTotalAmount
			,0 as ReceiveTotalAmount,
			dir.IpdDate AS IPD
		FROM [cb].[DealSwap_Wf] ds
		JOIN [cfgcb].[DealSwap] cfgds ON cfgds.DealSwapId = ds.DealSwapId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = ds.DealipdRunid
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
	--	ORDER BY cfgds.SwapName,dir.IpdDate DESC
		UNION
		SELECT
		  '' AS SwapId,
		  'Amount' as SwapName,
		CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
		    ,NULL AS PayCouponPeriodStart
			,NULL AS PayCouponPeriodEnd
			,NULL AS PayAccrualDays
			,NULL AS PayNotional
			,NULL AS PayBaseRate
			,NULL AS PayRate
			,NULL AS PayMarginDifferential
			,NULL AS PayAmount
			,NULL AS ReceiveCouponPeriodStart
			,NULL AS ReceiveCouponPeriodEnd
			,NULL AS ReceiveAccrualDays
			,NULL AS ReceiveNotional
			,NULL AS ReceiveBaseRate
			,NULL AS ReceiveRate
			,NULL AS ReceiveAmount
			--,NULL AS PayNetAmount
			--,NULL AS ReceiveNetAmount
			,NULL AS ReceiveMarginDifferential
			,SUM(ds.PayAmount) as PayTotalAmount
			,SUM(ds.ReceiveAmount - ds.PayAmount) as ReceiveTotalAmount,
			dir.IpdDate AS IPD
		FROM [cb].[DealSwap_Wf] ds
		JOIN [cfgcb].[DealSwap] cfgds ON cfgds.DealSwapId = ds.DealSwapId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = ds.DealipdRunid
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
		GROUP BY dir.IpdDate		
		) t
		ORDER BY t.SwapName,t.IPD DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetDealSwap'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


