USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetSwapCollateral]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetSwapCollateral]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 17-05-2021 
--Description: GET Swap Reserve Fund 
--[cb].[spGetSwapCollateral] 6,1034,''
--==================================   
CREATE PROCEDURE [cb].[spGetSwapCollateral] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
		SELECT CONVERT(VARCHAR(10), ipd.IpdDate, 103) AS IpdDate
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN wliParent.ParentLineItemId
				ELSE ISNULL(litem.ParentLineItemId, 0)
				END ParentId
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN 1
				ELSE 0
				END IsSubLineItems
        	,litem.DisplayTextUI
			,litem.FieldName
			,scf.SwapCollateralFund_bF
			,scf.SwapCollateralAmountReceived
			,scf.SwapCollateralExcludedAmount
			,scf.ReleaseToARR
			,scf.SwapCollateral_cf
		FROM cfgcb.CoveredBondFund cbf
		JOIN [cb].[SwapCollateralFund] scf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
		JOIN cw.dealipdrun dir ON dir.RunId = scf.DealipdRunid
		JOIN cw.DealIpd ipd ON ipd.DealIpdId = dir.DealIpdId
		JOIN [cfgcb].[CoveredBondFundLineItemUI] litem ON cbf.CoveredBondFundId = litem.CoveredBondFundId
		LEFT JOIN (
			SELECT DISTINCT ParentLineItemId
			FROM [cfgcb].[CoveredBondFundLineItemUI]
			) AS wliParent ON wliParent.ParentLineItemId = litem.CoveredBondFundLineItemId
		WHERE dir.RunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
		ORDER BY ipd.IpdDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetSwapCollateral'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


