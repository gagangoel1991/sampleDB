Use SFP_Securitisation

IF OBJECT_ID('corp.spGetRegRegReportGenerationData') IS NOT NULL
DROP PROC corp.spGetRegRegReportGenerationData

GO

/*
Author: Saurabh
Date:	11.08.2022
Description:  This will get Ref Reg report generation data
				
Change History
--------------
Author		Date		Description
-------------------------------------------------------
*/


CREATE PROCEDURE corp.spGetRegRegReportGenerationData 
	  @pStratName varchar(200)
	, @pDealIrConfigId INT
	, @pAsAtDate VARCHAR(100) = NULL
	, @pDealID INT
	, @pUserName VARCHAR(100)
	, @pPoolID INT = 0
	, @pOutputType VARCHAR(20) = ''
AS
BEGIN
	DECLARE @ReportTypeId INT = (
			SELECT ReportTypeId
			FROM [cfgCW].[IR_ReportType]
			WHERE ReportTypeName = 'Reference Registry'
			);
	
	DECLARE @MappedProcedure VARCHAR(200) = (
			SELECT MappedProcedure
			FROM cfgCW.IR_MiscStrat M
			Join cfgCW.IR_Strat S
			ON S.StratId = M.StratId
			WHERE S.Name = @pStratName
			);

	DECLARE @Query VARCHAR(8000) = 'EXEC ' 
	+ @MappedProcedure 
	+ ' @pDealIrConfigId = '+ CONVERT(varchar(200),@pDealIrConfigId) 
	+ ' ,@pAsAtDate = ''' + @pAsAtDate  + ''''
	+ ' ,@pDealID = ' + CONVERT(varchar(200), @pDealID)
	+ ' ,@pUserName = ''' + @pUserName  + ''''
	+ ' ,@pPoolID = ' + CONVERT(varchar(10), @pPoolID) 
	+ ' ,@pOutputType = ''' + @pOutputType   + '''' 
	print @Query

	EXEC (@Query)
END