USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetDetailDrillThroughReport]') AND type IN (N'P', N'PC'))
DROP PROCEDURE [ps].[spGetDetailDrillThroughReport]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- 11225, 11161
-- [ps].[spGetDetailDrillThroughReport] 79, 'kothpaj'
CREATE PROCEDURE [ps].[spGetDetailDrillThroughReport]	
	@pPoolId int,
	@pUserName VARCHAR(50)
AS
BEGIN	
	DECLARE @ECID VARCHAR(MAX) = '';
	DECLARE @NewEcId VARCHAR(MAX)
	DECLARE @PivotResult NVARCHAR(MAX) = '';
	DECLARE @AddECColumn VARCHAR(4000);
	DECLARE @ExclusionId INT, @Active BIT = 1, @GlobalExclusion BIT = 1	
	BEGIN TRY	
			IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL                                           
				DROP TABLE #Result 				
	
			SELECT @ECID =STUFF((SELECT DISTINCT ',' + QUOTENAME(ec.Name) 
                  FROM ps.PoolEligibilityBuildDetail pebd
                INNER JOIN ps.EligibilityCriteria ec
					ON pebd.EligibilityCriteriaId  = ec.EligibilityCriteriaId
				WHERE PoolId = @pPoolId 
				   AND pebd.EligibilityCriteriaId <> -1 
				GROUP BY ec.Name          
						FOR XML PATH(''), TYPE
						).value('.', 'NVARCHAR(MAX)') 
					,1,1,'')

			IF @ECID <> NULL OR @ECID <> ''
			BEGIN
				IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL                  
					DROP TABLE #Result;  

				CREATE TABLE #Result                              
				(  
					LoanId BIGINT				        
				)

				
				SET @NewEcId = REPLACE(@ECID, '],', ']~')			
				
				SET @AddECColumn  = 'Alter Table #Result ADD '
				SELECT @AddECColumn =@AddECColumn + STUFF((SELECT DISTINCT ', '+ ec.Value + ' int default 0 '
					FROM [app].[udfSplitString](@NewEcId,'~') ec
					GROUP BY ec.Value          
							FOR XML PATH(''), TYPE
							).value('.', 'NVARCHAR(MAX)') 
						,1,1,'')	
				SET @AddECColumn = @AddECColumn + ' ,[Exclusion] int default 0, [RandomSelection] int default 0';
				EXEC(@AddECColumn)	

				--Getting Ec results for each loan 
				SET @PivotResult = '
						INSERT INTO #Result(LoanId,'+ CONVERT(VARCHAR(max), @ECID) + ')
						SELECT  *
						FROM 
						(
							SELECT LoanId, ec.Name, Case When Status = 0 then 1 else 0 end as status							
							FROM [ps].[PoolEligibilityBuildDetail] pebd 
							INNER JOIN ps.EligibilityCriteria ec 
								ON pebd.EligibilityCriteriaId = ec.EligibilityCriteriaId
							WHERE PoolId  = '+ CONVERT(VARCHAR, @pPoolId) + ' 
						) src
						pivot
						(
							Max(STATUS) FOR [Name] in ('+ @ECID + ') 					
						) as piv'
				
				EXEC(@PivotResult);
				
				-- Updating existing records for exclusion or random selection
				UPDATE 
					#Result 
				SET 
					#Result.Exclusion = CASE WHEN pebd.Status = -1 THEN 1 ELSE 0 END,
					#Result.RandomSelection = CASE WHEN pebd.Status = -2 THEN 1 ELSE 0 END		
				FROM 
					#Result 
					INNER  JOIN [ps].[PoolEligibilityBuildDetail] pebd 
					ON pebd.LoanId = #Result.LoanId
				WHERE pebd.PoolId = @pPoolID AND pebd.EligibilityCriteriaId = -1

				-- Inserting new records for exclusion or random selection if they are not part of existing record set
				INSERT INTO #Result(LoanId, Exclusion, RandomSelection)
				SELECT pebd.LoanId, 
				CASE WHEN pebd.Status = -1 THEN 1 ELSE 0 END,
				CASE WHEN pebd.Status = -2 THEN 1 ELSE 0 END
				FROM [ps].[PoolEligibilityBuildDetail] pebd
				LEFT JOIN #Result r 
				ON pebd.LoanId = r.LoanId			
				WHERE pebd.PoolId = @pPoolId AND r.LoanId IS NULL
				
				SELECT * FROM #Result ORDER BY LoanId
		END
   END TRY
	BEGIN CATCH		
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetDetailDrillThroughReport', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO