USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetProductSwitchReportInv') IS NOT NULL
	DROP PROC CW.spGetProductSwitchReportInv
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Product Switch Data for Investor report.
 * Usage : CW.spGetProductSwitchReportInv @pAsAtDate  = '30-Nov-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetProductSwitchReportInv @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY  
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN
				
				
BEGIN TRY
	SET NOCOUNT ON;
  
	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	, @partitionID_Previous_AsAtDate INT
	, @previous_asatdate DATE = ( SELECT CW.SynFnPreviousReportDate(@pAsAtDate, 3)  )
	
   
	CREATE TABLE #CurrentMortgage
	(  
		SortNo Int, ProductSwitchType VARCHAR(100), MortgageLoans INT DEFAULT 0, MortgageLoansPercent float, TotalOutCapitalBalance Float DEFAULT 0
		, TotalOutCapitalBalancePercent Float DEFAULT 0, TrueBalance Float, TrueBalancePercent Float    
	);
	INSERT INTO #CurrentMortgage 
	EXEC CW.spGetPeriodProductSwitchReportInv @pAsAtDate, @pDealName, @pUserName
	

	CREATE TABLE #PreviousMortgage
	(  
		SortNo Int, ProductSwitchType VARCHAR(100), MortgageLoans INT DEFAULT 0, MortgageLoansPercent float, TotalOutCapitalBalance Float DEFAULT 0
		, TotalOutCapitalBalancePercent Float DEFAULT 0, TrueBalance Float, TrueBalancePercent Float
	);
	INSERT INTO #PreviousMortgage
	EXEC CW.spGetPeriodProductSwitchReportInv @previous_asatdate, @pDealName, @pUserName
	
   
	SELECT CM.ProductSwitchType AS HeaderText, 'Current Period' AS SubHeaderText, CM.MortgageLoans, MortgageLoansPercent, IsNUll(CM.TotalOutCapitalBalance,0) AS TotalOutCapitalBalance , IsNUll(CM.TotalOutCapitalBalancePercent ,0) AS TotalOutCapitalBalancePercent , TrueBalance, TrueBalancePercent FROM #CurrentMortgage CM 
	UNION ALL
    SELECT PM.ProductSwitchType AS HeaderText, 'Previous Period' AS SubHeaderText, isNull(PM.MortgageLoans,0) AS MortgageLoans, MortgageLoansPercent, isNull(PM.TotalOutCapitalBalance,0) TotalOutCapitalBalance , isNull(PM.TotalOutCapitalBalancePercent,0) AS TotalOutCapitalBalancePercent, TrueBalance, TrueBalancePercent FROM #PreviousMortgage PM
    
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetProductSwitchReportInv', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END

GO
