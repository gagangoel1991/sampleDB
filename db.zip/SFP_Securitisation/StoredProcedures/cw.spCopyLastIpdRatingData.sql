USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spCopyLastIpdRatingData') IS NOT NULL
	DROP PROC cw.spCopyLastIpdRatingData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--=========================================================================  
--Author: Saurabh Bhatia 
--Date: 01.11.2021
--Description: To Copy last ipd Rating data to Current Ipd as required by business 
--cw.spCopyLastIpdRatingData  14,12,'EUROPA\BHASAAA'
--=========================================================================  
CREATE PROCEDURE cw.spCopyLastIpdRatingData @pDealId INT
	,@pCurrentDealIpdId INT
	,@pUserName VARCHAR(50)
AS
BEGIN
	BEGIN TRY
		BEGIN TRAN

		--DECLARE @pDealId INT = 14
		--	,@pCurrentDealIpdId INT = 12;
		DECLARE @PrevIpdDate VARCHAR(20)
			,@PrevCollectionBusinessStart DATETIME
			,@PrevCollectionBusinessEnd DATETIME
			,@CurrentCollectionBusinessStart DATETIME
			,@CurrentCollectionBusinessEnd DATETIME
			,@DBRSRatingAgency VARCHAR(20) = 'DBRS'

		--Current IPD CollectionBusinessStart Date and CollectionBusinessEnd Date 
		SELECT @CurrentCollectionBusinessStart = CAST(CollectionBusinessStart AS DATETIME)
			,@CurrentCollectionBusinessEnd = CAST(CollectionBusinessEnd AS DATETIME)
			,@PrevIpdDate = PreviousIPD
		FROM cw.vwDealIpdDates
		WHERE DealIpdId = @pCurrentDealIpdId
			AND dealid = @pDealId

		--Previous IPD CollectionBusinessStart Date and CollectionBusinessEnd Date 
		SELECT @PrevCollectionBusinessStart = CAST(CollectionBusinessStart AS DATETIME)
			,@PrevCollectionBusinessEnd = CAST(CollectionBusinessEnd AS DATETIME)
		FROM cw.vwDealIpdDates
		WHERE IPD = @PrevIpdDate
			AND dealid = @pDealId

		--Bond Rating  
		INSERT INTO cw.UserBondRating ( 
			ISIN
			,Series
			,CRAId
			,RatingTypeId
			,Rating
			,RatingDate
			,Comment
			,IsPrevIpdRating
			,CreatedBy
			,CreatedDate
			,ModifiedBy
			,ModifiedDate
			)
		SELECT b.ISIN
			,b.Series
			,b.CRAId
			,b.RatingTypeId
			,b.Rating
			,@CurrentCollectionBusinessEnd AS RatingDate
			,b.Comment
			,1 AS IsPrevIpdRating
			,b.CreatedBy
			,b.CreatedDate
			,b.ModifiedBy
			,b.ModifiedDate
		FROM cw.vwBondRating b
		JOIN cfgCW.CreditRatingAgency a ON a.CRAId = b.CRAId
		WHERE [Name] = @DBRSRatingAgency
			AND RatingDate = @PrevCollectionBusinessEnd
			AND UserBondRatingId IS NOT NULL

		--CP Rating  
		INSERT INTO cw.UserCounterPartyRating (
			RatingDate
			,CisCode
			,CRAId
			,RatingTypeId
			,Rating
			,Comment
			,IsPrevIpdRating
			,CreatedBy
			,CreatedDate
			,ModifiedBy
			,ModifiedDate
			)
		SELECT @CurrentCollectionBusinessEnd AS RatingDate
			,CisCode
			,c.CRAId
			,RatingTypeId
			,Rating
			,c.Comment
			,1 AS IsPrevIpdRating
			,c.CreatedBy
			,c.CreatedDate
			,c.ModifiedBy
			,c.ModifiedDate
		FROM cw.vwCounterpartyRating c
		JOIN cfgCW.CreditRatingAgency a ON a.CRAId = c.CRAId
		WHERE [Name] = @DBRSRatingAgency
			AND RatingDate = @PrevCollectionBusinessEnd
			AND UserCounterpartyRatingId IS NOT NULL;

		COMMIT TRAN
	END TRY

	BEGIN CATCH
		IF @@TRANCOUNT > 0
			ROLLBACK TRAN

		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2
			,1
			,'cw.spCopyLastIpdRatingData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO