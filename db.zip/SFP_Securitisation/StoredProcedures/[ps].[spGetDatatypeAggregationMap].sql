USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[ps].[spGetDatatypeAggregationMap]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetDatatypeAggregationMap]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--EXEC [ps].[spGetDatatypeAggregationMap]  'EUROPA\LOGASLL'

CREATE PROCEDURE [ps].[spGetDatatypeAggregationMap] 
 @pUserName VARCHAR(50) 
AS  
BEGIN  
 BEGIN TRY  
			SELECT Map.DataTypeId, Map.AggregationId, Agn.AggregationName , Agn.Description  
			FROM PS.[AggregationTypeMap] Map  
			INNER JOIN ps.FieldAggregation Agn ON Map.AggregationId = Agn.AggregationId   
			WHERE Map.IsActive = 1 AND Agn.IsActive = 1  
			ORDER BY Map.DataTypeId, Agn.AggregationName  
 END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  

  SELECT @errorMessage = ERROR_MESSAGE()
 ,@errorSeverity = ERROR_SEVERITY()
 ,@errorNumber = ERROR_NUMBER()
 ,@errorLine = ERROR_LINE()
 ,@errorState = ERROR_STATE()  
  EXEC app.SaveErrorLog 2, 1, 'spGetDatatypeAggregationMap', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH
END
GO