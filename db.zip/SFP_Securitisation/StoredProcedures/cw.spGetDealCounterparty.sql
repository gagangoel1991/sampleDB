USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetDealCounterparty]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealCounterparty]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetDealCounterparty]
/*
 * Author: Kapil Sharma
 * Date:	15.07.2020
 * Description:  This will return the deal counterparty
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealId			INT = NULL,		
@pUserName			VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		
		SELECT 
			dp.DealCounterpartyId,
			deal.DealId,
			dp.CisCode,
			dp.CounterpartyName
		FROM
			[cw].[vw_ActiveDealCounterparty] dp
		JOIN
			[cw].[vw_ActiveDeal] deal ON dp.DealId = deal.DealId
		WHERE
			deal.DealId = @pDealId
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetDealCounterparty', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
