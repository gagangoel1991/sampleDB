USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cw].[spGetInvoiceCategory]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetInvoiceCategory]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [cw].[spGetInvoiceCategory]
/*
 * Author: Kapil Sharma
 * Date:	15.07.2020
 * Description:  This will return the all active deal names
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pInvoiceCategoryTypeId		TINYINT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		
		SELECT 
			InvoiceCategoryTypeId,
			InvoiceCategoryId,
			Name,
			[Description]
		FROM
			[cfgCW].[InvoiceCategory] 
		WHERE
			InvoiceCategoryTypeId = @pInvoiceCategoryTypeId
			AND IsActive = 1
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetInvoiceCategory', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
