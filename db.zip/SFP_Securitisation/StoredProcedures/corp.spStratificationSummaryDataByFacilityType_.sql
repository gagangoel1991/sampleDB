USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratificationSummaryDataByFacilityType]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratificationSummaryDataByFacilityType]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO


-----------------------------------------------------------------------------------------------------------------------------
--Author         : Mukesh Sharma 
--Creation Date  : 06-March-2023
--Description    : This will return calculated data for strats by Facilitytype, for more detail refer  SFTP-14484
--Execution      : EXEC [corp].[spStratificationSummaryDataByFacilityType]  @pAsAtDate= '2023-01-31', @pDealId = 1,@pUserName=NULL

------------------------------------------------------------------------------------------------------------------------------------

CREATE PROCEDURE [corp].[spStratificationSummaryDataByFacilityType] 	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100)
		DECLARE @CountStratsType INT
		DECLARE @Initialize INT=1
		DECLARE @StratType VARCHAR(20)
		DECLARE @Flag INT

		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats
		IF OBJECT_ID('tempdb..#StratsSummary') IS NOT NULL
		DROP TABLE #StratsSummary
		IF OBJECT_ID('tempdb..#FinalStratsSummary') IS NOT NULL
		DROP TABLE #FinalStratsSummary
		IF OBJECT_ID('tempdb..#StratsType') IS NOT NULL
		DROP TABLE #StratsType


		--- configuring stratstype as per need
		CREATE TABLE #StratsType

		( FacilityType VARCHAR(50)
		 ,Flag INT
		 ,SequenceNumber INT
		)

		INSERT INTO #StratsType
		VALUES('Full Pool',1,1),('Loan',0,2),('RCF',0,3)

		--- Creating final strats table

		CREATE TABLE #FinalStratsSummary

		( 
		 [Attributes] VARCHAR(100)
		,[Full Pool] VARCHAR(50)
		,[Loan]  VARCHAR(50)
		,[RCF] VARCHAR(50)
		)

		INSERT INTO #FinalStratsSummary([Attributes])
		VALUES
		('facility_count')
		,('Pool notional pre co-share')
		,('Pool utilisation pre co-share')
		,('Pool notional post co-share')
		,('WA PD%')
		,('WA TTC LGD%')
		,('WA LTV%')
		,('WA ICR')
		,('WA Maturity yrs')
        
		/*List of required Columns*/   
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','CommittedExposure','UtilisationGBP_SecDate','RONA','PDMidPoint','MaturityDate','InterestCoverOverride','TTCLGD','FacilityType','LTVGR3') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
		PRINT 'Strats Calculation Start : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId
			  ,CommittedExposure
			  ,UtilisationGBP_SecDate AS Utilisation
			  ,RONA
			  ,PDMidPoint
			  ,MaturityDate
			  ,InterestCoverOverride
			  ,TTCLGD 
			  ,FacilityType
			  ,LTVGR3
			  ,CASE WHEN LTVGR3 IS NULL THEN 0 ELSE RONA END AS RONA_LTV
		INTO #Strats 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
				/*Deleting Data from Staging table after use*/
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SET @CountStratsType=(SELECT COUNT(1) FROM #StratsType)
		WHILE(@CountStratsType>0)

		BEGIN
		DECLARE  @ReqFields NVARCHAR(MAX)
		IF OBJECT_ID('tempdb..#StratsSummary') IS NOT NULL
		DROP TABLE #StratsSummary
		IF OBJECT_ID('tempdb..#TempStratsSummary') IS NOT NULL
		DROP TABLE #TempStratsSummary

		SET @StratType=(SELECT FacilityType FROM #StratsType WHERE SequenceNumber=@Initialize)
		SET @Flag=(SELECT Flag FROM #StratsType WHERE SequenceNumber=@Initialize)

		SELECT [facility_count] = CONVERT(VARCHAR,COUNT(FacilityId))	 
		,[Pool notional pre co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(CommittedExposure)))
		,[Pool utilisation pre co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(Utilisation)))
		,[Pool notional post co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(RONA)))
		,[WA PD%] =IIF(SUM(RONA) = 0,NULL, CONVERT(VARCHAR, CONVERT(DECIMAL(10,4),SUM(RONA * PDMidPoint)/SUM(RONA))))
		,[WA TTC LGD%] = IIF(SUM(RONA) = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(10,4),SUM(RONA * TTCLGD)/ SUM(RONA))) )
		,[WA LTV%]=IIF(SUM(RONA_LTV) = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(10,4),SUM(RONA_LTV * LTVGR3)/ SUM(RONA_LTV))) )
		,[WA ICR] = IIF(SUM(RONA) = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(RONA * InterestCoverOverride) / SUM(RONA))) )
		,[WA Maturity yrs] = IIF(SUM(RONA) = 0,NULL, CONVERT(VARCHAR,CONVERT(DECIMAL(23,2),SUM(RONA * DATEDIFF(DD, @pAsAtDate, MaturityDate) / 365 ) /SUM(RONA))))
		INTO #StratsSummary
		FROM #Strats  WHERE FacilityType=@StratType OR(@Flag=1)

		SELECT [Attributes],[Value]  
		INTO #TempStratsSummary
		FROM #StratsSummary  
		UNPIVOT   
		(   
		[Value] FOR [Attributes] 
		IN (   
		 [facility_count] 
		,[Pool notional pre co-share]
		,[Pool utilisation pre co-share]
		,[Pool notional post co-share]
		,[WA PD%] 
		,[WA TTC LGD%] 
		,[WA LTV%]
		,[WA ICR]	
		,[WA Maturity yrs]
			)  )
	    AS UnpivotTable  


		-- updating strats dynamically based on strats type

		SET @ReqFields = N'  

		UPDATE FSM

		SET ['+@StratType+']=SM.Value
		FROM #FinalStratsSummary AS FSM
		INNER JOIN #TempStratsSummary AS SM  on
		SM.[Attributes]=FSM.[Attributes]'

		EXEC sp_executesql @Reqfields  

		SET @CountStratsType=@CountStratsType-1
		SET @Initialize=@Initialize+1

		END

		SELECT *
		FROM #FinalStratsSummary

		IF OBJECT_ID('tempdb..#StratsSummary') IS NOT NULL
		DROP TABLE #StratsSummary
		IF OBJECT_ID('tempdb..#TempStratsSummary') IS NOT NULL
		DROP TABLE #TempStratsSummary
		IF OBJECT_ID('tempdb..#FinalStratsSummary') IS NOT NULL
		DROP TABLE #FinalStratsSummary




		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    
	
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationSummaryDataByFacilityType', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO


