USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetCBNoteStaticAttributes]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetCBNoteStaticAttributes]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 24-02-2022 
--Description: GET CB Note static prop
--[cb].[spGetCBNoteStaticAttributes] 6,104,''
--==================================   
CREATE PROCEDURE [cb].[spGetCBNoteStaticAttributes] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY

	Declare @NewRedemptionDate DATE,@NewRedemptionIpdDate DATE

	IF ( Object_id('tempdb..#NewRedemptionDate') IS NOT NULL ) 
		DROP TABLE #NewRedemptionDate 

		CREATE TABLE #NewRedemptionDate(
			DealNoteId INT,NewRedemptionDate Date,NewRedemptionIPdDate Date)

		INSERT INTO #NewRedemptionDate
		SELECT DealNoteId,NewRedemptionDate,null FROM cfgcb.DealNote where series in (8,9,11)

	--SELECT TOP 1 @NewRedemptionDate = NewRedemptionDate from cfgcb.DealNote WHERE NewRedemptionDate IS NOT NULL

	SELECT TOP 1 @NewRedemptionIpdDate =dir.IpdDate from cw.vwDealIpdRun dir where dir.IpdDate>= @NewRedemptionDate
	   AND DealId=@pDealId

		--select @NewRedemptionDate,@NewRedemptionIpdDate
		Select T.DealNoteId
			,T.ISIN
			,T.IPDDate
			,T.DealNote
			,T.IssuanceAmount
			,T.IssuanceAmount_GBP
			,T.ExtendedCoveredBond
			,T.IsSwapLinked
			,T. HardBulletSeries
			,T.Currency
			,T.MaturityDate
			,T.Margin
			,T.RateType	 from 

			(SELECT dn.DealNoteId
			,dn.ISIN
			,CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IPDDate
			,dn.Series AS DealNote
			,dn.IssuanceAmount
			,dn.GBPEquivalent AS IssuanceAmount_GBP
			,CASE dn.ExtendedCoveredBond
			WHEN 'TRUE' THEN 'Yes' ELSE 'No' END AS ExtendedCoveredBond
			,CASE dn.IsSwapLinked
			WHEN 'TRUE' THEN 'Yes' ELSE 'No' END AS IsSwapLinked
			,dlv1.[Value] AS HardBulletSeries
			,c.Code AS Currency
			,dn.MaturityDate
			,dn.Margin
			,CASE dlv.[Value]
				WHEN 'FIXED'
					THEN 'N/A'
				ELSE CAST(dlv.[Value] AS VARCHAR(50))
				END AS RateType				
				,dn.NewRedemptionDate as NewRedemptionDate,
		--		(Select MIN(Ipddate) from cw.vwDealIpdRun where IpdDate>= dn.NewRedemptionDate ) AS NewRedemptionIPDDate,
				CASE 
				WHEN dir.IpdDate > (Select MIN(Ipddate) from cw.vwDealIpdRun dir where dir.Dealid = @pDealId  
				AND dir.IpdDate>= ISNULL(dn.NewRedemptionDate, dn.MaturityDate))
				THEN 0
				ELSE 1 END AS IsRedemptionSeries
				--,dn.NewRedemptionDate,@NewRedemptionIpdDate
		FROM cfgcb.DealNote dn
		JOIN cb.DealNote_Wf wf ON dn.DealNoteId = wf.DealNoteId
		LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = wf.DealipdRunid --AND dn.dealId=dir.dealId
		JOIN #NewRedemptionDate nr on nr.dealnoteid=dn.dealnoteid
		JOIN [CW].[vw_DealLookup] dlv ON dn.RateTypeId = dlv.LookupValueId
		JOIN [CW].[vw_DealLookup] dlv1 ON dn.BulletId = dlv1.LookupValueId
		JOIN cfgCW.Currency c ON dn.CurrencyId = c.CurrencyId
		WHERE dir.DealIpdRunId = @pIPDRunId
			AND dir.DealId = @pDealId
			AND dn.IsActive = 1
			)T
			where T.IsRedemptionSeries=1

	
			--AND  1= CASE 
			--     WHEN  (dn.NewRedemptionDate is  NULL AND  dn.MaturityDate < @NewRedemptionIpdDate )
			--	   OR  (dn.NewRedemptionDate is NOT NULL  AND 
			--	   --dir.IpdDate > @NewRedemptionIpdDate) 
			--	    IPDDate = (Select MIN(Ipddate) from cw.vwDealIpdRun where IpdDate>= dn.NewRedemptionDate  ))
			--	   THEN 0
			--	  ELSE  1
			--	  END
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetCBNoteStaticAttributes'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


