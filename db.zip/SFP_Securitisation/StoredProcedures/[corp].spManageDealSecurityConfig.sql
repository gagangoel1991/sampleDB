USE [SFP_Securitisation]
GO

IF OBJECT_ID('[corp].spManageDealSecurityConfig') IS NOT NULL
	DROP PROCEDURE [corp].spManageDealSecurityConfig
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
/*  =============================================================================
	Author: Sakthivel Loganathan 
	Date: 10 Mar 2023  
	Description:  To insert Deal's security configuration data 

	DECLARE @pDealSecurityConfigItems [cw].[DealSecurityConfigItems]
	INSERT @pDealSecurityConfigItems ([PageLookUpValueMapId] ,[DealId] ,[Val] ,[Name] ,[IsSelected] ,[TypeId])
	SELECT 0,22, '1ST', '', 1, 1
	UNION SELECT 0,22, 'CBILS', '', 1, 1
	UNION SELECT 0,22, 'CBILS', '', 1, 2
	UNION SELECT 0,22, 'NEWSTAT', '', 1, 3
	
	EXEC [corp].spManageDealSecurityConfig  22, @pDealSecurityConfigItems, 'LOGA'
	SELECT * FROM [cfg].[PageLookUpValueMap]
    ============================================================================== */


CREATE PROCEDURE [corp].spManageDealSecurityConfig (  
  @pDealId INT = NULL,
  @pDealSecurityConfigItems [corp].[DealSecurityConfigItems] READONLY,
  @pUserName VARCHAR(100) = 'System'
 )  
AS  
BEGIN  
 BEGIN TRY  

	DECLARE @ListingPageId INT = (SELECT ListingPageId FROM APP.ListingPage WHERE ListingPageName = 'Deal')
    DECLARE @PageLookUpMapId INT

	-- FOR SecurityType
	SELECT @PageLookUpMapId = PageLookUpMapID FROM [cfg].[PageLookUpMap] WHERE LookUpName = 'SecurityType' AND AssetClassId = 2 AND ListingPageId = @ListingPageId 
	DELETE FROM [cfg].[PageLookUpValueMap]
	WHERE ID = @pDealId 
		  AND PageLookUpMapID = @PageLookUpMapId
		  AND NOT EXISTS (select 1 from @pDealSecurityConfigItems lst WHERE lst.[TypeId] = 1 AND lst.IsSelected = 1 AND lst.val = LookUpValue)

	INSERT INTO [cfg].[PageLookUpValueMap](Id,PageLookUpMapID,LookUpValue,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
    SELECT @pDealId, @PageLookUpMapId, [VAL],'System', GetDate(),'System', GetDate() 
	FROM @pDealSecurityConfigItems lst
	WHERE [TypeId] = 1 AND IsSelected = 1
		  AND NOT EXISTS (select 1 from [cfg].[PageLookUpValueMap] map WHERE map.ID = @pDealId AND map.PageLookUpMapID = @PageLookUpMapId AND lst.val = map.LookUpValue)

	-- FOR SecuritySubTypeCode
	SELECT @PageLookUpMapId = PageLookUpMapID FROM [cfg].[PageLookUpMap] WHERE LookUpName = 'SecuritySubTypeCode' AND AssetClassId = 2 AND ListingPageId = @ListingPageId 
	DELETE FROM [cfg].[PageLookUpValueMap]
	WHERE ID = @pDealId 
		  AND PageLookUpMapID = @PageLookUpMapId
		  AND NOT EXISTS (select 1 from @pDealSecurityConfigItems lst WHERE lst.[TypeId] = 2 AND lst.IsSelected = 1 AND lst.val = LookUpValue)

	INSERT INTO [cfg].[PageLookUpValueMap](Id,PageLookUpMapID,LookUpValue,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
    SELECT @pDealId, @PageLookUpMapId, [VAL],'System', GetDate(),'System', GetDate() 
	FROM @pDealSecurityConfigItems lst
	WHERE [TypeId] = 2 AND IsSelected = 1
		  AND NOT EXISTS (select 1 from [cfg].[PageLookUpValueMap] map WHERE map.ID = @pDealId AND map.PageLookUpMapID = @PageLookUpMapId AND lst.val = map.LookUpValue)

	-- FOR SecurityStatusCode
	SELECT @PageLookUpMapId = PageLookUpMapID FROM [cfg].[PageLookUpMap] WHERE LookUpName = 'SecurityStatusCode' AND AssetClassId = 2 AND ListingPageId = @ListingPageId 
	DELETE FROM [cfg].[PageLookUpValueMap]
	WHERE ID = @pDealId 
		  AND PageLookUpMapID = @PageLookUpMapId
		  AND NOT EXISTS (select 1 from @pDealSecurityConfigItems lst WHERE lst.[TypeId] = 3 AND lst.IsSelected = 1 AND lst.val = LookUpValue)

	INSERT INTO [cfg].[PageLookUpValueMap](Id,PageLookUpMapID,LookUpValue,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
    SELECT @pDealId, @PageLookUpMapId, [VAL],'System', GetDate(),'System', GetDate() 
	FROM @pDealSecurityConfigItems lst
	WHERE [TypeId] = 3 AND IsSelected = 1
		  AND NOT EXISTS (select 1 from [cfg].[PageLookUpValueMap] map WHERE map.ID = @pDealId AND map.PageLookUpMapID = @PageLookUpMapId AND lst.val = map.LookUpValue)

 END TRY
 BEGIN CATCH  
  DECLARE @errorMessage NVARCHAR(MAX)  
   ,@errorSeverity INT  
   ,@errorNumber INT  
   ,@errorLine INT  
   ,@errorState INT;  
  
  SELECT @errorMessage = ERROR_MESSAGE()  
   ,@errorSeverity = ERROR_SEVERITY()  
   ,@errorNumber = ERROR_NUMBER()  
   ,@errorLine = ERROR_LINE()  
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2  
   ,1  
   ,'[cw].spManageDealSecurityConfig'  
   ,@errorNumber  
   ,@errorSeverity  
   ,@errorLine  
   ,@errorMessage  
   ,@pUserName  
  
  RAISERROR (  
    @errorMessage  
    ,@errorSeverity  
    ,@errorState  
    )  

 END CATCH  
END

GO
