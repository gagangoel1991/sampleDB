USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spCopyInitIpdDataOnWithdraw]') IS NOT NULL
	DROP PROCEDURE [cb].[spCopyInitIpdDataOnWithdraw]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================
--Author: Aditya Shrivastava
--Date:	23.03.2022
--Description:  To insert Initiate Ipd data for withdraw ipd

/*
DECLARE @pResultCode INT   
DECLARE @pNewDealIpdRunId INT        
  exec [cb].[spCopyInitIpdDataOnWithdraw]	3,'fm/pandsbl' ,@pNewDealIpdRunId OUTPUT ,@pResultCode OUTPUT
  Select @pNewDealIpdRunId,@pResultCode

*/
--================================== 

CREATE PROC [cb].[spCopyInitIpdDataOnWithdraw]
(
	@pOldDealIpdRunId SMALLINT,
	@pUserName	VARCHAR(80),
	@pNewDealIpdRunId INT OUTPUT,
	@pResultCode INT OUTPUT 

	/*
		@pResultCode
		1  : Success
		Else : Failed

		@pDealIpdRunId - Newly added run Id 

	*/
)
AS
BEGIN
	
	DECLARE
		@Message		VARCHAR(4000),
		@stepCode		VARCHAR(50)= 'WITHDRAW_INIT',
		@logStatus		VARCHAR(20) = 'STARTED',
		@logDescription	VARCHAR(1000),
		@inputParams	VARCHAR(100) = 'OldDealIpdRunId=' + CONVERT(VARCHAR(10) ,@pOldDealIpdRunId) ,
		@logExecutionId INT,
		@date			DATETIME = GETDATE(),
		@dealIpdWithdrawStatusId	SMALLINT;
	
	SET NOCOUNT ON

	BEGIN TRY
	    
		EXEC cw.spLogExecution @pOldDealIpdRunId, @stepCode, @logStatus,@inputParams, NULL,0,NULL, @pUserName,@logExecutionId OUT

		SELECT @dealIpdWithdrawStatusId = [cw].[fnGetWorkflowStepId]('Withdraw', 'Deal_Ipd')

		UPDATE cw.DealIpdRun
			SET IsCurrentVersion=0, ModifiedBy=@pUserName, ModifiedDate=@date
			WHERE RunID =@pOldDealIpdRunId
						

		INSERT INTO  cw.DealIpdRun(DealIpdId, Version, IsCurrentVersion, WorkflowStepId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
		SELECT DealIpdId,Version + 1 ,1,@dealIpdWithdrawStatusId,@pUserName, @date ,@pUserName, @date FROM [CW].DealIpdRun
			WHERE RunId=@pOldDealIpdRunId
				
		SET @pNewDealIpdRunId = (SELECT SCOPE_IDENTITY());

		INSERT INTO cb.ManualFieldValue (ManualFieldId,DealIpdRunId,Value,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate) 
		SELECT ManualFieldId,@pNewDealIpdRunId,Value   
				,@pUserName,@date,@pUserName,@date
				FROM [Cb].[ManualFieldValue]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY ManualFieldValueId	
			
		INSERT INTO [Cb].[DealNote_Wf](DealIpdRunId,DealNoteId,PrincipalOutstanding_Ccy,PrincipalOutstanding_GBP,RemainingTermYears
					,FInalMaturityLTEq12MonthsOfCalculationForHardBullet
					,RequiredRedemptionForHardBullet,ExtendedDueForExtendedBond_LTEq1yr,RedemptionAmountForExtendedBond_LTEq1yr
					,RedemptionAmountForExtendedBond_GT1yr,RateForEstimation,BaseRate,Coupon
					,CouponPaymentStartPeriod,CouponPaymentEndPeriod,DayCount,DayCountFactor
					,InterestAmountDue_Ccy,InterestAmountDue_GBP,EstimatedThreeMonthInterest_GBP,EstimatedOneMonthInterest_GBP
					,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)			
		SELECT @pNewDealIpdRunId,DealNoteId,PrincipalOutstanding_Ccy,PrincipalOutstanding_GBP,RemainingTermYears
					,FInalMaturityLTEq12MonthsOfCalculationForHardBullet
					,RequiredRedemptionForHardBullet,ExtendedDueForExtendedBond_LTEq1yr,RedemptionAmountForExtendedBond_LTEq1yr
					,RedemptionAmountForExtendedBond_GT1yr,RateForEstimation,BaseRate,Coupon
					,CouponPaymentStartPeriod,CouponPaymentEndPeriod,DayCount,DayCountFactor
					,InterestAmountDue_Ccy,InterestAmountDue_GBP,EstimatedThreeMonthInterest_GBP,EstimatedOneMonthInterest_GBP
				,1, @pUserName ,@date, @pUserName ,@date
				FROM [Cb].[DealNote_Wf]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealNote_WfId

			INSERT INTO [Cb].[DealSwap_Wf] (DealIpdRunId,DealSwapId,PayCouponPeriodStart,PayCouponPeriodEnd,PayDayCountFactor,PayNotional,PayBaseRate
			,PayRate,PayMarginDifferential,PayAmount,ReceiveCouponPeriodStart,ReceiveCouponPeriodEnd,ReceiveNotional
			,ReceiveBaseRate,ReceiveRate,ReceiveDayCountFactor,ReceiveAmount,NetAmount
			,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)
		SELECT @pNewDealIpdRunId,DealSwapId,PayCouponPeriodStart,PayCouponPeriodEnd,PayDayCountFactor,PayNotional,PayBaseRate
			,PayRate,PayMarginDifferential,PayAmount,ReceiveCouponPeriodStart,ReceiveCouponPeriodEnd,ReceiveNotional
			,ReceiveBaseRate,ReceiveRate,ReceiveDayCountFactor,ReceiveAmount,NetAmount,
			1,@date,@pUserName,@date,@pUserName 
			FROM [Cb].[DealSwap_Wf]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealSwap_WfId

			INSERT INTO [Cb].[NoteSwap_Wf] (DealIpdRunId,NoteSwapId,PayCouponPeriodStart,PayCouponPeriodEnd,PayDayCountFactor,PayBaseRate,PayRate,PayAmount
				,ReceiveCouponPeriodStart,ReceiveCouponPeriodEnd,ReceiveBaseRate,ReceiveRate,ReceiveDayCountFactor,ReceiveAmount,NetAmount
				,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)
		SELECT @pNewDealIpdRunId,NoteSwapId,PayCouponPeriodStart,PayCouponPeriodEnd,PayDayCountFactor,PayBaseRate,PayRate,PayAmount
				,ReceiveCouponPeriodStart,ReceiveCouponPeriodEnd,ReceiveBaseRate,ReceiveRate,ReceiveDayCountFactor,ReceiveAmount,NetAmount
			,1,@date,@pUserName,@date,@pUserName 
			FROM [Cb].[NoteSwap_Wf]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY NoteSwap_WfId


			INSERT INTO [cb].[DealIpdTestResult] (TestTypeId,DealIpdRunId,Result,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestTypeId,@pNewDealIpdRunId,Result
			,@pUserName,@date,@pUserName ,@date
			FROM [cb].[DealIpdTestResult]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdTestResultId

			INSERT INTO cb.TestLineItemValue (TestLineItemID,DealIpdRunId,Value,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,@pNewDealIpdRunId,Value,
			1,@pUserName,@date,@pUserName ,@date
			FROM cb.TestLineItemValue
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY TestLineItemValueID

				INSERT INTO cb.ForwardPoolData (DealIpdRunId,Months,ForwardPool,NetInterestRateSwap,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT 
		@pNewDealIpdRunId,Months,ForwardPool,NetInterestRateSwap,@pUserName,@date,@pUserName ,@date
			FROM cb.ForwardPoolData
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY ForwardPoolDataId


			INSERT INTO [Cb].[PreMaturityLiquidity_PreWF]  (DealIpdRunId,CoveredBondFundId,PreMaturityLiquidity_bF,RequiredAmount1,FinalRequiredAmount
				,CapitalContribution,DueAmount,ResidualAmount
				,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,PreMaturityLiquidity_bF,RequiredAmount1,FinalRequiredAmount
				,CapitalContribution,DueAmount,ResidualAmount
			,1,@pUserName,@date,@pUserName ,@date
			FROM [Cb].[PreMaturityLiquidity_PreWF]  
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY PreMaturityLiquidity_PreWFId

			INSERT INTO [Cb].[CouponPaymentFund_PreWf] 
			(DealIpdRunId,CoveredBondFundId,CouponPayment_bF,RequiredAmount1
			,FinalRequiredAmount,CapitalContribution,DueAmount,ResidualAmount
			,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,CouponPayment_bF,RequiredAmount1
			,FinalRequiredAmount,CapitalContribution,DueAmount,ResidualAmount
			,1,@pUserName,@date,@pUserName ,@date
			FROM [Cb].[CouponPaymentFund_PreWf] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY CouponPaymentFund_PreWf

			
			INSERT INTO [Cb].[SwapCollateralFund] 
			(DealIpdRunId,CoveredBondFundId,SwapCollateralAmountReceived,SwapCollateralFund_bF
			,SwapCollateralExcludedAmount,ReleaseToARR,SwapCollateral_cf
			,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,SwapCollateralAmountReceived,SwapCollateralFund_bF
			,SwapCollateralExcludedAmount,ReleaseToARR,SwapCollateral_cf
			,1,@pUserName,@date,@pUserName ,@date
			FROM [Cb].[SwapCollateralFund] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY SwapCollateralFundId

			INSERT INTO [Cw].[CashWaterfallDealConfigValue] 
			(DealIpdRunId,CashWaterfallDealConfigId,Value,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CashWaterfallDealConfigId,Value
			,1,@pUserName,@date,@pUserName ,@date
			FROM [Cw].[CashWaterfallDealConfigValue] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY CashWaterfallDealConfigValueId

			INSERT INTO [Cb].[ReserveFund_PreWF] 
			(DealIpdRunId,CoveredBondFundId,ReserveFund_bF,TwelveMonthsRollingFeesForAToCRPP,RequiredAmount1
			,RequiredAmount2,FinalRequiredAmount,DueAmount,ResidualAmount,ReleaseToARR
			,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CoveredBondFundId,ReserveFund_bF,TwelveMonthsRollingFeesForAToCRPP,RequiredAmount1
			,RequiredAmount2,FinalRequiredAmount,DueAmount,ResidualAmount,ReleaseToARR
			,1,@pUserName,@date,@pUserName ,@date
			FROM [Cb].[ReserveFund_PreWF] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY ReserveFund_PreWFId
			
		    
		
		INSERT INTO [CW].[VariableValue] (DealIpdRunId,VariableId,ValueFormat,Value,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy) 
		SELECT @pNewDealIpdRunId,VariableId,ValueFormat,Value,IsActive,@date,@pUserName,@date,@pUserName FROM [CW].[VariableValue] 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY VariableValueId
			
		INSERT INTO [CW].[ExpressionValue] (DealIpdRunId,ExpressionId,Level,ValueFormat,Value,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy)  
		SELECT @pNewDealIpdRunId,ExpressionId,Level,ValueFormat,Value,IsActive,@date,@pUserName,@date,@pUserName 
		FROM [CW].[ExpressionValue]			
		WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY ExpressionValueId

				
		INSERT INTO [CW].[InterimWaterfallFee] (DealIpdRunId,InvoiceCategoryTypeId,InvoiceCategoryId,Amount,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate) 	
		SELECT @pNewDealIpdRunId,InvoiceCategoryTypeId,InvoiceCategoryId,Amount,IsActive,@pUserName,@date,@pUserName,@date FROM [CW].[InterimWaterfallFee]
			WHERE DealIpdRunId=@pOldDealIpdRunId 
			ORDER BY InterimWaterfallFeeId 	
			
		INSERT INTO cw.DealIpdTriggerResult(DealIpdRunId, DealTriggerMapId, OutcomeSummary, IsBreached, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate) 
		SELECT @pNewDealIpdRunId, DealTriggerMapId, OutcomeSummary, IsBreached,@pUserName,@date,ModifiedBy, ModifiedDate FROM [CW].[DealIpdTriggerResult]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdTriggerResultId

		INSERT INTO cw.DealIpdTriggerRatingResult(DealIpdRunId, DealTriggerRatingMapId, ThresholdRating, CurrentRating, IsBreached, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  
		SELECT @pNewDealIpdRunId, DealTriggerRatingMapId, ThresholdRating, CurrentRating, IsBreached,@pUserName,@date,@pUserName,@date FROM [CW].[DealIpdTriggerRatingResult]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdTriggerRatingResultId

			--No need to copy invoiceData as it is DealIpdRun agnostic

		INSERT INTO cw.CashWaterfallDealConfigValue (DealIpdRunId,CashWaterfallDealConfigId,Value
													,IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pNewDealIpdRunId,CashWaterfallDealConfigId,Value,1,@pUserName, @date, @pUserName, @date FROM cw.CashWaterfallDealConfigValue 
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY CashWaterfallDealConfigId	

			
		INSERT INTO cw.WaterfallLineItemAmount (DealIpdRunId,WaterfallLineItemId,ExpressionId,ToolTipValue,ToolTipFormatType,RequiredAmount,AdjustedAmount,TotalRequiredAmount,   
				ValueFormat,IsActive,CreatedDate,CreatedBy,ModifiedDate,ModifiedBy,AdjustmentBy,AdjustmentDate) 
		SELECT @pNewDealIpdRunId,WaterfallLineItemId,ExpressionId,ToolTipValue,ToolTipFormatType,RequiredAmount,AdjustedAmount,TotalRequiredAmount,   
				ValueFormat,IsActive,@date,@pUserName,null,null,null,null FROM [CW].[WaterfallLineItemAmount]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY WaterfallLineItemAmountId		

			
		INSERT INTO [cw].[DealIpdSummaryLineItemStatus](DealIpdRunId, DealIpdSummaryLineItemId, [Status], CreatedBy, CreatedDate, ModifiedBy, ModifiedDate) 
		SELECT @pNewDealIpdRunId, DealIpdSummaryLineItemId, [Status], @pUserName, @date, @pUserName, @date FROM [CW].[DealIpdSummaryLineItemStatus]
			WHERE DealIpdRunId=@pOldDealIpdRunId
			ORDER BY DealIpdSummaryLineItemStatusId
										

		--Existing workflowprocess record
		INSERT INTO cw.WorkflowProcess(ProcessReferenceId,WorkflowStepId,Comment,ActionedBy,ActionedDate,CreatedDate)
		SELECT @pNewDealIpdRunId,wfp.WorkflowStepId,wfp.Comment,wfp.ActionedBy,wfp.ActionedDate,wfp.CreatedDate FROM   cw.workflowprocess wfp  
		  JOIN  cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId  
		  JOIN  cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId  
		  WHERE wft.[Name] = 'Deal_IPD' AND wfp.ProcessReferenceId = @pOldDealIpdRunId   
		  ORDER BY wfp.ActionedDate
			

			
		EXEC cw.spLogExecution @pOldDealIpdRunId, @stepCode, 'SUCCESS',@inputParams, NULL,0,NULL, @pUserName,@logExecutionId OUT	  

		SET @pResultCode = 1
		
	END TRY
	BEGIN CATCH
		
		DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			 @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cw.spCopyInitIpdDataOnWithdraw', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		EXEC cw.spLogExecution @pOldDealIpdRunId, @stepCode, 'FAILED',@inputParams, @Message,0,NULL, @pUserName,@logExecutionId OUT
		SET @pResultCode = 0
		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )

		
	END CATCH

	
END

GO
