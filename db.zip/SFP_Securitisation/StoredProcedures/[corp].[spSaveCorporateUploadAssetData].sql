USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spSaveCorporateUploadAssetData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spSaveCorporateUploadAssetData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [corp].[spSaveCorporateUploadAssetData]  
 @PoolId INT,  
 @LimitAnalysisField VARCHAR(200),  
 @UserName VARCHAR(50)   
AS  
BEGIN     
   
   DECLARE @PartitionId INT;
   DECLARE @IsBalanceUploaded BIT;     
   
   BEGIN TRY     
  
  --Getting PartionId       
  SELECT @PartitionId =CONVERT(VARCHAR, VintageDate, 112) FROM ps.Pool WHERE PoolId = @poolId; 
  SELECT @IsBalanceUploaded = (SELECT TOP(1) IsBalanceUploaded FROM ps.Pool WHERE PoolId = @PoolId)

  --First delete all the data related     
  DELETE FROM [ps].[PoolBuildDetail]     
  WHERE [PoolId] = @PoolId;     
      
  --Getting distinct asset data   
  
   SELECT  DISTINCT   
	   REPLACE(ff.FacilityId,'\P','') AS FacilityId,
	   ff.FacilityKey,
     CASE 
        WHEN @IsBalanceUploaded = 1 THEN uapm.LoanBalance 
        WHEN @LimitAnalysisField = 'OUTSTANDNG_CAPITAL_BALANCE_AMT' THEN ff.MarkedLimitAmt 
        ELSE ff.MarkedLimitAmt
     END AS Balance
   FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] ff
   INNER JOIN ps.UploadedAssetPoolMap uapm    
    ON REPLACE(ff.FacilityId,'\P','') =  CONVERT(VARCHAR,uapm.LoanId)  
	--ON CASE WHEN ff.SourceId = 2 THEN CONVERT(VARCHAR(10),uapm.LoanId) + '\P' ELSE  CONVERT(VARCHAR(10),uapm.LoanId) END = ff.FacilityId
    AND uapm.isActive = 1   
    AND uapm.PoolId = @PoolId   
  WHERE ff.PartitionId = @PartitionId  
 
  END TRY     
    
  BEGIN CATCH    
    
   DECLARE     
    @errorMessage     NVARCHAR(MAX),    
    @errorSeverity    INT,    
    @errorNumber      INT,    
    @errorLine        INT,    
    @errorState       INT;    
   SELECT     
    @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()            
    
   EXEC app.SaveErrorLog 2, 1, 'spSaveCorporateUploadAssetData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @UserName    
      
   RAISERROR (@errorMessage,    
     @errorSeverity,    
     @errorState )    
  END CATCH;    
END
GO