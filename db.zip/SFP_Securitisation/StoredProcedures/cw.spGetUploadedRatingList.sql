USE SFP_Securitisation
GO
IF OBJECT_ID('cw.spGetUploadedRatingList') IS NOT NULL
	DROP PROCEDURE cw.spGetUploadedRatingList 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--========================================
--Author: Saurabh Bhatia
--Date:	27-April-2020
--Description:  To get User Rating List
--Exec cw.spGetUploadedRatingList
--========================================
CREATE PROCEDURE cw.spGetUploadedRatingList
AS
BEGIN
	DECLARE @RatingUploadDetailId TABLE (RatingUploadDetailId INT)

	SELECT
		 urf.RatingUploadDetailId
		,d.DealName
		,urf.CollectionDate
		,urf.OriginalFileName
		,urf.UploadedFileName
		,urf.UploadedBy
		,urf.UploadedDate
	FROM cw.RatingUploadDetail urf
	JOIN cw.vw_ActiveDeal d ON urf.DealId = d.DealId	
	ORDER BY urf.UploadedDate DESC
END
