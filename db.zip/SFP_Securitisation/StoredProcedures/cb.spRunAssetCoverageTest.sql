USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRunAssetCoverageTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunAssetCoverageTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRunAssetCoverageTest]
/*
 * Author: Kapil Sharma
 * Date:	10.02.2022
 * Description:  This will RUN the ACT Test
 * 
 * Example - 
 * [cb].[spRunAssetCoverageTest] 67, 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE
			@dealId					INT,
			@testTypeId				INT,
			@collectionStartDt		DATE,
			@collectionEndDt		DATE,
			@dealIpdId				INT,
			@ipdDate				DATE,
			@lineItemCode			VARCHAR(200),
			@notesIssuanceAmount	DECIMAL(36, 18),
			@lineItemValue			DECIMAL(36, 18),
			@lineItemValue1			DECIMAL(36, 18),
			@lineItemValue2			DECIMAL(36, 18),
			@lineItemValue3			DECIMAL(36, 18),
			@weightedAverageMargin  DECIMAL(36, 9),
			@aggrAdjAssetAmt		DECIMAL(36, 18),
			@testResult				VARCHAR(40),
			@createdBy				VARCHAR(80) = 'System',
			@createdDate			DATETIME = GETDATE()

		SELECT @dealId = di.DealId, 
			@collectionStartDt = did.CollectionBusinessStart, 
			@collectionEndDt = did.CollectionBusinessEnd,
			@dealIpdId = di.DealIpdId, @ipdDate = di.IpdDate
		FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
		WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1
		PRINT @collectionEndDt
		DECLARE @tblTestLineItemValue TABLE(TestLineItemId INT, LineItemCode VARCHAR(200), LineItemValue VARCHAR(100))

		SELECT @testTypeId = TestTypeID FROM cfgcb.TestType WHERE InternalName = 'AssetCoverageTest'

		SELECT @notesIssuanceAmount = SUM(ISNULL(PrincipalOutstanding_GBP, 0)) FROM cb.DealNote_Wf WHERE  DealIpdRunId = @pDealIpdRunId

		IF @notesIssuanceAmount IS NOT NULL --This to ensure that test will not fail 
		BEGIN
			----*****START-(I) Aggregated Adjusted Asset Amount ((A + B + C + D + E- (X +Y + Z))----------------
			----Level1 - ACT_1.1_A(i)_AdjustedOutstandingBalance--------------------

			--Calculate ACT_1.1_A(i)_NWBAdjustedOutstandingBalance
			SET @lineItemCode = 'ACT_1.1_A(i)_NWBAdjustedOutstandingBalance'
			SELECT @lineItemValue = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'ArrearsAdjustedCapitalBalance'), 0)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			--Calculate ACT_1.1_A(i)_(Less)BreachesOfRepsAndWarranties
			SET @lineItemCode = 'ACT_1.1_A(i)_(Less)BreachesOfRepsAndWarranties'
			SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'Breaches_Reps_Warranties'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)
			SET @lineItemCode = 'ACT_1.1_A(ii)_(Less)BreachesOfRepsAndWarranties'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			----Calculate ACT_1.1_A(i)_(Less)BreachesOfWarranties
			--SET @lineItemCode = 'ACT_1.1_A(i)_(Less)BreachesOfWarranties' 
			--SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'Breaches_Warranties'), 0) AS FLOAT)
			--INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)
			--SET @lineItemCode = 'ACT_1.1_A(ii)_(Less)BreachesOfWarranties'
			--INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			--Calculate Level1 - ACT_1.1_A(i)_AdjustedOutstandingBalance
			SET @lineItemCode = 'ACT_1.1_A(i)_AdjustedOutstandingBalance' 
			SELECT @lineItemValue = ((SELECT LineItemValue FROM @tblTestLineItemValue WHERE LineItemCode = 'ACT_1.1_A(i)_NWBAdjustedOutstandingBalance') - 
			--(SELECT SUM(CAST(LineItemValue AS FLOAT)) FROM @tblTestLineItemValue WHERE LineItemCode IN( 'ACT_1.1_A(i)_(Less)BreachesOfRepsAndWarranties', 'ACT_1.1_A(i)_(Less)BreachesOfWarranties')))
			(SELECT SUM(CAST(LineItemValue AS FLOAT)) FROM @tblTestLineItemValue WHERE LineItemCode IN( 'ACT_1.1_A(i)_(Less)BreachesOfRepsAndWarranties')))
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			----Level1 - ACT_1.1_A(ii)_ArrearAdjustedOutstandingBalance--------------------

			--Calculate ACT_1.1_A(ii)_NWBArrearsAdjustedOutstandingBalance
			SET @lineItemCode = 'ACT_1.1_A(ii)_NWBArrearsAdjustedOutstandingBalance'
			SELECT @lineItemValue = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'ArrearsAdjustedCapitalBalancePreAssetPercentage'), 0)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			--Calculate Maximum Asset Percentage from Fitch (ACT_1.1_A(ii)_MaximumAssetPercentageFromFitch)
			SET @lineItemCode = 'ACT_1.1_A(ii)_MaximumAssetPercentageFromFitch'
			SELECT @lineItemValue1 = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'Max_Fitch_perct'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue1/100  AS DECIMAL(9,8)) AS VARCHAR(10)))

			SET @lineItemCode = 'ACT_1.1_A(ii)_MaximumAssetPercentageFromMoodys'
			SELECT @lineItemValue2 = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'Max_Moodys_perct'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue2/100 AS DECIMAL(9,8)) AS VARCHAR(10)) )

			SET @lineItemCode = 'ACT_1.1_A(ii)_MoodysBenchmark'
			SELECT @lineItemValue3 = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'Moodys_Benchmark'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue2/100 AS DECIMAL(9,8)) AS VARCHAR(10)) )

			SET @lineItemCode = 'ACT_1.1_A(ii)_ArrearAdjustedOutstandingBalance'
			SELECT @lineItemValue = ((SELECT LineItemValue FROM @tblTestLineItemValue WHERE LineItemCode = 'ACT_1.1_A(ii)_NWBArrearsAdjustedOutstandingBalance') - 
			--(SELECT SUM(CAST(LineItemValue AS FLOAT)) FROM @tblTestLineItemValue WHERE LineItemCode IN( 'ACT_1.1_A(ii)_(Less)BreachesOfRepsAndWarranties', 'ACT_1.1_A(ii)_(Less)BreachesOfWarranties'))) * 
			(SELECT SUM(CAST(LineItemValue AS FLOAT)) FROM @tblTestLineItemValue WHERE LineItemCode IN( 'ACT_1.1_A(ii)_(Less)BreachesOfRepsAndWarranties'))) * 
			(SELECT MIN(Val)/100 FROM  (VALUES(@lineItemValue1), (@lineItemValue2), (@lineItemValue2)) T(Val))
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, ISNULL(@lineItemValue, 0))

			SET @lineItemCode = 'ACT_1.1_MethodUsedForCalculatingComponentA'
			SELECT @lineItemValue1 = MIN(LineItemValue) FROM @tblTestLineItemValue WHERE LineItemCode = 'ACT_1.1_A(i)_AdjustedOutstandingBalance' --A(i)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CASE WHEN @lineItemValue < @lineItemValue1 THEN 'A(ii)' ELSE 'A(i)' END)

			SET @lineItemCode = 'ACT_1.1_ComponentA'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, ISNULL(@lineItemValue, 0))

			---Level 1 - (1.2) Component B

			--Calculate ACT_1.2_Adjustments
			SET @lineItemCode = 'ACT_1.2_PrincipalReceipts'
			SELECT @lineItemValue = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'MonthlyPrincipalReceipts'), 0) --As this value is in Negative in Daily Collection
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @lineItemCode =  'ACT_1.2_Adjustments'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) 
			SELECT @lineItemCode, SUM(ISNULL(wlia.AdjustedAmount, 0))  FROM cfgcw.WaterfallLineItem wli
			JOIN cfgcw.WaterfallCategory wc ON wc.WaterfallCategoryId = wli.WaterfallCategoryId
			JOIN cw.WaterfallLineItemAmount wlia ON wlia.WaterfallLineItemId = wli.WaterfallLineItemId
			WHERE
				wc.DealId = @dealId AND wc.InternalName = 'PreAvailablePrincipalReceipts'
				AND wli.InternalName = 'PreAvailablePrincipalReceipts_8.000'
				AND wlia.DealIpdRunId = @pDealIpdRunId  
		
			SET @lineItemCode = 'ACT_1.2_DeflaggedPrincipalReceipts'
			SELECT @lineItemValue = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'Repurchases'), 0) --As this value is in Negative in Daily Collection
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @lineItemCode = 'ACT_1.2_PrincipalLedgerCF'
			SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'PrincipaL_Ledger_CF'), 0) AS DECIMAL(36, 18))
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @lineItemCode = 'ACT_1.2_ComponentB'
			SELECT @lineItemValue = SUM(CAST(LineItemValue AS FLOAT))*-1 FROM @tblTestLineItemValue WHERE LineItemCode IN ('ACT_1.2_PrincipalReceipts', 'ACT_1.2_Adjustments', 
			'ACT_1.2_DeflaggedPrincipalReceipts', 'ACT_1.2_PrincipalLedgerCF')
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue)
			SELECT @lineItemCode, @lineItemValue

			--Level 1 - ACT_1.3_ComponentC
			SET @lineItemCode = 'ACT_1.3_CashCapitalContribution'
			SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'CashCapitalContribution'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @lineItemCode = 'ACT_1.3_ComponentC'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			--Level 1 - (1.4) Component D
			SET @lineItemCode = 'ACT_1.4_SubstitutionAssets'
			SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'SubstitutionAssets'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @lineItemCode = 'ACT_1.4_ComponentD'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, ISNULL(@lineItemValue, @lineItemValue))

			--Level 1 - (1.5) Component E
			SET @lineItemCode = 'ACT_1.5_SaleProceedsToTheCreditOfPreMaturityLL'
			SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'SalesProceedsCreditPreMaturityLedger'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @lineItemCode = 'ACT_1.5_ComponentE'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			--Level 1 - (1.6) Component X
			SET @lineItemCode = 'ACT_1.6_Flexible_DrawAllowance'
			SELECT @lineItemValue = CAST(ISNULL([cb].[fnGetManualFieldValue](@pDealIpdRunId, 'AssetCoverage', 'FlexibleDrawCapacity'), 0) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, (@lineItemValue*0.08*3))

			SET @lineItemCode = 'ACT_1.6_ComponentX'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, (@lineItemValue*0.08*3))

			--Level 1 - (1.7) Component Y
			SET @lineItemCode = 'ACT_1.7_SetOff'
			SELECT @lineItemValue = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'SetOffPercentage_Biannual'), 0)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue AS DECIMAL(12, 4)) AS VARCHAR(12)) + '%' )

			SET @lineItemCode = 'ACT_1.7_OutstandingCapitalBalanceAmount'
			SELECT @lineItemValue1 = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'TotalMortgageCapitalBalanceCF'), 0)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue1)

			SET @lineItemCode = 'ACT_1.7_ComponentY'
			SELECT @lineItemValue1 = CAST(ISNULL(CAST(@lineItemValue1 AS FLOAT)* @lineItemValue/100, 0 ) AS FLOAT)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue1)

			------ (1.8) Component Z
			--Calculate Weighted Average Margin - ACT_1.8_NegativeCarryAmount_NegativeCarryFactor_WeightedAverageMargin

			SELECT @lineItemValue1 = SUM((CAST(ISNULL(dnWf.PrincipalOutstanding_GBP, 0) AS FLOAT)/10000*
			CAST((CASE WHEN dn.IsSwapLinked = 1 THEN ISNULL(nw.PayMargin, 0) ELSE ISNULL(dn.Margin, 0) END) AS FLOAT)))
			/CAST(SUM(ISNULL(dnWf.PrincipalOutstanding_GBP, 0))AS FLOAT )
			FROM cfgcb.DealNote dn
			JOIN cb.DealNote_Wf dnWf ON dnwf.DealNoteId = dn.DealNoteId
			LEFT JOIN cfgcb.NoteSwap nw ON nw.DealNoteId = dn.DealNoteId AND  nw.ValidTo > @ipdDate
			WHERE dn.ValidTo > @ipdDate AND dnWf.DealIpdRunId = @pDealIpdRunId

			SET @lineItemCode = 'ACT_1.8_NegativeCarryAmount_NegativeCarryFactor_WeightedAverageMargin'
			SET @weightedAverageMargin = ROUND(@lineItemValue1, 10, 1)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@weightedAverageMargin*100 AS DECIMAL(12, 4)) AS VARCHAR(12)) + '%')
			
			--Calculate Negative Carry Factor - ACT_1.8_NegativeCarryAmount_NegativeCarryFactor
			print '@weightedAverageMargin'
			print @weightedAverageMargin
			SET @lineItemCode = 'ACT_1.8_NegativeCarryAmount_NegativeCarryFactor'
			SELECT @lineItemValue2 = CASE WHEN @weightedAverageMargin<=0.001 THEN 0.005 ELSE (@weightedAverageMargin - 0.001) + 0.005 END 
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue2*100 AS DECIMAL(12, 4)) AS VARCHAR(12)) + '%')


			--Weighted Average Remaining Term (Years) - ACT_1.8_NegativeCarryAmount_WeightedAverageRemainingTerm
			SET @lineItemCode = 'ACT_1.8_NegativeCarryAmount_WeightedAverageRemainingTerm'
			SELECT @lineItemValue3 = ROUND(CAST(SUM(ROUND(dnWf.RemainingTermYears, 6, 1)*PrincipalOutstanding_GBP) AS FLOAT)/CAST(SUM(PrincipalOutstanding_GBP) AS FLOAT), 8, 1)
			FROM cfgcb.DealNote dn
			JOIN cb.DealNote_Wf dnWf ON dnWf.DealNoteId = dn.DealNoteId 
			WHERE dnWf.DealIpdRunId = @pDealIpdRunId 
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue3)

			--Principal Outstanding Amount (Sterling) - ACT_1.8_NegativeCarryAmount_PrincipalOutstandingAmount
			SET @lineItemCode = 'ACT_1.8_NegativeCarryAmount_PrincipalOutstandingAmount'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @notesIssuanceAmount)

			--Negative Carry Amount - ACT_1.8_NegativeCarryAmount
			SET @lineItemCode = 'ACT_1.8_NegativeCarryAmount'
			SELECT @lineItemValue =  @notesIssuanceAmount*ROUND(@lineItemValue3, 8, 1)*ROUND(@lineItemValue2, 8, 1)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)
			
			SET @lineItemCode = 'ACT_1.8_ComponentZ'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

			SET @aggrAdjAssetAmt = (SELECT SUM(CAST(LineItemValue AS FLOAT)) FROM @tblTestLineItemValue WHERE LineItemCode IN ('ACT_1.1_ComponentA', 'ACT_1.2_ComponentB', 'ACT_1.3_ComponentC', 'ACT_1.4_ComponentD', 'ACT_1.5_ComponentE')) - 
			(SELECT SUM(CAST(LineItemValue AS FLOAT)) FROM @tblTestLineItemValue WHERE LineItemCode IN ('ACT_1.6_ComponentX', 'ACT_1.7_ComponentY', 'ACT_1.8_ComponentZ'))  

			SET @lineItemCode = 'ACT_AggregatedAdjustedAssetAmount'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @aggrAdjAssetAmt)
			-------END-(I) Aggregated Adjusted Asset Amount ((A + B + C + D + E- (X +Y + Z))------------------

			-------Remaining Items----------------
			SET @lineItemCode = 'ACT_PrincipalAmountOutstanding'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @notesIssuanceAmount)

			SET @lineItemCode = 'ACT_AssetCoverageTestResults'
			SET @testResult = (CASE WHEN @notesIssuanceAmount>@aggrAdjAssetAmt THEN 'FAIL' ELSE 'PASS' END)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @testResult)

			SET @lineItemCode = 'ACT_CreditSupportAsDerivedFromACT(GBP)'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, (@aggrAdjAssetAmt - @notesIssuanceAmount))

			SET @lineItemCode = 'ACT_CreditSupportAsDerivedFromACTPercentage'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(((@aggrAdjAssetAmt - @notesIssuanceAmount)/@notesIssuanceAmount) AS DECIMAL(38, 8)) AS VARCHAR(20)) )

			SET @lineItemCode = 'ACT_MaximumAssetPercentageFromS&P'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, 'N/A')

			SET @lineItemCode = 'ACT_MaximumAssetPercentageFromDBRS'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, 'N/A')

			--------Now insert the test line item into the main table

			--First update the TestLineItemId in the table variable
			UPDATE tbl SET tbl.TestLineItemId = tli.TestLineItemId
			FROM  @tblTestLineItemValue tbl
			JOIN cfgcb.TestLineItem tli ON tli.InternalName = tbl.LineItemCode
			JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
			WHERE tt.TestTypeID = @testTypeId

			--Now merge the line item values into main table
			MERGE cb.TestLineItemValue AS trg
			USING @tblTestLineItemValue AS src
			ON src.TestLineItemId = trg.TestLineItemId AND trg.DealIpdrunId = @pDealIpdRunId
			WHEN NOT MATCHED BY Target THEN
				INSERT (TestLineItemID, DealIpdRunId, [Value], IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES (src.TestLineItemId, @pDealIpdRunId, src.LineItemValue, 1, @createdBy, @createdDate, @createdBy, @createdDate)
			WHEN MATCHED THEN UPDATE SET
				trg.[Value]	= src.LineItemValue, trg.ModifiedDate = @createdDate, trg.ModifiedBy = @pUserName;

			---Save the test result 
			EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeId, @testResult, @pUserName
		END
		ELSE
		BEGIN
			PRINT 'Cashwaterfall is not run yet so spRunAssetCoverageTest cannot be run'
		END
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spRunAssetCoverageTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO