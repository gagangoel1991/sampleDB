USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRunPreMaturityTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunPreMaturityTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRunPreMaturityTest] 
    @pDealIpdRunId INT,
	@pUserName  VARCHAR(80) ='System'      
AS  
--   
/*
 * Author: Suresh Pandey
 * Date:	08-02-2022
 * Description:  This will run the  PeMaturity test and insert data for test.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Exec [cb].[spRunPreMaturityTest] 37,'suresh'
 * 
 * select  *from cb.DealIpdTestResult where DealIpdRunId=1034 and testtypeid=4
 * select  *from cb.TestLineItemValue  where DealIpdRunId=1034 and TestLineItemID in(select TestLineItemID from cfgcb.TestLineItem where testtypeid=4)
 * 
*/
BEGIN  
  
BEGIN TRY  
  
	DECLARE @result											VARCHAR(10)='N/A',
			@hardBulletCoveredBonds							VARCHAR(3) ='NO',
			@maturityDateLessThan12MonthsFromCurrentIPD		VARCHAR(3) ='NO',
			@triggerIsBreached								VARCHAR(3) ='NO',
			@ipdDate										DATETIME,
			@date12monthFromIpd								DATE,
			@testTypeID										INT,
			@dealId											INT;

			 
	SELECT @dealId=dealid, @ipdDate = IpdDate, @date12monthFromIpd= DATEADD(MONTH,12,IpdDate) FROM  cw.vwDealIpdRun 
		WHERE  DealIpdRunId = @pDealIpdRunId; 
		
			
	SELECT @testTypeID=TestTypeID  FROM cfgcb.TestType WHERE InternalName='PreMaturityTest'
	
	SET @triggerIsBreached = (SELECT CASE WHEN [CW].[fnIsTriggerBreached](@dealId, @pDealIpdRunId,'RatingTrigger','Pre-MaturityTest')=1 THEN 'YES' ELSE 'NO' END)

	IF EXISTS(SELECT 1 FROM cb.DealNote_Wf dnwf
				JOIN cfgcb.DealNote dn ON dn.DealNoteId=dnwf.DealNoteId
				JOIN  cfgcw.DealLookupValue dlv ON dlv.LookupValueId=dn.BulletId
				JOIN  cfgcw.DealLookupType dlt ON dlt.LookupTypeId=dlv.LookupTypeId
				WHERE dnwf.DealIpdRunId=@pDealIpdRunId AND dlv.[Name]='Bullet_Hard')
	BEGIN
		SET @result='FAIL'
		SET @hardBulletCoveredBonds = 'YES'

		IF EXISTS(SELECT 1 FROM cb.DealNote_Wf dnwf
				JOIN cfgcb.DealNote dn ON dn.DealNoteId=dnwf.DealNoteId
				JOIN  cfgcw.DealLookupValue dlv ON dlv.LookupValueId=dn.BulletId
				JOIN  cfgcw.DealLookupType dlt ON dlt.LookupTypeId=dlv.LookupTypeId
				WHERE dnwf.DealIpdRunId=@pDealIpdRunId AND dlv.[Name]='Bullet_Hard' AND dn.MaturityDate < @date12monthFromIpd)
		BEGIN
			SET @maturityDateLessThan12MonthsFromCurrentIPD = 'YES'
			
			IF(@triggerIsBreached = 'YES')
				SET @result='PASS'
		
		END

	END

	 
	IF ( Object_id('tempdb..#TestLineItemValue') IS NOT NULL ) 
		DROP TABLE #TestLineItemValue 

	CREATE TABLE #TestLineItemValue(
		TestLineItemID INT,
		InternalName VARCHAR(200),
		DealIpdRunId INT,
		[Value] VARCHAR(500))

	INSERT INTO #TestLineItemValue(TestLineItemID,InternalName,DealIpdRunId,[Value])
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@hardBulletCoveredBonds FROM cfgcb.TestLineItem WHERE InternalName='HardBulletBond'
	UNION				  
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@maturityDateLessThan12MonthsFromCurrentIPD FROM cfgcb.TestLineItem WHERE InternalName='FinalMaturityOfBondWithin12Months'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@triggerIsBreached FROM cfgcb.TestLineItem WHERE InternalName='PreMaturityRatingTriggersBreached'
	UNION				 
	SELECT TestLineItemID,InternalName,@pDealIpdRunId,@result FROM cfgcb.TestLineItem WHERE InternalName='PreMaturityTestResult'

	IF NOT EXISTS(SELECT 1 FROM cb.TestLineItemValue tv
							JOIN cfgcb.TestLineItem tl  ON tl.TestLineItemID=tv.TestLineItemID
							JOIN cfgcb.TestType tt ON tt.TestTypeId=tl.TestTypeId
							WHERE DealIpdRunId =@pDealIpdRunId AND tt.TestTypeId=@testTypeID)
	BEGIN
		INSERT INTO cb.TestLineItemValue(TestLineItemID,DealIpdRunId,[Value],IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,DealIpdRunId,CAST(ISNULL([Value],0) AS VARCHAR),1,@pUserName,GETDATE(),@pUserName,GETDATE() FROM #TestLineItemValue 
		
	END
	ELSE
	BEGIN	
		
		UPDATE tv SET tv.[Value]=CAST(ISNULL(temp.[Value],0) AS VARCHAR),tv.ModifiedBy=@pUserName, tv.ModifiedDate=GETDATE() 
			FROM cb.TestLineItemValue tv
			JOIN #TestLineItemValue temp
				ON temp.TestLineItemID=tv.TestLineItemID AND temp.DealIpdRunId=tv.DealIpdRunId
		WHERE temp.DealIpdRunId=@pDealIpdRunId

	END

	IF NOT EXISTS(SELECT 1 FROM cb.TestLineItemValue tv
							JOIN cfgcb.TestLineItem tl  ON tl.TestLineItemID=tv.TestLineItemID
							JOIN cfgcb.TestType tt ON tt.TestTypeId=tl.TestTypeId
							WHERE DealIpdRunId =@pDealIpdRunId AND tt.TestTypeId=@testTypeID AND tl.InternalName='PreMaturityTestResult')
	BEGIN
		INSERT INTO cb.TestLineItemValue(TestLineItemID,DealIpdRunId,[Value],IsActive,CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT TestLineItemID,DealIpdRunId,CAST(ISNULL([Value],0) AS VARCHAR),1,@pUserName,GETDATE(),@pUserName,GETDATE() FROM #TestLineItemValue 
		WHERE InternalName='PreMaturityTestResult'
		
	END
	ELSE
	BEGIN	
		
		UPDATE tv SET tv.[Value]=CAST(ISNULL(temp.[Value],0) AS VARCHAR),tv.ModifiedBy=@pUserName, tv.ModifiedDate=GETDATE() 
			FROM cb.TestLineItemValue tv
			JOIN #TestLineItemValue temp
				ON temp.TestLineItemID=tv.TestLineItemID AND temp.DealIpdRunId=tv.DealIpdRunId
		WHERE temp.DealIpdRunId=@pDealIpdRunId AND temp.InternalName='PreMaturityTestResult'

	END

	EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeID, @result, @pUserName

END TRY 
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cb.spRunPreMaturityTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END

GO