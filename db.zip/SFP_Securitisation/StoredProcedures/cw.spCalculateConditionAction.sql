USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spCalculateConditionAction') IS NOT NULL
	DROP PROCEDURE cw.spCalculateConditionAction
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spCalculateConditionAction
(
 /* 
 *   Author: Aditya Shrivastava 
 *   Date:  09.08.2021
 *   Description:  
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   ------------------------------------------------------- 
 *      
 * 	 
 * 	 cw.spCalculateConditionAction,'fm\shriyad'
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80)
)
AS
BEGIN
	BEGIN TRY
		--DECLARE @pDealIpdRunId INT = 32, @pUserName	VARCHAR(80) ='fm\shriyad'

		DECLARE @DealId smallInt,
		@tempId INT,
		@dynsql nvarchar(500)  ,
		@params nvarchar(500), 
		@returnValue AS BIT,
		@spName VARCHAR(MAX)

		SET @DealId  = (SELECT DealId FROM cw.vwdealipdrun WHERE DealIpdRunId = @pDealIpdRunId);

		IF OBJECT_ID('tempdb..#temp') IS NOT NULL DROP TABLE #temp

		SELECT dc.DealConditionId, dc.ActionStoredProcedure
		INTO #temp 
		FROM 
		cfgcw.DealCondition dc 
		JOIN cw.DealIpdConditionTest dct ON dc.DealConditionId = dct.DealConditionId
		AND dct.DealIpdRunId = @pDealIpdRunId
		AND dc.ActionStoredProcedure IS NOT NULL
		AND dct.ExpectedStatus != dct.ResultedStatus

		SET @tempId = (SELECT TOP 1 DealConditionId FROM #temp ORDER BY DealConditionId ASC);
		SET @spName = (SELECT ActionStoredProcedure FROM #temp WHERE DealConditionId =  @tempId);

		SET @params='@RunId int,@pUserName	VARCHAR(80)'

		WHILE(@tempId IS NOT NULL)
		BEGIN
			IF(@spName IS NOT NULL)
			BEGIN
				SET @dynsql='exec '+@spName+' @RunId,@pUserName'

				PRINT '@dynsql'
				PRINT @dynsql
				
				EXEC sp_executesql @dynsql, @params, @RunId=@pDealIpdRunId, @pUserName = @pUserName
				
			END


			SET @tempId  = (SELECT TOP 1 DealConditionId FROM #temp WHERE DealConditionId> @tempId ORDER BY DealConditionId ASC);
			SET @spName = (SELECT ActionStoredProcedure FROM #temp WHERE DealConditionId =  @tempId);

		END

		END TRY
		BEGIN CATCH
			DECLARE 
				@errorMessage     NVARCHAR(MAX),
				@errorSeverity    INT,
				@errorNumber      INT,
				@errorLine        INT,
				@errorState       INT;

			SELECT 
				@errorMessage = ERROR_MESSAGE()
				,@errorSeverity = ERROR_SEVERITY()
				,@errorNumber = ERROR_NUMBER()
				,@errorLine = ERROR_LINE()
				,@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'spCalculateConditionOverrideSql', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
			RAISERROR (@errorMessage,
				 @errorSeverity,
				 @errorState )

		END CATCH


	END



	GO