USE SFP_Securitisation
GO

IF OBJECT_ID('cb.spIR_PaymentHoliday') IS NOT NULL
	DROP PROC cb.spIR_PaymentHoliday
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-----------------------------------------------------
--Author: Arun 
--Date:	09-Feb-2022
--Description: This SP is Used to Get Covid-19-related Payment Holidays

--EXEC cb.spIR_PaymentHoliday '2021-04-30','DEIMOS'
--go
--EXEC cb.spIR_PaymentHoliday '2021-05-28','DEIMOS'

-----------------------------------------------------


CREATE PROCEDURE cb.spIR_PaymentHoliday
(
	 @pAsAtDate DATETIME
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
)

AS

BEGIN
	BEGIN TRY  

		DECLARE @dealId int;
		DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		DECLARE @totalSubAccounts float, @totalOutstandingCapitalBalance float

		SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
		SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
		
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
		INSERT INTO #VwMortgageSubAccount   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId

	
		SELECT @totalOutstandingCapitalBalance = sum(Outstandng_Capital_Balance_Amt)
		, @totalSubAccounts = count(*)
		FROM #VwMortgageSubAccount

		SELECT 'Loans currently with Payment Holiday Applied' AS [HeaderText]
		, count(PaymentOverride_Amount)  AS Number
		, CASE WHEN @totalSubAccounts > 0 THEN Cast(( count(PaymentOverride_Amount) / @totalSubAccounts ) AS Float)  ELSE 0 END AS [% of Total Number]
		, sum(Outstandng_Capital_Balance_Amt) AS [Amount (GBP)] 
		, CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast((sum(Outstandng_Capital_Balance_Amt) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS [% of Total Amount]
		FROM #VwMortgageSubAccount 
		WHERE PaymentOverride_StartDate <=  @pAsAtDate AND PaymentOverride_EndDate >= @pAsAtDate
		AND PaymentOverride_Amount IS NOT NULL

	
	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spIR_PaymentHoliday', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   

END

Go


