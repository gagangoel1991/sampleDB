USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[uspGetFacilitySecurityMaturityDates]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[uspGetFacilitySecurityMaturityDates]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
	CREATED BY : Sakthivel
	DATE	   : 10-Aug-2022
	NOTES	   : To get the list of maturity dates for facility override upload validation
	 --EXEC [corp].[uspGetFacilitySecurityMaturityDates]   '2022-05-31', 1
*/

CREATE PROCEDURE [corp].[uspGetFacilitySecurityMaturityDates]  
    @pDate DATE, 
    @pDealId VARCHAR(50),
	@pUserName VARCHAR(50) = 'System',
	@pIsRonaRequired INT = 0
AS
BEGIN
	--DECLARE @ReqCols XML = NULL
	--SELECT 'FacilityId' as CriteriaFieldName into #myTbl union select 'MaturityDate' 
	--SELECT @ReqCols = ( select * from #myTbl FOR XML PATH('Node'), ROOT('Root'))
 
	 -- [rpt].[uspCommercialFacilityEntity] 
	DECLARE @RowID VARCHAR(100) 
	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]  @VintageDate = @pDate , @DealKey = @pDealId, @FacilityIds = null, @ReqColumns =null, @OutputRowID = @RowID OUTPUT      
	   
    SELECT FacilityKey, FacilityId,SecurityKey,CradleSecurityId, SecurityUniqueId, ExpiryDate , 
	CASE WHEN FacilitySourceId = 2 THEN SecurityUniqueId ELSE CradleSecurityID END AS SecurityID , 
	ConnectionName, FacilitySourceId, CONVERT(DECIMAL(19, 2), 0) RONA
	INTO #TmpStagingDataWithRona
	FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
	
    IF (@pIsRonaRequired = 1)
	BEGIN

		Declare @FacilityList  corp.FacilityList 
		INSERT INTO @FacilityList 
		--SELECT '76881800' UNION SELECT '88111800' UNION SELECT '10437857' 
	    SELECT DISTINCT FacilityId FROM #TmpStagingDataWithRona

		CREATE TABLE #tblCalculatedRona(FacilityId INT, FacilityKey INT, AvailableRonaForAllocation DECIMAL(19,2)) 
		INSERT INTO #tblCalculatedRona    
		--EXEC CORP.spCalculateAvailableRona_Override  0, NULL, @FacilityList, @pUserName, @pDate, @pDealId
		EXEC CORP.spCalculateAvailableRona  0, NULL, @FacilityList, @pUserName, @pDate, @pDealId

		UPDATE STG
		SET STG.RONA = AvailableRonaForAllocation
		FROM #TmpStagingDataWithRona STG
		INNER JOIN #tblCalculatedRona tblRona ON STG.FacilityKey = tblRona.FacilityKey AND STG.FacilityId = tblRona.FacilityId
	END

	SELECT * FROM #TmpStagingDataWithRona
	DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
 END
 GO
 --EXEC [corp].[uspGetFacilitySecurityMaturityDates]   '2022-10-31', 1, 'loga', 0
