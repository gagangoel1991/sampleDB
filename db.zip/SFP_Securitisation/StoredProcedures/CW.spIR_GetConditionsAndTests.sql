USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spIR_GetConditionsAndTests') IS NOT NULL
DROP PROC CW.spIR_GetConditionsAndTests
GO

/*
 * Author: Arun
 * Date:    11.05.2021
 * Description:  This will return conditionn and tests details for Investor report.
 * Usage : CW.spIR_GetConditionsAndTests @pAsAtDate  = '29-JAN-2021'
 * 		,@pDealName  = 'ARDMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * A.S.			19-10-2021				Added sortorder of dealcondition for ordering in IR
 * -------------------------------------------------------
*/

CREATE PROC cw.spIR_GetConditionsAndTests
		@pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  

AS
BEGIN
SET NOCOUNT ON

BEGIN TRY

	DECLARE @dealId INT,
		@dealIpdId INT, 	
		@dealIpdRunID INT,
		@prevRunId INT;
		
	SELECT @DealId = DealId FROM cw.vw_ActiveDeal WHERE DealName=@pDealName

	SELECT @dealIPDId= DealIpdId
		FROM cw.vwDealIPDDates WHERE CollectionBusinessEnd=Cast(@pAsAtDate AS date)  AND DealId=@dealId
	
	SELECT @dealIpdRunID =DealIpdRunID, @prevRunId = prevRunId FROM cw.vwDealIpdRun WHERE DealIpdId =@dealIPDId AND IsCurrentVersion=1
		IF OBJECT_ID('tempdb..#temp') IS NOT NULL DROP TABLE #temp

	SELECT CT.DealConditionId , C.DisplayName AS Condition
	, CASE WHEN CT.ResultedStatus =1 THEN 'PASS' ELSE 'FAIL' END AS CurrentStatus
	, CT.Comment CurrentComment, CT.LoanCount AS CurrentNumber, CT.LoanAmount AS [CurrentAmount (EUR)]
	, C.ConsequencesComment CurrentConsequencesComment, CT.RepurchaseAmount AS [CurrentRepurchases (Current Balance)]
	, CT.PreviousRepurchaseDate AS Current_PreviousRepurchaseDate
	, CAST(NULL AS BIT) AS PreviousStatus
	, CAST(NULL AS varchar(500)) PreviousComment
	, CAST(NULL AS DECIMAL(38,2)) AS PreviousNumber
	, CAST(NULL AS DECIMAL(38,2)) AS [PreviousAmount (EUR)]
	, CAST(NULL AS varchar(500)) PreviousConsequencesComment
	, CAST(NULL AS DECIMAL(38,2)) AS [PreviousRepurchases (Current Balance)]
	, CAST(NULL AS Datetime) AS Previous_PreviousRepurchaseDate
	, c.SortOrder
	INTO #temp
	FROM [cfgCW].[DealCondition] C
	LEFT JOIN [CW].[DealIpdConditionTest] CT ON C.DealConditionId=CT.DealConditionId AND DealIPDRunId=@dealIpdRunID
	WHERE DealId = @dealId 
	ORDER BY c.SortOrder

	UPDATE temp
	SET PreviousStatus = CT.ResultedStatus
	,PreviousComment = CT.Comment
	,PreviousNumber = CT.LoanCount
	,[PreviousAmount (EUR)] = CT.LoanAmount
	,PreviousConsequencesComment = C.ConsequencesComment
	,[PreviousRepurchases (Current Balance)] = CT.RepurchaseAmount
	,Previous_PreviousRepurchaseDate = CT.PreviousRepurchaseDate
	FROM [cfgCW].[DealCondition] C
	JOIN [CW].[DealIpdConditionTest] CT ON C.DealConditionId=CT.DealConditionId AND DealIPDRunId=@prevRunId
	JOIN #temp temp ON CT.DealConditionId=temp.DealConditionId
	WHERE DealId = @dealId 

	SELECT Condition, CurrentStatus, CurrentComment, CurrentNumber, [CurrentAmount (EUR)]
	, CurrentConsequencesComment, [CurrentRepurchases (Current Balance)]
	, Current_PreviousRepurchaseDate
	, PreviousStatus
	, PreviousComment
	, PreviousNumber
	, [PreviousAmount (EUR)]
	, PreviousConsequencesComment
	, [PreviousRepurchases (Current Balance)]
	, Previous_PreviousRepurchaseDate
	FROM #temp
	ORDER BY SortOrder

END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spIR_GetConditionsAndTests', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
	
END

GO