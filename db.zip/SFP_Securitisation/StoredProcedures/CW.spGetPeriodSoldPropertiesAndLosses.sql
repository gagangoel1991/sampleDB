USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetPeriodSoldPropertiesAndLosses') IS NOT NULL
	DROP PROC CW.spGetPeriodSoldPropertiesAndLosses
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Property and losses Data for Investor report.
 * Usage : CW.spGetPeriodSoldPropertiesAndLosses @pAsAtDate  = '28-Feb-2020'
 * 		,@pDealName  = 'DUNMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetPeriodSoldPropertiesAndLosses @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN
				
					
BEGIN TRY

  
	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	, @mortgagedealstart DATE 
	, @intPaymentStartDate_YYYYMM INT
	, @pAsAtDate_YYYYMM INT
	, @totalSubAccounts float
	, @totalOutstandingCapitalBalance float
	, @totalTrueBalance float

	SELECT @mortgagedealstart = DealStartDate
	, @intPaymentStartDate_YYYYMM =  CONVERT(INT, CONVERT(VARCHAR(6), InterestPaymentStartDate, 112))
	 FROM sfp.[syn_SfpModel_vw_MortgageDeal_v1]
	WHERE DealName = @pDealName 

	--SET @pAsAtDate_YYYYMM = (  SELECT CONVERT(INT, CONVERT(VARCHAR(6), @pAsAtDate, 112))      )  
 --   SET @partitionID_Previous_AsAtDate = CONVERT(INT, CONVERT(VARCHAR(8), @previous_asatdate, 112))  

	------------------ Fact_Mortgage for Current Business Reporting Date ------------------------------------------------------------      
	SELECT DISTINCT Enforcementkey, MortgageSubAccountKey, TotalOutstandingCapitalBalance, TrueBalance
	INTO #Mortgage 
	FROM CW.VwMortgageSubAccount VMS  
	WHERE VMS.partitionid = @partitionID_AsAtDate  
	AND VMS.DealName = @pDealName  
	
	CREATE CLUSTERED INDEX INDXEK ON #Mortgage  (Enforcementkey);     
	
	-------------------- Fact_Mortgage for Previous Business Reporting Date ------------------------------------------------------------      
	--SELECT Distinct Enforcementkey, MortgageSubAccountKey, TotalOutstandingCapitalBalance, TrueBalance
	--INTO #PreviousMortgage 
	--FROM CW.VwMortgageSubAccount VMS  
	--WHERE VMS.partitionid = @partitionID_Previous_AsAtDate  
	--AND VMS.DealName = @pDealName  

	--CREATE CLUSTERED INDEX EK ON #PreviousMortgage  (Enforcementkey);     


--=FOR % of Total Current pool of Mortgage
	SELECT @totalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
		, @totalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0))  
		, @totalTrueBalance  = ISNULL(SUM(M.TrueBalance), 0)
	FROM   #Mortgage M
	

----=FOR % of Total Previous pool of Mortgage
--	SELECT @PreviousTotalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))  
--		, @PreviousTotalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0))  
--	FROM   #PreviousMortgage M
	
-------------------- Enforcement --------------------------------------------------------------  
	SELECT DealName, Enforcementkey, LossSeverityForFlaggedAccounts, CapitalBalanceOfFlaggedAccountsPropertySold, CalculatedShortfallForFlaggedAccounts, LossCalculatedDate, AsAtDateFrom, AsAtDateTo  
	INTO  #Enforcement 
	FROM sfp.syn_SfpModel_tbl_DimEnforcement e
	WHERE e.enforcementkey <> - 1  AND e.DealName = @pDealName  
	AND e.LossCalculatedDate <> '0001-01-01'  
	AND e.AsAtDateFrom <= @pAsAtDate AND e.AsAtDateTo > @pAsAtDate  
	
    CREATE CLUSTERED INDEX EK ON #Enforcement (Enforcementkey)  

	-----================================================================
	--------     Sold Properties    --------  
	-----================================================================
	
	SELECT 1 AS SortNo, 'Sold Properties' AS HeaderText, count(m.MortgageSubAccountKey) AS [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts > 0 THEN Cast((COUNT(m.MortgageSubAccountKey) / @totalSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END  AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(e.CapitalBalanceOfFlaggedAccountsPropertySold) AS Float) , 0) AS TotalOutCapitalBalance
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(e.CapitalBalanceOfFlaggedAccountsPropertySold) /  @totalOutstandingCapitalBalance ) *100 AS Decimal(10,2)) ELSE 0 END  AS Float) , 0) AS TotalOutCapitalBalancePercent
	, ISNULL(CAST(sum(m.TrueBalance) AS Float) , 0) AS TrueBalance
	, ISNull( Cast( CASE WHEN @totalTrueBalance > 0 THEN (sum(m.TrueBalance) /  @totalTrueBalance ) *100 ELSE 0 END AS Decimal(10,2)),0)  AS TrueBalancePercent
	
	FROM #Enforcement e  
	INNER JOIN #Mortgage m ON m.enforcementkey = e.enforcementkey  
	WHERE e.LossCalculatedDate >= @mortgagedealstart  AND e.LossCalculatedDate < @pAsAtDate  


-------================================================================
--	--------     Recoveries from Sold Properties    --------  
--	-----================================================================
	UNION ALL
	SELECT 2 AS SortNo, 'Recoveries from Sold Properties' AS HeaderText, isNull(NULL,0) AS CurrentMortgageLoans,  isNull(NULL,0), isNull(NULL,0) AS CurrentTotalOutCapitalBalance, isNull(NULL,0) AS CurrentTotalAmtinPercent, isNull(NULL,0), isNull(NULL,0)

-------================================================================
--	--------     Losses from Sold Properties    --------  
--	-----================================================================
	UNION ALL
	SELECT 3 AS SortNo, 'Losses from Sold Properties' AS HeaderText, count(m.MortgageSubAccountKey) AS [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts > 0 THEN Cast( (COUNT(m.MortgageSubAccountKey) / @totalSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent  
	, ISNULL(CAST(sum(e.CalculatedShortfallForFlaggedAccounts) * -1 AS Float) , 0) AS TotalOutCapitalBalance
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(e.CalculatedShortfallForFlaggedAccounts) /  @totalOutstandingCapitalBalance) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS TotalOutCapitalBalancePercent
	, ISNULL(CAST(sum(m.TrueBalance) * -1  AS Float) , 0) AS TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(m.TrueBalance) /  @totalTrueBalance ) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS TrueBalancePercent
	FROM #Enforcement e  
	INNER JOIN #Mortgage m ON m.enforcementkey = e.enforcementkey  
	WHERE e.LossCalculatedDate >= @mortgagedealstart  AND e.LossCalculatedDate < @pAsAtDate 
	
	

---------================================================================
----	--------     Loss Severity (% of total)    --------  
----	-----================================================================
	UNION ALL
	SELECT 4, 'Loss Severity (% of total)' AS HeaderText, count(m.MortgageSubAccountKey) AS [MortgageLoans]
	, ISNULL(CAST( CASE WHEN @totalSubAccounts > 0 THEN Cast( (COUNT(m.MortgageSubAccountKey) / @totalSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END  AS Float) , 0) AS MortgageLoansPercent  	
	, ISNULL(CAST(sum(e.LossSeverityForFlaggedAccounts * e.CapitalBalanceOfFlaggedAccountsPropertySold) * -1  AS Float) , 0)  AS TotalOutCapitalBalance
	, ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN  sum(e.LossSeverityForFlaggedAccounts * e.CapitalBalanceOfFlaggedAccountsPropertySold) /  @totalOutstandingCapitalBalance ELSE 0 END AS Float) , 0) AS TotalOutCapitalBalancePercent
	, ISNULL(CAST(sum(m.TrueBalance) * -1 AS Float) , 0) AS TrueBalance
	, ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(m.TrueBalance) /  @totalTrueBalance ) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS TrueBalancePercent
	FROM #Enforcement e  
	INNER JOIN #Mortgage m ON m.enforcementkey = e.enforcementkey  
	WHERE e.LossCalculatedDate >= @mortgagedealstart  AND e.LossCalculatedDate < @pAsAtDate  


	UNION ALL	
	SELECT 5, 'Total Net Losses as % of Original Pool Balance' AS HeaderText, isNull(NULL,0) AS CurrentMortgageLoans,  isNull(NULL,0), isNull(NULL,0) AS CurrentTotalOutCapitalBalance, isNull(NULL,0) AS CurrentTotalAmtinPercent, isNull(NULL,0), isNull(NULL,0)

END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spGetPeriodSoldPropertiesAndLosses', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END

GO
