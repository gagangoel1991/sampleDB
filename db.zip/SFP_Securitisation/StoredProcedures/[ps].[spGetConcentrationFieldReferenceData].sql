USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetConcentrationFieldReferenceData]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetConcentrationFieldReferenceData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGetConcentrationFieldReferenceData]
(
	@pFieldId INT,
	@pUserName VARCHAR(50)    
)    
AS    
BEGIN    
	BEGIN TRY    
    
		DECLARE @FieldName VARCHAR(50)  
		DECLARE @FieldRefName VARCHAR(50)      
		DECLARE @DataType VARCHAR(20)    
		
		SELECT @FieldName = ecField.CriteriaFieldName,
				@FieldRefName = ecField.ReferenceLookup,
				@DataType = fType.[Type]
				FROM [ps].[EligibilityCriteriaField] ecField
		INNER JOIN 
			[ps].[FieldDataType] fType
			ON ecField.FieldDataType = fType.FieldDataTypeId
		WHERE
			EligibilityCriteriaFieldId = @pFieldId

		-- Get Field Rule Operators
		EXEC [ps].[spGetConcentrationRuleOperators] @DataType, @pUserName

		-- Get Field Lookup Data
		IF(@DataType = 'Reference')
			EXEC [ps].[spGetFieldLookupData] 'SFP+', @FieldRefName
	END TRY                  
BEGIN CATCH                  
  DECLARE                   
   @errorMessage     NVARCHAR(MAX),                  
   @errorSeverity    INT,                  
   @errorNumber      INT,                  
   @errorLine        INT,                  
   @errorState       INT;                  
  SELECT                   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()                  
                  
    EXEC app.SaveErrorLog 2, 1, 'spGetConcentrationFieldReferenceData', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''                  
                    
  RAISERROR (@errorMessage,                  
             @errorSeverity,                  
             @errorState )                  
 END CATCH    
END
GO


