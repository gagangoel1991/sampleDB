USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetDealIrConfigList') IS NOT NULL
	DROP PROC cw.spGetDealIrConfigList
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetDealIrConfigList]
	/*
 * Author: Kapil Sharma
 * Date:	17.12.2020
 * Description:  This will return the Deal IR Config List data 
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * saurabh		6-2-2021
 * Arun		24-06-21	include workflow status
 * exec cw.spGetDealIrConfigList 'bhasaaa'
 * 
 * -----------------------
*/
 @pUserName VARCHAR(80)  ,
 @pReportTypeName VARCHAR(20) = '',
 @pAssetClassId INT = 1
AS
BEGIN
	SET NOCOUNT ON

	DECLARE @IR_Reporting_Management INT =1;
	IF(@pReportTypeName = 'Reference Registry')
	BEGIN 
	 SET @IR_Reporting_Management  = (select WorkflowTypeId from cfgcw.WorkflowType wft  WHERE wft.[Name] = 'RR_Reporting_Management');
	END
 	
	DECLARE @ReportTypeId INT;
	SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
 	SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName
 
	BEGIN TRY
		SELECT IR_Conf.DealIrConfigId
			,IR_Conf.[Name]
			,Isnull(IR_Conf.[Description], '') AS [Description]
			,Deal.DealName AS DealName
			,isnull(Template.[Name], '') AS TemplateName
			,COUNT(CASE 
					WHEN Strat.StratTypeId = '1'
						THEN 1
					ELSE NULL
					END) AS AssetStratCount
			,COUNT(CASE 
					WHEN Strat.StratTypeId = '2'
						THEN 1
					ELSE NULL
					END) AS LiabilityStratCount
			,COUNT(CASE 
					WHEN Strat.StratTypeId = '3'
						THEN 1
					ELSE NULL
					END) AS MiscStratCount
			,IR_Conf.IsLocked
			,IR_Conf.CreatedBy
			,IR_Conf.CreatedDate
			,IR_Conf.ModifiedBy
			,IR_Conf.ModifiedDate
			,ws.DisplayName AS Status
		FROM [cfgCW].[IR_DealIrConfig] IR_Conf
		JOIN [app].[vwActiveDeal] Deal ON Deal.DealId = IR_Conf.DealId
		JOIN [cfgCW].[IR_DealIrStratMap] IrStrtaMap ON IR_Conf.DealIrConfigId = IrStrtaMap.DealIrConfigId
		JOIN [cfgCW].[IR_Strat] Strat ON Strat.StratId = IrStrtaMap.StratId AND Strat.IsLocked <> 2  AND Strat.ReportTypeId = @ReportTypeId
		LEFT JOIN [cfgCW].[IR_Template] Template ON Template.TemplateId = IR_Conf.TemplateId  AND IR_Conf.ReportTypeId = Template.ReportTypeId
		LEFT JOIN cfgCW.WorkflowStep ws ON ws.WorkflowStepId = IR_Conf.WorkflowStepId and ws.WorkflowTypeId= @IR_Reporting_Management 
		WHERE IR_Conf.ReportTypeId = @ReportTypeId AND IR_Conf.AssetClassId = @pAssetClassId
		GROUP BY IR_Conf.DealIrConfigId
			,IR_Conf.[Name]
			,IR_Conf.[Description]
			,Deal.DealName
			,Template.[Name]
			,IR_Conf.IsLocked
			,IR_Conf.CreatedBy
			,IR_Conf.CreatedDate
			,IR_Conf.ModifiedBy
			,IR_Conf.ModifiedDate
			,ws.DisplayName
		ORDER BY Cast(IR_Conf.ModifiedDate AS DateTime) DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetDealIrConfigList'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO
