USE [SFP_Securitisation]
GO
/****** Object:  StoredProcedure [CW].[spGetDeflagPoolList]    Script Date: 02-04-2023 18:23:26 ******/

IF OBJECT_ID('[CW].[spGetDeflagPoolList]') IS NOT NULL
	DROP PROCEDURE [CW].[spGetDeflagPoolList]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CW].[spGetDeflagPoolList]
/*-----------------------------------------------------
 * Author: Prashant Sharma
 * Date:	20.03.2023
 * Description:  It will provide the Deflag pool List.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
-- PoolPurposeId = 3 : PoolPurpose : Repurchase
-- PoolStatusId = 6 : Status : Complete
AS
BEGIN
	BEGIN TRY
		
		 SELECT DISTINCT pcca.PoolCashCollectionAdjustmentId
			   ,d.DealName
			   ,pcca.VintageDate
			   ,(SELECT p.effectivedate from [CW].[PoolCashCollectionAdjustmentMap] pccam
		        INNER JOIN ps.pool p on p.poolid= pccam.poolid
				WHERE pcca.PoolCashCollectionAdjustmentId = pccam.PoolCashCollectionAdjustmentId GROUP BY p.effectivedate) 
				As EffectiveDate
			   ,pp.PoolPurpose 
			   ,(SELECT count(PoolCashCollectionAdjustmentId) from [CW].[PoolCashCollectionAdjustmentMap] pccam 
			    WHERE pcca.PoolCashCollectionAdjustmentId = pccam.PoolCashCollectionAdjustmentId Group By PoolCashCollectionAdjustmentId) 
				As NoOfPool
			   ,(SELECT Name As 'Brand' from [cfgCW].[DealBrand] Where DealBrandId IN (Select BrandId from cw.dailycollection Where DealId = d.DealId)) AS Brand
			   ,(SELECT SUM(CurrentPoolAmount) AS Balance from ps.pool where poolid IN (Select PoolId From [CW].[PoolCashCollectionAdjustmentMap] pccam Where 
			    pcca.PoolCashCollectionAdjustmentId = pccam.PoolCashCollectionAdjustmentId)) AS Balance
			   ,pcca.TotalPrincipalAdjustment
			   ,pcca.TotalReceiptAdjustment
			   ,pcca.AdjustmentProcessedDate
			   ,IIF(pcca.WorkFlowStatusId =104,'Processed',ws.DisplayName ) As ProcessState
			   ,wfc.Comment As Comment
			   ,pcca.CreatedBy
			   ,pcca.CreatedDate,
			   pcca.WorkFlowStatusId,
			   IIF(pcca.ModifiedDate IS NOT NULL,pcca.ModifiedDate,wfc.ActionedDate) as ModifiedDate,
			   IIF(pcca.ModifiedBy IS NOT NULL,pcca.ModifiedBy,wfc.ActionedBy) as ModifiedBy
			   FROM [CW].[PoolCashCollectionAdjustment] pcca
		       INNER Join cfg.Deal d on pcca.SourceDealId = d.DealId
		       INNER Join [ps].[PoolPurpose] pp on pp.PoolPurposeId = pcca.PoolPurposeId		       
			   LEFT  JOIN cfgcw.workflowstep ws ON ws.WorkflowStepId=pcca.WorkFlowStatusId
		       LEFT Join cfgcw.workflowType wt ON wt.WorkflowTypeid =ws.WorkflowTypeid
			   LEFT JOIN (SELECT Comment, ProcessReferenceId,ActionedDate,ActionedBy,WorkflowProcessId
						FROM [cw].[vwWorkflowProcess] 
						WHERE WorkflowProcessId in ( SELECT Max(WorkflowProcessId)
										FROM [cw].[vwWorkflowProcess] wp 
										where wp.Name='Deflag_Adjustment' group by ProcessReferenceId
										)) wfc ON Wfc.ProcessReferenceId = pcca.PoolCashCollectionAdjustmentId ORDER BY pcca.VintageDate DESC

	END TRY
	BEGIN CATCH
		--Eat the exception
	END CATCH
END
GO