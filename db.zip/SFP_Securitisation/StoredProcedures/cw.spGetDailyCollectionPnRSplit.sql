USE SFP_Securitisation

GO

IF OBJECT_ID('[cw].[spGetDailyCollectionPnRSplit]') IS NOT NULL
	DROP PROCEDURE [cw].spGetDailyCollectionPnRSplit
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Arun  
Date:    26.08.2022  
Description:  Fetch the P& R Split data for Dunmore Deal
Usage : cw.spGetDailyCollectionPnRSplit @pAsAtDate= '2022-10-28',  @pAdviceDate='2022-11-01', @pdealName= 'Dunmore1'              
Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  

CREATE PROC cw.spGetDailyCollectionPnRSplit
@pAsAtDate DateTime,
@pAdviceDate DateTime,
@pdealName varchar(255) ='DUNMORE1',
@pUserName varchar(255) = null 
as
BEGIN
	SET NOCOUNT  ON
	BEGIN TRY	
		
		Declare @CollectionValueFA float, @TotalPrincipalReceiptsFA as float, @InterestCollectionssFA as float,  @InterestValueFA float
		Declare @CollectionValueUB float, @TotalPrincipalReceiptsUB as float, @InterestCollectionssUB as float, @InterestValueUB float
		Declare @SecuritisationName varchar(100)='DUNMORE SECURITIES NO1' 
		Declare @Alias varchar(20)='Nephin' 
		Declare @OriginatorFA varchar(20) ='FA (GMS)'
		Declare @OriginatorUB varchar(20) ='UB (GMS)'
		Declare @IsEstimationDataLoaded INT =0
		Declare @dealId INT=15;

		Select * INTO #DailyCollectionLineItemValue from cw.vwDailyCollectionLineItemValue  
		where CollectionDate=@pAsAtDate and dealName = @pdealName

		Select * INTO #DailyCollectionSummaryLevelData FROM [CW].[DailyCollectionSummaryLevelData] 
		where Convert(datetime, BusinessDate, 103) = @pAsAtDate and DealName = @pdealName
		

		SELECT @IsEstimationDataLoaded = IsNull(IsEstimationData,0) From  [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId 
		


		SET @CollectionValueFA = IsNull(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem In ('Principal Receipts Adjustment (Control Break) (FA)', 'Principal Receipts Adjustment (FA)')
									and DailyCollectionCategory='Deal Summary - Adjustments'
								  )),0)
		
		IF @IsEstimationDataLoaded=1 
		BEGIN
			SET @TotalPrincipalReceiptsFA = ((Select CAST(isNull(Value,0) as decimal(38,2)) FROM #DailyCollectionLineItemValue Where LineItemInternalName='Est_Net Principal Collections_1.000'))
			SET @InterestCollectionssFA = ((Select CAST(isNull(Value,0) as decimal(38,2)) FROM #DailyCollectionLineItemValue where LineItemInternalName='Est_Revenue Collections_2.000'))
		END
		ELSE
		BEGIN
			SET @TotalPrincipalReceiptsFA = -((Select [TotalPrincipalReceipts] FROM #DailyCollectionSummaryLevelData where BrandID='FAB'))
			SET @InterestCollectionssFA = -((Select [TotalRevenueReceipts] FROM #DailyCollectionSummaryLevelData where BrandID='FAB'))
		END
				
		SET @CollectionValueUB = IsNull(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem In ('Principal Receipts Adjustment (Control Break) (UB)', 'Principal Receipts Adjustment (UB)')
									and DailyCollectionCategory='Deal Summary - Adjustments'
								  )),0)


		SET @InterestValueFA = IsNull(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem ='Revenue Receipts Adjustment (FA)'
									and DailyCollectionCategory='Deal Summary - Adjustments'
								  )),0)

		SET @InterestValueUB = IsNull(((Select SUM(ISNULL(CAST(Value as DECIMAL(38,2)),0) )
									FROM #DailyCollectionLineItemValue 
									where LineItem ='Revenue Receipts Adjustment (UB)'
									and DailyCollectionCategory='Deal Summary - Adjustments'
								  )),0)
		
		IF @IsEstimationDataLoaded=1 
		BEGIN
			SET @TotalPrincipalReceiptsUB = ((Select CAST(isNull(Value,0) as decimal(38,2)) FROM #DailyCollectionLineItemValue where LineItemInternalName='Est_Net Principal Collections_UBR_1.100'))
			SET @InterestCollectionssUB = ((Select CAST(isNull(Value,0) as decimal(38,2)) FROM #DailyCollectionLineItemValue where LineItemInternalName='Est_Revenue Collections_UBR_2.100'))
		END
		ELSE
		BEGIN
			SET @TotalPrincipalReceiptsUB = -((Select [TotalPrincipalReceipts] FROM #DailyCollectionSummaryLevelData where BrandID='UBR'))
			SET @InterestCollectionssUB = -((Select [TotalRevenueReceipts] FROM #DailyCollectionSummaryLevelData where BrandID='UBR'))
		END

		Select @pAdviceDate as AdviceDate, @pAsAtDate as CollectionDate, @SecuritisationName as [SecuritisationName], @Alias as Alias, @OriginatorFA as [Originator]
		, IsNull(@TotalPrincipalReceiptsFA,0) + IsNull(@CollectionValueFA,0) as [GrossPrincipalCollections]
		, IsNull(@TotalPrincipalReceiptsFA,0) + IsNull(@CollectionValueFA,0) as [NetPrincipalCollections]
		, IsNull(@InterestCollectionssFA,0) + IsNull(@InterestValueFA,0) as [InterestCollections]
		, CAST(0 as DECIMAL(2,2)) as [FeesCollection]
		, IsNull(@TotalPrincipalReceiptsFA,0) + IsNull(@CollectionValueFA,0) + IsNull(@InterestCollectionssFA,0) + IsNull(@InterestValueFA,0) as [TOTALCashCollections]

		UNION ALL

		Select @pAdviceDate as AdviceDate, @pAsAtDate as CollectionDate, @SecuritisationName as [SecuritisationName], @Alias as Alias, @OriginatorUB as [Originator]
		, IsNull(@TotalPrincipalReceiptsUB,0) + IsNull(@CollectionValueUB,0) as [GrossPrincipalCollections]
		, IsNull(@TotalPrincipalReceiptsUB,0) + IsNull(@CollectionValueUB,0) as [NetPrincipalCollections]
		, IsNull(@InterestCollectionssUB,0) + IsNull(@InterestValueUB,0)  as [InterestCollections]
		, 0 as [Fees Collection]
		, IsNull(@TotalPrincipalReceiptsUB,0) + IsNull(@CollectionValueUB,0) + IsNull(@InterestCollectionssUB,0) + IsNull(@InterestValueUB,0) as [TOTALCashCollections]

		UNION ALL

		Select  Null as AdviceDate, Null as CollectionDate, Null as [Securitisation Name], Null as Alias, Null as [Originator]
		, IsNull(@TotalPrincipalReceiptsUB,0) + IsNull(@CollectionValueUB,0) +  IsNull(@TotalPrincipalReceiptsFA,0) + IsNull(@CollectionValueFA,0) as [GrossPrincipalCollections]
		, IsNull(@TotalPrincipalReceiptsUB,0) + IsNull(@CollectionValueUB,0) + IsNull(@TotalPrincipalReceiptsFA,0) + IsNull(@CollectionValueFA,0) as [NetPrincipalCollections]
		, IsNull(@InterestCollectionssUB,0) + IsNull(@InterestCollectionssFA,0) + IsNull(@InterestValueFA,0) + IsNull(@InterestValueUB,0)  as [InterestCollections]
		, 0 as [FeesCollection]
		, IsNull(@TotalPrincipalReceiptsUB,0) + IsNull(@CollectionValueUB,0) + IsNull(@InterestCollectionssUB,0) + IsNull(@InterestValueUB,0) 
			+ IsNull(@TotalPrincipalReceiptsFA,0) + IsNull(@CollectionValueFA,0) + IsNull(@InterestCollectionssFA,0) + IsNull(@InterestValueFA,0) as [TOTALCashCollections]

	END TRY  
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionPnRSplit',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH  

END

GO
