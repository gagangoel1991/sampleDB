USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spWithdrawIpd]') IS NOT NULL
	DROP PROCEDURE [cb].[spWithdrawIpd]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================
--Author: Aditya Shrivastava
--Date:	23.03.2022
--Description:  Wrapper SP to insert IPD date for withdraw ipd by calling initiate and run SP

/*

DECLARE @pResultCode INT        
  exec cb.[spWithdrawIpd] 6,36,'Test Withdraw','fm/pandsbl',@pResultCode OUTPUT
  Select @pResultCode

*/
--================================== 

CREATE PROC [cb].[spWithdrawIpd]
(
	@pDealId SMALLINT,
	@pIPDRunId SMALLINT,
	@pComment	VARCHAR(1000),
	@pUserName	VARCHAR(80),
	@pResultCode INT OUTPUT 
	/*
		@pResultCode >0  : Success and it will be new run id
		@pResultCode <=0  : Fail 
		
	*/
)
AS
BEGIN
	DECLARE
		@Message			VARCHAR(4000),
		@stepCode			VARCHAR(50)= 'WITHDRAW',
		@logStatus			VARCHAR(20) = 'STARTED',
		@logDescription		VARCHAR(1000),
		@inputParams		VARCHAR(100) = 'DealId=' + CONVERT(VARCHAR(10) ,@pDealId)+'; DealIpdRunId=' + CONVERT(VARCHAR(10) ,@pIPDRunId)+ '; Comment=' + CONVERT(VARCHAR(10) ,@pComment)+ '; UserName=' + CONVERT(VARCHAR(10) ,@pUserName),
		@logExecutionId		INT, 
		@date				DATETIME = GETDATE(),
		@pNewDealIpdRunId	INT,
		@dealIpdWithdrawStatusId	SMALLINT,
		@dealIpdAuthorisedStatusId	SMALLINT,
		@currentIpdWorkFlowStatusId	SMALLINT,
		@dealIpdId			INT,
		@dealIpdDate DATE;
	
	SET NOCOUNT ON ;     

	BEGIN TRY 

		SELECT @dealIpdAuthorisedStatusId = [cw].[fnGetWorkflowStepId]('Authorise', 'Deal_Ipd')

		SELECT @currentIpdWorkFlowStatusId=WorkflowStepId FROM cw.DealIpdRun WHERE RunId= @pIPDRunId

		IF NOT EXISTS(SELECT 1 FROM cw.DealIpdRun	dir	JOIN cw.DealIpd di ON di.DealIpdId =dir.DealIpdId WHERE dealID=@pDealId AND RunId= @pIPDRunId AND IsCurrentIPD=1)
		BEGIN
			SET @Message =  'Withdraw IPD is not a current ipd'
			SET @pResultCode = -1
		END
		ELSE IF @currentIpdWorkFlowStatusId IS NOT NULL AND @currentIpdWorkFlowStatusId <> @dealIpdAuthorisedStatusId
		BEGIN
			SET @Message =  'Speciified IPD is not authorised so you cannot withdraw this IPD'
			SET @pResultCode = -2
		END
		ELSE
		BEGIN
			BEGIN TRAN

			EXEC cw.spLogExecution @pIPDRunId, @stepCode, @logStatus,@inputParams, NULL,0,NULL, @pUserName,@logExecutionId OUT
		
			SELECT @dealIpdWithdrawStatusId = [cw].[fnGetWorkflowStepId]('Withdraw', 'Deal_Ipd')

			EXEC cb.[spCopyInitIpdDataOnWithdraw] @pIPDRunId, @pUserName,@pNewDealIpdRunId=@pNewDealIpdRunId OUTPUT, @pResultCode = @pResultCode OUTPUT

			
			IF (@pResultCode =1)
			BEGIN
				SET @pResultCode = 0

				EXEC cb.[spCopyWaterfallDataOnWithdraw] @pIPDRunId,  @pNewDealIpdRunId, @pUserName, @pResultCode = @pResultCode OUTPUT
				
				IF (@pResultCode =1)
				BEGIN
				
					UPDATE cw.DealIpdRun 
						SET WorkflowStepId= @dealIpdWithdrawStatusId, ModifiedBy=@pUserName, ModifiedDate=@date
						WHERE RunId=@pIPDRunId

					INSERT INTO cw.WorkflowProcess(ProcessReferenceId,WorkflowStepId,Comment,ActionedBy,ActionedDate,CreatedDate)
					VALUES(@pIPDRunId,@dealIpdWithdrawStatusId,@pComment,@pUserName,@date,@date),
						(@pNewDealIpdRunId,@dealIpdWithdrawStatusId,@pComment,@pUserName,@date,@date)

					EXEC [cw].[spUpdateIpdSummaryLineItemStatus] @pNewDealIpdRunId, '', @pUserName
					
					SELECT @dealIpdDate=IpdDate FROM cw.vwDealIpdRun WHERE DealIpdRunId=@pNewDealIpdRunId 

					UPDATE cw.invoicedata 
						SET InvoiceStatusId= (SELECT [cw].[fnGetDealLookupValueId]('InvoiceStatus', 'Active')), ModifiedBy=@pUserName, ModifiedDate=@date
						WHERE DealId=@pDealId AND DealIpdDate=@dealIpdDate						
					
					SET @pResultCode=@pNewDealIpdRunId -- return new deal id as result code.
					
					COMMIT TRAN 

				END		
			END
			 IF @@TRANCOUNT > 0  
				ROLLBACK TRAN  

			SET @Message='SUCCESS: Withdraw Ipd data tables are filled!'
		END 
		SELECT @logStatus = IIF((@pResultCode = 1), 'SUCCESS', 'FAILED')
		SELECT @logDescription = IIF((@pResultCode = 1), @Message, 'Withdraw Init process failed due to the validation error: ' + @Message)
		EXEC cw.spLogExecution @pIPDRunId, @stepCode, @logStatus ,@inputParams, NULL, 0, @logDescription, @pUserName, @logExecutionId OUT
		
	END TRY
	BEGIN CATCH

		IF @@TRANCOUNT > 0 
		ROLLBACK TRAN 

		DECLARE 
		--	@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			 @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spWithdrawIpd', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		EXEC cw.spLogExecution @pIPDRunId, @stepCode, 'FAILED',@inputParams, @Message,0,NULL, @pUserName,@logExecutionId OUT
		SET @pResultCode = -9
		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )

		
	END CATCH

END
GO
