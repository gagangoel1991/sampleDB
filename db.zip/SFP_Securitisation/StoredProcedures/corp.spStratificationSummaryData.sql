USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[spStratificationSummaryData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [corp].[spStratificationSummaryData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Neeraj Jindal
Creation Date  : 15-Jul-2022
Description    : This will return calculated data for non-configurable strats
Execution      : EXEC [corp].[spStratificationSummaryData] @pDealId = 1 , @pAsAtDate= '2022-01-31', @pUserName='Europa\jindnaj'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spStratificationSummaryData] 	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100)   

		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats

		IF OBJECT_ID('tempdb..#StratsSummary') IS NOT NULL
		DROP TABLE #StratsSummary
		
        
		/*List of required Columns*/   
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','CommittedExposure','UtilisationGBP_SecDate','RONA','PDMidPoint','MaturityDate','DTLGD','TTCLGD') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
		PRINT 'Strats Calculation Start : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId
			  ,CommittedExposure
			  ,UtilisationGBP_SecDate AS Utilisation
			  ,RONA
			  ,PDMidPoint
			  ,MaturityDate
			  ,DTLGD
			  ,TTCLGD 
		INTO #Strats 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Calculating Non-Config Strats*/
		SELECT [Facility_count] = CONVERT(VARCHAR,COUNT(FacilityId))	 
			  ,[Pool notional pre co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),SUM(CommittedExposure)))
			  ,[Pool utilisation pre co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),SUM(Utilisation)))
			  ,[Pool notional post co-share] = CONVERT(VARCHAR,CONVERT(DECIMAL(18,2),SUM(RONA)))
			  ,[WA PD%] =IIF(SUM(RONA) = 0,'0.00', CAST( CONVERT(VARCHAR, CONVERT(DECIMAL(5,2),SUM(RONA * PDMidPoint) *100.00 /SUM(RONA))) + '%' AS VARCHAR))
			  ,[WA Life yrs] = IIF(SUM(RONA) = 0,'0.00', CONVERT(VARCHAR,CONVERT(DECIMAL(10,2),SUM(RONA * DATEDIFF(DD, @pAsAtDate, MaturityDate) / 365 ) /SUM(RONA))))
			  ,[Internal DT Loss Given Default Estimate] = IIF(SUM(RONA) = 0,'0.00', CAST(CONVERT(VARCHAR,CONVERT(DECIMAL(10,2),SUM(RONA * DTLGD) *100.00 / SUM(RONA))) + '%' AS VARCHAR))
			  ,[Internal TTC Loss Given Default Estimate] = IIF(SUM(RONA) = 0,'0.00', CAST(CONVERT(VARCHAR,CONVERT(DECIMAL(10,2),SUM(RONA * TTCLGD) *100.00 / SUM(RONA))) + '%' AS VARCHAR))
		INTO #StratsSummary
		FROM #Strats
		
		/*Showing Data Vertically DealId Wise*/
		SELECT IIF(@pDealId = 1,REPLACE(Bucket,'TTC ',''),REPLACE(Bucket,'Facility_count','Facility count')) AS [~Attributes]
			  ,Pool
		FROM  (SELECT * FROM #StratsSummary) AS x
		UNPIVOT (Pool FOR Bucket IN (
									 [Facility_count]
									,[Pool notional pre co-share]
									,[Pool utilisation pre co-share]
									,[Pool notional post co-share]
									,[WA PD%]
									,[WA Life yrs]	
									,[Internal DT Loss Given Default Estimate]									
									,[Internal TTC Loss Given Default Estimate]
									)
					) AS unpvt
		WHERE @pDealId != 1 OR (@pDealId = 1 AND Bucket != 'Internal DT Loss Given Default Estimate')
		
		/*Deleting Data from Staging table after use*/
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    
	
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationSummaryData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO
