USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetPoolDataForExport]') AND type IN (N'P', N'PC'))
DROP PROCEDURE [ps].[spGetPoolDataForExport]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- [ps].[spGetAdvanceSourcingData] 1100,  'FM\Kothpaj'
-- ps.poolbuilddetail where poolid =1100
CREATE PROCEDURE [ps].[spGetPoolDataForExport]
	@pPoolId int,
	@pReportType int,
	@pUserName VARCHAR(50)
AS
BEGIN	
	BEGIN TRY		
		DECLARE @VintageDate DATETIME;    
		DECLARE @PartitionId BIGINT;   
		
		SELECT @VintageDate = [VintageDate]     
		FROM [ps].[Pool]    
		WHERE [PoolId] = @pPoolId;    
		
		SELECT @PartitionId = CONVERT(VARCHAR, @VintageDate, 112);  
		IF OBJECT_ID('tempdb.dbo.#resultSet', 'U') IS NOT NULL                  
			DROP TABLE #resultSet;  

		SELECT          
			pb.LoanId as LoanId,       
			fmsa.BRAND_ID AS BrandId,
			DEAL_NAME AS DealName,
			@VintageDate AS VintageDate,
			pb.PoolId,
			msae.SubAccountNumber AS SubAccountId,  
			OUTSTANDNG_CAPITAL_BALANCE_AMT AS OutstandingCapitalBalance,
			TRUE_BALANCE_AMT  AS TrueBalance   
		INTO #resultSet
		FROM sfp.syn_SfpModel_vw_FactMortgageSubAccountEntity fmsa    
		INNER JOIN sfp.syn_SfpModel_vw_MortgageSubAccount msae     
			ON msae.MortgageSubAccountKey = fmsa.MortgagesubAccountKey 
		--	and mae.PartitionID_fma_Intrim = fmsa.PartitionId
		INNER JOIN  [ps].[PoolBuildDetail] pb    
			ON pb.MortgageAccountKey = fmsa.MortgageAccountKey AND pb.MortgageSubAccountKey = fmsa.MortgageSubAccountKey AND pb.IsActive = 1
		WHERE pb.PoolId = @pPoolId
			AND PartitionId = @PartitionId

		IF( @pReportType = 3 )
		BEGIN	 
			SELECT 
				LoanId, BrandId, DealName, VintageDate, PoolId, 
				SUM(OutstandingCapitalBalance) AS OutstandingCapitalBalance, SUM(TrueBalance) AS TrueBalance
			FROM #resultSet 
			GROUP BY LoanId, BrandId, DealName, VintageDate, PoolId
			ORDER BY LoanId;
			
		END
		ELSE
		BEGIN
			SELECT * FROM #resultSet
			ORDER BY LoanId, SubAccountId;
		END
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()
		

		EXEC app.SaveErrorLog 2, 1, 'spGetPoolDataForExport', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
