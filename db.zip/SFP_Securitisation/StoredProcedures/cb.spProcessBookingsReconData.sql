USE [SFP_Securitisation]

GO

IF OBJECT_ID('cb.spProcessBookingsReconData') IS NOT NULL
	DROP PROCEDURE cb.spProcessBookingsReconData
GO


/****** Object:  StoredProcedure cb.spProcessBookingsReconData    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:	12.03.2023
 * Description:  Bookings recon data
 * 				 @pCalculateDays is using to get the IPD-calcdays to get the CalculationDate 	
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
	
exec cb.spProcessBookingsReconData @pDealIpdRunId=64, @pPreviewAnalysisData='No', @pUserName ='kumavnb'
 * -------------------------------------------------------
*/  
 
CREATE PROC [cb].spProcessBookingsReconData
	@pDealIpdRunId INT, 
	@pPreviewAnalysisData varchar(10)='No',
	@pCalculateDays INT = -5,
	@pUserName  VARCHAR(20) 
AS        
BEGIN  
	
	DECLARE
		@dealId							INT,
		@dealName						VARCHAR(55),
		@dealRegion						VARCHAR(20),
		@PrevIpd						DATE,
		@NextIpd						DATE,
		@IpdDate						DateTime,
		@prevDealIpdRunId				INT,
		@pAsAtDate						DateTime,
		@ipdCollectionBusinessStart		DateTime,
		@ipdCollectionCalendarStart		DateTime

		
		BEGIN TRY  

			SELECT 	@dealId = d.DealId, @dealName = r.DealName
					, @IpdDate = CAST(d.IPD AS DATE)
					, @pAsAtDate = CAST(d.IPD AS DATE)
					, @PrevIpd = CAST(d.PreviousIPD AS DATE)
					, @NextIpd = d.NextIPD
					, @prevDealIpdRunId = r.prevRunId
					, @ipdCollectionBusinessStart = CAST(d.CollectionBusinessStart AS DATE)
					, @ipdCollectionCalendarStart = CAST(d.CollectionCalendarStart AS DATE)
				FROM cw.vwDealIpdDates d
				JOIN cw.vwDealIpdRun r			
				ON CAST(d.IPD AS DATE) = r.IpdDate
					AND d.DealIpdId =r.DealIpdId
				Where DealIpdRunId=@pDealIpdRunId

			SELECT @dealRegion = dlv.[Value], @dealId = DealId FROM cfg.Deal deal
			JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = deal.JurisdictionMarkerId
			WHERE deal.DealName = @dealName				
		
		--Select @IpdDate '@IpdDate', @PrevIpd '@PrevIpd', @prevDealIpdRunId '@prevDealIpdRunId', [cw].[fnGetBusinessDate](@IpdDate, @dealRegion, -5, 1), @dealRegion

		Select Row_Number() Over ( Order by DepositDate)as RowNum,  DepositDate, CollectionDate, MaturityDate
		, TotalCollection, SoniaRate
		, CAST(0.00 as FLOAT) as 'CalculatedMaturingCash'
		, CAST(0.00 as FLOAT) as 'CalculatedMaturingInterest'
		, Case WHEN CAST(DepositDate as DATE) <= [cw].[fnGetBusinessDate](@IpdDate, @dealRegion, @pCalculateDays, 1) THEN 'TRUE' ELSE 'FALSE' END as IpdMaturity5DayCheck
		INTO #TblAnalysis
		from cb.SFPCollectionInterest Where DepositDate>=@PrevIpd
		and DepositDate<@IpdDate
		--Order by DepositDate ASC
	

		Declare @DepositDate DATE, @MaturityDate Date, @TotalCollection Float, @SoniaRate float
		Declare @MaturingCash float = 0, @InterestAmt float =0
		Declare @NetCollection float, @depositMaturityDtDiff DECIMAL(8, 4)
		Declare @dayCountDays	DECIMAL(8, 4) = 365

		DECLARE cursorCWColDates CURSOR FOR     
			Select DepositDate, MaturityDate, TotalCollection, SoniaRate from #TblAnalysis
			OPEN cursorCWColDates    
  
			FETCH NEXT FROM cursorCWColDates INTO @DepositDate, @MaturityDate, @TotalCollection, @SoniaRate
			WHILE @@FETCH_STATUS = 0    
			BEGIN 
			
				SET @depositMaturityDtDiff = DATEDIFF(DD, @DepositDate, @MaturityDate)

				IF CAST(@PrevIpd as DATE)=CAST(@DepositDate as DATE)-- When collection date will be equal to Prev IPD date, then we need to pick the required amount 
				BEGIN
					Select  @MaturingCash = SUM(CAST(VALUE as DECIMAL(38,2))) 
					from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('New_Daily_GIC_Loan_Amount_Principal_NGL01', 'New_Daily_GIC_Loan_Amount_Interest_NGL02') 
					and DealIpdRunId=@prevDealIpdRunId
					Select @MaturingCash = @MaturingCash + ISNULL( CAST(VALUE as DECIMAL(38,2)),0)
					from [cb].[vwBookingLineItemValue] WHERE LineItemInternalName in ('Credit_Reserve_Ledger_Principal_MT03')
					and DealIpdRunId=@pDealIpdRunId

					SET @MaturingCash = @MaturingCash+@TotalCollection
					SET @NetCollection = isNull(@MaturingCash,0)
				END
				ELSE
				BEGIN
					SET @NetCollection = IsNull(@MaturingCash,0)+@InterestAmt+@TotalCollection
				END

				--Select @NetCollection, @soniaRate, @depositMaturityDtDiff, @dayCountDays
				SET @InterestAmt = (@NetCollection)*(@soniaRate/100.00)*(CAST(@depositMaturityDtDiff AS FLOAT)/@dayCountDays)

				update #TblAnalysis 
				SET CalculatedMaturingCash = @NetCollection, CalculatedMaturingInterest=@InterestAmt
				WHERE DepositDate = @DepositDate
				SET  @MaturingCash = @NetCollection

		FETCH NEXT FROM cursorCWColDates INTO @DepositDate, @MaturityDate, @TotalCollection, @SoniaRate
		END

		CLOSE cursorCWColDates;  
		DEALLOCATE cursorCWColDates; 

		IF @pPreviewAnalysisData='No'
		BEGIN
		---========================== Booking LineItem Value from expression
		IF (Select Count(*) FROM [cb].[BookingReconLineItemValue] where [DealIpdRunId] =  @pDealIpdRunId)  = 0 
		BEGIN
			Insert INTO [cb].[BookingReconLineItemValue]
			([DealIpdRunId], BookingReconLineItemId, Value, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			Select @pDealIpdRunId, vrli.BookingReconLineItemId, '0.00', @pUserName, getDate(), @pUserName, getDate()
			FROM [cfgcb].[BookingReconLineItem] vrli		
		
		END
		ELSE
			UPDATE [cb].[BookingReconLineItemValue] SET VALUE='0.00' WHERE DealIpdRunId=@pDealIpdRunId


		--=====================================================================================

		DECLARE @Value							VARCHAR(MAX),
				@CalculateValue					FLOAT,
				@CalculateTotalValue			FLOAT

		SELECT @Value = ManualFieldValue from [cb].[vwManualField] where ManualFieldInternalName='ProvisionalCashLadderPrincipalSEP' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId
		SET @CalculateTotalValue = CAST(@Value AS DECIMAL(38,18))
		UPDATE brliv SET VALUE= @Value 
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_STORM_Principal'

		SELECT @Value = ManualFieldValue from [cb].[vwManualField] where ManualFieldInternalName='ProvisionalCashLadderInterestSep' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId
		SET @CalculateTotalValue = ISNULL(@CalculateTotalValue,0) + CAST(@Value AS DECIMAL(38,18))
		UPDATE brliv SET VALUE= @Value 
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_STORM_Interest'

	
		UPDATE brliv SET VALUE= CAST(CAST(@CalculateTotalValue AS DECIMAL(38,2)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_STORM_Total'


		DECLARE @ipdMaturityDate DATE
		DECLARE @totalCollectionBeforeIpd	DECIMAL(36, 18),
				@totalInterestBeforeIpd		DECIMAL(36, 18),
				@totalReserveIntBeforeIpd	DECIMAL(36, 18),
				@totalReserveIpdMaturityDate	DECIMAL(36, 18)	

		SELECT @ipdMaturityDate = [cw].[fnGetBusinessDate](@pAsAtDate, @dealRegion, @pCalculateDays, 1)
	
		
		--Select @depositDate '@depositDate', @IpdDate '@IpdDate', @ipdMaturityDate '@ipdMaturityDate', @ipdCollectionBusinessStart '@ipdCollectionBusinessStart', @pDealIpdRunId '@pDealIpdRunId'

		SELECT @totalCollectionBeforeIpd = SUM(TotalCollection) FROM cb.SFPCollectionInterest 
		WHERE CAST(CollectionDate AS DATE)>=CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@depositDate AS DATE)

		SELECT @totalInterestBeforeIpd = SUM(InterestAmount) FROM cb.SFPCollectionInterest 
		WHERE CAST(MaturityDate AS DATE)>CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(MaturityDate AS DATE)<=CAST(@IpdDate AS DATE)

		SELECT @totalReserveIntBeforeIpd = SUM(InterestAmount) FROM cb.ReserveInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@depositDate AS DATE)

		SELECT @totalReserveIpdMaturityDate = SUM(InterestAmount) FROM cb.ReserveInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@ipdMaturityDate AS DATE)

		SELECT @Value = ISNULL(ManualFieldValue, '0.00') from [cb].[vwManualField] where ManualFieldInternalName='PriorIpdadjustment' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId

		SET @CalculateValue = @totalCollectionBeforeIpd + @totalInterestBeforeIpd + @totalReserveIntBeforeIpd + CAST(@Value as DECIMAL(38,18))
		Select @CalculateValue = ReserveFund_BF + IsNull(@CalculateValue,0) FROM Cb.vwReserveFundWf WHERE DealIpdRunId = @pDealIpdRunId
		SET @Value = CAST( CAST(@CalculateValue AS DECIMAL(38,8)) AS VARCHAR)
		UPDATE brliv SET VALUE= @Value 
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_EUDA_Total'

		Declare @CalculatedMaturingInterest  float, @CalculatedMaturingCash float
		Select @CalculatedMaturingInterest = CalculatedMaturingInterest, @CalculatedMaturingCash = CalculatedMaturingCash 
		from #TblAnalysis where CalculatedMaturingCash = ( Select MAX(CalculatedMaturingCash) FROM  #TblAnalysis)


		UPDATE brliv SET VALUE= CAST( CAST(@CalculatedMaturingCash AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_Replicated_Principal'
	
		UPDATE brliv SET VALUE= CAST( CAST(@CalculatedMaturingInterest AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_Replicated_Interest'
	
		UPDATE brliv SET VALUE= CAST(CAST(@CalculatedMaturingCash + @CalculatedMaturingInterest AS DECIMAL(38,2)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_IPD_1_Replicated_Total'

		--=====================================================================================


		SELECT @Value = ManualFieldValue from [cb].[vwManualField] where ManualFieldInternalName='ProvisionalCashLadderPrincipal' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId
		SET @CalculateTotalValue = CAST(@Value AS DECIMAL(38,18))
		UPDATE brliv SET VALUE= @Value 
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_STORM_Principal'

		SELECT @Value = ManualFieldValue from [cb].[vwManualField] where ManualFieldInternalName='ProvisionalCashLadderInterest' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId
		SET @CalculateTotalValue = @CalculateTotalValue + CAST(@Value AS DECIMAL(38,18))
		UPDATE brliv SET VALUE= @Value 
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_STORM_Interest'

	
		UPDATE brliv SET VALUE= CAST(CAST(@CalculateTotalValue AS DECIMAL(38,2)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_STORM_Total'
		

		SELECT @ipdMaturityDate = [cw].[fnGetBusinessDate](@pAsAtDate, @dealRegion, @pCalculateDays, 1)
	
	
		SELECT @totalReserveIntBeforeIpd = SUM(InterestAmount) FROM cb.ReserveInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@ipdMaturityDate AS DATE) --AND CAST(DepositDate AS DATE)<=CAST(@depositDate AS DATE)

		SELECT @totalCollectionBeforeIpd = SUM(TotalCollection) FROM cb.SFPCollectionInterest 
		WHERE CAST(CollectionDate AS DATE)>=CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@ipdMaturityDate AS DATE)

		SELECT @totalInterestBeforeIpd = SUM(InterestAmount) FROM cb.SFPCollectionInterest 
		WHERE CAST(MaturityDate AS DATE)>CAST(@ipdCollectionBusinessStart AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@ipdMaturityDate AS DATE)

		SELECT @Value = ISNULL(ManualFieldValue, '0.00') from [cb].[vwManualField] where ManualFieldInternalName='PriorIpdadjustment' and DealIpdRunId=@pDealIpdRunId and DealId=@dealId

		SET @CalculateValue = @totalCollectionBeforeIpd + @totalInterestBeforeIpd + @totalReserveIntBeforeIpd +  CAST(@Value as DECIMAL(38,18))
		Select @CalculateValue = ReserveFund_BF + IsNull(@CalculateValue,0) FROM Cb.vwReserveFundWf WHERE DealIpdRunId = @pDealIpdRunId
		SET @Value = CAST( CAST(@CalculateValue AS DECIMAL(38,8)) AS VARCHAR)
		UPDATE brliv SET VALUE= @Value 
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_EUDA_Total'
	 
		
		Select @CalculatedMaturingInterest = CalculatedMaturingInterest, @CalculatedMaturingCash = CalculatedMaturingCash 
		from #TblAnalysis where CalculatedMaturingCash = ( Select MAX(CalculatedMaturingCash) FROM  #TblAnalysis Where IpdMaturity5DayCheck='TRUE' )

		UPDATE brliv SET VALUE= CAST( CAST(@CalculatedMaturingCash AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_Replicated_Principal'
		
		UPDATE brliv SET VALUE= CAST( CAST(@CalculatedMaturingInterest AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_Replicated_Interest'

		UPDATE brliv SET VALUE= CAST(CAST(@CalculatedMaturingCash + @CalculatedMaturingInterest AS DECIMAL(38,2)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Maturing_Cash_Reconciliation_Replicated_Total'

		--==========================================================================================


	
		SELECT @totalReserveIntBeforeIpd = SUM(InterestAmount) FROM cb.ReserveInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@PrevIpd AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@depositDate AS DATE)

		SELECT @totalInterestBeforeIpd = SUM(InterestAmount) FROM cb.SFPCollectionInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@PrevIpd AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@depositDate AS DATE)

		UPDATE brliv SET VALUE= CAST( CAST(@totalReserveIntBeforeIpd + @totalInterestBeforeIpd AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='IPD_1_EUDA Collections'

		SELECT @totalReserveIntBeforeIpd = SUM(InterestAmount) FROM cb.ReserveInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@PrevIpd AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@ipdMaturityDate AS DATE)
		SELECT @totalInterestBeforeIpd = SUM(InterestAmount) FROM cb.SFPCollectionInterest 
		WHERE CAST(DepositDate AS DATE)>=CAST(@PrevIpd AS DATE) AND CAST(DepositDate AS DATE)<=CAST(@ipdMaturityDate AS DATE)

		UPDATE brliv SET VALUE= CAST( CAST(@totalReserveIntBeforeIpd + @totalInterestBeforeIpd AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Calculation_Date_EUDA Collections'

		Select @CalculatedMaturingInterest = SUM(CalculatedMaturingInterest) FROM  #TblAnalysis
		UPDATE brliv SET VALUE= CAST( CAST(@CalculatedMaturingInterest AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='IPD_1_Replicated using STORM behaviour'

		Select @CalculatedMaturingInterest = SUM(CalculatedMaturingInterest) FROM  #TblAnalysis Where IpdMaturity5DayCheck='TRUE'
		UPDATE brliv SET VALUE= CAST( CAST(@CalculatedMaturingInterest AS DECIMAL(38, 18)) AS VARCHAR)
		FROM [cb].[BookingReconLineItemValue] brliv
		INNER JOIN [cfgcb].[BookingReconLineItem] brli on brli.BookingReconLineItemId = brliv.BookingReconLineItemId
		WHERE DealIpdRunId=@pDealIpdRunId and brli.InternalName='Calculation_Date_Replicated using STORM behaviour'
	
		END
		ELSE
		BEGIN
			Select * from #TblAnalysis
		END

		DROP TABLE #TblAnalysis
	END TRY  
	BEGIN CATCH  

		
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE() + ' For Date ' + Convert(varchar(10), @pAsAtDate, 103) , @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cb.spProcessBookingsReconData',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH  

END

GO
