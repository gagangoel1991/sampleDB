USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessManualFieldsOnIpdInit]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessManualFieldsOnIpdInit]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessManualFieldsOnIpdInit] 
(
 /* 
 *   Author: Suresh Pandey 
 *   Date:  21.03.2022 
 *   Description:  Copy Manual Fields value for next IPD On initiate 

 -------------------------------------------
	Author		Date			Change
	A.S.		23.06.2022		Added expression value in Manual field calculation
								Called cb.spCalculateManualFieldOverrideSql in the last for override values
	A.S.		18.07.2022		Changed parameter from dealipdid to dealipdrunid
 *   
 *   EXEC cb.spProcessManualFieldsOnIpdInit 68,'Suresh' 
 *      
  */ 
	 @pDealIpRundId INT
	,@pUserName VARCHAR(50)
)
AS
BEGIN
	BEGIN TRY

		DECLARE @PrevRunId INT;

		SELECT @PrevRunId=prevRunId
		FROM cw.vwDealIPDrun
		WHERE DealIpdRunId = @pDealIpRundId
			 

		IF ( Object_id('tempdb..#TempManualFieldValue') IS NOT NULL ) 
			DROP TABLE #TempManualFieldValue 	
		-- If IsPrevIpdValueCF is 1 then copy Value from last IPD else use DefaultValue
		-- Newly Introduced Manual Fields will get Inserted with DefaultValue for the first time in ManualFieldValue Table
		-- Insert or Update only those Fields which are Active using last Ipd Value or DefaultValue 
			SELECT v.ManualFieldValueId
			,f.ManualFieldId
			,@pDealIpRundId AS CurrentRunId
			,IIF(f.expressionId IS NOT NULL, ISNULL(ev.Value, f.DefaultValue), IIF(f.IsPrevIpdValueCF = 1, ISNULL(v.[Value], f.DefaultValue), f.DefaultValue)) AS [Value]
			,IIF(f.expressionId IS NOT NULL, ISNULL(ev.Value, f.DefaultValue), IIF(f.IsPrevIpdValueCF = 1, ISNULL(v.[Value], f.DefaultValue), f.DefaultValue)) AS DefaultValue
			,ISNULL(v.CreatedBy, 'System') AS CreatedBy
			,ISNULL(v.CreatedDate, GETDATE()) AS CreatedDate
			,ISNULL(v.ModifiedBy, 'System') AS ModifiedBy
			,ISNULL(v.ModifiedDate, GETDATE()) AS ModifiedDate
		INTO #TempManualFieldValue
		FROM cfgcb.ManualField f
		LEFT JOIN [cb].[ManualFieldValue] v ON v.ManualFieldId = f.ManualFieldId
			AND v.DealIpdRunId = @PrevRunId
		LEFT JOIN [cw].[ExpressionValue] ev ON ev.expressionId = f.expressionId
			AND ev.DealIpdRunId = @pDealIpRundId
		WHERE 
			 f.IsActive = 1

		MERGE INTO [cb].[ManualFieldValue] t USING 
				#TempManualFieldValue  s
		ON  s.ManualFieldId=t.ManualFieldId AND s.CurrentRunId=t.DealIpdRunId
		WHEN NOT MATCHED BY TARGET 
			THEN INSERT (ManualFieldId, DealIpdRunId,[Value],[DefaultValue],CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES (s.ManualFieldId, s.CurrentRunId,s.[Value],s.CreatedBy,[DefaultValue], s.CreatedDate, s.ModifiedBy, s.ModifiedDate)
		WHEN MATCHED
			THEN UPDATE SET  
				t.[DefaultValue] = s.[DefaultValue],
				t.[Value] = s.[Value],
				t.ModifiedBy = s.ModifiedBy,
				t.ModifiedDate=s.ModifiedDate;

				--select * from #TempManualFieldValue


		--calculate overide sql for manual field
		exec cb.spCalculateManualFieldOverrideSql @pDealIpRundId,@pUserName


	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessManualFieldsOnIpdInit', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
				@errorSeverity,
				@errorState )
	END CATCH


END

GO