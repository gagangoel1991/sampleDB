USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spLoadAllocatedLoss]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spLoadAllocatedLoss]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 05-Oct-2022
Description    : This will return allocated loss for a particular LossManagementId
Execution      : EXEC [corp].[spLoadAllocatedLoss] '12', 'Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spLoadAllocatedLoss]
	@pLossManagementId INT,
	@pUserName VARCHAR(100),
	@pAllocatedLoss DECIMAL(19, 6) OUTPUT
AS
BEGIN
	BEGIN TRY
		DECLARE @ReqCols XML 
		DECLARE @RowID VARCHAR (100)
		DECLARE @MGS27DefaultDate DATE = (SELECT MGS27DefaultDate FROM [corp].[LossManagement] WHERE LossManagementId = @pLossManagementId)
		DECLARE @FacilityId VARCHAR (50) = (SELECT FacilityId FROM [corp].[LossManagement] WHERE LossManagementId = @pLossManagementId)
		DECLARE @DealId INT = (SELECT DealId FROM [corp].[LossManagement] WHERE LossManagementId = @pLossManagementId)
		DECLARE @CorpDealId INT
		IF (SELECT TOP (1) AllocatedLosses FROM [corp].[LossManagement] WHERE LossManagementId = @pLossManagementId) IS NOT NULL
		BEGIN
			SELECT @pAllocatedLoss = AllocatedLosses FROM [corp].[LossManagement] WHERE LossManagementId = @pLossManagementId
			RETURN @pAllocatedLoss
		END
		/* CONVERT REQUIRED COLUMN NAMES TO XML FORMAT */
		SELECT @ReqCols = (SELECT CriteriaFieldName
							FROM (VALUES ('UtilisationGBP_ReportingDate')) Field(CriteriaFieldName)
							FOR XML PATH('Node'), ROOT('Root'))


		SET @CorpDealId = (SELECT [DealId]
								FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1]
							WHERE [IsActive] = 'Y' AND [DealName] = (SELECT Top(1) DealName FROM cfg.Deal WHERE DealId = @DealId))

		/* EXECUTE COMMON SP TO FETCH THE DATA  */
		PRINT 'Common SP Execution Started (Month Before Default Date): ' + CONVERT(VARCHAR(20), GETDATE())

		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
				@VintageDate = @MGS27DefaultDate,
				@DealKey	 = @CorpDealId,
				@FacilityIds = @FacilityId,
				@ReqColumns	 = @ReqCols,
				@OutputRowID = @RowID OUTPUT

		PRINT 'Common SP Execution Ended (Month Before Default Date): ' + CONVERT(VARCHAR(20), GETDATE())

		/* INSERT DATA INTO #PreviousMonthData FROM STAGING TABLE  */
		SET @pAllocatedLoss = (SELECT TOP(1) 
										UtilisationGBP_ReportingDate AS [AllocatedLoss]
								FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID)
		
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
		
		UPDATE [corp].[LossManagement] 
		SET AllocatedLosses = @pAllocatedLoss,
			IsAllocatedLossLoaded = 1
		WHERE LossManagementId = @pLossManagementId

		RETURN @pAllocatedLoss

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spLoadAllocatedLoss',
			@errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
