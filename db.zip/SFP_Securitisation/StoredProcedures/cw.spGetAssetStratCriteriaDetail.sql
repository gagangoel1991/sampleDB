USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetAssetStratCriteriaDetail') IS NOT NULL
	DROP PROC  cw.spGetAssetStratCriteriaDetail
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
cw.spGetAssetStratCriteriaDetail 1
*/
CREATE PROC cw.spGetAssetStratCriteriaDetail
	@pStratId int
	, @pUserName varchar(100) = NULL
AS  
BEGIN  
  
  
 BEGIN TRY  
	
	SELECT  AssetStratCriteriaId AS StratConfigId, StratId, FromOperatorId, FromValue, ToOperatorId, ToValue,
	SortOrder, SC.CreatedBy, SC.CreatedDate, SC.ModifiedBy, SC.ModifiedDate
	FROM [cfgCW].IR_AssetStratCriteria SC
	INNER JOIN [cfgCW].IR_AssetStrat SM ON SM.AssetStratId=SC.AssetStratFieldMapId
	WHERE StratId=@pStratId --and IsActive=1
	ORDER BY SortOrder
  
 END TRY  
  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2, 1, 'spGetAssetStratCriteriaDetail', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
  
END  
GO
