USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessSwapCollateralFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessSwapCollateralFund]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessSwapCollateralFund] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  03.02.2022
 *   Description:  Fill SwapCollateralFund CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessSwapCollateralFund] 33,'fm\shriyad'
 *    select * from [Cb].[SwapCollateralFund] where dealipdrunid=33           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=33, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @dealId  INT, 
				  @ipdDate DATE,
				  @swapCollateralFund_bF decimal(38,16),
				  @swapCollateralAmountReceived decimal(38,16),
				  @swapCollateralExcludedAmount decimal(38,16)
				  
          SELECT @dealId = DealId, 
				@ipdDate = IpdDate
          FROM   cw.vwDealIpdRun dir
          WHERE  DealIpdRunId = @pDealIpdRunId 
		  

		  DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

          IF Object_id('tempdb..#SwapCollateralFund') IS NOT NULL 
            DROP TABLE #SwapCollateralFund

          CREATE TABLE #SwapCollateralFund
            ( 
				[DealIpdRunId] [int] NULL,
				[CoveredBondFundId] [smallint] NULL,
				[SwapCollateralAmountReceived] [decimal](38, 16) NULL,
				[SwapCollateralFund_bF] [decimal](38, 16) NULL,
				[SwapCollateralExcludedAmount] [decimal](38, 16) NULL,
				[ReleaseToARR] [decimal](38, 16) NULL,
				[SwapCollateral_cf] [decimal](38, 16) NULL
            ) 

				SELECT @swapCollateralFund_bF = SwapCollateral_cf
				FROM cb.SwapCollateralFund scf
					JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
					AND  cbf.InternalName = 'SwapCollateralFund'
				WHERE DealIpdRUnId = @dealPreviousIpdRunId

				
				SET @swapCollateralAmountReceived=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
												WHERE ManualFieldInternalName  
														IN ('AssetSwapCollateralGBP'
														,'CoveredBondSwapCollateralGBP')
												AND ManualFieldGroupInternalName = 'SwapCollateral'
												AND DealIpdRunId = @pDealIpdRunId);

				SET @swapCollateralExcludedAmount=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
												WHERE ManualFieldInternalName  =  'SwapCollateralExcludedAmount'
												AND ManualFieldGroupInternalName = 'SwapCollateral'
												AND DealIpdRunId = @pDealIpdRunId);

                INSERT INTO #SwapCollateralFund 
                            (
						DealIpdRunId
						,CoveredBondFundId
						,SwapCollateralAmountReceived
						,SwapCollateralFund_bF
						,SwapCollateralExcludedAmount
						,ReleaseToARR
						,SwapCollateral_cf
							) 
                 SELECT @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,COALESCE(@swapCollateralAmountReceived,0) SwapCollateralAmountReceived
						,COALESCE(@swapCollateralFund_bF,0) SwapCollateralFund_bF
						,COALESCE(@swapCollateralExcludedAmount,0) SwapCollateralExcludedAmount
						,NULL ReleaseToARR
						,NULL SwapCollateral_cf 
                FROM	cfgcb.CoveredBondFund cbf
                WHERE  cbf.InternalName = 'SwapCollateralFund' 


                UPDATE #SwapCollateralFund 
                SET		ReleaseToARR = SwapCollateralFund_bF - SwapCollateralExcludedAmount

				 UPDATE #SwapCollateralFund 
                SET		SwapCollateral_cf = SwapCollateralAmountReceived + SwapCollateralFund_bF - SwapCollateralExcludedAmount - ReleaseToARR

			--select * from #SwapCollateralFund

          DELETE FROM [Cb].[SwapCollateralFund] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[SwapCollateralFund] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,SwapCollateralAmountReceived
						,SwapCollateralFund_bF
						,SwapCollateralExcludedAmount
						,ReleaseToARR
						,SwapCollateral_cf
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
					SELECT DealIpdRunId
						,CoveredBondFundId
						,SwapCollateralAmountReceived
						,SwapCollateralFund_bF
						,SwapCollateralExcludedAmount
						,ReleaseToARR
						,SwapCollateral_cf
						 ,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM   #SwapCollateralFund 

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessSwapCollateralFund', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO