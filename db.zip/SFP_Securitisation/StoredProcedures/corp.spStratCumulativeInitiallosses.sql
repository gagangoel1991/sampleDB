USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spStratCumulativeInitiallosses]') AND type in (N'P',N'PC'))
   DROP PROCEDURE [corp].[spStratCumulativeInitiallosses]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

------------------------------------------------------------------------------------------------------  
  
  --Author: Mukesh Sharma
  --Date: 2023-01-27
  --Description:  Generating Strats for Cumulative Initial losses
  --Note- pAsAtDate parameter is not required in this Strat but adding it to make compatible with strats framework
  --exec  [corp].[spStratCumulativeInitiallosses] @pAsAtDate=NULL, @pDealId=1,@pUserName=null
--------------------------------------------------------------------------------------------------------------  
CREATE PROCEDURE [corp].[spStratCumulativeInitiallosses]
(    @pAsAtDate DATE ,
	 @pDealId INT ,
	 @pUserName VARCHAR(100)=NULL
)
AS
BEGIN
            
            DECLARE 
			 @RowID VARCHAR(100)
            ,@msgtxt VARCHAR(100) = ''
			,@DealIdS INT
			,@DealName Varchar(50)
		    ,@DealIdCommonSP INT

    BEGIN TRY
    SET @msgtxt = 'Calculating variables  ' + CONVERT(VARCHAR(20), getdate(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	SET @DealIdCommonSP                    = @pDealId
	SET @DealName                          =(SELECT DealName from[corp].[syn_SfpModelCorporate_vw_dimCorporateDeal]		
											 WHERE DealId=@pDealId  AND IsActive='Y')
	SET @DealIdS                           =(SELECT DealId FROM [cfg].[Deal] WHERE DealName = @DealName)

   -- Storing aggregated data from loss managment into temp dataset
	
	SELECT CreditEventTypeId
	,COUNT(facilityid) AS [Loan Volume]
	,CONVERT(DECIMAL(23,2),SUM( CurrentExposure)) AS Exposure
	,CONVERT(DECIMAL(23,2),SUM(InitialLossAmount)) AS [InitialLossAmount]  
	INTO #Templossdata  
	FROM [corp].[LossManagement]
	WHERE dealid=@DealIdS 
	AND IsActive=1 AND WorkflowStepId IN(90, 93, 94, 96,97)
	GROUP BY CreditEventTypeId

	--- joining with report lookup table to show all CreditEventTypeId description as these are fixed in template
	SELECT LK.Reportvalue AS [Credit event]
	,loss.[Loan Volume] AS [Loan Volume]
	,loss.Exposure AS Exposure
	,loss.[InitialLossAmount] AS [Initial Loss Amount]  
	FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  AS LK
	LEFT JOIN  #Templossdata AS Loss
	ON LK.LookUpvalue=Loss.CreditEventTypeId
	WHERE LK.ReportTemplateName='SFP+' and LK.LookUpName like 'CB Credit Event Type%'
	ORDER BY LK.Reportvalue

         /* Droping and creating temp tables */
  	IF OBJECT_ID('tempdb..#Templossdata') IS NOT NULL DROP TABLE #Templossdata
	
    


	SET @msgtxt = 'End of strats generation : ' + CONVERT(VARCHAR(20), GETDATE(), 121)
    RAISERROR(@msgtxt, 10, 1) WITH NOWAIT

	 END TRY
     BEGIN CATCH                  
     DECLARE       
	 @errorMessage     NVARCHAR(MAX),      
	 @errorSeverity    INT,      
	 @errorNumber      INT,      
	 @errorLine        INT,      
     @errorState       INT;      
     SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()     
     EXEC app.SaveErrorLog 2, 1, 'spStratCumulativeInitiallosses', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName   
     RAISERROR (@errorMessage,  @errorSeverity,  @errorState )              
     END CATCH   

  END
GO


