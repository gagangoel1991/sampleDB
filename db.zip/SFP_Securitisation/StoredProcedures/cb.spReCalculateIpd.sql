USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spReCalculateIpd') IS NOT NULL
	DROP PROCEDURE cb.spReCalculateIpd
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [Cb].[spReCalculateIpd]
(
	@pDealIpdRunId SMALLINT,
	@pUserName	VARCHAR(80),
	@pResultCode INT OUTPUT 
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  
 *   Description:  Re-Calculate IPD. 
 *   NOTE: THIS MUST BE SAME AS INITIATE IPD. ANY CHANGE IN INITIATE MUST BE ANALYSED HERE AS WELL.
 *        
 *   Change History 
 *   -------------- 
 *   Code		Author    Date			Description 
 *   @101		AS		21-05-2022		value of ARR total was diff in expressionValue and in waterfallLineItemAmount after invoice was added. Called block of code again to see the changes in waterfallLineItemAmount  after expression re-calculation
 *   ------------------------------------------------------- 
 *    
 *   DECLARE @pResultCode INT         
 *   exec cb.spReCalculateIpd	36,'fm\shriyad',@pResultCode OUTPUT
 *   Select @pResultCode
 *              
  */ 
)
AS
BEGIN
	
	DECLARE
		@Message		VARCHAR(4000),
		@stepCode		VARCHAR(50)= 'RECALCULATEIPD',
		@logStatus		VARCHAR(20) = 'STARTED',
		@logDescription	VARCHAR(1000),
		@inputParams	VARCHAR(100) = 'DealIpdRunId=' + CONVERT(VARCHAR(10) ,@pDealIpdRunId),
		@logExecutionId INT 
		, @date				DATETIME = GETDATE()
		,	@dealIpdRunStatusId	SMALLINT
		, @DealId SmallInt
	
	SET NOCOUNT ON

	BEGIN TRY
		BEGIN TRAN

			SELECT @DealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunid = @DealId


		    EXEC  [Cb].[spProcessDealNote] @pDealIpdRunId,@pUserName
			
			EXEC  [Cb].[spProcessDealSwap] @pDealIpdRunId,@pUserName
			
			EXEC  [Cb].[spProcessNoteSwap] @pDealIpdRunId,@pUserName
			
			EXEC [cb].[spRunPreMaturityTest] @pDealIpdRunId,@pUserName
	        
			EXEC  [Cb].[spProcessPreMaturityLiquidity_PreWF] @pDealIpdRunId,@pUserName
			
			EXEC  [Cb].[spProcessCouponPaymentFund_PreWf] @pDealIpdRunId,@pUserName
			
			EXEC  [Cb].[spProcessSwapCollateralFund] @pDealIpdRunId,@pUserName

			--EXEC [cw].[spProcessTriggersOnIpdInit] @pDealIpdRunId,@pUserName

			EXEC [CW].[spProcessInterimWaterfallFee] @pDealIpdRunId,@pUserName

			EXEC [cw].[spCalculateExpression] @pDealIpdRunId,@pUserName

			EXEC  cw.spProcessDealConfigValue @pDealIpdRunId, @pUserName

			EXEC [cw].[spProcessWaterfallLineItemAmount] @pDealIpdRunId,@pUserName

			EXEC [cw].[spCalculateCWOverrideSql] @pDealIpdRunId, @pUserName

			EXEC [Cb].[spProcessReserveFund_PreWF] @pDealIpdRunId,@pUserName

			EXEC  [cw].[spCalculateExpression] @pDealIpdRunId,@pUserName

			EXEC [cw].[spProcessWaterfallLineItemAmount] @pDealIpdRunId,@pUserName

			EXEC  cw.spCalculateCWOverrideSql @pDealIpdRunId, @pUserName
			--@101 START
			EXEC  [cw].[spCalculateExpression] @pDealIpdRunId,@pUserName

			EXEC [cw].[spProcessWaterfallLineItemAmount] @pDealIpdRunId,@pUserName

			EXEC  cw.spCalculateCWOverrideSql @pDealIpdRunId, @pUserName
			--@101 END

			EXEC  [cb].[spRunAllTest] @pDealIpdRunId, @pUserName

			EXEC  [Cb].[spProcessRevenueLedgerFund] @pDealIpdRunId,@pUserName

			EXEC  [cb].[spProcessPaymentLedgerFund] @pDealIpdRunId,@pUserName

			EXEC  [cb].[spProcessMaturingProceedsLoanFund] @pDealIpdRunId,@pUserName

			EXEC  [cb].[spProcessPrincipalLedgerFund] @pDealIpdRunId,@pUserName

			EXEC  [cb].[spProcessCapitalAccountLedger] @pDealIpdRunId,@pUserName
			
			EXEC  [cw].[spCalculateExpression] @pDealIpdRunId,@pUserName

			EXEC  cb.spProcessBookingsIPDData @pDealIpdRunId,@pUserName

			COMMIT TRAN 

			SET @pResultCode = 1

			SET @Message='SUCCESS: Re-calculate Ipd is successful!'
	END TRY
	BEGIN CATCH
		
		ROLLBACK TRAN 

		DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			 @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spInitiateIpd', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		SET @pResultCode = 0
		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )

		
	END CATCH

	SELECT @Message
END

GO