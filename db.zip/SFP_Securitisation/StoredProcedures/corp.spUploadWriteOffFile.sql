USE [SFP_Securitisation]
GO

IF EXISTS 
(
	SELECT 1 FROM sys.objects
	WHERE object_id = OBJECT_ID(N'[corp].[spUploadWriteOffFile]')
		AND type IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spUploadWriteOffFile]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 05-Oct-2022
Description    : This SP is used to upload write off file
Execution      : EXEC [corp].[spUploadWriteOffFile] @pWriteOffItems, 'Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spUploadWriteOffFile]
	@pWriteOffItems AS corp.WriteOffItem READONLY,
	@pUserName VARCHAR(50)
AS
BEGIN

	BEGIN TRY		

		DECLARE @CurrentDate DATETIME = GETDATE()
		DECLARE @Active BIT = 1
		DECLARE @InActive BIT = 0

		BEGIN TRANSACTION CORP_UploadWriteOffData

		/* DEACTIVATING EXISTING WRITE-OFF RECORDS */

		UPDATE [corp].[WriteOffData]
		SET [IsActive] = @InActive,
			[ModifiedBy] = @pUserName, 
			[ModifiedDate] = @CurrentDate
		WHERE [IsActive ]= @Active


		/* INSERTING NEW WRITE-OFF RECORDS */

		INSERT INTO [corp].[WriteOffData]
				([Month]
				,[Year]
				,[Description]
				,[FacilityId]
				,[CisCode]
				,[CC]
				,[CCY]
				,[Amount]
				,[AssessmentType]
				,[Comments]
				,[IsActive]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate])
			SELECT
				[Month]
				,[Year]
				,[Description]
				,[FacilityId]
				,[CisCode]
				,[CC]
				,[CCY]
				,[Amount]
				,[AssessmentType]
				,[Comments]
				,@Active
				,@pUserName
				,@CurrentDate
				,@pUserName
				,@CurrentDate
			FROM @pWriteOffItems

		COMMIT TRANSACTION CORP_UploadWriteOffData

	END TRY
	BEGIN CATCH

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION CORP_UploadWriteOffData
		END

		EXEC app.SaveErrorLog 2, 1, 'spUploadWriteOffFile',
			@errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;

END
GO
