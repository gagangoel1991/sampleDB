USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spIR_GetNonRatingTriggers]') IS NOT NULL
	DROP PROCEDURE [cw].spIR_GetNonRatingTriggers 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
--==================================    
--Author: Kapil Sharma  
--Date: 01-06-2021   
--Description: This will return the non-rating triggers detail for IR  
--[cw].[spIR_GetNonRatingTriggers]  '2021-08-31', 'DUNMORE1'  
--GO
--[cw].[spIR_GetNonRatingTriggers]  '2021-05-28', 'DEIMOS'  

--==================================    
CREATE PROCEDURE [CW].[spIR_GetNonRatingTriggers]   
(  
 @pAsAtDate datetime,   
 @pDealName  varchar(200)  
)      
AS    
BEGIN    
    
	BEGIN TRY    
		DECLARE   
			@dealIpdRunId		INT,  
			@dealId				SMALLINT,  
			@ipdDate			DATETIME,  
			@dealIpdRunVersion	SMALLINT   
  
		SELECT   
			@dealIpdRunId = dir.DealIpdRunId  
			, @dealId = dir.DealId  
			, @ipdDate = ipddate  
			, @dealIpdRunVersion = DealIpdRunVersion  
		FROM     
			cw.vwDealIpdDates dt  
		JOIN  
			cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId   
			AND dir.DealId = dt.DealId  
		WHERE   
			dir.InternalDealName = @pDealName  
			AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)   

		SELECT t.[Event],t.[Summary of Event],t.[Trigger Breached (Yes/No)],t.[Consequence of a Trigger Breach] FROM
		(
			SELECT   
				tt.DisplayName AS [Event],  
				tt.TriggerSummary AS [Summary of Event],  
				CASE WHEN tt.InternalName IN ( 'AmortisationTest','PreMaturityTest','YieldShortfallTest') THEN 'N/A' ELSE 'NO' END AS [Trigger Breached (Yes/No)],   
				tt.Consequences AS [Consequence of a Trigger Breach] ,
				tt.InternalName
			FROM   
				cfgcb.TestType tt
			WHERE tt.Consequences IS NOT NULL AND @pDealName='DEIMOS'
			UNION
			SELECT   
				t.DisplayName AS [Event],  
				t.TriggerSummary AS [Summary of Event],  
				CASE WHEN tr.IsBreached = 1 THEN 'YES' ELSE 'NO' END AS [Trigger Breached (Yes/No)],   
				t.Consequences AS [Consequence of a Trigger Breach] ,
				t.InternalName
			FROM   
				cw.DealIpdTriggerResult tr   
			JOIN   
				cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId  
			JOIN   
				cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId  
			JOIN   
				cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId AND t.DealId = tm.DealId
			JOIN   
				cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId  
			WHERE    
				tr.DealIpdRunId=@dealIpdRunId AND tm.DealId=@dealId AND tt.TriggerTypeId=2
		)t
		ORDER BY
		CASE
				WHEN InternalName='AssetCoverageTest' THEN 1
				WHEN InternalName='InterestRateShortfallTest' THEN 2
				WHEN InternalName='AmortisationTest' THEN 3	
				WHEN InternalName='PreMaturityTest' THEN 4
				WHEN InternalName='YieldShortfallTest' THEN 5
				WHEN InternalName='LLPEventofDefault' THEN 6	
				WHEN InternalName='IssuerEventofDefault' THEN 7
			 				
		END ASC
   
	END TRY    
	BEGIN CATCH    
		DECLARE     
		   @errorMessage     NVARCHAR(MAX),    
		   @errorSeverity    INT,    
		   @errorNumber      INT,    
		   @errorLine        INT,    
		   @errorState       INT;    
    
		SELECT     
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()    
    
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetNonRatingTriggers', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, 'System'    
      
		RAISERROR (@errorMessage,    
			@errorSeverity,    
			@errorState )    
	END CATCH    
END
GO