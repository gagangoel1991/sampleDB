USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetInvoice]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetInvoice]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetInvoice]
	/*
 * Author: Kapil Sharma
 * Date:	15.07.2021
 * Description:  This will return the single invoice record data
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
	@pInvoiceId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		SELECT invoice.Name
			,invoice.InvoiceId
			,deal.DealId
			,deal.DealName
			,ICT.InvoiceCategoryTypeId
			,ICT.Name AS InvoiceCategoryType
			,IC.InvoiceCategoryId
			,IC.Name AS InvoiceCategory
			,dcp.CounterpartyName
			,dcp.DealCounterpartyId
			,invoice.Description
			,CAST(invoice.Amount AS DECIMAL(38, 4)) Amount
			,invoice.PaidDate
			,invoice.DealIpdDate
			,invoice.UploadedFileName
			,invoice.OriginalFileName
			,invoice.ReferenceNumber AS ReferenceNumber
			,invoice.SourceSpotRate
			,invoice.SpotRate
			,invoice.InvoiceDate
			,CAST(invoice.InvoicePaidAmount AS DECIMAL(38, 4)) AS InvoicePaidAmount
			,invoice.InvoiceCurrencyId
			,invoice.InvoiceStatusId
			,invoice.SpotRateDate
			,invoice.ModifiedBy
			,invoice.ModifiedDate
			,c.Code AS DealCurrency
			,dlv.DisplayText AS STATUS
		FROM [CW].[InvoiceData] invoice
		JOIN [cfgCW].[InvoiceCategory] IC ON IC.InvoiceCategoryId = invoice.InvoiceCategoryId
		JOIN [cfgCW].[InvoiceCategoryType] ICT ON IC.InvoiceCategoryTypeId = ICT.InvoiceCategoryTypeId
		JOIN [cw].[vw_ActiveDeal] deal ON invoice.DealId = deal.DealId
		JOIN [cw].[vw_ActiveDealCounterparty] dcp ON dcp.DealCounterpartyId = invoice.DealCounterpartyId
		JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = invoice.InvoiceStatusId
		JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
		JOIN cfgCw.Currency c ON deal.DealCurrencyId = c.CurrencyId
		WHERE invoice.InvoiceId = @pInvoiceId
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetInvoice'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


