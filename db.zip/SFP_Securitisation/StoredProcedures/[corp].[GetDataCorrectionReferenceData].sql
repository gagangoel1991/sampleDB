USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[GetDataCorrectionReferenceData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [corp].[GetDataCorrectionReferenceData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[GetDataCorrectionReferenceData]
(
	@pUserName VARCHAR(20)  	
)
AS
BEGIN
	BEGIN TRY
		-- Get Deals
		DECLARE @SRTDealTypeId INT = (SELECT v.LookupValueId FROM [cfgCW].[DealLookupValue] v
										INNER JOIN cfgCW.DealLookupType t 
											ON v.LookupTypeId=t.LookupTypeId
										WHERE t.TypeCode='DealType' AND v.Name ='SRT')
		SELECT 
			[corpDeal].[DealId],
			[corpDeal].[DealName],
			[corpDeal].[Description],
			[corpDeal].[DealQuaterMonth],
			[corpDeal].[DealMaturityDate]     
		FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] corpDeal
		INNER JOIN cfg.Deal SecDeal ON SecDeal.DealName = corpDeal.DealName
		WHERE [corpDeal].[IsActive] = 'Y' AND [SecDeal].[DealTypeId] = @SRTDealTypeId  AND [SecDeal].[IsActive] = 1
	
		-- Entity
		SELECT 
			DealDataCorrectionEntityId AS EntityId,
			EntityName
		FROM [corp].[DealDataCorrectionEntity]
		WHERE IsActive = 1
	END TRY	
	BEGIN CATCH	                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'GetDataCorrectionReferenceData', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                    
                      
		RAISERROR (@errorMessage, @errorSeverity, @errorState)
	END CATCH
END
GO