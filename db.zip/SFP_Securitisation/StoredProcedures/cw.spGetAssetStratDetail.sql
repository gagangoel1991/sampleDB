USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetAssetStratDetail') IS NOT NULL
	DROP PROC  cw.spGetAssetStratDetail
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
cw.spGetAssetStratDetail @pStratType=1, @pStratId = Null
cw.spGetAssetStratDetail @pStratType=2, @pStratId = Null
*/

CREATE PROC cw.spGetAssetStratDetail
	@pStratId int = NULL
	, @pStratType int = 2
	, @pUserName varchar(100) = null
	, @pReportTypeName VARCHAR(20) = ''
	, @pAssetClassId INT = 1
As  
BEGIN  
 
 BEGIN TRY  

	DECLARE @assetStratTypeId int=1;
	
	DECLARE @ReportTypeId INT;
	SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
	SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 
	
	Select  M.BespokeStratId as FieldId, Name as FieldName, FieldDataTypeLookupId 
	into #TBL FROM cfgCW.IR_BeSpokeStrat M  where IsActive=1 and @pStratType=1 
	AND M.ReportTypeId = @ReportTypeId AND (isNull(@pStratId,0) > 0 OR M.AssetClassId = @pAssetClassId)
	Union ALL  
	Select M.AssetFieldId as FieldId, FieldDescription as FieldName, FieldDataType  
	FROM cfgCW.IR_AssetField  M where @pStratType=2  
	
	/*
		--Deal Type List as string  
	*/	
	SELECT sd.StratId , DL.Name INTO #TblDealType
	FROM cfgCW.IR_StratDealTypeMap sd
	INNER JOIN cw.vw_DealLookup DL ON sd.StratDealTypeId = dl.LookupValueId
	
										
	
	SELECT  Results.StratId,   STUFF((   SELECT ', ' + [Name] 
										 FROM #TblDealType sd
										 WHERE (sd.StratId = Results.StratId)  ORDER BY [Name]
    FOR XML PATH(''),TYPE).value('(./text())[1]','VARCHAR(MAX)') ,1,2,'') AS DealTypeNames
    INTO #DealType
	FROM #TblDealType Results
	GROUP BY Results.StratId
	


		
	SELECT  I.StratId, M.FieldId, I.Name, isNull(I.Description, '') AS Description, I.IsLocked
	, I.CreatedBy, Cast(I.CreatedDate AS date) CreatedDate, I.ModifiedBy, Cast(I.ModifiedDate AS Date) ModifiedDate
	, CASE WHEN M.FieldDataTypeLookupId=34 THEN 'NUMERIC' ELSE 'TEXT' END AS StratDataType, M.FieldName
	, CASE WHEN I.IsLocked =1 THEN 'Locked' ELSE 'Active' END AS StratStatus
	, DT.DealTypeNames
	FROM [cfgCW].[IR_Strat] I
 	INNER JOIN cfgCW.IR_AssetStrat SM ON SM.StratId=I.StratId AND SM.ReportTypeId = I.ReportTypeId
 	INNER JOIN #TBL M ON M.FieldId = CASE WHEN  @pStratType=1 THEN SM.BespokeStratId ELSE SM.FieldId END  
	LEFT JOIN cw.vw_DealLookup DL ON DL.LookupValueId = SM.FieldTypeLookupId
	LEFT JOIN #DealType DT ON DT.StratId= I.StratID
	WHERE 
	I.ReportTypeId = @ReportTypeId
	and I.StratId=isNull(@pStratId, I.StratId)  
	and I.StratTypeId=@assetStratTypeId
	and I.IsLocked in ( 0, 1)
	AND ( isNull(@pStratId,0) > 0 OR I.AssetClassId = @pAssetClassId )
	Order by Cast(I.ModifiedDate as DateTime) Desc
  
 END TRY  
  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2, 1, 'spGetAssetStratDetail', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
  
END  

GO

