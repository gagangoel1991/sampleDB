USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spProcessDealProductData]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessDealProductData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spProcessDealProductData]
/*
Author: Kapil Sharma
Date:	21.02.2022
Description:  This will load the deal product data on a monthly basis
				
Change History
--------------
Author		Date		Description

Usages:
[cb].[spProcessDealProductData] 1, '2022-06-01'
-------------------------------------------------------
*/
(  
	@pFeedRunLogId		INT,  
	@pAsAtDate			DATETIME  
)  
AS  
BEGIN   

	DECLARE   
		@createdDate					DATETIME = GETDATE(),  
		@createdBy						VARCHAR(100) = 'System',  
        @dealName						VARCHAR(100),  
        @mortgageDealId					INT,  
		@dealId							INT,  
		@productName					VARCHAR(100),
		@monthToBeProcessed				DATETIME,  
		@toCollectionDate				DATETIME,  
		@partitionId					INT,  
		@vintageDate					DATE,
		@dealRegionCode					VARCHAR(10)
		
   BEGIN TRY
		SELECT @dealId = DealId, @mortgageDealId = MortgageDealId, @dealRegionCode = DealRegionCode FROM cw.vw_ActiveDeal WHERE DealName = 'Deimos'

		--As batch will be run on first day of each month for prev month  
		SET @monthToBeProcessed = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-2)) 
		SET @toCollectionDate = EOMONTH(@pAsAtDate, -1)    
  
		--check temp table if exists  
		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult') IS NOT NULL DROP TABLE #tmpMortgageLoanResult  
		IF OBJECT_ID('tempdb..#tmpDealProductData') IS NOT NULL DROP TABLE #tmpDealProductData  
	
		CREATE TABLE #tmpDealProductData(CorrelatedDate Datetime, DealId INT, ProductTypeId SMALLINT, DisplayName VARCHAR(200), LoanCount INT, CapitalBalanceValue DECIMAL(38, 16), CurrentRate DECIMAL(38, 16), RemainingTeaserPeriod DECIMAL(38, 16), CurentMargin DECIMAL(38, 16), ReversionaryMargin DECIMAL(38, 16), InitialRate DECIMAL(38, 16))  

		SELECT * INTO #tmpMortgageLoanResult FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
          
		TRUNCATE TABLE #tmpMortgageLoanResult;  
     
		--Get the partition id, and last working date of the month  
		SELECT   
			TOP 1 @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), AsAtDate, 112)) ,  
			@vintageDate =  AsAtDate,  
			@toCollectionDate = AsAtDate  
		FROM   
			sfp.syn_SfpModel_vw_Calendar_v1 
		WHERE   
			Month = Month(@monthToBeProcessed)  AND year = Year(@monthToBeProcessed)    
			AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode  
		ORDER BY   
			AsAtDate DESC    
  
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @vintageDate, @mortgageDealId  
		INSERT INTO #tmpMortgageLoanResult     
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @mortgageDealId 
  

		PRINT 'Execution completed -  Mortgage Commmon SP'  
  
		INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, DisplayName, LoanCount, CapitalBalanceValue, CurrentRate, RemainingTeaserPeriod, CurentMargin, ReversionaryMargin, InitialRate)  
		SELECT   
			@vintageDate,  
			@dealId,   
			pt.ProductTypeId,   
			CASE WHEN pt.[Name] = 'FIXED' THEN 'Fixed at origination, reverting to SVR' 
				WHEN pt.[Name] = 'TRACKER' THEN 'Tracker at origination, reverting to SVR'
				WHEN pt.[Name] = 'LIFETIMETRACKER' THEN 'Tracker for life'
				WHEN pt.[Name] = 'LifetimeFixed' THEN 'Fixed for life'
			END As DisplayName,
			COUNT(*) AS LoanCount,  
			SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0, (CAST(SUM(ISNULL(CURRENT_INTEREST_RATE, 0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100.00, 0) CurrentRate,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0,((CAST(SUM((DATEDIFF(day, @vintageDate, CASE WHEN tmp.FINAL_STEP_DATE = '1900-01-01' THEN tmp.MATURITY_DATE ELSE tmp.FINAL_STEP_DATE END)*12.00/365.00)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100)*100, 0)  RemainingTeaserPeriod,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0,CAST(SUM((ISNULL(tmp.CURRENT_INTEREST_RATE_MARGIN,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))/100, 0) CurentMargin,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0,CASE WHEN pt.[Name] IN ('LIFETIMETRACKER','LifetimeFixed') THEN CAST(SUM((ISNULL(tmp.CURRENT_INTEREST_RATE_MARGIN,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))/100 
			ELSE '0.00' END, 0) ReversionaryMargin,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0,SUM(CAST((ISNULL(tmp.InterestRateAtFlagged,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT))/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) /100, 0) InitialRate
		FROM   
			#tmpMortgageLoanResult tmp  
		JOIN   
			[cfgCW].[ProductType] pt ON tmp.Product = pt.Name  
		WHERE  
			pt.[Name] IN ('FIXED', 'TRACKER', 'LIFETIMETRACKER', 'LifetimeFixed')
		GROUP BY   
			tmp.Product, pt.ProductTypeId, pt.[Name]  

		INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, DisplayName, LoanCount, CapitalBalanceValue, CurrentRate, RemainingTeaserPeriod, CurentMargin, ReversionaryMargin, InitialRate)  
		SELECT   
			@vintageDate,  
			@dealId,   
			NULL,   
			'SVR, including discount to SVR' As DisplayName,
			COUNT(*) AS LoanCount,  
			SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0, (CAST(SUM(ISNULL(CURRENT_INTEREST_RATE, 0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100.00 , 0) CurrentRate,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0, ((CAST(SUM((DATEDIFF(day, @vintageDate, CASE WHEN tmp.FINAL_STEP_DATE = '1900-01-01' THEN tmp.MATURITY_DATE ELSE tmp.FINAL_STEP_DATE END)*12.00/365.00)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100)*100 , 0) RemainingTeaserPeriod,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0, CAST(SUM((ISNULL(tmp.CURRENT_INTEREST_RATE_MARGIN,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))/100 , 0) CurentMargin,
			'0.00' ReversionaryMargin,
			IIF(SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))<>0, (SUM(CAST((ISNULL(tmp.InterestRateAtFlagged,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT))/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100 , 0)InitialRate
		FROM   
			#tmpMortgageLoanResult tmp  
		JOIN   
			[cfgCW].[ProductType] pt ON tmp.Product = pt.Name  
		WHERE  
			pt.[Name] NOT IN ('FIXED', 'TRACKER', 'LIFETIMETRACKER', 'LifetimeFixed')
		GROUP BY PartitionId

		--Now Insert the remianing line item value for which data is zero
		INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, DisplayName, LoanCount, CapitalBalanceValue, CurrentRate, RemainingTeaserPeriod, CurentMargin, ReversionaryMargin, InitialRate)
		SELECT @vintageDate, @dealId, null, 'Fixed at origination, reverting to Libor', 0, 0, 0, 0, 0, 0, 0
		UNION
		SELECT @vintageDate, @dealId, null, 'Fixed at origination, reverting to tracker', 0, 0, 0, 0, 0, 0, 0
		UNION
		SELECT @vintageDate, @dealId, null, 'Tracker at origination, reverting to Libor', 0, 0, 0, 0, 0, 0, 0
		UNION
		SELECT @vintageDate, @dealId, null, 'Libor', 0, 0, 0, 0, 0, 0, 0

		--Now Inserting total row
		INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, DisplayName, LoanCount, CapitalBalanceValue, CurrentRate, RemainingTeaserPeriod, CurentMargin, ReversionaryMargin, InitialRate)
		SELECT   
			@vintageDate,  
			@dealId,   
			NULL,   
			'Total' As DisplayName,
			COUNT(*) AS LoanCount,  
			SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue,
			(CAST(SUM(ISNULL(CURRENT_INTEREST_RATE, 0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100.00 CurrentRate,
			((CAST(SUM((DATEDIFF(day, @vintageDate, CASE WHEN tmp.FINAL_STEP_DATE = '1900-01-01' THEN tmp.MATURITY_DATE ELSE tmp.FINAL_STEP_DATE END)*12.00/365.00)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100)*100  RemainingTeaserPeriod,
			CAST(SUM((ISNULL(tmp.CURRENT_INTEREST_RATE_MARGIN,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))) AS FLOAT)/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))/100 CurentMargin,
			'0.00' ReversionaryMargin,
			(SUM(CAST((ISNULL(tmp.InterestRateAtFlagged,0)*ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) AS FLOAT))/SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)))/100 InitialRate
		FROM   
			#tmpMortgageLoanResult tmp  
		JOIN   
			[cfgCW].[ProductType] pt ON tmp.Product = pt.Name  
		GROUP BY PartitionId
  
		DELETE dpd FROM [cb].[DealProductData] dpd  
		JOIN #tmpDealProductData tmp ON dpd.CorrelatedDate = tmp.CorrelatedDate AND dpd.DealId = tmp.DealId  
  
		--Populating the Product data  
		INSERT INTO [cb].[DealProductData](CorrelatedDate, DealId, ProductTypeId, DisplayName, LoanCount, CapitalBalanceValue, CurrentRate, RemainingTeaserPeriod, CurentMargin, 
		ReversionaryMargin, InitialRate, CreatedBy, CreatedDate)  
		SELECT CorrelatedDate, DealId, tmp.ProductTypeId, DisplayName, ISNULL(LoanCount, 0), ISNULL(CapitalBalanceValue, 0), ISNULL(CurrentRate, 0), ISNULL(RemainingTeaserPeriod, 0), ISNULL(CurentMargin, 0)
		,ISNULL(ReversionaryMargin, 0), ISNULL(InitialRate, 0), @createdBy, @createdDate 
		FROM   
			#tmpDealProductData tmp  
  
		PRINT 'Completed............' 
  
	END TRY    
  
	BEGIN CATCH     
  
		DECLARE     
		   @errorMessage     NVARCHAR(MAX),    
		   @errorSeverity    INT,    
		   @errorNumber      INT,    
		   @errorLine        INT,    
		   @errorState       INT;    
  
		SELECT     
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()    
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spProcessDealProductData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage    
		, 'System'    
  
		RAISERROR (@errorMessage,    
			@errorSeverity,    
			@errorState )    
  
	END CATCH    
END

GO