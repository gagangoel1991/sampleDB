USE [SFP_Securitisation]
GO


GO

IF OBJECT_ID('[cw].[spGetDailyCollectionWorkflowDetails]') IS NOT NULL
	DROP PROCEDURE [cw].spGetDailyCollectionWorkflowDetails
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/****** Object:  StoredProcedure [CW].spGetDailyCollectionWorkflowDetails    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun
 * Date:	30.08.2022
 * Description:  Daily Collection  lineitem for multiples dates
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 

	Declare @dates  [cw].[utdDateList]
	Insert @dates ([dates]) values ('28-NOV-2022')
	Insert @dates ([dates]) values ('25-NOV-2022')
	Insert @dates ([dates]) values ('24-NOV-2022')
	
	exec cw.spGetDailyCollectionWorkflowDetails @pCollectionDates = @dates, @pDealName='Dunmore1', @pUserName = 'kumavnb'

 * -------------------------------------------------------
*/    
        
        
CREATE PROC [CW].spGetDailyCollectionWorkflowDetails
	@pCollectionDates [cw].[utdDateList] ReadOnly,
	@pDealName varchar(100),
	@pUserName varchar(255) = NULL
AS        
BEGIN  
	
	BEGIN TRY  
		DECLARE
			@dailyCollectionSummaryId	INT,
			@dealId				INT,
			@dealRegionCode VARCHAR(10);  

			SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  
	

			Select [cw].[fnGetBusinessDate] (dt.dates, @dealRegionCode, -1, 1)  as CollectionDate, @dealId as dealId, dcs.DailyCollectionSummaryId, WorkFlowStepId
			INTO #SummaryTable
			FROM @pCollectionDates dt
			INNER JOIN [CW].[DailyCollectionSummary]  dcs on dcs.CollectionDate = [cw].[fnGetBusinessDate] (dt.dates, @dealRegionCode, -1, 1) and dcs.dealId=@dealId

			
			Select [cw].[fnGetBusinessDate] (dt.dates, @dealRegionCode, -1, 1)  as CollectionDate, @dealId as dealId, Null as DailyCollectionSummaryId, Null as WorkFlowStepId
			INTO #CollectionSummaryTable
			FROM @pCollectionDates dt

			Update CT
			SET CT.DailyCollectionSummaryId=ST.DailyCollectionSummaryId,
				CT.WorkFlowStepId = ST.WorkFlowStepId
			FROM #CollectionSummaryTable CT
			INNER JOIN #SummaryTable ST on CT.CollectionDate=ST.CollectionDate


			Select S.DailyCollectionSummaryId, max(WorkflowProcessId) as WorkflowProcessId
			INTO #ReviewerLastAuditLog
			FROM #SummaryTable s
			INNER JOIN [cw].[vwWorkflowProcess] vwfp on ProcessReferenceId=s.DailyCollectionSummaryId
			WHERE Name='DealDailyCollection'
			AND StepName in ('Authorise','Reject')
			Group By S.DailyCollectionSummaryId


			Select S.DailyCollectionSummaryId, max(WorkflowProcessId) as WorkflowProcessId
			INTO #LastReviewerComment
			FROM #SummaryTable s
			INNER JOIN [cw].[vwWorkflowProcess] vwfp on ProcessReferenceId=s.DailyCollectionSummaryId
			WHERE Name='DealDailyCollection'
			AND StepName in ('Authorise','Reject', 'ReviewerComment')
			Group By S.DailyCollectionSummaryId

			Select S.DailyCollectionSummaryId, max(WorkflowProcessId) as WorkflowProcessId
			INTO #UserLastAuditLog
			FROM #SummaryTable s
			INNER JOIN [cw].[vwWorkflowProcess] vwfp on ProcessReferenceId=s.DailyCollectionSummaryId
			WHERE Name='DealDailyCollection'
			AND StepName in ( 'Draft','SendForReview' )
			Group By S.DailyCollectionSummaryId

			Select S.DailyCollectionSummaryId, max(WorkflowProcessId) as WorkflowProcessId
			INTO #LastUserComment
			FROM #SummaryTable s
			INNER JOIN [cw].[vwWorkflowProcess] vwfp on ProcessReferenceId=s.DailyCollectionSummaryId
			WHERE Name='DealDailyCollection'
			AND StepName in ( 'Draft','SendForReview', 'UserComment')
			Group By S.DailyCollectionSummaryId
		
			Select dcs.DealId, dcs.CollectionDate, dcs.DailyCollectionSummaryId, dcs.WorkFlowStepId
			, 'User' as LineItem, ucomment.LastComment as Comments
			,  wf.ActionedBy as ModifiedBy
			,  wf.ActionedDate as ModifiedDate
			From #CollectionSummaryTable dcs
			LEFT Join (	SELECT ActionedBy, ProcessReferenceId,  Comment, ActionedDate
						FROM cw.vwWorkflowProcess vwfp 
						INNER JOIN #UserLastAuditLog rlal on vwfp.WorkflowProcessId = rlal.WorkflowProcessId
         				) wf ON Wf.ProcessReferenceId = dcs.DailyCollectionSummaryId
			LEFT Join (	SELECT ProcessReferenceId, Comment as LastComment, ActionedBy, ActionedDate
						FROM cw.vwWorkflowProcess vwfp 
						INNER JOIN #LastUserComment luc on vwfp.WorkflowProcessId = luc.WorkflowProcessId
         				) ucomment ON ucomment.ProcessReferenceId = dcs.DailyCollectionSummaryId
			


			Union ALL

			Select dcs.DealId, dcs.CollectionDate, dcs.DailyCollectionSummaryId, dcs.WorkFlowStepId
			, 'Reviewer' as LineItem, rcomment.LastComment as Comments
			,  wf.ActionedBy as ModifiedBy
			,  wf.ActionedDate as ModifiedDate
			From #CollectionSummaryTable dcs
			LEFT Join (	SELECT ProcessReferenceId, Comment, ActionedBy, ActionedDate
						FROM cw.vwWorkflowProcess vwfp 
						INNER JOIN #ReviewerLastAuditLog rlal on vwfp.WorkflowProcessId = rlal.WorkflowProcessId
         				) wf ON Wf.ProcessReferenceId = dcs.DailyCollectionSummaryId
			LEFT Join (	SELECT ProcessReferenceId, Comment as LastComment, ActionedBy, ActionedDate
						FROM cw.vwWorkflowProcess vwfp 
						INNER JOIN #LastReviewerComment lrc on vwfp.WorkflowProcessId = lrc.WorkflowProcessId
         				) rcomment ON rcomment.ProcessReferenceId = dcs.DailyCollectionSummaryId
			

	END TRY  
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionWorkflowDetails',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH   
	
END

GO
