USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spGetCollectionLedger]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetCollectionLedger]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================
--Author: Saurabh Bhatia
--Date:	24-Nov-2020
--Description:  To get Collection Ledger List on basis 
--				 CollectionBusinessStart AND CollectionBusinessEnd

-- Exec cw.spGetCollectionLedger  15,5,''
--================================== 
CREATE PROC [cw].[spGetCollectionLedger] 
    @pDealId SMALLINT,
    @pIPDRunId INT,
	   @pUserName		VARCHAR(80) 
AS
BEGIN
SET NOCOUNT ON
BEGIN TRY
    DECLARE @collectionStartDate DATE,@collectionEndDate DATE

	SELECT	
			@collectionStartDate = CAST(CollectionBusinessStart AS DATE), 
			@collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
   SELECT * INTO #tempCollectionLedger FROM cw.CollectionLedger_WIP WHERE IsActive=1
   SELECT 
       CollectionLedgerId,
       AdviceDate,
       CollectionDateTime AS CollectionDate,
       NetPrincipalCollections,
       FinanceCollections,
       OtherCollections,
       TotalDailyCashAmount,
       [Status],
       ModifiedBy,
       ModifiedDate,
	      Reason FROM (
        SELECT 
	          cl.CollectionLedgerId 
          ,cl.AdviceDate AS AdviceDate
		        ,cl.CollectionDate AS CollectionDateTime
          ,wip.Id AS WIPId
          ,ROW_NUMBER() OVER(PARTITION BY cl.CollectionDate ORDER BY Id DESC) AS RowNum 
          ,CAST(IIF(wip.CollectionLedgerId IS NOT NULL, ROUND(WIP.NetPrincipalCollections,4), ROUND(CL.NetPrincipalCollections,4))AS DECIMAL(30,8)) AS NetPrincipalCollections
	         ,CAST(IIF(wip.CollectionLedgerId IS NOT NULL, ROUND(WIP.FinanceCollections,4), ROUND(CL.FinanceCollections,4))AS DECIMAL(30,8)) AS FinanceCollections
          ,CAST(IIF(wip.CollectionLedgerId IS NOT NULL, ROUND(WIP.OtherCollections,4), ROUND(CL.OtherCollections,4)) AS DECIMAL(30,8))AS OtherCollections 
	         ,CAST(IIF(wip.CollectionLedgerId IS NOT NULL, ROUND(WIP.TotalDailyCashAmount,4), ROUND(CL.TotalDailyCashAmount,4)) AS DECIMAL(30,8)) AS TotalDailyCashAmount
          ,CASE WHEN wip.CollectionLedgerId IS NOT NULL THEN wip.Status WHEN wip.CollectionLedgerId IS NULL THEN wip.Status END AS [Status]
          ,IIF(wip.CollectionLedgerId IS NOT NULL, WIP.CreatedBy, '') AS ModifiedBy
          ,IIF(wip.CollectionLedgerId IS NOT NULL, WIP.CreatedDate,cl.CreatedDate) AS ModifiedDate
		        ,WIP.ChangeReason AS Reason
          FROM cw.CollectionLEdger cl
          LEFT JOIN #tempCollectionLedger wip ON cl.CollectionLedgerId = wip.CollectionLedgerId
           WHERE cl.DealId =@pDealId 
           AND CAST(cl.CollectionDate AS DATE) BETWEEN @collectionStartDate AND @collectionEndDate)t  
           WHERE t.RowNum=1 ORDER BY CAST(t.ModifiedDate AS DATE) DESC, t.CollectionDateTime 
           
END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'GetCollectionLedger', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END 
GO

