USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM SYS.OBJECTS WHERE OBJECT_ID = OBJECT_ID(N'[corp].[spGeneratePoolAppliedEcCtReportCB]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGeneratePoolAppliedEcCtReportCB]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- EXEC [corp].[spGeneratePoolAppliedEcCtReportCB] 651, 'kumasdt'
CREATE PROCEDURE [corp].[spGeneratePoolAppliedEcCtReportCB]
	@pPoolId AS INT,
	@pUserName AS VARCHAR(50)
AS
BEGIN            
		BEGIN TRY
			 
			SELECT ec.Name EcName, Ec.Description EcDescription, ec.EligibilityExpression EcEligibilityExpression ,
				 typ.Type AS EcType, typ.Description AS EcTypeDescription, sts.Status AS EcStatus
			FROM ps.Pool pl                                            
			INNER JOIN ps.PoolEcMap ecMap ON pl.PoolId = ecMap.PoolId                                            
			INNER JOIN ps.EligibilityCriteria ec ON ecMap.EligibilityCriteriaId = ec.EligibilityCriteriaId   
			INNER JOIN [ps].EligibilityCriteriaStatus sts ON  sts.EligibilityCriteriaStatusId = ec.EligibilityCriteriaStatusId
			INNER JOIN [ps].EligibilityCriteriaType typ ON typ.EligibilityCriteriaTypeId IN (SELECT [value] FROM [app].[udfSplitString](ec.EligibilityCriteriaTypeId, ','))                                        
			WHERE  pl.PoolId = @pPoolId AND ecMAp.IsActive = 1 AND ec.IsActive = 1

			SELECT ct.CriteriaName AS CtCriteriaName, ct.Description CtDescription, ct.CtExpression, '' AS CtSuperSetExpression, 
				typ.TestType AS CtTestType, typ.Description AS CtTestTypeDescription, sts.Status AS CtStatus
			FROM ps.Pool pl 
			INNER JOIN [ps].PoolCTMap ctMap ON pl.PoolId = ctMap.PoolId
			INNER JOIN [ps].ConcentrationTest ct ON ctmap.ConcentrationTestId = ct.ConcentrationTestId
			INNER JOIN [ps].ConcentrationTestStatus sts ON  sts.ConcentrationTestStatusId = CT.StatusId
			INNER JOIN  [ps].ConcentrationTestType typ ON typ.ConcentrationTestTypeId IN (SELECT [value] FROM [app].[udfSplitString](ct.ConcentrationTestTypeId, ','))
			WHERE PL.PoolId = @pPoolId AND ctMap.IsActive = 1 AND ct.isActive = 1
		END TRY            
		BEGIN CATCH            
			DECLARE 
					@errorMessage     NVARCHAR(MAX),
					@errorSeverity    INT,
					@errorNumber      INT,
					@errorLine        INT,
					@errorState       INT;
			SELECT 
				@errorMessage = ERROR_MESSAGE()
				,@errorSeverity = ERROR_SEVERITY()
				,@errorNumber = ERROR_NUMBER()
				,@errorLine = ERROR_LINE()
				,@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 2, 1, 'spGeneratePoolAppliedEcCtReportCB', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
			RAISERROR (@errorMessage,
					@errorSeverity,
					@errorState )        
		 END CATCH            
	END
GO