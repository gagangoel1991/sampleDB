USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetIpdAuthWorkflowStatus]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetIpdAuthWorkflowStatus] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 09-05-2021 
--Description: Get current Ipd Status 
--[cw].[spGetIpdAuthWorkflowStatus] 14,7,''
--==================================   
CREATE PROCEDURE [cw].[spGetIpdAuthWorkflowStatus] 
   @pDealId   INT,    
   @pIPDRunId INT,
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   
    DECLARE @overridedIrStatusId INT;
	SELECT @overridedIrStatusId= [cw].[fnGetWorkflowStepId]('OverridedIR', 'Deal_Ipd')

	SELECT   
		wfs.[DisplayName]AS StepDescription,  
		wfs.StepName AS StepName,  
		wfp.Comment,  
		wfp.ActionedBy AS ActionBy,  
		wfp.ActionedDate AS ActionDate, 
		CASE WHEN diil.isOverrided =1 THEN 'Overrided_'+ diil.[FileName] ELSE ISNULL(diil.fileName,'Not Generated') END AS IrFileName 
	FROM 
		cw.DealIpd ipd   
	JOIN 
		cw.DealIpdrun ipdRun ON ipd.DealIpdId=ipdRun.DealIpdId  
	JOIN 
		cfgCW.WorkflowStep wfs ON wfs.WorkflowStepId  = ipdrun.WorkflowStepId
	JOIN 
		cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId AND wft.Name = 'Deal_IPD'
	LEFT JOIN   
		(SELECT * FROM (SELECT  wfp.ProcessReferenceId, wfp.ActionedBy,wfp.ActionedDate, wfs.DisplayName AS WorkflowStepDisplayName, wft.Name AS WorkflowTypeName,  
			wfp.WorkflowStepId,wfp.comment,wfp.WorkflowProcessId,  
				ROW_NUMBER() OVER(Partition BY ProcessReferenceId, wft.WorkflowTypeId  ORDER BY ActionedDate DESC) AS RowNum   
			FROM cw.WorkflowProcess wfp  
			JOIN cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = wfp.WorkflowStepId  
			JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId  
			WHERE ProcessReferenceId=@pIPDRunId   
			--AND wfp.WorkflowStepId not in (@overridedIrStatusId) 
			AND wft.Name='Deal_IPD') AS t WHERE  RowNum = 1  
		) wfp ON  wfp.WorkflowStepId = wfs.WorkflowStepId   
	LEFT JOIN 
		[cw].[DealIpdIrLocation] diil ON diil.DealIpdId=ipdRun.DealIpdId  AND FormatType='Excel'
	WHERE 
		ipdRun.RunId = @pIPDRunId
		AND wfp.ProcessReferenceId=@pIPDRunId  
		AND ipd.DealId=@pDealId 
	ORDER BY wfp.WorkflowProcessId DESC  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetIpdAuthWorkflowStatus', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO