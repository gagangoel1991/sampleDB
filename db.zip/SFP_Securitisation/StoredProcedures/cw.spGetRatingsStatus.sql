USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetRatingsStatus]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetRatingsStatus]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=================================================      
--Author: GUNJAN CHANDOLA      
--Date: 30-07-2021     
--Description: check if rating edited for reset  
--DECLARE @pResultCode  BIT
--EXEC [cw].[spGetRatingsStatus] 4,'CPRating',@pResultCode OUT,'' 
--SELECT @pResultCode 
--=================================================       
CREATE PROCEDURE [cw].[spGetRatingsStatus]     
   @pDealIpdRunId INT,
   @pRatingType VARCHAR(300),
   @pResultCode BIT OUT,
   @pUserName  VARCHAR(80)           
AS      
BEGIN      
 BEGIN TRY   
 DECLARE
   @dealId INT,
   @businessStartDate   DATE,    
   @businessEndDate   DATE,
   @MaxRatingDate   DATE ,
   @dealType VARCHAR(100)
  --Getting the dealid, Business Start and End Date for the speciifed run id    
  SELECT     
   @businessStartDate = did.CollectionBusinessStart,     
   @businessEndDate = did.CollectionBusinessEnd ,
   @dealId = di.DealId 
  FROM cw.DealIpd di    
  JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId    
  JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId    
  WHERE dir.RunId = @pDealIpdRunId;      
    
   SET @dealType =(SELECT [cw].[fnGetDealType] (@dealId))

   SET @pResultCode=0   
    
   IF @pRatingType='BondRating' --Bond Rating    
   BEGIN 
		IF (@dealType='Covered Bond')
		BEGIN
			SET @MaxRatingDate = ISNULL((
			SELECT CAST(MAX(br.RatingDate) AS DATE)
			FROM CW.vwBondRating br
			JOIN [cfgcb].[DealNote] dn ON dn.ISIN = br.ISIN  
			WHERE CAST(br.RatingDate AS DATE) BETWEEN @businessStartDate
					AND @businessEndDate
				AND dn.DealId = @dealId
			), @businessEndDate);

			IF EXISTS(SELECT TOP 1 1
				FROM [cw].[UserBondRating] ubr
				JOIN [cfgcb].[DealNote] dn 
				ON dn.ISIN = ubr.ISIN
				AND  dn.IsNote = 1
				WHERE CAST(ubr.RatingDate AS DATE) = @MaxRatingDate
					AND dn.DealId = @dealId
					AND ISNULL(ubr.IsPrevIpdRating, 0) = 0
					AND ubr.RatingUploadDetailId IS NULL)    
			BEGIN 
				SET @pResultCode=1    
			END
		END
		ELSE IF(@dealType='RMBS')
		BEGIN
			SET @MaxRatingDate = ISNULL((
			SELECT CAST(MAX(br.RatingDate) AS DATE)
			FROM CW.vwBondRating br
			JOIN [cfgCW].[DealNote] dn ON dn.ISIN = br.ISIN
			WHERE CAST(br.RatingDate AS DATE) BETWEEN @businessStartDate
					AND @businessEndDate
				AND dn.DealId = @dealId
			), @businessEndDate);

			IF EXISTS(SELECT TOP 1 1
				FROM [cw].[UserBondRating] ubr
				JOIN [cfgCW].[DealNote] dn 
				ON dn.ISIN = ubr.ISIN
				AND  dn.IsNote = 1
				WHERE CAST(ubr.RatingDate AS DATE) = @MaxRatingDate
					AND dn.DealId = @dealId
					AND ISNULL(ubr.IsPrevIpdRating, 0) = 0
					AND ubr.RatingUploadDetailId IS NULL)    
			BEGIN 
			   SET @pResultCode=1    
			END
		END

			
   END    
   ELSE IF @pRatingType='CPRating' --cp Rating  
   BEGIN  

	SET @MaxRatingDate = ISNULL((
	SELECT CAST(MAX(cp.RatingDate) AS DATE)
	FROM CW.vwCounterpartyRating cp
	JOIN [CW].[vw_ActiveDealCounterparty] dc ON dc.CisCode = cp.CisCode
	WHERE CAST(cp.RatingDate AS DATE) BETWEEN @businessStartDate
			AND @businessEndDate
		AND dc.DealId = @dealId
	), @businessEndDate);	


   IF EXISTS(SELECT TOP 1 1
				FROM CW.userCounterpartyRating cp
				JOIN [CW].[vw_ActiveDealCounterparty] dc ON dc.CisCode = cp.CisCode
				WHERE CAST(cp.RatingDate AS DATE) = @MaxRatingDate
					AND dc.DealId = @dealId
					AND ISNULL(cp.IsPrevIpdRating, 0) = 0
					AND cp.RatingUploadDetailId IS NULL)    
      BEGIN 
           SET @pResultCode=1
      END
   END
 END TRY      
 BEGIN CATCH      
 IF @@trancount > 0 ROLLBACK TRANSACTION;   
  DECLARE       
   @errorMessage     NVARCHAR(MAX),      
   @errorSeverity    INT,      
   @errorNumber      INT,      
   @errorLine        INT,      
   @errorState       INT;      
      
  SELECT       
  @errorMessage = ERROR_MESSAGE()
  ,@errorSeverity = ERROR_SEVERITY()
  ,@errorNumber = ERROR_NUMBER()
  ,@errorLine = ERROR_LINE()
  ,@errorState = ERROR_STATE()      
      
  EXEC app.SaveErrorLog 1, 1, 'cw.spGetRatingsStatus', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName      
        
  RAISERROR (@errorMessage,      
     @errorSeverity,      
     @errorState )      
 END CATCH      
END

GO
