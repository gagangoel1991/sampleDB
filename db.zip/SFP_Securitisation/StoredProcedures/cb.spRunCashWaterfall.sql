USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spRunCashWaterfall') IS NOT NULL
	DROP PROCEDURE cb.spRunCashWaterfall
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cb.spRunCashWaterfall(
@pDealIpdRunId INT, 
@pUserName	VARCHAR(80)
,@pResultCode SMALLINT OUTPUT/* 
 * Author: Aditya Shrivastava 
 * Date:  21.03.2020 
 * Description:  Run cash waterfall
 *      
 * Change History 
 * -------------- 
 * Author    Date    Description 
 * ------------------------------------------------------- 
 DECLARE @resultCode		INT
  exec cb.spRunCashWaterfall 65,'fm\shriyad' , @resultCode OUTPUT
  SELECT @resultCode	
 * 
*/ 
)
AS
BEGIN
	DECLARE 
		@Message			VARCHAR(4000),   
		@stepCode			VARCHAR(50),
		@LogStepId      INT,
		@inputParams		VARCHAR(100) = 'DealIpdRunId=' + CONVERT(VARCHAR(10) ,@pDealIpdRunId) + '; UserName=' + CONVERT(VARCHAR(10) ,@pUserName) ,
		@logExecutionId		INT, 
		@validationOutput	SMALLINT,
		@pWorkflowProcessId INT,
		@exceptionErrorMessage  NVARCHAR(4000),
		@logFeatureID       INT,
		@ModuleID           INT

		DECLARE @tblWaterfallLogStep  TABLE
		(
		ExecutionId [INT] IDENTITY(1,1) NOT NULL,
		[LogStepId] [INT],
		[RelatedId] [INT] ,
		[StepCode] [varchar](100) NULL,
		[StartTime] [datetime] NOT NULL,
		[EndTime] [datetime] NULL,
		[Status] [varchar](100) NULL,
		[InputParams] [varchar](500) NULL,
		[ErrorDetails] [varchar](500) NULL,
		[IsDebug] [INT],
		[AdditonalDescription] [varchar](1000) NULL,
		[CreatedBy] [varchar](50) NOT NULL,
		[CreatedDate] [datetime] NOT NULL
		)

	BEGIN TRY 
		--Firstly update the IPD status as Running  
		UPDATE cw.DealIPDRun SET IsIpdRunning = 1, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE Runid = @pDealIpdRunId 

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep WHERE  StepCode = 'CW_RC'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());
	 
		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep WHERE  StepCode = 'CW_EXP_ADJ'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_WLI_1'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_WLI_OVERRIDE_2'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_RW'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_COUPONPAYMENTFUND_POST'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_RESERVEFUND_POST'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_PREMATURITYLIQUIDITY_POST_1'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_PW'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_PREMATURITYLIQUIDITY_POST_2'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_UPDATELINEITEM_POST'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_MANAGEWORKFLOW_POST'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

		SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_SAVEIPDDATA_POST'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());

			SELECT @LogStepId =  LogStepId, @stepCode= StepCode FROM app.LogStep   WHERE StepCode = 'CB_CW_RUNALLTEST'
		INSERT INTO @tblWaterfallLogStep(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
			VALUES (@LogStepId,@pDealIpdRunId, @stepCode, GETDATE(), NULL, 'PENDING', @InputParams, NULL	, 0, NULL, @puserName, GETDATE());


		BEGIN TRAN		
		
		DECLARE 
			@DealId			INT,
			@IpdDate		DATE,
			@Version		INT,
			@ipdSequence	INT

		SELECT @DealId=DealId, @IpdDate=IpdDate, @version=DealIpdRunVersion , @ipdSequence=IpdSequence FROM cw.vwDealIpdRun WHERE DealIpdRunId=@pDealIpdRunId;

		SELECT @ModuleID =  ModuleId FROM app.Module WHERE Name ='Cashwaterfall'
		SELECT @logFeatureID = LogFeatureId FROM app.LogFeature WHERE Feature = 'RunCashWaterfall' AND ModuleId = @ModuleID;

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CW_RC',@logFeatureID);

		DECLARE @resultCode		INT
		EXEC [cw].[spReCalculateIpd] @pDealIpdRunId, @pUserName, @resultCode OUTPUT

		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

		--CALCULATE EXPRESSION AFTER ADJUSTMENT
		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_EXP_ADJ',@logFeatureID);
		EXEC  cw.spCalculateExpression @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId		 	

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_WLI_1',@logFeatureID);
		EXEC  cw.spUpdateWaterfallLineItemAmount @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId	

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_WLI_OVERRIDE_2',@logFeatureID);
		EXEC  cw.spCalculateCWOverrideSql @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId	

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_RW',@logFeatureID)
		EXEC   [cb].[spCalculateRevenueWaterfallPayment] @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId 

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_COUPONPAYMENTFUND_POST',@logFeatureID);
		EXEC  cb.spProcessCouponPaymentFund_PostWf @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId	

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_RESERVEFUND_POST',@logFeatureID);
		EXEC  cb.spProcessReserveFund_PostWF @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId	

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_PREMATURITYLIQUIDITY_POST_1',@logFeatureID);
		EXEC  cb.spProcessPreMaturityLiquidity_PostWF @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId	

		SELECT @LogStepId = cw.fnGetLogStepCodeValue('CB_CW_PW',@logFeatureID)
		EXEC [cb].[spCalculatePrincipalWaterfallPayment] @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_PREMATURITYLIQUIDITY_POST_2',@logFeatureID);
		EXEC  cb.spProcessPreMaturityLiquidity_PostWF @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId	

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_MANAGEWORKFLOW_POST',@logFeatureID)
		EXEC [cw].[spManageIpdAuthWorkflow]  @pDealId=@DealId, @pIPDRunId=@pDealIpdRunId,@pStepName='Draft', @pComment ='', @pUserName=@pUserName ,@pOutput= @pWorkflowProcessId OUT
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_UPDATELINEITEM_POST',@logFeatureID)
		EXEC [cw].[spUpdateIpdSummaryLineItemStatus] @pDealIpdRunId, '', @pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_SAVEIPDDATA_POST',@logFeatureID)
		EXEC cw.spSaveIpdInputData_PostWF @pDealIpdRunId,@pWorkflowProcessId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
		
		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_CW_RUNALLTEST',@logFeatureID)
		EXEC [cb].[spRunAllTest] @pDealIpdRunId, @pUserName 
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId

		SELECT @LogStepId =  cw.fnGetLogStepCodeValue('CB_RUN_BOOKINGS',@logFeatureID);
		EXEC  [cw].[spCalculateExpression] @pDealIpdRunId,@pUserName
		EXEC  cb.spProcessBookingsIPDData @pDealIpdRunId,@pUserName
		UPDATE @tblWaterfallLogStep SET Status='SUCCESS' , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
	

		COMMIT TRAN 
		          
		SET @pResultCode = 1

	END TRY 
    BEGIN CATCH 
          
		 IF @@TRANCOUNT > 0  
			ROLLBACK TRAN  

		--Reset the IPD running status  
		UPDATE cw.DealIPDRun SET IsIpdRunning = 0, ModifiedBy=@pUserName, ModifiedDate=GETDATE() WHERE Runid = @pDealIpdRunId  

        DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spRunCashWaterfall', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		SET @pResultCode = 0

		SELECT @exceptionErrorMessage = ERROR_MESSAGE()
		UPDATE @tblWaterfallLogStep SET Status='FAILED',ErrorDetails = @exceptionErrorMessage , EndTime =  GETDATE() WHERE LogStepID=@LogStepId
		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )
	END CATCH

		INSERT INTO [cw].[LogExecution]
		(LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate) 
		SELECT LogStepId,RelatedId,StepCode,StartTime,EndTime,Status,InputParams,ErrorDetails,IsDebug,AdditonalDescription,CreatedBy,CreatedDate 
		 FROM @tblWaterfallLogStep
END

GO 