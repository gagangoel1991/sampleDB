USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[GetSecurityDataCorrectionList]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [corp].[GetSecurityDataCorrectionList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/**********************************************************************************************************************************
Author:			Neeraj Jindal
Create Date:	12-May-2022
Description:	Stored proc to get Security columns which user wants to override.
Update Date:	
Usage:  
DECLARE @RowID VARCHAR(50)		
EXEC [corp].[GetSecurityDataCorrectionList] '10-May-2022', 1, 2,null,'Europa\racfid'
				
**********************************************************************************************************************************/

CREATE PROCEDURE [corp].[GetSecurityDataCorrectionList] 
(
	@pDate DATE,
	@pDealId INT,
	@pEntityId INT,
	@pFsId VARCHAR(20) = NULL,
	@pUserName VARCHAR(20)
)
AS
BEGIN
	BEGIN TRY		
		IF OBJECT_ID('tempdb.dbo.#AttributeList', 'U') IS NOT NULL
			DROP TABLE #AttributeList;
		IF OBJECT_ID('tempdb.dbo.#PivotedOriginalUpdatedData', 'U') IS NOT NULL
			DROP TABLE #PivotedOriginalUpdatedData;
		IF OBJECT_ID('tempdb.dbo.#PivotedOriginalData', 'U') IS NOT NULL
			DROP TABLE #PivotedOriginalData;
		IF OBJECT_ID('tempdb.dbo.#PivotedCorrectedData', 'U') IS NOT NULL
			DROP TABLE #PivotedCorrectedData;		

		-- Insert origional data into #AttributeList temp  		
		SELECT DISTINCT			 
			 dsec.ConnectionId
			,dsec.SecurityId	
			,ffac.FacilityId		
			,dsec.ValnSourceCode
			,dsec.GrossValueAmt
			,dsec.PropertyNatureCode
			,dsec.PropertyPostcode
			,dsec.SecurityDescription
			,dsec.CradleSecurityId

		INTO #AttributeList
		FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] ffac
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac	
			ON dfac.FacilityKey = ffac.FacilityKey
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeFacilitySecurity] bfs
			ON bfs.FacilitySecurityGroupKey = ffac.FacilitySecurityGroupKey	AND ffac.FacilitySecurityGroupKey <> -1	
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimSecurity] dsec
			ON dsec.SecurityKey = bfs.SecurityKey 
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_DealToFacilityMapping] deal
			ON CONVERT(VARCHAR, deal.FacilityId) = ffac.FacilityId
		WHERE deal.DealId = @pDealId
		AND ffac.PartitionId =  CONVERT(VARCHAR, CONVERT(DATETIME, @pDate), 112)				
		AND (ISNULL(@pFsId,'') = '' OR @pFsId = IIF(@pEntityId=1, ffac.FacilityId, CONVERT(VARCHAR, dsec.SecurityId)))
		
		-- Piovt Original data into #PivotedOriginalData	
		SELECT 
			 SecurityId			
			,ConnectionId
			,MAX(ValnSourceCode) AS ValnSourceCode
			,MAX(GrossValueAmt) AS GrossValueAmt
			,MAX(PropertyNatureCode) AS PropertyNatureCode
			,MAX(PropertyPostcode) AS PropertyPostcode
			,MAX(SecurityDescription) AS SecurityDescription
			,MAX(CradleSecurityId) AS CradleSecurityId				
			,STUFF((SELECT DISTINCT ', ' + CAST(FacilityId AS VARCHAR(10)) [text()]
					FROM #AttributeList 
					WHERE SecurityId = t.SecurityId AND ConnectionId = t.ConnectionId
					FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') FacilityId
		INTO #PivotedOriginalData
		FROM #AttributeList t		
		WHERE SecurityId IS NOT NULL 
		GROUP BY SecurityId, ConnectionId
		

		-- Copy data to #PivotedOriginalUpdatedData where we update it with overrided value later
		SELECT * INTO #PivotedOriginalUpdatedData FROM #PivotedOriginalData

		-- Get Corrected data  and Piovt into #PivotedCorrectedData	
		SELECT * INTO #PivotedCorrectedData FROM
		(
			SELECT 
				 ddcd.facilitySecurityId
				,ddcd.ConnectionId
				,attr.AttributeName
				,ddcd.Value					
			FROM [corp].[DealDataCorrectionDetail] ddcd
			INNER JOIN [corp].[DealDataCorrection] ddc
				ON ddc.dealdatacorrectionid = ddcd.dealdatacorrectionid
			INNER JOIN [corp].[DealDataCorrectionAttribute] attr
				ON attr.DealDataCorrectionAttributeId = ddcd.AttributeId
				AND ddc.AsAtDate = @pDate
		)pvt
		PIVOT 
		(
			MAX(pvt.Value)
			FOR AttributeName IN
			(								
				 ValnSourceCode
				,GrossValueAmt
				,PropertyNatureCode
				,PropertyPostcode
				,SecurityDescription
				,CradleSecurityId
			)
		)pvtDataCorrection
		
		-- Update and return final result
		UPDATE orig 		
		SET 			
			 orig.ValnSourceCode = ISNULL(corr.ValnSourceCode, orig.ValnSourceCode)
			,orig.GrossValueAmt = ISNULL(corr.GrossValueAmt, orig.GrossValueAmt)			
			,orig.PropertyNatureCode = NULLIF(ISNULL(corr.PropertyNatureCode, orig.PropertyNatureCode), '')
			,orig.PropertyPostcode = NULLIF(ISNULL(corr.PropertyPostcode, orig.PropertyPostcode), '')
			,orig.SecurityDescription = NULLIF(ISNULL(corr.SecurityDescription, orig.SecurityDescription), '')
			,orig.CradleSecurityId = ISNULL(corr.CradleSecurityId, orig.CradleSecurityId)
		FROM #PivotedOriginalUpdatedData orig
		INNER JOIN #PivotedCorrectedData corr
			ON orig.SecurityId = corr.FacilitySecurityId
			AND orig.ConnectionId = corr.ConnectionId
		
		SELECT * FROM #PivotedOriginalUpdatedData ORDER BY SecurityId ASC --Overirded Data
		SELECT * FROM #PivotedOriginalData ORDER BY SecurityId ASC -- Original Data

END TRY
	BEGIN CATCH	                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'GetSecurityDataCorrectionList', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                    
                      
		RAISERROR (@errorMessage, @errorSeverity, @errorState)
	END CATCH
END
GO