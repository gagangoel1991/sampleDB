USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cb].[spProcessMaturingProceedsLoanFund]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessMaturingProceedsLoanFund]
GO

/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 11/17/2022 10:05:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessMaturingProceedsLoanFund] 
( 
  /* 
 *   Author: Arun 
 *   Date:  24.11.2022
 *   Description:  Fill Principal ledger Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessMaturingProceedsLoanFund] 33,'fm\shriyad'
 *    select * from [Cb].[SwapCollateralFund] where dealipdrunid=33           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
        

			DECLARE @dealId  INT, 
			@calendarStartDt			DATE,
			@calendarEndDt			DATE,
			@coveredBondFundId INT,
			@ipdDate DATE, @prevIpdDate DATE, 
			@MaturingProceedsLoanFund_bF decimal(38,16),
			@Rate  decimal(38,16),
			@Interest  decimal(38,16), @InterestDays INT,
			@CapitalContributionRedemption decimal(38,16),
			@PrincipalCollectionReduction decimal(38,16),
			@RetainedPrincipal decimal(38,16),
			@IssuanceFunds decimal(38,16),
			@CapitalContributionTopUps decimal(38,16),
			@MaturingProceedsLoanFund_cf  decimal(38, 16)


			SELECT 	@dealId = d.DealId, @ipdDate = Ipd
			, @calendarStartDt = CAST(d.CollectionCalendarStart AS DATE) 
			, @calendarEndDt= CAST(d.CollectionCalendarEnd AS DATE) 			
			FROM cw.vwDealIpdDates d
			JOIN cw.vwDealIpdRun r			
			ON CAST(d.IPD AS DATE) = r.IpdDate
				AND d.DealIpdId =r.DealIpdId
			Where DealIpdRunId=@pDealIpdRunId

		  
			DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);

			SELECT @prevIpdDate = IpdDate FROM cw.vwDealIpdRun dir WHERE  DealIpdRunId = @dealPreviousIpdRunId 

			SET @InterestDays = DATEDIFF(d, @prevIpdDate, @ipdDate)

			Select @coveredBondFundId = CoveredBondFundId FROM	cfgcb.CoveredBondFund cbf
                WHERE  cbf.InternalName = 'MaturingProceedsLoan' 

			SELECT @MaturingProceedsLoanFund_bF = MaturingProceedsLoanFund_cf
			FROM cb.[MaturingProceedsLoanFund] scf
			JOIN cfgCb.CoveredBondFund cbf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
			AND  cbf.InternalName = 'MaturingProceedsLoan'
			WHERE DealIpdRUnId = @dealPreviousIpdRunId

			
			SET @Rate=	ISNULL((SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName   ='MPL_Rate'
									AND ManualFieldGroupInternalName = 'MaturingProceedsLoan'
									AND DealIpdRunId = @pDealIpdRunId),0);
			

			SET @Interest = ISNULL(@MaturingProceedsLoanFund_bF * @Rate * ( @InterestDays/ 365),0)

			SET @CapitalContributionRedemption =	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='CashCapital_RedemptionCoveredBond'
									AND ManualFieldGroupInternalName = 'CashCapitalContributions'
									AND DealIpdRunId = @pDealIpdRunId);
			
			Select @PrincipalCollectionReduction= -1 * sum(PrincipalReceiptAmount) FROM cb.SFPCollectionInterest Where CollectionDate>=@calendarStartDt and CollectionDate<=@calendarEndDt

			SET @RetainedPrincipal=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='AmountretainedPrincipalLedger'
									AND ManualFieldGroupInternalName = 'AvailablePrincipalReceipts'
									AND DealIpdRunId = @pDealIpdRunId);
			
			SET @IssuanceFunds=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='IssuancesFunds'
									AND ManualFieldGroupInternalName = 'MaturingProceedsLoan'
									AND DealIpdRunId = @pDealIpdRunId);

			SET @CapitalContributionTopUps=	(SELECT SUM(CONVERT(decimal(38,16),ManualFieldValue)) FROM [Cb].[vwManualField] 		
									WHERE ManualFieldInternalName  ='LoansSaleRelatedSecurityLLP'
									AND ManualFieldGroupInternalName = 'CapitalContributionsInKind'
									AND DealIpdRunId = @pDealIpdRunId);

			

			SET @MaturingProceedsLoanFund_cf = IsNull(@MaturingProceedsLoanFund_bF,0) + @Interest - @PrincipalCollectionReduction + @IssuanceFunds

			DELETE FROM cb.[MaturingProceedsLoanFund] WHERE DealIpdRunId = @pDealIpdRunId 

			INSERT INTO cb.[MaturingProceedsLoanFund] 
						  ( DealIpdRunId,
							CoveredBondFundId,
							MaturingProceedsLoanFund_bF,
							Rate,
							Interest,
							CapitalContributionRedemption,
							PrincipalCollectionReduction,
							RetainedPrincipal,
							IssuanceFunds,
							CapitalContributionTopUps,
							MaturingProceedsLoanFund_cf,
							IsActive,
							CreatedBy,
							CreatedDate,
							ModifiedBy,
							ModifiedDate) 
			SELECT @pDealIpdRunId
							,@coveredBondFundId
							,@MaturingProceedsLoanFund_bF
							,@Rate
							,@Interest
							,@CapitalContributionRedemption
							,@PrincipalCollectionReduction
							,@RetainedPrincipal
							,@IssuanceFunds
							,@CapitalContributionTopUps
							,@MaturingProceedsLoanFund_cf
							 ,1, 
							 @pUserName, 
							 Getdate(), 
							 @pUserName ,
							 Getdate()

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessMaturingProceedsLoanFund', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END