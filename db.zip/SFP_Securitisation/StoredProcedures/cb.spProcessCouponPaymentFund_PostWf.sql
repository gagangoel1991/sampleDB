USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessCouponPaymentFund_PostWf]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessCouponPaymentFund_PostWf]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessCouponPaymentFund_PostWf] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  16.03.2022
 *   Description:  Fill CouponPaymentFund_PostWf CB Fund table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *     
 *   exec cb.[spProcessCouponPaymentFund_PostWf] 35,'fm\shriyad'
 *    select * from [Cb].[CouponPaymentFund_PostWf] where dealipdrunid=35           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 
      BEGIN TRY 
          --declare @pDealIpdRunId int=35, @pUserName varchar(20)='fm\shriyad'; 

	        DECLARE @CreditReceived decimal(38,16)

				SELECT @CreditReceived = RevenueWaterfallTotalPaidAmount
				FROM [CW].[vwRevenueWaterfallPaymentSummary]
				WHERE DealIpdRUnId = @pDealIpdRunId AND WaterfallLineItemInternalName='RevenuePriorityofPayments_6.000'

                
          DELETE FROM [Cb].[CouponPaymentFund_PostWf] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[CouponPaymentFund_PostWf] 
                      ( DealIpdRunId
						,CoveredBondFundId
						,CreditReceived
						,CouponPayment_cf
						,IsActive
						,CreatedBy
						,CreatedDate
						,ModifiedBy
						,ModifiedDate) 
          SELECT   @pDealIpdRunId                       
						,cbf.CoveredBondFundId 
						,@CreditReceived
						,COALESCE(CouponPayment_bF,0)+COALESCE(CapitalContribution,0)
								 -COALESCE(ResidualAmount,0)+@CreditReceived
						,1, 
						 @pUserName, 
						 Getdate(), 
						 @pUserName ,
						 Getdate()
				  FROM	cfgcb.CoveredBondFund cbf
						JOIN cb.CouponPaymentFund_PreWf cpf_preWF ON cpf_preWF.CoveredBondFundId = cbf.CoveredBondFundId
								AND cpf_preWF.DealIpdRunId = @pDealIpdRunId
                WHERE  cbf.InternalName = 'CouponPaymentFund' 
		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessCouponPaymentFund_PostWf', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END

GO