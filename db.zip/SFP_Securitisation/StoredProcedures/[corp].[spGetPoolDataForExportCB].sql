USE [SFP_Securitisation]
GO


IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetPoolDataForExportCB]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetPoolDataForExportCB]
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [corp].[spGetPoolDataForExportCB] 711, 4, 'kumasdt'
CREATE PROCEDURE [corp].[spGetPoolDataForExportCB]
	@pPoolId int,
	@pReportType int,
	@pUserName VARCHAR(50)
AS
BEGIN	
	BEGIN TRY		
		DECLARE @VintageDate DATETIME;    
		DECLARE @PartitionId BIGINT;   
		DECLARE @PoolPurposeId INT = (SELECT PoolPurposeId FROM ps.Pool WHERE PoolId = @pPoolId) 

		SELECT @VintageDate = [VintageDate]     
		FROM [ps].[Pool]    
		WHERE [PoolId] = @pPoolId;    
		
		SELECT @PartitionId = CONVERT(VARCHAR, @VintageDate, 112);  
		
		IF OBJECT_ID('tempdb.dbo.#resultSet', 'U') IS NOT NULL                  
			DROP TABLE #resultSet;

		IF OBJECT_ID('tempdb.dbo.#tempPoolBuildData', 'U') IS NOT NULL                  
			DROP TABLE #tempPoolBuildData;

		SELECT distinct PoolBuildDetailId, PB.PoolId, LoanId, MortgageAccountKey, VintageDate, MortgageSubAccountKey, LoanBalance, PB.IsActive
		  INTO #tempPoolBuildData
		  FROM [ps].[PoolBuildDetail] PB
		   LEFT JOIN PS.PoolFacilityCherryPickState PFD
				  ON PB.LoanId = PFD.FacilityID AND PB.PoolId = PFD.PoolID
			   AND (PB.IsActive = 1 OR PFD.CurrentIsActiveState = 1)
			   where PB.PoolId = @pPoolId

		DECLARE @DealIds VARCHAR(500) = ''
		SELECT @DealIds = @DealIds + ',' + CAST(FCAP.DealKey AS VARCHAR(50))
		  FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] FF
		  JOIN #tempPoolBuildData PB
			ON PB.MortgageAccountKey = FF.FacilityKey 
		   AND FF.PartitionId = @PartitionId 
		   --AND PB.IsActive = 1
		   --AND PB.PoolId = @pPoolId
		   Join [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] FCAP
	       ON FCAP.DealFacilityGroupKey = FF.DealFacilityGroupKey 
          GROUP BY FCAP.DealKey   
		SET @DealIds = STUFF(@DealIds, 1, 1, '')

		DECLARE @FacilityIds VARCHAR(MAX) = '' 

		Select @FacilityIds = @FacilityIds + ',' + CAST(LoanId AS VARCHAR(50))
		FROM #tempPoolBuildData
  
		SET @FacilityIds = STUFF(@FacilityIds, 1, 1, '')  
		IF Exists(Select 1 From #tempPoolBuildData)  
			IF LTRIM(RTRIM(@DealIds)) = '' OR @DealIds IS NULL  
				SET @DealIds = '-1'  
   --ELSE IF @DealIds Not LIKE '%-1%'  
    --SET @DealIds = '-1,' + @DealIds  

	--	-- If any Facility is not part of vw_FactCorporateAssetPool, then some Facilities belong to No Deal also.
	--	DECLARE @FacilityCount INT = 0

	--	SELECT @FacilityCount = COUNT(DISTINCT PB.LoanId)
	--	  FROM #tempPoolBuildData PB
	--	  INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] FF
	--		ON PB.MortgageAccountKey = FF.FacilityKey 
	--	   AND FF.PartitionId = @PartitionId 
	--	   AND PB.IsActive = 1
	--	   AND PB.PoolId = @pPoolId
	--	   AND DealFacilityGroupKey = -1

	--  	IF @FacilityCount > 0
	--		IF LTRIM(RTRIM(@DealIds)) = '' OR @DealIds IS NULL
	--			SET @DealIds = '-1'
	--		ELSE IF @DealIds Not LIKE '%-1%'
	--			SET @DealIds = '-1,' + @DealIds

	--	DECLARE @FacilityIds VARCHAR(MAX) = ''

	--	SELECT @FacilityIds = @FacilityIds + ',' + FF.FacilityId
	--	  FROM #tempPoolBuildData PB
	-- LEFT JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] FF
	--		ON PB.MortgageAccountKey = FF.FacilityKey 
	--	   AND FF.PartitionId = @PartitionId 
	--	   AND PB.IsActive = 1
	--	   AND PB.PoolId = @pPoolId
	--  GROUP BY FF.FacilityId
	--  	SET @FacilityIds = STUFF(@FacilityIds, 1, 1, '')

	---- 	SELECT @FacilityIds = @FacilityIds + ',' + CAST(LoanId AS VARCHAR(50))
	---- 	  FROM [ps].[PoolBuildDetail] PB
	---- 	 WHERE PB.PoolId = @pPoolId
	----   GROUP BY LoanId
	---- 	SET @FacilityIds = STUFF(@FacilityIds, 1, 1, '')
		
		Declare @RowID Varchar(50) = ''
		DECLARE @ReqCols XML = NULL
		SELECT @ReqCols = ( 
			SELECT CriteriaFieldName FROM (
				VALUES ('FacilityId'), ('DealName'), ('TotalCreditLimit'), ('UtilisationGBP_SecDate'), ('CIS')
			) T(CriteriaFieldName) FOR XML PATH('Node'), ROOT('Root'))
		
		-- Calling Common SP to fetch the data
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
			@VintageDate = @VintageDate,    
			@DealKey  = @DealIds,
			@FacilityIds = @FacilityIds,
			@ReqColumns  = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		
		SELECT DISTINCT 
				FacilityId, NULL AS DealId,
				IIF (@PoolPurposeId = 2, 'NA', DealName) AS DealName, 
				TotalCreditLimit, UtilisationGBP_SecDate AS Utilisation,
				CIS
		INTO #resultSet
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging]
		WHERE RowId = @RowID

		Update O
		SET O.DealId = C.DealId
		FROM #resultSet O INNER JOIN [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] C ON O.DealName = C.DealName
		where O.DealName = C.DealName

		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		IF( @pReportType = 4 )
		BEGIN
			SELECT distinct RS.FacilityId,
				   DealName,
				   @VintageDate AS VintageDate,
				   PB.PoolId,
				   Utilisation AS OutstandingCapitalBalance,
				   TotalCreditLimit AS TrueBalance,
				   PB.LoanBalance AS Rona,
				   CIS
			  FROM #resultSet RS
			  JOIN [ps].[PoolBuildDetail] PB
			    ON PB.LoanId = RS.FacilityId
				  LEFT JOIN PS.PoolFacilityCherryPickState PFD
				  ON PB.LoanId = PFD.FacilityID AND PB.PoolId = PFD.PoolID	   
			   WHERE  PB.PoolId = @pPoolId AND (PB.IsActive = 1 OR PFD.CurrentIsActiveState = 1) AND (RS.DealID = PFD.DealId OR PFD.DealId IS NULL)
		END
		
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()
		

		EXEC app.SaveErrorLog 2, 1, 'spGetPoolDataForExportCB', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
