USE SFP_Securitisation

GO

IF OBJECT_ID('cw.spIR_GenerateExcelViewDealIRConfig') IS NOT NULL
DROP PROC  cw.spIR_GenerateExcelViewDealIRConfig
GO

GO
/****** Object:  StoredProcedure [cw].[GenerateExcelViewDealIRConfig]    Script Date: 14/03/2021 15:08:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:	14.03.2021
 * Description:  Excel Framework Report Deal Mapping Logic for excel writing   
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
 * exec cw.spIR_GenerateExcelViewDealIRConfig 32, '30-Nov-2020'
 * -------------------------------------------------------
*/    
        
CREATE PROC CW.spIR_GenerateExcelViewDealIRConfig
	@pDealIrConfigId		INT,  
	@pAsAtdate DateTime = NULL ,
	@pReportTypeName VARCHAR(50) = ''
AS        
BEGIN        

	DECLARE @defaultTemplateFile varchar(255)
	, @irFilePeriod varchar(50)
	, @irDatePeriod DateTime = DateAdd(m, 1, @pAsAtdate)
	, @irFormatColStartIndex INT=1
	, @irFormatColEndIndex INT=1
	, @irFormatRowStartIndex INT
	, @irFormatRowEndIndex INT
	, @irFormatRowEndIndex_CB INT
	, @esmaFormatColEndIndex INT
	, @dealName varchar(50)

	DECLARE @ReportTypeId INT;

	SELECT @dealName = DealName FROM [cfgCW].[IR_DealIRConfig] ircfg
						INNER JOIN cfg.Deal deal ON ircfg.DealId = deal.dealId
						WHERE DealIrConfigId = @pDealIrConfigId

	DECLARE @AssetClassId  INT = (SELECT AssetClassId FROM cfg.Deal WHERE DealName = @dealName)
	DECLARE @CorporateAssetId INT = (SELECT AssetClassId FROM ps.AssetClass WHERE Code = 'CL')
	DECLARE @RetailAssetId INT = (SELECT AssetClassId FROM ps.AssetClass WHERE Code = 'RT')

	SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
	SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 
	
	

    SET @irFilePeriod= DateName(month, @irDatePeriod) + ' ' + Cast(YEAR(@irDatePeriod) AS varchar) + ' IPD.xlsx'
	
	DECLARE @ReportTitle varchar(200)
	IF @pReportTypeName = 'IR' SELECT @ReportTitle = ' - Investor Report - '
	ELSE SELECT @ReportTitle = ' - '+ @pReportTypeName +' Report - ';


	IF(@pReportTypeName = 'Reference Registry')
	BEGIN 			
			Select @defaultTemplateFile = NULL;
			SET @irFilePeriod='.xlsx'
			SET @ReportTitle =' - '+ @pReportTypeName +' Report';
	END 
	ELSE IF (@AssetClassId = @CorporateAssetId)
	BEGIN 
		SELECT @defaultTemplateFile = Value FROM cw.vw_DealLookup WHERE TypeCode='Build_IR' AND Name='CB_IR_Template'
	END
	ELSE 
	BEGIN
		SELECT @defaultTemplateFile = Value FROM cw.vw_DealLookup WHERE TypeCode='Build_IR' AND Name='IR_Template'
	END
	
	
	SELECT I.StratId, I.Name AS StratName, StratTypeId, 
	CASE WHEN DL.Name ='Bespoke Field' THEN SM.BespokeStratId ELSE FieldId  END AS FieldId
	, I.Name AS SheetName
	INTO #TBLStrat
	FROM [cfgCW].[IR_Strat] I
	LEFT JOIN cfgCW.IR_AssetStrat SM ON SM.StratId=I.StratId  AND SM.ReportTypeId = I.ReportTypeId 
	LEFT JOIN cw.vw_DealLookup DL ON DL.LookupValueId = SM.FieldTypeLookupId  
	LEFT JOIN cfgCW.IR_AssetField E ON E.AssetFieldId=SM.FieldId  
	WHERE I.IsLocked IN ( 0, 1)  --AND I.ReportTypeId = @ReportTypeId
	
	
	SELECT  @irFormatColStartIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='Start Column Index'
	SELECT  @irFormatColEndIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='End Column Index'
	SELECT  @irFormatRowStartIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='Start Row Index'
	SELECT  @irFormatRowEndIndex = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_RMBS' AND LookupTypeName='IR_Formatting' AND Name='End Row Index'

	SELECT  @irFormatRowEndIndex_CB = Value FROM  cw.vw_DealLookup DL WHERE TypeCode='IR_CB' AND LookupTypeName='IR_Formatting' AND Name='End Row Index'
	SELECT  @esmaFormatColEndIndex =[cw].[fnGetReportLookupValueByName]('ESMA','ESMAEndColumnIndex','ESMA_Report_Formatting')

	SELECT DL.DealName,  ST.FieldId, ST.StratName
	, CASE 
		WHEN @pReportTypeName IN ('HTT','Reference Registry')
			THEN IRSM.SheetName		
		ELSE 'sys' + LEFT(replace(ST.SheetName, ' ', ''), 28)
		END AS WorksheetName   
	, AnchorCell AS AnchorCell   
	
	, CASE WHEN IRDC.UploadedFileName IS NOT NULL THEN
			IRDC.UploadedFileName
		WHEN IRDC.TemplateID IS NULL THEN 
			CASE WHEN IRDC.UploadedFileName  IS NULL THEN 
					@defaultTemplateFile 
				 ELSE IRDC.UploadedFileName END
	  ELSE IRT.UploadedFileName END AS ExcelTemplateFile      
	  
	,  CASE WHEN IRDC.OriginalFileName IS NOT NULL THEN
		IRDC.OriginalFileName
		WHEN IRDC.TemplateID IS NOT NULL THEN
		isNull(IRT.OriginalFileName,  @defaultTemplateFile) 
		ELSE isNull(IRDC.OriginalFileName,  @defaultTemplateFile)  END AS [ExcelOutputFile]
	
	, 2 AS RowStartIndex, 1 AS   ColumnStartIndex  
	, DL.DealName + @ReportTitle + @irFilePeriod AS DownloadIrFileName  
	, @irFormatColStartIndex AS IrFormatColStartIndex
	, CASE WHEN CHARINDEX('ESMA_',@pReportTypeName) > 0  THEN @esmaFormatColEndIndex  ELSE  @irFormatColEndIndex END AS IrFormatColEndIndex
	, @irFormatRowStartIndex AS IrFormatRowStartIndex
	, CASE WHEN DL.DealTypeId = 25 THEN IsNull(@irFormatRowEndIndex_CB, 565) ELSE @irFormatRowEndIndex END AS IrFormatRowEndIndex
	, IsNull(IRSM.IsMappingSheetRequire,0) AS IsMappingSheetRequire
	FROM [cfgCW].[IR_DealIrConfig] IRDC 
	INNER JOIN [cfgCW].[IR_DealIrStratMap] IRSM ON IRDC.DealIrConfigId=IRSM.DealIrConfigId      
	INNER JOIN #TBLStrat ST ON ST.StratId = IRSM.StratId 
	INNER JOIN app.vwActiveDeal DL ON DL.DealID=IRDC.DealId  
	LEFT JOIN cfgCW.IR_Template IRT ON IRT.TemplateID=IRDC.TemplateID  AND IRDC.ReportTypeId = IRT.ReportTypeId
	
	
	WHERE IRDC.DealIrConfigId = @pDealIrConfigId  
	ORDER BY ST.StratTypeId, ST.StratName
    
END       

GO

