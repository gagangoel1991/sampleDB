USE [SFP_Securitisation]
GO
/****** Object:  StoredProcedure [CW].[spGetDeflagPoolList]    Script Date: 02-04-2023 18:23:26 ******/

IF OBJECT_ID('[CW].[spGetDeflagAdjustmentPoolList]') IS NOT NULL
	DROP PROCEDURE [CW].[spGetDeflagAdjustmentPoolList]

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [CW].[spGetDeflagAdjustmentPoolList]
/*-----------------------------------------------------
 * Author: Prashant Sharma
 * Date:	20.03.2023
 * Description:  It will provide the Deflag pool List.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
-- PoolPurposeId = 3 : PoolPurpose : Repurchase
-- PoolStatusId = 6 : Status : Complete
(	
	@poolAdjustmentId INT
) 
AS
BEGIN
	BEGIN TRY
		
		 SELECT pccam.PoolId
			   ,p.Name AS 'PoolName'
			   ,d.DealName
			   ,pp.PoolPurpose 
			   ,p.NumberOfAccount AS 'Account'
			   ,p.VintageDate
			   ,p.EffectiveDate
			   ,(Select Name As 'Brand' from [cfgCW].[DealBrand] Where DealBrandId IN (Select BrandId from cw.dailycollection Where DealId = d.DealId)) AS Brand
			   ,p.CurrentPoolAmount AS 'Balance'
			   ,pccam.PrincipalAdjustment
			   ,pccam.ReceiptAdjustment
			   ,pccam.CreatedDate
			   ,pccam.CreatedBy
			   ,pcca.ModifiedBy
			   ,pcca.ModifiedDate
			   ,pcca.AdjustmentProcessedDate
			   FROM [CW].[PoolCashCollectionAdjustmentMap] pccam
			   INNER JOIN [CW].[PoolCashCollectionAdjustment] pcca on pcca.PoolCashCollectionAdjustmentId = pccam.PoolCashCollectionAdjustmentId
			   INNER JOIN [ps].[Pool] p on p.PoolId = pccam.PoolId
			   INNER Join [ps].[PoolPurpose] pp on pp.PoolPurposeId = p.PoolPurposeId
		       INNER JOIN cfg.Deal d on pcca.SourceDealId = d.DealId
			   Where pccam.PoolCashCollectionAdjustmentId = @poolAdjustmentId

	

	END TRY
	BEGIN CATCH
		--Eat the exception
	END CATCH
END
GO