USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetPdlBreakdownDetails]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetPdlBreakDownDetails] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 04-05-2021 
--Description: GET PDL breakdown details 
--(PRE and Post)
--[cw].[spGetPdlBreakdownDetails] 14,,''
--==================================   
CREATE PROCEDURE [cw].[spGetPdlBreakdownDetails] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
	BEGIN TRY   
	
		SELECT 
			dn.Series,
			CONVERT(VARCHAR(10),ipd.IpdDate,103) AS IPDDate,
			pdlPre.OutstandingAmount AS Principal_bf,
			pdlPre.PDLAllocated AS PdlAllocated,
			pdlPre.PDLToBeCreditedInWaterfall AS PdlToBeCredited,
			pdlPost.ActualPDLCredited AS ActualPdlCredit,
			pdlPost.ClosingBalance AS NetPdl,
   pdlPost.ClosingBalance,
   pdlPre.OpeningBalance
		FROM 
			cw.pdlLedger_prewf pdlPre
		JOIN
			cw.dealipdrun dir ON dir.RunId=pdlPre.DealipdRunid 
		JOIN
			cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN
			cfgCW.DealNote dn ON pdlPre.DealNoteId=dn.DealNoteId 
		LEFT JOIN
			cw.PdlLedger_postwf pdlPost ON pdlPre.DealipdRunid=pdlPost.DealipdRunid AND pdlPost.DealNoteId=dn.DealNoteId 
		WHERE
			dir.RunId IN(SELECT RunId FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId,4))
			AND ipd.DealId=@pDealId 
			AND dn.IsNote=1 
		ORDER BY
			dn.Series DESC,ipd.IpdDate DESC, dn.NoteRank

	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spGetPdlBreakdownDetails', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH  
END
GO