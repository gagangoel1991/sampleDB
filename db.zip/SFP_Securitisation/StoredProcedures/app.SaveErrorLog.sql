USE [SFP_Securitisation]
GO
IF OBJECT_ID('[app].[SaveErrorLog]') IS NOT NULL
	DROP PROCEDURE [app].[SaveErrorLog]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[SaveErrorLog]
/*-----------------------------------------------------
 * Author: Kapil Sharma
 * Date:	1.06.2020
 * Description:  This will save the error log
 * 				
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
(
	@moduleId			SMALLINT = NULL,
	@logOriginTypeId	SMALLINT = 1, --1: db, 2: App
	@errorProcedure		VARCHAR(128),
	@errorNumber		INT = 0,
	@errorSeverity		INT = 0,
	@errorLine			INT = 0,
	@errorMsg			VARCHAR(1000),
	@userName           VARCHAR(40),
	@pLogId			INT = 0 OUTPUT
)
AS
BEGIN
	BEGIN TRY
		
		IF @userName  =''
			SELECT @userName = suser_sname();
			
		INSERT INTO [app].[ErrorLog](ModuleId, LogOriginTypeId, ErrorProcedure, ErrorNumber, ErrorSeverity, ErrorLine, ErrorMessage, UserName, ErrorTime) 
		VALUES (@moduleId, @logOriginTypeId, @errorProcedure, @errorNumber, @errorSeverity, @errorLine, @errorMsg, @userName, GETDATE());

		SELECT @pLogId = SCOPE_IDENTITY()

	END TRY
	BEGIN CATCH
		--Eat the exception
	END CATCH
END
GO
