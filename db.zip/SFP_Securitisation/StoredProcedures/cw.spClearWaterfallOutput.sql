USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spClearWaterfallOutput]') IS NOT NULL
	DROP PROC  [cw].[spClearWaterfallOutput]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA   
--Description: Clear Waterfall Output 
--[cw].[spResetDealIpd] 14,'2021-02-15',6,'EUROPA\CHAGJGA'
--==================================   
CREATE PROCEDURE [CW].[spClearWaterfallOutput]    
(    
 @pDealId SMALLINT,  
 @pIpdDate  DATETIME,      
 @pIpdRunId  INT,    
 @pUserName VARCHAR(80)    
)           
AS      
BEGIN     
 BEGIN TRY    
 DECLARE  @businessStartDate DATE,  
          @businessEndDate   DATE,  
          @maxBondRatingDate DATE,  
          @maxCPRatingDate   DATE,
          @dealType VARCHAR(100);
  
  BEGIN TRAN  
   SELECT  @businessStartDate = did.CollectionBusinessStart,   
           @businessEndDate = did.CollectionBusinessEnd  
          FROM cw.DealIpd di  
          JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId  
          JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId  
          WHERE dir.RunId = @pIpdRunId  
  
   SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

   IF (@dealType='Covered Bond')
	BEGIN
	     SET @maxBondRatingDate = ISNULL((  
              SELECT CAST(MAX(br.RatingDate) AS DATE)  
              FROM CW.vwBondRating br  
              JOIN [cfgCb].[DealNote] dn ON dn.ISIN = br.ISIN  
              WHERE CAST(br.RatingDate AS DATE) BETWEEN @businessStartDate  
                AND @businessEndDate  
               AND dn.DealId = @pDealId  
              ), @businessEndDate); 	
    END
	ELSE IF(@dealType='RMBS')
	BEGIN
	     SET @maxBondRatingDate = ISNULL((  
              SELECT CAST(MAX(br.RatingDate) AS DATE)  
              FROM CW.vwBondRating br  
              JOIN [cfgCW].[DealNote] dn ON dn.ISIN = br.ISIN  
              WHERE CAST(br.RatingDate AS DATE) BETWEEN @businessStartDate  
                AND @businessEndDate  
               AND dn.DealId = @pDealId  
              ), @businessEndDate); 	
    END  
    
  
     SET @maxCPRatingDate = ISNULL((  
      SELECT CAST(MAX(cp.RatingDate) AS DATE)  
      FROM CW.vwCounterpartyRating cp  
      JOIN [CW].[vw_ActiveDealCounterparty] dc ON dc.CisCode = cp.CisCode  
      WHERE CAST(cp.RatingDate AS DATE) BETWEEN @businessStartDate  
        AND @businessEndDate  
       AND dc.DealId = @pDealId  
      ), @businessEndDate);  
      
    DELETE FROM [cw].[RevenueWaterfallPayment] WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.RevenueWaterfallPaymentSummary WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.PrincipalWaterfallPayment WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.PrincipalWaterfallPaymentSummary WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.NoteData_PostWf WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.SubLoan_PostWF WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.ReserveFund_PostWF WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.PdlLedger_PostWf WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.Pdl_PostWf WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM cw.MiscLedger_PostWF WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM [cw].[InvoiceData_PostWF] WHERE DealIpdDate=@pIpdDate  
  
    DELETE FROM [CW].[WaterfallLineItemAmount_PostWF] WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM [cw].[DealIpdTriggerResult_PostWF] WHERE DealIpdRunId=@pIpdRunId  
  
    DELETE FROM [cw].[UserBondRating_PostWF] WHERE RatingDate=@maxBondRatingDate  
  
    DELETE FROM [CW].[UserCounterpartyRating_PostWF] WHERE RatingDate= @maxCPRatingDate  
  
    SELECT Replace(wc.InternalName, 'PreAvailable', 'PostAvailable') InternalName,RequiredAmount,AdjustedAmount,TotalRequiredAmount,wli.SortOrder  INTO #preTable  
    FROM cw.WaterfallLineItemAmount pwli JOIN cfgcw.WaterfallLineItem wli ON pwli.WaterfallLineItemId=wli.WaterfallLineItemId  
    JOIN  cfgcw.WaterfallCategory wc ON  wc.WaterfallCategoryId=wli.WaterfallCategoryId   
    JOIN  cw.vwDealIpdRun dir ON dir. DealId=wc. DealId  
    WHERE pwli.DealIpdRunId=dir.DealIpdRunId  
    AND dir.DealIpdRunId=@pIpdRunId  
    AND wc.InternalName IN ('PreAvailablePrincipalReceipts','PreAvailableRevenueReceipts')  
    ORDER BY wc.WaterfallCategoryId, wli.SortOrder  
  
    UPDATE pwli SET pwli.RequiredAmount=pre.RequiredAmount, pwli.AdjustedAmount=0, pwli.TotalRequiredAmount=pre.TotalRequiredAmount  
    FROM cw.WaterfallLineItemAmount pwli   
    JOIN cfgcw.WaterfallLineItem wli ON pwli.WaterfallLineItemId=wli.WaterfallLineItemId  
    JOIN  cfgcw.WaterfallCategory wc ON  wc.WaterfallCategoryId=wli.WaterfallCategoryId   
    JOIN  cw.vwDealIpdRun dir ON dir. DealId=wc. DealId  
    JOIN #preTable pre ON pre.InternalName=wc.InternalName  
    WHERE pwli.DealIpdRunId=dir.DealIpdRunId  
    AND dir.DealIpdRunId=@pIpdRunId  
    AND wli.Sortorder=pre.Sortorder  
    AND wc.InternalName IN ('PostAvailablePrincipalReceipts','PostAvailableRevenueReceipts')  
  COMMIT TRAN  
 END TRY        
 BEGIN CATCH      
  IF @@TRANCOUNT > 0    
    ROLLBACK TRAN    
  DECLARE       
   @errorMessage     NVARCHAR(MAX),      
   @errorSeverity    INT,      
   @errorNumber      INT,      
   @errorLine        INT,      
   @errorState       INT;      
      
  SELECT       
  @errorMessage = ERROR_MESSAGE()
  ,@errorSeverity = ERROR_SEVERITY()
  ,@errorNumber = ERROR_NUMBER()
  ,@errorLine = ERROR_LINE()
  ,@errorState = ERROR_STATE()      
      
  EXEC app.SaveErrorLog 1, 1, '[cw].[spClearWaterfallOutput]', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName      
        
  RAISERROR (@errorMessage, @errorSeverity,@errorState )      
 END CATCH      
END
GO