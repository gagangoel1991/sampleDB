USE SFP_Securitisation

GO


IF OBJECT_ID('[cw].[spGetDailyCollectionSummary]') IS NOT NULL
	DROP PROCEDURE [cw].spGetDailyCollectionSummary
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Arun  
Date:    07.07.2022  
Description:  This will Deal Summary status and other detail based on advice date.
Usage : [cw].spGetDailyCollectionSummary  '2023-05-11','Deimos'        
  
Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  
CREATE PROCEDURE [cw].spGetDailyCollectionSummary 
   @pAsAtDate DATE = null 
  ,@pDealName VARCHAR(255)
  ,@pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
BEGIN TRY  
   
   		DECLARE @dealId INT, @dealRegionCode VARCHAR(10);  
		Declare @collectionDate DateTime,
		@CurrentEuribor Decimal(38, 4),
		@DealSummaryMaxCollectionDate DateTime,
		@IsDeflag Varchar(2);

		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  
		SET @collectionDate = (SELECT [cw].[fnGetBusinessDate] (@pAsAtDate, @dealRegionCode, -1, 1))

		Declare @ProcessedDeflagWorkFlowStepId INT=0, @AuthoriseDeflagWorkFlowStepId INT=0
		, @DFlagTotalAdjustmentToBeProcess FLOAT =0, @DFlagProcesssedTotalAdjustment FLOAT =0;
		SET @ProcessedDeflagWorkFlowStepId = (Select  [cw].[fnGetWorkflowStepId]('Process','Deflag_Adjustment') )
		SET @AuthoriseDeflagWorkFlowStepId = (Select  [cw].[fnGetWorkflowStepId]('Authorise','Deflag_Adjustment') )
		
		SELECT @DFlagTotalAdjustmentToBeProcess=CAST(ISNULL(SUM(TotalPrincipalAdjustment),0) + IsNULL(SUM(TotalReceiptAdjustment),0) as DECIMAL(38,2))	
		FROM [CW].[PoolCashCollectionAdjustment] 
		Where WorkFlowStatusId=@AuthoriseDeflagWorkFlowStepId and @pAsAtDate >=CAST(AdjustmentProcessedDate as DATE)
	
		SET @DFlagProcesssedTotalAdjustment = (SELECT IsNull(SUM(TotalPrincipalAdjustment),0) + IsNull(SUM(TotalReceiptAdjustment),0) 
			FROM [CW].[PoolCashCollectionAdjustment] 
			Where WorkFlowStatusId=@ProcessedDeflagWorkFlowStepId and @pAsAtDate=CAST(AdjustmentProcessedDate as DATE)
			and SourceDealId=@dealId
			)
		

		SELECT  TOP 1 
		  dir.DealId,
		  did.CollectionBusinessEnd,
		  did.CollectionCalendarStart,
		  did.CollectionCalendarEnd,
		  did.PreviousIPD,
		  did.NextIpd,
		  did.RateResetDate
		  INTO #DealTrnDates
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		JOIN cw.vwDealIPDDates did ON did.DealIpdId = di.DealIpdId
		WHERE   
			deal.DealName = @pDealName
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)<= @collectionDate
			AND dir.IpdSequence <> 0
		Order by CollectionBusinessEnd DESC

		SET @DealSummaryMaxCollectionDate = (Select MAX(CollectionDate) FROM [CW].[DailyCollectionSummary] dcs Where DealId = @dealId)

		IF @pDealName='Dunmore1'
		BEGIN
			Declare @BaseDate DateTime
			SET @BaseDate = [cw].[fnGetBusinessDate] ( (Select Cast(RateResetDate as date) From #DealTrnDates), @dealRegionCode, 0, 1)
			Select @CurrentEuribor = Rate From cw.InterestRate where BaseDate=@BaseDate  and RICCode='EURIBOR3MD='
		END 

		SELECT dcs.DailyCollectionSummaryId, dcs.CollectionDate, dcs.[WorkFlowStepId], dcs.ModifiedBy, dcs.ModifiedDate, wfs.StepName
		, dtd.NextIpd, dtd.PreviousIPD as PreviousIpd, dtd.CollectionCalendarStart as CollectionAdvicestartDate, dtd.CollectionCalendarEnd as CollectionAdviceEndDate
		, dtd.RateResetDate as RateReset, IsNull(CAST(@CurrentEuribor as VARCHAR),'N/A') AS CurrentEuribor 
		, @DealSummaryMaxCollectionDate as DealSummaryMaxCollectionDate
		, @DFlagTotalAdjustmentToBeProcess as DFlagTotalAdjustmentToBeProcess
		,CASE WHEN ISNULL(@DFlagProcesssedTotalAdjustment,0) <> 0   THEN 2
			  WHEN ISNULL(@DFlagTotalAdjustmentToBeProcess,0) <> 0   THEN 1
			  ELSE 0
		 END As IsDeflagProcessed
		FROM [CW].[DailyCollectionSummary] dcs
		LEFT JOIN cfgCW.WorkflowStep wfs on wfs.WorkflowStepId= dcs.[WorkFlowStepId]
		LEFT JOIN  #DealTrnDates dtd on dtd.dealId=dcs.dealId
		Where CollectionDate= @collectionDate and dcs.dealId=@dealId

END TRY
		BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionSummary', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH

END

GO