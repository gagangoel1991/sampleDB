USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spIR_GetSetOff') IS NOT NULL
	DROP PROC CW.spIR_GetSetOff
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:    08.07.2021
 * Description:  This will return set off values for Investor report.
 * Usage : CW.spIR_GetSetOff @pAsAtDate  = '30-JUL-2021'
 * 		,@pDealName  = 'ARDMORE1'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spIR_GetSetOff @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN
				
				
BEGIN TRY
	
	DECLARE @dealId int

	SELECT @dealId = dealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	
	SELECT daf.Description AS [~HeaderText],
	isNull(dad.LoanBalance,0) AS [Total SetOff Amount], 
	isNull(dad.WeightedAvgBalance, 0) AS [Average SetOff Amount]
	FROM  cfgCW.DealAggregatedField daf 
	LEFT JOIN cw.DealAggregatedData dad ON daf.DealAggregatedFieldId = dad.DealAggregatedFieldId AND  dad.CorrelatedDate =@pAsAtDate
	LEFT JOIN cfg.Deal d ON d.DealId = daf.DealId AND dad.DealId=daf.dealId
	WHERE  daf.FieldName IN ('Setoff_1', 'Setoff_2')  
	AND daf.DealId=@dealId
	ORDER BY daf.FieldName
  
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'spIR_GetSetOff', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END
			   
GO

