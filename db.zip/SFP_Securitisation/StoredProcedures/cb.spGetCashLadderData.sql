USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spGetCashLadderData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetCashLadderData]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================
--Author: Ravindra Singh
--Date:	24-Nov-2020
--Description:  To get Cash Ledger List on basis 
--				 CollectionBusinessStart AND CollectionBusinessEnd

-- Exec cb.spGetCashLadderData  6,1034,''
--================================== 
CREATE PROC [cb].[spGetCashLadderData] 
    @pDealId SMALLINT,
    @pIPDRunId INT,
	   @pUserName		VARCHAR(80) 
AS
BEGIN
SET NOCOUNT ON
BEGIN TRY
    DECLARE @collectionStartDate DATE,@collectionEndDate DATE

	SELECT	
			@collectionStartDate = CAST(CollectionBusinessStart AS DATE), 
			@collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
   SELECT * INTO #tempCashLadder FROM cw.CashLadder_WIP WHERE IsActive=1
   SELECT 
       CashLadderId,
       CollectionDateTime AS CollectionDate,
	   CorrespondentAccountNumber,
        DealReference,
		Product,
		SubProduct,
		CounterParty,
		ContextName,
		Rate,
		MaturityDate,
		Currency,
		InflowAmount,
		OutflowAmount,
		FlowSubTotal,
		Version
        Status,
		ModifiedBy,
		ModifiedDate,
	    Reason FROM (
        SELECT 
			cl.CashLadderId 
			,cl.CollectionDate AS CollectionDateTime
			,wip.Id AS WIPId
			,ROW_NUMBER() OVER(PARTITION BY cl.CollectionDate ORDER BY Id DESC) AS RowNum,
			cl.CorrespondentAccountNumber,
			cl.DealReference,
			cl.Product,
			cl.SubProduct,
			cl.CounterParty,
			cl.ContextName,
			CAST(IIF(wip.CashLadderId IS NOT NULL, ROUND(WIP.Rate,4), ROUND(CL.Rate,4))AS DECIMAL(30,8)) AS Rate,
			cl.MaturityDate,
			cl.Currency,
			CAST(IIF(wip.CashLadderId IS NOT NULL, ROUND(WIP.InflowAmount,4), ROUND(CL.InflowAmount,4))AS DECIMAL(30,8)) AS InflowAmount,
			CAST(IIF(wip.CashLadderId IS NOT NULL, ROUND(WIP.OutflowAmount,4), ROUND(CL.OutflowAmount,4))AS DECIMAL(30,8)) AS OutflowAmount,
			CAST(IIF(wip.CashLadderId IS NOT NULL, ROUND(WIP.FlowSubTotal,4), ROUND(CL.FlowSubTotal,4))AS DECIMAL(30,8)) AS FlowSubTotal,	
			cl.Version
			,CASE WHEN wip.CashLadderId IS NOT NULL THEN wip.Status WHEN wip.CashLadderId IS NULL THEN wip.Status END AS [Status]
			,IIF(wip.CashLadderId IS NOT NULL, WIP.CreatedBy, '') AS ModifiedBy
			,IIF(wip.CashLadderId IS NOT NULL, WIP.CreatedDate,cl.CreatedDate) AS ModifiedDate
			,WIP.ChangeReason AS Reason
          FROM cw.CashLadder cl
          LEFT JOIN #tempCashLadder wip ON cl.CashLadderId = wip.CashLadderId
           WHERE cl.DealId =@pDealId 
           AND CAST(cl.CollectionDate AS DATE) BETWEEN @collectionStartDate AND @collectionEndDate
		)t  
           WHERE t.RowNum=1 ORDER BY CAST(t.ModifiedDate AS DATE) DESC, t.CollectionDateTime 
           
END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'GetCollectionLedger', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END 
GO

