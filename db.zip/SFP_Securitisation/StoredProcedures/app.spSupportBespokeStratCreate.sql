USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[app].[spSupportBespokeStratCreate]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [app].[spSupportBespokeStratCreate]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 21-March-2023
Description    : This will help in creating bespoke asset strats
Execution      : EXEC [app].[spSupportBespokeStratCreate] 'Summary Data', 'Summary Data', 'IR', '[app].[spStratificationSummaryData]', 'Text', 'SRT' 2
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [app].[spSupportBespokeStratCreate]
	@pStratName VARCHAR(100),
	@pStratDescription VARCHAR(300),
	@pReportTypeName VARCHAR(50),
	@pStoredProcName VARCHAR(200),
	@pFieldDataTypeName VARCHAR(20),
	@pDealType VARCHAR(50),
	@pAssetClassId INT = 1
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE @CurrentDateTime DATETIME = GETDATE() 
		DECLARE @UserName VARCHAR(20) = 'System'
		DECLARE @Active BIT = 1
		DECLARE @StratTypeId INT = (SELECT TOP (1) StratTypeId FROM cfgCW.IR_StratType WHERE [Name] = 'Asset')
		DECLARE @ReportTypeId INT = (SELECT TOP (1) ReportTypeId FROM cfgCW.IR_ReportType WHERE [ReportTypeName] = @pReportTypeName)
		DECLARE @FieldDataTypeLookupId INT
		DECLARE @FieldTypeLookupId INT
		DECLARE @StratId INT
		DECLARE @BespokeStratId INT
		DECLARE @DealTypeId INT

		SET @FieldDataTypeLookupId = (SELECT TOP (1) lookupValue.LookupValueId FROM cfgCW.DealLookupValue lookupValue
										INNER JOIN cfgCW.DealLookupType lookupType ON lookupValue.LookupTypeId = lookupType.LookupTypeId
										WHERE lookupType.TypeCode = 'FieldDataType' AND	lookupValue.Name = @pFieldDataTypeName)

		SET @FieldTypeLookupId = (SELECT TOP (1) lookupValue.LookupValueId FROM cfgCW.DealLookupValue lookupValue
									INNER JOIN cfgCW.DealLookupType lookupType ON lookupValue.LookupTypeId = lookupType.LookupTypeId
									WHERE lookupType.TypeCode = 'IR_FieldType' AND	lookupValue.Name = 'Bespoke Field')
		
		SET @DealTypeId = (SELECT TOP (1) lookupValue.LookupValueId FROM cfgCW.DealLookupValue lookupValue
							INNER JOIN cfgCW.DealLookupType lookupType ON lookupValue.LookupTypeId = lookupType.LookupTypeId
							WHERE lookupType.TypeCode = 'DealType' AND	lookupValue.Name = @pDealType)
		
		IF NOT EXISTS (SELECT 1 FROM [cfgCW].[IR_Strat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId AND [ReportTypeId] = @ReportTypeId)
		BEGIN 
			INSERT INTO [cfgCW].[IR_Strat]
				([StratTypeId]
				,[Name]
				,[Description]
				,[IsLocked]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate]
				,[ReportTypeId]
				,[AssetClassId])
			VALUES
					(@StratTypeId
					,@pStratName
					,@pStratDescription
					,1
					,@UserName
					,@CurrentDateTime
					,@UserName
					,@CurrentDateTime
					,@ReportTypeId
					,@pAssetClassId)

			PRINT ('Inserted "' + @pStratName + '" strat into [cfgCW].[IR_Strat]')
		END
		ELSE 
		BEGIN
			UPDATE [cfgCW].[IR_Strat]
			SET [StratTypeId] = @StratTypeId
				,[Description] = @pStratDescription
				,[IsLocked] = 1
				,[ModifiedBy] = @UserName
				,[ModifiedDate] = @CurrentDateTime
			WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId AND [ReportTypeId] = @ReportTypeId

			PRINT ('"' + @pStratName + '" strat updated in [cfgCW].[IR_Strat]')
		END

		IF NOT EXISTS (SELECT 1 FROM [cfgCW].[IR_BespokeStrat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId AND IsActive = @Active)
		BEGIN 
			INSERT INTO [cfgCW].[IR_BespokeStrat]
				([Name]
				,[Description]
				,[FieldDataTypeLookupId]
				,[RelatedStoredProc]
				,[IsActive]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate]
				,[ReportTypeId]
				,[AssetClassId])
			VALUES
					(@pStratName
					,@pStratDescription
					,@FieldDataTypeLookupId
					,@pStoredProcName
					,@Active
					,@UserName
					,@CurrentDateTime
					,@UserName
					,@CurrentDateTime
					,@ReportTypeId
					,@pAssetClassId)

			PRINT ('Inserted "' + @pStratName + '" strat into [cfgCW].[IR_BespokeStrat]')
		END
		ELSE 
		BEGIN
			UPDATE [cfgCW].[IR_BespokeStrat]
			SET [Description] = @pStratDescription
				,[FieldDataTypeLookupId] = @FieldDataTypeLookupId
				,[RelatedStoredProc] = @pStoredProcName
				,[IsActive] = @Active
				,[ModifiedBy] = @UserName
				,[ModifiedDate] = @CurrentDateTime
				,[ReportTypeId] = @ReportTypeId
			WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId

			PRINT ('"' + @pStratName + '" strat updated in [cfgCW].[IR_BespokeStrat]')
		END
			



		SET @StratId = (SELECT StratId FROM [cfgCW].[IR_Strat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId)
		SET @BespokeStratId = (SELECT BespokeStratId FROM [cfgCW].[IR_BespokeStrat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId AND IsActive = @Active)

		IF NOT EXISTS (SELECT 1 FROM [cfgCW].[IR_AssetStrat] WHERE [StratId] = @StratId AND [ReportTypeId] = @ReportTypeId)
		BEGIN 
			INSERT INTO [cfgCW].[IR_AssetStrat]
					([StratId]
					,[FieldId]
					,[FieldTypeLookupId]
					,[CreatedBy]
					,[CreatedDate]
					,[ModifiedBy]
					,[ModifiedDate]
					,[BespokeStratId]
					,[ReportTypeId]
					,[ReportLookupDbId])
			VALUES
					(@StratId
					,NULL
					,@FieldTypeLookupId
					,@UserName
					,@CurrentDateTime
					,@UserName
					,@CurrentDateTime
					,@BespokeStratId
					,@ReportTypeId
					,NULL)

			PRINT ('Inserted "' + @pStratName + '" strat into [IR_AssetStrat]')
		END
		ELSE 
		BEGIN
			UPDATE [cfgCW].[IR_AssetStrat]
				SET [FieldId] = NULL
					,[FieldTypeLookupId] = @FieldTypeLookupId
					,[ModifiedBy] = @UserName
					,[ModifiedDate] = @CurrentDateTime
					,[BespokeStratId] = @BespokeStratId
					,[ReportLookupDbId] = NULL
			WHERE [StratId] = @StratId AND [ReportTypeId] = @ReportTypeId

			PRINT ('"' + @pStratName + '" strat updated in [IR_AssetStrat]')
		END

		IF NOT EXISTS (SELECT 1 FROM [cfgCW].[IR_StratDealTypeMap] WHERE [StratId] = @StratId AND [StratDealTypeId] = @DealTypeId AND IsActive = @Active)
		BEGIN 
			INSERT INTO [cfgCW].[IR_StratDealTypeMap]
				([StratId]
				,[StratDealTypeId]
				,[IsActive]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate])
			VALUES
				(@StratId
				,@DealTypeId
				,@Active 
				,@UserName
				,@CurrentDateTime
				,@UserName
				,@CurrentDateTime)
		
			PRINT ('Inserted "' + @pStratName + '" strat with deal type "' + @pDealType + '" into [cfgCW].[IR_StratDealTypeMap]')
		END
		ELSE 
		BEGIN
			UPDATE [cfgCW].[IR_StratDealTypeMap]
			SET [IsActive] = @Active
				,[ModifiedBy] = @UserName
				,[ModifiedDate] = @CurrentDateTime
			WHERE [StratId] = @StratId AND [StratDealTypeId] = @DealTypeId 

			PRINT ('"' + @pStratName + '" strat with deal type "' + @pDealType + '" updated in [cfgCW].[IR_StratDealTypeMap]')
		END
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
