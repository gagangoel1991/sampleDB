USE [SFP_Securitisation]
GO

IF OBJECT_ID('corp.getDealSecurityListItems') IS NOT NULL
	DROP PROCEDURE corp.getDealSecurityListItems
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
/*  =============================================================================
	Author: Sakthivel Loganathan 
	Date: 10 Mar 2023  
	Description:  To get deal's security configuration data 

	EXEC corp.getDealSecurityListItems '22','loga'
    ============================================================================== */

CREATE PROC corp.getDealSecurityListItems
(
	@pDealId INT = 0,
	@pUserName VARCHAR(50) = 'System'
)
AS
BEGIN
			CREATE TABLE #Tmp_DealSecListItems
			(
				PageLookUpValueMapId INT,
				DealId INT,
				Val VARCHAR(100),
				[Name] VARCHAR(150),
				IsSelected INT,
				IsExcluded INT,
				TypeId  INT,
				IsSaved INT
			)

			INSERT INTO #Tmp_DealSecListItems
			SELECT 0,
				   @pDealId,
				   LookUpValue AS Val,
				   LookUpValueDescription AS [Name],
				   0 AS IsSelected,
				   0 AS IsExcluded,
				   CASE WHEN LookUpName = 'SecurityType' THEN 1 
						WHEN LookUpName = 'SecuritySubTypeCode' THEN 2
						WHEN LookUpName = 'SecurityStatusCode' THEN 3
						ELSE 0 END  AS TypeId,
				  0 AS IsSaved
			FROM sfp.syn_SfpModel_vw_ref_vw_ReportLookUpData_v1
			WHERE ReportTemplateName = 'SFP+' and LookUpName  IN ('SecurityType','SecuritySubTypeCode','SecurityStatusCode')


			-- GETTING SAVED VALUES AND UPDATE 'IsSelected' flag
			DECLARE @ListingPageId INT = (SELECT ListingPageId FROM APP.ListingPage WHERE ListingPageName = 'Deal')
			--DECLARE @PageLookUpMapId INT = (SELECT PageLookUpMapID FROM [cfg].[PageLookUpMap] WHERE LookUpName = 'SecurityType' AND AssetClassId = 2 AND ListingPageId = @ListingPageId)

			SELECT Id As DealId, map.PageLookUpMapID,  LookUpValue as [Val], LookUpName, 
				   CASE WHEN LookUpName = 'SecurityType' THEN 1
					 WHEN LookUpName = 'SecuritySubTypeCode' THEN 2 
					 WHEN LookUpName = 'SecurityStatusCode' THEN 3 END As TypeID
			INTO #TmpSavedDealSecConfig
			FROM [cfg].[PageLookUpValueMap] map 
			inner join [cfg].[PageLookUpMap] pag ON map.PageLookUpMapID = pag.PageLookUpMapID 
			WHERE ID = @pDealId AND ListingPageId = @ListingPageId and AssetClassId = 2 


			UPDATE items
			SET IsSelected = 1, IsSaved = 1  
			FROM #Tmp_DealSecListItems items
			INNER JOIN #TmpSavedDealSecConfig sdsc ON items.Val = sdsc.Val AND items.TypeId = sdsc.TypeID


			SELECT * FROM #Tmp_DealSecListItems ORDER BY TypeId, Val

END

GO