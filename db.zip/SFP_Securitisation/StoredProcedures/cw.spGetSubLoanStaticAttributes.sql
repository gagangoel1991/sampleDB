USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetSubloanStaticAttributes]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetSubloanStaticAttributes] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 27-04-2021 
--Description: GET sub loan static attr 
--(PRE and Post)
--[cw].[spGetSubloanStaticAttributes] 14,3,''
--==================================   
CREATE PROCEDURE [cw].[spGetSubloanStaticAttributes] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  
BEGIN TRY   
      SELECT 
		sl.SubLoanTypeId AS SubloanTypeId, sl.DisplayName AS ApplicableSubLoan,sl.InitialAmount,sl.LimitAmount,
		CASE dlv.[Value] WHEN 'FIXED' THEN 'N/A' ELSE CAST(sl.Margin AS VARCHAR(50)) END  AS Margin,
		CASE dlv.[Value] WHEN 'FIXED' THEN 'N/A' ELSE CAST(dlv.[Value] AS VARCHAR(300)) END AS RateType
		 FROM cfgcw.dealsubloan sl
	JOIN 
		cw.subloan_prewf spre ON sl.DealsubloanId=spre.DealsubloanId
	JOIN 
		cw.dealipdrun dir ON dir.RunId=spre.DealipdRunid 
	JOIN 
		cw.DealIpd ipd ON dir.DealIpdId=ipd.DealIpdId
	JOIN 
		cfgCW.DealLookupValue dlv ON sl.RateTypeId=dlv.LookupValueId   
	LEFT JOIN 
		cw.subloan_postwf spost ON spre.DealipdRunid=spost.DealipdRunid AND spre.DealsubloanId=spost.DealsubloanId 
	WHERE 
		ipd.DealId=@pDealId AND dir.RunId=@pIPDRunId
    
END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'cw.spGetSubloanStaticAttributes', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END
GO
