USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spSaveWIPDealNoteInformation]') IS NOT NULL
	DROP PROCEDURE [cb].[spSaveWIPDealNoteInformation] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--================================== 
/* 
--Author: RAVINDRA SINGH  
--Date: 10-07-2022 
--Description: save Deal Note WIP Information
DECLARE  @pReturnCode SMALLINT 
EXEC [cb].[spSaveWIPDealNoteInformation] 2,6,'Series 8','XS0731407655','2022-06-13','2022-06-13','2022-12-22','','','',@pReturnCode =@pReturnCode  OUTPUT
Select @pReturnCode 
*/
--==================================   
CREATE PROCEDURE [cb].[spSaveWIPDealNoteInformation] 
	@pDealNoteId   INT
	,@pDealId INT
	,@pName varchar(50)
	,@pISIN varchar(50)
   ,@pValidFrom DATETIME
   ,@pValidTo DATETIME	
	,@pNewRedemptionDate DATETIME
	,@pAuthorizerComment VARCHAR(max) = NULL
	,@pDealStatusId TINYINT =NULL
	,@pUserName VARCHAR(256)
	,@pReturnCode SMALLINT = - 1 OUTPUT
AS  
BEGIN 
BEGIN TRY
		DECLARE @processReferenceId INT
			,@workflowType VARCHAR(100) = 'New_Deal_Onboarding'
			,@stepName VARCHAR(50)
			,@displayName VARCHAR(50)


		IF EXISTS (SELECT 1
				FROM cfgcb.DealNote
				WHERE DealNoteId = @pDealNoteId
				 AND NewRedemptionDate =@pNewRedemptionDate )
		BEGIN

			SET @pReturnCode = -1

		END 
		
		ELSE
		
		BEGIN	
			IF(@pDealStatusId IS NOT NULL)
			BEGIN
				SELECT @stepName = StepName
				FROM cfgCW.WorkflowStep
				WHERE WorkflowStepId = @pDealStatusId

				DECLARE @dealStatusID INT = cw.fnGetWorkflowStepId(@stepName, @workflowType)
			END

			IF EXISTS (
					SELECT 1
					FROM cfgcb.DealNote_WIP
					WHERE DealNoteId = @pDealNoteId
					) --DRAFT
			BEGIN
				UPDATE cfgcb.DealNote_WIP
				SET NewRedemptionDate = @pNewRedemptionDate
					,DealStatusId = @pDealStatusId
					,ChangeReason = @pAuthorizerComment
					,CreatedDate = GETDATE()
					,IsActive=1
				WHERE DealNoteId = @pDealNoteId
					--END
			END
			ELSE
			BEGIN
				INSERT INTO cfgcb.DealNote_WIP (
					[DealNoteId]
					,[DealId]
					,[Name]
					,[ISIN]
					,[ValidFrom]
					,[ValidTo]				
					,[NewRedemptionDate]
					,[DealStatusId]
					,[ChangeReason]
					,[IsActive]
					,[CreatedBy]
					,[CreatedDate]
					,[ModifiedBy]
					,[ModifiedDate]
					)
				VALUES (
					@pDealNoteId,
					@pDealId
					,@pName
					,@pISIN
					,@pValidFrom
					,@pValidTo
					,@pNewRedemptionDate
					,@pDealStatusID
					 ,@pAuthorizerComment
					,1
					,@pUserName
					,GETDATE()
					,@pUserName
					,GETDATE()
					)			
			END

			SET @pReturnCode = 1

		END
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spSaveWIPDealNoteInformation'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)

		SET @pReturnCode = - 1
	END CATCH
END
GO
