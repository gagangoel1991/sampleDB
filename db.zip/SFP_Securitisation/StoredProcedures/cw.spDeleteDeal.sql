
USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spDeleteDeal]') IS NOT NULL
	DROP PROCEDURE [cw].[spDeleteDeal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spDeleteDeal]
	--==================================
	--Author: Gunjan Chandola
	--Date:	12-01-2021
	--Description:  To delete a deal created by user
	--==================================
	@pDealId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY

		IF EXISTS(SELECT '1' FROM [cfg].[Deal] d JOIN cfgCW.DealLookupValue dlvDealStatus ON d.DealStatusId = dlvDealStatus.LookupValueId     
				WHERE DealId = @pDealId AND dlvDealStatus.[Name] <> 'Active')
		BEGIN
			DECLARE @ListingPageId INT = (SELECT ListingPageId FROM APP.ListingPage WHERE ListingPageName = 'DEAL')
			DELETE FROM [cfg].[PageLookUpValueMap]
			WHERE PageLookUpMapId IN (SELECT PageLookUpMapID 
								FROM [cfg].[PageLookUpMap] 
								WHERE ListingPageId = @ListingPageId 
								AND LookUpName IN( 'SecurityType','SecuritySubTypeCode','SecurityStatusCode') 
								AND AssetClassId = 2)
			AND ID = @pDealId
		END


		DELETE d
		FROM [cfg].[Deal] d
		JOIN cfgCW.DealLookupValue dlvDealStatus ON d.DealStatusId = dlvDealStatus.LookupValueId --Deal Status	 
		WHERE DealId = @pDealId
			AND dlvDealStatus.[Name] <> 'Active'
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		IF @@TRANCOUNT > 0
			EXEC app.SaveErrorLog 2
				,1
				,'cw.spDeleteDeal'
				,@errorNumber
				,@errorSeverity
				,@errorLine
				,@errorMessage
				,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH;
END
GO
