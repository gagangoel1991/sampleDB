USE SFP_Securitisation

IF OBJECT_ID('cw.spIR_GetLoanRedemptionsReplenishments') IS NOT NULL
	DROP PROC cw.spIR_GetLoanRedemptionsReplenishments
GO

/*
 * ---------------------------------------------------
 * Author: Arun 
 * Date:	09-Feb-2022
 * Description: This SP is Used to Get Loan Redemptions and Replenishments
 * 
 * EXEC cw.spIR_GetLoanRedemptionsReplenishments '2021-05-28','DEIMOS'
 * ---------------------------------------------------
*/
CREATE PROCEDURE cw.spIR_GetLoanRedemptionsReplenishments
	 @pAsAtDate DATETIME
	,@pDealName VARCHAR(500)
	,@pUserName VARCHAR(50) = NULL
AS
BEGIN
	BEGIN TRY
		
		DECLARE @dealId              SMALLINT,
		@dealTypeId			INT,
		@mortgageDealId		INT,
		@currentTotalLoanCount numeric,
		@currentTotalCapitalBalance decimal(38,12),
		@previousTotalLoanCount numeric,
		@previousTotalCapitalBalance decimal(38,12),
		@previousAsAtDate Date,
		@partitionId INT,
		@previousPartitionId INT;

		DECLARE @LoanRedemptionCount INT;
        DECLARE @LoanSoldCount INT;
        DECLARE @LoanBoughtBackCount INT;
        DECLARE @LoanRedemptionAmount DECIMAL(19, 9);
        DECLARE @LoanSoldAmount DECIMAL(19, 9);
        DECLARE @LoanBoughtBackAmount DECIMAL(19, 9)  = 0;

		SELECT 
		@previousAsAtDate = PreviousIPDCollectionBusinessEnd
		FROM   
		cw.vwDealIpdDates dt
			JOIN		cw.vwDealIpdRun dir ON dt.DealIpdId = dir.DealIpdId AND dir.DealId = dt.DealId
		WHERE	dir.InternalDealName = @pDealName
			AND CAST(dt.CollectionBusinessEnd AS DATE)= CAST(@pAsAtDate AS DATE)

		SELECT @dealTypeId = DealTypeId, @dealId = DealId, @mortgageDealId=MortgageDealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName

		SET @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
		SET @previousPartitionId = CONVERT(INT, CONVERT(VARCHAR(8), @previousAsAtDate, 112))

		SELECT @previousTotalLoanCount = COUNT(fmsa.MortgageSubAccountKey)
             , @previousTotalCapitalBalance = SUM(fmsa.TotalOutstandingCapitalBalance)
        FROM   [sfp].[syn_SfpModel_vw_FactMortgageSubAccount_v1] AS fmsa
               JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS msa
                    ON fmsa.MortgageSubAccountKey = msa.MortgageSubAccountKey
        WHERE  fmsa.PartitionID = @previousPartitionId
               AND fmsa.MortgageDealKey = @mortgageDealId
               AND msa.InceptionDate <> '0001-01-01'
               AND msa.ProcessStatus <> 1;

		--SELECT @currentTotalLoanCount = COUNT(fmsa.MortgageSubAccountKey)
  --           , @currentTotalCapitalBalance = SUM(fmsa.TotalOutstandingCapitalBalance)
  --      FROM   [sfp].[syn_SfpModel_vw_FactMortgageSubAccount_v1] AS fmsa
  --             JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS msa
  --                  ON fmsa.MortgageSubAccountKey = msa.MortgageSubAccountKey
  --      WHERE  fmsa.PartitionID = @partitionId
  --             AND fmsa.MortgageDealKey = @mortgageDealId
  --             AND msa.InceptionDate <> '0001-01-01'
  --             AND msa.ProcessStatus <> 1;
	
		SELECT DISTINCT msa.LoanID,msa.SubAccountNumber 
		INTO #LoansRedeemed 
		FROM [sfp].[syn_SfpModel_vw_Fact_MortgageSubAccountSecTransaction_v1] fsat
			JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] msa
			ON msa.MortgageSubAccountKey = fsat.MortgageSubAccountKey
			AND msa.InceptionDate <> '0001-01-01'
			AND msa.ProcessStatus <> 1
			AND fsat.PartitionID > @previousPartitionId AND fsat.PartitionID <= @partitionId
			AND fsat.MortgageDealKey = @MortgageDealId AND fsat.FullRedemptionCapitalPaid <> 0
			ORDER BY msa.LoanID,msa.SubAccountNumber
		
		SELECT @LoanRedemptionCount = COUNT(1) FROM #LoansRedeemed;
		
        SELECT @LoanRedemptionAmount = SUM(FullRedemptionCapitalPaid)
        FROM   [sfp].[syn_SfpModel_vw_Fact_MortgageSubAccountSecTransaction_v1]
        WHERE  PartitionID > @previousPartitionId
               AND PartitionID <= @partitionId
               AND MortgageDealKey = @MortgageDealId;


		SELECT msa.LoanID
             , msa.SubAccountNumber
             , fmap.MortgageSubAccountKey
             , fmap.CapitalBalanceAtDeflagged
             , cldrdeflag.AsAtDate
        INTO #BoughtBackInfo
        FROM   [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool] AS fmap
               JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS msa ON msa.MortgageSubAccountKey = fmap.MortgageSubAccountKey
               JOIN [sfp].[syn_SfpModel_vw_Calendar_v1] AS cldrdeflag ON cldrdeflag.AsAtDateKey = fmap.DeFlaggedDateKey
                       AND cldrdeflag.AsAtDate > @previousAsAtDate
                       AND cldrdeflag.AsAtDate < @pAsAtDate
                       AND fmap.DeFlaggedDateKey <> -1
                       AND msa.InceptionDate <> '0001-01-01' -- Have to skip closed accounts
                       AND msa.ProcessStatus <> 1
                       AND fmap.MortgageDealKey = @MortgageDealId;

        SELECT @LoanBoughtBackCount = COUNT(DISTINCT bbi.MortgageSubAccountKey)
        FROM   #BoughtBackInfo AS bbi;

        SELECT DISTINCT 
               AsAtDate
        INTO #DateInfo
        FROM   #BoughtBackInfo;
        WHILE EXISTS
        (
            SELECT *
            FROM   #DateInfo
        )

        BEGIN
            DECLARE @tempDate DATE = '';
            DECLARE @PrevtempDate DATE = '';
            DECLARE @PrevDatePartitionID INT;
            DECLARE @localTotalBalance DECIMAL(19, 9)  = 0;

            --Find the date for which data to be fetched out
            SET @tempDate =
            (
                SELECT TOP 1 AsAtDate
                FROM         #DateInfo
                ORDER BY AsAtDate DESC
            );
            --FInd previous working day
            SET @PrevtempDate =
            (
                SELECT TOP 1 AsAtDate
                FROM         [sfp].[syn_SfpModel_vw_Calendar_v1]
                WHERE        RegionCode = 'UK'
                             AND AsAtDate < @tempDate
                             AND IsWorkingDay = 1
                ORDER BY AsAtDate DESC
            );
            SET @PrevDatePartitionID = CONVERT(INT, CONVERT(VARCHAR(8), @PrevtempDate, 112));
            WITH CalculationCTE
                 AS (SELECT *
                     FROM   #BoughtBackInfo
                     WHERE  AsAtDate =
                     (
                         SELECT TOP 1 AsAtDate
                         FROM         #DateInfo
                         ORDER BY AsAtDate DESC
                     ))

                 --Now Get the total poutstanding Capital Balance Amount
                 SELECT @localTotalBalance = SUM(ISNULL(A.TotalOutstandingCapitalBalance, 0))
                 FROM   [sfp].[syn_SfpModel_vw_FactMortgageSubAccount_v1] AS A
                        JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS B
                             ON A.MortgageSubAccountKey = B.MortgageSubAccountKey
                        JOIN CalculationCTE AS C
                             ON B.LoanID = C.LoanID
                                AND B.SubAccountNumber = C.SubAccountNumber
                                AND A.PartitionID = @PrevDatePartitionID
                                AND B.InceptionDate <> '0001-01-01' -- Have to skip closed accounts
                                AND B.ProcessStatus <> 1;
            SET @LoanBoughtBackAmount = @LoanBoughtBackAmount + @localTotalBalance;
            DELETE FROM #DateInfo
            WHERE       AsAtDate = @tempDate;
        END;


		--Start work on Loan sold into Cover Pool
        --Start processing of Loan Sold Information';
        SELECT msa.LoanId
             , msa.SubAccountNumber
             , fmap.MortgageSubAccountKey
             , cldr.AsAtDate AS AsAtDateFlagged
             , cldrdeflag.AsAtDate AS DeflagDate
             , fmap.DeFlaggedDateKey
        INTO #flaggingInfo
        FROM   [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool] AS fmap
               JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS msa
                    ON msa.MortgageSubAccountKey = fmap.MortgageSubAccountKey
               JOIN  [sfp].[syn_SfpModel_vw_Calendar_v1] AS cldr
                    ON cldr.AsAtDateKey = fmap.FlaggedDateKey
                       AND fmap.MortgageDealKey = @mortgageDealId
                       AND cldr.AsAtDate > @previousAsAtDate
                       AND cldr.AsAtDate <= @pAsAtDate
               JOIN [sfp].[syn_SfpModel_vw_Calendar_v1] AS cldrdeflag
                    ON cldrdeflag.AsAtDateKey = fmap.DeFlaggedDateKey
                       AND (cldrdeflag.AsAtDate <= @previousAsAtDate
                            OR cldrdeflag.AsAtDate > @pAsAtDate)
                       AND msa.InceptionDate <> '0001-01-01' -- Have to skip closed accounts
                       AND msa.ProcessStatus <> 1
                       AND fmap.IsFurtherAdvance = 0
                       AND fmap.IsBalanceTransfer = 0;
        
		
		SELECT @LoanSoldCount = COUNT(MortgageSubAccountKey)
        FROM   #flaggingInfo;

        SELECT @LoanSoldAmount = SUM(fmsa.TotalOutstandingCapitalBalance)
        FROM   [sfp].[syn_SfpModel_vw_FactMortgageSubAccount_v1] AS fmsa --20040
               JOIN [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] AS msa
                    ON msa.MortgageSubAccountKey = fmsa.MortgageSubAccountKey
               JOIN #FlaggingInfo AS fi
                    ON msa.LoanID = fi.LoanID
                       AND msa.SubAccountNumber = fi.SubAccountNumber
                       AND fmsa.PartitionID = @partitionId
                       AND fmsa.MortgageDealKey = @mortgageDealId
                       AND msa.InceptionDate <> '0001-01-01' -- Have to skip closed accounts
                       AND msa.ProcessStatus <> 1;
      
      
		


		CREATE TABLE #Summary ( SortOrder INT, Header varchar(255), LoanCount numeric, TotalCapitalBalance Decimal(38,12))

		INSERT INTO #Summary
		SELECT 3, 'of which are non-performing loans' AS Header, IsNull(SUM(pool.NumberOfSubAccount),0) AS LoanCount, Cast(IsNull(SUM(pool.CapitalBalance),0) AS decimal(38,12)) AS TotalCapitalBalance
		FROM ps.pool pool
		JOIN [ps].[PoolEcMap] ecmap ON ecmap.PoolId = pool.PoolId
		JOIN ps.EligibilityCriteria ec ON ec.EligibilityCriteriaId = ecmap.EligibilityCriteriaId
		WHERE pool.PoolPurposeId = 3 AND ec.Name IN ('CB MngtC - Months in Arrears >=3')
		AND pool.IsActive =1 AND pool.AuthorizedDate IS NOT NULL
		AND pool.DealTypeId=@dealTypeId
		AND VintageDate = @previousAsAtDate

		UNION ALL

		SELECT 4, 'of which have breached R&Ws' AS Header, IsNull(SUM(pool.NumberOfSubAccount),0) , Cast(IsNull(SUM(pool.CapitalBalance),0) AS decimal(38,12))
		FROM ps.pool pool
		JOIN [ps].[PoolEcMap] ecmap ON ecmap.PoolId = pool.PoolId
		JOIN ps.EligibilityCriteria ec ON ec.EligibilityCriteriaId = ecmap.EligibilityCriteriaId
		WHERE pool.PoolPurposeId = 3 
		AND ec.Name IN ('SMBPN - E26.B - Is Staff Mortgage', 'SMBPN - E09.B - Product Desc not have SCO22',
		'SMBPN - E35 - Exclude property year after 2030')
		AND pool.IsActive =1 AND pool.AuthorizedDate IS NOT NULL
		AND pool.DealTypeId=@dealTypeId
		AND VintageDate = @previousAsAtDate
		
		UNION ALL

		--Select Case When DealAggregatedFieldName= 'Repurchases' Then 2
		-- 	When DealAggregatedFieldName= 'Redemptions' Then 1
		-- 	Else 5 End as SortOrder
		--, DealAggregatedFieldName, IsNull(DealAggregatedDataLoanCount,0), Cast(IsNull(DealAggregatedDataLoanBalance,0) as decimal(38,12))
		--from CW.vwDealAggregatedData 
		--where DealAggregatedFieldName IN (		'Repurchases', 	'Redemptions', 		'TopupBalance')
		--AND CorrelatedDate =  @pAsAtDate
		--AND DealID=@dealId
		
		SELECT 1 AS SortOrder, 'Loan redemptions since previous reporting date'
                 , ISNULL(@LoanRedemptionCount, 0) AS num
                 , ISNULL(@LoanRedemptionAmount, 0) AS amt
            UNION ALL
            SELECT 2 AS SortOrder, 'Loans bought back by seller(s)'
                 , ISNULL(@LoanBoughtBackCount, 0) AS num
                 , ISNULL(@LoanBoughtBackAmount, 0) AS amt
            UNION ALL
            SELECT 5 AS SortOrder, 'Loans sold into the cover pool'
                 , ISNULL(@LoanSoldCount, 0) AS num
                 , ISNULL(@LoanSoldAmount, 0) AS amt

			
		
		SELECT Header ,
		LoanCount [Number],
		CASE WHEN @previousTotalLoanCount>0 THEN IsNull(LoanCount/@previousTotalLoanCount ,0) ELSE  0 END AS [% of Total Number],
		TotalCapitalBalance [Amount (GBP)], 
		CASE WHEN abs(@previousTotalCapitalBalance)>0 THEN IsNull(TotalCapitalBalance/@previousTotalCapitalBalance ,0) ELSE  0 END AS [% of Total Amount]
		FROM #Summary 
		ORDER BY SortOrder
	

	END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetLoanRedemptionsReplenishments', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  
END

Go


