USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spRunICTTest]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunICTTest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spRunICTTest]
/*
 * Author: Kapil Sharma
 * Date:	10.02.2022
 * Description:  This will RUN the ICT calculation Test
 * 
 * Example - 
 * [cb].[spRunICTTest] 34, 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE
			@dealId					INT,
			@testTypeId				INT,
			@collectionStartDt		DATE,
			@collectionEndDt		DATE,
			@dealIpdId				INT,
			@ipdDate				DATE,
			@lineItemCode			VARCHAR(200),
			@lineItemValue			DECIMAL(36, 18),
			@lineItemValue1			DECIMAL(36, 18),
			@lineItemValue2			DECIMAL(36, 18),
			@revenueReceipt			DECIMAL(36, 18),
			@netReceipt				DECIMAL(36, 18),
			@netCBSwapNotePayment	DECIMAL(36, 18),
			@aggrAdjAssetAmt		DECIMAL(36, 18),
			@testResult				VARCHAR(40),
			@createdBy				VARCHAR(80) = 'System',
			@createdDate			DATETIME = GETDATE()

		SELECT @dealId = di.DealId, 
			@collectionStartDt = did.CollectionBusinessStart, 
			@collectionEndDt = did.CollectionBusinessEnd,
			@dealIpdId = di.DealIpdId, @ipdDate = di.IpdDate
		FROM cw.DealIpd di
		JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
		JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
		WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1
		PRINT @collectionEndDt
		DECLARE @tblTestLineItemValue TABLE(TestLineItemId INT, LineItemCode VARCHAR(200), LineItemValue VARCHAR(100))

		SELECT @testTypeId = TestTypeID FROM cfgcb.TestType WHERE InternalName = 'ICTMonthly'

		----*****Net Receipts----------------

		--Calculate Net Revenue Receipts
		SET @lineItemCode = 'ICT_NetReceipts_RevenueReceipt_NetRevenueReceipts'
		SELECT 
			@lineItemValue = SUM(CAST(ISNULL(dc.DailyCollectionValue, 0) AS DECIMAL(38, 16)))
		FROM 
			cw.vwDailyCollection dc
		WHERE 
			dc.DailyCollectionFieldColumnName IN ('TotalRevenueReceipts', 'DeflaggedRevenueReceipts')
			AND dc.DailyCollectionFieldDealId = @dealId
			AND  CAST(dc.CollectionDate AS DATE) >= CAST(@collectionStartDt AS DATE) 
			AND CAST(dc.CollectionDate AS DATE) <= CAST(@collectionEndDt AS DATE)

		SET @lineItemValue = @lineItemValue *-1
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

		--Calculate Adjusted Capital Balance
		SET @lineItemCode = 'ICT_NetReceipts_RevenueReceipt_AdjustedCapitalBalance'
		SELECT @lineItemValue1 = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'AdjustedCapitalBalance'), 0)
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue1)

		--Capital Balance greater than 0
		SET @lineItemCode = 'ICT_NetReceipts_RevenueReceipt_CapitalBalanceGT0'
		SELECT @lineItemValue2 = ISNULL([cw].[fnGetDealAggregatedFieldValue](@collectionEndDt, @dealId, 'CapitalBalanceGT0'), 0)
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue2)

		--Revenue Receipt
		SET @lineItemCode = 'ICT_NetReceipts_RevenueReceipt' 
		SET @revenueReceipt = @lineItemValue*@lineItemValue1/@lineItemValue2
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @revenueReceipt)

		----Net Interest Swap Payment--------------------

		--Calculate Interest Rate Swap Receipt
		SET @lineItemCode = 'ICT_NetReceipts_NetInterestSwapPayment_InterestRateSwapReceipt'
		SELECT @lineItemValue = [cw].[fnGetWaterfallLineItemValue](@pDealIpdRunId, 'PreAvailableRevenueReceipts', 'PreAvailableRevenueReceipts_7.000') 
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

		--Calculate ICT_NetReceipts_NetInterestSwapPayment_InterestRateSwapPayment
		SET @lineItemCode = 'ICT_NetReceipts_NetInterestSwapPayment_InterestRateSwapPayment'
		SELECT @lineItemValue1 = [cw].[fnGetWaterfallLineItemValue](@pDealIpdRunId, 'RevenuePriorityofPayments', 'RevenuePriorityofPayments_4.000')
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue1)

		--Calculate ICT_NetReceipts_NetInterestSwapPayment
		SET @lineItemCode = 'ICT_NetReceipts_NetInterestSwapPayment'
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, (@lineItemValue1 - @lineItemValue)*-1)

		-------Finally save the Net Receipts
		SET @lineItemCode = 'ICT_NetReceipts'
		SET @netReceipt = (@revenueReceipt + (@lineItemValue1 - @lineItemValue)*-1)
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @netReceipt)

		
		-----**********Net Covered Bond Swap and Note Payment-------------------
		--Calculate CB Swap Receipt
		SET @lineItemCode = 'ICT_NetCoveredBondSwapAndNotePayment_CBSwapReceipt'
		SELECT @lineItemValue = [cw].[fnGetWaterfallLineItemValue](@pDealIpdRunId, 'PreAvailableRevenueReceipts', 'PreAvailableRevenueReceipts_8.000')
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue)

		SET @lineItemCode = 'ICT_NetCoveredBondSwapAndNotePayment_CBSwapPaymentAndNotesCouponPayment'
		SELECT @lineItemValue1 = [cw].[fnGetWaterfallLineItemValue](@pDealIpdRunId, 'RevenuePriorityofPayments', 'RevenuePriorityofPayments_5.000')
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @lineItemValue1)

		SET @lineItemCode = 'ICT_NetCoveredBondSwapAndNotePayment'
		SET @netCBSwapNotePayment = (@lineItemValue + @lineItemValue1)
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @netCBSwapNotePayment)

		-----***********Headroom-------------------------------------------------
		SET @lineItemCode = 'ICT_Headroom'
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(((@netReceipt - @netCBSwapNotePayment)/@netCBSwapNotePayment)*100 AS VARCHAR(40)) + '%')

		SET @lineItemCode = 'ICT_Threshold'
		SELECT @lineItemValue = CAST([Value] AS DECIMAL(10,4)) FROM [CW].[vw_DealLookup] WHERE TypeCode = 'Deimos_Test_Config' AND [Name] = 'ICT_Threshold'
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue AS DECIMAL(10,4)) AS VARCHAR(10)) + '%')

		-----***********ICT Ratio-------------------------------------------------
		SET @lineItemCode = 'ICT_Ratio'
		SELECT @lineItemValue = @netReceipt/@lineItemValue1*100
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@lineItemValue AS DECIMAL(10,4)) AS VARCHAR(10)) + '%')
		
		-----***********Result-------------------------------------------------
		SET @lineItemCode = 'ICT_Result'
		SET @testResult = CASE WHEN @lineItemValue >100 THEN 'PASS' ELSE 'FAILED' END;
		INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @testResult)

		--------Now insert the test line item into the main table

		--First update the TestLineItemId in the table variable
		UPDATE tbl SET tbl.TestLineItemId = tli.TestLineItemId
		FROM  @tblTestLineItemValue tbl
		JOIN cfgcb.TestLineItem tli ON tli.InternalName = tbl.LineItemCode
		JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
		WHERE tt.TestTypeID = @testTypeId

		--Now merge the line item values into main table
		MERGE cb.TestLineItemValue AS trg
		USING @tblTestLineItemValue AS src
		ON src.TestLineItemId = trg.TestLineItemId AND trg.DealIpdrunId = @pDealIpdRunId
		WHEN NOT MATCHED BY Target THEN
			INSERT (TestLineItemID, DealIpdRunId, [Value], IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
			VALUES (src.TestLineItemId, @pDealIpdRunId, src.LineItemValue, 1, @createdBy, @createdDate, @createdBy, @createdDate)
		WHEN MATCHED THEN UPDATE SET
			trg.[Value]	= src.LineItemValue;

		---Save the test result 
		EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeId, @testResult, @pUserName

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spRunICTTest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO