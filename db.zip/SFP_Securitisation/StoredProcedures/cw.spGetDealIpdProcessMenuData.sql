USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spGetDealIpdProcessMenuData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealIpdProcessMenuData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	28.04.2020
 * Description:  This will return menu items for deal ipd run process
 * 				
 * Change History
 * --------------
 * [cw].[spGetDealIpdProcessMenuData] 14, 'Europa\Sharapi'
*/
CREATE PROCEDURE [cw].[spGetDealIpdProcessMenuData] 
	@pDealId			SMALLINT,
	@pUserName			VARCHAR(80)
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		--Returning the Menu items
		SELECT 
			DealNavbarMenuId AS NavbarMenuId, 
			MenuName,
			RouterLink,
			Icon,
			ParentMenuId,
			SeqOrder,
			1 IsAccessible ,
			DefaultSelected Selected,
			DefaultExpanded Expanded
		FROM 
			[cfgcw].[DealNavbarMenu]
		WHERE
			IsActive = 1
			AND (DealId = @pDealId OR DealId IS NULL)
		ORDER BY 
			SeqOrder
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetDealIpdProcessMenuData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO