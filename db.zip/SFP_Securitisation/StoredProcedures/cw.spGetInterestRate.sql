USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spGetInterestRate]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetInterestRate]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================
--Author: Gunjan Chandola
--Date:	13-04-2021
--Description:  To get interest rate List on basis 
--CollectionBusinessStart AND CollectionBusinessEnd from CW and WIP
-- Exec cw.spGetInterestRate  14,7,''
--================================== 
CREATE PROC [cw].[spGetInterestRate] 
    @pDealId		SMALLINT,
    @pIPDRunId		INT,
	@pUserName		VARCHAR(80) 
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE
			@interestRateDate		DATE,
			@dealType				VARCHAR(20),
			@startDt				DATE,
			@endDt					DATE,
			@prevIpdDate			DATE,
			@currentIpdDate			DATE,
			@dealRegionCode			VARCHAR(20)

		DECLARE @tblDealBenchmarkCode AS TABLE(RICCode		VARCHAR(100))

		SET @dealType =(SELECT [cw].[fnGetDealType] (@pDealId))

		SELECT 
			@currentIpdDate = dit.Ipd, 
			@prevIpdDate= dit.PreviousIPD,
			@dealRegionCode = deal.DealRegionCode
		FROM cw.vwDealIpdRun dir
		JOIN cw.vw_ActiveDeal deal ON deal.DealId = dir.DealId
		JOIN cw.vwDealIpdDates dit ON dir.DealIpdId = dit.DealIpdId
		WHERE dir.DealIpdRunId = @pIPDRunId

		--fetching the RICCode based on the deal type
		IF (@dealType='Covered Bond')
		BEGIN
			INSERT INTO @tblDealBenchmarkCode(RICCode)
			SELECT DISTINCT dlv.Value AS RicCode FROM cfgcb.DealNote dn1 
			JOIN cb.DealNote_Wf dnDF ON dnDF.DealNoteId = dn1.DealNoteId
			JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = dn1.BenchmarkId
			JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
			WHERE dn1.DealId = @pDealId AND dlt.Name = 'Benchmark' 

			--Fetching the IPD collection start and end date
			DECLARE
				@resetLeadDays		INT

			SELECT @resetLeadDays = CAST([Value] AS INT) FROM [cfgcb].[SoniaResetLeadDays] WHERE IsActive = 1
			SELECT @startDt = [CW].[fnGetBusinessDate](@prevIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
			SELECT @endDt = [CW].[fnGetBusinessDate](@currentIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
		END
		ELSE IF(@dealType='RMBS')
		BEGIN
			INSERT INTO @tblDealBenchmarkCode(RICCode)
			SELECT DISTINCT dlv.Value AS RicCode FROM cfgcw.DealNote dn1 
			JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = dn1.BenchmarkId
			JOIN cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
			WHERE dn1.DealId = @pDealId AND dlt.Name = 'Benchmark' 
		END

		SELECT * INTO #tempInterestRate FROM cw.InterestRate_wip WHERE IsActive=1

		SELECT
			@interestRateDate = CAST(ipdDt.RateResetDate AS DATE)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
    
		SELECT InterestRateId,RICCode,InterestRateType,IpdDate,InterestRate,[Status],ModifiedBy,ModifiedDate,Reason 
		FROM 
		(
			SELECT 
				ir.InterestRateId
				,ir.RICCode
				,ir.Asset AS InterestRateType
				,wip.Id AS WIPId
				,WIP.CreatedDate
				,wip.ChangeReason AS Reason
				,ROW_NUMBER() OVER(PARTITION BY ir.InterestRateId ORDER BY ID DESC) AS RowNum    
				,CASE WHEN @dealType = 'RMBS' THEN @interestRateDate ELSE ir.BaseDate END AS IpdDate
				,CAST(IIF(wip.InterestRateId IS NOT NULL, ROUND(WIP.Rate,4), ROUND(ir.Rate,4)) AS DECIMAL(30,8)) AS InterestRate
				,IIF(wip.InterestRateId IS NOT NULL, WIP.CreatedBy, ir.CreatedBy) AS ModifiedBy
				,IIF(wip.InterestRateId IS NOT NULL,WIP.CreatedDate,ir.CreatedDate) AS ModifiedDate
				,IIF(wip.InterestRateId IS NOT NULL, WIP.Status, WIP.Status) AS [Status]
			FROM 
				cw.InterestRate ir
			JOIN
				@tblDealBenchmarkCode dealRC ON ir.RICCode = dealRC.RicCode
			LEFT JOIN 
				#tempInterestRate wip ON ir.InterestRateId = wip.InterestRateId
			WHERE 
				(
					(@dealType = 'Covered Bond' AND CAST(ir.BaseDate AS DATE)>=@startDt AND CAST(ir.BaseDate AS DATE)<=@endDt)
					OR
					(@dealType = 'RMBS' AND (CAST(ir.BaseDate AS DATE)=CAST(@interestRateDate AS DATE)))
				)
		)t  
		WHERE	
			t.RowNum=1 
		ORDER BY 
			t.CreatedDate DESC

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetInterestRate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
				@errorSeverity,
				@errorState )
	END CATCH
END
GO

