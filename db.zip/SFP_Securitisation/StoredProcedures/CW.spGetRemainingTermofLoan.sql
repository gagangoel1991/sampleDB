USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetRemainingTermofLoan', 'P') IS NOT NULL
 DROP PROC  CW.spGetRemainingTermofLoan;

GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
/*  
 * Author: Arun  
 * Date:    26.05.2020  
 * Description:  This will return Reaminng Term of loan for Investor report.  
 * Usage : CW.spGetRemainingTermofLoan @pAsAtDate  ='31-Mar-2020'  
 *   ,@pDealName  = 'DUNMORE1' 
 *   ,@pStratInternalName='RemainingTermofLoan' 
 *   ,@pUserName = NULL                                                    
 * Change History  
 * --------------  
 * Author              Date                 Description  
 * -------------------------------------------------------  
*/  
CREATE PROC CW.spGetRemainingTermofLoan @pAsAtDate DATE  
  ,@pDealName VARCHAR(255)   
  ,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY  
  ,@pUserName VARCHAR(50) = NULL    
  
AS  
BEGIN  
      
      
BEGIN TRY  
  
 DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))  
  , @totalNumberofSubAccounts float  
  , @totalOutstandingCapitalBalance float  
  , @totalTrueBalance float  
         
 SELECT @totalNumberofSubAccounts = COUNT(ISNULL(VMS.MortgageSubAccountKey, 0))    
  , @totalOutstandingCapitalBalance = SUM(ISNULL(VMS.totaloutstandingcapitalbalance, 0))    
  , @totalTrueBalance  = SUM(ISNULL(VMS.TrueBalance, 0))   
 FROM   CW.VwMortgageSubAccount VMS  
 WHERE PartitionID = (@partitionID_AsAtDate)    
  AND DealName = @pDealName    
 GROUP BY VMS.mortgagedealkey, VMS.BusinessDate  
   
    
 SELECT DealName, VMS.MortgageDealKey, VMS.MortgageSubAccountKey, VMS.TotalOutstandingCapitalBalance , TrueBalance  
 , CW.fnGetStratConfigGroupName(@pStratRangeData, ROUND(CAST(DATEDIFF(day, @pAsAtDate, VMS.maturitydate) / 365.0  AS FLOAT), 2) ) AS BandRange  
 INTO #temp  
 FROM   CW.VwMortgageSubAccount VMS  
 WHERE PartitionID = (@partitionID_AsAtDate)    
  AND DealName = @pDealName    
   
  
 SELECT dans.DisplayName 'HeaderText', count(MortgageSubAccountKey) [MortgageLoans]  
 , ISNULL(CAST( CASE WHEN @totalNumberofSubAccounts > 0 THEN Cast( (COUNT(MortgageSubAccountKey) / @totalNumberofSubAccounts  * 100) AS Decimal(10,2)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent 
 , ISNULL(CAST(sum(TotalOutstandingCapitalBalance) AS Float) , 0) 'TotalOutCapitalBalance'   
 , ISNULL(CAST( CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast( (sum(TotalOutstandingCapitalBalance) / @totalOutstandingCapitalBalance ) *100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TotalOutCapitalBalancePercent
 , ISNULL(CAST(sum(TrueBalance) AS Float) , 0) TrueBalance  
 , ISNULL(CAST( CASE WHEN @totalTrueBalance > 0 THEN Cast( (sum(TrueBalance) / @totalTrueBalance) * 100 AS Decimal(10,2)) ELSE 0 END AS Float) , 0) TrueBalancePercent  
 FROM @pStratRangeData dans   
 LEFT JOIN #temp T ON T.BandRange = dans.DisplayName   
 --Where dans.StratInternalName = @pStratInternalName  
 GROUP BY dans.DisplayName , dans.SortOrder   
 ORDER BY dans.SortOrder;    
   
END TRY  
BEGIN CATCH  
    DECLARE   
                @errorMessage     NVARCHAR(MAX),  
                @errorSeverity    INT,  
                @errorNumber      INT,  
                @errorLine        INT,  
                @errorState       INT;  
  
    SELECT   
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()  
  
    EXEC app.SaveErrorLog 1, 1, 'spGetRemainingTermofLoan', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
    RAISERROR (@errorMessage,  
                @errorSeverity,  
                @errorState )  
END CATCH     
  
END  
  
	
GO
