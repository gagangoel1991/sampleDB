USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetSpotRate]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetSpotRate]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE  PROCEDURE [cw].[spGetSpotRate]
	/*
 * Author: Gunjan Chandola
 * Date:	21.01.2022
 * Description:  Get Spot Rate from FXRate
 * 				
 * Change History
 * --------------
 * 	DECLARE @pSpotRate DECIMAL(18, 11)
 * 	exec cw.spGetSpotRate 15,56,'2021-05-28','',@pSpotRate OUTPUT
 * 	SELECT @pSpotRate
 * Author		Date		Description
 * -------------------------------------------------------
*/
	@pDealId INT
	,@pInvoiceCurrencyId INT
	,@pSpotRateDate DATE
	,@pUserName VARCHAR(80)
	,@pSpotRate DECIMAL(18, 11) OUTPUT
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		--SET @pSpotRate = 1;

		DECLARE @DealCurrencyId INT;

		SELECT @DealCurrencyId = DealCurrencyId
		FROM cfg.Deal
		WHERE DealId = @pDealId
			AND IsActive = 1

		SET @pSpotRate = [cw].[fnGetCurrencySwapRate](@pInvoiceCurrencyId, @DealCurrencyId, @pSpotRateDate)
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetSpotRate'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO