
USE [SFP_Securitisation]
GO

IF EXISTS ( SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetDashBoardDealFlagDeFlagDataCorporate]') AND type IN(N'P', N'PC') )
    DROP PROCEDURE [corp].[spGetDashBoardDealFlagDeFlagDataCorporate];
GO

SET ANSI_NULLS ON;
GO

SET QUOTED_IDENTIFIER ON;
GO

/*
 *   Author: Sakthivel Loganathan
 *   Date:  23-Feb-2023
 *   Description: To get Corporate's Deal data for dashboard (being called from the sp:[ps].[spGetSFPPlusDashBoardDeals])
 *   Change History 
 *   ---------------------------------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   exec [corp].[spGetDashBoardDealFlagDeFlagDataCorporate] '31 jan 2023', 0
*/

-- RETAIL VERSION : [SFP_Model].[rpt].[spGetDashBoardDealFlagDeFlagData]  
CREATE PROCEDURE [corp].[spGetDashBoardDealFlagDeFlagDataCorporate]    
(    
 @AsAtDate DATE,    
 @isInitial BIT     
)    
AS    
    BEGIN            
		BEGIN TRY   
  
			DECLARE @AsAtDateKey             INT= NULL,        
			@PartitionID             INT = NULL,        
			@PreviousPartitionID_NI  INT = NULL,        
			@PreviousPartitionID_UK  INT = NULL,        
			@PreviousPartitionID_ROI INT = NULL,        
			@AsAtDateKey_NI          INT= NULL,        
			@AsAtDateKey_UK          INT= NULL,        
			@AsAtDateKey_ROI         INT= NULL;        
        
		 IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#PartitionIdWithRegion') AND type = 'U')        
		 DROP TABLE #partitionidwithregion;        
        
		 SELECT asatdate, previousasatdate,regioncode        
		 INTO   #partitionidwithregion        
		 FROM   sfp.syn_SfpModel_vw_Calendar_v1 --[dm].[Dim_Calendar]        
		 WHERE  isworkingday = 1   AND asatdate = @asAtDate        
		 ORDER  BY asatdate DESC  
  
		 IF(@isInitial = 1)        
		 BEGIN     
		  SELECT TOP 1 asatdate CurrentDate, previousasatdate Previousdate        
		  FROM  sfp.syn_SfpModel_vw_Calendar_v1 -- [dm].[Dim_Calendar]        
		  WHERE  isworkingday = 1 AND    asatdate <= GETDATE()        
		  ORDER  BY asatdate DESC     
		 END        
		 ELSE        
		 BEGIN     
		  SELECT TOP 1 AsAtDate CurrentDate, PreviousAsAtDate Previousdate  FROM #partitionidwithregion;     
		 END  
        
		 SELECT @PartitionID = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE(asatdate, '-', ''  ), 112)  ),        
		   @PreviousPartitionID_UK = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE(previousasatdate, '-', ''), 112))        
		 FROM   #partitionidwithregion        
		 WHERE  regioncode = 'UK'        
        
		 SELECT @PreviousPartitionID_NI = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE( previousasatdate, '-', ''),112))        
		 FROM   #partitionidwithregion        
		 WHERE  regioncode = 'NI'        
        
		 SELECT @PreviousPartitionID_ROI = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE(previousasatdate, '-', ''), 112))        
		 FROM   #partitionidwithregion        
		 WHERE  regioncode = 'ROI'     
   
		 --SELECT @PartitionID = '20221031',@PreviousPartitionID_UK = '20221027'  
   
		 IF(@PartitionID IS NULL)        
		  BEGIN        
			SELECT @PartitionID = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE(asatdate, '-', ''), 112)),        
			 @PreviousPartitionID_UK = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE(previousasatdate, '-', ''), 112))        
			FROM   #partitionidwithregion        
			WHERE  regioncode = 'NI'      
		  END        
          
		  IF(@PartitionID IS NULL)        
		  BEGIN        
			SELECT @PartitionID = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE(asatdate, '-', '' ), 112) ),        
		   @PreviousPartitionID_UK = CONVERT(INT, CONVERT(VARCHAR(8), REPLACE( previousasatdate, '-', ''), 112))        
			FROM   #partitionidwithregion        
			WHERE  regioncode = 'ROI'     
		  END
  
		   --UtilisaitonAmt, CommitedExpoure_TCE : Calculation      
		  SELECT fx.FromCurrencyName AS FromCurrency,  fx.Rate AS FxRate, deal.DealId AS DealId      
		  INTO #fxRates        
		  FROM [CW].[vw_FXRate] fx        
		  LEFT JOIN [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] deal ON CONVERT(DATE, fx.RelatesRateDate) = deal.FxRateDate AND fx.ToCurrencyName = 'GBP'      
		  WHERE (deal.DealID IS NOT NULL)   
  
		  --CREATE INDEX Index_FxRate ON #fxRates(DealId) 

		  --FIN CURRENT 
		  SELECT     
			  bfd.DealKey,     
			  ff.FacilityKey,    
			  ff.FacilityId,
			  SUM(CASE WHEN dl.SourceId = 4 
				  THEN CONVERT(DECIMAL(38, 2), CAST(ABS(ISNULL(fl.ClearedBalForAuth,0.00)) * ISNULL(fx.FxRate, 1.00)  AS DECIMAL(38, 2)))  
				  ELSE CONVERT(DECIMAL(38, 2), CAST(ISNULL(td.PosShareAmt,0.00)  AS DECIMAL(38, 2)))						 
			  END) AS Utilisation, 
			  SUM(ISNULL(CAST(ff.MarkedLimitAmt AS DECIMAL(38,20)), 0.00)  * ISNULL(fx.FxRate, 1.00)) AS CommittedExposure,
			  SUM(ISNULL(ISNULL((CONVERT(DECIMAL(21,8), facdcorr.RONA)), bfd.RONA),0.0)) AS RONA
		  INTO   
			#FactLoanFinValues    
		  FROM     
			  [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock)     
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey       
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON dfac.FacilityKey =  ff.FacilityKey 
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeFacilitySecurity] bfs   ON bfs.FacilitySecurityGroupKey = ff.FacilitySecurityGroupKey  
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimSecurity] ds ON ds.SecurityKey = bfs.SecurityKey
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeFacilityLoan] bfl ON bfl.FacilityLoanGroupKey = ff.FacilityLoanGroupKey     
			  LEFT JOIN [corp].[syn_SfpModelCorporate_vw_FactLoan] fl ON fl.LoanKey = bfl.LoanKey AND fl.PartitionId = @PartitionId     
			  LEFT JOIN [corp].[syn_SfpModelCorporate_vw_DimLoan] dl ON dl.LoanKey = fl.LoanKey     
			  LEFT JOIN [corp].[syn_SfpModelCorporate_vw_DimOutstandingPositions] td ON td.OutstandingGroupKey = fl.OutstandingGroupKey     
			  LEFT JOIN #fxRates fx ON fx.FromCurrency = td.ccy AND fx.DealId = fl.DealID 
			  LEFT JOIN [corp].[vw_FacilityDataOverrideDetail] facdcorr  ON facdcorr.PartitionId = FF.PartitionId   
					AND facdcorr.FacilityId = REPLACE(FF.FacilityId,'\P','')
		   WHERE  ff.PartitionId = @PartitionId
				 AND ((FF.SourceId = 1 AND dfac.FacilityTypeCode NOT IN ('10','21','40','CC','N/A')) OR FF.SourceId <>1)  
				 AND dfac.facilitysourcecode in ('R','N','RBS','N/A','ABN','NWM','NWBEU','NWH','AAH','RBSG','NWB','RBSI') 
		  GROUP BY bfd.DealKey,ff.FacilityKey,ff.FacilityId 

		   --FIN PREV
		  SELECT     
			  bfd.DealKey,     
			  ff.FacilityKey,    
			  ff.FacilityId,
			  SUM(CASE WHEN dl.SourceId = 4 
				  THEN CONVERT(DECIMAL(38, 2), CAST(ABS(ISNULL(fl.ClearedBalForAuth,0.00)) * ISNULL(fx.FxRate, 1.00)  AS DECIMAL(38, 2)))  
				  ELSE CONVERT(DECIMAL(38, 2), CAST(ISNULL(td.PosShareAmt,0.00)  AS DECIMAL(38, 2)))						 
			  END) AS Utilisation, 
			  SUM(ISNULL(CAST(ff.MarkedLimitAmt AS DECIMAL(38,20)), 0.00)  * ISNULL(fx.FxRate, 1.00)) AS CommittedExposure,
			  SUM(ISNULL(ISNULL((CONVERT(DECIMAL(21,8), facdcorr.RONA)), bfd.RONA),0.0)) AS RONA
		  INTO   
			  #FactLoanFinValues_Prev    
		  FROM     
			  [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock)     
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey       
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON dfac.FacilityKey =  ff.FacilityKey 
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeFacilitySecurity] bfs   ON bfs.FacilitySecurityGroupKey = ff.FacilitySecurityGroupKey  
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimSecurity] ds ON ds.SecurityKey = bfs.SecurityKey
			  INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeFacilityLoan] bfl ON bfl.FacilityLoanGroupKey = ff.FacilityLoanGroupKey     
			  LEFT JOIN [corp].[syn_SfpModelCorporate_vw_FactLoan] fl ON fl.LoanKey = bfl.LoanKey AND fl.PartitionId = @PreviousPartitionID_UK     
			  LEFT JOIN [corp].[syn_SfpModelCorporate_vw_DimLoan] dl ON dl.LoanKey = fl.LoanKey     
			  LEFT JOIN [corp].[syn_SfpModelCorporate_vw_DimOutstandingPositions] td ON td.OutstandingGroupKey = fl.OutstandingGroupKey     
			  LEFT JOIN #fxRates fx ON fx.FromCurrency = td.ccy AND fx.DealId = fl.DealID  
			  LEFT JOIN [corp].[vw_FacilityDataOverrideDetail] facdcorr  ON facdcorr.PartitionId = FF.PartitionId   
					AND facdcorr.FacilityId = REPLACE(FF.FacilityId,'\P','')
		   WHERE  ff.PartitionId = @PreviousPartitionID_UK
			  AND ((FF.SourceId = 1 AND dfac.FacilityTypeCode NOT IN ('10','21','40','CC','N/A')) OR FF.SourceId <>1)  
			  AND facilitysourcecode in ('R','N','RBS','N/A','ABN','NWM','NWBEU','NWH','AAH','RBSG','NWB','RBSI') 
		  GROUP BY bfd.DealKey,ff.FacilityKey,ff.FacilityId  
  
        
 IF( @PreviousPartitionID_UK = @PreviousPartitionID_NI AND @PreviousPartitionID_NI = @PreviousPartitionID_ROI ) 
  BEGIN      
		  IF EXISTS (SELECT 1  FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#tmpBalances') AND type = 'U')        
		   DROP TABLE #tmpbalances;     
		  IF EXISTS (SELECT 1  FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#dashboard') AND type = 'U')        
		   DROP TABLE #dashboard;     
		  IF EXISTS (SELECT 1  FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#dealaccountcount') AND type = 'U')        
		   DROP TABLE #dealaccountcount;     
		  IF EXISTS (SELECT 1 FROM   tempdb.sys.objects  WHERE object_id = Object_id(N'tempdb..#dealaccount') AND type = 'U')        
		   DROP TABLE #dealaccount;     
		  IF EXISTS (SELECT 1 FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccountcount_pv')  AND type = 'U')        
		   DROP TABLE #dealaccountcount_pv;     
		  IF EXISTS (SELECT 1 FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccount_pv')  AND type = 'U')        
		   DROP TABLE #dealaccount_pv;
      
		 SELECT DISTINCT cdd.loanid,        
							  cdd.mortgagedealkey,        
							  cdd.brandkey,        
							  cdd.mortgageaccountkey,        
							  cdd.mortgagesubaccountkey,        
							  pdd.loanid     AS                    LoanId_pv,        
							  pdd.mortgagedealkey AS               MortgageDealKey_pv,        
							  pdd.brandkey AS                      BrandKey_pv,        
							  pdd.mortgageaccountkey AS            MortgageAccountKey_pv,        
							  pdd.mortgagesubaccountkey        
							  MortgageSubAccountKey_pv    
			 INTO #tmpbalances        
			 FROM   ( 
							SELECT 
								FF.FacilityId AS  loanid,      
								NULL AS subaccountnumber,      
								bfd.DealKey AS mortgagedealkey,      
								0 AS brandkey,      
								FF.FacilityKey AS mortgageaccountkey,      
								NULL AS mortgagesubaccountkey    
							FROM   
								 [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock)  
								 INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey
								 INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON dfac.FacilityKey =  ff.FacilityKey
							 WHERE  ff.PartitionId = @PartitionId
								 AND ((FF.SourceId = 1 AND dfac.FacilityTypeCode NOT IN ('10','21','40','CC','N/A')) OR FF.SourceId <>1)  
								 AND facilitysourcecode in ('R','N','RBS','N/A','ABN','NWM','NWBEU','NWH','AAH','RBSG','NWB','RBSI')
			  ) cdd        
			  INNER JOIN (     
						SELECT 
							 FF.FacilityId AS  loanid,      
							 NULL AS subaccountnumber,      
							 bfd.DealKey AS mortgagedealkey,      
							 0 AS brandkey,      
							 FF.FacilityKey AS mortgageaccountkey,      
							 NULL AS mortgagesubaccountkey      
						FROM   
							 [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock)  
							 INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey
							 INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON dfac.FacilityKey =  ff.FacilityKey
						WHERE  ff.PartitionId = @PreviousPartitionID_UK
							 AND ((FF.SourceId = 1 AND dfac.FacilityTypeCode NOT IN ('10','21','40','CC','N/A')) OR FF.SourceId <>1)  
							 AND facilitysourcecode in ('R','N','RBS','N/A','ABN','NWM','NWBEU','NWH','AAH','RBSG','NWB','RBSI')
	
			) pdd        
			ON cdd.loanid = pdd.loanid AND cdd.mortgagedealkey <> pdd.mortgagedealkey;   

		  SELECT  distinct      
			   DealKey,      
			   0 AS BrandKey,      
			   ISNULL(Utilisation,0) AS UtilisaitonAmt,      
			   ISNULL(CommittedExposure,0) AS CommitedExpoure_TCE,      
			   ISNULL(RONA,0) AS RONA,    
			   FacilityKey as LoanCount,      
			   0 as SubAccountCount,    
			   FacilityId    
		  INTO   #dealaccount       
		  FROM  #FactLoanFinValues  
        
		  SELECT DealKey,brandkey,        
			   SUM(UtilisaitonAmt) AS UtilisaitonAmt,        
			   SUM(CommitedExpoure_TCE) AS CommitedExpoure_TCE,     
			   SUM(RONA) AS RONA,      
			   COUNT(DISTINCT LoanCount) AS LoanCount,        
			   0 AS SubAccountCount    
		  INTO   #dealaccountcount        
		  FROM   #dealaccount        
		  GROUP  BY DealKey ,brandkey;    
        
		  SELECT  DISTINCT      
			   DealKey,      
			   0 AS BrandKey,      
			   ISNULL(Utilisation,0) AS UtilisaitonAmt,      
			   ISNULL(CommittedExposure,0) AS CommitedExpoure_TCE,    
			   ISNULL(RONA,0) AS RONA,    
			   FacilityKey as LoanCount,      
			   0 as SubAccountCount,    
			   FacilityId    
		  INTO  #dealaccount_pv       
		  FROM  #FactLoanFinValues_Prev
      
		  SELECT   
			   DealKey,        
			   brandkey,        
			   SUM(UtilisaitonAmt) AS      UtilisaitonAmt,        
			   SUM(CommitedExpoure_TCE) AS CommitedExpoure_TCE,     
			   SUM(RONA) AS RONA,     
			   COUNT(DISTINCT LoanCount) AS LoanCount,    
			   0 AS SubAccountCount    
		  INTO   #dealaccountcount_pv    
		  FROM   #dealaccount_pv    
		  GROUP  BY DealKey, brandkey;  
        
		  SELECT ISNULL(curbalance.mortgagedealkey,pvBalance.mortgagedealkey) AS mortgagedealkey,        
				 ISNULL(curbalance.brandkey,pvBalance.brandkey) AS brandkey,        
				 (ISNULL(curBalance.mortgageaccountkeyCount,0) - ISNULL(pvBalance.mortgageaccountkeyCount,0)) AS LoanVariance,        
		(ISNULL(curBalance.mortgagesubaccountkeyCount,0) - ISNULL(pvBalance.mortgagesubaccountkeyCount,0)) AS SubAccountVariance        
		  INTO   #dashboard        
		  FROM   (SELECT mortgagedealkey,        
						 brandkey,        
						 COUNT(DISTINCT mortgageaccountkey) AS   MortgageAccountKeyCount,        
						 COUNT(DISTINCT mortgagesubaccountkey) AS MortgageSubAccountKeyCount        
				  FROM   #tmpbalances        
				  GROUP  BY mortgagedealkey,        
							brandkey) curbalance        
				 FULL OUTER JOIN (SELECT mortgagedealkey_pv        
									MortgageDealKey,        
									brandkey_pv        
									BrandKey,        
									COUNT(DISTINCT mortgageaccountkey_pv) AS MortgageAccountKeyCount,        
									COUNT(DISTINCT mortgagesubaccountkey_pv) AS MortgageSubAccountKeyCount        
							 FROM   #tmpbalances        
							 GROUP  BY mortgagedealkey_pv,        
									   brandkey_pv) pvBalance        
						 ON curbalance.mortgagedealkey = pvBalance.mortgagedealkey        
							--AND curbalance.brandkey = pvBalance.brandkey;        
        
		SELECT deal.dealname,        
		  0 AS brandcode,        
		  ISNULL(DealAccount.UtilisaitonAmt, DealAccount_pv.UtilisaitonAmt) AS truebalance,        
		  ISNULL(DealAccount.CommitedExpoure_TCE,DealAccount_pv.CommitedExpoure_TCE) AS capitalbalance,     
		  ISNULL(DealAccount.RONA,DealAccount_pv.RONA) AS RONA,    
		  ISNULL(DealAccount.LoanCount,0) AS currentaccountcount,        
		  ISNULL(DealAccount.SubAccountCount,0) AS currentsubaccountcount,        
		  LoanVariance,        
		  ISNULL(DealAccount_pv.LoanCount,0) AS previousaccountcount,        
		  ISNULL(DealAccount_pv.SubAccountCount,0) AS previoussubaccountcount,        
		  SubAccountVariance     
	   FROM   #dashboard balance       
		 INNER JOIN [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] deal ON balance.mortgagedealkey = deal.DealId        
		 LEFT OUTER JOIN #dealAccountCount DealAccount ON DealAccount.DealKey = balance.mortgagedealkey       
		 LEFT JOIN #dealAccountCount_pv DealAccount_pv   ON DealAccount_pv.DealKey = balance.mortgagedealkey       
		WHERE LoanVariance <> 0     
		ORDER  BY deal.dealname --, brand.brandname;  
    
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#tmpBalances') AND type = 'U')        
		DROP TABLE #tmpbalances;     
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#dashboard') AND type = 'U')        
		DROP TABLE #dashboard;     
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#dealaccountcount') AND type = 'U')        
		DROP TABLE #dealaccountcount;     
		IF EXISTS (SELECT 1 FROM   tempdb.sys.objects  WHERE object_id = Object_id(N'tempdb..#dealaccount') AND type = 'U')        
		DROP TABLE #dealaccount;     
		IF EXISTS (SELECT 1 FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccountcount_pv')  AND type = 'U')        
		DROP TABLE #dealaccountcount_pv;     
		IF EXISTS (SELECT 1 FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccount_pv')  AND type = 'U')        
		DROP TABLE #dealaccount_pv;    
        
  END        
ELSE        
  BEGIN

		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#tmpBalances_h') AND type = 'U')        
		DROP TABLE #tmpbalances_h;        
        
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dashboard_h') AND type = 'U')        
		DROP TABLE #dashboard_h;        
        
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccountcount_h')   AND type = 'U')        
		DROP TABLE #dealaccountcount_h;        
        
		IF EXISTS (SELECT 1   FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#dealaccount_h')  AND type = 'U')        
		DROP TABLE #dealaccount_h;        
        
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccountcount_pv_h') AND type = 'U')        
		DROP TABLE #dealaccountcount_pv_h;      
        
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccount_pv_h') AND type = 'U')        
		DROP TABLE #dealaccount_pv_h;        
      
		  SELECT DISTINCT cdd.loanid,        
							  cdd.mortgagedealkey,        
							  cdd.brandkey,        
							  cdd.mortgageaccountkey,        
							  cdd.mortgagesubaccountkey,        
							  pdd.loanid       AS                  LoanId_pv,        
							  pdd.mortgagedealkey AS               MortgageDealKey_pv,        
							  pdd.brandkey       AS                BrandKey_pv,        
							  pdd.mortgageaccountkey AS             MortgageAccountKey_pv,        
							  pdd.mortgagesubaccountkey        
							  MortgageSubAccountKey_pv        
			  INTO   #tmpbalances_h        
			  FROM   (  
						 SELECT   
							 FF.FacilityId AS  loanid,      
							 NULL AS subaccountnumber,      
							 bfd.DealKey AS mortgagedealkey,      
							 NULL AS brandkey,      
							 FF.FacilityKey AS mortgageaccountkey,      
							 NULL AS mortgagesubaccountkey
						 FROM   
							[corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock)  
							INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey
							INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON dfac.FacilityKey =  ff.FacilityKey
						 WHERE  ff.PartitionId = @PartitionId
							AND ((FF.SourceId = 1 AND dfac.FacilityTypeCode NOT IN ('10','21','40','CC','N/A')) OR FF.SourceId <>1)  
							AND facilitysourcecode in ('R','N','RBS','N/A','ABN','NWM','NWBEU','NWH','AAH','RBSG','NWB','RBSI')
						) cdd        
					 INNER JOIN (  
						 SELECT   
							  FF.FacilityId AS  loanid,      
							  NULL AS subaccountnumber,      
							  bfd.DealKey AS mortgagedealkey,      
							  NULL AS brandkey,      
							  FF.FacilityKey AS mortgageaccountkey,      
							  NULL AS mortgagesubaccountkey 
						 FROM   
							 [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock)  
							 INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bfd ON ff.dealfacilitygroupkey = bfd.dealfacilitygroupkey
							 INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac ON dfac.FacilityKey =  ff.FacilityKey
						WHERE  ff.PartitionId = @PreviousPartitionID_UK
							 AND ((FF.SourceId = 1 AND dfac.FacilityTypeCode NOT IN ('10','21','40','CC','N/A')) OR FF.SourceId <>1)  
							 AND facilitysourcecode in ('R','N','RBS','N/A','ABN','NWM','NWBEU','NWH','AAH','RBSG','NWB','RBSI')
					 )pdd ON cdd.loanid = pdd.loanid       
					  AND cdd.mortgagedealkey <> pdd.mortgagedealkey  
        
		  SELECT  distinct      
			   DealKey,      
			   0 AS BrandKey,      
			   ISNULL(Utilisation,0) AS UtilisaitonAmt,      
			   ISNULL(CommittedExposure,0) AS CommitedExpoure_TCE,      
			   ISNULL(RONA,0) AS RONA,    
			   FacilityKey as LoanCount,      
			   0 as SubAccountCount,    
			   FacilityId    
		  INTO #dealaccount_h       
		  FROM  #FactLoanFinValues  
    
		  SELECT DealKey  AS  DealKey,        
			   0 AS BrandKey,        
			   SUM(UtilisaitonAmt) AS UtilisaitonAmt,        
			   SUM(CommitedExpoure_TCE) AS CommitedExpoure_TCE,        
			   SUM(RONA) AS RONA,      
			   COUNT(DISTINCT LoanCount) AS LoanCount,        
			   0 AS SubAccountCount        
		  INTO #dealaccountcount_h        
		  FROM #dealaccount_h        
		  GROUP BY DealKey,brandkey;  
        
		  SELECT  distinct      
			   DealKey,      
			   0 AS BrandKey,      
			   ISNULL(Utilisation,0) AS UtilisaitonAmt,      
			   ISNULL(CommittedExposure,0) AS CommitedExpoure_TCE,      
			   ISNULL(RONA,0) AS RONA,    
			   FacilityKey as LoanCount,      
			   0 as SubAccountCount,    
			   FacilityId    
		  INTO #dealaccount_pv_h       
		  FROM #FactLoanFinValues_Prev  
  
		SELECT DealKey AS DealKey,        
			brandkey  AS BrandKey,        
			SUM(UtilisaitonAmt) AS UtilisaitonAmt,        
			SUM(CommitedExpoure_TCE) AS CommitedExpoure_TCE,        
			COUNT(DISTINCT LoanCount) AS LoanCount,     
			SUM(RONA) AS RONA,    
			0 AS SubAccountCount        
		INTO   #dealaccountcount_pv_h        
		FROM   #dealaccount_pv_h        
		GROUP  BY DealKey,brandkey;  
      
		SELECT ISNULL(curbalance.mortgagedealkey,pvBalance.mortgagedealkey) AS mortgagedealkey,        
			ISNULL(curbalance.brandkey,pvBalance.brandkey) AS brandkey,        
			(ISNULL(curBalance.mortgageaccountkeyCount,0) - ISNULL(pvBalance.mortgageaccountkeyCount,0)) AS LoanVariance,        
			(ISNULL(curBalance.mortgagesubaccountkeyCount,0) - ISNULL(pvBalance.mortgagesubaccountkeyCount,0)) AS SubAccountVariance        
		INTO   #dashboard_h        
		FROM   (SELECT mortgagedealkey,        
			brandkey,        
			COUNT(DISTINCT mortgageaccountkey)  AS  MortgageAccountKeyCount,        
			COUNT(DISTINCT mortgagesubaccountkey) AS MortgageSubAccountKeyCount        
			FROM   #tmpbalances_h        
			GROUP  BY mortgagedealkey,        
			brandkey) curbalance        
		FULL OUTER JOIN   
			(SELECT   
			mortgagedealkey_pv        
			MortgageDealKey,        
			brandkey_pv        
			BrandKey,        
			COUNT(DISTINCT mortgageaccountkey_pv) AS MortgageAccountKeyCount,        
			COUNT(DISTINCT mortgagesubaccountkey_pv) AS MortgageSubAccountKeyCount        
			FROM   #tmpbalances_h        
			GROUP  BY mortgagedealkey_pv,        
			brandkey_pv) pvBalance        
		ON curbalance.mortgagedealkey = pvBalance.mortgagedealkey        
		--AND curbalance.brandkey = pvBalance.brandkey;  
  
		SELECT deal.dealname,        
			NULL AS brandcode,        
			ISNULL(DealAccount.UtilisaitonAmt, DealAccount_pv.UtilisaitonAmt) AS truebalance,        
			ISNULL(DealAccount.CommitedExpoure_TCE,DealAccount_pv.CommitedExpoure_TCE) AS capitalbalance,     
			ISNULL(DealAccount.RONA,DealAccount_pv.RONA) AS RONA,    
			ISNULL(DealAccount.LoanCount,0) AS currentaccountcount,        
			ISNULL(DealAccount.SubAccountCount,0) AS currentsubaccountcount,        
			LoanVariance,        
			ISNULL(DealAccount_pv.LoanCount,0) AS previousaccountcount,        
			ISNULL(DealAccount_pv.SubAccountCount,0) AS previoussubaccountcount,        
			SubAccountVariance    
		FROM   #dashboard_h balance      
			INNER JOIN [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] deal ON balance.mortgagedealkey = deal.DealId       
			LEFT JOIN #dealaccountcount_h DealAccount ON DealAccount.DealKey = balance.mortgagedealkey       
			LEFT JOIN #dealaccountcount_pv_h DealAccount_pv ON DealAccount_pv.DealKey = balance.mortgagedealkey       
		WHERE LoanVariance <> 0        
		ORDER  BY deal.dealname --,brand.brandname;
    
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#tmpBalances_h') AND type = 'U')        
		DROP TABLE #tmpbalances_h;     
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dashboard_h') AND type = 'U')        
		DROP TABLE #dashboard_h;     
		IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#dealaccountcount_h')   AND type = 'U')        
		DROP TABLE #dealaccountcount_h;    
  END   
       
 END TRY      
        BEGIN CATCH      
            DECLARE @ERR_MSG AS NVARCHAR(4000)= ERROR_MESSAGE(), @ERR_STA AS SMALLINT= ERROR_STATE(), @ERR_PROC AS VARCHAR(100)= ERROR_PROCEDURE(), @ERR_LINE AS SMALLINT= ERROR_LINE(), @ERR_NUM AS INT= 50001; --Set default to 50001;       
            --Valid range is between 50000 AND 2147483647 for ERROR_NUMBER if used with THROW      
            IF ERROR_NUMBER() BETWEEN 50000 AND 2147483647      
                SET @ERR_NUM = ERROR_NUMBER();      
            SET @ERR_MSG = 'Error occurred while executing ''' + @ERR_PROC + '''; ' + 'Line number: ' + CONVERT(VARCHAR(2), @ERR_LINE) + '; ' + 'Exception: ' + @ERR_MSG;      
            THROW @ERR_NUM, @ERR_MSG, @ERR_STA;      
        END CATCH;      
    END; 
  
  GO
 -- EXEC [rpt].[spGetDashBoardDealFlagDeFlagDataCorporate] '2022-7-29',  1
 --EXEC [rpt].[spGetDashBoardDealFlagDeFlagDataCorporate] '2023-01-31',  1
 -- EXEC [rpt].[spGetDashBoardDealFlagDeFlagDataCorporate] '2022-10-31',  1