USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetReserveSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetReserveSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spIR_GetReserveSummary 
(
@pAsAtDate datetime,
 @pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL
) 
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get Reserve summary for IR liability Strats
 *   cw.spIR_GetReserveSummary '29-Oct-21', 'ARDMOre1'
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------
 *   Arun		09-Dec-21	   deal-termination-scenario-handling-in-the-investor-report 
 *           
  */ 
AS 
  BEGIN 
  BEGIN TRY 
   --   Declare @pDealName varchar(200)='ARDMORE1'
	  --,@pAsAtDate datetime='2018-07-31'
      
	  DECLARE @dealIpdRunId        INT,
        @dealId              SMALLINT,
        @ipdDate             DATETIME,
        @previousIPDDateName VARCHAR(200)='PreviousIPD',
		@PreviousRunNum      SMALLINT, 
		@previousIpdDate      DATE,  
		@dealPreviousIpdRunId INT,
		@RatedClosingBalance DECIMAL(38,16) 

		SELECT   
	  @dealIpdRunId = dir.DealIpdRunId  
	  , @dealId = dir.DealId  
	  , @ipdDate = di.IpdDate  
	  , @previousIpdDate  = ipdDt.PreviousIPD  
	 FROM     
	  cw.vwDealIpdDates ipdDt  
	 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
	 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
	 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
	 WHERE   
	  deal.DealName = @pDealName  
	  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
	  AND dir.IpdSequence <> 0   
	        
	 SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
	 JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
	 WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1

      IF( Object_id('tempdb..#tempReserve') IS NOT NULL ) 
        DROP TABLE #tempReserve 
      IF( Object_id('tempdb..#tempReserveRatedNotes') IS NOT NULL ) 
        DROP TABLE #tempReserveRatedNotes 
      IF( Object_id('tempdb..#tempReserveClassA') IS NOT NULL ) 
        DROP TABLE #tempReserveClassA 
      IF( Object_id('tempdb..#tempFinal') IS NOT NULL ) 
        DROP TABLE #tempFinal 
      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL ) 
        DROP TABLE #tempPrevious 
      IF( Object_id('tempdb..#tempPreviousInverted') IS NOT NULL ) 
        DROP TABLE #tempPreviousInverted 

      SELECT rf.DealReserveFundId, 
             rf.DisplayName, 
             ReserveFundRequiredAmount, 
             ReserveFund_bF, 
             DrawingsInPeriod, 
             CreditReceived, 
             ReserveFund_cf, 
			 rPre.ReserveResidualAmount,
             CONVERT(DECIMAL(38, 16), NULL) RatedNotePercentage, 
             CONVERT(DECIMAL(38, 16), NULL) ClassAPercentage 
      INTO   #tempReserve 
      FROM   cw.ReserveFund_PostWf rPost
             JOIN cw.ReserveFund_PreWf rPre ON rPost.DealIpdRunId = rPre.DealIpdRunId 
             JOIN cfgcw.DealReserveFund rf  ON rf.DealReserveFundId = rPre.ReserveFundId 
             AND rPre.ReserveFundId = rPost.ReserveFundId 
      WHERE  rPre.DealIpdRunId = @dealIpdRunId 
             
	SELECT @RatedClosingBalance = sum(nPost.Principal_Cf)   
	FROM cw.NoteData_Postwf nPost  
		JOIN cfgcw.DealNote dn ON nPost.DealNoteId = dn.DealNoteId  
	WHERE  
	nPost.DealIpdRunId = @dealIpdRunId  
	AND dn.IsRatedNOte = 1  
    

	SELECT rfnp.DealReserveFundId,sum(nPost.Principal_Cf) AClosingBalance 
	INTO #tempReserveClassA
	FROM cw.NoteData_Postwf nPost
		 JOIN cfgcw.DealNote dn ON nPost.DealNoteId = dn.DealNoteId
		 JOIN cfgcw.DealReserveFundNoteMap rfnp ON rfnp.DealNoteId = dn.DealNoteId
	WHERE 
		nPost.DealIpdRunId = @dealIpdRunId
	AND dn.NoteRank = 1
	GROUP BY rfnp.DealReserveFundId

	UPDATE #tempReserve
	SET RatedNotePercentage = CASE WHEN @RatedClosingBalance = 0 THEN 0 ELSE  (ReserveFund_cf/@RatedClosingBalance)  END 
	

	UPDATE #tempReserve
	SET ClassAPercentage = CASE WHEN AClosingBalance = 0 THEN 0 ELSE (ReserveFund_cf/AClosingBalance) END
	FROM #tempReserve, #tempReserveClassA
	WHERE #tempReserve.DealReserveFundId = #tempReserveClassA.DealReserveFundId
	

      SELECT DisplayName                    AS ReserveName, 
             LineItemName, 
             CurrentPeriodAmount, 
             CONVERT(DECIMAL(38, 16), NULL) PreviousPeriodAmount 
      INTO   #tempFinal 
      FROM   #tempReserve 
             UNPIVOT ( CurrentPeriodAmount 
                     FOR LineItemName IN (ReserveFundRequiredAmount, 
                                          ReserveFund_bF, 
                                          DrawingsInPeriod, 
                                          CreditReceived, 
                                          ReserveFund_cf,
										  ReserveResidualAmount,
										RatedNotePercentage, 
										ClassAPercentage) ) unpiv; 

		

      ---------------------------------------------previous 
      SELECT rf.DealReserveFundId, 
             rf.DisplayName, 
             ReserveFundRequiredAmount, 
             ReserveFund_bF, 
             DrawingsInPeriod, 
             CreditReceived, 
             ReserveFund_cf,
			 ReserveResidualAmount,
             CONVERT(DECIMAL(38, 16), NULL) RatedNotePercentage, 
             CONVERT(DECIMAL(38, 16), NULL) ClassAPercentage
      INTO   #tempPrevious 
      FROM   cw.ReserveFund_PostWf rPost 
             JOIN cw.ReserveFund_PreWf rPre ON rPost.DealIpdRunId = rPre.DealIpdRunId
             JOIN cfgcw.DealReserveFund rf  ON rf.DealReserveFundId = rPre.ReserveFundId 
             AND rPre.ReserveFundId = rPost.ReserveFundId 
      WHERE  
				rPre.DealIpdRunId = @dealPreviousIpdRunId 
             

	
	DELETE FROM #tempReserveClassA 

	SELECT @RatedClosingBalance = sum(nPost.Principal_Cf)   
	FROM cw.NoteData_Postwf nPost  
		JOIN cfgcw.DealNote dn ON nPost.DealNoteId = dn.DealNoteId  
	WHERE   
	nPost.DealIpdRunId = @dealPreviousIpdRunId  
	AND dn.IsRatedNOte = 1 

	INSERT INTO #tempReserveClassA 
	SELECT rfnp.DealReserveFundId,sum(nPost.Principal_Cf) AClosingBalance 
	FROM cw.NoteData_Postwf nPost
	     JOIN cfgcw.DealNote dn ON nPost.DealNoteId = dn.DealNoteId
		 JOIN cfgcw.DealReserveFundNoteMap rfnp ON rfnp.DealNoteId = dn.DealNoteId
	WHERE 
		nPost.DealIpdRunId = @dealPreviousIpdRunId
		AND dn.NoteRank = 1
		GROUP BY rfnp.DealReserveFundId


	 UPDATE #tempPrevious  
		SET RatedNotePercentage = CASE WHEN @RatedClosingBalance = 0 THEN 0 ELSE  (ReserveFund_cf/@RatedClosingBalance)  END 
	


	UPDATE #tempPrevious
	SET ClassAPercentage = CASE WHEN AClosingBalance = 0 THEN 0 ELSE (ReserveFund_cf/AClosingBalance) END
	FROM #tempPrevious, #tempReserveClassA
	WHERE #tempPrevious.DealReserveFundId = #tempReserveClassA.DealReserveFundId


      SELECT DisplayName AS ReserveName, 
             LineItemName, 
             PreviousPeriodAmount 
      INTO   #tempPreviousInverted 
      FROM   #tempPrevious 
             UNPIVOT ( PreviousPeriodAmount 
                     FOR LineItemName IN (ReserveFundRequiredAmount, 
                                          ReserveFund_bF, 
                                          DrawingsInPeriod, 
                                          CreditReceived, 
                                          ReserveFund_cf,
										  ReserveResidualAmount,
										RatedNotePercentage, 
										ClassAPercentage) ) unpiv; 


      UPDATE #tempFinal 
      SET    #tempFinal.PreviousPeriodAmount = #tempPreviousInverted.PreviousPeriodAmount 
      FROM   #tempFinal, 
             #tempPreviousInverted 
      WHERE  #tempFinal.ReserveName = #tempPreviousInverted.ReserveName 
             AND #tempFinal.LineItemName = #tempPreviousInverted.LineItemName 


		 IF( Object_id('tempdb..#tempLineOrder') IS NOT NULL ) 
				DROP TABLE #tempLineOrder 

		CREATE TABLE #tempLineOrder (InternalName varchar(200), DisplayName varchar(500), sortOrder decimal(9,3))

		INSERT INTO #tempLineOrder VALUES
		 ('ReserveFundRequiredAmount','Reserve Fund Required Amount',1)			
		,('ReserveFund_bF','Reserve Fund B/F',2)						
		,('DrawingsInPeriod','Drawings in Period',3)					
		,('ReserveResidualAmount','Release in Period',3.1)
		,('CreditReceived','Credit Received from Revenue Priority of Payments',4)						
		,('ReserveFund_cf','Reserve Fund C/F',5)						
		,('ClassAPercentage','% of Class A Notes',6)						
		,('RatedNotePercentage','% of Rated Notes	',7)					


      SELECT ReserveName, 
             DisplayName, 
             CASE WHEN InternalName IN ( 'RatedNotePercentage', 'ClassAPercentage' ) THEN CAST( CONVERT(DECIMAL(38, 8), CurrentPeriodAmount) AS VARCHAR) 
                                 ELSE             CAST(CONVERT(DECIMAL(38, 2), (CurrentPeriodAmount)) AS VARCHAR) END AS  CurrentPeriodAmount, 

             CASE WHEN InternalName IN ( 'RatedNotePercentage', 'ClassAPercentage' ) THEN CAST( CONVERT(DECIMAL(38, 8), PreviousPeriodAmount) AS VARCHAR) 
                                 ELSE             CAST(CONVERT(DECIMAL(38, 2), (PreviousPeriodAmount)) AS VARCHAR) END AS  PreviousPeriodAmount
      FROM   #tempFinal 
	         JOIN #tempLineOrder ON #tempFinal.LineItemName = #tempLineOrder.InternalName
	  --WHERE 
	  ORDER BY ReserveName, #tempLineOrder.sortOrder
    END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetReserveSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  END 

GO