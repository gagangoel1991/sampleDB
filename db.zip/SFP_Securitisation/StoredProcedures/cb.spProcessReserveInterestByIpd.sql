USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spProcessReserveInterestByIpd]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessReserveInterestByIpd]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spProcessReserveInterestByIpd]
/*-----------------------------------------------------
 * Author: Kapil Sharma
 * Date:	25.01.2022
 * Description:  This will calculate the interest on Reserve for a particular IPD
 * 
 * Example: 
 * [cb].[spProcessReserveInterestByIpd] 1034
 * 				
 * Change History
 * --------------
 * Author		Date		Description
-------------------------------------------------------*/
(
	@pDealIpdRunId				INT
)
AS
BEGIN
	BEGIN TRY

		IF EXISTS(SELECT TOP 1 * FROM cw.DealIpdRun WHERE RunId = @pDealIpdRunId AND IsCurrentVersion = 1)
		BEGIN
			BEGIN TRANSACTION

			DECLARE
				@dealId							INT,
				@date							DATE,
				@collectionStartDate			DATE,
				@collectionEndDate				DATE,
				@prevIpdRunId					INT,
				@prevIpdDate					DATE
			
			SELECT @dealId = deal.DealId, @prevIpdDate = did.PreviousIPD,
				@collectionStartDate = did.CollectionBusinessStart, @collectionEndDate = did.CollectionBusinessEnd
			FROM cfg.Deal deal
			JOIN cw.DealIpd di ON di.DealId = deal.DealId
			JOIN cw.DealIpdRun dir ON dir.DealIpdId = di.DealIpdId
			JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = deal.JurisdictionMarkerId
			JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId AND di.DealId = deal.DealId
			WHERE dir.RunId = @pDealIpdRunId AND dir.IsCurrentVersion = 1  

			SELECT @prevIpdRunId = dir.RunId FROM cw.DealIpdRun dir
			JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId
			WHERE dir.IsCurrentVersion = 1 AND di.IpdDate = @prevIpdDate

			SET @date = @collectionStartDate

			WHILE @date <= @collectionEndDate
			BEGIN
				EXEC [cb].[spCalculateOneDayReserveInterest] @date

				SET @date = DATEADD(DD, 1, @date)
			END

			COMMIT TRANSACTION;  
		END

	END TRY
	BEGIN CATCH

		IF @@trancount > 0 ROLLBACK TRANSACTION; 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spProcessReserveInterestByIpd', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO