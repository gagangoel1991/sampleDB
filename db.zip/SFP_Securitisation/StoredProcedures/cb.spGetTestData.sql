USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spGetTestData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetTestData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spGetTestData] 
(
	  @pDealId INT 
	, @pIPDRunId INT
	, @pTestTypeName		VARCHAR(100)
	, @pUserName			VARCHAR(80) = NULL
)
/* 
 *   Author: Arun
 *   Date:  25.02.2022 
 *   Description:  Get the test data based on test type
 *   
 *   Example - EXEC [cb].[spGetTestData] 6, 66, 'ICT12MonthsForwardTest', 'System'
 *   EXEC [cb].[spGetTestData] 6, 66, 'AssetCoverageTest', 'System'
 *   
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
*/ 
AS 
BEGIN 
	 BEGIN TRY 

		 DECLARE 
			@dealIpdRunId                  INT,
			@dealId                        SMALLINT,
			@collectionEndDt               DATE,
            @parentTestLineItemId          INT,
			@IpdDate					   Date


			SELECT @DealId = DealId
			,@IpdDate = IpdDate
			FROM [cw].[vwDealIpdRun]
			WHERE DealIpdRunId = @pIPDRunId;

			-- Current and Previous 3 ipd run id 
			SELECT TOP 4 
				 DealIpdId
				,DealIpdRunId
				,IpdDate
			INTO #DealRunDetail
			FROM [cw].[vwDealIpdRun]
			WHERE IpdDate <= @IpdDate
				AND DealId = @DealId
				AND IpdSequence > 131
			ORDER BY IpdDate DESC;

			

			 SELECT   
                @collectionEndDt = ipdDt.CollectionBusinessEnd
              FROM     
                     cw.vwDealIpdDates ipdDt  
              JOIN #DealRunDetail r ON r.DealIpdId =ipdDt.DealIpdId 
			


		IF(@pTestTypeName='ICT12MonthsForwardTest')
		BEGIN		

			DECLARE @tblTestLineItemValue TABLE (
				TestLineItemId INT
				,InternalName VARCHAR(200)
				,DisplayName VARCHAR(200)
				,LineItemValue VARCHAR(100)
				,SortOrder INT
				,ParentTestLineItemId INT
				,DealIpdRunId INT
				,IpdDate Date
				,IsRedemptionSeries INT
			)

			INSERT INTO @tblTestLineItemValue (
				TestLineItemId
				,InternalName
				,DisplayName
				,LineItemValue
				,SortOrder
				,ParentTestLineItemId
				,DealIpdRunId
				,IpdDate
				)
              
			  SELECT 
                     tli.TestLineItemId,
                     tli.InternalName,
                     tli.DisplayName, 
                     tliv.Value,
                     tli.SortOrder,
                     tli.ParentTestLineItemId,
					 r.DealIpdRunId,
					 r.IpdDate
              FROM 
				cfgcb.TestType tt
				JOIN cfgcb.TestLineItem tli ON tt.TestTypeID = tli.TestTypeID
				CROSS JOIN #DealRunDetail r
				LEFT JOIN cb.TestLineItemValue tliv ON tliv.DealIpdRunId = r.DealIpdRunId AND tliv.TestLineItemID = tli.TestLineItemID
              WHERE 
                     tt.InternalName = 'ICT12MonthsForwardTest' 
              ORDER BY 
                     tli.SortOrder 

			SELECT @parentTestLineItemId = TestLineItemId
			  FROM cfgcb.TestLineItem
			  WHERE InternalName = 'ICT12Months_NetAnnualCBSwap_NotePayment'

            --Now insert active notes details
			INSERT INTO @tblTestLineItemValue (
			     TestLineItemId
			     ,InternalName
			     ,DisplayName
			     ,LineItemValue
			     ,SortOrder
			     ,ParentTestLineItemId
				 ,DealIpdRunId
				 ,IpdDate
				 ,IsRedemptionSeries
			   )

				SELECT dn.DealNoteId
					,dn.[Name]
					,dn.[Name]
					,CASE 
						WHEN dn.IsSwapLinked = 1
							THEN nsWF.PayRate * dnWF.PrincipalOutstanding_GBP
						ELSE dnWF.RateForEstimation * dnWF.PrincipalOutstanding_GBP
						END
					,ROW_NUMBER() OVER (ORDER BY dn.DealNoteId) + 2
					,@parentTestLineItemId
					,dnWF.DealIpdRunId
					,r.IpdDate

					, CASE WHEN r.IpdDate > (Select MIN(Ipddate) from cw.vwDealIpdRun dir where dir.Dealid = @pDealId AND dir.IpdDate>= ISNULL(dn.NewRedemptionDate, dn.MaturityDate))	THEN 0
					  ELSE 1 END AS IsRedemptionSeries

				FROM cfgcb.DealNote dn
              JOIN cb.DealNote_Wf dnWF ON dnWF.DealNoteId = dn.DealNoteId
			  JOIN #DealRunDetail r ON r.DealIpdRunId = dnWF.DealIpdRunId 
              LEFT JOIN cfgcb.NoteSwap ns ON dn.DealNoteId = ns.DealNoteId AND ns.ValidTo>=@collectionEndDt
              LEFT JOIN cb.NoteSwap_Wf nsWF ON nsWF.NoteSwapId = ns.NoteSwapId AND nsWF.DealIpdRunId = dnWF.DealIpdRunId
            
            SELECT 
				     ParentTestLineItemId,
					 TestLineItemId, 
					 InternalName, 
					 DisplayName,
					 InternalName  AS InternalTestLineItem, 
					 CASE WHEN IsRedemptionSeries =0 THEN '-' ELSE ISNULL(LineItemValue,'-') END AS LineItemValue,
					 DealIpdRunId,
					 IpdDate
			  FROM @tblTestLineItemValue 
			  WHERE DisplayName Not IN (
								SELECT DisplayName
								FROM 
								( Select DisplayName, IsNull(IsRedemptionSeries,1) as IsRedemptionSeries, count(IsRedemptionSeries) countRow 
									FROM @tblTestLineItemValue 
									Group by DisplayName, IsNull(IsRedemptionSeries,1)
								) as TBL where IsNull(IsRedemptionSeries,1)=0 and countRow=4)
			  ORDER BY SortOrder

		END
		ELSE
		BEGIN
		
			SELECT
				tli.ParentTestLineItemId,
				tli.TestLineItemId,
				tt.InternalName,
				tli.DisplayName, 
				tli.InternalName AS InternalTestLineItem, 
				CASE WHEN  tli.InternalName IN ( 'ACT_1.1_A(ii)_MaximumAssetPercentageFromFitch'
				, 'ACT_1.1_A(ii)_MaximumAssetPercentageFromMoodys'
				, 'ACT_1.1_A(ii)_MoodysBenchmark'
				, 'ACT_1.1_MethodUsedForCalculatingComponentA'
				, 'ACT_CreditSupportAsDerivedFromACTPercentage') 
				THEN 
					CASE WHEN IsNumeric(tliv.Value) = 1 THEN 
						ISNULL(CAST(Cast(tliv.Value AS float) * 100 AS varchar)  + '%' , '-') 
					ELSE
						ISNULL(tliv.Value,'-')
					END
				ELSE 
					ISNULL(tliv.Value,'-')
				END AS LineItemValue,

				r.DealIpdRunId,
				r.IpdDate
			FROM  				
				cfgcb.TestType tt
				JOIN cfgcb.TestLineItem tli ON tt.TestTypeID = tli.TestTypeID
				CROSS JOIN #DealRunDetail r
				LEFT JOIN cb.TestLineItemValue tliv ON tliv.DealIpdRunId = r.DealIpdRunId AND tliv.TestLineItemID = tli.TestLineItemID
			WHERE 
				tt.InternalName = @pTestTypeName  
				
			ORDER BY 
				tli.SortOrder , tli.ParentTestLineItemId
		END

	END TRY 
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.[spGetTestData]', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH   
END 
GO
