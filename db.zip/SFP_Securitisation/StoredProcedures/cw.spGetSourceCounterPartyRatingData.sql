USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetSourceCounterPartyRatingData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetSourceCounterPartyRatingData]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetSourceCounterPartyRatingData]   
/*  
 * Author: Gunjan Chandola  
 * Date: 26.03.2021  
 * Description:  This will return unmodified CP rating for collection business date and IPD Run ID 
 * [cw].[spGetSourceCounterPartyRatingData] 14,4,'Test'
 * Change History  
 * --------------  
 * 
 * Author: Saurabh Bhatia  
 * Date: 22.06.2021  
 * -------------------------------------------------------  
*/  
@pDealId  INT,   
@pIPDRunId INT,
@pUserName  VARCHAR(80)  
AS  
BEGIN  
  
 SET NOCOUNT ON  
 
 BEGIN TRY  
      DECLARE @cols AS NVARCHAR(MAX),@collectionStartDate DATE, @collectionEndDate DATE, @query VARCHAR(MAX), @latestRatingDate DATE
      
	    SELECT  @cols = STUFF((SELECT DISTINCT ',' + CAST(CisCode AS NVARCHAR(20)) 
		FROM [cfgCW].[DealCounterParty] dcp
			 JOIN [CW].[vw_DealLookup] dlv ON dlv.LookupValueId = dcp.DealCounterpartyTypeId
		WHERE dcp.IsActive=1 AND DealId=@pDealId AND dlv.Name <> 'Booking' 
        FOR XML PATH(''), TYPE).value('.', 'NVARCHAR(MAX)') ,1,1,'');			

		SELECT @collectionStartDate = CAST(CollectionBusinessStart AS DATE)
			,@collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
		FROM [cw].[vwDealIpdDates] ipdDt
		JOIN cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE ipdRun.RunId = @pIPDRunId
		
        SET @latestRatingDate=(SELECT CAST(MAX(cpr.RatingDate) AS DATE) FROM [cw].[SourceCounterPartyRating] cpr WHERE cpr.RatingDate
		BETWEEN @collectionStartDate AND @collectionEndDate 
		)
              
      IF OBJECT_ID('tempdb..#tempCpRating') IS NOT NULL DROP TABLE #tempCpRating
      
      SELECT  rt.Name AS RatingType
      ,CASE WHEN cpr.RatingDate=@collectionEndDate THEN 0 ELSE 1 END AS IsPostCollectionEndDate  
      ,cpr.CisCode
      ,cra.Name AS RatingAgency
      ,rt.RatingTypeId
      ,cra.CRAId
      ,cpr.RatingDate
      ,cpr.Rating 
      ,NULL AS ModifiedBy
      ,NULL AS ModifiedDate INTO #tempCpRating
      FROM [cw].[SourceCounterPartyRating] cpr
        JOIN cfgcw.RatingType rt ON rt.RatingTypeId = cpr.RatingTypeId AND rt.IsActive = 1
        JOIN cfgcw.CreditRatingAgency cra ON cra.CRAId = cpr.CRAId AND cra.IsActive = 1
		JOIN cfgcw.DealSubjectCRAMap dscm ON dscm.CRAId = cra.CRAId AND dscm.DealId = @pDealId AND dscm.IsActive = 1	
		JOIN cfgcw.DealSubjectType dst ON dst.DealSubjectTypeId = dscm.DealSubjectTypeId AND dst.[Name] = 'Counterparty'
      WHERE  CAST(cpr.RatingDate AS DATE)=@latestRatingDate

    
    
    SET @query = 
                'SELECT * FROM 
                (
                    SELECT RatingDate,IsPostCollectionEndDate, CRAId, RatingTypeId, CisCode, RatingType, RatingAgency, Rating, ModifiedBy, ModifiedDate FROM #tempCpRating
                ) src
                pivot 
                (
                    MAX(Rating) for CisCode in (' + @cols + ')
                ) piv'

    EXECUTE(@query)


 END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'cw.spGetSourceCpRatingData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END 
GO