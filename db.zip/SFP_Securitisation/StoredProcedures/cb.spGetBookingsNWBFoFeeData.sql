USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingsNWBFoFeeData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingsNWBFoFeeData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 06-Feb-2032 
--Description: GET Booking NWB FO Fees Data 
--[cb].[spGetBookingsNWBFoFeeData] 6,60,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingsNWBFoFeeData] 
   @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  

BEGIN TRY  
     SELECT
		CONVERT(VARCHAR(30),dir.IpdDate,103) AS [ValueDate],
		CONVERT(VARCHAR(30),dir.IpdDate,103) AS [AccrualStart],
		CONVERT(VARCHAR(30),dir.IpdDate,103) AS [AccrualEnd],
		bv.Currency,
		TRY_CAST(bv.[Value] AS DECIMAL(18, 2)) as FeeAmount,
		'None' as TaxType,
		'' AS TaxRate,
		bv.FeeType,
		IIF(TRY_CAST(CASE WHEN bv.[Value] = '-' THEN '0' ELSE bv.[Value] END AS DECIMAL(18,3)) > 0,'Receivable','Payable') AS PayRec,
		'Verified' AS PropVeri,
		bv.BookName AS BookCode,
		'NWBPLC GT DEIMOS COL' AS BookingEntity,
		bv.CounterpartyName AS Counterparty,
		IIf(bv.LineItemInternalName = 'GT_Interest_Top-up_NCA1_14', 'Yes', 'No') As SendMsg,
		'IPD Payment' AS SwiftField,
		bv.LineItem AS Memo,
		'No' AS GTCollection,
		'No' AS ReductionAmount
	FROM 
		[cb].[vwBookingLineItems] bg
			LEFT JOIN [cb].[vwBookingLineItemValue] bv ON bg.BookingLineItemId =bv.BookingLineItemId
			LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
	WHERE 
			bg.BookingGroupInternalName  IN ('NW_Collections_Account-(4607236 - LDNAWELO-GBP)')
			AND bg.Dealname='Deimos' 
			AND bv.DealIpdRunId = @pIPDRunId AND dir.IsCurrentVersion = 1 AND bg.DealId = @pDealId
			AND bv.LineItemInternalName in ('GT_Interest_Top-up_NCA1_14','Servicer_charges_NCA1_15',
			'Cash_Manager_charges_NCA1_16',
			'Account_Bank_charges_NCA1_17',
			'Asset_Monitor_charges_NCA1_18',
			'Credit_Coupon_PaymentLedger_NCA1_19',
			'Credit_Pre-Maturity_Liquidity_Ledger_NCA1_20',
			'Credit_Revenue Ledger_NCA1_21',
			'Excluded_Swap_Termination_Amounts__NCA1_22',
			'Indemnity_amounts_due_to_Asset_NCA1_23',
			'Repay_RBS_Cash_Capital_Contributions_NCA1_24',
			'Payment_of_NWB_Deferred_Consideration_NCA1_25',
			'Fee_payable_to_Liquidation_Member_NCA1_26',
			'Profit_payable_to_Members_NCA1_27')


	ORDER BY IIF(TRY_CAST(REPLACE(bv.Value,'-','0') AS DECIMAL(12,3)) >0,'Receivable','Payable') DESC
  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetBookingsNWBFoFeeData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END

Go