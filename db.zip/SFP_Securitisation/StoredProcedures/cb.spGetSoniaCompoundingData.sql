USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetSoniaCompoundingData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetSoniaCompoundingData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Suresh Pandey 
--Date: 17-02-2022 
--Description: GET Sonia compounding data
--   [cb].[spGetSoniaCompoundingData] '2021-02-08 00:00:00.000','2021-06-08 00:00:00.000',''
--==================================   
CREATE PROCEDURE [cb].[spGetSoniaCompoundingData] 
	@pAccrualStartDate DATE,
	@pAccrualEndDate DATE,
	@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY

		SELECT [Value] AS [Reset Lead],
			CONVERT(VARCHAR,ResetDate,103) AS [Reset Date],
			CONVERT(VARCHAR,AccrualStartDate,103) AS [Accrual Start Date], 
			CONVERT(VARCHAR,AccrualEndDate,103) AS [Accrual End Date],
			DATEDIFF(DAY,AccrualStartDate,AccrualEndDate) AS [Days],
			SoniaRate AS [1 -day SONIA Rate (MDX)],
			DayCountMethod_ACT AS [Compounded Rate (Actual/Actual)],
			DayCountMethod_365 AS [Compounded Rate (Actual/365)],
			DayCountMethod_360 AS [Compounded Rate (Actual/360)]
		FROM
		(
			SELECT 
				srld.[Value], 
				scr.ResetDate,
				scr.AccrualStartDate,
				scr.AccrualEndDate,
				scr.SoniaRate,
				vlook.[Name],
				scar.Rate
			FROM cb.SoniaCompoundingRate scr
			JOIN cb.SoniaCompoundingAccrualRate scar ON scar.SoniaCompoundingRateId=scr.SoniaCompoundingRateId
			JOIN cw.vw_DealLookup vlook ON vlook.LookupValueId = scar.AccrualBasisTypeId
			JOIN cfgcb.SoniaResetLeadDays srld ON srld.SoniaResetLeadDaysId=scr.SoniaResetLeadDaysId
			WHERE scr.AccrualStartDate >= @pAccrualStartDate 
				AND scr.AccrualEndDate <= @pAccrualEndDate
				AND vlook.TypeCode = 'DayCountMethod'


			
		) AS SourceTable 
				PIVOT(max([Rate]) FOR [Name] IN (DayCountMethod_ACT ,DayCountMethod_365,DayCountMethod_360)) AS PivotTable;
 

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spGetSoniaCompoundingData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO
GO


