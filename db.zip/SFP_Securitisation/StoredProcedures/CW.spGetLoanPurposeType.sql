USE [SFP_Securitisation]
GO

IF OBJECT_ID('CW.spGetLoanPurposeType') IS NOT NULL
	DROP PROC CW.spGetLoanPurposeType
GO

