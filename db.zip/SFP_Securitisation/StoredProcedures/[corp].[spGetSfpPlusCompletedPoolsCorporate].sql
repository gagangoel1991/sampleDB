USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetSfpPlusCompletedPoolsCorporate]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetSfpPlusCompletedPoolsCorporate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 *   Author: Sakthivel Loganathan
 *   Date:  23-Feb-2023
 *   Description: To get Corporate's completed pool data for dashboard (being called from the sp:[ps].[spGetSFPPlusDashBoardCompletedPools])
 *   Change History 
 *   ---------------------------------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   exec [CORP].[spGetSfpPlusCompletedPoolsCorporate] '1 jan 2023','1 feb 2023','System', 2
*/

 -- RETAIL VERSION : [ps].[spGetSFPPlusCompletedPools]
CREATE PROCEDURE [CORP].[spGetSfpPlusCompletedPoolsCorporate]    
(          
	 @pFromDate DATE,    
	 @pToDate DATE,    
	 @pUserName VARCHAR(50),  
	 @pAssetClassID  INT
)          
AS          
BEGIN          
 BEGIN TRY
	DECLARE @PoolStatusCompleteId INT    
	DECLARE @PoolStatusAuthorisedId INT    
	DECLARE @PoolPurposeIDRepurchase INT    

    SELECT @PoolStatusCompleteId = MAX(IIF(status = 'Complete',poolstatusid ,0)) , @PoolStatusAuthorisedId = MAX(IIF(status = 'Authorised',poolstatusid ,0)  )
    FROM   ps.poolstatus 
	WHERE  status in( 'Authorised','Complete')  
    
    SELECT @PoolPurposeIDRepurchase = PoolPurposeId    
    FROM   ps.PoolPurpose    
    WHERE  PoolPurpose = 'Repurchase';    
    
    DECLARE @poolPartitionMap_Tbl TABLE (poolid INT, hypopoolpartitionid INT)     
    
    INSERT INTO @poolPartitionMap_Tbl (poolid, hypopoolpartitionid)  
    SELECT poolid,  CONVERT(VARCHAR, vintagedate, 112)  
    FROM   ps.pool  
    WHERE ( ((batchprocessingdate BETWEEN @pFromDate AND @pToDate AND PoolStatusId = @PoolStatusCompleteId)  
      OR (EffectiveDate BETWEEN @pFromDate AND @pToDate AND PoolStatusId = @PoolStatusAuthorisedId))  )
	  AND AssetClassId = @pAssetClassID
	  --AND PoolStatusId = 2  -- test added

     IF EXISTS (SELECT 1   FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#sourcePoolDetail') AND type = 'U')  
		DROP TABLE #sourcepooldetail  
	 IF EXISTS (SELECT 1   FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#PoolBuildDetail')  AND type = 'U')  
		DROP TABLE #poolbuilddetail  
	 IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#sourceDetails') AND type = 'U')  
		DROP TABLE #sourcedetails  
	 IF EXISTS (SELECT 1   FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#sourceDetails_1')   AND type = 'U')  
		DROP TABLE #sourcedetails_1  
	 IF EXISTS (SELECT 1  FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#closedLoans')  AND type = 'U')  
		DROP TABLE #closedLoans   
    
    SELECT pbd.poolid,    
        pbd.mortgageaccountkey,    
        pbd.mortgagesubaccountkey,
		pbd.LoanId
    INTO   #poolbuilddetail    
    FROM   ps.poolbuilddetail pbd    
    WHERE  pbd.poolid IN (SELECT poolid    
           FROM   @poolPartitionMap_Tbl)    
     AND pbd.IsActive = 1    

	 ------------------------
	SELECT DISTINCT--FCAP.*, FF.SourceId , tmp2.poolid 
			CASE WHEN pl.PoolPurposeId = 2 THEN -1 ELSE FCAP.DealId END AS mortgagedealkey,
			pbd.poolid,
			FF.FacilityKey AS mortgageaccountkey,
			NULL AS mortgagesubaccountkey,
			NULL AS AccountClosureDate,
			pbd.LoanId
	INTO   #sourcepooldetail  
	FROM [corp].[syn_SfpModelCorporate_vw_FactCorporateAssetPool] FCAP (nolock)   
	INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] FF (nolock) ON FCAP.FacilityId = FF.FacilityId  
	INNER JOIN #poolbuilddetail pbd ON pbd.MortgageAccountKey = FF.FacilityKey  --AND pbd.LoanId = REPLACE(FF.FacilityId, '\P','')  -- sakk
	--INNER JOIN  @poolPartitionMap_Tbl tmp2 ON tmp2.hypopoolpartitionid = ff.PartitionId --AND tmp2.poolid = pbd.PoolId
	INNER JOIN ps.pool pl on pbd.PoolId = pl.PoolId 
	WHERE ff.PartitionId IN (SELECT hypopoolpartitionid FROM @poolPartitionMap_Tbl)


	
	 SELECT source.mortgagedealkey,    
         source.poolid,    
         source.mortgageaccountkey,    
         source.mortgagesubaccountkey,    
         source.loanid    
     INTO   #sourcedetails_1    
     FROM   #sourcepooldetail source

    
	 -- For sfp_model.[rpt].[FlaggingAssetHistory] there is no table in sfp_model_corporate. Need to check.
     SELECT source.loanid,    
            source.poolid    
     INTO   #closedloans    
     FROM   #sourcedetails_1 source    
         INNER JOIN sfp.syn_sfpmodel_vw_flaggingassetclosedloanhistory cl    
           ON source.poolid = cl.poolid AND source.loanid = cl.loanid 

     SELECT source.mortgagedealkey,    
         source.poolid,    
         Count(DISTINCT source.mortgageaccountkey)    AS AccountCount,    
         Count(DISTINCT source.mortgagesubaccountkey) AS SubAccountCount,    
         Count(DISTINCT cl.loanid)                    AS ClosedLoanCount    
     INTO   #sourcedetails    
     FROM   #sourcedetails_1 source    
         INNER JOIN ps.pool p   ON source.poolid = p.poolid    
         LEFT JOIN #closedloans cl ON cl.poolid = source.poolid    
     WHERE  ( ( p.poolpurposeid <> @PoolPurposeIDRepurchase    
          AND source.loanid NOT IN (SELECT loanid   FROM   #closedloans) )    
         OR p.poolpurposeid = @PoolPurposeIDRepurchase )    
     GROUP  BY source.mortgagedealkey, source.poolid;

	SELECT p.poolid,    
        PoolName = p.NAME,    
        Purpose = purpose.poolpurpose,    
        CASE WHEN sourceDeal.dealname = 'NA' then 'No Deal' ELSE sourceDeal.dealname END AS SourceDeal,
        TargetDeal = TargetDeal.dealname,    
        NumberOfLoans = source.accountcount,    
        NumberOfSubAccounts = source.subaccountcount,    
        ClosedLoanCount = source.ClosedLoanCount,    
        PoolStatus = pstatus.Status,    
        EffectiveDate = CASE WHEN p.PoolStatusId = @PoolStatusAuthorisedId THEN p.EffectiveDate ELSE p.BatchProcessingDate END ,
		P.VintageDate,
		CASE WHEN TargetDeal.CashReportingFlag = 'Y' then 'Cash Deal'
			  WHEN TargetDeal.CashReportingFlag = 'N' then 'Non-Cash Deal'
			  ELSE NULL END CashReportingFlag
    FROM   [ps].[pool] p    
    INNER JOIN [ps].[poolpurpose] purpose ON p.poolpurposeid = purpose.poolpurposeid    
    INNER JOIN [ps].[PoolStatus] pstatus ON p.PoolStatusId = pstatus.PoolStatusId    
    INNER JOIN #sourcedetails source ON source.poolid = p.poolid    
    INNER JOIN [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] sourceDeal ON sourceDeal.DealId = source.mortgagedealkey    
    INNER JOIN [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] TargetDeal ON TargetDeal.DealId = p.targetpoolid    
    ORDER BY p.EffectiveDate DESC, p.NAME ASC; 
    
    
   IF EXISTS (SELECT 1   FROM   tempdb.sys.objects  WHERE  object_id = Object_id(N'tempdb..#sourcePoolDetail') AND type = 'U')  
		DROP TABLE #sourcepooldetail  
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#PoolBuildDetail')  AND type = 'U')  
		DROP TABLE #poolbuilddetail  
	IF EXISTS (SELECT 1  FROM   tempdb.sys.objects WHERE  object_id = Object_id(N'tempdb..#sourceDetails') AND type = 'U')  
		DROP TABLE #sourcedetails  
	IF EXISTS (SELECT 1   FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#sourceDetails_1')   AND type = 'U')  
		DROP TABLE #sourcedetails_1  
	IF EXISTS (SELECT 1  FROM   tempdb.sys.objects   WHERE  object_id = Object_id(N'tempdb..#closedLoans')  AND type = 'U')  
		DROP TABLE #closedLoans     
                  
 END TRY                        
 BEGIN CATCH                        
  DECLARE                         
  @errorMessage     NVARCHAR(MAX),                        
  @errorSeverity    INT,                        
  @errorNumber      INT,                        
  @errorLine        INT,                        
  @errorState       INT;                        
  SELECT                         
  @errorMessage = ERROR_MESSAGE()    
  ,@errorSeverity = ERROR_SEVERITY()    
  ,@errorNumber = ERROR_NUMBER()    
  ,@errorLine = ERROR_LINE()    
  ,@errorState = ERROR_STATE()                        
                        
  EXEC app.SaveErrorLog 2, 1, 'spGetSFPPlusDashBoardCompletedPools', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''                        
                          
  RAISERROR (@errorMessage,                        
     @errorSeverity,                        
     @errorState )                        
 END CATCH          
END  
  
GO
--EXEC [ps].[spGetSfpPlusCompletedPoolsCorporate] '13 JAN 2023', '13 FEB 2023', 'LOGAS', 2