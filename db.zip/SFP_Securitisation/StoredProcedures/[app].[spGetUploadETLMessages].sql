USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spGetUploadETLMessages]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[spGetUploadETLMessages]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spGetUploadETLMessages]
(	
	@pFileInfoId INT,
	@pUserName VARCHAR(50)	
)      
AS      
BEGIN      
	BEGIN TRY   
		DECLARE @PackageName VARCHAR(max);
		SELECT @PackageName = '%'+StagingPackageName+'%' 
		FROM app.FileWorkflowConfig 
		WHERE FileInfoId = @pFileInfoId;

		SELECT 
		 TaskName, EventCode, EventDescription, StartTime 
		FROM [app].[syn_Configuration_tbl_dbo.SSISLog] where GUID = (
		SELECT TOP 1 GUID FROM [app].[syn_Configuration_tbl_dbo.SSISLog] 
		WHERE PackageName LIKE @PackageName)
		ORDER by StartTime ASC
			
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetUploadETLMessages', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO
