USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingsIPDData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingsIPDData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 07-07-2022 
--Description: GET DealNote Data 
--[cb].[spGetBookingsIPDData] 6,77,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingsIPDData] 
  @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  
  
BEGIN TRY   
        DECLARE @ipdDate DATE

		SELECT	
			@ipdDate =CAST(IPD AS DATE)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId


		CREATE TABLE #Invoice(Name varchar(max), InvoiceId INT, DealId INT, DealName varchar(max), InvoiceCategoryTypeId INT, InvoiceCategoryType varchar(max), InvoiceCategoryId INT, InvoiceCategory varchar(max)
		, CounterpartyName varchar(max), DealCounterpartyId INT, Description varchar(max), Amount DECIMAL(38,18), PaidDate DATETIME, DealIpdDate DATETIME, UploadedFileName varchar(max), OriginalFileName varchar(max), STATUS varchar(max), ReferenceNumber varchar(max)
		, SourceSpotRate DECIMAL(38, 18), SpotRate DECIMAL(38, 18), InvoiceDate DATETIME, InvoicePaidAmount DECIMAL(38,18), CreatedBy varchar(max), CreatedDate DATETIME, ModifiedBy varchar(max), ModifiedDate DATETIME)
		
		INSERT INTO #Invoice
		EXEC [cw].[spGetInvoiceList] @pDealId=@pdealId, @pIPDRunId=@pIPDRunId, @pPaidStartDate=null, @pPaidEndDate=null, @pIPDDate=null, @pUserName='system'

   
	   SELECT 	    BookingGroupInternalName As GroupName, 		AccountTypeLookupName AS AccountType, 		FlipTypeName AS Flip,
		bv.LineItem As [Name], 		Currency,  		TransactionType, 		bv.Value as Value, 		BookName AS BookCode,
		CounterpartyName AS CounterPartyCode, 		FeeType,  		 LineItemOperatorInTotal,
		bv.DealIpdRunId, 		bv.GroupSortOrder, 		bv.SortOrder
		INTO #BookingData
		FROM 
		[cb].[vwBookingLineItemValue] bv
	
			INNER JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
		WHERE 
			bv.BookingGroup NOT IN ('Maturing Trades','New GIC Loan Information')
			AND dir.DealIpdRunId =@pIPDRunId AND dir.DealId= @pDealId
	--		order by bg.SortOrder,bl.SortOrder

		UNION

	SELECT 
  'NWB_Covered_Bonds_Transaction_Account_(600001 - 48803413 / NWBCOVBONDS-GBP)' As GroupName,
	'Fee' AS AccountType, 	'N/A' AS Flip, 	#Invoice.Description As [Name], 	'GBP' AS Currency,
	'Dr' AS TransactionType, 	CAST(CAST(-1*#Invoice.Amount AS DECIMAL(38, 2)) AS VARCHAR(MAX))  as Value,
	 	'NWLLP_TRANS' AS BookCode, 	'SPV Fees Account - Non Trading Counterparties'  AS CounterPartyCode,
	'Administration Fee' AS FeeType, 	null as LineItemOperatorInTotal, 	@pIPDRunId as DealIpdRunId,
	'5.000' as GroupSortOrder, 	'21.000' AS 	SortOrder 
	
	FROM
	  #Invoice

	  SELECT * FROM #BookingData 
	 order by GroupSortOrder,SortOrder,
	 CASE
	WHEN LineItemOperatorInTotal !='' AND LineItemOperatorInTotal = 'IPD-1' THEN 1
	WHEN LineItemOperatorInTotal !='' AND LineItemOperatorInTotal = 'IPD' THEN 2
	WHEN LineItemOperatorInTotal !='' AND LineItemOperatorInTotal = 'IPD+1' THEN 3
     END;

END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetBookingsIPDData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO

