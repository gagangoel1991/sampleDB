USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[app].[spSupportBespokeStratRemove]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [app].[spSupportBespokeStratRemove]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 21-March-2023
Description    : This will help in removing bespoke asset strats
Execution      : EXEC [app].[spSupportBespokeStratRemove] 'Summary Data', 'IR', 'SRT', 2
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [app].[spSupportBespokeStratRemove]
	@pStratName VARCHAR(100),
	@pReportTypeName VARCHAR(50),
	@pDealType VARCHAR(50),
	@pAssetClassId INT = 1
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE @ReportTypeId INT = (SELECT TOP (1) ReportTypeId FROM cfgCW.IR_ReportType WHERE [ReportTypeName] = @pReportTypeName)
		DECLARE @StratId INT
		DECLARE @DealTypeId INT
		DECLARE @Active BIT = 1
		SET @DealTypeId = (SELECT TOP (1) lookupValue.LookupValueId FROM cfgCW.DealLookupValue lookupValue
							INNER JOIN cfgCW.DealLookupType lookupType ON lookupValue.LookupTypeId = lookupType.LookupTypeId
							WHERE lookupType.TypeCode = 'DealType' AND	lookupValue.Name = @pDealType)
		
		SET @StratId = (SELECT StratId FROM [cfgCW].[IR_Strat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId)
	
		DELETE FROM [cfgCW].[IR_StratDealTypeMap] WHERE [StratId] = @StratId AND [StratDealTypeId] = @DealTypeId AND IsActive = @Active
		PRINT ('Deleted "' + @pStratName + '" strat with deal type "' + @pDealType + '" from [cfgCW].[IR_StratDealTypeMap]')

		DELETE FROM [cfgCW].[IR_AssetStrat] WHERE [StratId] = @StratId AND [ReportTypeId] = @ReportTypeId
		PRINT ('Deleted "' + @pStratName + '" strat from [IR_AssetStrat]')

		DELETE FROM [cfgCW].[IR_BespokeStrat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId AND IsActive = @Active
		PRINT ('Deleted "' + @pStratName + '" strat from [cfgCW].[IR_BespokeStrat]')

		DELETE FROM [cfgCW].[IR_Strat] WHERE [Name] = @pStratName AND [AssetClassId] = @pAssetClassId AND [ReportTypeId] = @ReportTypeId
		PRINT ('Deleted "' + @pStratName + '" strat from [cfgCW].[IR_Strat]')

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
