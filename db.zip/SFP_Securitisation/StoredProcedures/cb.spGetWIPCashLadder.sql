USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetWIPCashLadder]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetWIPCashLadder]  
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [cb].[spGetWIPCashLadder] 
--==================================
--Author: Ravindra Singh
--Date:	31-01-2022
--Description:  To get Cash Ladder List on the basis 
--of CollectionBusinessStart AND CollectionBusinessEnd FROM WIP
-- Exec cb.spGetWIPCashLadder  6,1034,''
--================================== 
    @pDealId SMALLINT,
    @pIPDRunId INT,
	   @pUserName		VARCHAR(80) 
AS
BEGIN
SET NOCOUNT ON
BEGIN TRY

   DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX)
   DECLARE @collectionStartDate VARCHAR(10),@collectionEndDate VARCHAR(10)

   SELECT * INTO #tempCashLadder FROM cw.CashLadder_WIP WHERE IsActive=1

	  SELECT	
			@collectionStartDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessStart AS DATE),23), 
			@collectionEndDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessEnd AS DATE),23)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
       SELECT  CashLadderId,
       CollectionDate,	   
		Rate,	
		InflowAmount,
		OutflowAmount,
		FlowSubTotal,
		   [Status],
		   ModifiedBy,
		   ModifiedDate,
			  Reason FROM
   	   (SELECT
           wip.[Status]
          ,wip.Id AS WIPId
	      ,cl.CashLadderId 
          ,ROW_NUMBER() OVER(PARTITION BY cl.CollectionDate ORDER BY Id DESC) AS RowNum 
			,cl.CollectionDate AS CollectionDate
			,ROUND(cl.Rate,4) Rate
			,ROUND(cl.InflowAmount,4) InflowAmount
			,ROUND(cl.OutflowAmount,4) OutflowAmount
			,ROUND(cl.FlowSubTotal,4)  FlowSubTotal
          ,cl.CreatedBy AS ModifiedBy
          ,cl.CreatedDate AS ModifiedDate
		        ,wip.ChangeReason AS Reason
	        FROM cw.CashLadder cl
          JOIN #tempCashLadder wip ON cl.CashLadderId = wip.CashLadderId
          WHERE cl.DealId=@pDealId  
		  AND CAST(cl.CollectionDate AS DATE) BETWEEN @collectionStartDate AND @collectionEndDate
		  )t  WHERE t.RowNum=1 ORDER BY CASE WHEN t.WIPId IS NOT NULL THEN 0 ELSE 1 END, t.CollectionDate
           
END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetWIPCashLadder', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END 
GO
