USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetSoldPropertiesAndLosses') IS NOT NULL
	DROP PROC CW.spGetSoldPropertiesAndLosses
GO
/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Sold Properties and Losses for Investor report.
 * Usage : CW.spGetSoldPropertiesAndLosses @pAsAtDate  = '30-NOV-2020'
 * 		,@pDealName  = 'DUNMORE1' 
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetSoldPropertiesAndLosses
(
	@pAsAtDate			DATE
	,@pDealName			VARCHAR(255) 
	,@pStratRangeData	AS [cw].[udtStratRangeConfig] READONLY  
	,@pUserName			VARCHAR(50) = NULL  
)
AS
BEGIN
	BEGIN TRY
		
		DECLARE 
			@dealId								INT
			, @dealIpdRunId						INT
			, @previousIpdDate					DATE
			, @prevAsAtDate						DATE
			, @dealPreviousIpdRunId				INT  
			, @outstandng_Capital_Balance_Amt	Float
			, @partitionId						INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112)) 
	
	
		--Temp table drop if exist
		IF OBJECT_ID('tempdb..#CurrentMortgage')	IS NOT NULL DROP TABLE #CurrentMortgage
		IF OBJECT_ID('tempdb..#PreviousMortgage')	IS NOT NULL DROP TABLE #PreviousMortgage	
   
		CREATE TABLE #Lookup
		(  
			SortNo Int, HeaderText VARCHAR(100)
		);
	
		CREATE TABLE #CurrentMortgage
		(  
			SortNo Int, MortgageLoans INT DEFAULT 0, TotalOutCapitalBalance Float DEFAULT 0 , TotalOutCapitalBalancePercent Float DEFAULT 0
		);

		CREATE TABLE #PreviousMortgage
		(  
			SortNo Int, MortgageLoans INT DEFAULT 0, TotalOutCapitalBalance Float DEFAULT 0 , TotalOutCapitalBalancePercent Float DEFAULT 0	
		);
	
		CREATE TABLE #CumilativeMortgage
		(  
			SortNo Int, MortgageLoans INT DEFAULT 0, TotalOutCapitalBalance Float DEFAULT 0 , TotalOutCapitalBalancePercent Float DEFAULT 0
		);
	
		SELECT   
			@dealIpdRunId = dir.DealIpdRunId
			, @dealId = dir.DealId  
			, @previousIpdDate  = ipdDt.PreviousIPD
			, @prevAsAtDate = ipdDt.PreviousIPDCollectionBusinessEnd
			, @dealPreviousIpdRunId = dir.prevRunId
		FROM     
			cw.vwDealIpdDates ipdDt  
		JOIN 
			cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
		JOIN	
			cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
		JOIN 
			cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
		WHERE   
			deal.DealName = @pDealName  
			AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
			AND dir.IpdSequence <> 0  
	  
		--SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
		--JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
		--WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1	   
	  
		SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	
		SELECT * INTO #VwMortgageSubAccount FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1
		--Checking and loading the mortgage field data into the base table from SFP
		EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
		INSERT INTO #VwMortgageSubAccount   
		SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @dealId
	  
		SELECT  @outstandng_Capital_Balance_Amt=  SUM(Outstandng_Capital_Balance_Amt) 
		FROM #VwMortgageSubAccount
	
		INSERT INTO #Lookup (SortNo, HeaderText)VALUES 
		(1, 'Sold Properties')
		,(2, 'Recoveries from Sold Properties')
		,(3, 'Losses from Sold Properties')
		,(4, 'Loss Severity (% of total)')
		,(5, 'Total Net Losses as % of Original Pool Balance')
			  
		----================================================================
		--------     Current Period    --------  
		-----================================================================
		INSERT INTO #CurrentMortgage
		--Select 1 as SortNo, COUNT(*) as MortgageLoans,  sum(LOSS_ON_SALE) as TotalOutCapitalBalance, Case When @outstandng_Capital_Balance_Amt > 0 Then (( sum(LOSS_ON_SALE)/ @outstandng_Capital_Balance_Amt )) Else 0 End as TotalOutCapitalBalancePercent
		--From #VwMortgageSubAccount
		--where LOSS_ON_SALE>0 AND LOSS_CALCULATION_DATE = @prevAsAtDate
		SELECT 1 AS SortNo, MortgageLoans,  TotalOutCapitalBalance, TotalOutCapitalBalancePercent
		FROM [cw].[DealIpdAssetStratData] WHERE LineItemGroupText='Sold Properties' AND dealIpdRunId = @dealIpdRunId
		
		----================================================================
		--------     Previous Period    --------  
		-----================================================================
		INSERT INTO #PreviousMortgage
		SELECT 1 AS SortNo, MortgageLoans,  TotalOutCapitalBalance, TotalOutCapitalBalancePercent
		FROM [cw].[DealIpdAssetStratData] WHERE LineItemGroupText='Sold Properties' AND dealIpdRunId = @dealPreviousIpdRunId

		----================================================================
		--------     Cumilative Period    --------  
		-----================================================================

		INSERT INTO #CumilativeMortgage
		SELECT 1 AS SortNo, SUM(MortgageLoans),  sum(TotalOutCapitalBalance) AS TotalOutCapitalBalance, SUM(TotalOutCapitalBalancePercent) AS  TotalOutCapitalBalancePercent
		FROM [cw].[DealIpdAssetStratData] dias
		INNER JOIN cw.vwDealIpdRun vdir ON vdir.DealIpdRunId=dias.DealIpdRunId AND DealName= @pDealName
		WHERE LineItemGroupText='Sold Properties' AND dias.dealIpdRunId <= @dealIpdRunId

		SELECT 
			L.HeaderText AS '~HeaderText',
			ISNULL(CM.[MortgageLoans],0) AS 'Number of Mortgage Loans~CurrentPeriod', 
			ISNULL(CM.TotalOutCapitalBalance,0) AS 'Amount (EUR)~CurrentPeriod', 
			ISNULL(CM.TotalOutCapitalBalancePercent,0) AS '% of Total Amount~CurrentPeriod',
			ISNULL(FD.[MortgageLoans],0) AS 'Number of Mortgage Loans~PreviousPeriod', 
			ISNULL(FD.TotalOutCapitalBalance,0) AS 'Amount (EUR)~PreviousPeriod', 
			ISNULL(FD.TotalOutCapitalBalancePercent,0) AS '% of Total Amount~PreviousPeriod',
			ISNULL(CD.[MortgageLoans],0) AS 'Number of Mortgage Loans~Cumulative', 
			ISNULL(CD.TotalOutCapitalBalance ,0) AS 'Amount (EUR)~Cumulative', 
			ISNULL(CD.TotalOutCapitalBalancePercent,0) AS '% of Total Amount~Cumulative'
		FROM #Lookup L
		LEFT JOIN #CurrentMortgage CM ON CM.SortNo=L.SortNo
		LEFT JOIN #PreviousMortgage FD ON FD.SortNo = L.SortNo
		LEFT JOIN #CumilativeMortgage CD ON CD.SortNo = L.SortNo
		ORDER BY L.SortNo

		
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetSoldPropertiesAndLosses', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
		RAISERROR (@errorMessage,
					@errorSeverity,
					@errorState )
	END CATCH						
END

Go