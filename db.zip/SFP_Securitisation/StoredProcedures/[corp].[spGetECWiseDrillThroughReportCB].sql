USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetECWiseDrillThroughReportCB]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetECWiseDrillThroughReportCB]
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- exec [corp].[spGetECWiseDrillThroughReportCB] 651, 'kumasdt'
CREATE PROCEDURE [corp].[spGetECWiseDrillThroughReportCB]	
	@pPoolId int,
	@pUserName VARCHAR(50)	
AS
BEGIN	
	BEGIN TRY	
		IF OBJECT_ID('tempdb.dbo.#SourcePoolLoan', 'U') IS NOT NULL                                           
				DROP TABLE #SourcePoolLoan 	
		
		CREATE TABLE #SourcePoolLoan
		(
			LoanId INT,
			Balance DECIMAL(19,2)
		)

		DECLARE @EcCount INT
		SELECT @EcCount = COUNT(1) FROM PS.PoolEcMap WHERE POOLID = @pPoolId AND IsActive = 1

		INSERT INTO #SourcePoolLoan
		SELECT DISTINCT LoanId, LoanBalance AS Balance FROM ps.PoolBuildDetail WHERE poolid = @pPoolId AND IsActive = 1
		UNION
		SELECT DISTINCT LoanId, LoanBalance AS Balance FROM ps.PoolEligibilityBuildDetail WHERE poolid = @pPoolId 

		DECLARE @SourcePoolCount INT
		DECLARE @SourcePoolBalance DECIMAL(19,2)
		DECLARE @ApplicableECMethod INT
		DECLARE @PoolPurposeId INT

		SELECT @ApplicableECMethod = ApplicableECMethod FROM PS.Pool WHERE PoolId = @pPoolId
		SELECT @SourcePoolCount = COUNT(DISTINCT LoanId), @SourcePoolBalance=SUM(Balance) FROM #SourcePoolLoan
		SELECT @PoolPurposeId = PoolPurposeId FROM PS.Pool WHERE PoolId = @pPoolId

		-- For Top-Up Pool, we need to calulate Source Pool Balance differently
		--IF @PoolPurposeId = 2
		--BEGIN
			
		--END
		
		IF (SELECT COUNT(1) FROM ps.PoolEligibilityBuildDetail WHERE poolid = @pPoolId) = 0
		BEGIN
			-- NO Facility has failed any of the ECs
			SELECT EC.Name,
					@SourcePoolCount AS TotalPassCount,
					0 AS TotalFailCount,
					@SourcePoolBalance AS TotalPassBalance,
					0 AS TotalFailBalance
				FROM PS.PoolEcMap MAP
				JOIN ps.EligibilityCriteria ec
				ON MAP.EligibilityCriteriaId = ec.EligibilityCriteriaId
				WHERE MAP.PoolId = @pPoolId AND MAP.IsActive = 1 AND ec.IsActive = 1
		END
		ELSE
		BEGIN
			SELECT * FROM (
				SELECT *, ROW_Number() Over(Partition by X.Name Order by X.TotalPassCount) as row FROM(
					SELECT EC.Name,  
					 @SourcePoolCount AS TotalPassCount,  
					 0 AS TotalFailCount,  
					 @SourcePoolBalance AS TotalPassBalance,  
					 0 AS TotalFailBalance  
					FROM PS.PoolEcMap MAP  
					JOIN ps.EligibilityCriteria ec  
					ON MAP.EligibilityCriteriaId = ec.EligibilityCriteriaId  
					WHERE MAP.PoolId = @pPoolId AND MAP.IsActive = 1 AND ec.IsActive = 1 
				UNION 
					SELECT      
					ec.Name,   
					@SourcePoolCount- COUNT(DISTINCT LoanId)  AS TotalPassCount,  
					COUNT(DISTINCT LoanId) AS TotalFailCount,   
					@SourcePoolBalance-SUM(LoanBalance) AS TotalPassBalance,  
					SUM(LoanBalance) AS TotalFailBalance  
					FROM ps.PoolEligibilityBuildDetail  pebd   
					INNER JOIN ps.EligibilityCriteria ec  
					ON pebd.EligibilityCriteriaId = ec.EligibilityCriteriaId  
					WHERE poolid = @pPoolId AND status = 0  
					GROUP BY  ec.Name
				 )X
			)Y Where Y.row =1
		END

		SELECT 
			NumberOfAccount, 
			--CASE WHEN TrueBalance = 0 THEN CapitalBalance ELSE TrueBalance END AS Balance,
			ISNULL(CurrentPoolAmount, 0) AS Balance,
			@SourcePoolCount AS TotalAccount,
			@SourcePoolBalance AS TotalBalance,
			ApplicableECMethod AS FacilitySelectionCriteria
		FROM PS.Pool
		WHERE PoolId = @pPoolId	

  		--CT Summary
		SELECT  ct.CriteriaName AS ConcentrationCriteria,
				ct.LimitPercentage AS ThreshholdValue,
				pctDetail.ResultPercent AS PoolConcentrationValue,
				IIF(pctDetail.ResultStatus=0,'Fail','Pass') AS [Status]
		FROM	ps.Pool pl                                             
				INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = 1
				INNER JOIN ps.PoolCTDetail pctDetail ON pctDetail.PoolCTMapId = ctMap.PoolCTMapId
				INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1
				WHERE pl.PoolId = @pPoolId AND
				pctDetail.PoolCTDetailId IN (SELECT MAX(PoolCTDetailId) FROM ps.PoolCTDetail GROUP BY PoolCTMapId)

   END TRY
	BEGIN CATCH		
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetECWiseDrillThroughReportCB', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
