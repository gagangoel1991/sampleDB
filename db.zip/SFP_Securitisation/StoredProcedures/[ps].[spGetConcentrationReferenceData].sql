USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetConcentrationReferenceData]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetConcentrationReferenceData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGetConcentrationReferenceData]
(  
	@pUserName VARCHAR(50) ,
	@pAssetClassId int = 1  
)  
AS      
BEGIN      
	BEGIN TRY      
		-- Get Field data[<All> / Integer]
		EXEC [ps].[spGetConcentrationFields] '<All>',@pAssetClassId, @pUserName  
      
		-- Get Concentration Type      
		SELECT [ConcentrationTestTypeId] AS [Value],      
		[TestType] AS Title      
		FROM ps.ConcentrationTestType  
		WHERE (@pAssetClassId = 1 AND ConcentrationTestTypeId <> 3) OR @pAssetClassId = 2
   
		-- Get Asset class      
		SELECT AssetClassId AS [Value],      
		Class AS Title      
		FROM [ps].[AssetClass]    
		WHERE IsActive = 1  
  
		-- Get Operators   
		EXEC [ps].[spGetConcentrationRuleOperators] 'Integer', @pUserName
		
		-- Get CT Type
		SELECT EligibilityCriteriaTypeId AS [Value],
			   Type AS [Title]
		FROM [ps].[EligibilityCriteriaType]    
		WHERE IsActive=1 AND AssetClassId = @pAssetClassId
	END TRY                                            
	BEGIN CATCH
		DECLARE                                             
		@errorMessage     NVARCHAR(MAX),                                            
		@errorSeverity    INT,                                            
		@errorNumber      INT,                                            
		@errorLine        INT,                                            
		@errorState       INT;                                          
		SELECT                             
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                           
           
		EXEC app.SaveErrorLog 2, 1, 'GetConcentrationReferenceData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName                             
                                          
		RAISERROR (@errorMessage, @errorSeverity, @errorState)      
  END CATCH      
 END
