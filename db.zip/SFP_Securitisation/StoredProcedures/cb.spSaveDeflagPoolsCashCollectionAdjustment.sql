USE [SFP_Securitisation]

GO

IF OBJECT_ID('cb.spSaveDeflagPoolsCashCollectionAdjustment') IS NOT NULL
	DROP PROCEDURE cb.spSaveDeflagPoolsCashCollectionAdjustment
GO


/****** Object:  StoredProcedure cb.spSaveDeflagPoolsCashCollectionAdjustment    Script Date: 8/30/2022 11:16:44 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:	30.03.2023
 * Description:  Initiate Deflag Pool Cash Collection Adjustment
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * 
	
exec cb.spSaveDeflagPoolsCashCollectionAdjustment @pAsAtDate='25-JAN-2023', @pUserName ='kumavnb'
 * -------------------------------------------------------
*/  

CREATE PROC [cb].spSaveDeflagPoolsCashCollectionAdjustment
	@pAsAtDate DateTime,
	@pUserName varchar(255) = null
AS        
BEGIN  
	BEGIN TRY

		Declare @dealId INT =6
		, @mortgageDealId INT
		, @poolCashCollectionAdjustmentId INT
		, @draftWorkFlowStepId INT
		, @completePoolStatusId INT
		, @poolPurposeId INT
		, @assetClassId INT
		, @partitionIdFrom INT
		, @partitionIdTo INT
		, @vintageDate Datetime


		SELECT @mortgageDealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealId=@dealId
	
		Select @completePoolStatusId = poolstatusid FROM ps.poolstatus WHERE  status = 'Complete'
		SELECT @poolPurposeId = PoolPurposeId FROM   ps.PoolPurpose  WHERE  PoolPurpose = 'Repurchase';  
		Select @assetClassId = AssetClassId from [ps].[AssetClass] Where Class='Retail'
		SET @draftWorkFlowStepId = (Select  [cw].[fnGetWorkflowStepId]('Draft','Deflag_Adjustment') )

		CREATE TABLE #DeflagPoolCashCollection
		(MortgageDealKey INT, VintageDate Date, EffectiveDate Date, PoolId INT, LoanId Varchar(20), MortgageAssetPoolId INT, MortgageAccountKey INT, DeFlaggedDateKey INT)

		INSERT INTO  #DeflagPoolCashCollection
		exec sfp.syn_SfpModel_spGetDeflagLoansForRepurchasePool @pAsAtDate=@pAsAtDate, @pUserName =@pUserName



		CREATE TABLE #PoolDeflagAdjustment(PoolId INT, [TotalPrincipalReceipts] float, [TotalRevenueReceipts] float)

		IF (SELECT COUNT(*) FROM #DeflagPoolCashCollection) >0
		BEGIN
			
			INSERT INTO #PoolDeflagAdjustment (PoolId, [TotalPrincipalReceipts], [TotalRevenueReceipts])
			SELECT UFM.PoolId, SUM(map.DeFlagPrincipalAmount), SUM(map.DeFlagRevenueAmount)
			FROM [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool] map 
			INNER JOIN #DeflagPoolCashCollection UFM on map.MortgageAccountKey = UFM.MortgageAccountKey 
			and  map.MortgageAssetPoolId = UFM.MortgageAssetPoolId
			and map.DeFlaggedDateKey=UFM.DeFlaggedDateKey
			and map.MortgageDealKey=UFM.MortgageDealKey
			Group by UFM.PoolId
			
			SELECT Top 1 @vintagedate= VintageDate, @partitionIdFrom=CONVERT(VARCHAR, VintageDate, 112), @partitionIdTo = CONVERT(VARCHAR, EffectiveDate, 112) 
			FROM #DeflagPoolCashCollection pl


			IF ( Select Count(*) From [CW].[PoolCashCollectionAdjustment] where CAST(CreatedDate as DATE)= CAST(@pAsAtDate as DATE) and SourceDealId=@dealId ) = 0 
			BEGIN
					INSERT INTO [CW].[PoolCashCollectionAdjustment]
					(PoolPurposeId, SourceDealId, VintageDate, WorkFlowStatusId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
					Select @poolPurposeId, @dealId, @vintagedate, @draftWorkFlowStepId,  'System', @pAsAtDate, 'System', GetDate()
				
					SELECT @poolCashCollectionAdjustmentId = max(PoolCashCollectionAdjustmentId) from [CW].[PoolCashCollectionAdjustment]
					INSERT INTO [CW].[PoolCashCollectionAdjustmentMap]
					(PoolCashCollectionAdjustmentId, PoolId, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
					SELECT distinct @poolCashCollectionAdjustmentId, PoolId, 'System', GetDate(), 'System', GetDate() FROM #DeflagPoolCashCollection
					Where mortgagedealkey = @mortgageDealId
			END
			ELSE
				SELECT @poolCashCollectionAdjustmentId = PoolCashCollectionAdjustmentId from [CW].[PoolCashCollectionAdjustment]
				where CAST(CreatedDate as DATE)= CAST(@pAsAtDate as DATE) and SourceDealId=@dealId 



			Update pccam
			SET PrincipalAdjustment = TotalPrincipalReceipts, ReceiptAdjustment= TotalRevenueReceipts
			FROM [CW].[PoolCashCollectionAdjustmentMap] pccam
			INNER JOIN #PoolDeflagAdjustment pda on pccam.PoolId = pda.poolId
			Where PoolCashCollectionAdjustmentId = @poolCashCollectionAdjustmentId

			Update [CW].[PoolCashCollectionAdjustment]
			SET TotalPrincipalAdjustment = (Select SUM(TotalPrincipalReceipts) from #PoolDeflagAdjustment)
			, TotalReceiptAdjustment = (Select SUM(TotalRevenueReceipts) from #PoolDeflagAdjustment)
			Where PoolCashCollectionAdjustmentId = @poolCashCollectionAdjustmentId
			

			EXEC [CW].[spManageDeflagAdjustmentWorkflowProcess]  
			@pPoolCashCollectionAdjustmentId	= @poolCashCollectionAdjustmentId,
			@pAdjustmentProcessDate = Null,
			@pWorkFlowStepId	    = @draftWorkFlowStepId,
			@pAuthorizerComment		= 'System Created',
			@pUserName				= 'System',
			@pReturnCode			= 0


		END

	END TRY  
	BEGIN CATCH  

		
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE() + ' For Date ' + Convert(varchar(10), @pAsAtDate, 103) , @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cb.spSaveDeflagPoolsCashCollectionAdjustment',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH  

END

GO
