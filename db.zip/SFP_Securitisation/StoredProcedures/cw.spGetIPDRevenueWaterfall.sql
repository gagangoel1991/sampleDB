USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spGetIPDRevenueWaterfall') IS NOT NULL
	DROP PROCEDURE cw.spGetIPDRevenueWaterfall
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spGetIPDRevenueWaterfall
(
	@pDealIpdRunId INT,
	@pUserName	VARCHAR(80)
/*
exec cw.spGetIPDRevenueWaterfall 4,'fm\shriyad'
*/
)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE 
			@DealId			INT,
			@IpdDate		DATE,
			@DealName		VARCHAR(20),
			@ipdSequence	INT

		SELECT @DealId=DealId, @IpdDate=IpdDate, @DealName=DealName , @ipdSequence=IpdSequence FROM cw.vwDealIpdRun WHERE DealIpdRunId=@pDealIpdRunId;

		IF(@DealName IN ('ARDMORE1','DUNMORE1'))
			BEGIN
			  EXEC cw.spRMBSGetIPDRevenueWaterfall	@pDealIpdRunId ,@pUserName 
			END
		ELSE
		   BEGIN
			  EXEC cb.spGetIPDRevenueWaterfall	@pDealIpdRunId ,@pUserName
			END		


	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetIPDRevenueWaterfall', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO