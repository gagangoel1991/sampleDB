USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetSFPPlusDashBoardFailedPools]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetSFPPlusDashBoardFailedPools]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGetSFPPlusDashBoardFailedPools]
(      
	@pAsAtDate DATE,
	@pUserName VARCHAR(50),
	@pAssetClassID INT = 1
)      
AS      
BEGIN      
	BEGIN TRY      

	    DECLARE @PoolStatusFailedId INT
		DECLARE @AssetClass_Retail INT = (SELECT AssetClassId FROM PS.AssetClass WHERE CODE = 'RT')

		SELECT @PoolStatusFailedId = poolstatusid
		FROM   ps.poolstatus
		WHERE  status = 'Fail';

		IF(@pAssetClassID = @AssetClass_Retail )
		BEGIN
				SELECT [NAME] AS 'PoolName',  
					IsNull(fph.FailureReason, '') AS 'FailedReason'  
				FROM   ps.pool pool  
				INNER JOIN [sfp].[syn_SfpModel_vw_PoolFlaggingFailedHistory] fph  -- Vw : [SFP_Model].[rpt].[vw_PoolFlaggingFailedHistory]
				ON fph.PoolId = pool.PoolId   
				WHERE  batchprocessingdate = @pAsAtDate  
					AND poolstatusid = @PoolStatusFailedId
					AND [pool].AssetClassId = @pAssetClassID
		END
		ELSE
		BEGIN
			   SELECT [NAME] AS 'PoolName',  
				  IsNull(fph.FailureReason, '') AS 'FailedReason'  
			   FROM   ps.pool pool  
			   INNER JOIN  [sfp].[syn_SfpModelCorporate_vw_PoolFlaggingFailedHistory] fph  -- vw : [SFP_MODEL_CORPORATE].[rpt].[vw_PoolFlaggingFailedHistory]
			   ON fph.PoolId = pool.PoolId   
			   WHERE  batchprocessingdate = @pAsAtDate  
				  AND poolstatusid = @PoolStatusFailedId
				  AND [pool].AssetClassId = @pAssetClassID
		END
              
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetSFPPlusDashBoardFailedPools', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''                    
                      
		RAISERROR (@errorMessage,                    
					@errorSeverity,                    
					@errorState )                    
	END CATCH      
END
GO