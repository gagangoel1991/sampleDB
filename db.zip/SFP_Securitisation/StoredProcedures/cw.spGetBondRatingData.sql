USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetBondRatingData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetBondRatingData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetBondRatingData]
	/*  
 * Author: Gunjan Chandola  
 * Date: 19.01.2021  
 * Description:  This will return Bond rating data based collection business date and IPD Run ID 
 * [cw].[spGetBondRatingData] 14,4,'Test'
 * Change History  
 * --------------  
 * Author | Date | Description 
 * Saurabh Bhatia | 22-06-2021 | Changes to get data from user tables 
 * --------------  
 * Author | Date | Description 
 * Saurabh Bhatia | 01-11-2021 | New Column IsPrevIpdRating added 
 * -------------------------------------------------------  
*/
	@pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @ColsISINWhere AS NVARCHAR(MAX)
			,@ColsISINSelect AS NVARCHAR(MAX)
			,@collectionStartDate DATE
			,@collectionEndDate DATE
			,@query VARCHAR(MAX)
			,@RatingDate DATE
			,@seprator varchar(20) = ' | '; 

		SELECT @collectionStartDate = CAST(CollectionBusinessStart AS DATE)
			,@collectionEndDate = CAST(CollectionBusinessEnd AS DATE)
		FROM [cw].[vwDealIpdDates] ipdDt
		JOIN cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE ipdRun.RunId = @pIPDRunId

		SET @RatingDate = ISNULL((
					SELECT CAST(MAX(br.RatingDate) AS DATE)
					FROM CW.vwBondRating br
					JOIN [cfgCW].[DealNote] dn ON dn.ISIN = br.ISIN
					WHERE CAST(br.RatingDate AS DATE) BETWEEN @collectionStartDate
							AND @collectionEndDate
						AND dn.DealId = @pDealId
					), @collectionEndDate)

		IF OBJECT_ID('tempdb..#tempBondRating') IS NOT NULL
			DROP TABLE #tempBondRating

		CREATE TABLE #TempBondRatingMasterData (
			[UniqueIdentifier] VARCHAR(200)
			,[CRAId] INT
			,[CRA] VARCHAR(200)
			,[RatingTypeId] INT
			,[RatingType] VARCHAR(200)
			,[Rating] VARCHAR(200)
			,[Type] VARCHAR(200)
			);

		INSERT INTO #TempBondRatingMasterData
		EXEC cw.spGetRatingMasterData @pDealId

		DELETE
		FROM #TempBondRatingMasterData
		WHERE [Type] <> 'Bond'

		SELECT DISTINCT br.SourceBondRatingId
			,br.UserBondRatingId
			,CASE 
				WHEN @RatingDate = @collectionEndDate
					THEN 0
				ELSE 1
				END AS IsPostCollectionEndDate
			,tempBondData.[UniqueIdentifier] AS ISIN
			,dn.[Name]
			,tempBondData.CRAId
			,tempBondData.CRA AS RatingAgency
			,tempBondData.RatingTypeId
			,tempBondData.[RatingType] AS RatingType
			,ISNULL(br.Rating, '') AS Rating
			,CAST(@RatingDate AS DATE) AS RatingDate			
			,IIF(SourceBondRatingId IS NOT NULL,NULL,br.ModifiedBy) AS ModifiedBy
			,IIF(SourceBondRatingId IS NOT NULL,NULL,br.ModifiedDate) AS ModifiedDate
			,br.IsPrevIpdRating
			,br.Comment
		INTO #tempBondRating
		FROM #TempBondRatingMasterData tempBondData
		INNER JOIN [cfgCW].[DealNote] dn ON tempBondData.[UniqueIdentifier] = dn.ISIN  AND dn.DealId = @pDealId  
		LEFT JOIN cw.vwBondRating br ON CAST(br.RatingDate AS DATE) = @RatingDate
			AND tempBondData.[UniqueIdentifier] = br.ISIN
			AND tempBondData.CRAId = br.CRAId
			AND tempBondData.RatingTypeId = br.RatingTypeId

		SELECT @ColsISINWhere = STUFF((
					SELECT DISTINCT ',' + CAST(ISIN AS NVARCHAR(20))
					FROM #tempBondRating
					FOR XML PATH('')
						,TYPE
					).value('.', 'NVARCHAR(MAX)'), 1, 1, '');

		SELECT @ColsISINSelect = STUFF((
					SELECT DISTINCT ',MAX(' + CAST(ISIN AS NVARCHAR(20))+') as [' + CAST(ISIN AS NVARCHAR(20)) + @seprator + [Name] + ']'
					FROM #tempBondRating
					FOR XML PATH('')
						,TYPE
					).value('.', 'NVARCHAR(MAX)'), 1, 1, '');

		SET @query = '		
				SELECT 
				 null as SourceBondRatingId
				,IsPostCollectionEndDate
				,CRAId
				,RatingAgency
				,RatingTypeId
				,RatingType
				,RatingDate				
				,MAX(IIF(row_num<>1,null, ModifiedBy)) as ModifiedBy
				,MAX(ModifiedDate) AS ModifiedDate
				,MAX(IIF(row_num<>1,null, Comment)) as Reason
				,IIF( SUM(IIF(UserBondRatingId IS NOT NULL,1,0)) = SUM(IIF(UserBondRatingId IS NOT NULL and IsPrevIpdRating = 1,1,0)) AND SUM(IIF(UserBondRatingId IS NOT NULL and IsPrevIpdRating = 1,1,0)) <> 0,1,0 ) AS IsPrevIpdRating
				,' + @ColsISINSelect + '
			FROM (	SELECT					
					ROW_NUMBER() OVER (
					     PARTITION BY CRAId,RatingTypeId
					     ORDER BY ModifiedDate desc
					  ) row_num	,
					*
					FROM #tempBondRating
					PIVOT(MAX(Rating) FOR ISIN IN (' + @ColsISINWhere + ')) AS Pivot_Table
			) AS x 
			GROUP BY			
				IsPostCollectionEndDate				
				,CRAId
				,RatingAgency
				,RatingTypeId
				,RatingType
				,RatingDate		
				
		'

		PRINT @query

		EXECUTE (@query)
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetBondRatingData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


