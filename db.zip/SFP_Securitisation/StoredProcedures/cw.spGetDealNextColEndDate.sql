USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetDealNextColEndDate]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealNextColEndDate]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--================================================
--Author: Suresh Pandey
--Date:	12-08-2021
--Description:  This will return the next collection date for IPDs
--Exec cw.spGetDealNextColEndDate 
--================================================
CREATE PROCEDURE [cw].[spGetDealNextColEndDate]
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY

		IF OBJECT_ID('tempdb..#tempDeal') IS NOT NULL DROP TABLE #tempDeal

		CREATE TABLE #tempDeal
		(
			DealId SMALLINT ,
			DealName VARCHAR(256),
			IpdDate DATE
		)

		DECLARE
			@startDealId		INT = 1,
			@maxDealId			INT
			

		SELECT @maxDealId= MAX(DealId) FROM cw.vw_ActiveDeal

		WHILE(@startDealId <= @maxDealId)
		BEGIN 

			DECLARE
				@currentIpdDate				DATETIME,
				@currentIpdWorkflowStepId	SMALLINT,
				@currentDealIpdId			INT

			SELECT @currentIpdDate = IpdDate, @currentIpdWorkflowStepId = WorkflowStepId, @currentDealIpdId = di.DealIpdId FROM cw.DealIpd di
			JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
			WHERE di.IsCurrentIPD = 1 AND dir.IsCurrentVersion = 1
			AND di.DealId = @startDealId

		

			IF NOT EXISTS(SELECT  * FROM cfgcw.WorkflowStep wfs 
				JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
				WHERE wft.Name = 'Deal_IPD' AND wfs.StepName NOT IN ('SendForAuthorisation', 'Authorise')
				AND wfs.WorkflowStepID = @currentIpdWorkflowStepId)
			BEGIN
				SELECT @currentIpdDate = NextIPD FROM cw.vwDealIpdDates WHERE DealIpdId = @currentDealIpdId AND DealId = @startDealId
			END

		
			INSERT INTO #tempDeal
			SELECT 
				di.DealId ,
				ad.dealName,
				dt.CollectionBusinessEnd			
			FROM 
				cw.DealIpd  di
				JOIN cw.vwdealipddates dt ON dt.dealipdid =di.DealIpdId
				JOIN cw.vw_ActiveDeal ad ON ad.dealid=dt.dealid
			WHERE 
				di.DealId = @startDealId 
				AND IpdDate>= @currentIpdDate

			SET @startDealId = @startDealId +1

		END

		SELECT  * FROM #tempDeal
		

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END

GO

