USE [SFP_Securitisation]
GO

IF OBJECT_ID('cfg.spSaveEmailConfig') IS NOT NULL
	DROP PROCEDURE cfg.spSaveEmailConfig
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Suresh Pandey  
--Date: 06-09-2022  
--Description: To Save Email Config data
--Exec cfg.spSaveEmailConfig 2,1,'EMAIL_1','Daily Collection','aaa.bb@dfd.com','test.abx@dfd.com',null,null,'Test for Dev 2','This is email body',0,'TEXT',0,1,'Suresh' 
/*

DECLARE  @pReturnCode int 
EXEC cfg.spSaveEmailConfig 2,1,'EMAIL_1','Daily Collection','aaa.bb@dfd.com','test.abx@dfd.com',null,null,'Test for Dev 2','This is email body',0,'Text',0,1,'Suresh',@pReturnCode=-1
Select @pReturnCode

*/
--==================================  
CREATE PROCEDURE [cfg].[spSaveEmailConfig] 
	@pEmailConfigId INT
	,@pEmailTypeId INT
	,@pInternalName VARCHAR(200)=NULL  
	,@pDisplayName VARCHAR(200)  
	,@pFrom VARCHAR(200)  
	,@pTo VARCHAR(MAX) 
	,@pCC VARCHAR(MAX)=NULL  
	,@pBCC VARCHAR(MAX)=NULL 
	,@pSubject VARCHAR(MAX)
	,@pBody VARCHAR(MAX)
	,@pImportance BIT  
	,@pEmailFormat  VARCHAR(20)
	,@pAttachment BIT
	,@pIsActive BIT
	,@pUserName VARCHAR(80)
	,@pReturnCode INT=-1 OUTPUT 
AS
BEGIN
	BEGIN TRY

		IF EXISTS ( SELECT 1 FROM [cfg].[EmailConfiguration] WHERE EmailTypeId=@pEmailTypeId AND ISNULL(@pEmailConfigId,0) = 0 ) 
		BEGIN 
			SET @pReturnCode = 0 --duplicate email configuration type
		RETURN
		END
		

      IF(@pEmailConfigId>0)
         BEGIN
		 
			DECLARE @oldEmailTypeId INT
			SET @oldEmailTypeId = (SELECT EmailTypeId FROM [cfg].[EmailConfiguration] WHERE EmailConfigId=@pEmailConfigId)
		 
			IF EXISTS ( SELECT 1 FROM [cfg].[EmailConfiguration] WHERE EmailTypeId=@pEmailTypeId AND @oldEmailTypeId <> @pEmailTypeId) 
			BEGIN 
				SET @pReturnCode = 0 --duplicate email configuration type
			RETURN
			END
			
			UPDATE [cfg].[EmailConfiguration]					
				SET 
				[EmailTypeId]=@pEmailTypeId
                --,[InternalName]=@pInternalName
                ,[DisplayName]=@pDisplayName
                ,[EmailFrom]=@pFrom
                ,[EmailTo]=@pTo
                ,[EmailCC]=@pCC  
                ,[EmailBCC]=@pBCC
				,[EmailSubject]=@pSubject
                ,[EmailBody]=@pBody
                ,[EmailImportance]=@pImportance 
                ,[EmailFormat]=@pEmailFormat   
                ,[Attachment]=@pAttachment
                ,[IsActive]=@pIsActive
                ,[ModifiedBy]=@pUserName 
                ,[ModifiedDate]=GETDATE()
			WHERE EmailConfigId=@pEmailConfigId
                
			SET @pReturnCode = 1
                  
         END
        ELSE
         BEGIN
		   DECLARE @internalName VARCHAR(200)
		   SET @internalName = (SELECT 'EMAILCONFIG_' + Cast(IDENT_CURRENT('[cfg].[EmailConfiguration]') AS VARCHAR))
			INSERT INTO [cfg].[EmailConfiguration](  
				[EmailTypeId]
				,[InternalName]
				,[DisplayName]
				,[EmailFrom]
				,[EmailTo]
				,[EmailCC]
				,[EmailBCC]
				,[EmailSubject]
				,[EmailBody]
				,[EmailImportance]
				,[EmailFormat]
				,[Attachment]
				,[IsActive]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate]  
			) VALUES(  
				@pEmailTypeId
				,@internalName
				,@pDisplayName
				,@pFrom
				,@pTo
				,@pCC  
				,@pBCC
				,@pSubject
				,@pBody
				,@pImportance 
				,@pEmailFormat
				,@pAttachment
				,1   
				,@pUserName   
				,GETDATE()  
				,@pUserName  
				,GETDATE()  
              )  
			  			 
             SET @pReturnCode = 1
         END
		 
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2
			,1
			,'cfg.spSaveEmailConfig'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH;
END

GO
