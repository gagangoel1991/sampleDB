USE [SFP_Securitisation]
GO


IF OBJECT_ID('[cw].[spGetDealLatestAuthorisedIpdDate]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDealLatestAuthorisedIpdDate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-------------------------------------------
 * 
 *  DECLARE @IPDDate varchar(50)
 *   EXEC [cw].[spGetDealLatestAuthorisedIpdDate] 15,'',@IPDDate OUTPUT
 *   SELECT @IPDDate
 * 
--------------------------------------------*/

CREATE PROCEDURE [cw].[spGetDealLatestAuthorisedIpdDate] 
  
--==================================  
--Author: Ravindra Singh 
--Date: 16-12-2021  
--Description:  Get Validate Deal Before Collapse 
  
  -- [cw].[spGetDealLatestAuthorisedIpdDate] 12,''
--==================================  
       @pDealId INT,  
       @pUserName VARCHAR(80)
	   ,@pReturnIPDDate varchar(50) OUTPUT 
AS  
BEGIN  
 BEGIN TRY  
		DECLARE @LoanCount INT=0;
		  
   SET @pReturnIPDDate= (SELECT  TOP 1 CONVERT(varchar(10),DATEADD(day,1,prevDt.IPD),120) 	FROM 
			cw.vwDealIpdDates prevDt
		JOIN 
			cw.vwDealIpdDates currDt ON prevDt.DealId = currDt.DealId AND prevDt.IPD < currDt.NextIPD 
		JOIN 
			cw.dealIpd prevIpd ON prevIpd.DealIpdId = prevDt.DealIpdId
			JOIN 
			cw.dealIpd currIpd ON currIpd.DealIpdId = currDt.DealIpdId
		JOIN 
			cw.dealipdrun dir ON prevIpd.dealIpdid = dir.dealipdId
		LEFT JOIN
			cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
		JOIN 
		   cfg.Deal dl ON dl.DealId =prevDt.DealId

		   WHERE dl.DealId=@pDealId AND wfs.DisplayName ='Authorised'

		   ORDER BY RunId DESC 
		   )	


 END TRY  
 BEGIN CATCH  
  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  IF @@TRANCOUNT > 0  
  EXEC app.SaveErrorLog 2, 1, 'cw.spGetDealLatestAuthorisedIpdDate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH;  
END  
GO
