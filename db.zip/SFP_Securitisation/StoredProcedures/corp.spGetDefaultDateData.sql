USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spGetDefaultDateData]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spGetDefaultDateData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 05-Oct-2022
Description    : This will return data for selected default date
Execution      : EXEC [corp].[spGetDefaultDateData] '10399675', 'Atlas', 'PRISM', '2022-08-31', NULL, 'Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spGetDefaultDateData]
	@pFacilityId VARCHAR(50),
	@pDealName VARCHAR(50),
	@pSource VARCHAR(50),
	@pDefaultDate DATE,
	@pFxRateDate DATE = NULL,
	@pUserName VARCHAR(100)
AS
BEGIN
	SET NOCOUNT ON
	BEGIN TRY
		DECLARE @ReqCols XML 
		DECLARE @RowID VARCHAR (100)
		DECLARE @MonthBeforeDefault DATE = DATEADD(MONTH, -1, @pDefaultDate)
		DECLARE @TotalRona DECIMAL (24, 4)
		DECLARE @MinPercent DECIMAL (15, 14) = (SELECT IIF (LegalRetentionPercent < RiskRetentionPercent, LegalRetentionPercent, RiskRetentionPercent) FROM cfg.Deal WHERE DealName = @pDealName)
		DECLARE @CalcRona DECIMAL (24, 4)

		DECLARE @FacilityId VARCHAR (50) = (SELECT CASE 
												WHEN @pSource = 'RMP' THEN @pFacilityId 
												WHEN @pSource = 'PRISM' THEN @pFacilityId + '\p'
											END)

		DECLARE @CorpDealId VARCHAR(50)
		DECLARE @PreviousMonthDate DATE  = (SELECT MAX(AsAtDate)
												FROM [sfp].[syn_SfpModel_vw_Calendar_v1] 
											WHERE RegionCode = 'UK' AND IsWorkingDay = 1 AND 
												[Month] =  MONTH(@MonthBeforeDefault) AND 
												[Year] = YEAR(@MonthBeforeDefault))

		/* DROP TEMPORARY TABLES */
		IF OBJECT_ID('tempdb..#DefaultDateData') IS NOT NULL
			DROP TABLE #DefaultDateData
		IF OBJECT_ID('tempdb..#PreviousMonthData') IS NOT NULL
			DROP TABLE #PreviousMonthData

		/* FETCH DATA FOR DEFAULT DATE */
		/* CONVERT REQUIRED COLUMN NAMES TO XML FORMAT */
		SELECT @ReqCols = (SELECT CriteriaFieldName
							FROM (VALUES ('RONA')
										,('DealName')
										,('B2_APP_EAD_PRE_CRM_AMT')
										,('UtilisationGBP_ReportingDate')) Field(CriteriaFieldName)
									FOR XML PATH('Node'), ROOT('Root'))

		SET @CorpDealId = STUFF((SELECT ',' + CONVERT(VARCHAR, [corpDeal].[DealId])
									FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] corpDeal
									INNER JOIN cfg.Deal SecDeal ON SecDeal.DealName = corpDeal.DealName
									INNER JOIN [corp].[syn_SfpModelCorporate_vw_FactFacility] ff 
										ON ff.PartitionId = CONVERT(VARCHAR, CONVERT(DATETIME, @pDefaultDate), 112) AND ff.FacilityId = @FacilityId
									INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bdf 
										ON bdf.DealFacilityGroupKey =  ff.DealFacilityGroupKey AND bdf.DealKey = corpDeal.DealId
									WHERE [corpDeal].[IsActive] = 'Y' AND [SecDeal].[IsActive] = 1
									FOR XML PATH('')
								),1,1,'')
		
		/* EXECUTE COMMON SP TO FETCH THE DATA  */

		PRINT 'Common SP Execution Started (Default Date): ' + CONVERT(VARCHAR(20), GETDATE())

		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
				@VintageDate = @pDefaultDate,
				@DealKey	 = @CorpDealId,
				@FacilityIds = @FacilityId,
				@ReqColumns	 = @ReqCols,
				@FxRateDate  = @pFxRateDate,
				@OutputRowID = @RowID OUTPUT

		PRINT 'Common SP Execution Ended (Default Date): ' + CONVERT(VARCHAR(20), GETDATE())
			
		/* INSERT DATA INTO #DefaultDateData FROM STAGING TABLE  */
		SELECT DISTINCT 
				@pFacilityId AS [FacilityId]
				,DealName
				,RONA
				,B2_APP_EAD_PRE_CRM_AMT AS [EAD]
				,UtilisationGBP_ReportingDate AS [Utilisation]
		INTO #DefaultDateData 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
		
		SELECT 
			@TotalRona = SUM(RONA)
		FROM #DefaultDateData
		
		SELECT
			@CalcRona = IIF(@TotalRona = 0 OR @TotalRona IS NULL, 0, @MinPercent * Utilisation * (SELECT RONA FROM #DefaultDateData WHERE DealName = @pDealName) / @TotalRona)
		FROM #DefaultDateData 
		WHERE DealName = @pDealName

		/* FETCH DATA FOR PREVIOUS MONTH OF DEFAULT DATE */
		/* CONVERT REQUIRED COLUMN NAMES TO XML FORMAT */
		SELECT @ReqCols = (SELECT CriteriaFieldName
							FROM (VALUES ('RONA')
										,('CurrentPrincipalBalance')
										,('TTCLGD')
										,('DealName')
										,('RecordedLedgerBal')
										,('PosShareAmt')
										,('FxRate')
										,('LoanSourceId')
										,('UtilisationGBP_ReportingDate')) Field(CriteriaFieldName)
									FOR XML PATH('Node'), ROOT('Root'))


		SET @CorpDealId = (SELECT [DealId]
								FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1]
							WHERE [IsActive] = 'Y' AND [DealName] = @pDealName)

		/* EXECUTE COMMON SP TO FETCH THE DATA  */
		PRINT 'Common SP Execution Started (Month Before Default Date): ' + CONVERT(VARCHAR(20), GETDATE())

		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
				@VintageDate = @PreviousMonthDate,
				@DealKey	 = @CorpDealId,
				@FacilityIds = @FacilityId,
				@ReqColumns	 = @ReqCols,
				@FxRateDate  = @pFxRateDate,
				@OutputRowID = @RowID OUTPUT

		PRINT 'Common SP Execution Ended (Month Before Default Date): ' + CONVERT(VARCHAR(20), GETDATE())

		/* INSERT DATA INTO #PreviousMonthData FROM STAGING TABLE  */
		SELECT DISTINCT 
				@pFacilityId AS [FacilityId]
				,DealName
				,RONA
				,CONVERT(DECIMAL, REPLACE(CurrentPrincipalBalance, 'GBP', '')) AS [CurrentPrincipalBalance]
				,TTCLGD
		INTO #PreviousMonthData 
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
		
		
		
		/* CTE TO GET LATEST WRITEOFF DATA FOR A FACILITY */
		;WITH writeOffCTE AS
		(
			SELECT *,
				ROW_NUMBER() OVER (PARTITION BY FacilityId ORDER BY [Year], [Month] DESC) AS RowNo
			FROM [corp].[WriteOffData]
			WHERE IsActive = 1
		)

		/* SELECT REQUIRED DEFAULT DATE DATA */
		SELECT TOP(1)
			Curr.Utilisation AS [ExposureAtDefault]
			,WriteOff.Amount AS [EADRestructured]
			,Curr.RONA AS [CurrentExposure]
			,CASE 
				WHEN Prev.CurrentPrincipalBalance = 0.00 OR Prev.CurrentPrincipalBalance IS NULL
					THEN NULL
				ELSE (Prev.RONA * WriteOff.Amount) / Prev.CurrentPrincipalBalance
			END AS [CERestructured]
			,Prev.TTCLGD AS [InitialLossPercent]
			,Prev.RONA As [PreviousMonthRONA]
			,CASE
				WHEN @CalcRona < Curr.RONA THEN @CalcRona
				ELSE Curr.RONA
			END AS DefaultedNotional
			,CASE 
				WHEN Curr.Utilisation IS NULL OR Curr.Utilisation = 0 THEN 0
				WHEN @CalcRona < Curr.RONA THEN @CalcRona / Curr.Utilisation
				ELSE Curr.RONA / Curr.Utilisation
			END AS FacilitySharePercent
		FROM #DefaultDateData Curr
		LEFT JOIN #PreviousMonthData Prev ON Curr.FacilityId = Prev.FacilityId
		LEFT JOIN writeOffCTE WriteOff ON WriteOff.FacilityId = Curr.FacilityId AND WriteOff.RowNo = 1
		WHERE Curr.DealName = @pDealName


	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(),
			@errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetDefaultDateData',
			@errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
				
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
