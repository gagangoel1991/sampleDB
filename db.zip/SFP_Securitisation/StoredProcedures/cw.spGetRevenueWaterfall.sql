USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spGetRevenueWaterfall') IS NOT NULL
	DROP PROCEDURE cw.spGetRevenueWaterfall
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/********
   
  exec cw.spGetRevenueWaterfall	3,'fm\shriyad'
 

  **********/

CREATE PROC cw.spGetRevenueWaterfall
(
	@pDealIpdRunId INT,
	@pUserName	VARCHAR(80)
)
AS
BEGIN
	DECLARE 
		@Message			VARCHAR(4000), 		
		@exceptionErrorMessage  NVARCHAR(4000)		

	BEGIN TRY 
		DECLARE 
			@DealId			INT,
			@IpdDate		DATE,
			@DealName		VARCHAR(20),
			@ipdSequence	INT

		SELECT @DealId=DealId, @IpdDate=IpdDate, @DealName=DealName , @ipdSequence=IpdSequence FROM cw.vwDealIpdRun WHERE DealIpdRunId=@pDealIpdRunId;

		IF(@DealName IN ('ARDMORE1','DUNMORE1'))
			BEGIN
			  EXEC cw.spRMBSGetRevenueWaterfall	@pDealIpdRunId ,@pUserName 
			END
		ELSE
		   BEGIN
			  EXEC Cb.spGetRevenueWaterfall	@pDealIpdRunId ,@pUserName
			END		

		

	END TRY 
    BEGIN CATCH
	 DECLARE 
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@Message = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(),
			@errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'cw.spGetRevenueWaterfall', @errorNumber,  @errorSeverity, @errorLine, @Message, @pUserName

		
		RAISERROR (@Message,
             @errorSeverity,
             @errorState )
	END CATCH


END
GO