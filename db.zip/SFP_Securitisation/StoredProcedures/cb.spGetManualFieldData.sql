USE [SFP_Securitisation]
GO

IF OBJECT_ID('cb.spGetManualFieldData') IS NOT NULL
	DROP PROCEDURE cb.spGetManualFieldData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
 *   Author: Saurabh Bhatia
 *   Date:  28-Jan-2022
 *   Description:  To Get CB Manual Values Data 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.spGetManualFieldData 1034,'europa\bhasaaa'
 *    
  */
CREATE PROCEDURE [cb].[spGetManualFieldData] 
	 @pDealIpdRunId				INT,
	 @pManualFieldGroupTypeId	INT,
	 @pUserName					VARCHAR(20)
AS
BEGIN
	BEGIN TRY
		DECLARE @DealId INT;
		DECLARE @IpdDate DATETIME;

		SELECT @DealId = DealId
			,@IpdDate = IpdDate
		FROM [cw].[vwDealIpdRun]
		WHERE DealIpdRunId = @pDealIpdRunId;

		-- Current and Previous 3 ipd run id 
		SELECT TOP 4 DealIpdRunId
			,IpdDate
		INTO #DealRunDetail
		FROM [cw].[vwDealIpdRun]
		WHERE IpdDate <= @IpdDate
			AND DealId = @DealId
			AND IpdSequence > 131
		ORDER BY IpdDate DESC;

		SELECT CAST(IIF(g_p.ManualFieldGroupId IS NULL, g_c.ManualFieldGroupId, g_p.ManualFieldGroupId) AS INT) AS GroupFieldGroupId
			,IIF(g_p.DisplayName IS NULL, g_c.DisplayName, g_p.DisplayName) AS GroupDisplayName
			,CAST(IIF(g_p.ManualFieldGroupId IS NOT NULL, g_c.ManualFieldGroupId, NULL) AS INT) AS SubGroupFieldGroupId
			,IIF(g_p.DisplayName IS NOT NULL, g_c.DisplayName, NULL) AS SubGroupDisplayName
			,f.ManualFieldId
			,f.DisplayName AS FieldDisplayName
			,f.TooltipText
			,ManualFieldValueId
			,FieldDataType
			,v.[Value] AS [FieldValue]
			,v.DealIpdRunId
			,r.IpdDate
			,IIF(g_p.SortOrder IS NULL,g_c.SortOrder,g_p.SortOrder) AS GroupSortOrder
			,IIF(g_p.SortOrder IS NULL,NULL,g_c.SortOrder) AS SubGroupSortOrder			
			,f.SortOrder AS FieldSortOrder
			,v.ModifiedBy AS ModifiedBy
			,v.ModifiedDate AS ModifiedDate			
		FROM cfgcb.ManualFieldGroup g_c
		JOIN cfgcb.ManualFieldGroupType mfgt ON mfgt.ManualFieldGroupTypeId = g_c.ManualFieldGroupTypeId 
		AND mfgt.ManualFieldGroupTypeId =  @pManualFieldGroupTypeId
		LEFT JOIN cfgcb.ManualFieldGroup g_p ON (
				g_c.ParentManualFieldGroupId = g_p.ManualFieldGroupId
				AND g_p.IsActive = 1
				AND g_c.IsActive = 1
				)
		LEFT JOIN cfgcb.ManualField f ON f.ManualFieldGroupId = g_c.ManualFieldGroupId AND f.IsActive = 1
		JOIN cb.ManualFieldValue v ON v.ManualFieldId = f.ManualFieldId
		JOIN #DealRunDetail r ON r.DealIpdRunId = v.DealIpdRunId
		WHERE f.ManualFieldId IS NOT NULL AND g_c.IsActive = 1
		ORDER BY g_p.ManualFieldGroupId
			,g_c.ManualFieldGroupId
			,f.ManualFieldId;

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spGetManualFieldData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


