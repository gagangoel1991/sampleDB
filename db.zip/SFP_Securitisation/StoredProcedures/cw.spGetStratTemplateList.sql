USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetStratTemplateList]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetStratTemplateList]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [cw].[spGetStratTemplateList]
/*
 * Author: Kapil Sharma
 * Date:	10.12.2020
 * Description:  This will return the Strat Template List data 
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/		
@pUserName				VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		
		SELECT 
			st.StratTemplateId,
			st.Name AS [Name],
			st.Description,
			SUM(CASE WHEN sType.StratTypeId = 1 THEN 1 ELSE 0 END) AS AssetStratCount,
			SUM(CASE WHEN sType.StratTypeId = 2 THEN 1 ELSE 0 END) AS LiabilityStratCount,
			SUM(CASE WHEN sType.StratTypeId = 3 THEN 1 ELSE 0 END) AS MiscellaneousStratCount,
			CASE WHEN ISNULL(st.IsLocked, 0) = 1 THEN 'Locked' ELSE 'Active' END AS Status,
			st.CreatedBy AS CreatedBy,
			st.CreatedDate AS CreatedDate,
			st.ModifiedBy AS ModifiedBy,
			st.ModifiedDate AS ModifiedDate
		FROM
			cfgCW.IR_StratTemplate st
		JOIN
			cfgcw.IR_StratTemplateMap stm ON st.StratTemplateId = stm.StratTemplateId
		JOIN
			cfgcw.IR_Strat strat ON strat.StratId = stm.StratId
		JOIN
			[cfgCW].[IR_StratType] sType ON sType.StratTypeId = strat.StratTypeId
		GROUP BY
			st.StratTemplateId, st.Name, st.Description, sType.StratTypeId, st.IsLocked, st.CreatedBy, 
			st.CreatedDate, st.ModifiedBy, st.ModifiedDate
		ORDER BY
			st.ModifiedDate DESC
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetStratTemplateList', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
