USE [SFP_Securitisation]
GO

IF OBJECT_ID('cb.spResetManualFieldData') IS NOT NULL
	DROP PROCEDURE cb.spResetManualFieldData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/* 
 *   Author: Saurabh Bhatia
 *   Date:  28-Jan-2022
 *   Description:  To Get CB Manual Values Data 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date			Description 
	A.S.	18.07.2022		changed logic completely
	Arun	28.04.2023		Group Type check added of reset
 *   ------------------------------------------------------- 
 *    
  */
CREATE PROCEDURE [cb].[spResetManualFieldData] 
	 @pDealIpdRunId INT,	 
	 @pManualFieldGroupTypeId	INT
	,@pUserName VARCHAR(20)
AS
BEGIN
	BEGIN TRY
		
		DECLARE @prevDealIpdRunId INT;

		UPDATE v
		SET [Value] = v.DefaultValue
			,ModifiedDate = Getdate()
			,ModifiedBy = @pUserName
		FROM cb.ManualFieldValue v
		JOIN cfgcb.ManualField mf ON mf.ManualFieldId = v.ManualFieldId
		JOIN cfgcb.ManualFieldGroup mfg ON mfg.ManualFieldGroupId = mf.ManualFieldGroupId
		JOIN cfgcb.ManualFieldGroupType mfgt ON mfgt.ManualFieldGroupTypeId = mfg.ManualFieldGroupTypeId
		WHERE 
			mfgt.ManualFieldGroupTypeId = @pManualFieldGroupTypeId
			and v.DealIpdRunId = @pDealIpdRunId


		DECLARE @resultCode		INT
		EXEC [cb].[spReCalculateIpd] @pDealIpdRunId, @pUserName, @resultCode OUTPUT 

		EXEC [cw].[spUpdateIpdSummaryLineItemStatus] @pDealIpdRunId=@pDealIpdRunId,@lineItemCode='Manual_Field',@pUserName=@pUserName

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spResetManualFieldData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


