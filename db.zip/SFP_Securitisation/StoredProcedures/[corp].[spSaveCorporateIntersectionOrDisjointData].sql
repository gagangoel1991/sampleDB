USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spSaveCorporateIntersectionOrDisjointData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spSaveCorporateIntersectionOrDisjointData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[spSaveCorporateIntersectionOrDisjointData]        
@poolId INT,        
@sourcingType INT,         
@LimitAnalysisField VARCHAR(200),        
@UserName VARCHAR(50)         
AS    
        
BEGIN          
       
  DECLARE @PartitionId INT  
  DECLARE @VDate Date
  DECLARE @ReqCols XML    
  DECLARE @RowID VARCHAR(100) 
  DECLARE @DealKeys VARCHAR(50)      
          
  BEGIN TRY
	--Getting PartionId
	SELECT @PartitionId = CONVERT(VARCHAR, VintageDate, 112), @VDate = VintageDate FROM [ps].[Pool] WHERE [PoolId] = @poolId;

	IF OBJECT_ID('tempdb..#IntersectOrDisjointData ') IS NOT NULL
		DROP TABLE #IntersectOrDisjointData

    IF OBJECT_ID('tempdb..#Data ') IS NOT NULL
		DROP TABLE #Data

    --First delete all the data related         
    DELETE FROM [ps].[PoolBuildDetail] WHERE [PoolId] = @poolId; 

    CREATE TABLE #Data (FacilityId VARCHAR(50), FacilityKey INT, DealKey INT, RONA DECIMAL(28,10),TotalCreditLimit DECIMAL(28,10),UtilisationGBP_ReportingDate DECIMAL(28,10))	
       
	SELECT @DealKeys = COALESCE(@DealKeys + ',', '') + CAST(SourcePoolId AS VARCHAR(15))   
	FROM PS.PoolSourceMap   
	WHERE SourcePoolType IN ('Deal') AND IsActive = 1 AND PoolId= @poolId    
	ORDER BY SourcePoolId ASC  


  /*Getting Deal amount Values from common sp*/  
	IF LEN(@DealKeys) > 0
	BEGIN	

		SELECT @ReqCols = ( SELECT CriteriaFieldName, FieldDataType 
							FROM (SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
								  FROM ps.EligibilityCriteriaField   
								  WHERE AssetClassId = 2
								  AND CriteriaFieldSql IN ('FacilityId','RONA','TotalCreditLimit','UtilisationGBP_ReportingDate')  
								  UNION ALL 
								  SELECT 'FacilityKey',2
								  UNION ALL 
								  SELECT 'DealName',1
								  )x
							FOR XML PATH('Node'), ROOT('Root')
							)	
		
		PRINT 'Common SP Execution Start For Deal Data : ' + CONVERT(VARCHAR,GETDATE(),114)
		
		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @VDate,
			@DealKey	 = @DealKeys,			
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End For Deal Data: ' + CONVERT(VARCHAR,GETDATE(),114)		
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		INSERT INTO #Data
		SELECT DISTINCT stg.FacilityId, stg.FacilityKey, cd.DealId, stg.RONA, stg.TotalCreditLimit, stg.UtilisationGBP_ReportingDate
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] stg
		INNER JOIN corp.syn_SfpModelCorporate_vw_dimCorporateDeal cd ON cd.DealName = stg.DealName
		WHERE RowId = @RowID

	 	DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
	 END
        
	SELECT *     
	INTO #IntersectOrDisjointData          
	FROM(    
	  -- SELECT  DISTINCT     
	  --  REPLACE(FF.FacilityId,'\P','') AS FacilityId,   
	  --  ff.FacilityKey,  
	  --  CASE WHEN @LimitAnalysisField = 'OUTSTANDNG_CAPITAL_BALANCE_AMT' THEN ff.MarkedLimitAmt ELSE ff.MarkedLimitAmt END AS Balance,  -- Need to check  
	  --  psm.SelectedSourcePoolDropdown AS SelectedDropDown  
	  -- FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] ff  
	  --inner join[corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bdf on ff.DealFacilityGroupKey = BDF.DealFacilityGroupKey    
	  --INNER JOIN ps.PoolSourceMap psm WITH (NOLOCK) ON BDF.DealKey = psm.SourcePoolId        
	  --AND psm.PoolId = @poolId  AND psm.isActive = 1   
	  -- WHERE ff.partitionid = @Partitionid AND psm.SourcePoolType = 'Deal'   
   
	SELECT d.FacilityId
		  ,d.FacilityKey
		  ,CASE WHEN @LimitAnalysisField = 'RONA' THEN d.RONA 
			   WHEN @LimitAnalysisField = 'TotalCreditLimit' THEN d.TotalCreditLimit
			   WHEN @LimitAnalysisField = 'UtilisationGBP_ReportingDate' THEN d.UtilisationGBP_ReportingDate
		       ELSE d.TotalCreditLimit 
		   END AS Balance
		  ,psm.SelectedSourcePoolDropdown AS SelectedDropDown
	 FROM #Data d
	 INNER JOIN ps.PoolSourceMap psm ON d.DealKey = psm.SourcePoolId 
	 WHERE psm.SourcePoolType = 'Deal' AND psm.PoolId = @poolId  AND psm.isActive = 1 

	 UNION      
     
	SELECT DISTINCT       
		   REPLACE(ff.FacilityId,'\P','') AS FacilityId    
          ,ff.FacilityKey    
          ,CASE WHEN @LimitAnalysisField = 'RONA' THEN bdf.RONA ELSE pb.LoanBalance END AS Balance  
		  ,psm.SelectedSourcePoolDropdown AS SelectedDropDown    
    FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] ff 
	INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeDealFacility] bdf on ff.DealFacilityGroupKey = bdf.DealFacilityGroupKey   
    INNER JOIN ps.PoolBuildDetail pb WITH (NOLOCK) ON pb.MortgageAccountKey = ff.FacilityKey
	  --ON CASE WHEN ff.SourceId = 2 THEN CONVERT(VARCHAR(10),pb.LoanId) + '\P' ELSE  CONVERT(VARCHAR(10),pb.LoanId) END = ff.FacilityId
	  AND pb.IsActive = 1
    INNER JOIN ps.PoolSourceMap psm ON pb.PoolId = psm.SourcePoolId 
	WHERE ff.PartitionId = @PartitionId AND psm.SourcePoolType = 'Pool' AND psm.isActive = 1 AND psm.PoolId = @poolId 
  ) AS tmp  
        
	CREATE NONCLUSTERED INDEX NCI_#tempdata ON #IntersectOrDisjointData(SelectedDropDown)

	IF @sourcingType = (SELECT SourcingTypeId  FROM ps.PoolSourcingType WHERE Description  = 'Intersection')         
	BEGIN
	SELECT DISTINCT     
		   FacilityId    
		  ,FacilityKey   
		  ,Balance 
	FROM #IntersectOrDisjointData     
	WHERE SelectedDropDown = 1    
	AND FacilityId IN ( SELECT FacilityId FROM #IntersectOrDisjointData WHERE SelectedDropDown = 1    
						INTERSECT    
						SELECT FacilityId FROM #IntersectOrDisjointData WHERE SelectedDropDown = 2     
					   )
	END        
	ELSE         
	BEGIN
	SELECT DISTINCT     
		   FacilityId    
		  ,FacilityKey   
		  ,Balance
	FROM #IntersectOrDisjointData    
	 WHERE SelectedDropDown = 1    
	 AND FacilityId IN ( SELECT FacilityId FROM #IntersectOrDisjointData WHERE SelectedDropDown = 1    
						 EXCEPT  --Disjoint    
						 SELECT FacilityId FROM #IntersectOrDisjointData WHERE SelectedDropDown = 2    
						)       
	END 

	IF OBJECT_ID('tempdb..#IntersectOrDisjointData ') IS NOT NULL        
	DROP TABLE #IntersectOrDisjointData     
       
 END TRY          
    
 BEGIN CATCH        
        
  DECLARE         
    @errorMessage     NVARCHAR(MAX),        
    @errorSeverity    INT,        
    @errorNumber      INT,        
    @errorLine        INT,        
    @errorState       INT; 
	       
	SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()          
          
	EXEC app.SaveErrorLog 2, 1, 'spSaveCorporateIntersectionOrDisjointData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage ,@UserName    
	
	IF LEN(@RowID) > 1
	DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID    
          
	RAISERROR (  @errorMessage, @errorSeverity, @errorState )        
 END CATCH;     
END
GO