USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spProcessNoteSwap]') IS NOT NULL
	DROP PROCEDURE [cb].[spProcessNoteSwap]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cb].[spProcessNoteSwap] 
( 
  /* 
 *   Author: Aditya Shrivastava 
 *   Date:  10.01.2022
 *   Description:  Fill Note Swap table 
 *        
 *   Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   
 *   exec cb.[spProcessNoteSwap] 133,'fm\shriyad'
 *    select * from [Cb].[NoteSwap_Wf]  where DealIpdRunId = 36           
  */ 
  @pDealIpdRunId INT, 
  @pUserName  VARCHAR(20)
) 
AS
BEGIN 

      DECLARE @message VARCHAR(4000)

      BEGIN TRY 
          --declare @pDealIpdRunId int=65, @pUserName varchar(20)='fm\shriyad'; 

	    DECLARE 
			@dealId	INT, 
			@ipdDate DATE,
            @tempNoteSwapId      INT, 
			@payCouponPeriodStart datetime,
			@payCouponPeriodEnd datetime,
			@receiveCouponPeriodStart datetime,
			@receiveCouponPeriodEnd datetime,
			@jurisdictionMarker varchar(200),
			@payPaymentFrequency tinyint,
			@receivePaymentFrequency tinyint,
			@date datetime=getDate(),
			@CalculationDate date,
			@MaturityDate date,
			@CouponPaymentCalendarEndPeriod date,
			@LastCouponPaymentCalendarStartPeriod date,
			@LastCouponPaymentCalendarEndPeriod date,
			@endDateForYearFrac	date

        SELECT @dealId = DealId, 
			@ipdDate = IpdDate,
			@jurisdictionMarker = dlv.Value
        FROM   cw.vwDealIpdRun dir, cfgcw.DealLookupValue dlv
        WHERE  dlv.LookupValueId = dir.DealJurisdictionMarkerId AND DealIpdRunId = @pDealIpdRunId 

		Declare @MaxInterestRateDate date= (select top 1 BaseDate FROM [cw].[vwInterestRate] where RICCode = 'SONIAOSR=' order by 1 desc);
		SELECT @endDateForYearFrac = AccrualEndDate FROM cb.SoniaCompoundingRate WHERE ResetDate = @MaxInterestRateDate

		If(@endDateForYearFrac < @ipddate)
			SET @endDateForYearFrac= @endDateForYearFrac;
		else
			SET @endDateForYearFrac = @ipddate;

		  SELECT @CalculationDate = DealDateValue FROM [CW].[vwDealDate] 
		  WHERE DealIpdRunId=@pDealIpdRunId AND DealDateKeyInternalName='CalculationDate'

		  DECLARE @dealPreviousIpdRunId INT= [cw].[fnGetPrevIpdRunIdByIpdDate](@DealId, @ipdDate);


          IF Object_id('tempdb..#NoteSwap_Wf') IS NOT NULL 
            DROP TABLE #NoteSwap_Wf

          CREATE TABLE #NoteSwap_Wf
            ( 
				[DealIpdRunId] [int] NOT NULL,
				[NoteSwapId] [smallint] NULL,
				[PayCouponPeriodStart] [datetime] NOT NULL,
				[PayCouponPeriodEnd] [datetime] NOT NULL,
				[PayDayCountFactor] [decimal](38, 16) NULL,
				[PayBaseRate] [decimal](38, 16) NULL,
				[PayRate] [decimal](38, 16) NULL,
				[PayAmount] [decimal](38, 16) NULL,
				[ReceiveCouponPeriodStart] [datetime] NOT NULL,
				[ReceiveCouponPeriodEnd] [datetime]  NULL,
				[ReceiveBaseRate] [decimal](38, 16) NULL,
				[ReceiveRate] [decimal](38, 16) NULL,
				[PayPaymentFrequency] smallInt NULL,
				[ReceiveDayCountMethod] decimal(9,1) NULL,
				[ReceiveDayCountFactor] [decimal](38, 16) NULL,
				[ReceiveNotional] [decimal](38, 16) NULL,
				[ReceiveAmount] [decimal](38, 16) NULL,
				[NetAmount] [decimal](38, 16) NULL,
				CouponPaymentCalendarStartPeriod date,
				CouponPaymentCalendarEndPeriod date
            ) 

          SET @tempNoteSwapId =(SELECT TOP 1 NoteSwapId 
                                FROM   cfgCb.NoteSwap ns, cfgcb.DealNote dn
                                WHERE dn.DealNoteId = ns.DealNoteId AND DealId = @dealId 
								AND dn.ValidFrom<@date AND dn.ValidTo>@date
								AND ns.ValidFrom<@date AND ns.ValidTo>@date
								AND IssuanceDate<=@CalculationDate
                                ORDER  BY NoteSwapId ASC) 

          WHILE( @tempNoteSwapId > 0 ) 
            BEGIN 

				SELECT 
					 @payCouponPeriodStart = PayCouponPeriodEnd
					,@MaturityDate = ISNULL(NewRedemptionDate, dn.MaturityDate) 
					,@receiveCouponPeriodStart = IIF(@ipdDate<ReceiveCouponPeriodEnd
														OR 
														(MONTH(ReceiveCouponPeriodEnd)=MONTH(@ipdDate) AND YEAR(ReceiveCouponPeriodEnd)=YEAR(@ipdDate))
														, ReceiveCouponPeriodStart
														, ReceiveCouponPeriodEnd)
					,@payPaymentFrequency=dlvPayPaymentFrequency.Value 
					,@receivePaymentFrequency=dlvReceivePaymentFrequency.Value
					 ,@LastCouponPaymentCalendarStartPeriod=CouponPaymentCalendarStartPeriod
					 ,@LastCouponPaymentCalendarEndPeriod=CouponPaymentCalendarEndPeriod
				FROM cb.NoteSwap_Wf nswf
				JOIN cfgCb.NoteSwap ns ON ns.NoteSwapId = nswf.NoteSwapId
				JOIN cfgCb.DealNote dn ON dn.DealNoteId = ns.DealNoteId
				LEFT JOIN cw.vw_DealLookup dlvPayPaymentFrequency 
						ON ns.PayPaymentFrequencyId = dlvPayPaymentFrequency.LookupValueId
						AND  dlvPayPaymentFrequency.TypeCode = 'IpdFrequency'
				LEFT JOIN cw.vw_DealLookup dlvReceivePaymentFrequency 
						ON ns.ReceivePaymentFrequencyId = dlvReceivePaymentFrequency.LookupValueId
						AND  dlvReceivePaymentFrequency.TypeCode = 'IpdFrequency'
				WHERE ns.NoteSwapId = @tempNoteSwapId  AND DealIpdRUnId = @dealPreviousIpdRunId

				IF(@MaturityDate< @ipdDate)
					SET @payCouponPeriodEnd = @MaturityDate;
				ELSE
					SET @payCouponPeriodEnd = @ipdDate


				SET @receiveCouponPeriodEnd = (SELECT 
				[cw].[fnGetBusinessDate](dateadd(day,1,dateadd(day,-1,dateadd(month,@receivePaymentFrequency,@receiveCouponPeriodStart))), @jurisdictionMarker, 0, 0))
				
                INSERT INTO #NoteSwap_Wf 
                            (DealIpdRunId
							,NoteSwapId
							,PayCouponPeriodStart
							,PayCouponPeriodEnd
							,PayDayCountFactor
							,PayBaseRate
							,PayRate
							,PayAmount
							,ReceiveCouponPeriodStart
							,ReceiveCouponPeriodEnd
							,ReceiveBaseRate
							,ReceiveRate
							,PayPaymentFrequency
							,ReceiveDayCountMethod
							,ReceiveDayCountFactor
							,ReceiveNotional
							,ReceiveAmount
							,NetAmount
							,CouponPaymentCalendarStartPeriod
							,CouponPaymentCalendarEndPeriod) 
               SELECT @pDealIpdRunId,                       
						NoteSwapId, 
						@payCouponPeriodStart PayCouponPeriodStart,
						@payCouponPeriodEnd PayCouponPeriodEnd,
						[Cb].[fnYearFracValue] (@payCouponPeriodStart, @endDateForYearFrac, dlvPayDayCountMethod.Value) PayDayCountFactor,
						((CASE WHEN dlvPayRateType.Value='FIXED' 
								THEN 0 
								ELSE Round([Cb].[fnGetSoniaCompoundingCouponRate]
													(PayDayCountMethodId 
														-- PayDayCountFactor below
														,[Cb].[fnYearFracValue] (@payCouponPeriodStart
																				,@endDateForYearFrac
																				,dlvPayDayCountMethod.Value
																				)
													,@payCouponPeriodStart
													,@endDateForYearFrac
													)
											,6)
						END)) AS PayBaseRate,
						IIF(dlvPayRateType.Value='FIXED',ns.PayRateForFixed,
						--PayBaseRate below
							((CASE WHEN dlvPayRateType.Value='FIXED' 
													THEN 0 
													ELSE Round([Cb].[fnGetSoniaCompoundingCouponRate]
																			(PayDayCountMethodId, 
																				[Cb].[fnYearFracValue] (@payCouponPeriodStart
																										,@endDateForYearFrac
																										,dlvPayDayCountMethod.Value)
																			,@payCouponPeriodStart
																			,@endDateForYearFrac)
															,6)
							END))
							+ (ns.PayMargin/10000)) PayRate
						
						,(CONVERT(decimal(35,16),ns.PayNotional)
						* 
						CONVERT(decimal(18,16),
						IIF(dlvPayRateType.Value='FIXED',ns.PayRateForFixed,

							((CASE WHEN dlvPayRateType.Value='FIXED' 
													THEN 0 
													ELSE Round([Cb].[fnGetSoniaCompoundingCouponRate]
																			(PayDayCountMethodId, 
																				[Cb].[fnYearFracValue] (@payCouponPeriodStart
																										,@endDateForYearFrac
																										,dlvPayDayCountMethod.Value)
																			,@payCouponPeriodStart
																			,@endDateForYearFrac)
															,6)
							END))
							+ (ns.PayMargin/10000)) ) 
							* CONVERT(decimal(18,16),[Cb].[fnYearFracValue] (@payCouponPeriodStart ,@payCouponPeriodEnd, dlvPayDayCountMethod.Value)))PayAmount
						,@receiveCouponPeriodStart ReceiveCouponPeriodStart
						--,IIF(@receiveCouponPeriodEnd < @MaturityDate, @receiveCouponPeriodEnd, @MaturityDate)  ReceiveCouponPeriodEnd
						,NULL  ReceiveCouponPeriodEnd
						,IIF(dlvReceiveRateType.Value='FIXED',0,0) ReceiveBaseRate
						,IIF(dlvReceiveRateType.Value='FIXED',ReceiveRateForFixed/100,0.000491 + (ns.ReceiveMargin/10000)) ReceiveRate
						,dlvPayPaymentFrequency.Value PayPaymentFrequency
						,dlvReceiveDayCountMethod.Value ReceiveDayCountMethod
						,NULL ReceiveDayCountFactor
						,ns.ReceiveNotional
						,NULL ReceiveAmount
						,NULL NetAmount
						,IIF (@ipdDate<@LastCouponPaymentCalendarEndPeriod
						OR 
						(MONTH(@LastCouponPaymentCalendarEndPeriod)=MONTH(@ipdDate) AND YEAR(@LastCouponPaymentCalendarEndPeriod)=YEAR(@ipdDate))
																	,@LastCouponPaymentCalendarStartPeriod
																	,@LastCouponPaymentCalendarEndPeriod) AS CouponPaymentCalendarStartPeriod
						,NULL CouponPaymentCalendarEndPeriod
                FROM   cfgcb.NoteSwap ns 
						LEFT JOIN cw.vw_DealLookup dlvPayDayCountMethod ON ns.PayDayCountMethodId = dlvPayDayCountMethod.LookupValueId
					   AND  dlvPayDayCountMethod.TypeCode = 'DayCountMethod'

					   LEFT JOIN cw.vw_DealLookup dlvPayRateType ON ns.PayRateTypeId = dlvPayRateType.LookupValueId
					   AND  dlvPayRateType.TypeCode = 'RateType'

					   LEFT JOIN cw.vw_DealLookup dlvReceiveRateType ON ns.ReceiveRateTypeId = dlvReceiveRateType.LookupValueId
					   AND  dlvReceiveRateType.TypeCode = 'RateType'

					   LEFT JOIN cw.vw_DealLookup dlvPayPaymentFrequency ON ns.PayPaymentFrequencyId = dlvPayPaymentFrequency.LookupValueId
						AND  dlvPayPaymentFrequency.TypeCode = 'IpdFrequency'

					    LEFT JOIN cw.vw_DealLookup dlvReceiveDayCountMethod ON ns.ReceiveDayCountMethodId = dlvReceiveDayCountMethod.LookupValueId
					   AND  dlvReceiveDayCountMethod.TypeCode = 'DayCountMethod'
                WHERE  NoteSwapId = @tempNoteSwapId 


				 UPDATE #NoteSwap_Wf 
                SET   CouponPaymentCalendarEndPeriod = IIF(@MaturityDate<IIF(@MaturityDate <= CouponPaymentCalendarStartPeriod
																, @MaturityDate
																, DATEADD(month
																			,@receivePaymentFrequency
																			,CouponPaymentCalendarStartPeriod) )
																			,@MaturityDate
																			,IIF(@MaturityDate <= CouponPaymentCalendarStartPeriod
																, @MaturityDate
																, DATEADD(month
																			,@receivePaymentFrequency
																			,CouponPaymentCalendarStartPeriod) ))
                FROM   #NoteSwap_Wf  
                WHERE NoteSwapId = @tempNoteSwapId 


				 UPDATE #NoteSwap_Wf 
                SET   ReceiveCouponPeriodEnd = IIF([cw].[fnGetBusinessDate](dateadd(day,1,dateadd(day,-1,dateadd(month,@receivePaymentFrequency, CouponPaymentCalendarStartPeriod))), @jurisdictionMarker, 0, 0)
													< @MaturityDate
																, [cw].[fnGetBusinessDate](dateadd(day,1,dateadd(day,-1,dateadd(month,@receivePaymentFrequency, CouponPaymentCalendarStartPeriod))), @jurisdictionMarker, 0, 0)
																,@MaturityDate)
                FROM   #NoteSwap_Wf  
                WHERE NoteSwapId = @tempNoteSwapId 

				

                UPDATE #NoteSwap_Wf 
                SET    ReceiveDayCountFactor 
					= IIF(PayPaymentFrequency=12
						,1
						,[Cb].[fnYearFracValue] 
								(CouponPaymentCalendarStartPeriod
								,CouponPaymentCalendarEndPeriod
								,ReceiveDayCountMethod))
                FROM   #NoteSwap_Wf  
                WHERE NoteSwapId = @tempNoteSwapId 

				--select 
				--@receiveCouponPeriodEnd,
				--@MaturityDate,
				--@receiveCouponPeriodStart,
				--ReceiveDayCountMethod,
				--	 IIF(PayPaymentFrequency=12
				--		,1
				--		,[Cb].[fnYearFracValue] 
				--				(@receiveCouponPeriodStart
				--				,IIF(@receiveCouponPeriodEnd < @MaturityDate, @receiveCouponPeriodEnd, @MaturityDate)
				--				,ReceiveDayCountMethod))
    --            FROM   #NoteSwap_Wf  
    --            WHERE NoteSwapId = @tempNoteSwapId 


				UPDATE #NoteSwap_Wf 
                SET    ReceiveAmount = CONVERT(decimal(35,16),ReceiveNotional) * CONVERT(decimal(18,16),ReceiveDayCountFactor) * CONVERT(decimal(18,16),ReceiveRate)
                FROM   #NoteSwap_Wf  
                WHERE NoteSwapId = @tempNoteSwapId 

				UPDATE #NoteSwap_Wf 
                SET    NetAmount = ReceiveAmount - PayAmount
                FROM   #NoteSwap_Wf  
                WHERE NoteSwapId = @tempNoteSwapId 


				   SET @tempNoteSwapId =(SELECT TOP 1 NoteSwapId 
									FROM   cfgCb.NoteSwap ns, cfgcb.DealNote dn
									WHERE dn.DealNoteId = ns.DealNoteId AND DealId = @dealId 
									AND dn.ValidFrom<@date AND dn.ValidTo>@date
									AND ns.ValidFrom<@date AND ns.ValidTo>@date
									AND IssuanceDate<=@CalculationDate
									 AND NoteSwapId > @tempNoteSwapId 
									ORDER  BY NoteSwapId ASC) 
            END 

			--select * from #NoteSwap_Wf

          DELETE FROM [Cb].[NoteSwap_Wf] 
          WHERE  DealIpdRUnId = @pDealIpdRunId 

          INSERT INTO [Cb].[NoteSwap_Wf] 
                      ( DealIpdRunId
						,NoteSwapId
						,PayCouponPeriodStart
						,PayCouponPeriodEnd
						,PayDayCountFactor
						,PayBaseRate
						,PayRate
						,PayAmount
						,ReceiveCouponPeriodStart
						,ReceiveCouponPeriodEnd
						,ReceiveBaseRate
						,ReceiveRate
						,ReceiveDayCountFactor
						,ReceiveAmount
						,NetAmount
						,CouponPaymentCalendarStartPeriod
							,CouponPaymentCalendarEndPeriod
						,IsActive
						,CreatedDate
						,CreatedBy
						,ModifiedDate
						,ModifiedBy) 
          SELECT  DealIpdRunId
				,NoteSwapId
				,PayCouponPeriodStart
				,PayCouponPeriodEnd
				,PayDayCountFactor
				,PayBaseRate
				,PayRate
				,PayAmount
				,ReceiveCouponPeriodStart
				,ReceiveCouponPeriodEnd
				,ReceiveBaseRate
				,ReceiveRate
				,ReceiveDayCountFactor
				,ReceiveAmount
				,NetAmount
				,CouponPaymentCalendarStartPeriod
							,CouponPaymentCalendarEndPeriod
                 ,1, 
                 Getdate(), 
                 @pUserName, 
                 Getdate(), 
                 @pUserName 
          FROM   #NoteSwap_Wf 

		  
      END TRY 

      BEGIN CATCH 
        

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spProcessNoteSwap', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName

		RAISERROR (@errorMessage,
			@errorSeverity,
			@errorState )

		
      END CATCH 

      
END



GO