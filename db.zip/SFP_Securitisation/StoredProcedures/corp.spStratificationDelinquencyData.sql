USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[spStratificationDelinquencyData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [corp].[spStratificationDelinquencyData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Neeraj Jindal
Creation Date  : 18-Jul-2022
Description    : This will return calculated data for non-configurable strats
Execution      : EXEC [corp].[spStratificationDelinquencyData] @pDealId = 1 , @pAsAtDate= '2022-01-31', @pUserName='Europa\jindnaj'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spStratificationDelinquencyData] 	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @ReqCols XML 
		DECLARE @RowID Varchar(100)   

		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats
		IF OBJECT_ID('tempdb..#Delinquency') IS NOT NULL
		DROP TABLE #Delinquency
		IF OBJECT_ID('tempdb..#EmptyBucket') IS NOT NULL
		DROP TABLE #EmptyBucket
		 
        
		/*List of required Columns*/    
		DECLARE @AssetClassId INT = (SELECT AssetClassID FROM PS.AssetClass WHERE CODE = 'CL')
		SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType  
							FROM ps.EligibilityCriteriaField   
							WHERE AssetClassId = @AssetClassId
							AND CriteriaFieldSql IN ('FacilityId','RONA','DaysInExcess') 
							FOR XML PATH('Node'), ROOT('Root')
						  )
		
		PRINT 'Common SP Execution Start : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data from Common SP*/
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @pDealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT
		 
		PRINT 'Common SP Execution End : ' + CONVERT(VARCHAR(20),GETDATE())
		PRINT 'Strats Calculation Start : ' + CONVERT(VARCHAR(20),GETDATE())
 
		/*Saving Data from staging table into temp table with required datatype conversion*/
		SELECT DISTINCT 
			   FacilityId			  
			  ,RONA			  
			  ,DaysInExcess = ISNULL(DaysInExcess,0)
		INTO #Strats 		
		FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Calculating Non-Config Strats*/
		SELECT Bucket
			  ,Exposure = CONVERT(DECIMAL(18,2),SUM(RONA))
			  ,ExposurePercent = IIF(MAX(RonaTotal) = 0, 0.00 ,CONVERT(DECIMAL(18,6),SUM(RONA) / MAX(RonaTotal)))

		INTO #Delinquency
		FROM
			(SELECT
				 RONA
				,SUM(RONA) OVER() AS RonaTotal							
				,CASE WHEN DaysInExcess = 0 THEN '1_Current'
					  WHEN DaysInExcess >= 1 AND DaysInExcess < 30 THEN '2_1 to 29 days overdue'
					  WHEN DaysInExcess >= 30 AND DaysInExcess < 60 THEN '3_30 to 59 days overdue'
					  WHEN DaysInExcess >= 60 AND DaysInExcess < 90 THEN '4_60 to 89 days overdue'
					  WHEN DaysInExcess >= 90 AND DaysInExcess < 120 THEN '5_90 to 119 days overdue'
					  WHEN DaysInExcess >= 120 AND DaysInExcess < 150 THEN '6_120 to 149 days overdue'
					  WHEN DaysInExcess >= 150 AND DaysInExcess < 180 THEN '7_150 to 179 days overdue'
					  ELSE '8_180 + days overdue'
				END AS Bucket
			FROM #Strats	
			) d		
		GROUP BY Bucket		

		/*For Attaching a bucket which doen't come in actual data*/
		SELECT '1_Current' AS Bucket, 0.00 Exposure, 0.00 AS ExposurePercent
		INTO #EmptyBucket
		UNION SELECT '2_1 to 29 days overdue',0.00,0.00
		UNION SELECT '3_30 to 59 days overdue',0.00,0.00
		UNION SELECT '4_60 to 89 days overdue',0.00,0.00
		UNION SELECT '5_90 to 119 days overdue',0.00,0.00
		UNION SELECT '6_120 to 149 days overdue',0.00,0.00
		UNION SELECT '7_150 to 179 days overdue',0.00,0.00
		UNION SELECT '8_180 + days overdue',0.00,0.00

		INSERT INTO #Delinquency(Bucket, Exposure, ExposurePercent)
		SELECT eb.Bucket, eb.Exposure, eb.ExposurePercent 
		FROM #EmptyBucket eb
		WHERE eb.Bucket NOT IN (SELECT DISTINCT Bucket FROM #Delinquency) 

		SELECT SUBSTRING(Bucket,3,LEN(Bucket)) AS [~Bucket], Exposure, ExposurePercent AS '%' FROM #Delinquency ORDER BY Bucket
					
		/*Deleting Data from Staging table after use*/
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    
	
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationDelinquencyData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO
