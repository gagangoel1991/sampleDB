USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spGetPrincipalWaterfall') IS NOT NULL
	DROP PROCEDURE cb.spGetPrincipalWaterfall
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cb.spGetPrincipalWaterfall(
@pDealIpdRunId INT, 
@pUserName	VARCHAR(80)
/* 
 * Author: Aditya Shrivastava 
 * Date:  21.03.2020 
 * Description:  Get principal waterfall payment 
 *      
 * Change History 
 * -------------- 
 * Author    Date    Description 
 * ------------------------------------------------------- 
 * 
 * exec cb.spGetPrincipalWaterfall 35,'fm\shriyad' 
 * 
*/ 
)
AS
	BEGIN
	 SET NOCOUNT ON

	BEGIN TRY
	--	declare @pDealIpdRunId int=3 ,@pUserName varchar(20)='fm\shriyad';

		DECLARE @sourceId_DueAmount_cols AS NVARCHAR(MAX), @Max_SourceId_DueAmount_cols AS NVARCHAR(MAX)
		DECLARE @sourceId_SourceCurrentAmount_cols AS NVARCHAR(MAX), @Max_SourceId_SourceCurrentAmount_cols AS NVARCHAR(MAX)
		DECLARE @sourceId_AmountPaidFromSource_cols AS NVARCHAR(MAX), @Max_SourceId_AmountPaidFromSource_cols AS NVARCHAR(MAX)
		DECLARE @SourceId_RemainingDueAmount_cols AS NVARCHAR(MAX), @Max_SourceId_RemainingDueAmount_cols AS NVARCHAR(MAX)
		DECLARE @SourceId_IsEligible_cols AS NVARCHAR(MAX), @Max_SourceId_IsEligible_cols AS NVARCHAR(MAX)
		DECLARE @colNameToDisplay AS NVARCHAR(MAX);

		DECLARE @dealId  SMALLINT
		SELECT @dealId = DealId FROM cw.vwDealIpdRun WHERE DealIpdRunId = @pDealIpdRunId		

		IF( Object_id('tempdb..#tempSourceDisplayName') IS NOT NULL ) 
		DROP TABLE #tempSourceDisplayName 

		CREATE TABLE #tempSourceDisplayName (SourceName varchar(200), SourceDisplayName varchar(500))

		INSERT INTO #tempSourceDisplayName VALUES
		 ('Pre Available Principal Receipts','AvailablePrincipalReceipt')

		IF( Object_id('tempdb..#tempWaterfallEligibleSource') IS NOT NULL ) 
			DROP TABLE #tempWaterfallEligibleSource 

		CREATE TABLE #tempWaterfallEligibleSource 
		(WaterfallSourceId int, SourceDisplayName varchar(200), [priority] decimal(9,3))

		INSERT INTO #tempWaterfallEligibleSource
			SELECT ws.WaterfallSourceId, temp.SourceDisplayName, ws.[priority]
			FROM cfgCW.WaterfallSource ws
			JOIN cfgcw.WaterfallSourceEligibility wlse ON wlse.DealId = ws.DealId
			JOIN cfgcw.waterfallCategory wc  ON wc.DealId = wlse.DealId AND wlse.EligibleWaterfallSourceId=ws.WaterfallSourceId
			JOIN cfgcw.waterfallLineItem wli  ON  wli.waterfallCategoryId = wc.waterfallCategoryId
			AND wli.waterfallLineItemId = wlse.waterfallLineItemId
			JOIN #tempSourceDisplayName temp ON temp.SourceName = ws.SourceName
			WHERE 
			 wc.InternalName='PrincipalPriorityofPayments'
			AND ws.DealId=@dealId 
			AND ws.IsActive=1 
			GROUP BY ws.WaterfallSourceId,SourceDisplayName,[priority]
			ORDER BY [priority]

		SELECT @colNameToDisplay=STUFF((SELECT 
		+',' + QUOTENAME('IsEligible_'+SourceDisplayName)
		+',' + QUOTENAME('DueAmount_'+SourceDisplayName)
		+',' + QUOTENAME('SourceCurrentAmount_'+SourceDisplayName)
		+',' + QUOTENAME('AmountPaidFromSource_'+SourceDisplayName)
		+',' + QUOTENAME('RemainingDueAmountAfter_'+SourceDisplayName)
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')


		SELECT 
		-------------------DueAmount
				@sourceId_DueAmount_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+10000) 
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_DueAmount_cols=STUFF((SELECT ',max(' + QUOTENAME(WaterfallSourceId+10000)+') as ' + QUOTENAME('DueAmount_'+SourceDisplayName) +''
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				-------------------SourceCurrentAmount
				,@sourceId_SourceCurrentAmount_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+1000000) 
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_SourceCurrentAmount_cols
				=STUFF((SELECT ',max(' + QUOTENAME(WaterfallSourceId+1000000) +') as ' + QUOTENAME('SourceCurrentAmount_'+SourceDisplayName) +''
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				-------------------AmountPaidFromSource
				,@sourceId_AmountPaidFromSource_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+100000000) 
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_AmountPaidFromSource_cols
				=STUFF((SELECT ',max(' + QUOTENAME(WaterfallSourceId+100000000) +') as ' + QUOTENAME('AmountPaidFromSource_'+SourceDisplayName) +''
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				-------------------RemainingDueAmount
				,@SourceId_RemainingDueAmount_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+10000000000) 
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_RemainingDueAmount_cols
				=STUFF((SELECT ',max(' + QUOTENAME(WaterfallSourceId+10000000000) +') as ' + QUOTENAME('RemainingDueAmountAfter_'+SourceDisplayName) +''
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				-------------------IsEligible
				,@SourceId_IsEligible_cols=STUFF((SELECT ',' + QUOTENAME(WaterfallSourceId+1000000000000) 
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')
				, @Max_SourceId_IsEligible_cols
				=STUFF((SELECT ',max(' + QUOTENAME(WaterfallSourceId+1000000000000) +') as ' + QUOTENAME('IsEligible_'+SourceDisplayName) +''
					FROM #tempWaterfallEligibleSource ORDER BY [priority]
					FOR XML PATH(''), TYPE
					).value('.', 'NVARCHAR(MAX)') 
				,1,1,'')

				IF(object_id('tempdb..#finalTable') IS NOT NULL) DROP TABLE #finalTable

				DECLARE  @query  AS NVARCHAR(MAX);

				SET @query ='SELECT   WaterfallLineItemId,max(TotalDueAmount) as TotalDueAmount
				,'+@Max_SourceId_DueAmount_cols+','+@Max_SourceId_SourceCurrentAmount_cols+','+@Max_SourceId_AmountPaidFromSource_cols+',
				'+@Max_SourceId_RemainingDueAmount_cols+','+@Max_SourceId_IsEligible_cols+',max(TotalPaidAmount) as TotalPaidAmount
				into #finalTable
				 from 
					 (
						select WaterfallLineItemId,TotalDueAmount,DueAmount,SourceCurrentAmount,AmountPaidFromSource,RemainingDueAmount
						,CAST(IsEligible AS TINYINT) IsEligible,TotalPaidAmount
						,SourceId+10000 as SourceId_DueAmount
						,SourceId+1000000 as SourceId_SourceCurrentAmount
						,SourceId+100000000 as SourceId_AmountPaidFromSource
						,SourceId+10000000000 as SourceId_RemainingDueAmount
						,SourceId+1000000000000 as SourceId_IsEligible
						from cw.PrincipalWaterfallPayment where DealIpdRunId='+CONVERT(varchar(200),@pDealIpdRunId)+' 
					) x
					pivot 
					(
						max(DueAmount)
						for SourceId_DueAmount in ('+@sourceId_DueAmount_cols+')
					) p1 
					pivot 
					(
						max(SourceCurrentAmount)
						for SourceId_SourceCurrentAmount in ('+@sourceId_SourceCurrentAmount_cols+')
					) p2 
					pivot 
					(
						max(AmountPaidFromSource)
						for SourceId_AmountPaidFromSource in ('+@sourceId_AmountPaidFromSource_cols+')
					) p3
					pivot 
					(
						max(RemainingDueAmount)
						for SourceId_RemainingDueAmount in ('+@SourceId_RemainingDueAmount_cols+')
					) p4
					pivot 
					(
						max(IsEligible)
						for SourceId_IsEligible in ('+@SourceId_IsEligible_cols+')
					) p5 
					
					GROUP BY WaterfallLineItemId
					ORDER BY WaterfallLineItemId;

					select wli.WaterfallLineItemId, wli.DisplayName LineItem,f.TotalDueAmount,
					'+@colNameToDisplay+'
					,f.TotalPaidAmount
					,pwp.CreatedDate,pwp.CreatedBy,pwp.ModifiedDate, pwp.ModifiedBy
					from #finalTable f
					JOIN cfgCW.WaterfallLineItem wli ON f.WaterfallLineItemId=wli.WaterfallLineItemId
					JOIN cfgCW.WaterfallCategory wc ON wc.WaterfallCategoryId =wli.WaterfallCategoryId 
					JOIN cw.PrincipalWaterfallPayment pwp ON f.WaterfallLineItemId=pwp.WaterfallLineItemId
					JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId=pwp.DealIpdRunId AND dir.DealId=wc.DealId
					where 
					  dir.DealIpdRunId='+CONVERT(varchar(200),@pDealIpdRunId)+' 
					and wli.IsActive=1 
					and wc.IsActive=1 
					order by wli.SortOrder
							'
					--print @query
					EXECUTE(@query)


				--select  
				--convert(int,row_number() over(order by f.WaterfallLineItemId)) WaterfallRank,
				----f.WaterfallLineItemId,
				----w.categoryname,
				--w.Displayname
				--,f.IsARREligible
				--,f.DueAmount as Required
				--,f.ARRCurrentAmount
				--,f.AmountPaidFromARR
				--,DeficiencyPostARR
				--,f.IsGeneralReserveEligible
				--,GeneralReserveCurrentAmount
				--,case when IsGeneralReserveEligible=1 then DeficiencyPostARR else 0 end GeneralReserveRequiredSupport
				--,f.AmountPaidFromGeneralReserve
				--,DeficiencyPostGeneralReserve
				--,f.IsAPREligible
				--,DueAmountPostGeneralReserve
				--,case when IsAPREligible=1 then DueAmountPostGeneralReserve else 0 end PrincipalRequiredSupport
				--,APRCurrentAmount
				--,f.AmountPaidFromAPR
				--,DeficiencyPostAPR 
				--,f.AmountPaidFromARR+f.AmountPaidFromGeneralReserve+f.AmountPaidFromAPR as TotalAmountPaid
				--,f.DueAmount-(f.AmountPaidFromARR+f.AmountPaidFromGeneralReserve+f.AmountPaidFromAPR) as DeficiencyPostSupport
				--from #finalTable f, cfgCW.WaterfallLineItem w where f.WaterfallLineItemId=w.id 
				--		and w.DealId=@dealId and w.IsActive=1 order by w.SortOrder

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetPrincipalWaterfall', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
	END

GO 