USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetAllDealIPDsData') IS NOT NULL
	DROP PROCEDURE cw.spGetAllDealIPDsData
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh
--Date: 17-05-2021  
--Description: To get deals data for Admore/Dunmore for Cashwaterfall Dashboard
--Exec cw.spGetAllDealIPDsData ''
--==================================  
CREATE PROCEDURE [cw].[spGetAllDealIPDsData]
@pUserName VARCHAR(80) 
AS
BEGIN
	BEGIN TRY
	 -- drop table #AllDealsIPDData
	  CREATE TABLE #AllDealsIPDData
		(
			DealId int,
			RunId int,
			IpdDate date DEFAULT NULL,
			CollectionBusinessStart varchar(50),
			CollectionBusinessEnd varchar(50),
			IpdStatus varchar(50),
			IpdType varchar(50),
			DealName varchar(50),
			[DealStatus] varchar(200),
			[DealStatusDisplayName] varchar(200),
			EarlyRedemptionDate Datetime,
			SortOrder	SMALLINT
		 )
	   --current IPD
	   INSERT INTO #AllDealsIPDData 
	   SELECT t.* FROM
		(
		SELECT 
			 di.DealId
			,dir.RunID
			,di.IpdDate
			,dt.CollectionCalendarStart 			
			,dt.CollectionCalendarEnd
			,wfs.DisplayName AS IpdStatus
			,'Current' AS IpdType
			,deal.DealName			
			,NULL AS [DealStatus]
			,NULL AS [DealStatusDisplayName]
			,NULL AS EarlyRedemptionDate
			,deal.SortOrder
		FROM 
			cw.dealIpd di
		JOIN 
			cw.dealipdrun dir ON di.dealIpdid = dir.dealipdId
		JOIN 
			[cw].[vwDealIPDDates] dt ON dt.DealIpdID = di.DealIpdId
		JOIN 
			cw.vw_ActiveDeal deal ON deal.dealid = di.dealid
		JOIN 
			[CW].[vw_DealLookup] dl ON dl.LookupValueId = deal.DealTypeId AND dl.TypeCode = 'DealType'
		LEFT JOIN
			cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
		WHERE 
			IsCurrentIPD = 1
			AND dir.IsCurrentVersion = 1
			AND di.IpdSequence> CASE WHEN dl.[Value] = 'Covered Bond' THEN 131 ELSE 0 END --For CB, IPD sequence will be start from 132
		--Next IPD
		UNION
		SELECT 
			 ipd.DealId
			,NULL AS RunID 
			,nextDt.IPD AS IpdDate
			,nextDt.CollectionCalendarStart
			,nextDt.CollectionCalendarEnd
			,wfs.DisplayName AS IpdStats
			,'Next' AS IpdType
			,deal.DealName
			,deal.[DealStatus]
			,deal.[DealStatusDisplayName] AS [DealStatusDisplayName] 
			,EarlyRedemptionDate	
			,deal.SortOrder
		FROM 
			cw.vwDealIpdDates nextDt
		JOIN 
			cw.vwDealIpdDates currDt ON nextDt.IPD = currDt.NextIPD AND nextDt.DealId = currDt.DealId
		JOIN 
			cw.dealIpd ipd ON ipd.DealIpdId = currDt.DealIpdId
		JOIN 
			cw.vw_ActiveDeal deal ON deal.dealid = currDt.dealid
		LEFT JOIN
			cw.dealIpd prevIpd ON prevIpd.DealIpdId = currDt.DealIpdId
		LEFT JOIN 
			cw.dealipdrun dir ON dir.dealIpdid = prevIpd.dealipdId AND dir.IsCurrentVersion = 1
		LEFT JOIN
			cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
		WHERE 
			ipd.IsCurrentIPD = 1
		--Previous IPD
		UNION
		SELECT 
			 prevDt.DealId
			,dir.RunID
			,prevDt.IPD AS IpdDate
			,prevDt.CollectionCalendarStart
			,iif(prevDt.dealipdid =1,'2021-05-27',prevDt.CollectionCalendarEnd) AS CollectionBusinessEnd
			,wfs.DisplayName AS IpdStats
			,'Previous' AS IpdType
			,deal.DealName
			,NULL AS [DealStatus]
			,NULL AS [DealStatusDisplayName] 
			,NULL AS EarlyRedemptionDate
			,deal.SortOrder
		FROM 
			cw.vwDealIpdDates prevDt
		JOIN 
			cw.vwDealIpdDates currDt ON prevDt.DealId = currDt.DealId AND prevDt.IPD < currDt.NextIPD 
		JOIN 
			cw.dealIpd prevIpd ON prevIpd.DealIpdId = prevDt.DealIpdId
		JOIN 
			cw.dealIpd currIpd ON currIpd.DealIpdId = currDt.DealIpdId
		JOIN 
			cw.vw_ActiveDeal deal ON deal.dealid = currDt.dealid
		JOIN 
			[CW].[vw_DealLookup] dl ON dl.LookupValueId = deal.DealTypeId AND dl.TypeCode = 'DealType'
		JOIN 
			cw.dealipdrun dir ON prevIpd.dealIpdid = dir.dealipdId
		LEFT JOIN
			cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = dir.WorkflowStepId
		WHERE 
			currIpd.IsCurrentIPD = 1
			AND prevIpd.IpdSequence> CASE WHEN dl.[Value] = 'Covered Bond' THEN 131 ELSE 0 END --For CB, IPD sequence will be start from 132
			AND prevIpd.DealIpdId <> currIpd.DealIpdId
			AND dir.IsCurrentVersion = 1
		) t		
			ORDER BY t.dealName ASC,
			CASE
			 WHEN IpdType='Current' THEN 1
			 WHEN IpdType='Previous' THEN 2
			 WHEN IpdType='Next' THEN 3				
			END ASC,
			t.ipdDate DESC

		--blank Next IPD
		IF NOT EXISTS (SELECT 1 FROM #AllDealsIPDData dd		
							FULL JOIN #AllDealsIPDData dd1 ON dd1.dealid=dd.dealid WHERE dd1.IpdType  = 'Next') 
		BEGIN
			INSERT INTO  #AllDealsIPDData 
			SELECT DISTINCT dd.dealid,''
				,NULL AS IpdDate
				,''
				,''
				,'' AS IpdStats
				,'Next' AS IpdType
				,dd.DealName
				,NULL AS [DealStatus]
				,NULL AS [DealStatusDisplayName] 
				,NULL AS EarlyRedemptionDate
				,deal.SortOrder
				FROM #AllDealsIPDData dd
			  JOIN 
				cw.vw_ActiveDeal deal ON deal.dealid = dd.dealid
		     JOIN #AllDealsIPDData dd1 ON dd1.DealId=dd.DealId --dd1.IpdType<> dd.IpdType and dd1.DealId=dd.DealId
			AND dd1.IpdType =dd.IpdType --  in ('Next','Previous','Current')
			--	where dd.DealId is not null
		END

		--blank Previous IPD
		IF  EXISTS (SELECT 1
		FROM #AllDealsIPDData dd  RIGHT JOIN 
				cw.vw_ActiveDeal deal ON deal.dealid = dd.dealid AND dd.IpdType='Previous' AND deal.DealId IS NOT NULL
				JOIN 	cw.vwDealIpdDates currDt ON deal.dealid = currDt.dealid WHERE dd.DealId IS  NULL) 
		BEGIN
			INSERT INTO  #AllDealsIPDData 
			SELECT DISTINCT deal.dealid,''
				,NULL AS IpdDate
				,''
				,''
				,'' AS IpdStats
				,'Previous' AS IpdType
				,deal.DealName
				,NULL AS [DealStatus]
				,NULL AS [DealStatusDisplayName] 
				,NULL AS EarlyRedemptionDate
				,deal.SortOrder
				FROM #AllDealsIPDData dd  RIGHT JOIN 
				cw.vw_ActiveDeal deal ON deal.dealid = dd.dealid AND dd.IpdType='Previous' AND deal.DealId IS NOT NULL
				JOIN 	cw.vwDealIpdDates currDt ON deal.dealid = currDt.dealid WHERE dd.DealId IS  NULL
		END

		SELECT * FROM #AllDealsIPDData aipd
		ORDER BY 
			SortOrder ASC,
			CASE
			 WHEN IpdType='Current' THEN 1
			 WHEN IpdType='Previous' THEN 2
			 WHEN IpdType='Next' THEN 3
			END ASC,
			aipd.ipdDate DESC

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cw.spGetAllDealIPDsData'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH;
END

GO