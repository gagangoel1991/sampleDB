USE SFP_Securitisation
GO

IF OBJECT_ID('[corp].[spSaveOverrideLinkagesList]') IS NOT NULL
	DROP PROCEDURE corp.[spSaveOverrideLinkagesList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-------------------------------------------------------  
Author: Sakthivel Loganathan
Date: 24 Oct 2022  
Description: To save facility security Unlink/Relink from override screen.
*/

CREATE PROCEDURE [corp].[spSaveOverrideLinkagesList]
(
 @pDate DATE,  
 @pDealId INT,  
 @pStatusId INT = NULL,   
 @pLinkItems AS [corp].[FacilitySequrityLinkItem] READONLY,
 @pisListEdited VARCHAR(3) = '0',
 @pUserName VARCHAR(20), 
 @pResult INT OUTPUT
)
AS
BEGIN
 BEGIN TRY


  IF(@pisListEdited != '1')
  BEGIN
		SET @pResult = -15
		RETURN
  END

  DECLARE @IsActive BIT = 1
  DECLARE @pEntityId INT = (SELECT DealDataCorrectionEntityId FROM [corp].[DealDataCorrectionEntity] WHERE EntityName = 'Relinking')  

   -- DELETE IF EXISTING DETAILS AVAILABLE FOR STATUS : 'Draft', 'Rejected', 'Recalled'      
  DECLARE @LastDealDataCorrectionId INT = (SELECT MAX(DealDataCorrectionId) FROM [corp].[DealDataCorrection]       
											WHERE AsAtDate = @pDate AND DealId = @pDealId AND EntityTypeId = @pEntityId)   
    
  DECLARE @MaxDealOverrideParentId INT = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent]       
											WHERE AsAtDate = @pDate AND DealId = @pDealId)    
											
  DECLARE @LastStatusID INT = (SELECT DataCorrectionStatus FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @MaxDealOverrideParentId)     
    
    IF EXISTS(SELECT 1 FROM [corp].[DealDataCorrection] ddc    
      INNER JOIN [corp].[DealOverrideParent] dop ON ddc.AsAtDate = dop.AsAtDate AND ddc.DealId = dop.DealID AND ddc.DealOverrideParentId = dop.DealOverrideParentId    
      WHERE ddc.AsAtDate = @pDate AND ddc.DealId = @pDealId AND ddc.EntityTypeId = @pEntityId      
      AND dop.DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))    
      AND dop.DealOverrideParentId = @MaxDealOverrideParentId )    
    BEGIN    
		UPDATE [corp].[DealDataCorrection]       
		SET DataCorrectionStatus = 1, ModifiedBy = @pUserName, ModifiedDate = Getdate()       
		WHERE DealDataCorrectionId = @LastDealDataCorrectionId 
		
		-- DELETE AND INSERT
		DELETE FROM [corp].[DealDataCorrectionLinkage] WHERE DealDataCorrectionId = @LastDealDataCorrectionId

		INSERT INTO [corp].[DealDataCorrectionLinkage] (DealDataCorrectionId,AsAtDate,FacilityId,SecurityId,CradleSecurityId, isLinked,
														IsActive, CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		 SELECT @LastDealDataCorrectionId, @pDate, facilityId, securityId, cradleSecurityId, isLinked,
				1, @pUserName, GetDate(), @pUserName, GetDate()
		 FROM @pLinkItems
    
		UPDATE [corp].[DealOverrideParent]     
		SET DataCorrectionStatus = 1, ModifiedBy = @pUserName, ModifiedDate = Getdate()     
		WHERE DealOverrideParentId = @MaxDealOverrideParentId 
		
		SET @pResult = 0 --@LastDealDataCorrectionId
    END    
    ELSE IF NOT EXISTS(SELECT 1 FROM [corp].[DealDataCorrection] ddc    
      INNER JOIN [corp].[DealOverrideParent] dop ON ddc.AsAtDate = dop.AsAtDate AND ddc.DealId = dop.DealID     
      WHERE ddc.AsAtDate = @pDate AND ddc.DealId = @pDealId AND ddc.EntityTypeId = @pEntityId  AND ddc.DealOverrideParentId = dop.DealOverrideParentId    
      AND dop.DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))    
      AND dop.DealOverrideParentId = @MaxDealOverrideParentId )     
    BEGIN     
			IF NOT EXISTS (SELECT 1 FROM [corp].[DealOverrideParent] dop     
				WHERE dop.AsAtDate = @pDate AND dop.DealID = @pDealId     
				AND DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled'))
			)     
			BEGIN    
			 INSERT INTO [corp].[DealOverrideParent]    
			 (    
				  DealId,    
				  AsAtDate,    
				  DataCorrectionStatus,    
				  IsActive,   
				  CreatedBy,    
				  CreatedDate,    
				  ModifiedBy,    
				  ModifiedDate    
			 )    
			 VALUES    
			 (    
				  @pDealId,    
				  @pDate,     
				  @pStatusId,      
				  @IsActive,      
				  @pUserName,      
				  Getdate(),      
				  @pUserName,      
				  Getdate()    
			 )    
			END    
    
		 SELECT @MaxDealOverrideParentId = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent]     
             WHERE AsAtDate = @pDate AND DealId = @pDealId     
             AND DataCorrectionStatus IN (SELECT DealDataCorrectionStatusId FROM corp.[DealDataCorrectionStatus] WHERE STATUS IN ('Draft', 'Rejected', 'Recalled')))     
    
		INSERT INTO [corp].[DealDataCorrection]      
		(      
			AsAtDate,      
			DealId,      
			EntityTypeId,          
			DataCorrectionStatus,        
			IsActive,      
			CreatedBy,      
			CreatedDate,      
			ModifiedBy,      
			ModifiedDate ,    
			DealOverrideParentId    
		)      
		VALUES      
		(      
			@pDate,      
			@pDealId,      
			@pEntityId,      
			@pStatusId,      
			@IsActive,      
			@pUserName,      
			Getdate(),      
			@pUserName,      
			Getdate()  ,    
			@MaxDealOverrideParentId    
		)      
     
		DECLARE @pDealDataCorrectionId INT = (SELECT MAX(DealDataCorrectionId) FROM [corp].[DealDataCorrection] )  --@@IDENTITY (this won't work after trigger added)      
      
		-- INSERT INTO LINKAGE TABLE
		INSERT INTO [corp].[DealDataCorrectionLinkage] (DealDataCorrectionId,AsAtDate,FacilityId,SecurityId,CradleSecurityId,isLinked,
													IsActive, CreatedBy,CreatedDate,ModifiedBy,ModifiedDate)
		SELECT @pDealDataCorrectionId, @pDate, facilityId, securityId, cradleSecurityId,isLinked,
			1, @pUserName, GetDate(), @pUserName, GetDate()
		FROM @pLinkItems


	  SET @pResult = 0 --@pDealDataCorrectionId
      DECLARE @workflowType VARCHAR(50)='DealDataCorrection'      
      DECLARE @stepName VARCHAR(50)='Draft'      
      DECLARE @NewDdcComment  VARCHAR(250)='DealDataCorrection created'      
      DECLARE @DraftStatusId INT = 1       
      DECLARE @DealDataCorrectionFilterId  INT;     
    
      -- INSERTING WORKFLOW TABLE --      
      EXEC [ps].[spManageAuthWorkflow] @pWorkflowType=@workflowType,@pPsId=@MaxDealOverrideParentId,@pStatus=@DraftStatusId,@pStepName=@stepName,      
      @pComment=@NewDdcComment,@pUserName=@pUserName           
      -- WORKFLOW ENDS --     
  END   
END TRY    
 BEGIN CATCH                         
  DECLARE                         
  @errorMessage     NVARCHAR(MAX),                        
  @errorSeverity    INT,                        
  @errorNumber      INT,                        
  @errorLine        INT,                        
  @errorState       INT;                        
  SELECT                         
  @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                        
            
  SET @pResult = -15     
    
  EXEC app.SaveErrorLog 2, 1, 'SaveDataCorrectionBasicInfo', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                        
                          
  RAISERROR (@errorMessage, @errorSeverity, @errorState)    
 END CATCH    
END
GO
