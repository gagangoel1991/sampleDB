USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spLoadBondRatingData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadBondRatingData]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spLoadBondRatingData]  
/*-------------------------------------------------------  
Author: Arun
Date: 12.09.2020  
Description:  This will TRANSNFORM & LOAD data FROM staging into CW table for InterestRate
			  [cw].[spLoadBondRatingData]  1, '05-Oct-20'
Change History  
--------------  
Author			Date		Description  
-------------------------------------------------------  
Kapil Sharma	21-06-2022	Include the covered bond notes as well while populating the rating
*/  
(  
 @pFeedRunLogId   INT,  
 @pAsAtDate    DATETIME  
)  
AS  
BEGIN 
	Declare 
		@createdDate	DateTime = GETDATE(),
		@createdBy		VARCHAR(100) = 'System',
		@Version		INT=0,
		@ISIN			VARCHAR(40), 
		@Series			VARCHAR(10), 
		@CRAId			INT, 
		@RatingTypeId	INT,
		@Rating			VARCHAR(10)
			
	BEGIN TRY  

		IF @pFeedRunLogId IS NOT NULL  
		BEGIN  
			SELECT @RatingTypeId = RatingTypeId FROM cfgCW.RatingType WHERE Name='Bond Rating' 
			SELECT @Version = isNull(Version, 0) FROM cw.SourceBondRating
			WHERE CAST(CreatedDate as Date)= CAST(getdate() as Date)
			
			set @Version =@Version +1
			
			SELECT B.ISIN, A.CRAId, @RatingTypeId as RatingTypeID
			, CASE When A.Name ='Moody''s' Then CurrentRatingMoody
				   When A.Name ='Fitch' Then CurrentRatingFitch
				   When A.Name ='S&P' Then LTRIM(RTRIM(REPLACE(REPLACE(CurrentRatingSandP,'(sf)',''),'(sf','')))
				   End as Rating
			, @Version as Version, 1 as isActive
			, @CreatedBy as CreatedBy, @CreatedDate as CreatedDate
			, @CreatedBy as ModifiedBy, @CreatedDate as ModifiedDate
			INTO #BondData
			FROM cfgCW.CreditRatingAgency A
			,  cw.Syn_SfpStaging_tbl_BondRating B
			WHERE A.Name in ('Moody''s', 'Fitch', 'S&P' ) 
			and IsActive=1
			
			
			DECLARE cursorBondRatingStg CURSOR FAST_FORWARD
			FOR SELECT b.ISIN, dn.Series, b.CRAId, b.RatingTypeId, b.Rating 
			FROM #BondData b
			INNER JOIN 
			(
				SELECT rmbs.ISIN, rmbs.Series FROM cfgCW.DealNote rmbs 
				JOIN cfgCW.CashWaterfallDeal deal ON deal.DealId = rmbs.DealId
				WHERE rmbs.IsActive=1
				UNION
				SELECT cb.ISIN, cb.Series FROM cfgcb.DealNote cb WHERE cb.ValidTo > GETDATE()
			)dn ON dn.ISIN = b.ISIN
			WHERE b.Rating is not Null
			Order by b.ISIN

		--===================================
			OPEN cursorBondRatingStg
		--===================================
			
			FETCH NEXT FROM cursorBondRatingStg INTO 
				@ISIN, @Series, @CRAId, @RatingTypeId, @Rating 

			WHILE @@FETCH_STATUS = 0
			BEGIN
				SET @Version = 1;

				IF EXISTS(SELECT TOP 1* FROM CW.SourceBondRating WHERE CAST(RatingDate as Date)= CAST(@pAsAtDate as date)
					and ISIN=@ISIN and Rating=@Rating and CRAId=@CRAId )
				BEGIN
						
					SELECT @Version = Max(Version) FROM CW.SourceBondRating WHERE CAST(RatingDate as Date)= CAST(@pAsAtDate as date)
						and ISIN=@ISIN and Rating=@Rating   and CRAId=@CRAId
		
					DELETE FROM CW.SourceBondRating
					WHERE CAST(RatingDate as Date)= CAST(@pAsAtDate as date) and ISIN=@ISIN and Rating=@Rating  and CRAId=@CRAId

					SET @Version = ISNULL(@Version, 0) + 1
				END

				--Inserting data into CW.SourceBondRating Table
				Insert into CW.SourceBondRating (FeedRunLogId, ISIN, Series, CRAId, RatingTypeId, Rating, RatingDate
					,Version, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				Select @pFeedRunLogId,  @ISIN,  @Series, @CRAId, @RatingTypeId, @Rating, @pAsAtDate
					, @Version, @CreatedBy, @CreatedDate, @CreatedBy, @CreatedDate

			--Fetch record again FROM cursor
			FETCH NEXT FROM cursorBondRatingStg INTO 
				@ISIN, @Series, @CRAId, @RatingTypeId, @Rating  
					
			END
			CLOSE cursorBondRatingStg;
			DEALLOCATE cursorBondRatingStg;			

		END

	END TRY

	BEGIN CATCH  

	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  

	SELECT   
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  

	EXEC [CW].[spUpdateFeedRunLog] @pFeedRunLogId, '', 'Failed', 0  

	EXEC app.SaveErrorLog 1, 1, 'cw.spLoadBondRatingData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
	, 'System'  

	RAISERROR (@errorMessage,  
		 @errorSeverity,  
		 @errorState )  
	END CATCH  

END
GO


