USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetForberanceLoanType') IS NOT NULL
DROP PROC CW.spGetForberanceLoanType
GO

/*  
 * Author: Arun  
 * Date:    26.05.2020  
 * Description:  This will return Primary Forbearance - Loan Type for Investor report.  
 * Usage : CW.spGetForberanceLoanType @pAsAtDate  = '30-Nov-2020'  
 *   ,@pDealName  = 'DUNMORE1'    
 *   ,@pUserName = NULL       
 *     
 *   CW.spGetForberanceLoanType @pAsAtDate  = '30-OCT-2020'  
 *   ,@pDealName  = 'ARDMORE1'    
 *   ,@pUserName = NULL                                                    
 * Change History  
 * --------------  
 * Author              Date                 Description  
 * -------------------------------------------------------  
*/  
CREATE PROC CW.spGetForberanceLoanType @pAsAtDate DATE  
  ,@pDealName VARCHAR(255)   
  ,@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY   
  ,@pUserName VARCHAR(50) = NULL    
  
AS  
BEGIN  
      
      
BEGIN TRY  
     
    
 DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))  
 ,@totalSubAccounts float, @totalOutstandingCapitalBalance float, @totalTrueBalance float
 , @dealId INT  
 , @fieldName varchar(100) ='FORBEARANCE_TYPE';
 
   IF OBJECT_ID('tempdb..#Mortgage')					 IS NOT NULL DROP TABLE #Mortgage
   IF OBJECT_ID('tempdb..#ReportLookUp')				 IS NOT NULL DROP TABLE #ReportLookUp
   IF OBJECT_ID('tempdb..#Forbearance')					 IS NOT NULL DROP TABLE #Forbearance
   IF OBJECT_ID('tempdb..#FBType')						 IS NOT NULL DROP TABLE #FBType
   IF OBJECT_ID('tempdb..#NoSecondaryForbearance')		 IS NOT NULL DROP TABLE #NoSecondaryForbearance
   IF OBJECT_ID('tempdb..#CapitalisationArrear')		 IS NOT NULL DROP TABLE #CapitalisationArrear
   IF OBJECT_ID('tempdb..#TermExtension')				 IS NOT NULL DROP TABLE #TermExtension
   IF OBJECT_ID('tempdb..#FinalNoSecondaryForbearance')	 IS NOT NULL DROP TABLE #FinalNoSecondaryForbearance
   IF OBJECT_ID('tempdb..#FinalCapitalisationArrear')	 IS NOT NULL DROP TABLE #FinalCapitalisationArrear
   IF OBJECT_ID('tempdb..#FinalTermExtension')			 IS NOT NULL DROP TABLE #FinalTermExtension

     
 
	SELECT @dealId = MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1 

	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @dealId


	   
  
	SELECT MortgageSubAccountKey, ForbearanceKey, FORBEARANCE_TYPE AS ForbearanceType, FORBEARANCE_COUNTER AS ForbearanceCounter, FORBEARANCE_STATUS AS forbearanceStatus
	, CURRENT_CAPITALISATION_DATE AS CapitalisationDate, CURRENT_TERM_EXT_DATE AS TermExtensionDate
	, FIRST_FORBEARANCE_START_DATE AS FirstForbearanceStartDate, CURRENT_FORBEARANCE_END_DATE AS CurrentForbearanceEndDate, Forbearance_AsAtDateFrom AS AsAtDateFrom, Forbearance_AsAtDateTo AS AsAtDateTo
	, Outstandng_Capital_Balance_Amt AS TotalOutstandingCapitalBalance, True_Balance_Amt AS TrueBalance
	, CW.fnGetStratConfigGroupName(@pStratRangeData, MONTHS_IN_ARREARS ) AS BandRange  
	INTO #Mortgage        
	FROM #VwMortgageSubAccount
		
	  
	 CREATE CLUSTERED INDEX FB ON #Mortgage  (forbearancekey);       
	  
	 SELECT LookUpValue, AL.ReportLookupValue AS LookUpValueDescription  INTO #ReportLookUp 
	 FROM cfgcw.IR_AssetStratGroupingLookupData AL 
	 INNER JOIN  cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
	 INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 L ON L.ReportTemplateName='SFP+' 
						AND L.LookupValueDescription=AL.ReportLookupName AND L.LookupName =M.FieldName
	 WHERE M.FieldName=@fieldName
	 
	   
	 CREATE CLUSTERED INDEX IndxLookup ON #ReportLookUp (LookUpValue)  
	   
	 SELECT MortgageSubAccountKey, ForbearanceKey, ForbearanceType, ForbearanceStatus, CapitalisationDate, TermExtensionDate, TotalOutstandingCapitalBalance, TrueBalance, BandRange, FirstForbearanceStartDate, CurrentForbearanceEndDate 
	 INTO #Forbearance    
	 FROM #Mortgage F  
	 WHERE f.ForbearanceStatus = 'L'  AND  f.AsAtDateTo > @pAsAtDate  AND f.AsAtDateFrom <= @pAsAtDate   
	 AND f.ForbearanceKey <> - 1    
	     
	 CREATE CLUSTERED INDEX CR ON #Forbearance  (forbearancekey);    
	  
	 CREATE TABLE #FBType(SortOrder tinyint,FBLoanType varchar(100))  
	 INSERT INTO #FBType VALUES (1, 'Reduced Repayment - Amortising')  
	 INSERT INTO #FBType VALUES (2, 'Alternate Treatments - Discount Rate')  
	 INSERT INTO #FBType VALUES (3, 'Reduced Repayment - Interest Only')  
	 INSERT INTO #FBType VALUES (4, 'Other')  
	   
	 CREATE CLUSTERED INDEX FLT ON #FBType  (FBLoanType);   
	   
	--=FOR % of Total pool of Mortgage  
	 SELECT @totalSubAccounts = COUNT(ISNULL(M.MortgageSubAccountKey, 0))    
	  , @totalOutstandingCapitalBalance = SUM(ISNULL(M.TotalOutstandingCapitalBalance, 0))    
	  , @totalTrueBalance  = ISNULL(SUM(M.TrueBalance), 0)  
	 FROM   #Mortgage M  
	   
	---=For @Amortising in Forbearance ---    
	 SELECT FBLoanType, Count(DISTINCT F.MortgageSubAccountKey) AS MortgageSubAccountKey, Sum(F.TotalOutstandingCapitalBalance) AS TotalOutstandingCapitalBalance, Sum(F.TrueBalance) AS TrueBalance  
	 INTO #NoSecondaryForbearance  
	 FROM #Forbearance F  
	 INNER JOIN #ReportLookUp r ON r.LookUpValue = f.ForbearanceType  
	 INNER JOIN #FBType FBT ON FBT.FBLoanType = r.LookUpValueDescription  
	 WHERE f.CapitalisationDate IN (       '0001-01-01'       ,'1900-01-01'       )    
		AND f.TermExtensionDate IN (       '0001-01-01'       ,'1900-01-01'       )    
		AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate
		GROUP BY FBLoanType  
	  
	 SELECT FBLoanType, Count(F.MortgageSubAccountKey) AS MortgageSubAccountKey, Sum(F.TotalOutstandingCapitalBalance) AS TotalOutstandingCapitalBalance, Sum(F.TrueBalance) AS TrueBalance  
	 INTO #CapitalisationArrear  
	 FROM #Forbearance F  
	 INNER JOIN #ReportLookUp r ON r.LookUpValue = f.ForbearanceType  
	 INNER JOIN #FBType FBT ON FBT.FBLoanType = r.LookUpValueDescription  
	 WHERE f.CapitalisationDate NOT IN (       '0001-01-01'       ,'1900-01-01'       )   
	 AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate
	 GROUP BY FBLoanType  
	      
	 SELECT FBLoanType, Count(F.MortgageSubAccountKey) AS MortgageSubAccountKey, Sum(F.TotalOutstandingCapitalBalance) AS TotalOutstandingCapitalBalance, Sum(F.TrueBalance) AS TrueBalance  
	 INTO #TermExtension  
	 FROM #Forbearance F  
	 INNER JOIN #ReportLookUp r ON r.LookUpValue = f.ForbearanceType  
	 INNER JOIN #FBType FBT ON FBT.FBLoanType = r.LookUpValueDescription  
	 WHERE f.TermExtensionDate NOT IN (       '0001-01-01'       ,'1900-01-01'       )   
	 AND FirstForbearanceStartDate <= @pAsAtDate
		AND CurrentForbearanceEndDate >= @pAsAtDate 
		GROUP BY FBLoanType    
	        
	                 
	--=========================================================================================  
	  
	 SELECT 'No Secondary Forbearance' AS 'HeaderText', F.FBLoanType AS SubHeaderText ,  isNull(MortgageSubAccountKey,0)AS [MortgageLoans]  
	 , ISNULL(CAST( CASE WHEN @totalSubAccounts> 0 THEN Cast( (MortgageSubAccountKey / @totalSubAccounts  ) AS Decimal(38,18)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent    
	 , ISNULL(CAST((TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance'   
	 , CAST(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN ISNULL(Cast( (TotalOutstandingCapitalBalance / @totalOutstandingCapitalBalance)  AS Decimal(38,18)),0)  ELSE 0 END AS Float) TotalOutCapitalBalancePercent  
	 , ISNULL(CAST((TrueBalance) AS Decimal(38,2)) , 0)  TrueBalance  
	 , ISNULL(CAST( CASE WHEN @totalTrueBalance> 0 THEN Cast( ((TrueBalance) / @totalTrueBalance)  AS Decimal(38,18)) ELSE 0 END  AS Float) , 0) TrueBalancePercent    
	 INTO #FinalNoSecondaryForbearance  
	 FROM #FBType F  
	 LEFT JOIN #NoSecondaryForbearance dans ON F.FBLoanType=dans.FBLoanType   
	   
	   
	 SELECT 'Secondary Forbearance - Capitalisation of Arrears' AS 'HeaderText', F.FBLoanType AS SubHeaderText , isNull(MortgageSubAccountKey,0)AS [MortgageLoans]  
	 , ISNULL(CAST( CASE WHEN @totalSubAccounts> 0 THEN Cast( (MortgageSubAccountKey / @totalSubAccounts  ) AS Decimal(38,8)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent    
	 , ISNULL(CAST((TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance'   
	 , CAST(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN ISNULL(Cast( (TotalOutstandingCapitalBalance / @totalOutstandingCapitalBalance) AS Decimal(38,8)),0)  ELSE 0 END AS Float) TotalOutCapitalBalancePercent  
	 , ISNULL(CAST((TrueBalance) AS Decimal(38,2)) , 0)  TrueBalance  
	 , ISNULL(CAST( CASE WHEN @totalTrueBalance> 0 THEN Cast( ((TrueBalance) / @totalTrueBalance)  AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) TrueBalancePercent    
	 INTO #FinalCapitalisationArrear  
	 FROM #FBType F  
	 LEFT JOIN #CapitalisationArrear dans ON F.FBLoanType=dans.FBLoanType  
	   
	   
	 SELECT 'Secondary Forbearance - Term Extension' AS 'HeaderText', F.FBLoanType AS SubHeaderText,  isNull(MortgageSubAccountKey,0)AS [MortgageLoans]  
	 , ISNULL(CAST( CASE WHEN @totalSubAccounts> 0 THEN Cast( (MortgageSubAccountKey / @totalSubAccounts ) AS Decimal(38,8)) ELSE 0 END AS Float) , 0) AS MortgageLoansPercent    
	 , ISNULL(CAST((TotalOutstandingCapitalBalance) AS Decimal(38,2)) , 0) 'TotalOutCapitalBalance'   
	 , CAST(CASE WHEN @totalOutstandingCapitalBalance > 0 THEN ISNULL(Cast( (TotalOutstandingCapitalBalance / @totalOutstandingCapitalBalance) AS Decimal(38,8)),0)  ELSE 0 END AS Float) TotalOutCapitalBalancePercent  
	 , ISNULL(CAST((TrueBalance) AS Decimal(38,2)) , 0)  TrueBalance  
	 , ISNULL(CAST( CASE WHEN @totalTrueBalance> 0 THEN Cast( ((TrueBalance) / @totalTrueBalance)  AS Decimal(38,8)) ELSE 0 END  AS Float) , 0) TrueBalancePercent    
	 INTO #FinalTermExtension  
	 FROM #FBType F  
	 LEFT JOIN #TermExtension dans ON F.FBLoanType=dans.FBLoanType  
	   
	  SELECT   
	  ISNULL(FB.FBLoanType,'Total') AS '~HeaderText',    
	  SUM(FS.[MortgageLoans]) AS 'Number of Mortgage Loans~NoSecondaryForbearance',    
	  SUM(FS.TotalOutCapitalBalance) AS 'Amount (EUR)~NoSecondaryForbearance',     
	  SUM(FS.TotalOutCapitalBalancePercent) AS 'Amount as % of total pool assets~NoSecondaryForbearance',   
	  SUM(FC.[MortgageLoans]) AS 'Number of Mortgage Loans~CapitalisationArrear',   
	  SUM(FC.TotalOutCapitalBalance) AS 'Amount (EUR)~CapitalisationArrear',    
	  SUM(FC.TotalOutCapitalBalancePercent) AS 'Amount as % of total pool assets~CapitalisationArrear',   
	  SUM(FI.[MortgageLoans]) AS 'Number of Mortgage Loans~TermExtension',   
	  SUM(FI.TotalOutCapitalBalance) AS 'Amount (EUR)~TermExtension',     
	  SUM(FI.TotalOutCapitalBalancePercent) AS 'Amount as % of total pool assets~TermExtension',   
	  SUM(FS.TotalOutCapitalBalancePercent+FC.TotalOutCapitalBalancePercent+FI.TotalOutCapitalBalancePercent) AS 'Amount as % of total pool assets'    
	  FROM #FBType FB  
	  LEFT JOIN #FinalNoSecondaryForbearance FS ON FB.FBLoanType = FS.SubHeaderText  
	  LEFT JOIN #FinalCapitalisationArrear FC ON FB.FBLoanType = FC.SubHeaderText  
	  LEFT JOIN #FinalTermExtension FI ON FB.FBLoanType = FI.SubHeaderText  
	  GROUP BY FB.FBLoanType WITH rollup   
	  ORDER BY SUM(FB.SortOrder)  
  
  
END TRY  
BEGIN CATCH  
    DECLARE   
                @errorMessage     NVARCHAR(MAX),  
                @errorSeverity    INT,  
                @errorNumber      INT,  
                @errorLine        INT,  
                @errorState       INT;  
  
    SELECT   
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()  
  
    EXEC app.SaveErrorLog 1, 1, 'spGetForberanceLoanType', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
      
    RAISERROR (@errorMessage,  
                @errorSeverity,  
                @errorState )  
END CATCH     
END  

GO

