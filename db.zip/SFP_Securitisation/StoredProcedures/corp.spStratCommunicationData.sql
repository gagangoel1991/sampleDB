USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[spStratCommunicationData]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [corp].[spStratCommunicationData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 29-Aug-2022
Description    : This will return communication strat data for CB IR
Execution      : EXEC [corp].[spStratCommunicationData] @pDealId = 1 , @pAsAtDate= '2022-07-29', @pUserName='Europa\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spStratCommunicationData] 	   	 
	 @pAsAtDate Date,
	 @pDealId INT,
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY 

		DECLARE @PreviousBusinessDate DATE = DATEADD(m, -2, DATEADD(m, DATEDIFF(m, 0, @pAsAtDate), 0))
		DECLARE @SRTDealTypeId INT = (SELECT v.LookupValueId FROM [cfgCW].[DealLookupValue] v
										INNER JOIN cfgCW.DealLookupType t 
											ON v.LookupTypeId=t.LookupTypeId
										WHERE t.TypeCode='DealType' AND v.Name ='SRT')
		IF OBJECT_ID('tempdb..#Strats') IS NOT NULL
		DROP TABLE #Strats

		IF OBJECT_ID('tempdb..#StratsCommunication') IS NOT NULL
		DROP TABLE #StratsCommunication

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())

		SELECT [Business Date] = CAST(CONVERT(VARCHAR, EOMONTH(@pAsAtDate), 103) AS VARCHAR(255)) 
			  ,[Closing Date] = CAST(CONVERT(VARCHAR, ISNUll(dl.ClosingDate,'01/01/1900'), 103) AS VARCHAR(255)) 
			  ,[Schedule Maturity Date] = CAST(CONVERT(VARCHAR, ISNULL(dl.DealMaturityDate, '01/01/1900'), 103) AS VARCHAR(255))
			  ,[Previous Business Date] = CAST(CONVERT(VARCHAR, @PreviousBusinessDate, 103) AS VARCHAR(255)) 
			  ,[Risk Retention Method] = CAST(ISNULL(corpDl.RiskRetentionMethod + ' slice (Minimum ' + CONVERT(VARCHAR, CONVERT(FLOAT, (1 - dl.RiskRetentionPercent) * 100)) + '%)', '') AS VARCHAR(255)) 
			  ,[Risk Retention Holder] = CAST(IIF(corpDL.RiskRetentionHolder IN ('RBS', 'NWB'), 'Originator (ORIG)', 'Other (OTHR)') AS VARCHAR(255)) 
			  ,[Risk Transfer Method] = CAST(IIF(dl.DealTypeId = @SRTDealTypeId, 'Synthetic', 'Other') AS VARCHAR(255))
			  ,[Underlying Exposure Type] = CAST('Other (OTHR)' AS VARCHAR(255))
			  ,[Business Month Name] = CAST(FORMAT(@pAsAtDate, 'MMM') AS VARCHAR(255))
		INTO #StratsCommunication
		FROM cfg.Deal dl
		INNER JOIN [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] corpDl
			ON dl.DealName = corpDl.DealName AND  dl.IsActive = 1
		WHERE corpDl.DealId = @pDealId
		
		/*Showing Data Vertically*/
		SELECT [Bucket] AS [~Attributes]
			  ,[Values] AS [~Values]
		FROM  (SELECT * FROM #StratsCommunication) AS x
		UNPIVOT ([Values] FOR Bucket IN (
									 [Business Date]
									,[Closing Date]
									,[Schedule Maturity Date]
									,[Previous Business Date]
									,[Risk Retention Method]
									,[Risk Retention Holder]	
									,[Risk Transfer Method]
									,[Underlying Exposure Type]
									,[Business Month Name]
									)
					) AS unpvt

		PRINT 'Strats Calculation End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;    

		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratCommunicationData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO
