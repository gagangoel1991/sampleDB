USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spValidateDrillThroughReportCB]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spValidateDrillThroughReportCB]
GO


SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


-- exec [corp].[spValidateDrillThroughReportCB] 651, 'kumasdt'
CREATE PROCEDURE [corp].[spValidateDrillThroughReportCB]
	@pPoolId int,
	@pUserName VARCHAR(50),
	@pReturnValue INT = 1 OUTPUT
AS
BEGIN		
	BEGIN TRY

		DECLARE @ApplicableECMethod INT;
		SELECT @ApplicableECMethod = ApplicableECMethod FROM PS.Pool WHERE PoolId = @pPoolId
		
		DECLARE @ECCount INT; 
		SELECT @ECCount = COUNT(1) FROM PS.PoolEligibilityBuildDetail WHERE PoolId = @pPoolId AND EligibilityCriteriaId <> -1;

		DECLARE @CTCount INT; 
		SELECT @CTCount = COUNT(1) FROM PS.PoolCTMap WHERE PoolId = @pPoolId;


		IF @ApplicableECMethod = 1
		BEGIN
			-- Check validation for EC ALL option selected for Pool
			-- Check whether any EC or CT applied on Pool or not		
			IF (@ECCount > 0 OR @CTCount > 0)		
				SET @pReturnValue = 1;		
			ELSE
				SET @pReturnValue = -1;
		END
		ELSE
		BEGIN
			-- Check validation for EC ANY option selected for Pool
			SELECT @ECCount = COUNT(*) FROM PS.PoolEcMap WHERE PoolId = @pPoolId AND IsActive = 1

			DECLARE @FailedLoansCount INT = 0
			IF @ECCount > 0
			BEGIN
				;WITH CTE(LoanId, [COUNT]) AS (
					SELECT LoanId, COUNT(*) OVER (PARTITION BY LoanId) [Count] FROM PS.PoolEligibilityBuildDetail where poolid = @pPoolId
				)

				SELECT @FailedLoansCount = count(*) FROM CTE WHERE [Count] = @ECCount
			END

			IF ( (@ECCount > 0 AND @FailedLoansCount > 0) OR @CTCount > 0)		
				SET @pReturnValue = 1;		
			ELSE
				SET @pReturnValue = -1;

		END

		
		-- -- Check whether any EC or CT applied on Pool or not		
		-- IF (@ECCount > 0 OR @CTCount > 0)		
		-- 	SET @pReturnValue = 1;		
		-- ELSE
		-- 	SET @pReturnValue = -1;

		RETURN @pReturnValue;
   END TRY
	BEGIN CATCH		
		SET @pReturnValue  = -2;
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spValidateDrillThroughReportCB', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RETURN @pReturnValue;

		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
