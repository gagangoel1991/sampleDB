USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetCBNoteSummary]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetCBNoteSummary]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 24-02-2022
--Description: GET NoteSummary for CB 
--[cb].[spGetCBNoteSummary] 6,46,''
--==================================   
CREATE PROCEDURE [cb].[spGetCBNoteSummary] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY
		SELECT dn.DealNoteId
			,CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
			,CONVERT(VARCHAR(10), nwf.CouponPaymentStartPeriod, 103) CouponPaymentStartPeriod
			,CONVERT(VARCHAR(10), nwf.CouponPaymentEndPeriod, 103) CouponPaymentEndPeriod
			,ISNULL(nwf.DayCount,0) AS DaysInInterestPeriod
			,dlv.value AS DayCountBasis
			,nwf.BaseRate AS BaseRate
			,nwf.Coupon AS CouponRate
			,nwf.PrincipalOutstanding_Ccy
			,nwf.PrincipalOutstanding_GBP
			,nwf.InterestAmountDue_Ccy
			,nwf.InterestAmountDue_GBP
			,nwf.RequiredRedemptionForHardBullet
			,nwf.RedemptionAmountForExtendedBond_GT1yr
			,nwf.RedemptionAmountForExtendedBond_LTEq1yr
			,nwf.RateForEstimation AS RateForEstimation
			,nwf.EstimatedThreeMonthInterest_GBP
			,nwf.EstimatedOneMonthInterest_GBP
		FROM cb.DealNote_Wf nwf
		JOIN cfgcb.DealNote dn ON dn.DealNoteId = nwf.DealNoteId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId
 = nwf.DealipdRunid

		JOIN [CW].[vw_DealLookup] dlv ON dn.DayCountMethodId = dlv.LookupValueId
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
		ORDER BY dir.IpdDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'spGetCBNoteSummary'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


