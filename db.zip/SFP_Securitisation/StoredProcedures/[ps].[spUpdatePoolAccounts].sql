USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spUpdatePoolAccounts]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spUpdatePoolAccounts]
GO


CREATE PROCEDURE [ps].[spUpdatePoolAccounts]
 @pPoolId int,     
 @pFacilityIdList corp.CherryPickFacilityList READONLY,    
 @pUserName VARCHAR(50)    
AS    
BEGIN    
 BEGIN TRY    
      
  BEGIN TRAN    
      
	     IF OBJECT_ID('tempdb..#tmp1') IS NOT NULL    
    DROP TABLE #tmp1    
    
   SELECT distinct FacilityId    
   INTO #tmp1    
   FROM @pFacilityIdList where IsSelected = 0

	DELETE PS  
	FROM ps.PoolFacilityCherryPickState PS  where poolid = @pPoolId

   INSERT INTO ps.PoolFacilityCherryPickState (DealID, PoolID, FacilityID, CurrentIsActiveState, PoolInclusionReasonID, IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  
  Select f.DealId, @pPoolId, CASE WHEN f.FacilityId is NULL then t.FacilityId ELSE f.FacilityId END, 
  f.IsSelected, f.CurrentReasonId, CASE WHEN f.FacilityId is NULL then 0 ELSE 1 END , @pUserName, getdate(), @pUserName, getdate()
   FROM @pFacilityIdList f JOIN #tmp1 t on f.facilityId = t.facilityId

   -- Update IsActive value in PoolBuildDetail table    
   UPDATE PBD    
   SET IsActive = Case when F.FacilityId is null then 1 else 0 END   
   FROM ps.PoolBuildDetail PBD   
   Left Join #tmp1 F
    ON PBD.LoanId = F.FacilityId    
   WHERE PBD.PoolId = @pPoolId    
    
   DECLARE @NumOfAccount int    
   DECLARE @PoolBalance DECIMAL(19,2)    
   SELECT @NumOfAccount = COUNT(*), @PoolBalance = SUM(LoanBalance) FROM ps.PoolBuildDetail PBD
   LEFT JOIN (Select distinct poolId, FacilityID from ps.PoolFacilityCherryPickState where CurrentIsActiveState = 1) PCS ON PBD.LoanId = PCS.FacilityID
   AND PCS.PoolID = PBD.PoolId
   WHERE PBD.PoolId = @pPoolId AND (PBD.IsActive = 1 OR PCS.FacilityID IS NOT NULL)
   
   UPDATE ps.Pool    
   SET NumberOfAccount = @NumOfAccount,    
    CurrentPoolAmount = @PoolBalance    
   WHERE PoolId = @pPoolId    
   
    
  COMMIT TRAN    
 END TRY    
 BEGIN CATCH    
      
  ROLLBACK TRAN    
      
  DECLARE     
   @errorMessage     NVARCHAR(MAX),    
   @errorSeverity    INT,    
   @errorNumber      INT,    
   @errorLine        INT,    
   @errorState       INT;    
  SELECT     
   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()    
    
  EXEC app.SaveErrorLog 2, 1, 'spUpdatePoolAccounts', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName    
        
  RAISERROR (@errorMessage,    
             @errorSeverity,    
             @errorState )    
 END CATCH    
END
GO