USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[corp].[GetFacilityDataCorrectionList]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [corp].[GetFacilityDataCorrectionList]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/**********************************************************************************************************************************
Author:			Neeraj Jindal
Create Date:	11-May-2022
Description:	Stored proc to get Facility columns which user wants to override.
Update Date:	
Usage:  
DECLARE @RowID VARCHAR(50)		
EXEC [corp].[GetFacilityDataCorrectionList] '10-May-2022', 1, 1,null,'Europa\racfid'
				
**********************************************************************************************************************************/

CREATE PROCEDURE [corp].[GetFacilityDataCorrectionList]
(
	@pDate DATE,
	@pDealId INT,
	@pEntityId INT,
	@pFsId VARCHAR(20) = NULL,
	@pUserName VARCHAR(20)
)
AS
BEGIN
	BEGIN TRY		
		IF OBJECT_ID('tempdb.dbo.#AttributeList', 'U') IS NOT NULL
			DROP TABLE #AttributeList;
		IF OBJECT_ID('tempdb.dbo.#PivotedOriginalUpdatedData', 'U') IS NOT NULL
			DROP TABLE #PivotedOrigionalUpdatedData;
		IF OBJECT_ID('tempdb.dbo.#PivotedOriginalData', 'U') IS NOT NULL
			DROP TABLE #PivotedOrigionalData;
		IF OBJECT_ID('tempdb.dbo.#PivotedCorrectedData', 'U') IS NOT NULL
			DROP TABLE #PivotedCorrectedData;		
		
		SELECT DISTINCT
			 ffac.FacilityId
			,ffac.CisCode
			,dsec.SecurityId
			,dfac.FirstInterestMargin
			,dfac.InterestCharge
			,dfac.LtvOverride
			,dfac.DevelopmentLtcOverride
			,dfac.DevelopmentLtcValue
			,dfac.FacilityTypeCode
			,dfac.InterestBasis
			,dfac.InterestBasisCode
			,dfac.CostCentre
			,dfac.FacilityCurrencyCode
			,dfac.FacilitySourceCode			

		INTO #AttributeList
		FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] ffac
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimFacility] dfac	
			ON dfac.FacilityKey = ffac.FacilityKey
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_BridgeFacilitySecurity] bfs
			ON bfs.FacilitySecurityGroupKey = ffac.FacilitySecurityGroupKey
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_DimSecurity] dsec
			ON dsec.SecurityKey = bfs.SecurityKey 
		INNER JOIN [corp].[syn_SfpModelCorporate_vw_DealToFacilityMapping] deal
			ON CONVERT(VARCHAR, deal.FacilityId) = ffac.FacilityId
		WHERE deal.DealId = @pDealId
		AND ffac.PartitionId =  CONVERT(VARCHAR, CONVERT(DATETIME, @pDate), 112)				
		AND (ISNULL(@pFsId,'') = '' OR @pFsId = IIF(@pEntityId=1, ffac.FacilityId, CONVERT(VARCHAR, dsec.SecurityId)))
		
		-- Pivot Original data into #PivotedOriginalData	
		SELECT 
			 FacilityId			
			,MAX(FirstInterestMargin) AS FirstInterestMargin
			,MAX(InterestCharge) AS InterestCharge
			,MAX(LtvOverride) AS LtvOverride
			,MAX(DevelopmentLtcOverride) AS DevelopmentLtcOverride
			,MAX(DevelopmentLtcValue) AS DevelopmentLtcValue
			,MAX(FacilityTypeCode) AS FacilityTypeCode
			,MAX(InterestBasis) AS InterestBasis
			,MAX(InterestBasisCode) AS InterestBasisCode
			,MAX(CostCentre)AS CostCentre
			,MAX(FacilityCurrencyCode) AS FacilityCurrencyCode
			,MAX(FacilitySourceCode) AS FacilitySourceCode
			,MAX(CisCode) AS CisCode						
			,STUFF((SELECT DISTINCT ', ' + CAST(SecurityId AS VARCHAR(10)) [text()]
				    FROM #AttributeList 
					WHERE FacilityId = t.FacilityId
					FOR XML PATH(''), TYPE).value('.','NVARCHAR(MAX)'),1,2,' ') SecurityId

		INTO #PivotedOriginalData
		FROM #AttributeList t		
		GROUP BY FacilityId
		

		-- Copy data to #PivotedOriginalUpdatedData where we update it with overrided value later
		SELECT * INTO #PivotedOriginalUpdatedData FROM #PivotedOriginalData

		-- Get Corrected data and Pivot into #PivotedCorrectedData	
		SELECT * INTO #PivotedCorrectedData FROM
		(
			SELECT 
				 ddcd.FacilitySecurityId				
				,attr.AttributeName	
				,ddcd.Value	
			FROM [corp].[DealDataCorrectionDetail] ddcd
			INNER JOIN [corp].[DealDataCorrection] ddc
				ON ddc.dealdatacorrectionid = ddcd.dealdatacorrectionid
			INNER JOIN [corp].[DealDataCorrectionAttribute] attr
				ON attr.DealDataCorrectionAttributeId = ddcd.AttributeId AND attr.IsActive = 1
				AND ddc.AsAtDate = @pDate
		)pvt
		PIVOT 
		(
			MAX(pvt.Value)
			FOR AttributeName IN
			(
				FirstInterestMargin
				,InterestCharge
				,LtvOverride
				,DevelopmentLtcOverride
				,DevelopmentLtcValue
				,FacilityTypeCode
				,InterestBasis
				,InterestBasisCode
				,CostCentre
				,FacilityCurrencyCode
				,FacilitySourceCode
				,CisCode
			)
		)pvtDataCorrection
		
		-- Update and return final result
		UPDATE orig 		
		SET 
			 orig.FirstInterestMargin = ISNULL(corr.FirstInterestMargin, orig.FirstInterestMargin)
			,orig.InterestCharge = ISNULL(corr.InterestCharge, orig.InterestCharge)
			,orig.LtvOverride = ISNULL(corr.LtvOverride, orig.LtvOverride)			
			,orig.DevelopmentLtcOverride = ISNULL(corr.DevelopmentLtcOverride, orig.DevelopmentLtcOverride)
			,orig.DevelopmentLtcValue = ISNULL(corr.DevelopmentLtcValue, orig.DevelopmentLtcValue)
			,orig.FacilityTypeCode = NULLIF(ISNULL(corr.FacilityTypeCode, orig.FacilityTypeCode), '')
			,orig.InterestBasis = NULLIF(ISNULL(corr.InterestBasis, orig.InterestBasis), '')
			,orig.InterestBasisCode = NULLIF(ISNULL(corr.InterestBasisCode, orig.InterestBasisCode), '')
			,orig.CostCentre = NULLIF(ISNULL(corr.CostCentre, orig.CostCentre), '')
			,orig.FacilityCurrencyCode = NULLIF(ISNULL(corr.FacilityCurrencyCode, orig.FacilityCurrencyCode), '')
			,orig.FacilitySourceCode = NULLIF(ISNULL(corr.FacilitySourceCode, orig.FacilitySourceCode), '')
			,orig.CisCode = NULLIF(ISNULL(corr.CisCode, orig.CisCode), '')			
		FROM #PivotedOriginalUpdatedData orig
		INNER JOIN #PivotedCorrectedData corr
			ON orig.FacilityId = CONVERT(VARCHAR,corr.FacilitySecurityId)
		
		SELECT * FROM #PivotedOriginalUpdatedData ORDER BY FacilityId ASC  --Overirded Data
		SELECT * FROM #PivotedOriginalData ORDER BY FacilityId ASC  -- Original Data

END TRY
	BEGIN CATCH	                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'GetFacilityDataCorrectionList', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName                    
                      
		RAISERROR (@errorMessage, @errorSeverity, @errorState)
	END CATCH
END

GO