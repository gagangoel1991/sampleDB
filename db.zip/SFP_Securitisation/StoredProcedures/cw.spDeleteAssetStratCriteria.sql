USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spDeleteAssetStratCriteria') IS NOT NULL
	DROP PROC  cw.spDeleteAssetStratCriteria
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spDeleteAssetStratCriteria
@pStratId int,
@pModifiedBy varchar(80)='System',
@pReturnCode int =0 output  ,
@pReportTypeName VARCHAR(50) = ''
AS  
BEGIN  

 BEGIN TRY  
    
  DECLARE @ReportTypeId INT;
  SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
  SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 
  DELETE FROM [cfgCW].IR_AssetStratCriteria WHERE AssetStratFieldMapId = (SELECT AssetStratId FROM [cfgCW].IR_AssetStrat WHERE StratId=@pStratId AND ReportTypeId = @ReportTypeId)  
  
  SET @pReturnCode=1
  
  RETURN @pReturnCode;
   
 END TRY  
  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2, 1, 'spDeleteAssetStratCriteria', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pModifiedBy  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
  
END  
GO
