USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetConcentrationFields]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetConcentrationFields]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [ps].[spGetConcentrationFields]
(    
	@pType VARCHAR(50) = '<All>',
	@pAssetClassId INT = 1,
	@pUserName VARCHAR(50)
)      
AS      
BEGIN      
	BEGIN TRY      
      
		DECLARE @DataType VARCHAR(50)      
		IF @pType = '<All>'      
		SET @DataType = '%'      
		ELSE      
		SET @DataType =  '%' + @pType+  '%'      
        
		SELECT tblField.EligibilityCriteriaFieldId AS [Value],      
			   tblField.CriteriaFieldName AS [Title],   
			   tblType.[Type],		
			   tblField.CriteriaFieldSql AS [Description],                  
			   tblField.ReferenceLookup,      
			   CASE WHEN tblStatus.Status = 'Authorised' THEN 'True' ELSE 'False' END AS [IsAuthorised]      
                     
		FROM       
			[ps].[EligibilityCriteriaField] tblField                    
		INNER JOIN       
			[ps].[FieldDataType] tblType                    
			ON tblField.FieldDataType=tblType.FieldDataTypeId      
		INNER JOIN       
			[ps].[FieldStatus] tblStatus      
			ON tblField.FieldStatusId = tblStatus.FieldStatusId        
		WHERE 
			tblType.Type LIKE  @DataType      
			AND tblField.IsActive = 1
			AND tblField.AssetClassId = @pAssetClassId
		ORDER BY
			tblField.CriteriaFieldName;      
              
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetConcentrationFields', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''                    
                      
		RAISERROR (@errorMessage,                    
					@errorSeverity,                    
					@errorState )                    
	END CATCH      
END
GO