USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[app].[spSetFileWorkflowState]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [app].[spSetFileWorkflowState]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spSetFileWorkflowState]
(	
	@pUserName VARCHAR(50),
	@pFileInfoId INT,
	@pFileStaus VARCHAR(20)
)      
AS      
BEGIN      
	BEGIN TRY        	
		DECLARE @NewStatusId INT; 
		DECLARE @IsAuthRequired BIT = (SELECT [AuthWorkflowRequired] FROM [app].[FileInfo] where [FileInfoId] = @pFileInfoId);
		IF @pFileStaus = 'FAILED' OR  @pFileStaus = 'FAIL'
		BEGIN			
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'FAILED' ;

			UPDATE app.FileUploadDetail
			SET FileWorkflowStatusId = @NewStatusId
			WHERE FileInfoId = @pFileInfoId
				AND FileWorkflowStatusId IN 
				(SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE STATUSNAME NOT IN ('CANCELLED', 'INMODEL'))			
		END
	ELSE
	IF @pFileStaus = 'START' -- Upload
		BEGIN
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'CANCELLED' ;
			
			UPDATE app.FileUploadDetail
			SET FileWorkflowStatusId = @NewStatusId
			WHERE FileInfoId = @pFileInfoId
			AND (InModelDate IS NULL
			AND  FileWorkflowStatusId NOT IN (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'FAILED'));

			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INITIAL';
			
			-- TRUNCATE TABLE
			INSERT INTO 
				 app.FileUploadDetail(
			     [FileInfoId]
				,[FileWorkflowStatusId]
				,[AuthorizedBy]
				,[AuthorizedDate]
				,[IsActive]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate]
				,[InModelDate]
				)
			VALUES 
				(
				 @pFileInfoId
				,@NewStatusId
				,NULL 
				,NULL
				,1
				,NULL
				,NULL
				,NULL
				,NULL
				,NULL				
				);
		END;
	ELSE
	IF @pFileStaus = 'QUEUE' -- Upload
		BEGIN
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'CANCELLED' ;
			
			UPDATE app.FileUploadDetail
			SET FileWorkflowStatusId = @NewStatusId
			WHERE FileInfoId = @pFileInfoId
			AND (InModelDate IS NULL
			AND  FileWorkflowStatusId NOT IN (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'FAILED'));

			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'QUEUED';		
			
			-- TRUNCATE TABLE
			INSERT INTO 
				 app.FileUploadDetail(
			     [FileInfoId]
				,[FileWorkflowStatusId]
				,[AuthorizedBy]
				,[AuthorizedDate]
				,[IsActive]
				,[CreatedBy]
				,[CreatedDate]
				,[ModifiedBy]
				,[ModifiedDate]
				,[InModelDate]
				)
			VALUES 
				(
				 @pFileInfoId
				,@NewStatusId
				,NULL 
				,NULL
				,1
				,@pUserName
				,GETUTCDATE()
				,NULL
				,NULL
				,NULL			
				);			
			
		END
	ELSE
	IF @pFileStaus = 'LOAD' 
		BEGIN			

			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INSTAGING';
			-- check how to pass same user name from etl
			UPDATE [app].[FileUploadDetail]
			SET  
				[FileWorkflowStatusId]= @NewStatusId				
			WHERE 
				FileInfoId = @pFileInfoId
				AND
				FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'QUEUED')
			-- When Authentication is not required 
			-- System should auto send file authorisation and auto approved authentication
			IF @IsAuthRequired = 0
			BEGIN 
			  SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING';
			  UPDATE [app].[FileUploadDetail]
			  SET  
			  	[FileWorkflowStatusId]= @NewStatusId,
			  	[ModifiedBy] = 'System',
			  	[ModifiedDate] = GETUTCDATE()
			  WHERE 
			  	FileInfoId = @pFileInfoId
			  	AND
			  	FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INSTAGING')	
			  END 
			  
			  SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING-PUBLISH';
			  UPDATE [app].[FileUploadDetail]
			  SET  [AuthorizedBy] = 'System'
			  	,[AuthorizedDate] = GetUTCDate()
			  	,[FileWorkflowStatusId]= @NewStatusId
			  WHERE 
			  	FileInfoId = @pFileInfoId				
			  	AND
			  	FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING');
			  
			  SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INMODEL';
			  UPDATE [app].[FileUploadDetail]
			  SET FileWorkflowStatusId= @NewStatusId,
			  	[InModelDate] = GetUTCDate()
			  WHERE 
			  	FileInfoId = @pFileInfoId				
			  	AND
			  	FileWorkflowStatusId  IN (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName  IN ('AUTHORISED','AWAITING-PUBLISH'));
		END

	ELSE	
	IF @pFileStaus = 'LOAD-ERROR' 
		BEGIN
			--If There is any validation error then set the StatusName as 'INSTAGING-ERROR' 
			--so that the authorization can not be requested.			
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INSTAGING-ERROR';

			UPDATE [app].[FileUploadDetail]
			SET  
				[FileWorkflowStatusId]= @NewStatusId
			WHERE 
				FileInfoId = @pFileInfoId
				AND
				FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'QUEUED')			
		END
	ELSE	
	IF @pFileStaus = 'REQUEST' -- request auth
		BEGIN
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING';

			UPDATE [app].[FileUploadDetail]
			SET  
				[FileWorkflowStatusId]= @NewStatusId,
				[ModifiedBy] = @pUserName,
				[ModifiedDate] = GETUTCDATE()
			WHERE 
				FileInfoId = @pFileInfoId
				AND
				FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INSTAGING')	
		END	
	ELSE
	IF @pFileStaus = 'AUTHORISE'  
		BEGIN
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING-PUBLISH';

			UPDATE [app].[FileUploadDetail]
			SET  [AuthorizedBy] = @pUserName
				,[AuthorizedDate] = GetUTCDate()
				,[FileWorkflowStatusId]= @NewStatusId
			WHERE 
				FileInfoId = @pFileInfoId				
				AND
				FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING');

			DECLARE @FileInfoName NVARCHAR(100)
			DECLARE @IsProcedureBasedFeed BIT = 0;
			DECLARE @AsAtDate DATE;
			DECLARE @HasException BIT;

			SELECT @FileInfoName = FileName
			FROM [app].[FileInfo] WHERE fileinfoid = @pFileInfoId;

			IF(@FileInfoName = 'Encumbrance')
			BEGIN
				EXEC [sfp].[syn_SfpModel_spBuild_EncumbranceData]; 
				SET @IsProcedureBasedFeed = 1;
			END
			ELSE IF(@FileInfoName = 'Enforcement')
			BEGIN

				SELECT @AsAtDate = GETUTCDATE();
				EXEC [sfp].[syn_SfpModel_spBuild_Dim_Enforcement] @AsAtDate,@HasException OUT;
				SET @IsProcedureBasedFeed = 1;
			END
			ELSE IF(@FileInfoName = 'ONS')
			BEGIN
				EXEC [sfp].[syn_SfpModel_spBuild_Ref_ONSPriceIndex];
				SET @IsProcedureBasedFeed = 1;
			END
			ELSE IF(@FileInfoName = 'LAU File' OR @FileInfoName = 'NUTS File')
			BEGIN
				EXEC sfp.syn_SfpModel_spBuild_ONSPDLAUNUTS;
				SET @IsProcedureBasedFeed = 1;
			END
			IF (@IsProcedureBasedFeed = 1)
			BEGIN

			       SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INMODEL';

					UPDATE [app].[FileUploadDetail]
					SET  [AuthorizedBy] = @pUserName
						,[InModelDate] = GetUTCDate()
						,[FileWorkflowStatusId]= @NewStatusId
					WHERE 
						FileInfoId = @pFileInfoId				
						AND
						FileWorkflowStatusId = (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'AWAITING-PUBLISH');

			END

			
			


		END
	ELSE
	IF @pFileStaus = 'PUBLISH' -- there may be a delay in between authorisation and in ref/model
		BEGIN			
			SELECT @NewStatusId = FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName = 'INMODEL';

			UPDATE [app].[FileUploadDetail]
			SET FileWorkflowStatusId= @NewStatusId,
				[InModelDate] = GetUTCDate()
			WHERE 
				FileInfoId = @pFileInfoId				
				AND
				FileWorkflowStatusId  IN (SELECT FileWorkflowStatusId FROM app.FileWorkflowStatus WHERE StatusName  IN ('AUTHORISED','AWAITING-PUBLISH'));
		END;
			
	END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;                    
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spSetFileWorkflowState', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO
