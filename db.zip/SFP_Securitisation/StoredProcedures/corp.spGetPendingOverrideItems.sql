USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'corp.spGetPendingOverrideItems') AND type in (N'P', N'PC'))
	DROP PROCEDURE corp.spGetPendingOverrideItems
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE corp.spGetPendingOverrideItems
(
	@pCallFromOverrideAuth INT = 0,
	@pId INT,
	@pReturnIds VARCHAR(500) OUTPUT
)
AS
BEGIN
		SELECT @pReturnIds = ''
		DECLARE @Entity_FacilityId INT = (SELECT DealDataCorrectionEntityId FROM CORP.DealDataCorrectionEntity WHERE EntityName = 'Facility')

		-- WHILE AUTHORIZING OVERRIDE
		-- CHECK IF ANY POOL WITH 'SUBMITTED' STATUS AND HAS FACILITIES WHICH ARE IN CURRENT OVERRIDE
		IF(@pCallFromOverrideAuth = 1)
		BEGIN 
			SELECT DDCD.FacilitySecurityId AS FacilityId, DOP.AsAtDate
			INTO #OverrideFacilities 
			FROM [corp].[DealOverrideParent] DOP 
			INNER JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId
			INNER JOIN [corp].[DealDataCorrectionDetail] DDCD ON DDC.DealDataCorrectionId = DDCD.DealDataCorrectionId
			WHERE EntityTypeId = @Entity_FacilityId 
				  AND DOP.DealOverrideParentId = @pId 

				
			DECLARE @VintageDate DATE = (SELECT AsAtDate FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @pId )
			DECLARE @PoolStatusId INT = (SELECT PoolStatusId FROM PS.PoolStatus WHERE STATUS = 'Submitted')
			SELECT DISTINCT pl.PoolId 
			INTO #PendingPools 
			FROM PS.Pool pl 
			INNER JOIN PS.PoolBuilddetail ppd ON pl.PoolId = ppd.PoolId
			-- INNER JOIN #OverrideFacilities OvrFac ON OvrFac.FacilityId = ppd.LoanId AND OvrFac.AsAtDate = PL.VintageDate
			WHERE pl.PoolStatusId = @PoolStatusId AND pl.VintageDate = @VintageDate
				 AND EXISTS (SELECT 1 FROM #OverrideFacilities OvrFac WHERE OvrFac.FacilityId = ppd.LoanId) 

			--SELECT * FROM #OverrideFacilities
			--SELECT * FROM #PendingPools

			IF EXISTS(SELECT 1 FROM #PendingPools)
			BEGIN
				SELECT @pReturnIds = @pReturnIds +','+ CONVERT(VARCHAR(5),PoolId) FROM #PendingPools
				SELECT @pReturnIds = SUBSTRING(@pReturnIds, 2, LEN(@pReturnIds))
			END 

		END
			 -- WHILE AUTHORIZING POOL
		ELSE -- CHECK IF ANY OVERRIDE WITH 'SUBMITTED' STATUS AND HAS FACILITIES WHICH ARE IN CURRENT POOLS
		BEGIN

			DECLARE @DealDataCorrectionStatusId INT = (SELECT DealDataCorrectionStatusId FROM CORP.[DealDataCorrectionStatus] WHERE STATUS = 'Submitted')
			
			SELECT ppd.LoanId AS FacilityId, pl.VintageDate as AsAtDate
			INTO #PoolFacilities 
			FROM PS.PoolBuilddetail ppd
			INNER JOIN PS.Pool pl ON pl.PoolId = ppd.PoolId
			WHERE pl.PoolId = @pId  

			SELECT DISTINCT deal.DealName + ' (' + FORMAT ( DOP.AsAtDate, 'MMM yyyy') + ')' AS DealIds
			INTO #PendingOverrideFacilities 
			FROM [corp].[DealOverrideParent] DOP 
			INNER JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId
			INNER JOIN [corp].[DealDataCorrectionDetail] DDCD ON DDC.DealDataCorrectionId = DDCD.DealDataCorrectionId
			INNER JOIN #PoolFacilities PolFac ON PolFac.FacilityId = DDCD.FacilitySecurityId AND PolFac.AsAtDate = DOP.AsAtDate
			INNER JOIN [corp].[vwActiveDeal] deal ON deal.AssetClassDealId = DOP.DealId
			WHERE DDC.EntityTypeId = @Entity_FacilityId 
				  AND DOP.DataCorrectionStatus = @DealDataCorrectionStatusId  

			IF EXISTS(SELECT 1 FROM #PendingOverrideFacilities)
			BEGIN
				SELECT @pReturnIds = @pReturnIds +','+ DealIds FROM #PendingOverrideFacilities
				SELECT @pReturnIds = SUBSTRING(@pReturnIds, 2, LEN(@pReturnIds))
			END 
		END
END

GO
--DECLARE @pReturnIds VARCHAR(500)
--EXEC corp.spGetPendingOverrideItems 0,'573', @pReturnIds OUT
----EXEC corp.spGetPendingOverrideItems 1,'15', @pReturnIds OUT
----EXEC corp.spGetPendingOverrideItems 1,'11', @pReturnIds OUT
--SELECT @pReturnIds 