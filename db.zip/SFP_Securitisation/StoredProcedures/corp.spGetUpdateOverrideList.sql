USE SFP_Securitisation
GO

IF OBJECT_ID('[corp].[spGetUpdateOverrideList]') IS NOT NULL
	DROP PROCEDURE corp.[spGetUpdateOverrideList]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--================================================
-- Author: Saurabh Bhatia
-- Date:	17-Aug-2022
-- Description:  To get Update Override List
-- Exec [corp].[spGetUpdateOverrideList]  'europa\bhasaaa', '31 MAY 2022' , 1
-- Exec [corp].[spGetUpdateOverrideList]  'europa\bhasaaa', '30 JUN 2022' , 1
--================================================
CREATE PROCEDURE [corp].[spGetUpdateOverrideList]
	@pUserName VARCHAR(50),
	@pAsAtDate DATE = NULL,
	@pDealId INT = 0
AS
BEGIN

	BEGIN TRY

	 DECLARE @DealTypeId INT = (SELECT LookupValueId FROM [cfgCW].[DealLookupValue] WHERE [Name] = 'SRT')  
	 SELECT @pDealId = NULLIF(@pDealId,0)  
	 DECLARE @LastAuthVintageDate DATE  
	 DECLARE @AuthorizedStatusId INT  
  
	 IF OBJECT_ID('tempdb..#TmpLatestDealCrctnData') IS NOT NULL DROP TABLE #TmpLatestDealCrctnData  
  
		SELECT *   
		INTO #TmpLatestDealCrctnData  
		FROM   
		(   
		 SELECT   
		   ROW_NUMBER() OVER(PARTITION BY DOP.DealId ORDER BY DDC.ModifiedDate DESC) as Rn    
		  ,DOP.DealId   
		  ,DOP.AsAtDate         
		  ,DOP.ModifiedBy   
		  ,DOP.ModifiedDate
		  ,DOP.CreatedBy
		  ,STS.Status as OverrideStatus
		  ,DOP.AuthorizedBy
		  ,DOP.AuthorizedDate
		  ,DOP.DealOverrideParentId
		 FROM [corp].[DealOverrideParent] DOP
		 INNER JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId
		 INNER JOIN [corp].[DealDataCorrectionStatus] STS ON DOP.DataCorrectionStatus = STS.DealDataCorrectionStatusId
		 WHERE DOP.AsAtDate = ISNULL(@pAsAtDate,DOP.AsAtDate) AND DOP.IsActive = 1   
		) AS X   
	  WHERE Rn = 1; 

	  SELECT * INTO #TmpLatestAuthData
	  FROM       
	  (       
	   SELECT       
		 ROW_NUMBER() OVER(PARTITION BY DOP.DealId ORDER BY DOP.ModifiedDate DESC) as Rn        
		,DOP.DealId       
		,DOP.AsAtDate             
		,DOP.ModifiedBy       
		,DOP.ModifiedDate    
		,DOP.CreatedBy    
		,STS.Status as OverrideStatus    
		,DOP.AuthorizedBy    
		,DOP.AuthorizedDate
		,LastOvrd.ModifiedDate LATEST, DOP.ModifiedDate AUTH_MODIFIED 
		,DOP.DealOverrideParentId
	   FROM [corp].[DealOverrideParent] DOP    
	   INNER JOIN [corp].[DealDataCorrection] DDC ON DOP.DealOverrideParentId = DDC.DealOverrideParentId    
	   INNER JOIN [corp].[DealDataCorrectionStatus] STS ON DOP.DataCorrectionStatus = STS.DealDataCorrectionStatusId 
	   INNER JOIN #TmpLatestDealCrctnData LastOvrd ON DOP.DealId = LastOvrd.DealId --AND LastOvrd.AsAtDate > DOP.AsAtDate --LastOvrd.ModifiedDate > DOP.ModifiedDate  
	   WHERE DOP.AsAtDate = ISNULL(@pAsAtDate,DOP.AsAtDate) AND DOP.IsActive = 1 AND [status] = 'Authorised'    
	  ) AS X       
	  WHERE Rn = 1; 

		--select * from #TmpLatestDealCrctnData
		--return

	 -- used inside the details page, being called with DealID and Date
	 DECLARE @LA_ParentId INT 
	 SELECT @AuthorizedStatusId = DealDataCorrectionStatusId FROM Corp.DealDataCorrectionStatus WHERE [STATUS] = 'Authorised'  
	 SELECT @LA_ParentId = MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent] WHERE IsActive = 1 AND DealId = @pDealId AND DataCorrectionStatus = @AuthorizedStatusId 
	 SELECT @LastAuthVintageDate = AsAtDate FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @LA_ParentId 
	 SELECT @LastAuthVintageDate = ISNULL(@LastAuthVintageDate, '31-AUG-2022')
 


	 --TAKE LAST ACTION 
	 DECLARE @LastActionBy VARCHAR(50) = '', @LastActionDate DATE, @LastStatusID INT
	 IF (@pDealId IS NOT NULL AND @pAsAtDate IS NOT NULL)
	 BEGIN
		DECLARE @MaxDealOverrideParentId INT = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent]   
												WHERE AsAtDate = @pAsAtDate AND DealId = @pDealId) 
		SELECT @LastStatusID = DataCorrectionStatus, @LastActionBy = ModifiedBy, @LastActionDate = ModifiedDate 
		FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @MaxDealOverrideParentId 
		DECLARE @LastStatus VARCHAR(30) = (SELECT TOP 1 [STATUS] FROM Corp.DealDataCorrectionStatus WHERE DealDataCorrectionStatusId = @LastStatusID)
		IF(@LastStatus != 'DRAFT' AND @MaxDealOverrideParentId > 0)
		BEGIN
			SELECT TOP 1 @LastActionBy=ActionedBy,  @LastActionDate = ActionedDate 
			FROM [CW].WorkflowProcess 
			WHERE WorkflowStepId IN (
										SELECT WorkflowStepId FROM [cfgCW].WorkflowStep 
										WHERE WorkflowTypeId =(SELECT WorkflowTypeId FROM [cfgCW].WorkflowType where [name] = 'DealDataCorrection')
									) AND ProcessReferenceId = @MaxDealOverrideParentId 
			ORDER BY WorkflowProcessId Desc
		END
	 END
 

   DECLARE @isFacilityDownloadAvailable INT = 0, @isSecurityDownloadAvailable INT = 0, @isLinkagesAvailable INT = 0, @DraftStatusId INT = 0, @OtherDraftAvailableMonth VARCHAR(10)
   DECLARE @Last_ParentId INT = 0, @CurrentStatusId INT = 0
   SELECT @Last_ParentId = MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent] WHERE IsActive = 1 AND DealId = @pDealId AND  AsAtDate = @pAsAtDate
   SELECT @CurrentStatusId = DataCorrectionStatus FROM [corp].[DealOverrideParent] WHERE DealOverrideParentId = @Last_ParentId
   --select @Last_ParentId,@CurrentStatusId, @DraftStatusId

    SELECT TOP 1 @OtherDraftAvailableMonth = format(DOP.AsAtDate , 'MMM yyyy')
    FROM [corp].[DealOverrideParent] DOP
    INNER JOIN [corp].[DealDataCorrectionStatus] STS ON DOP.DataCorrectionStatus = STS.DealDataCorrectionStatusId AND DOP.AsAtDate != @pAsAtDate AND DOP.IsActive = 1 
	AND STS.[STATUS]  = 'DRAFT' AND DealId = @pDealId

   IF (@CurrentStatusId IN (SELECT DealDataCorrectionStatusId FROM Corp.DealDataCorrectionStatus WHERE [STATUS] IN ('DRAFT', 'Recalled', 'Rejected','Submitted') ))
   BEGIN
		SELECT @isFacilityDownloadAvailable = COUNT(*) FROM [corp].[DealDataCorrectionDetail] 
		WHERE DealDataCorrectionId = (SELECT DealDataCorrectionId FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @Last_ParentId 
			 AND EntityTypeId = (SELECT DealDataCorrectionEntityId FROM [corp].DealDataCorrectionEntity WHERE EntityName = 'Facility'))

		SELECT @isSecurityDownloadAvailable = COUNT(*) FROM [corp].[DealDataCorrectionDetail] 
		WHERE DealDataCorrectionId = (SELECT DealDataCorrectionId FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @Last_ParentId 
			  AND EntityTypeId = (SELECT DealDataCorrectionEntityId FROM [corp].DealDataCorrectionEntity WHERE EntityName = 'Security'))

		SELECT @isLinkagesAvailable = COUNT(*) FROM [corp].[DealDataCorrectionLinkage] 
		WHERE DealDataCorrectionId = (SELECT DealDataCorrectionId FROM [corp].[DealDataCorrection] WHERE DealOverrideParentId = @Last_ParentId 
			  AND EntityTypeId = (SELECT DealDataCorrectionEntityId FROM [corp].DealDataCorrectionEntity WHERE EntityName = 'Relinking'))
   END


	 Select   
	  AssetClassDealId as DealId  
	 ,DealName   
	 , ISNULL(Auth.OverrideStatus, dcd.OverrideStatus) as [Status] -- Need to Changes after cfgCW.WorkflowStep entry  
	 , dcd.ModifiedBy as OverrideBy  --  
	 , dcd.ModifiedDate AS OverrideDate  --  
	 , ISNULL(Auth.AuthorizedBy, dcd.AuthorizedBy) AS  AuthorisedBy    
	 , ISNULL(Auth.AuthorizedDate, dcd.AuthorizedDate) AS AuthorisedDate    
	 --, dcd.AsAtDate AS CurrentOverrideVintageDate    
	  , CASE WHEN dcd.DealOverrideParentId = LastOvr.DealOverrideParentId THEN NULL ELSE dcd.AsAtDate END CurrentOverrideVintageDate
	 , LastOvr.AsAtDate AS LastOverrideVintageDate  
	 , @LastAuthVintageDate AS LastAuthVintageDate
	 , Auth.DealOverrideParentId
	 , Auth.DataCorrectionStatus StatusId
	 , dcd.CreatedBy
	 , @LastActionBy AS LastActionBy
	 , @LastActionDate AS LastActionDate
	 , CASE WHEN @isFacilityDownloadAvailable = 0 THEN 0 ELSE 1 END IsFacilityDownloadAvailable
	 , CASE WHEN @isSecurityDownloadAvailable = 0 THEN 0 ELSE 1 END IsSecurityDownloadAvailable
	 , CASE WHEN @isLinkagesAvailable = 0 THEN 0 ELSE 1 END IsLinkagesAvailable
	 , @OtherDraftAvailableMonth AS 'OtherDraftAvailableMonth'
	 FROM [corp].[vwActiveDeal] ActDeal  
	  LEFT JOIN #TmpLatestDealCrctnData dcd   ON ActDeal.AssetClassDealId =  dcd.DealId     
	   LEFT JOIN #TmpLatestAuthData LastOvr   ON ActDeal.AssetClassDealId =  LastOvr.DealId      
	  LEFT JOIN (    
		SELECT DOP.DealOverrideParentId, DataCorrectionStatus, STS.[Status] as OverrideStatus  , AuthorizedBy, AuthorizedDate, DOP.DealId    
		FROM [corp].[DealOverrideParent] DOP    
		INNER JOIN [corp].[DealDataCorrectionStatus] STS ON DOP.DataCorrectionStatus = STS.DealDataCorrectionStatusId    
		WHERE DealOverrideParentId = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent] WHERE DealId = @pDealId AND AsAtDate = @pAsAtDate)    
		) Auth ON ActDeal.AssetClassDealId = Auth.DealId     
     
	 WHERE DealTypeId = @DealTypeId AND ActDeal.AssetClassDealId = ISNULL(@pDealId,ActDeal.AssetClassDealId)  

END TRY
	
	BEGIN CATCH

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION SFP_Sec_SaveAdhocReportTemplate
		END

		EXEC app.SaveErrorLog 2, 1, 'spGetUpdateOverrideList', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
End

GO

--Exec [corp].[spGetUpdateOverrideList]  'europa\logasll', '2022-08-31' , 1
--Exec [corp].[spGetUpdateOverrideList] 'europa\logasll', null , 0