USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spICT12MonthForwardCalculation]') IS NOT NULL
	DROP PROCEDURE [cb].[spICT12MonthForwardCalculation]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cb].[spICT12MonthForwardCalculation]
/*
 * Author: Kapil Sharma
 * Date:	10.02.2022
 * Description:  This will RUN the ICT 12 MONTHS forward calculation
 * 
 * Example - 
 * [cb].[spICT12MonthForwardCalculation] 34, 'System'	
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE
			@dealId					INT,
			@testTypeId				INT,
			@collectionStartDt		DATE,
			@collectionEndDt		DATE,
			@dealIpdId				INT,
			@ipdDate				DATE,
			@lineItemCode			VARCHAR(200),
			@netAnnualReceipts		DECIMAL(20, 8),
			@netAnnualCBSwapNotPay	DECIMAL(20, 8),
			@headroom				DECIMAL(20, 2),
			@thresholdValue			DECIMAL(10, 3),
			@testResult				VARCHAR(40),
			@createdBy				VARCHAR(80) = 'System',
			@createdDate			DATETIME = GETDATE()

		IF EXISTS(SELECT TOP 1* FROM cb.DealNote_Wf WHERE DealIpdRunId = @pDealIpdRunId)
		BEGIN
			SELECT @dealId = di.DealId, 
				@collectionStartDt = did.CollectionBusinessStart, 
				@collectionEndDt = did.CollectionBusinessEnd,
				@dealIpdId = di.DealIpdId, @ipdDate = di.IpdDate
			FROM cw.DealIpd di
			JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
			JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
			WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1
			PRINT @collectionEndDt
			DECLARE @tblTestLineItemValue TABLE(TestLineItemId INT, LineItemCode VARCHAR(200), LineItemValue VARCHAR(100))
		
			SELECT @testTypeId = TestTypeID FROM cfgcb.TestType WHERE InternalName = 'ICT12MonthsForwardTest'

			----*****Net Receipts----------------

			--Calculate Net Annual Receipts
			SET @lineItemCode = 'ICT12Months_NetAnnualReceipts'
			SELECT 
				@netAnnualReceipts = SUM(ISNULL(NetInterestRateSwap, 0))
			FROM 
				[cb].[ForwardPoolData]
			WHERE 
				DealIpdRunId = @pDealIpdRunId
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @netAnnualReceipts)

			--Calculate Net Annual Covered Bond Swap and Note Payment
			SELECT @netAnnualCBSwapNotPay = SUM(CASE WHEN dn.IsSwapLinked = 1 THEN nsWF.PayRate * dnWF.PrincipalOutstanding_GBP ELSE dnWF.RateForEstimation*dnWF.PrincipalOutstanding_GBP END)
			FROM cfgcb.DealNote dn
			JOIN cb.DealNote_Wf dnWF ON dnWF.DealNoteId = dn.DealNoteId 
			LEFT JOIN cfgcb.NoteSwap ns ON dn.DealNoteId = ns.DealNoteId AND ns.ValidTo>=@collectionEndDt
			LEFT JOIN cb.NoteSwap_Wf nsWF ON nsWF.NoteSwapId = ns.NoteSwapId AND nsWF.DealIpdRunId = dnWF.DealIpdRunId
			WHERE dnWF.DealIpdRunId = @pDealIpdRunId
			SET @lineItemCode = 'ICT12Months_NetAnnualCBSwap_NotePayment'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @netAnnualCBSwapNotPay)

			-----***********ICT12Months_Ratio-------------------------------------------------
			SET @lineItemCode = 'ICT12Months_Ratio'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST((@netAnnualReceipts/@netAnnualCBSwapNotPay*100) AS DECIMAL(10,4)) AS VARCHAR(10)) + '%')


			-----***********Headroom-------------------------------------------------
			SET @lineItemCode = 'ICT12Months_Headroom'
			SET @headroom = ((@netAnnualReceipts - @netAnnualCBSwapNotPay)/@netAnnualCBSwapNotPay)*100;
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@headroom AS VARCHAR(40)) + '%')

			SET @lineItemCode = 'ICT12Months_Threshold'
			SELECT @thresholdValue = CAST([Value] AS DECIMAL(10,2)) FROM [CW].[vw_DealLookup] WHERE TypeCode = 'Deimos_Test_Config' AND [Name] = 'ICT_Threshold'
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@thresholdValue AS VARCHAR(12)) + '%')


			-----***********Result-------------------------------------------------
			SET @lineItemCode = 'ICT12Months_Result'
			SET @testResult = CASE WHEN @headroom>@thresholdValue THEN 'PASS' ELSE 'FAILED' END
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, @testResult)

			--------Now insert the test line item into the main table

			--First update the TestLineItemId in the table variable
			UPDATE tbl SET tbl.TestLineItemId = tli.TestLineItemId
			FROM  @tblTestLineItemValue tbl
			JOIN cfgcb.TestLineItem tli ON tli.InternalName = tbl.LineItemCode
			JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
			WHERE tt.TestTypeID = @testTypeId

			--Now merge the line item values into main table
			MERGE cb.TestLineItemValue AS trg
			USING @tblTestLineItemValue AS src
			ON src.TestLineItemId = trg.TestLineItemId AND trg.DealIpdrunId = @pDealIpdRunId
			WHEN NOT MATCHED BY Target THEN
				INSERT (TestLineItemID, DealIpdRunId, [Value], IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES (src.TestLineItemId, @pDealIpdRunId, src.LineItemValue, 1, @createdBy, @createdDate, @createdBy, @createdDate)
			WHEN MATCHED THEN UPDATE SET
				trg.[Value]	= src.LineItemValue;

			---Save the test result 
			EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeId, @testResult, @pUserName
		END
		ELSE
		BEGIN
			PRINT 'Cashwaterfall is not run yet so spICT12MonthForwardCalculation cannot be run'
		END
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spICT12MonthForwardCalculation', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
