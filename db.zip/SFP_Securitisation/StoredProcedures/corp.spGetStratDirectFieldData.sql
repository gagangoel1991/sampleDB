USE [SFP_Securitisation]
GO

IF  EXISTS 
(
	SELECT 1 FROM sys.objects 
	WHERE object_id = OBJECT_ID(N'[corp].[spGetStratDirectFieldData]') 
	AND TYPE IN (N'P', N'PC')
)
	DROP PROCEDURE [corp].[spGetStratDirectFieldData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 16-March-2023
Description    : This will return direct field strat data for Investor report for Corporate Asset Class
Execution      : EXEC corp.spGetStratDirectFieldData @pAsAtDate  ='30-Nov-2022'
							,@pDealName  = 'Atlas'  
							,@pFieldName = 'SecurityFlag'
							,@pUserName = 'EUROPA\aggaadi'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE corp.spGetStratDirectFieldData
	@pAsAtDate DATE,
	@pDealName VARCHAR(255) = NULL,
	@pFieldName varchar(255) = NULL,
	@pStratRangeData  AS [cw].[udtStratRangeConfig] READONLY,
	@pUserName VARCHAR(50) = NULL,
	@pAssetClassId INT = 2
AS
BEGIN
	BEGIN TRY

	DECLARE @DealId INT =  (SELECT TOP(1)
								AssetClassDealId
							FROM [corp].[vwActiveDeal]
							WHERE DealName = @pDealName)
	DECLARE @EligibilityCriteriaFieldId INT
	DECLARE @CriteriaFieldSql VARCHAR(MAX)
	DECLARE @FieldDataType VARCHAR(20)
	DECLARE @FieldType VARCHAR(20)
	DECLARE @SourceFieldsUsed VARCHAR(100)
	DECLARE @ReqCols XML 
	DECLARE @RowID VARCHAR (100) 
	DECLARE @FacilityCount INT
	DECLARE @TotalRONA FLOAT
	DECLARE @TotalRONAPercent FLOAT
	DECLARE @TotalVolumePercent FLOAT
	DECLARE @SQLQuery NVARCHAR(MAX)
	DECLARE @Parameters NVARCHAR(MAX)
	DECLARE @MaxRowCount INT = (SELECT COUNT(1) FROM @pStratRangeData)

	/* DROP TEMPORARY TABLES */
	IF OBJECT_ID('tempdb..#SourceFields') IS NOT NULL
		DROP TABLE #SourceFields
	IF OBJECT_ID('tempdb..#StratData') IS NOT NULL
		DROP TABLE #StratData
	IF OBJECT_ID('tempdb..#FinalData') IS NOT NULL
		DROP TABLE #FinalData
	

	/* CREATE TEMPORARY TABLES */
	CREATE TABLE #SourceFields
	(
		FieldId INT
	)
	
	CREATE TABLE #StratData
	(
		FacilityId INT,
		RONA FLOAT,
		Field NVARCHAR(1000)
	)

	CREATE TABLE #FinalData
	(
		FieldName VARCHAR(255),
		Exposure FLOAT,
		ExposurePercent FLOAT,
		LoanVolume INT,
		LoanVolumePercent FLOAT,
		SortOrder INT
	)

	SELECT
		@EligibilityCriteriaFieldId = EligibilityCriteriaFieldId
		, @CriteriaFieldSql = Field.CriteriaFieldSql
		, @FieldDataType = LookUp.Name
		, @FieldType = FieldType.TypeName
		, @SourceFieldsUsed = Field.SourceFieldsUsed
	FROM ps.EligibilityCriteriaField Field
		INNER JOIN cfgCW.IR_AssetField IrField ON IrField.FieldDescription = Field.CriteriaFieldName AND IrField.AssetClassId = Field.AssetClassId
		INNER JOIN cfgCW.DealLookupValue LookUp ON IrField.FieldDataType = LookUp.LookupValueId
		INNER JOIN ps.FieldType FieldType ON FieldType.FieldTypeId = Field.FieldType
	WHERE IrField.FieldName = @pFieldName AND Field.AssetClassId = @pAssetClassId AND IrField.IsActive = 1 AND Field.IsActive = 1


	IF @FieldType = 'Custom'
	BEGIN
		SET @CriteriaFieldSql  = REPLACE(REPLACE(@CriteriaFieldSql, '(', '( '), ')', ' )');
		SET @CriteriaFieldSql  = REPLACE(@CriteriaFieldSql, ',', ' , ');
		SET @CriteriaFieldSql  = REPLACE(REPLACE(@CriteriaFieldSql, '[', '[ '), ']', ' ]');

		INSERT #SourceFields
		SELECT CONVERT(INT,Value) AS FieldId
		FROM [app].[udfSplitString](@SourceFieldsUsed, ',')

		SELECT @CriteriaFieldSql  = [ps].[fn_ReplaceWholeWord](@CriteriaFieldSql, Field.CriteriaFieldName, Field.CriteriaFieldSql)
		FROM #SourceFields sourceField
		INNER JOIN ps.EligibilityCriteriaField Field ON Field.EligibilityCriteriaFieldId = sourceField.FieldId


		SET @CriteriaFieldSql  = REPLACE(REPLACE(@CriteriaFieldSql, '( ', '('), ' )', ')');
		SET @CriteriaFieldSql  = REPLACE(@CriteriaFieldSql, ' , ', ',');
		SET @CriteriaFieldSql  = REPLACE(REPLACE(@CriteriaFieldSql, '[ ', '['), ' ]', ']');
	END
	ELSE
	BEGIN
		INSERT #SourceFields
		SELECT @EligibilityCriteriaFieldId AS FieldId
	END

	/* INSERT MANDATORY COLUMN NAMES */
	INSERT #SourceFields
	SELECT EligibilityCriteriaFieldId AS FieldId
	FROM ps.EligibilityCriteriaField
	WHERE CriteriaFieldSql IN ('FacilityId', 'RONA') AND AssetClassID = @pAssetClassId AND IsActive = 1
    
	
	/* CONVERT REQUIRED COLUMN NAMES TO XML FORMAT */
	SELECT @ReqCols = (SELECT DISTINCT
			Field.CriteriaFieldSql AS CriteriaFieldName, Field.FieldDataType
		FROM #SourceFields sourceField
			INNER JOIN ps.EligibilityCriteriaField Field ON Field.EligibilityCriteriaFieldId = sourceField.FieldId
		FOR XML PATH('Node'), ROOT('Root'))  
	
	/* EXECUTE COMMON SP TO FETCH THE DATA  */

	PRINT 'Common SP Execution Started : ' + CONVERT(VARCHAR(20), GETDATE())

	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
			@VintageDate = @pAsAtDate,
			@DealKey	 = @DealId,
			@FacilityIds = NULL,
			@ReqColumns	 = @ReqCols,
			@OutputRowID = @RowID OUTPUT

	PRINT 'Common SP Execution Ended : ' + CONVERT(VARCHAR(20), GETDATE())
	
	SET @Parameters= N'@pStratRangeData [cw].[udtStratRangeConfig] ReadOnly, @pRowID VARCHAR (100)' 
	IF @FieldDataType = 'Text' OR @FieldDataType = 'Reference' OR @FieldDataType = 'Bool'
	BEGIN
		SET @SQLQuery = 'INSERT #StratData
						 SELECT DISTINCT
							FacilityId,
							RONA,
							' + @CriteriaFieldSql + ' AS Field
						 FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @pRowID'
	END
	ELSE IF @FieldDataType = 'Numeric'
	BEGIN
		SET @SQLQuery = 'INSERT #StratData
						 SELECT DISTINCT
							FacilityId,
							RONA,
							CW.fnGetStratConfigGroupName(@pStratRangeData, IIF(ISNUMERIC(' + @CriteriaFieldSql + ') = 0, ''0.00'', ' + @CriteriaFieldSql + ' )) AS Field
						 FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @pRowID'
	END
	
	PRINT (@SQLQuery)
	EXEC sp_executesql @sqlQuery, @Parameters, @pStratRangeData = @pStratRangeData, @pRowID = @RowId

	/* DELETE DATA FROM STAGING TABLE AFTER USE */
	DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID
	
	SELECT @FacilityCount = COUNT(ISNULL(FacilityId, 0))  
		  , @TotalRONA = SUM(ISNULL(RONA, 0))
	FROM #StratData

	INSERT INTO #FinalData
	SELECT
		Field AS [FieldName]
		, SUM(ISNULL(RONA, 0)) AS [Exposure]
		, IIF(@TotalRONA > 0, SUM(ISNULL(RONA, 0)) / @TotalRONA, 0) AS [ExposurePercent]  
		, COUNT(ISNULL(FacilityId, 0)) AS [LoanVolume] 
		, IIF(@FacilityCount > 0, CONVERT(FLOAT, COUNT(ISNULL(FacilityId, 0))) / @FacilityCount, 0) AS [LoanVolumePercent]
		, ROW_NUMBER() OVER(ORDER BY [Field] ASC) AS [SortOrder]
	FROM #StratData stratData
	WHERE (Field <> '' AND @FieldDataType = 'Numeric') OR @FieldDataType <> 'Numeric'
	GROUP BY [Field]

	SELECT
		@TotalRONA = SUM(Exposure),
		@TotalRONAPercent = SUM(ExposurePercent),
		@FacilityCount = SUM(LoanVolume),
		@TotalVolumePercent = SUM(LoanVolumePercent),
		@MaxRowCount = IIF (MAX(SortOrder) > @MaxRowCount, MAX(SortOrder), @MaxRowCount)
	FROM  #FinalData

	INSERT INTO #FinalData
	SELECT
		'Total' AS [FieldName]
		, @TotalRONA AS [Exposure]
		, @TotalRONAPercent AS [ExposurePercent]
		, @FacilityCount AS [LoanVolume]
		, @TotalVolumePercent AS [LoanVolumePercent]
		, @MaxRowCount + 1 AS [SortOrder]
	
	IF @FieldDataType = 'Text' OR @FieldDataType = 'Reference' OR @FieldDataType = 'Bool'
	BEGIN
		SELECT
			FieldName,
			Exposure,
			ExposurePercent,
			LoanVolume,
			LoanVolumePercent
		FROM #FinalData
		ORDER BY SortOrder
	END
	ELSE IF @FieldDataType = 'Numeric'
	BEGIN
		SELECT
			ISNULL(stratRange.DisplayName, stratData.FieldName) AS FieldName,
			Exposure,
			ExposurePercent,
			LoanVolume,
			LoanVolumePercent
		FROM #FinalData stratData
		FULL OUTER JOIN @pStratRangeData stratRange ON stratRange.DisplayName = stratData.FieldName
		ORDER BY ISNULL(stratRange.SortOrder, stratData.SortOrder)
	END
	
END TRY
BEGIN CATCH
    DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

	DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

    SELECT
		@errorMessage = ERROR_MESSAGE()
		, @errorSeverity = ERROR_SEVERITY()
		, @errorNumber = ERROR_NUMBER()
		, @errorLine = ERROR_LINE()
		, @errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'corp.spGetStratDirectFieldData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH

END

GO
