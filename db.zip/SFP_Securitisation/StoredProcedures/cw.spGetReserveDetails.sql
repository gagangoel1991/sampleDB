USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetReserveDetails]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetReserveDetails] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: GUNJAN CHANDOLA  
--Date: 27-04-2021 
--Description: GET sub loan details 
--(PRE and Post)
--[cw].[spGetReserveDetails] 14,2,''
--==================================   
CREATE PROCEDURE [cw].[spGetReserveDetails] 
   @pDealId   INT,    
   @pIPDRunId INT, 
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
	BEGIN TRY   
	  
		SELECT 
			drf.ReserveFundTypeId, 
			CONVERT(VARCHAR(10),ipd.IpdDate,103) AS IPDDate,
			drf.DisplayName, 
			rpre.ReserveFund_bF AS ReserveFund_bf,
			rpre.ReserveFundRequiredAmount AS RequiredReserveFund,
			rpre.ReserveFundDueAmount AS ReserveFundDue,
			rpre.ReserveResidualAmount AS ReserveResidualAmount,
			rpost.DrawingsInPeriod,
			rpost.CreditReceived,
			rpost.ReserveFund_cf
		FROM 
			cfgcw.DealReserveFund drf
		JOIN 
			cw.reservefund_prewf rpre ON drf.DealReserveFundId = rpre.ReserveFundId
		JOIN 
			cfgCW.DealLookupValue dlv ON drf.ReserveFundTypeId=dlv.LookupValueId 
		JOIN  
			cw.dealipdrun dir ON dir.RunId=rpre.DealipdRunid 
		JOIN 
			cw.DealIpd ipd ON dir.DealIpdId=ipd.DealIpdId
		LEFT JOIN  
			cw.reservefund_postwf rpost ON  rpre.DealipdRunid=rpost.DealipdRunid 
			AND rpre.ReserveFundId = rpost.ReserveFundId AND drf.DealReserveFundId=rpost.ReserveFundId
		WHERE  
			dir.RunId IN(SELECT RunId FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId,4))
		ORDER BY ipd.IpdDate DESC      
    
	END TRY  
	BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spGetReserveDetails', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
					@errorState )  
	END CATCH  
END
GO