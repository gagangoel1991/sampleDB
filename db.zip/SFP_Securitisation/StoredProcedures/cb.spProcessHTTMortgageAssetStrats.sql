USE [SFP_Securitisation]
GO
GO
IF OBJECT_ID('cb.spProcessHTTMortgageAssetStrats') IS NOT NULL
	DROP PROCEDURE cb.spProcessHTTMortgageAssetStrats
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cb.spProcessHTTMortgageAssetStrats 
(
@pAsAtDate datetime, 
@pDealName  varchar(200),
@pStratName varchar(200),
@pUserName	VARCHAR(80) = NULL

)
/* 
 *   Author: Arun 
 *   Date:  22.04.2022
 *   Description:  Get HTT report Mortgage Asset data
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */ 
AS 
  BEGIN 
	 BEGIN TRY 
     
	 DECLARE @TotalCapitalBalance float
	 DECLARE @TotalLoanCount INT

	  IF( Object_id('tempdb..#Tbl') IS NOT NULL ) 
        DROP TABLE #temp 
	
	  CREATE TABLE #Tbl (LineItem varchar(max), Value float)
	  
	
		IF @pStratName ='HTT M.A Property Type'
		BEGIN
			
			INSERT INTO #Tbl(LineItem, Value)
			EXEC sfp.syn_SfpModel_sp_rpt_spMortgageCharacterstics_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT [cb].[fnGetNumberInMillion](Value) AS CapitalBalance FROM #Tbl WHERE LineItem='TotalLoanBalance'
		END
		ELSE IF @pStratName ='HTT M.A General Info'
		BEGIN
			INSERT INTO #Tbl(LineItem, Value)
			EXEC sfp.syn_SfpModel_sp_rpt_spMortgageCharacterstics_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT [Value] FROM #Tbl WHERE LineItem='NumberOfloansInPool'
		END
		ELSE IF @pStratName ='HTT M.A Concentration Risk'
		BEGIN
			INSERT INTO #Tbl(LineItem, Value)
			EXEC sfp.syn_SfpModel_sp_rpt_spMortgageCharacterstics_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT [Value]/100 FROM #Tbl WHERE LineItem='BorrowersConcentration'
		END
		ELSE IF @pStratName ='HTT M.A Average NonIndexed-LTV'
		BEGIN
			INSERT INTO #Tbl(LineItem, Value)
			EXEC sfp.syn_SfpModel_sp_rpt_spMortgageCharacterstics_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT [Value]/100 FROM #Tbl WHERE LineItem='WeightedAverageNonIndexLTV'
		END
		ELSE IF @pStratName ='HTT M.A Average LTV'
		BEGIN
			INSERT INTO #Tbl(LineItem, Value)
			EXEC sfp.syn_SfpModel_sp_rpt_spMortgageCharacterstics_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT [Value]/100 FROM #Tbl WHERE LineItem='WeightedAverageIndexLTV'
		END
		ELSE IF @pStratName ='HTT M.A Region Breakdown'
		BEGIN
			CREATE TABLE #TblRegion (SortOrder INT, Region varchar(max), LoanCount INT, LoanCountPercent float,  CapitalBalance float, CapitalBalancePercent float)
			INSERT INTO #TblRegion
			EXEC sfp.syn_SfpModel_sp_rpt_spRegional_Distribution_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT CapitalBalancePercent FROM #TblRegion 
		END
		ELSE IF @pStratName ='HTT M.A InterestRate Breakdown'
		BEGIN
			CREATE TABLE #TblIntrstRate (Rate varchar(max), LoanCount INT, LoanCountPercent float,  CapitalBalance float, CapitalBalancePercent float)
			INSERT INTO #TblIntrstRate
			EXEC sfp.syn_SfpModel_sp_rpt_spInterestPaymentType_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType = 'MOODYSAGGREGATED'

			SELECT CapitalBalancePercent, 0 AS ColName, NULL,CapitalBalancePercent AS CapitalBalancePercentTotal FROM #TblIntrstRate WHERE Rate='Fixed'
			UNION ALL
			SELECT SUM(CapitalBalancePercent), 0 AS ColName, NULL,sum(CapitalBalancePercent) FROM #TblIntrstRate WHERE Rate IN ('SVR', 'Tracker')
			UNION ALL
			SELECT CapitalBalancePercent, 0 AS ColName, NULL, CapitalBalancePercent FROM #TblIntrstRate WHERE Rate='Other'

		END
		ELSE IF @pStratName IN ('HTT M.A LoanType Breakdown' , 'HTT M.A NPL Loan', 'HTT M.A Average Loan Size')
		BEGIN
			CREATE TABLE #TblRepaymntType (Type varchar(max), CapitalBalancePercent float, CapitalBalancePercent1 float)
			INSERT INTO #TblRepaymntType
			EXEC sfp.syn_SfpModel_sp_rpt_spHTTMortgageAssets @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType = 'MOODYSAGGREGATED'

			IF @pStratName='HTT M.A LoanType Breakdown'
				SELECT CapitalBalancePercent, 0 AS ColName, NULL, CapitalBalancePercent1 FROM #TblRepaymntType 
				WHERE Type IN ('Bullet', 'Amortising', 'Other') 
			ELSE IF @pStratName='HTT M.A NPL Loan'
				SELECT CapitalBalancePercent, 0 AS ColName, NULL, CapitalBalancePercent1 FROM #TblRepaymntType 
				WHERE Type ='NPLs'
			ELSE IF @pStratName='HTT M.A Average Loan Size'
				SELECT CapitalBalancePercent, 0 AS ColName, NULL, CapitalBalancePercent1 FROM #TblRepaymntType 
				WHERE Type = 'AverageLoanSize'
		END
		

		ELSE IF @pStratName ='HTT M.A Sesoning'
		BEGIN
			CREATE TABLE #TblSeason (CapitalBalance1 float, CapitalBalance2 float, CapitalBalance3 float, CapitalBalance4 float, CapitalBalance5 float, CapitalBalance6 float, CapitalBalance7 float, CapitalBalance8 float, CapitalBalance9 float, CapitalBalance10 float, CapitalBalance11 float, CapitalBalance12 float)
			INSERT INTO #TblSeason
			EXEC sfp.syn_SfpModel_sp_rpt_spSeasoning_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType = 'MOODYSAGGREGATED'

			
			SELECT @TotalCapitalBalance = sum(CapitalBalance1) FROM #TblSeason

			SELECT CASE WHEN @TotalCapitalBalance >0 THEN CapitalBalance1/@TotalCapitalBalance ELSE 0 END AS CapitalBalancePercent
			, 0 AS ColName
			,NULL
			, CASE WHEN @TotalCapitalBalance >0 THEN CapitalBalance1/@TotalCapitalBalance ELSE 0 END AS CapitalBalancePercentTotal
			FROM #TblSeason

		END
		ELSE IF @pStratName ='HTT M.A Loan Size'
		BEGIN
			CREATE TABLE #TblLoanSize (SortOrder INT, LoanCount INT, LoanCountPercent float,  CapitalBalance float, CapitalBalancePercent float)
			INSERT INTO #TblLoanSize
			EXEC sfp.syn_SfpModel_sp_rpt_spCurrentOutstandingBalanceOfLoan_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType = 'MOODYSAGGREGATED'

			SELECT [cb].[fnGetNumberInMillion](CapitalBalance) AS CapitalBalance, LoanCount FROM #TblLoanSize 
		END
		ELSE IF @pStratName ='HTT M.A Type Breakdown'
		BEGIN
			CREATE TABLE #TblLoanType (SortOrder INT, LoanType varchar(max), LoanCount INT, LoanCountPercent float,  CapitalBalance float, CapitalBalancePercent float)
			INSERT INTO #TblLoanType
			EXEC sfp.syn_SfpModel_sp_rpt_LoanPurpose_Type_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName

			SELECT CapitalBalancePercent FROM #TblLoanType  WHERE LoanType='Owner Occupied'
			UNION ALL
			SELECT CapitalBalancePercent FROM #TblLoanType  WHERE LoanType='Second Home'
			UNION ALL
			SELECT CapitalBalancePercent FROM #TblLoanType  WHERE LoanType='Buy-to-Let'
			UNION ALL
			SELECT 0 
			UNION ALL
			SELECT 0 
			UNION ALL
			SELECT CapitalBalancePercent FROM #TblLoanType  WHERE LoanType='Right To Buy'
		END
		ELSE IF @pStratName ='HTT M.A Dwelling Type'
		BEGIN
			CREATE TABLE #TblDwellingType (CapitalBalance float, LoanCount INT)
			INSERT INTO #TblDwellingType
			EXEC sfp.syn_SfpModel_sp_rpt_spPropertyType @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType = 'MOODYSAGGREGATED'

			SELECT CapitalBalance, LoanCount FROM #TblDwellingType 
		END
		ELSE IF @pStratName ='HTT M.A NonIndexed-LTV'
		BEGIN
			
			CREATE TABLE #TblCrntNonIndexLtv (SortOrder INT, Range varchar(max), LoanCount INT, LoanCountPercent float,  CapitalBalance float, CapitalBalancePercent float)
			INSERT INTO #TblCrntNonIndexLtv
			EXEC sfp.syn_SfpModel_sp_rpt_spCurrentNonIndexedLTV_V1  @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType= 'HTT'

			CREATE TABLE #TblCrntNonIndexLtvRange (CapitalBalance float, LoanCount INT)
			INSERT INTO #TblCrntNonIndexLtvRange
			EXEC sfp.syn_SfpModel_sp_rpt_spUnIndexedLTVRangesDistribution_V1  @AsAtDate=@pAsAtDate, @DealName=@pDealName
			

			SET @TotalCapitalBalance = (SELECT sum(CapitalBalance) FROM #TblCrntNonIndexLtvRange)
			SET @TotalLoanCount = (SELECT sum(LoanCount) FROM #TblCrntNonIndexLtv WHERE SortOrder>1 )

			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range='Less than 40 %' 
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range='Over 40% - 50%' 
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range IN ('Over 50% - 55%', 'Over 55% - 60%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range IN ('Over 60% - 65%', 'Over 65% - 70%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range IN ('Over 70% - 75%', 'Over 75% - 80%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range IN ('Over 80% - 85%', 'Over 85% - 90%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range IN ('Over 90% - 95%', 'Over 95% -100%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntNonIndexLtv WHERE Range IN ('Over 100-105%', 'Over 105-110%', 'Over 110-125%', 'Over 125%')

		END
		ELSE IF @pStratName ='HTT M.A LTV'
		BEGIN
			
			CREATE TABLE #TblCrntIndexLtv (SortOrder INT, Range varchar(max), LoanCount INT, LoanCountPercent float,  CapitalBalance float, CapitalBalancePercent float)
			INSERT INTO #TblCrntIndexLtv
			EXEC sfp.syn_SfpModel_sp_rpt_spCurrentIndexedLTV_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName, @DealType= 'HTT'

			CREATE TABLE #TblCrntIndexLtvRange (CapitalBalance float, LoanCount INT)
			INSERT INTO #TblCrntIndexLtvRange
			EXEC [sfp].syn_SfpModel_sp_rpt_spIndexedLTVRangesDistribution_V1 @AsAtDate=@pAsAtDate, @DealName=@pDealName
			

			SET @TotalCapitalBalance = (SELECT sum(CapitalBalance) FROM #TblCrntIndexLtvRange)
			SET @TotalLoanCount = (SELECT sum(LoanCount) FROM #TblCrntIndexLtv WHERE SortOrder>1 )

			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range='<40%' 
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range='40-50%' 
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range IN ('50-55%', '55-60%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range IN ('60-65%', '65-70%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range IN ('70-75%', '75-80%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range IN ('80-85%', '85-90%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range IN ('90-95%', '95-100%')
			UNION ALL
			SELECT [cb].[fnGetNumberInMillion](SUM(CapitalBalance)) AS CapitalBalance, sum(LoanCount) AS LoanCount
			, NULL AS ColumnName
			, CASE WHEN @TotalCapitalBalance > 0 THEN SUM(CapitalBalance)/@TotalCapitalBalance ELSE 0.00 END AS CapitalBalancePercent
			FROM #TblCrntIndexLtv WHERE Range IN ('100-105%', '105-110%', '100-125%', '125+%')

		END
		ELSE
		BEGIN
			SELECT NULL--@pStratName + ' No Data'
		END

	END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cb.spProcessHTTMortgageAssetStrats', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH 
	  
 END 

 Go
