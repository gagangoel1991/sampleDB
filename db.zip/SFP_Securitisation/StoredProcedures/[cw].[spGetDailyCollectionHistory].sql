USE SFP_Securitisation

GO


IF OBJECT_ID('[cw].[spGetDailyCollectionHistory]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDailyCollectionHistory]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
/*  
Author: Arun  
Date:    30.08.2022  
Description:  This will return daily collection history for defined range.  
Usage : 
Declare @strings [cw].[utdStringList]
	Insert @strings ([StringList]) values ('FAB')
	Insert @strings ([StringList]) values ('UBR')

exec [cw].[spGetDailyCollectionHistory]  @pAsAtDate= '2022-05-01', @pAsAtToDate='2022-05-31', @pDealName='Dunmore1',  @pBrandList=@strings, @pUserName='kumavnb'

Change History  
--------------  
Author              Date                 Description  
-------------------------------------------------------  
*/  
CREATE PROCEDURE [cw].[spGetDailyCollectionHistory] 
   @pAsAtDate DATETIME = NULL
  ,@pAsAtToDate DATETIME = NULL
  ,@pDealName VARCHAR(255)
  ,@pBrandList [cw].[utdStringList] ReadOnly
  ,@pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
	BEGIN TRY  
   
  
		Select Convert(datetime, [BusinessDate], 103) as [BusinessDate]
		  ,[DealName]
		  ,[BrandID]
		  ,[OpeningTrueBalance]
		  ,[OpeningAccruedInterest]
		  ,[OpeningCustomerStatementBalanceDerived]
		  ,[ScheduledPrincipalReductions]
		  ,[PartialPrepayments]
		  ,[Overpayments]
		  ,[FullRedemptionPayments]
		  ,[FurtherStageAdvances]
		  ,[FeesChargedCapitalised]
		  ,[TrueCapitalBalance]
		  ,[CapitalBalanceInArrears]
		  ,[InterestReceived]
		  ,[InterestInArrears]
		  ,[FeesReceived]
		  ,[FeesInArrears]
		  ,[FinesReceived]
		  ,[FinesInArrears]
		  ,[OtherPrincipalMovements]
		  ,[TotalPrincipalReceipts]
		  ,[FeesandFinesReceived]
		  ,[TotalRevenueReceipts]
		  ,[TotalCashReceived]
		  ,[InterestCharged]
		  ,[FeesandFinesCharged]
		  ,[TotalBalanceMovements]
		  ,[ClosingTrueBalance]
		  ,[ClosingAccruedInterest]
		  ,[ClosingCustomerStatementBalanceDerived]
		  ,[ClosingTrueBalanceDerived]
		  ,[VarianceClosingTrueBalancevsClosingTrueBalanceDerived]
		  ,[PrevTrueBalance]
		  ,[PrevTrueCapitalBalance]
		  ,[PrevCapitalInArrears]
		  ,[PrevPrepayments]
		  ,[PrevTotalCapitalBalanceOutstanding]
		  ,[PrevFeesInArrears]
		  ,[PrevFinesInArrears]
		  ,[PrevInterestInArrears]
		  ,[PrevArrearsInsurance]
		  ,[PrevInterestEarnedNotApplied]
		  ,[PrevTrueInterestAfterWorkingCalendarDate]
		  ,[PrevControlBreak]
		  ,[CrntTrueBalance]
		  ,[CrntTrueCapitalBalance]
		  ,[CrntCapitalInArrears]
		  ,[CrntPrepayments]
		  ,[CrntTotalCapitalBalanceOutstanding]
		  ,[CrntFeesInArrears]
		  ,[CrntFinesInArrears]
		  ,[CrntInterestInArrears]
		  ,[CrntArrearsInsurance]
		  ,[CrntInterestEarnedNotApplied]
		  ,[CrntTrueInterestAfterWorkingCalendarDate]
		  ,[CrntControlBreak]
		  ,[PrincipalReceiptsDeflagged]
		  ,[RevenueReceiptsDeflagged]
		  ,[TotalDeflaggedBalance]
		  ,[PrincipalReceiptsTopup]
		  ,[RevenueReceiptsTopup]
		  ,[TotalTopupBalance]
		  ,[NetPrincipalReceiptsCurrentvspreviousBusinessDay]
		  ,[NetRevenueReceipts]
		  ,[OverallVariance]
		  ,[Variance]
		  ,[OverallControlBreak] 
		From 
		[CW].[DailyCollectionSummaryLevelData] dcsl
		INNER JOIN @pBrandList bl on bl.StringList = dcsl.BrandID
		Where   DealName=@pDealName
		and Convert(datetime, BusinessDate, 103) >= @pAsAtDate and   Convert(datetime, BusinessDate, 103) <= @pAsAtToDate
		Order by Convert(datetime, BusinessDate, 103) desc

	END TRY  
	BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionHistory', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH    	
END

GO

