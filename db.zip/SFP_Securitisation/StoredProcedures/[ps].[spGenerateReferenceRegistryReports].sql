USE SFP_Securitisation
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[ps].[spGenerateReferenceRegistryReports]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [ps].[spGenerateReferenceRegistryReports]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--EXEC [ps].[spGenerateReferenceRegistryReports] @pDealIrConfigId = 1045, @pUserName='logasll' , @pDealID = 1 , @pAsAtDate= '2023-01-31', @pTabType='Security' 
---Update Date:	21-Mar-2023 SFPT-14523 Pranali: Added the block to update 'AccountStatus','DefaultReason' with the Lookupvalue Description.
 
CREATE PROCEDURE [ps].[spGenerateReferenceRegistryReports]   
 @pDealIrConfigId INT = 0,   
 @pUserName VARCHAR(100),   
 @pAsAtDate Date = null,
 @pDealID INT,
 @IsDebug INT = 0,
 @pTabType VARCHAR(4000),
 @pPoolID INT = 0,
 @pOutputType VARCHAR(20) = ''
AS  
 BEGIN  
  BEGIN TRY 
   
   DECLARE @FieldSelectColumn VARCHAR(MAX) = '';  
   DECLARE @AddFieldsColumn VARCHAR(MAX) = '';  
   DECLARE @FieldSelectColumn_Security VARCHAR(MAX) = '';  
   DECLARE @AddFieldsColumn_Security VARCHAR(MAX) = '';  
   DECLARE @Active BIT = 1;  
   DECLARE @CustomFieldTypeId INT = (SELECT FieldTypeId FROM ps.FieldType WHERE TypeName = 'Custom');  
   
  
   DECLARE @Query NVARCHAR(MAX) = '' 
   DECLARE @Query_Security NVARCHAR(MAX) = ''; 
     
    
   IF OBJECT_ID('tempdb.dbo.#tempReportFields', 'U') IS NOT NULL                      
    DROP TABLE #tempReportFields;      
    
   IF OBJECT_ID('tempdb.dbo.#AccountKeys', 'U') IS NOT NULL                      
    DROP TABLE #AccountKeys    
	
	IF OBJECT_ID('tempdb.dbo.#AccountKeys_Security', 'U') IS NOT NULL                      
    DROP TABLE #AccountKeys_Security
    
   IF OBJECT_ID('tempdb.dbo.#tempCustomReportFields', 'U') IS NOT NULL    
    DROP TABLE #tempCustomReportFields    
    
   IF OBJECT_ID('tempdb.dbo.#CustomFieldUpdatedSQL', 'U') IS NOT NULL    
    DROP TABLE #CustomFieldUpdatedSQL    
    
   IF OBJECT_ID('tempdb.dbo.#CustomECFields', 'U') IS NOT NULL    
    DROP TABLE #CustomECFields    
       
   IF OBJECT_ID('tempdb.dbo.#tempWithCustomFieldsData', 'U') IS NOT NULL    
    DROP TABLE #tempWithCustomFieldsData    
    
   CREATE TABLE #AccountKeys                                  
   (      
		ID INT IDENTITY(1,1)
		--FacilityId BIGINT 
   );  
   
   CREATE TABLE #AccountKeys_Security                                  
   (    
		ID INT IDENTITY(1,1)
		--SecurityId BIGINT 
   );
     
   SELECT DISTINCT    
     field.EligibilityCriteriaFieldId,    
     field.CriteriaFieldTable,    
     field.FieldDataType,    
     field.FieldType,          
     field.CriteriaFieldName,     
     field.CriteriaFieldSql,      
     field.SourceFieldsUsed,    
  
     (CASE WHEN templateFields.EligibilityCriteriaFieldId IS NOT NULL THEN     
     templateFields.FieldOrderId END) AS FieldOrderId,    
  
     (CASE WHEN templateFields.EligibilityCriteriaFieldId IS NOT NULL THEN     
     templateFields.DisplayFieldName END) AS DisplayFieldName,     
     ROW_NUMBER() OVER (PARTITION BY field.EligibilityCriteriaFieldId ORDER BY field.EligibilityCriteriaFieldId) RowNumber ,    
     templateFields.AggregationTypeId,    
     templateFields.AggregationName AS OperatorName,
	 templateFields.FieldLevel
   INTO #tempReportFields    
   FROM ps.EligibilityCriteriaField field     
   LEFT  JOIN     
   (SELECT DISTINCT fieldMap.EligibilityCriteriaFieldId, fieldMap.FieldOrderId, fieldMap.DisplayFieldName,FL.FieldLevel, AggregationTypeId, Agrtn.AggregationName 
   ,RANK() OVER (PARTITION BY  fieldMap.DisplayFieldName, fieldMap.FieldLevelId  ORDER BY fieldMap.FieldOrderId) rnk
	  FROM ps.PoolAdhocReportFieldMap fieldMap
	  JOIN ps.EligibilityCriteriaField ec 
	  	ON fieldMap.EligibilityCriteriaFieldId = ec.EligibilityCriteriaFieldId
	  JOIN [cfgCW].[IR_DealIrStratMap]  smap 
	  	ON smap.StratId = fieldMap.StratId
	  JOIN ps.FieldLevel FL ON FL.FieldLevelId = fieldMap.FieldLevelId
           AND smap.DealIrConfigId = @pDealIrConfigId    
      LEFT JOIN [ps].[FieldAggregation] Agrtn 
	       ON Agrtn.AggregationId = fieldMap.AggregationTypeId 
		   AND Agrtn.IsActive = @Active	  )    
	 AS templateFields
	 	ON templateFields.EligibilityCriteriaFieldId = field.EligibilityCriteriaFieldId
	 WHERE (templateFields.EligibilityCriteriaFieldId IS NOT NULL)
	 	AND field.IsActive = @Active
		AND templateFields.rnk = 1
	 ORDER BY field.EligibilityCriteriaFieldId 
                  
   SELECT     
    ecf.EligibilityCriteriaFieldId,    
    ecf.CriteriaFieldSql,    
    sp.*,    
    ecfs.CriteriaFieldName 'Replace_From_Name',    
    ecfs.CriteriaFieldSQL 'Replace_TO_Name',     
    ROW_NUMBER() OVER (PARTITION BY ecf.EligibilityCriteriaFieldId ORDER BY ecfs.EligibilityCriteriaFieldId) RowNumber     
     INTO #tempCustomReportFields     
   FROM #tempReportFields ecf    
    CROSS APPLY [app].[udfSplitString](SourceFieldsUsed, ',') sp    
    INNER JOIN  ps.EligibilityCriteriaField ecfs    
     ON sp.value = ecfs.EligibilityCriteriaFieldId    
   WHERE ecf.FieldType = @CustomFieldTypeId    
  
       
   -- Replacing brackets and commas with leading and trailing space     
   -- so that it can be considered as a whole word for replacement    
   UPDATE #tempCustomReportFields    
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '(', '( '), ')', ' )');    
    
   UPDATE #tempCustomReportFields    
   SET CriteriaFieldSql  = replace(CriteriaFieldSql, ',', ' , ');    
    
   UPDATE #tempCustomReportFields    
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '[', '[ '), ']', ' ]');    
    
   ;WITH UpdatedEligibilitySQLf(RowID,EligibilityCriteriaFieldId, Expression)                                  
   AS                                  
   (                        
    SELECT RowNumber,                       
     EligibilityCriteriaFieldId,                                  
     Expression = [ps].[fn_ReplaceWholeWord](replace(replace(CriteriaFieldSql, '[', ''), ']', ''), Replace_From_Name, '[' + Replace_TO_Name  + ']')    
    FROM #tempCustomReportFields WHERE RowNumber = 1                                                        
 UNION ALL                                                                                              
    SELECT RowNumber,                       
     t.EligibilityCriteriaFieldId,           
     Expression = [ps].[fn_ReplaceWholeWord](replace(replace(c.Expression, '[', ''), ']', ''), Replace_From_Name, '[' + Replace_TO_Name + ']')                            
    FROM UpdatedEligibilitySQLf c                          
     INNER JOIN #tempCustomReportFields t ON t.EligibilityCriteriaFieldId = c.EligibilityCriteriaFieldId                          
    WHERE RowNumber = RowID + 1                          
   )       
     
   SELECT EligibilityCriteriaFieldId,                       
   Expression As FinalExpression      
   INTO #CustomFieldUpdatedSQL    
   FROM UpdatedEligibilitySQLf                                                
   WHERE RowID IN                                                 
   (                                                
    SELECT MAX(RowID) AS RowID       
    FROM UpdatedEligibilitySQLf tbl       
    WHERE UpdatedEligibilitySQLf.EligibilityCriteriaFieldId = tbl.EligibilityCriteriaFieldId                                                                                          
   )      
   GROUP BY RowID, EligibilityCriteriaFieldId, Expression                                             
   ORDER BY EligibilityCriteriaFieldId       
    
   UPDATE te    
   SET te.CriteriaFieldSQL = cf.FinalExpression    
   FROM #tempReportFields te    
    INNER JOIN #CustomFieldUpdatedSQL cf    
   ON te.EligibilityCriteriaFieldId = cf.EligibilityCriteriaFieldId    
       
   /*fetch custom fields with base columns names as comma seperated in single row*/    
   DECLARE @fields VARCHAR(MAX)    
   SELECT @fields =   ISNULL(@fields+', ','') + t.SourceFieldsUsed    
   FROM (SELECT DISTINCT SourceFieldsUsed FROM #tempReportFields WHERE SourceFieldsUsed IS NOT NULL ) t    
       
   /*Now split custom fields list into a temp tabel in multiple rows*/    
   SELECT CONVERT(INT,Value) AS fieldId INTO #CustomECFields FROM [app].[udfSplitString](@fields,',')         
       
   /*Added CriteriaFieldName in temp table for both custom and non custom fields*/    
   SELECT DISTINCT CriteriaFieldSql, CriteriaFieldTable, FieldDataType    
   INTO #tempWithCustomFieldsData     
   FROM (    
     SELECT CriteriaFieldSql, CriteriaFieldTable, FieldDataType   
  FROM ps.EligibilityCriteriaField WHERE EligibilityCriteriaFieldId in (SELECT fieldId FROM #CustomECFields) AND IsActive = 1    
     )x  
   UNION     
    SELECT DISTINCT CriteriaFieldSql, CriteriaFieldTable, FieldDataType FROM #tempReportFields WHERE SourceFieldsUsed IS NULL       
    
   /*Mandatory Eligibility Criteria Fields Which are exposed on UI as well */    
  ------ UNION     
  ------  SELECT CriteriaFieldSql, CriteriaFieldTable, FieldDataType  
  ------FROM ps.EligibilityCriteriaField WHERE CriteriaFieldSql IN ('LOAN_IDENTIFIER','OUTSTANDNG_CAPITAL_BALANCE_AMT','TRUE_BALANCE_AMT')    
    

   -- Reverting square brackets to its previous state so that sql can evaluate expression value within brackets.    
   UPDATE #tempReportFields    
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '( ', '('), ' )', ')');    
    
   UPDATE #tempReportFields    
   SET CriteriaFieldSql  = replace(CriteriaFieldSql, ' , ', ',');        
        
   UPDATE #tempReportFields    
   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '[ ', '['), ' ]', ']');    
   
   DECLARE @ReqCols XML = NULL  
   DECLARE @RowID Varchar(100)   
   DECLARE @XmlData XML = NULL     
   ------SELECT @XmlData = ( SELECT fmsa.MortgageAccountKey, fmsa.MortgageSubAccountKey     
   ------     FROM sfp.syn_SfpModel_vw_FactMortgageSubAccountEntity fmsa WITH (NOLOCK)     
   ------     INNER JOIN sfp.syn_SfpModel_vw_MortgageAccountEntity ma WITH (NOLOCK)    
   ------      ON fmsa.MortgageAccountKey = ma.MortgageAccountKey     
   ------     INNER JOIN (    
   ------        SELECT DISTINCT LoanId     
   ------        FROM ps.PoolBuildDetail pld                 
   ------         WHERE pld.poolId = @pPoolID     
   ------        ) ln               
   ------      ON ln.LoanId = ma.LoanId             
   ------     WHERE fmsa.PartitionId = @PartitionKey          
   ------     FOR XML PATH('Node'), ROOT('Root')    
   ------     )  
          
	INSERT INTO #tempWithCustomFieldsData
	SELECT 'FacilitySourceId','Facility',2 
	UNION SELECT 'FacilitySourceId','Facility',2 
	UNION SELECT 'SecurityUniqueId','Facility',2
	UNION SELECT 'CradleSecurityID','Facility',2
	UNION SELECT 'SecurityKey','Security',2

   SELECT @ReqCols = ( SELECT DISTINCT '['+CriteriaFieldSql+']' AS CriteriaFieldName, FieldDataType  FROM #tempWithCustomFieldsData FOR XML PATH('Node'), ROOT('Root'))

   --   SP NAME : SFP_MODEL_CORPORATE.[rpt].[uspCommercialFacilityEntity]
   IF(ISNULL(@pPoolID,0) > 0)
   BEGIN
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]   
		  @VintageDate = @pAsAtDate,  
		  @DealKey  = NULL,  
		  @FacilityIds = NULL,  
		  @ReqColumns  = @ReqCols,  
		  @CanIncludeOverrideLinkages = 1,
		  @poolId = @pPoolID,
		  @OutputRowID = @RowID OUTPUT 
   END
   ELSE
   BEGIN
		   --   SP NAME : SFP_MODEL_CORPORATE.[rpt].[uspCommercialFacilityEntity]  
		   EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]  
		  @VintageDate = @pAsAtDate,  
		  @DealKey  = @pDealID,  
		  @FacilityIds = NULL,  
		  @ReqColumns  = @ReqCols,  
		  @CanIncludeOverrideLinkages = 1,
		  @OutputRowID = @RowID OUTPUT
   END
		 

   PRINT 'Query Execution Started : ' + convert(varchar(20),getdate())
   IF EXISTS(Select 1 from #tempReportFields)        
   BEGIN
		--FOR FACILITY
		IF EXISTS(SELECT 1 FROM #tempReportFields WHERE CriteriaFieldSql IN ('AccountStatus','DefaultReason'))
		BEGIN
			/*Updating Staging table data with LookUpValueDescription using report lookup table*/
			UPDATE stg  SET stg.AccountStatus = ISNULL(RefAccStatus.LookUpValueDescription, stg.AccountStatus)
			FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] stg
		    LEFT JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 RefAccStatus ON RefAccStatus.LookUpValue = stg.AccountStatus AND RefAccStatus.Lookupname = 'AccountStatus'
			WHERE stg.RowId =  @RowID AND EXISTS(SELECT 1 FROM #tempReportFields WHERE CriteriaFieldSql = 'AccountStatus')

			UPDATE stg  SET stg.DefaultReason = ISNULL(RefDefaultReason.LookUpValueDescription, stg.DefaultReason)
			FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] stg
		    LEFT JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 RefDefaultReason ON RefDefaultReason.LookUpValue = stg.DefaultReason AND RefDefaultReason.Lookupname = 'ReasonforDefaultorForeclosure'
			WHERE stg.RowId =  @RowID AND EXISTS(SELECT 1 FROM #tempReportFields WHERE CriteriaFieldSql = 'DefaultReason')
		END

		 SELECT @FieldSelectColumn = @FieldSelectColumn + 
		 (CASE WHEN FieldType = 2 
		 THEN  CriteriaFieldSql + ' AS ''' + CAST(DisplayFieldName AS VARCHAR(100))+ ''' , '
		ELSE '['+ CriteriaFieldSql + '] AS '''  + CAST(DisplayFieldName AS VARCHAR(100)) + ''', ' END )           
     FROM #tempReportFields WHERE FieldLevel = 'Facility' ORDER BY FieldOrderId ASC 


		--SET @FieldSelectColumn = ','+ @FieldSelectColumn   
		SET @FieldSelectColumn = @FieldSelectColumn

		--Alter #AccountKeys Table to add Fields as columns        
		SET @AddFieldsColumn  = 'ALTER Table #AccountKeys ADD  '        
		SELECT @AddFieldsColumn = @AddFieldsColumn +  '[' + CAST(DisplayFieldName AS VARCHAR(100))  + '] VARCHAR(MAX), ' 
			From #tempReportFields  WHERE FieldLevel = 'Facility'      
			ORDER BY FieldOrderId ASC        
		SET @AddFieldsColumn = (SUBSTRING(@AddFieldsColumn, 0, LEN(@AddFieldsColumn))) 

		EXEC (@AddFieldsColumn)
    
		SET @QUERY= 'Insert into #AccountKeys                                        
			SELECT DISTINCT '+ SUBSTRING(@FieldSelectColumn, 0, LEN(@FieldSelectColumn))+'             
			FROM  ( SELECT * FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = '''+@RowID+''' ) query '
    IF(@IsDebug = 1) PRINT CAST(@query as NTEXT)    

		IF EXISTS( SELECT '1' FROM corp.vwDealOverrideData WHERE DealId = @pDealId AND AsAtDate = @pAsAtDate)
		BEGIN
			EXEC ps.spUpdateStagingWithOverrideData @pRowID = @RowID, @pEntityName = 'facility', @pDealId = @pDealID,  @pAsAtDate = @pAsAtDate
		END

		--FOR SECURITY 
		IF EXISTS( SELECT 1 From #tempReportFields  WHERE FieldLevel = 'Security' )
		BEGIN  
				--SELECT @FieldSelectColumn_Security = @FieldSelectColumn_Security +'['+ (CASE WHEN CriteriaFieldSql = 'SecurityID' THEN 'securityID_NEW' ELSE CriteriaFieldSql END) + '] AS '''  + CAST(DisplayFieldName AS VARCHAR(100))  + ''', '   
				--FROM #tempReportFields WHERE CriteriaFieldTable = 'Security' OR CriteriaFieldSql = 'FacilityId' ORDER BY FieldOrderId ASC

				SELECT @FieldSelectColumn_Security = @FieldSelectColumn_Security +
				       (CASE WHEN FieldType = 2 
		                THEN  CriteriaFieldSql + ' AS ''' + CAST(DisplayFieldName AS VARCHAR(100))+ ''' , '
		                ELSE '['+ CriteriaFieldSql + '] AS '''  + CAST(DisplayFieldName AS VARCHAR(100)) + ''', ' END )
				FROM #tempReportFields WHERE FieldLevel = 'Security'  ORDER BY FieldOrderId ASC        
				SET @FieldSelectColumn_Security = @FieldSelectColumn_Security 
				--Alter #AccountKeys Table to add Fields as columns        
				SET @AddFieldsColumn_Security  = 'ALTER Table #AccountKeys_Security ADD ' 
				SELECT @AddFieldsColumn_Security = @AddFieldsColumn_Security +  '[' + CAST(DisplayFieldName AS VARCHAR(100))  + '] VARCHAR(MAX), ' 
						From #tempReportFields  WHERE FieldLevel = 'Security'      
						ORDER BY FieldOrderId ASC 
				SET @AddFieldsColumn_Security = (SUBSTRING(@AddFieldsColumn_Security, 0, LEN(@AddFieldsColumn_Security)))  
				EXEC (@AddFieldsColumn_Security)
				
				--SET @Query_Security= 'Insert into #AccountKeys_Security                                        
				--					  SELECT DISTINCT '+ SUBSTRING(@FieldSelectColumn_Security, 0, LEN(@FieldSelectColumn_Security))+'             
				--					  FROM  ( SELECT * FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = '''+@RowID+''' ) query ' 

				SET @Query_Security= 'Insert into #AccountKeys_Security                                        
									  SELECT DISTINCT '+ SUBSTRING(@FieldSelectColumn_Security, 0, LEN(@FieldSelectColumn_Security))+'             
									  FROM  (
												SELECT CASE WHEN FacilitySourceId = 2 THEN SecurityUniqueId ELSE CradleSecurityID END AS  securityID_NEW, *              
												FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] 
												WHERE SecurityKey IS NOT NULL AND RowId = '''+@RowID+''' ) query '

        
       IF(@IsDebug = 1) PRINT CAST(@Query_Security as NTEXT)    
			  IF EXISTS( SELECT '1' FROM corp.vwDealOverrideData WHERE DealId = @pDealId AND AsAtDate = @pAsAtDate)
				BEGIN
					EXEC ps.spUpdateStagingWithOverrideData @pRowID = @RowID, @pEntityName = 'security', @pDealId = @pDealID,  @pAsAtDate = @pAsAtDate
				END
		END
   END 
                                   
  --  REDATED VARIABLES 
    SELECT *, ROW_NUMBER() OVER(ORDER BY RedactField) Row_ID
    INTO #RedactFieldTbl
    FROM (
          SELECT 'DownturnLGD' RedactField
          UNION SELECT 'IFRS9Stage'
          UNION SELECT 'BorrowerCovidViabilityCategory' 
          UNION SELECT 'BorrowerMGS'
          UNION SELECT 'BorrowerProbabilityOfDefault'
          UNION SELECT 'TTCLGD'
          UNION SELECT 'HMFlag'
          UNION SELECT 'ROCLFlag'
          UNION SELECT 'BorrowerLatestMGSGradingReviewDate'
    ) A
    
    DECLARE @LoopIndex INT = 1,@LoopMax INT = 0
    DECLARE @RedactedField VARCHAR(50), @FieldDisplayName VARCHAR(50)
    SELECT @LoopMax = MAX(Row_ID) FROM #RedactFieldTbl
    DECLARE @DealName VARCHAR(50) = (SELECT DealName FROM  [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealId = @pDealId)

	 --FOR SORTING
    DECLARE @FacilityID_FieldColumnName VARCHAR(50) = (SELECT TOP 1 '['+DisplayFieldName+']' FROM #tempReportFields WHERE CriteriaFieldSql = 'FacilityId' AND FieldLevel = 'Facility')
	 IF(@pTabType = 'Facility')
	 BEGIN		  
	    EXEC(@query)
		  WHILE(@LoopIndex <= @LoopMax)
		  BEGIN
		             SELECT @RedactedField = RedactField from #RedactFieldTbl WHERE Row_ID = @LoopIndex
		             SELECT @FieldDisplayName = DisplayFieldName FROM #tempReportFields WHERE CriteriaFieldName = @RedactedField  AND FieldLevel = 'Facility'
		  
		             IF(ISNULL(@FieldDisplayName,'') != '')
		             BEGIN
		                            EXEC ('UPDATE temp
		                            SET temp.['+ @FieldDisplayName +'] = ''REDACTED''
		                            FROM #AccountKeys temp
		                            INNER JOIN cfg.deal deal ON TEMP.'+@FacilityID_FieldColumnName+' In (SELECT [Value] from [app].[udfSplitString](Deal.RedactedFacilityIds, '',''))
		                            WHERE deal.DealName =   '''+ @DealName +'''  ')
		             END
		             SELECT @LoopIndex = @LoopIndex + 1
		  END
		ALTER TABLE #AccountKeys  DROP COLUMN ID;
		EXEC('SELECT * FROM #AccountKeys ORDER BY CONVERT(BIGINT, '+ @FacilityID_FieldColumnName +')')
	 END
  
   SET @FacilityID_FieldColumnName = (SELECT TOP 1 '['+DisplayFieldName+']' FROM #tempReportFields WHERE CriteriaFieldSql = 'FacilityId' AND FieldLevel = 'Security')
   DECLARE @CradleSecurityID_FieldColumnName VARCHAR(50) = (SELECT '['+DisplayFieldName+']' FROM #tempReportFields WHERE CriteriaFieldSql = 'CradleSecurityID' )
   DECLARE @SecurityUniqueID_FieldColumnName VARCHAR(50) = (SELECT '['+DisplayFieldName+']' FROM #tempReportFields WHERE CriteriaFieldSql = 'SecurityUniqueID')

   
	 IF(@pTabType = 'Security')
	 BEGIN
      EXEC(@Query_Security)
      SET @LoopIndex = 1
      WHILE(@LoopIndex <= @LoopMax)
		  BEGIN
		             SELECT @RedactedField = RedactField from #RedactFieldTbl WHERE Row_ID = @LoopIndex
		             SELECT @FieldDisplayName = DisplayFieldName FROM #tempReportFields WHERE CriteriaFieldName = @RedactedField  AND FieldLevel = 'Security'
		  
		             IF(ISNULL(@FieldDisplayName,'') != '')
		             BEGIN
		                            EXEC ('UPDATE temp
		                            SET temp.['+ @FieldDisplayName +'] = ''REDACTED''
		                            FROM #AccountKeys_Security temp
		                            INNER JOIN cfg.deal deal ON TEMP.'+@FacilityID_FieldColumnName+' In (SELECT [Value] from [app].[udfSplitString](Deal.RedactedFacilityIds, '',''))
		                            WHERE deal.DealName =   '''+ @DealName +'''  ')
		             END
		             SELECT @LoopIndex = @LoopIndex + 1
		  END
      ALTER TABLE #AccountKeys_Security  DROP COLUMN ID;
      EXEC('SELECT * FROM #AccountKeys_Security WHERE (ISNULL(NULLIF(CradleSecurityID,0), NULLIF(SecurityUniqueID,0)) IS NOT NULL) ORDER BY CONVERT(BIGINT, '+ @FacilityID_FieldColumnName +'), CONVERT(BIGINT, '+ @CradleSecurityID_FieldColumnName +'), CONVERT(BIGINT, '+ @SecurityUniqueID_FieldColumnName +')')
	 END
	 --  WHERE !(ISNULL(CradleSecurityID,0) =0 AND ISNULL(SecurityUniqueID,0) =0)
	  DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID

	  PRINT 'Query Execution Ends : ' + convert(varchar(20),getdate())
    
  END TRY                
  BEGIN CATCH                
   DECLARE     
     @errorMessage     NVARCHAR(MAX),    
     @errorSeverity    INT,    
     @errorNumber      INT,    
     @errorLine        INT,    
     @errorState       INT;    
   
	SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
	EXEC app.SaveErrorLog 2, 1, 'spGenerateReferenceRegistryReports', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 
	RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
   END CATCH                
 END  
 GO