USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spLoadCounterpartyRatingData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadCounterpartyRatingData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spLoadCounterpartyRatingData]   
/*-------------------------------------------------------        
 * Author: Gunjan Chandola        
 * Date: 22.10.2020        
 * Description:  This will LOAD data from staging into CW table for Counterparty rating       
 *             
 * Change History        
 * --------------        
 * Author  Date  Description        
 * -------------------------------------------------------        
*/        
(        
 @pFeedRunLogId   INT,      
 @pAsAtDate    DATETIME        
)        
AS        
BEGIN        
        
 SET NOCOUNT ON       
        
 BEGIN TRY        
      
 IF @pFeedRunLogId IS NOT NULL        
 BEGIN       
  DECLARE                                      
   @createdBy       VARCHAR(80),    
   @createDate     DATETIME    
    
   SET @createdBy = 'System';    
   SET @createDate = GETDATE();    
       
   --Check whether the temp table already exist or not    
   IF OBJECT_ID('tempdb..#tmp_CPRating') IS NOT NULL DROP TABLE #tmp_CPRating    
     
    SELECT  * INTO  #tmp_CPRating FROM (SELECT  DISTINCT  
              cra1.CRAId,    
              CisCode    
              ,rt.RatingTypeId AS RatingTypeId    
              ,Rating    
              ,CONVERT(DATETIME,RatingDate,104) AS RatingDate    
              ,[FileName]   
       FROM     
              cw.vw_ActiveCounterpartyRatingStg cpr   
       LEFT JOIN     
              cfgcw.CreditRatingAgency cra1 ON  CASE cpr.[RatingAgencyCode] WHEN 'SNP' THEN 'S&P'     
               WHEN 'MOODYS' THEN 'Moody''s'    
               WHEN 'FITCH'THEN 'Fitch'    
               WHEN 'DBRS'THEN 'DBRS'END =cra1.Name    
       LEFT JOIN     
              cfgcw.RatingType rt ON CASE cpr.[TermTypeCode]   
              WHEN 'L'   
              THEN 'Long Term'     
              WHEN 'S' THEN 'Short Term'  
              END=rt.Name   
       WHERE    
              RatingTypeId IS NOT NULL   
              AND cpr.RatingAgencyCode <> 'MOODYS'  
     AND (TermTypeCode = 'S' OR TermTypeCode = 'L')  
     AND RatingTypeCode = 'ISSUER' AND CurrencyTypeCode = 'F'   
       UNION  
    --Moody's Short term rating  
   SELECT  DISTINCT  
              cra1.CRAId,    
              CisCode    
              ,rt.RatingTypeId AS RatingTypeId    
              ,Rating    
              ,CONVERT(DATETIME,RatingDate,104) AS RatingDate    
              ,[FileName]   
       FROM     
              cw.vw_ActiveCounterpartyRatingStg cpr   
       JOIN     
              cfgcw.CreditRatingAgency cra1 ON  CASE cpr.[RatingAgencyCode]    
               WHEN 'MOODYS' THEN 'Moody''s' END =cra1.Name    
       LEFT JOIN     
              cfgcw.RatingType rt ON CASE cpr.[TermTypeCode]   
              WHEN 'S' THEN 'Short Term'  
              END=rt.Name   
       WHERE    
            RatingTypeId IS NOT NULL   
            AND cpr.RatingAgencyCode = 'MOODYS'  
   AND cpr.TermTypeCode = 'S'     
   AND cpr.RatingTypeCode = 'BDR'   
   AND CurrencyTypeCode = 'L'   
  UNION  
  ---Moody's Counterparty Short Term and Long Term Rating  
  SELECT  DISTINCT  
              cra1.CRAId,    
              CisCode    
              ,rt.RatingTypeId AS RatingTypeId    
              ,Rating    
              ,CONVERT(DATETIME,RatingDate,104) AS RatingDate    
              ,[FileName]   
       FROM     
              cw.vw_ActiveCounterpartyRatingStg cpr   
       JOIN     
              cfgcw.CreditRatingAgency cra1 ON  CASE cpr.[RatingAgencyCode]    
               WHEN 'MOODYS' THEN 'Moody''s' END =cra1.Name    
       LEFT JOIN     
              cfgcw.RatingType rt ON CASE cpr.[TermTypeCode]   
              WHEN 'S' THEN 'Short Term Counterparty'  
     WHEN 'L' THEN 'Long Term Counterparty'  
              END=rt.Name   
       WHERE    
            RatingTypeId IS NOT NULL   
            AND cpr.RatingAgencyCode = 'MOODYS'  
   AND (cpr.TermTypeCode = 'S' OR cpr.TermTypeCode = 'L' )  
   AND cpr.RatingTypeCode = 'CRA'   
   AND (CurrencyTypeCode IS NULL OR CurrencyTypeCode= '')  
  UNION  
       --Outlook Rating other than Moody's  
       SELECT  DISTINCT  
              cra1.CRAId,    
              CisCode    
              ,rt.RatingTypeId AS RatingTypeId    
              ,RatingOutlook AS Rating    
              ,CONVERT(DATETIME,RatingOutlookDate,104) AS RatingDate    
              ,[FileName]   
       FROM     
              cw.vw_ActiveCounterpartyRatingStg cpr   
       JOIN     
              cfgcw.CreditRatingAgency cra1 ON  CASE cpr.[RatingAgencyCode] WHEN 'SNP' THEN 'S&P'     
               WHEN 'FITCH'THEN 'Fitch'    
               WHEN 'DBRS'THEN 'DBRS'END =cra1.Name    
       LEFT JOIN     
              cfgcw.RatingType rt ON CASE cpr.[TermTypeCode]   
              WHEN 'L' THEN 'Long Term Outlook'  
              END=rt.Name   
       WHERE    
              RatingTypeId IS NOT NULL   
              AND cpr.RatingAgencyCode <> 'MOODYS'  
       UNION    
       ---Moody's Long Term Rating  
       SELECT DISTINCT  
              cra1.CRAId    
              ,cpr.CisCode    
              ,rt.RatingTypeId AS RatingTypeId    
              ,Rating = CASE WHEN ISNULL(ml1.Rating, '') = '' THEN ml2.Rating ELSE ml1.Rating END   
              ,FORMAT(ISNULL(CONVERT(DATETIME,ml1.RatingDate,103),CONVERT(DATETIME,ml2.RatingDate,103)), 'yyyy-MM-dd 00:00:00.000') AS RatingDate    
              ,[FileName]   
       FROM   
              cw.vw_ActiveCounterpartyRatingStg cpr  
       JOIN     
              cfgcw.CreditRatingAgency cra1 ON  CASE cpr.[RatingAgencyCode]      
                     WHEN 'MOODYS' THEN 'Moody''s' END =cra1.Name    
       LEFT JOIN   
       (    
              SELECT     
                     CisCode, Rating, RatingDate, RatingOutlook, RatingOutlookDate,RelatesToDate    
              FROM     
                     cw.vw_ActiveCounterpartyRatingStg    
              WHERE     
                     RatingAgencyCode = 'MOODYS'   
                     AND TermTypeCode = 'L'   
                     AND (CurrencyTypeCode IS NULL OR  CurrencyTypeCode ='')   
                     AND RatingTypeCode = 'ISSUER'  -- MOODYS: If LT Issuer data available, then take that, otherwise take LT BDR (Bank deposit rate)  
       ) ml1    
              ON  cpr.CisCode = ml1.CisCode AND cpr.RelatesToDate = ml1.RelatesToDate    
       LEFT JOIN   
       (    
              SELECT     
                     CisCode, Rating, RatingDate, RatingOutlook, RatingOutlookDate,RelatesToDate    
              FROM     
                     cw.vw_ActiveCounterpartyRatingStg    
              WHERE     
                     RatingAgencyCode = 'MOODYS' AND    
                     TermTypeCode = 'L' AND    
                     RatingTypeCode = 'BDR' AND   -- MOODYS: If LT Issuer data available, then take that, otherwise take LT BDR (Bank deposit rate)  
                     CurrencyTypeCode = 'F'   
       ) ml2   
              ON cpr.CisCode = ml2.CisCode AND cpr.RelatesToDate = ml2.RelatesToDate   
       LEFT JOIN     
              cfgcw.RatingType rt ON CASE cpr.[TermTypeCode]   
              WHEN 'L' THEN 'Long Term'  
              END=rt.Name   
       WHERE    
              RatingTypeId IS NOT NULL   
              AND cpr.RatingAgencyCode = 'MOODYS' AND TermTypeCode = 'L'  
       UNION  
       ---Moody's Long Term Outlook Rating  
       SELECT DISTINCT  
              cra1.CRAId    
              ,cpr.CisCode    
              ,rt.RatingTypeId AS RatingTypeId    
              ,Rating= CASE WHEN ISNULL(ml1.RatingOutlook, '') ='' THEN ml2.RatingOutlook ELSE ml1.RatingOutlook END  
       ,FORMAT(ISNULL(CONVERT(DATETIME,ml1.RatingOutlookDate,103),CONVERT(DATETIME,ml2.RatingOutlookDate,103)), 'yyyy-MM-dd 00:00:00.000') AS RatingDate    
              ,[FileName]   
       FROM   
              cw.vw_ActiveCounterpartyRatingStg cpr  
       JOIN     
              cfgcw.CreditRatingAgency cra1 ON  CASE cpr.[RatingAgencyCode]      
                     WHEN 'MOODYS' THEN 'Moody''s' END =cra1.Name    
       LEFT JOIN   
       (    
              SELECT     
                     CisCode, Rating, RatingDate, RatingOutlook, RatingOutlookDate,RelatesToDate    
              FROM     
                     cw.vw_ActiveCounterpartyRatingStg    
              WHERE     
                     RatingAgencyCode = 'MOODYS'    
                     AND TermTypeCode = 'L'     
                     AND (CurrencyTypeCode IS NULL OR  CurrencyTypeCode ='')   
                     AND RatingTypeCode = 'ISSUER'  -- MOODYS: If LT Issuer data available, then take that, otherwise take LT BDR (Bank deposit rate)  
       ) ml1    
              ON  cpr.CisCode = ml1.CisCode AND cpr.RelatesToDate = ml1.RelatesToDate    
       LEFT JOIN   
       (    
              SELECT     
                     CisCode, Rating, RatingDate, RatingOutlook, RatingOutlookDate,RelatesToDate    
              FROM     
                     cw.vw_ActiveCounterpartyRatingStg    
              WHERE     
                     RatingAgencyCode = 'MOODYS' AND    
                     TermTypeCode = 'L' AND    
                     RatingTypeCode = 'BDR' AND   -- MOODYS: If LT Issuer data available, then take that, otherwise take LT BDR (Bank deposit rate)  
                     CurrencyTypeCode = 'F'   
       ) ml2   
              ON cpr.CisCode = ml2.CisCode AND cpr.RelatesToDate = ml2.RelatesToDate   
       LEFT JOIN     
              cfgcw.RatingType rt ON CASE cpr.[TermTypeCode]   
              WHEN 'L' THEN 'Long Term Outlook'  
              END=rt.Name   
       WHERE    
              RatingTypeId IS NOT NULL   
              AND cpr.RatingAgencyCode = 'MOODYS' AND TermTypeCode = 'L'  
          
 )t WHERE Rating!='' ORDER BY CisCode   
  
    
   BEGIN TRANSACTION       
    
   --Updating the records if record is already exists    
   UPDATE scr SET     
    scr.Rating = tmpRating.Rating,    
    Version = (Version + 1),    
    ModifiedBy = @createdBy,    
    ModifiedDate = @createDate,    
    FeedRunLogId = @pFeedRunLogId    
   FROM     
    [cw].[SourceCounterpartyRating] scr    
   JOIN    
    #tmp_CPRating tmpRating ON scr.CRAId = tmpRating.CRAId AND LTRIM(RTRIM(scr.CisCode)) = LTRIM(RTRIM(tmpRating.CisCode))    
    AND scr.RatingTypeId = tmpRating.RatingTypeId --AND CONVERT(DATE,scr.TermDate) = CONVERT(DATE,tmpRating.RatingDate)   
    AND (CAST(scr.RatingDate AS DATE) = CAST(@pAsAtDate AS DATE))    
    
   ---Inserting the new records which comes as new record    
   INSERT INTO [cw].[SourceCounterpartyRating]([FeedRunLogId], RatingDate, [CRAId], [CisCode], [RatingTypeId]    
   ,[Rating], [TermDate], [Version], [CreatedBy], [CreatedDate], [ModifiedBy], [ModifiedDate])    
   SELECT     
    DISTINCT @pFeedRunLogId, @pAsAtDate, tmpRating.CRAId, tmpRating.CisCode, tmpRating.RatingTypeId,     
    tmpRating.Rating, tmpRating.RatingDate, 1, @createdBy, @createDate, @createdBy, @createDate    
   FROM     
    #tmp_CPRating tmpRating    
   LEFT JOIN    
    [cw].[SourceCounterpartyRating] scr ON scr.CRAId = tmpRating.CRAId AND LTRIM(RTRIM(scr.CisCode)) = LTRIM(RTRIM(tmpRating.CisCode))   
    AND scr.RatingTypeId = tmpRating.RatingTypeId   
    AND scr.Rating = tmpRating.Rating    
    AND (CAST(scr.RatingDate AS DATE) = CAST(@pAsAtDate AS DATE))   
   WHERE     
    scr.CRAId IS NULL    
    
   --Delete records which are not there in the latest feed    
   DELETE scr     
   FROM     
    [cw].[SourceCounterpartyRating] scr    
   LEFT JOIN    
    #tmp_CPRating tmpRating ON (CAST(scr.RatingDate AS DATE) = CAST(@pAsAtDate AS DATE)) 
    AND     
    (    
     scr.CRAId <> tmpRating.CRAId OR LTRIM(RTRIM(scr.CisCode)) <> LTRIM(RTRIM(tmpRating.CisCode))    
     OR scr.RatingTypeId <> tmpRating.RatingTypeId OR scr.Rating <> tmpRating.Rating    
    )    
   WHERE    
    scr.FeedRunLogId <> @pFeedRunLogId    
	AND CAST(scr.RatingDate AS DATE) = CAST(@pAsAtDate AS DATE)

   COMMIT TRANSACTION;      
  END           
 END TRY        
 BEGIN CATCH        
        
	IF @@trancount > 0 ROLLBACK TRANSACTION;        
        
	DECLARE         
		@errorMessage     NVARCHAR(MAX),        
		@errorSeverity    INT,        
		@errorNumber      INT,        
		@errorLine        INT,        
		@errorState       INT;        
        
	SELECT         
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()        
        
	EXEC [CW].[spUpdateFeedRunLog] @pFeedRunLogId, '', 'Failed', 0        
        
	EXEC app.SaveErrorLog 1, 1, 'cw.spLoadCounterpartyRatingData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, 'System'        
          
	RAISERROR (@errorMessage,        
				@errorSeverity,        
				@errorState )        
 END CATCH        
END 
GO
