USE [SFP_Securitisation]
GO

IF OBJECT_ID('[ps].[spGetAuthWorkflowStatus]') IS NOT NULL
	DROP PROCEDURE [ps].[spGetAuthWorkflowStatus] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Aditya Aggarwal 
--Date: 12-08-2021 
--Description: Get current Status 
--[ps].[spGetAuthWorkflowStatus] 1, 'Concentration_Test'
--==================================   
CREATE PROCEDURE [ps].[spGetAuthWorkflowStatus] 
   @pPsId   INT,    
   @pWorkflowType  VARCHAR(100),
   @pUserName  VARCHAR(80)       
AS  
BEGIN  
  BEGIN TRY 
	  DECLARE 
         @ctWorkflow	VARCHAR(100) = 'Concentration_Test',
         @ecWorkflow	VARCHAR(100) = 'Eligibility_Criteria',
         @ecfWorkflow VARCHAR(100) = 'Custom_Field',
	      @ddcWorkflow VARCHAR(100) = 'DealDataCorrection',
	      @lmWorkflow VARCHAR(100) = 'Loss_Management'

	  IF @pWorkflowType=@ctWorkflow    
      BEGIN    
         SELECT TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,    
            wfs.WorkflowStepName AS StepName,    
            ct.[StatusId] AS Status,    
            wfs.Comment,    
            wfs.ActionedDate AS ActionDate ,    
            wfs.ActionedBy AS ActionBy    
         FROM [cw].[vwWorkFlowLastAction] wfs    
         JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = wfs.ProcessReferenceId    
         WHERE ct.ConcentrationTestId = @pPsId AND wfs.WorkflowTypeName = @pWorkflowType AND ct.isActive = 1 
         ORDER BY wfs.ActionedDate DESC    
      END
     ELSE IF @pWorkflowType=@ecWorkflow    
      BEGIN    
         SELECT TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,    
            wfs.WorkflowStepName AS StepName,    
            ec.[EligibilityCriteriaStatusId] AS Status,    
            wfs.Comment AS Comment,    
            wfs.ActionedDate AS ActionDate ,    
            wfs.ActionedBy AS ActionBy
         FROM [cw].[vwWorkFlowLastAction] wfs    
         JOIN ps.EligibilityCriteria ec ON ec.EligibilityCriteriaId = wfs.ProcessReferenceId    
         WHERE ec.EligibilityCriteriaId = @pPsId AND wfs.WorkflowTypeName = @pWorkflowType AND ec.IsActive = 1    
         ORDER BY wfs.ActionedDate DESC    
      END
     ELSE IF @pWorkflowType=@ecfWorkflow    
      BEGIN    
         SELECT TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,    
            wfs.WorkflowStepName AS StepName,    
            ecf.[FieldStatusId] AS Status,    
            wfs.Comment,    
            wfs.ActionedDate AS ActionDate ,    
            wfs.ActionedBy AS ActionBy   
         FROM [cw].[vwWorkFlowLastAction] wfs    
         JOIN ps.EligibilityCriteriaField ecf ON ecf.EligibilityCriteriaFieldId = wfs.ProcessReferenceId    
         WHERE ecf.EligibilityCriteriaFieldId = @pPsId AND wfs.WorkflowTypeName = @pWorkflowType AND ecf.IsActive = 1 
         ORDER BY wfs.ActionedDate DESC    
      END
      ELSE IF @pWorkflowType=@ddcWorkflow      
	  BEGIN      
			SELECT TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,        
			wfs.WorkflowStepName AS StepName,        
			ddc.DataCorrectionStatus AS Status,        
			wfs.Comment,        
			wfs.ActionedDate AS ActionDate ,        
			wfs.ActionedBy AS ActionBy        
			FROM [cw].[vwWorkFlowLastAction] wfs        
			--JOIN [corp].[DealDataCorrection] ddc ON ddc.DealDataCorrectionId = wfs.ProcessReferenceId 
			JOIN [corp].[DealOverrideParent] ddc ON ddc.DealOverrideParentId = wfs.ProcessReferenceId 
			WHERE ddc.DealOverrideParentId = @pPsId AND wfs.WorkflowTypeName = @pWorkflowType AND ddc.isActive = 1     
			ORDER BY wfs.ActionedDate DESC    
	  END 
      ELSE IF @pWorkflowType=@lmWorkflow      
	  BEGIN      
		 SELECT TOP 1 wfs.WorkflowStepDisplayName AS StepDescription,      
			wfs.WorkflowStepName AS StepName,      
			lm.WorkflowStepId AS Status,      
			wfs.Comment,      
			wfs.ActionedDate AS ActionDate ,      
			wfs.ActionedBy AS ActionBy      
		 FROM [cw].[vwWorkFlowLastAction] wfs      
		 JOIN [corp].[LossManagement] lm ON lm.LossManagementId = wfs.ProcessReferenceId      
		 WHERE lm.LossManagementId = @pPsId AND wfs.WorkflowTypeName = @pWorkflowType AND lm.isActive = 1   
		 ORDER BY wfs.ActionedDate DESC      
	  END 

END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'ps.spGetAuthWorkflowStatus', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO
