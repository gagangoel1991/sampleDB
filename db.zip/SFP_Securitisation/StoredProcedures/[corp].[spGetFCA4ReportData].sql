USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetFCA4ReportData]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetFCA4ReportData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE Procedure [corp].[spGetFCA4ReportData]
	@DealName AS VARCHAR(100) = NULL,
	@AsAtDate AS DATE,
	@pUserName AS VARCHAR(50),
	 @pPoolId AS INT = NULL 
As
BEGIN	
	BEGIN TRY	
		
		EXEC [dbo].[syn_Corporate_sp_Annex4FCACollateralDataReport] @AsAtDate, @DealName, @pPoolId;

		EXEC [dbo].[syn_Corporate_sp_Annex4FCAExposureDataReport] @AsAtDate, @DealName, @pPoolId;

    END TRY
	BEGIN CATCH		
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetFCA4ReportData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, ''
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
