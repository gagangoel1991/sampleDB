USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetConcentrationRuleOperators]') AND type IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetConcentrationRuleOperators]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
  
CREATE PROCEDURE [ps].[spGetConcentrationRuleOperators]
(  
	 @pType VARCHAR(20) = '<All>',  
	 @pUserName VARCHAR(20) = NULL  
)  
AS   
BEGIN  
	BEGIN TRY  
		DECLARE @DataType VARCHAR(50)  
		IF @pType = '<All>'  
			SET @DataType = '%'  
		ELSE      
			SET @DataType =  '%' + @pType+  '%'      
  
		SELECT operator.OperatorId AS [Value],  
		operator.Operator AS [Title],  
		(  
			CASE [type].[Type] WHEN 'Integer' THEN 'number'   
			WHEN 'Text' THEN 'string'   
			WHEN 'Bool' THEN 'boolean'   
			WHEN 'Date' THEN 'date'   
			WHEN 'Reference' THEN 'category'   
		END  
		)AS OperatorType,
		operator.Title AS OperatorText
		FROM PS.Operator operator  
		INNER JOIN   
			PS.OperatorFieldDataTypeMap operatorMap  
			ON operator.OperatorId = operatorMap.OperatorId  
		INNER JOIN   
			PS.FieldDataType [type]   
			ON [type].FieldDataTypeId = operatorMap.FieldDataTypeId  
		WHERE 
			operatorMap.IsActive = 1  
			AND [type].[Type] LIKE  @DataType
			AND operator.Title <> 'Between'   
		ORDER BY [type].[Type]  
	END TRY  
	BEGIN CATCH  
		DECLARE                                             
		@errorMessage     NVARCHAR(MAX),                                            
		@errorSeverity    INT,                                            
		@errorNumber      INT,                                            
		@errorLine        INT,                                            
		@errorState       INT;                                          
		SELECT                             
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()                           
           
		EXEC app.SaveErrorLog 2, 1, 'spGetConcentrationRuleOperators', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName                             
                                          
		RAISERROR (@errorMessage, @errorSeverity, @errorState)      
		END CATCH
END
GO
