USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.spTempRollbackNextIpd') IS NOT NULL
	DROP PROCEDURE cb.spTempRollbackNextIpd
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cb.[spTempRollbackNextIpd]  
(  
	 @pDealId	SMALLINT,  
	 @pIpdDate	DATE,  
	 @pUserName VARCHAR(80)  
 --exec cb.spTempRollbackNextIpd 6, '2021-05-24 00:00:00.000', 'fm\shriyad'  
)  
AS  
BEGIN  
	BEGIN TRY   
		DECLARE   
			@dealIpdRunId	INT,  
			@dealIpdId		INT  
  
		SELECT @dealIpdId=dealipdid  
		FROM cw.DealIpd WHERE DealId=@pDealId AND IpdDate=@pIpdDate;  
   
		SELECT @dealIpdRunId=runid  
		FROM cw.DealIpdRun WHERE DealIpdId=@dealIpdId  
		PRINT @dealIpdRunId 
 
		DELETE FROM cw.DealIpdTriggerResult_PostWF WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cw.WaterfallLineItemAmount_PostWF WHERE DealIpdRunId=@dealIpdRunId  
  
		DELETE FROM cb.TestLineItemValue WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.DealIpdTestResult WHERE DealIpdRunId=@dealIpdRunId  
  
		DELETE FROM cb.CouponPaymentFund_PostWf WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.PreMaturityLiquidity_PostWF WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.ReserveFund_PostWF WHERE DealIpdRunId=@dealIpdRunId  
   
		DELETE FROM cw.PrincipalWaterfallPaymentSummary WHERE DealIpdRunId=@dealIpdRunId;  
		DELETE FROM cw.PrincipalWaterfallPayment WHERE DealIpdRunId=@dealIpdRunId;  
   
		DELETE FROM CW.InterimWaterfallFee  WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.PreMaturityLiquidity_PreWF WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.CouponPaymentFund_PreWf WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.ReserveFund_PreWF WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.SwapCollateralFund WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.RevenueLedgerFund WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.[PrincipalLedgerFund] WHERE DealIpdRunId=@dealIpdRunId
		DELETE FROM cb.[PaymentLedgerFund] WHERE DealIpdRunId=@dealIpdRunId
		DELETE FROM cb.[MaturingProceedsLoanFund] WHERE DealIpdRunId=@dealIpdRunId
		DELETE FROM [cb].[CapitalAccountLedger] WHERE DealIpdRunId=@dealIpdRunId
		
		DELETE FROM cb.DealSwap_Wf WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.DealNote_Wf WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.NoteSwap_Wf WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cb.ManualFieldValue WHERE DealIpdRunId=@dealIpdRunId  
   
		DELETE FROM cw.ExpressionValue WHERE DealIpdRunId=@dealIpdRunId  
		DELETE FROM cw.VariableValue WHERE DealIpdRunId=@dealIpdRunId  
   
   
		DELETE FROM cw.RevenueWaterfallPaymentSummary WHERE DealIpdRunId=@dealIpdRunId;  
		DELETE FROM cw.RevenueWaterfallPayment WHERE DealIpdRunId=@dealIpdRunId;  
		DELETE FROM cw.WaterfallLineItemAmount_PostWF WHERE DealIpdRunId=@dealIpdRunId;  
		DELETE FROM cw.WaterfallLineItemAmount WHERE DealIpdRunId=@dealIpdRunId;  
		DELETE FROM cw.DealIpdTriggerResult_PostWF WHERE DealIpdRunId = @dealIpdRunId;  
		DELETE FROM cw.DealIpdTriggerResult WHERE DealIpdRunId=@dealIpdRunId;  
		DELETE FROM cw.DealIpdTriggerRatingResult WHERE DealIpdRunId=@dealIpdRunId;  
  
		DELETE FROM cw.DealIpdSummaryLineItemStatus WHERE DealIpdRunId = @DealIpdRunId  
   
		DELETE FROM cw.DealIpdRun WHERE RunId=@dealIpdRunId;  
		DELETE FROM cw.InvoiceData_PostWF WHERE DealIpdDate = @pIpdDate;  
   
		UPDATE cw.DealIpd  
		SET IsCurrentIPD=0  
		WHERE DealIpdId = @dealIpdId  
  
		DELETE FROM cw.DealIpdSummaryLineItemStatus   
		WHERE DealIpdRunId = @DealIpdRunId  
  
		UPDATE cw.DealIpdConditionTest SET LoanAmount=0,RepurchaseAmount = 0,  
		Comment = NULL,LoanCount = 0,PreviousRepurchaseDate= NULL, ModifiedBy = @pUserName,  
		ModifiedDate = GETDATE()  
		WHERE DealIpdRunId = @DealIpdRunId  
  
		UPDATE cw.dealipd SET IsCurrentIPD = 1 WHERE  
		DealIpdId = (SELECT DealIpdId FROM cw.vwDealIpdDates WHERE DealId = @pDealId AND CAST(NextIPD AS DATE)= CAST(@pIpdDate AS DATE))  
  
		DELETE FROM cw.DealIpdIrLocation WHERE DealIpdId = @dealIpdId  
  
		DELETE FROM cw.InvoiceData WHERE DealIpdDate = @pIpdDate;  
  
	END TRY   
  
    BEGIN CATCH    
		DECLARE     
			@errorMessage     NVARCHAR(MAX),    
			@errorSeverity    INT,    
			@errorNumber      INT,    
			@errorLine        INT,    
			@errorState       INT;    
    
		SELECT     
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()    
			EXEC app.SaveErrorLog 1, 1, 'cw.spTempRollbackNextIpd', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName    
      
		RAISERROR (@errorMessage,    
			@errorSeverity,    
			@errorState )    
	END CATCH     
 END
GO