USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetDealList') IS NOT NULL
	DROP PROCEDURE cw.spGetDealList
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Saurabh Bhatia  
--Date: 12-02-2021  
--Description: To get deal list
--Exec cw.spGetDealList 'bhasaaa' 
--==================================  
CREATE PROCEDURE [cw].[spGetDealList] @pUserName VARCHAR(80), @pAssetClassId INT = 1
AS
BEGIN
	BEGIN TRY
		SELECT d.DealId
			,d.DealName
			,d.DealPublicName
			,d.[Description]
			,d.OwnerName
			,dlvBusinessArea.[DisplayText] AS BusinessArea
			,dlvDealType.[DisplayText] AS DealType
			,wrkStp.DisplayName AS DealStatus
			,d.ClosingDate
			,d.DealMaturityDate
			,dlvDealCurrency.[Code] AS DealCurrency
			,dlvJurisdictionMarker.[DisplayText] AS JurisdictionMarker
			,dlvDealAccountingType.[DisplayText] AS DealAccountingType

			,dlvCashReportingFlag.[DisplayText] AS CashReporting
			,DealInitialSize
			,TopupEndDate
			,dlvTopupFlag.[DisplayText] AS TopupFlag
			,(RiskRetentionPercent * 100) AS RiskRetentionPercent
			,dlvRiskRetentionMethod.[DisplayText] AS RiskRetentionMethod
			,dlvRiskRetentionHolder.[DisplayText] AS RiskRetentionHolder

			,d.IsActive
			,d.CreatedBy
			,d.CreatedDate
			,d.ModifiedBy
			,d.ModifiedDate
		FROM [cfg].[Deal] d
		LEFT JOIN cfgCW.DealLookupValue dlvDealType ON d.DealTypeId = dlvDealType.LookupValueId --Deal Type
		LEFT JOIN cfgCW.DealLookupValue dlvBusinessArea ON d.BusinessAreaId = dlvBusinessArea.LookupValueId --Business Area
	--	LEFT JOIN cfgCW.DealLookupValue dlvDealCurrency ON d.DealCurrencyId = dlvDealCurrency.LookupValueId --Deal Currency
		LEFT JOIN cfgCW.DealLookupValue dlvJurisdictionMarker ON d.JurisdictionMarkerId = dlvJurisdictionMarker.LookupValueId --Jurisdiction Marker
		LEFT JOIN cfgCW.DealLookupValue dlvDealAccountingType ON d.DealAccountingTypeId = dlvDealAccountingType.LookupValueId --Accounting Type

		LEFT JOIN cfgcw.Currency dlvDealCurrency ON d.DealCurrencyId = dlvDealCurrency.CurrencyId --Deal Currency
		LEFT JOIN cfgCW.DealLookupValue dlvCashReportingFlag ON d.CashReportingFlagId = dlvCashReportingFlag.LookupValueId --Cash Reporting Flag
		LEFT JOIN cfgCW.DealLookupValue dlvTopupFlag ON d.TopupFlagId = dlvTopupFlag.LookupValueId --Topup Flag
		LEFT JOIN cfgCW.DealLookupValue dlvRiskRetentionMethod ON d.RiskRetentionMethodId = dlvRiskRetentionMethod.LookupValueId --Risk Retention Method
		LEFT JOIN cfgCW.DealLookupValue dlvRiskRetentionHolder ON d.RiskRetentionHolderId = dlvRiskRetentionHolder.LookupValueId --Risk Retention Holder

		LEFT JOIN cfgCW.WorkflowStep wrkStp ON d.DealStatusId = wrkStp.WorkflowStepId  -- Deal Status
			 JOIN cfgCW.WorkflowType wrkType ON wrkStp.WorkflowTypeId = wrkType.WorkflowTypeId  
					WHERE wrkType.Name='New_Deal_Onboarding' AND d.AssetClassId = @pAssetClassId
		ORDER BY d.ModifiedDate DESC
	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2
			,1
			,'cw.spGetDealList'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH;
END

GO
