USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetOverrideStatusDetail]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetOverrideStatusDetail] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 
 -- EXEC [corp].[spGetOverrideStatusDetail]  1 , '31-AUG-2022'
CREATE PROCEDURE [corp].[spGetOverrideStatusDetail]    
    @pDealId INT,   
    @pAsAtDate DATE    
AS  
BEGIN

	DECLARE @IsPoolAuthorizedButNotOverride INT = 0

   SELECT DOP.*, STS.[Status] as OverrideSatus, @IsPoolAuthorizedButNotOverride AS IsPoolAuthorizedButNotOverride
   FROM [corp].[DealOverrideParent] DOP
   INNER JOIN [corp].[DealDataCorrectionStatus] STS ON DOP.DataCorrectionStatus = STS.DealDataCorrectionStatusId
   WHERE DealOverrideParentId = (SELECT MAX(DealOverrideParentId) FROM [corp].[DealOverrideParent] WHERE DealId = @pDealId AND AsAtDate = @pAsAtDate)
   -- SELECT * FROM [corp].[DealDataCorrectionStatus] 
 END

 GO 
