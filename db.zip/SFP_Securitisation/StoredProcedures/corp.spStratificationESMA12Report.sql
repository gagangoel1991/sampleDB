USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = OBJECT_ID(N'[corp].[spStratificationESMA12Report]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
DROP PROCEDURE [corp].[spStratificationESMA12Report]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Neeraj Jindal
Creation Date  : 12-Oct-2022
Description    : This will return calculated data for ESMA 12 Report
Execution      : EXEC [corp].[spStratificationESMA12Report] @pAsAtDate= '2022-01-31', @pDealId = 1 ,  @pUserName='Europa\jindnaj'
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE PROCEDURE [corp].[spStratificationESMA12Report] 	   	 
	 @pAsAtDate Date,
	 @pDealId INT,	 
	 @pUserName VARCHAR(100) 
	
AS  
BEGIN  
	BEGIN TRY    

		IF OBJECT_ID('tempdb..#ESMA12') IS NOT NULL
		DROP TABLE #ESMA12
		IF OBJECT_ID('tempdb..#ESMA12Delinquency') IS NOT NULL
		DROP TABLE #ESMA12Delinquency
		IF OBJECT_ID('tempdb..#ESMA12ObligorPD') IS NOT NULL
		DROP TABLE #ESMA12ObligorPD
		IF OBJECT_ID('tempdb..#ESMA12Summary') IS NOT NULL
		DROP TABLE #ESMA12Summary
		 
        /*Creating temp tables*/
		CREATE TABLE #ESMA12 (FieldName VARCHAR(200), FieldValue VARCHAR(100))
		CREATE TABLE #ESMA12Delinquency (Bucket VARCHAR(200), Exposure DECIMAL(15,2), Percnt DECIMAL(15,6))
		CREATE TABLE #ESMA12ObligorPD (Bucket VARCHAR(200), RonaPercent DECIMAL(15,6), CountofObligors INT)
		CREATE TABLE #ESMA12Summary (Bucket VARCHAR(200), Pool VARCHAR(100))

		PRINT 'Temp Tables Created : ' + CONVERT(VARCHAR(20),GETDATE())

		/*Getting data into temp tables*/
		INSERT INTO #ESMA12
		EXEC [corp].[spAnnex12ESMAUnderlyingExposureReport] @pAsAtDate = @pAsAtDate, @pDealId = @pDealId, @pUserName = @pUserName

		INSERT INTO #ESMA12Delinquency
		EXEC [corp].[spStratificationDelinquencyData] @pAsAtDate = @pAsAtDate, @pDealId = @pDealId, @pUserName = @pUserName

		INSERT INTO #ESMA12ObligorPD
		EXEC [corp].[spStratificationObligorPDData] @pAsAtDate = @pAsAtDate, @pDealId = @pDealId, @pUserName = @pUserName

		INSERT INTO #ESMA12Summary
		EXEC [corp].[spStratificationSummaryData] @pAsAtDate = @pAsAtDate, @pDealId = @pDealId, @pUserName = @pUserName


		INSERT INTO #ESMA12
		SELECT Bucket, Pool FROM #ESMA12Summary 
		WHERE Bucket IN ('Internal TTC Loss Given Default Estimate', 'Internal Loss Given Default Estimate')
		UNION
		SELECT Bucket, CONVERT(VARCHAR,CONVERT(DECIMAL(5,2), Percnt * 100))+'%' FROM #ESMA12Delinquency
		WHERE Bucket NOT IN ('Current') 
		UNION
		SELECT Bucket, CONVERT(VARCHAR,CONVERT(DECIMAL(5,2), RonaPercent * 100))+'%' FROM #ESMA12ObligorPD
		
		/*Final Output*/
		SELECT FieldName, FieldValue FROM #ESMA12

		PRINT 'ESMA 12 Report End : ' + CONVERT(VARCHAR(20),GETDATE())
    
	END TRY                
	BEGIN CATCH                
	   DECLARE     
		 @errorMessage     NVARCHAR(MAX),    
		 @errorSeverity    INT,    
		 @errorNumber      INT,    
		 @errorLine        INT,    
		 @errorState       INT;   	
		
		SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()   
		EXEC app.SaveErrorLog 2, 1, 'spStratificationESMA12Report', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName 

		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )            
	END CATCH                
END  
GO
