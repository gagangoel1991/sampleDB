USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spGetDealIpdBasicInfoData') IS NOT NULL
DROP PROC  cw.spGetDealIpdBasicInfoData

GO
/****** Object:  StoredProcedure [cw].[spGetDealIpdBasicInfoData]    Script Date: 14/03/2021 15:08:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Ravindra Singh
 * Date:  03.05.2021
 * Description:  IPD Deal Configuration Basic information for IPD run.
 *                             
 * Change History
 * --------------
 * Author        Date          Description
 * 
 * CW.spGetDealIpdBasicInfoData 14, 27 
 * -------------------------------------------------------
*/         
CREATE PROC CW.spGetDealIpdBasicInfoData
@pDealId                    INT = NULL,
@pDealIpdRunId              INT
AS        
BEGIN  

	DECLARE 
		@AuthoriseBuildIR		INT,
		@reportTypeId			INT;
    
    SELECT @AuthoriseBuildIR=[cw].[fnGetWorkflowStepId]('Authorise', 'IR_Reporting_Management')
    SELECT @reportTypeId = ReportTypeId FROM cfgcw.IR_ReportType WHERE ReportTypeName = 'IR' AND IsActive =1

    SELECT
        deal.DealName
        ,ipdDt.IPD AS IPDDate
        ,ipdRun.CreatedDate  AS IPDRunDate
        ,ipdRun.CreatedBy    AS IPDInitiatedBy
        ,ipdDt.CollectionCalendarStart AS CollectionStartDate
        ,ipdDt.CollectionCalendarEnd AS CollectionENDDate
        ,ipdDt.CollectionBusinessEnd AS IpdCollectionEndDate
        ,ipdDt.PreviousIPD AS PreviousIPDDate
        ,CASE WHEN IR_Conf.UploadedFileName IS NOT NULL THEN 0 ELSE  IsNull(IR_Conf.TemplateId,0) END AS TemplateId
        ,IsNull(IR_Conf.DealIrConfigId,0) AS DealIrConfigId
        ,wla.WorkflowStepDisplayName AS IpdStatus
        ,wla.ActionedBy AS AuthorisedBy
        ,wla.ActionedDate AS AuthorisedDate
        ,ipd.IsCurrentIPD AS IsCurrentIPD 
    FROM
        [cw].[vwDealIpdDates] ipdDt
    JOIN
        cw.DealIpdRun ipdRun ON ipdRun.DealIpdId = ipdDt.DealIpdId
    JOIN
        cw.DealIpd ipd ON ipd.DealIpdId = ipdRun.DealIpdId
    JOIN
        [cw].[vw_ActiveDeal] deal ON deal.DealID = ipdDt.DealId
	LEFT JOIN 
        [cfgCW].[IR_DealIrConfig] IR_Conf ON IR_Conf.DealId=ipdDt.DealId AND IR_Conf.WorkFlowStepId= @AuthoriseBuildIR
		AND IR_Conf.ReportTypeId = @reportTypeId
    LEFT JOIN
	(
        SELECT * FROM (
            SELECT  wfp.ProcessReferenceId, wfp.ActionedBy,wfp.ActionedDate, wfs.DisplayName AS WorkflowStepDisplayName, wft.Name AS WorkflowTypeName,  
				ROW_NUMBER() OVER(PARTITION BY ProcessReferenceId, wft.WorkflowTypeId  ORDER BY ActionedDate DESC) AS RowNum 
			FROM cw.WorkflowProcess wfp
			JOIN 
                cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = wfp.WorkflowStepId
			JOIN 
                cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
			WHERE 
				ProcessReferenceId=@pDealIpdRunId 
				AND wft.Name='Deal_IPD'
            ) AS t WHERE  RowNum = 1
	) wla ON wla.ProcessReferenceId=ipdRun.RunId
    WHERE
        deal.DealId = @pDealId
        AND ipdRun.RunID = @pDealIpdRunId
        AND wla.WorkflowTypeName='Deal_IPD'
END
GO