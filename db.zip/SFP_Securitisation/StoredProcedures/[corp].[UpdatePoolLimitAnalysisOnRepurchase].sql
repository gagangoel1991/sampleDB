USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[UpdatePoolLimitAnalysisOnRepurchase]') AND type IN (N'P', N'PC'))
DROP PROCEDURE [corp].[UpdatePoolLimitAnalysisOnRepurchase]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [corp].[UpdatePoolLimitAnalysisOnRepurchase]     
(      
 @pPoolId INT      
)      
AS      
BEGIN   
BEGIN TRY
Declare @SourceDeals varchar(50);    
Declare @PoolLimiAnalysisFieldName varchar(50)    
Declare @check INT  
  
DECLARE @Temp TABLE(deals varchar(50))  
DECLARE @PoolLimitAnalysisResult TABLE(RonaCalculatedBasedOn varchar(50))  
INSERT INTO @Temp EXEC ps.getPoolSourceDeals @pPoolId   
SELECT @SourceDeals = deals from @Temp  
if(@SourceDeals != null or @SourceDeals != '')    
BEGIN    
 INSERT into @PoolLimitAnalysisResult (RonaCalculatedBasedOn)   
 (Select  RonaCalculatedBasedOn from  [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] where DealId In (    
SELECT  * from [app].[udfSplitString] (@SourceDeals,','))  
)  
SET @check = (Select (Case WHEN COUNT(Distinct RonaCalculatedBasedOn)>= 2 then 1 ELSE 0 END)  
from @PoolLimitAnalysisResult where RonaCalculatedBasedOn IN ('TotalCreditLimit','Utilisation'))  
IF(@check = 1)  
BEGIN  
SET @PoolLimiAnalysisFieldName = 'TotalCreditLimit, Utilisation'  
ENd  
ELSe if Exists(Select 1 from @PoolLimitAnalysisResult where RonaCalculatedBasedOn = 'Utilisation')  
BEGIN  
SET @PoolLimiAnalysisFieldName = 'Utilisation'  
ENd  
ELSe if Exists(Select 1 from @PoolLimitAnalysisResult where RonaCalculatedBasedOn = 'TotalCreditLimit' )  
BEGIN  
SET @PoolLimiAnalysisFieldName = 'TotalCreditLimit'  
ENd  
if(@PoolLimiAnalysisFieldName != null or @PoolLimiAnalysisFieldName != '')  
BEGIN  
Update ps.Pool   
Set PoolLimitAnalysisFieldId = (Select PoolLimitAnalysisFieldId  from ps.PoolLimitAnalysisField  
where LimitAnalysisFieldName = @PoolLimiAnalysisFieldName)  
where PoolId = @pPoolId  
END  
    
END    
   END TRY    
 BEGIN CATCH      
  DECLARE     
   @errorMessage     NVARCHAR(MAX),    
   @errorSeverity    INT,    
   @errorNumber      INT,    
   @errorLine        INT,    
   @errorState       INT;    
  SELECT     
   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()    
    
  EXEC app.SaveErrorLog 2, 1, 'UpdatePoolLimitAnalysisOnRepurchase', @errorNumber,  @errorSeverity, @errorLine, @errorMessage    
  , ''    
      
  RAISERROR (@errorMessage,    
             @errorSeverity,    
             @errorState )    
 END CATCH;    
END 