USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[spCheckAndLoadMortgageFieldData]') IS NOT NULL
BEGIN
	DROP PROCEDURE [cw].[spCheckAndLoadMortgageFieldData]
END
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [CW].[spCheckAndLoadMortgageFieldData]
/*
 * Author: Kapil Sharma
 * Date:	13.08.2021
 * Description:  This will check the mortage field data and if it is not exists it will load the data
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pAsAtDate				DATE,
@pMortgageDealId		INT = NULL,
@pUserName				VARCHAR(80) = NULL,
@pDealName				varchar(80) = NULL
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		DECLARE
			@partitionId	INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))

		IF @pDealName IS NOT NULL
			SET @pMortgageDealId = (SELECT MortgageDealId FROM CW.[vw_ActiveDeal] WHERE DealName=@pDealName )

		IF NOT EXISTS(SELECT TOP 1 * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @pMortgageDealId)
		BEGIN
			IF OBJECT_ID('tempdb..#VwMortgageFieldData')IS NOT NULL 
				DROP TABLE #VwMortgageFieldData

			SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1
			INSERT INTO #VwMortgageSubAccount   
			EXEC [sfp].[syn_SfpModel_sp_rpt_uspMortgageLoanEntity_Liability] @pAsAtDate, @pMortgageDealId, ''

			INSERT INTO [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData]
			SELECT * FROM #VwMortgageSubAccount
		END
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		SET @pUserName = ISNULL(@pUserName,  'System')
		EXEC app.SaveErrorLog 1, 1, 'spCheckAndLoadMortgageFieldData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO