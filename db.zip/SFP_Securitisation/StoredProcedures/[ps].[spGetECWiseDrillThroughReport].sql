USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetECWiseDrillThroughReport]') AND type IN (N'P', N'PC'))
DROP PROCEDURE [ps].[spGetECWiseDrillThroughReport]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
-- [ps].[spGetECWiseDrillThroughReport] 11161, 'kothpaj'
CREATE PROCEDURE [ps].[spGetECWiseDrillThroughReport]	
	@pPoolId int,
	@pUserName VARCHAR(50)	
AS
BEGIN	
	BEGIN TRY	
		IF OBJECT_ID('tempdb.dbo.#SourcePoolLoan', 'U') IS NOT NULL                                           
				DROP TABLE #SourcePoolLoan 	
		CREATE TABLE #SourcePoolLoan
		(
			LoanId INT,
			Balance DECIMAL(19,2)
		)
		INSERT INTO #SourcePoolLoan
		SELECT DISTINCT LoanId, LoanBalance AS Balance FROM ps.PoolBuildDetail WHERE poolid = @pPoolId AND IsActive = 1
		UNION
		SELECT DISTINCT LoanId, LoanBalance AS Balance FROM ps.PoolEligibilityBuildDetail WHERE poolid = @pPoolId 

		DECLARE @SourcePoolCount INT
		DECLARE @SourcePoolBalance DECIMAL(19,2)
		
		SELECT @SourcePoolCount = COUNT(DISTINCT LoanId), @SourcePoolBalance=SUM(Balance) FROM #SourcePoolLoan				
		
		SELECT 			
			ec.Name, 
			@SourcePoolCount- COUNT(DISTINCT LoanId)  AS TotalPassCount,
			COUNT(DISTINCT LoanId) AS TotalFailCount, 
			@SourcePoolBalance-SUM(LoanBalance) AS TotalPassBalance,
			SUM(LoanBalance) AS TotalFailBalance		
		FROM ps.PoolEligibilityBuildDetail  pebd 
		INNER JOIN ps.EligibilityCriteria ec
			ON pebd.EligibilityCriteriaId = ec.EligibilityCriteriaId
		WHERE poolid = @pPoolId AND status = 0			
		GROUP BY  ec.Name

		SELECT 
			NumberOfAccount, 
			CASE WHEN TrueBalance = 0 THEN CapitalBalance ELSE TrueBalance END AS Balance,
			@SourcePoolCount AS TotalAccount,
			@SourcePoolBalance AS TotalBalance
		FROM PS.Pool
		WHERE PoolId = @pPoolId	

  --CT Summary
	SELECT   ct.CriteriaName AS ConcentrationCriteria,
   			 ct.LimitPercentage AS ThreshholdValue,
			 pctDetail.ResultPercent AS PoolConcentrationValue,
			 IIF(pctDetail.ResultStatus=0,'Fail','Pass') AS [Status]
	FROM	ps.Pool pl                                             
			INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = 1
			INNER JOIN ps.PoolCTDetail pctDetail ON pctDetail.PoolCTMapId = ctMap.PoolCTMapId
			INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1
			WHERE pl.PoolId = @pPoolId AND
			pctDetail.PoolCTDetailId IN (SELECT MAX(PoolCTDetailId) FROM ps.PoolCTDetail GROUP BY PoolCTMapId)

   END TRY
	BEGIN CATCH		
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;
		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 2, 1, 'spGetECWiseDrillThroughReport', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH;
END
GO
