USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spCalculateProvisionalAmount]') IS NOT NULL
	DROP PROCEDURE [cb].[spCalculateProvisionalAmount]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

Create PROC [cb].[spCalculateProvisionalAmount] 
(
 /* 
  Author: Aditya Shrivastava 
  Date:  29.06.2022 
  Description:  Calculate override sql of Provisional Amount for a  line item (e)  of RPP
       
  Change History 
  -------------- 
  Code		Author    Date			Description 
  ------------------------------------------------------- 

  DECLARE @ret_value DECIMAL(38,16)
  EXEC cb.spCalculateProvisionalAmount 66,'fm\shriyad' ,@ret_value  OUTPUT
  SELECT @ret_value   
        
  */ 
@pDealIpdRunId INT,
@pUserName	VARCHAR(80),
@oValue DECIMAL(38,16) OUTPUT
)
AS
BEGIN
		BEGIN TRY
		--DECLARE @pDealIpdRunId INT = 130, @pUserName	VARCHAR(80),@oValue DECIMAL(38,16) 

		DECLARE @tempDealNoteId      INT,
		@MaturityDate date,
		@CurrentIpdDate date,
		@DealId int,
		@IpdDateToCalculateProvisionalAmount date,
		@TotalAmount decimal(38,16)=0;

		SELECT @CurrentIpdDate = IpdDate, @DealId = DealId
		from cw.vwDealIpdRun 
		where DealIpdRunId = @pDealIpdRunId 

	  SET @tempDealNoteId =(SELECT TOP 1 DealNoteId 
                                FROM   cfgcb.DealNote dn
                                WHERE DealId = @dealId 
								AND ValidFrom<=GETDATE() AND ValidTo>=GETDATE()
                                ORDER  BY DealNoteId ASC) 

		 WHILE( @tempDealNoteId > 0 ) 
            BEGIN 

				select @MaturityDate = ISNULL(NewRedemptionDate, MaturityDate) 
				from cfgcb.DealNote where DealNoteId=@tempDealNoteId

				IF EXISTS(SELECT TOP 1 * FROM cfgcb.DealNote WHERE DealNoteId=@tempDealNoteId AND NewRedemptionIpd IS NOT NULL)
				BEGIN
					SET @IpdDateToCalculateProvisionalAmount = (SELECT NewRedemptionIpd FROM cfgcb.DealNote
																WHERE DealNoteId=@tempDealNoteId)
				END
				ELSE
				BEGIN
					SET @IpdDateToCalculateProvisionalAmount = cw.fnGetBusinessDate(datefromparts(year(DATEADD(month, -1, @MaturityDate)), month(DATEADD(month, -1, @MaturityDate)),22),'UK',0,0) 				
				END

				IF(@IpdDateToCalculateProvisionalAmount IS NOT NULL AND @MaturityDate IS NOT NULL)
				begin
					if(@IpdDateToCalculateProvisionalAmount=@CurrentIpdDate)
					begin
						SELECT @TotalAmount = @TotalAmount + cast(RateForEstimation as float)
						*  (DATEDIFF(day, @IpdDateToCalculateProvisionalAmount, @MaturityDate)/convert(decimal(38,16),365))
						* cast(PrincipalOutstanding_GBP  as float)
						FROM cb.DealNote_Wf 
						WHERE DealIpdRunId = @pDealIpdRunId
						and DealNoteId = @tempDealNoteId 
					end
				end


			  SET @tempDealNoteId =(SELECT TOP 1 DealNoteId 
											FROM   cfgcb.DealNote dn
											WHERE DealId = @dealId 
											AND ValidFrom<=GETDATE() AND ValidTo>=GETDATE()
											AND DealNoteId > @tempDealNoteId 
											ORDER  BY DealNoteId ASC)
			END 

			--select @TotalAmount

			SELECT @oValue = @TotalAmount;
		END TRY
		BEGIN CATCH
			DECLARE 
				@errorMessage     NVARCHAR(MAX),
				@errorSeverity    INT,
				@errorNumber      INT,
				@errorLine        INT,
				@errorState       INT;

			SELECT 
				@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

			EXEC app.SaveErrorLog 1, 1, 'spCalculateProvisionalAmount', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
			RAISERROR (@errorMessage,
				 @errorSeverity,
				 @errorState )
		END CATCH


	END

GO