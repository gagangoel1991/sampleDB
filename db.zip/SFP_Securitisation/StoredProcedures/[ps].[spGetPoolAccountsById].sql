USE [SFP_Securitisation]
GO


-- exec [ps].[spGetPoolAccountsById] 825, '1,8', '2023-02-28', 'kumasdt'
IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[ps].[spGetPoolAccountsById]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [ps].[spGetPoolAccountsById]
	
GO

CREATE PROCEDURE [ps].[spGetPoolAccountsById]
 @poolId INT,    
 @dealKey Varchar(50),    
 @vintageDate DATE,    
 @pUserName VARCHAR(50)    
AS    
BEGIN    
 BEGIN TRY    
  DECLARE @vintageDate1 DATE, @vintageDate2 DATE    
    
  Declare @date1 DATE = EOMONTH(DATEADD(m, -1, @vintageDate))    
  Declare @prevDate DATE = [cw].[fnGetBusinessDate] (EOMONTH(@date1), 'UK', 0, 1)    
    
  SELECT @vintageDate1 = @vintageDate, @vintageDate2 = @prevDate    
    
  DECLARE @CompletePoolStatusId INT    
  SELECT @CompletePoolStatusId = PoolStatusId From PS.PoolStatus WHERE Status = 'Complete'    

  DECLARE @PoolPurpose INT    
  SELECT @PoolPurpose = PoolPurposeId From PS.Pool WHERE PoolId = @poolId   
    
  -- Check if pool is in draft state    
  DECLARE @isPoolInDraftState BIT    
  SELECT @isPoolInDraftState =     
   CASE     
    WHEN PS.Status NOT IN ('Authorised', 'Lock', 'Complete') THEN 1    
    ELSE 0    
   END    
  FROM PS.Pool P JOIN PS.PoolStatus PS On P.PoolStatusId = PS.PoolStatusId    
  WHERE P.PoolId = @poolId    
    
  IF OBJECT_ID('tempdb.dbo.#OutputValues', 'U') IS NOT NULL                        
   DROP TABLE #OutputValues    
    
  CREATE TABLE #OutputValues (  
   [DealId] Int NULL,
   [DealName] VARCHAR(100) NULL,
   [EligibilityCriteria] VARCHAR(max) NULL,
   [FacilityId] [varchar](100) COLLATE Latin1_General_CI_AS NULL,    
   [CIS] [varchar](200) COLLATE Latin1_General_CI_AS NULL,    
   [MasterGradingScore] [varchar](10) COLLATE Latin1_General_CI_AS NULL,    
   [FacilityType] [varchar](100) COLLATE Latin1_General_CI_AS NULL,    
   [CommittedExposure] [decimal](15, 2) NULL,    
   [FacilityStartDate] [date] NULL,    
   [ExpiryDate] [date] NULL,    
   [PreviousExpiryDate] [date] NULL,    
   [PreviousMasterGradingScore] [varchar](10) COLLATE Latin1_General_CI_AS NULL,    
   [MaturityDate] [date] NULL,    
   [PDMidPoint] [decimal](7, 6) NULL,    
   [NumberOfDaysInArrears] [int] NULL,    
   [PreviousReasonId] Int NULL,    
   [PreviousReasonValue] VARCHAR(200) NULL,    
   [CurrentReasonId] Int NULL,    
   [CurrentReasonValue] VARCHAR(200) NULL,   
   [UtilisationGBP] [DECIMAL](21,2) NULL,
   [IsActive] BIT    
  )    
    
    
  IF OBJECT_ID('tempdb.dbo.#Reasons', 'U') IS NOT NULL    
   DROP TABLE #Reasons    
    
  SELECT CAST(LookUpValue AS INT) AS PoolInclusionReasonID, LookUpValueDescription AS InclusionReason    
  INTO #Reasons    
  FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]     
  WHERE ReportTemplateName = 'CHERRYPICK' AND LookUpName = 'InclusionReasons'   
  

  IF OBJECT_ID('tempdb.dbo.#CherryPickState', 'U') IS NOT NULL    
   DROP TABLE #CherryPickState    
    
    Select CASE WHEN P.IsActive = 0 THEN F.CurrentIsActiveState ELSE P.IsActive END AS IsActive, LoanId, DealID   
	INTO #CherryPickState 
	FROM ps.PoolBuildDetail P LEFT Join PS.PoolFacilityCherryPickState F
    ON P.PoolId = F.PoolID AND P.LoanId = F.FacilityID
	WHERE P.PoolId = @poolId   

  -- Get the details for     
  DECLARE @ReqCols1 XML, @ReqCols2 XML, @RowID1 VARCHAR(100), @RowID2 Varchar(100)    
  SELECT @ReqCols1 = (    
   select CriteriaFieldName from (     
    SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName      
	FROM ps.EligibilityCriteriaField       
    WHERE AssetClassId = 2    
    AND CriteriaFieldSql IN (    
					'FacilityId', 'CIS', 'FacilityType', 'CommittedExposure', 'FacilityStartDate', 'ExpiryDate', 'MaturityDate', 'PDMidPoint', 'NumberOfDaysInArrears', 'MasterGradingScore', 'DaysInExcess','UtilisationGBP_ReportingDate'
    )     
    UNION    
    SELECT 'FacilityStartDate' AS CriteriaFieldName    
    UNION    
    SELECT 'DealName' AS CriteriaFieldName    
   ) A    
   FOR XML PATH('Node'), ROOT('Root')    
  )

  DECLARE @XmlData XML = NULL
	SELECT @XmlData = ( SELECT LoanId AS FacilityKey  FROM ps.poolbuilddetail    
  WHERE  poolId = @poolId   FOR XML PATH('Node'), ROOT('Root'))    
    
	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
    @VintageDate = @vintageDate1, 
    @DealKey = @dealKey, 
    @FacilityIds = NULL, 
    @ReqColumns	 = @ReqCols1,
    @XmlData = @XmlData, 
    @OutputRowID = @RowID1 OUTPUT
    
  -- Get the details for the previous month    
  SELECT @ReqCols2 = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName      
         FROM ps.EligibilityCriteriaField       
         WHERE AssetClassId = 2    
         AND CriteriaFieldSql IN ('FacilityId', 'ExpiryDate', 'MasterGradingScore')     
         FOR XML PATH('Node'), ROOT('Root')    
          )    
    
	EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity] 
    @VintageDate = @vintageDate2, 
    @DealKey = @dealKey, 
    @FacilityIds = NULL, 
    @ReqColumns	 = @ReqCols2,
    @XmlData = @XmlData, 
    @OutputRowID = @RowID2 OUTPUT
    
   INSERT INTO #OutputValues (FacilityId,DealName)
    SELECT DISTINCT FacilityId, DealName    
   FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] S WHERE RowId = @RowID1   

  UPDATE O1     
  SET
   O1.FacilityType = S1.FacilityType,    
   O1.CIS = S1.CIS,    
   O1.MasterGradingScore = S1.MasterGradingScore,    
   O1.CommittedExposure = S1.CommittedExposure,    
   O1.FacilityStartDate = S1.FacilityStartDate,    
   O1.ExpiryDate = S1.ExpiryDate,    
   O1.MaturityDate = S1.MaturityDate,    
   O1.PDMidPoint = S1.PDMidPoint,    
   O1.NumberOfDaysInArrears = S1.NumberOfDaysInArrears, 
   O1.UtilisationGBP = S1.UtilisationGBP_ReportingDate
  FROM (    
   SELECT DISTINCT FacilityId, FacilityType, CIS, MasterGradingScore, CommittedExposure, FacilityStartDate, 
   ExpiryDate, MaturityDate, PDMidPoint, NumberOfDaysInArrears,UtilisationGBP_ReportingDate    
   FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] S WHERE RowId = @RowID1    
   --AND EXISTS (SELECT 1 FROM #OutputValues O WHERE O.FacilityId = CAST(S.FacilityId AS VARCHAR(100)) COLLATE Latin1_General_CI_AS)    
  ) S1    
  Join #OutputValues O1 On CAST(S1.FacilityId AS VARCHAR(100)) COLLATE Latin1_General_CI_AS = O1.FacilityId    
    
	Update O
	SET O.DealId = C.DealId
	FROM #OutputValues O INNER JOIN [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] C ON O.DealName = C.DealName
	where O.DealName = C.DealName
	
   UPDATE O
   SET O.IsActive = S.IsActive
   From(Select IsActive, LoanId, DealId from #CherryPickState) S
   Join #OutputValues O On  O.FacilityId = CAST(S.LoanId AS VARCHAR(100)) COLLATE Latin1_General_CI_AS
   AND (O.DealId = S.DealID OR S.DealID is NULL)
	

	DECLARE @ApplicableECMethod INT
	SELECT @ApplicableECMethod= ApplicableECMethod FROM ps.Pool WHERE PoolId = @poolId 
	
	IF (@ApplicableECMethod = 2) 
	BEGIN 
		IF OBJECT_ID('tempdb.dbo.#Res', 'U') IS NOT NULL
		DROP TABLE #Res;
		CREATE TABLE #Res (poolId int, LoanId BIGINT, EligibilityCriteriaId Int) 
		
		IF OBJECT_ID('tempdb.dbo.#Res1','U') IS NOT NULL
		DROP TABLE #Res1;

		CREATE TABLE #Res1 (LoanId BIGINT, EligibilityCriteria Varchar(MAX))

		INSERT INTO #Res
		SELECT DISTINCT pm.poolId,loanId,pm.eligibilityCriteriaId FROM [ps].[PoolBuildDetail]  ped
		JOIN ps.PoolEcMap pm ON ped.poolId = pm.poolId and pm.IsActive = 1 
		WHERE pm.poolID = @poolId
		EXCEPT
		SELECT DISTINCT poolId,loanId,eligibilityCriteriaId FROM [ps].[PoolEligibilityBuildDetail]
		WHERE poolID = @poolId AND status = 0

		INSERT INTO #Res1
		SELECT DISTINCT loanId,
                EligibilityCriteria = stuff(
                                              (SELECT DISTINCT ', ' + ec.Name
                                               FROM PS.EligibilityCriteria EC
                                               INNER JOIN #Res r ON Ec.EligibilityCriteriaId = r.EligibilityCriteriaId
                                               WHERE r.LoanId = r1.LoanId
                                                 FOR XML PATH(''),
                                                         TYPE).value('.', 'NVARCHAR(MAX)') ,
                                                               1,
                                                               1,
                                                               '')
		FROM #Res r1

		UPDATE O4
		SET EligibilityCriteria = r.EligibilityCriteria
		FROM #OutputValues O4
		INNER JOIN #Res1 r ON O4.FacilityId = r.LoanId 
	END
	IF (@ApplicableECMethod = 1) 
	BEGIN
		UPDATE O5
		SET EligibilityCriteria = 'All'
		FROM #OutputValues O5
	END

  Update O2     
  Set O2.PreviousExpiryDate = S2.ExpiryDate,    
   O2.PreviousMasterGradingScore = S2.MasterGradingScore    
  From (    
   SELECT DISTINCT FacilityId, ExpiryDate, MasterGradingScore      
   FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] S WHERE RowId = @RowID2    
   --And Exists (Select 1 From #OutputValues O Where O.FacilityId = CAST(S.FacilityId AS varchar(100)) COLLATE Latin1_General_CI_AS)    
  ) S2    
  Join #OutputValues O2 On CAST(S2.FacilityId AS varchar(100)) COLLATE Latin1_General_CI_AS = O2.FacilityId    
    
  -- If the pool is not in draft state, we should not get any current reason    
  IF @isPoolInDraftState = 0    
  BEGIN    
   UPDATE O3    
   SET O3.PreviousReasonId = S3.PoolInclusionReasonID,    
    O3.PreviousReasonValue = PIR.InclusionReason,    
    O3.IsActive = S3.CurrentIsActiveState    
   FROM (    
    SELECT PFS.FacilityID AS FacilityID, DealId,     
        FIRST_VALUE(PFS.PoolInclusionReasonID) OVER (PARTITION BY FacilityId, DealID ORDER BY PoolAccountStateID DESC) AS PoolInclusionReasonID,    
        FIRST_VALUE(PFS.CurrentIsActiveState) OVER (PARTITION BY FacilityId, DealID ORDER BY PoolAccountStateID DESC) AS CurrentIsActiveState    
      FROM PS.PoolFacilityCherryPickState PFS    
      Join PS.Pool P On PFS.PoolID = P.PoolID And PFS.IsActive = 1 And P.IsActive = 1 AND P.PoolStatusId = @CompletePoolStatusId   
     WHERE DealID IN (SELECT  * from [app].[udfSplitString] (@dealKey,','))   
       AND PFS.PoolId = @poolId    
       AND PFS.IsActive = 1    
   ) S3    
   LEFT JOIN #Reasons PIR ON S3.PoolInclusionReasonID = PIR.PoolInclusionReasonID    
   JOIN #OutputValues O3 ON CAST(S3.FacilityId AS VARCHAR(100)) COLLATE Latin1_General_CI_AS = O3.FacilityId  AND  S3.DealId = O3.DealId 
  END    
  ELSE    
  BEGIN    
   UPDATE O3    
   SET O3.CurrentReasonId = S3.PoolInclusionReasonID,    
    O3.CurrentReasonValue = PIR.InclusionReason,    
    O3.IsActive = S3.CurrentIsActiveState    
   FROM (    
    SELECT PFS.FacilityID as FacilityID, DealId,    
        FIRST_VALUE(PFS.PoolInclusionReasonID) OVER (PARTITION BY FacilityId, DealID ORDER BY PoolAccountStateID DESC) AS PoolInclusionReasonID,    
        FIRST_VALUE(PFS.CurrentIsActiveState) OVER (PARTITION BY FacilityId, DealID ORDER BY PoolAccountStateID DESC) AS CurrentIsActiveState    
      FROM PS.PoolFacilityCherryPickState PFS    
     WHERE DealID IN (SELECT  * from [app].[udfSplitString] (@dealKey,','))    
       AND PFS.PoolId = @poolId    
       AND PFS.IsActive = 1    
   ) S3    
   LEFT JOIN #Reasons PIR ON S3.PoolInclusionReasonID = PIR.PoolInclusionReasonID    
   JOIN #OutputValues O3 ON CAST(S3.FacilityId AS VARCHAR(100)) COLLATE Latin1_General_CI_AS = O3.FacilityId  AND  S3.DealId = O3.DealId
    
   UPDATE O3    
   SET O3.PreviousReasonId = S3.PoolInclusionReasonID,    
    O3.PreviousReasonValue = PIR.InclusionReason    
   FROM (    
    SELECT PFS.FacilityID AS FacilityID, DealId,    
        FIRST_VALUE(PFS.PoolInclusionReasonID) OVER (PARTITION BY FacilityId, DealID ORDER BY PoolAccountStateID DESC) AS PoolInclusionReasonID    
      FROM PS.PoolFacilityCherryPickState PFS    
      Join PS.Pool P On PFS.PoolID = P.PoolID And PFS.IsActive = 1 And P.IsActive = 1 AND P.PoolStatusId = @CompletePoolStatusId    
 WHERE DealID IN (SELECT  * from [app].[udfSplitString] (@dealKey,','))    
       AND PFS.PoolId <> @poolId    
       AND PFS.IsActive = 1    
   ) S3    
   LEFT JOIN #Reasons PIR ON S3.PoolInclusionReasonID = PIR.PoolInclusionReasonID    
   JOIN #OutputValues O3 ON CAST(S3.FacilityId AS VARCHAR(100)) COLLATE Latin1_General_CI_AS = O3.FacilityId   AND  S3.DealId = O3.DealId 
  End    

   UPDATE #OutputValues 
   SET DealName = CASE WHEN @PoolPurpose = 2 THEN 'No Deal' ELSE DealName END, DealId = CASE WHEN @PoolPurpose = 2 THEN -1 ELSE DealId END
 


  SELECT distinct    
   CAST(FacilityId AS INT) FacilityId,
   DealId,
   DealName,
   EligibilityCriteria,
   CIS,    
   MasterGradingScore,    
   FacilityType,  
   UtilisationGBP,
   CommittedExposure,     
   FacilityStartDate,     
   ExpiryDate,    
   PreviousExpiryDate,    
   PreviousMasterGradingScore,    
   MaturityDate,     
   PDMidPoint,    
   NumberOfDaysInArrears,     
   PreviousReasonId,     
   PreviousReasonValue,     
   CurrentReasonId,     
   CurrentReasonValue,     
   IsActive     
  FROM #OutputValues    
  ORDER BY 1    
    
  DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID1    
  --Delete From [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID2    
 END TRY    
 BEGIN CATCH    
  DECLARE     
   @errorMessage     NVARCHAR(MAX),    
   @errorSeverity    INT,    
   @errorNumber      INT,    
   @errorLine        INT,    
   @errorState       INT;    
  SELECT     
   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()    
    
  EXEC app.SaveErrorLog 2, 1, 'spGetPoolAccountsById', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName    
        
  RAISERROR (@errorMessage,    
             @errorSeverity,    
             @errorState )    
 END CATCH    
END
GO
