USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetStratTemplate]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetStratTemplate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROCEDURE [cw].[spGetStratTemplate]
/*
 * Author: Kapil Sharma
 * Date:	14.12.2020
 * Description:  This will return the Strat Template single record based on id
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/		
@pStratTemplateId		INT,
@pUserName				VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		
		SELECT 
			st.StratTemplateId,
			st.Name AS [Name],
			st.Description,
			STUFF((
				SELECT DISTINCT ', ' + CAST(strat.StratId AS VARCHAR)
				FROM cfgcw.IR_Strat strat
				JOIN cfgcw.IR_StratTemplateMap stm ON strat.StratId = stm.StratId
				WHERE 
					stm.StratTemplateId = ST.StratTemplateId
				FOR XML PATH('')), 1, 2, '') AS ConcatenatedStratList,
			CASE WHEN ISNULL(st.IsLocked, 0) = 1 THEN 'Locked' ELSE 'Active' END AS Status
		FROM
			cfgCW.IR_StratTemplate st
		WHERE
			st.StratTemplateID = @pStratTemplateId
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetStratTemplate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
