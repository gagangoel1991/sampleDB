USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spRunCBMCResult]') IS NOT NULL
	DROP PROCEDURE [cb].[spRunCBMCResult]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cb].[spRunCBMCResult]
/*
Author: Suresh Pandey
Date:	07.06.2022
Description:   

Example - 
[cb].[spRunCBMCResult] 56, 'System'	
Change History
--------------
Author		Date		Description
-------------------------------------------------------
*/
@pDealIpdRunId				INT,
@pUserName					VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
	
		DECLARE
			@dealId						INT,
			@testTypeId					INT,
			@collectionCalendarStart	DATE,
			@collectionCalendarEnd		DATE,
			@ipdStartDate				DATE,
			@ipdEndDate					DATE,
			@dealIpdId					INT,
			@ipdDate					DATE,
			@numberOfDaysInYear			INT,
			@lineItemCode				VARCHAR(200),
			@compoundingPeriod			INT,
			@ipdPeriod					INT,			 
			@testResult					VARCHAR(40) = 'N/A',
			@createdBy					VARCHAR(80) = 'System',
			@createdDate				DATETIME = GETDATE()

		 
			SELECT  
				@dealId = di.DealId, 
				@ipdStartDate = did.PreviousIPD, 
				@ipdEndDate = did.IPD,
				@dealIpdId = di.DealIpdId, 
				@ipdDate = di.IpdDate,
				@collectionCalendarStart = did.CollectionCalendarStart,
				@collectionCalendarEnd = did.CollectionCalendarEnd
			FROM cw.DealIpd di
			JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
			JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
			WHERE dir.RunId	= @pDealIpdRunId AND dir.IsCurrentVersion = 1
			 
			DECLARE @tblTestLineItemValue TABLE(TestLineItemId INT, LineItemCode VARCHAR(200), LineItemValue VARCHAR(100))
		
			SELECT @testTypeId = TestTypeID FROM cfgcb.TestType WHERE InternalName = 'CBMC'

			SET @compoundingPeriod =( SELECT SUM(DATEDIFF(DAY, AccrualStartDate , AccrualEndDate)) 
											FROM cb.SoniaCompoundingRate WHERE ResetDate >=  @collectionCalendarStart AND ResetDate <= @collectionCalendarEnd)
			SET @ipdPeriod = (SELECT DATEDIFF(DAY,  @ipdStartDate,@ipdEndDate))



			SELECT 
				ds.SwapName, 
				dswf.PayNotional,
				dswf.PayAmount,
				dswf.ReceiveRate- dswf.ReceiveBaseRate AS SwapReceiveMargins 
			INTO #dealSwap 
			FROM cfgcb.DealSwap ds
			JOIN cb.DealSwap_Wf dswf 
				ON dswf.DealSwapId=ds.DealSwapId
			WHERE DealIpdRunId=@pDealIpdRunId

			 
			---- Total IRS Notional Balances ----------------
			DECLARE @totalIRSNotionalBalances decimal(36,16)
					,@totalIRSNotionalBalances_Fixed decimal(36,16)
					,@totalIRSNotionalBalances_Tracker decimal(36,16)
					,@totalIRSNotionalBalances_Variable decimal(36,16)

			SET @lineItemCode = 'TotalIRSNotionalBalances'
			SET @totalIRSNotionalBalances = (SELECT SUM(PayNotional) FROM #dealSwap)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalIRSNotionalBalances AS VARCHAR(40)) )

			SET @lineItemCode = 'TotalIRSNotionalBalances_Fixed'
			SET @totalIRSNotionalBalances_Fixed = (SELECT PayNotional FROM #dealSwap WHERE SwapName='Fixed' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalIRSNotionalBalances_Fixed AS VARCHAR(40)) ) 

			SET @lineItemCode = 'TotalIRSNotionalBalances_Tracker'
			SET @totalIRSNotionalBalances_Tracker = (SELECT PayNotional FROM #dealSwap WHERE SwapName='Tracker' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalIRSNotionalBalances_Tracker AS VARCHAR(40)) ) 

			SET @lineItemCode = 'TotalIRSNotionalBalances_Variable'
			SET @totalIRSNotionalBalances_Variable = (SELECT PayNotional FROM #dealSwap WHERE SwapName='Variable' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalIRSNotionalBalances_Variable AS VARCHAR(40)) ) 

			---- Total Interest rate swap Payments ----------------
			DECLARE @totalInterestRateSwapPayments decimal(36,16)
					,@totalInterestRateSwapPayments_Fixed decimal(36,16)
					,@totalInterestRateSwapPayments_Tracker decimal(36,16)
					,@totalInterestRateSwapPayments_Variable decimal(36,16)

			SET @lineItemCode = 'TotalInterestRateSwapPayments'
			SET @totalInterestRateSwapPayments = (SELECT SUM(PayAmount) FROM #dealSwap)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalInterestRateSwapPayments AS VARCHAR(40)) )

			SET @lineItemCode = 'TotalInterestRateSwapPayments_Fixed'
			SET @totalInterestRateSwapPayments_Fixed = (SELECT PayAmount FROM #dealSwap WHERE SwapName='Fixed' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalInterestRateSwapPayments_Fixed AS VARCHAR(40)) ) 

			SET @lineItemCode = 'TotalInterestRateSwapPayments_Tracker'
			SET @totalInterestRateSwapPayments_Tracker = (SELECT PayAmount FROM #dealSwap WHERE SwapName='Tracker' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalInterestRateSwapPayments_Tracker AS VARCHAR(40)) ) 

			SET @lineItemCode = 'TotalInterestRateSwapPayments_Variable'
			SET @totalInterestRateSwapPayments_Variable = (SELECT PayAmount FROM #dealSwap WHERE SwapName='Variable' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(@totalInterestRateSwapPayments_Variable AS VARCHAR(40)) ) 

			
			---- Average Swap Receipt Margins ----------------
			DECLARE @averageSwapReceiptMargins decimal(36,16)
					,@averageSwapReceiptMargins_Fixed decimal(36,16)
					,@averageSwapReceiptMargins_Tracker decimal(36,16)
					,@averageSwapReceiptMargins_Variable decimal(36,16)

			SET @lineItemCode = 'AverageSwapReceiptMargins'
			SET @averageSwapReceiptMargins = (SELECT AVG(SwapReceiveMargins) FROM #dealSwap)
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@averageSwapReceiptMargins AS decimal(18, 4)) AS VARCHAR)  + '%')

			SET @lineItemCode = 'AverageSwapReceiptMargins_Fixed'
			SET @averageSwapReceiptMargins_Fixed = (SELECT SwapReceiveMargins FROM #dealSwap WHERE SwapName='Fixed' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@averageSwapReceiptMargins_Fixed AS decimal(18, 4))AS VARCHAR)  + '%') 

			SET @lineItemCode = 'AverageSwapReceiptMargins_Tracker'
			SET @averageSwapReceiptMargins_Tracker = (SELECT SwapReceiveMargins FROM #dealSwap WHERE SwapName='Tracker' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@averageSwapReceiptMargins_Tracker AS decimal(18, 4))AS VARCHAR)  + '%') 

			SET @lineItemCode = 'AverageSwapReceiptMargins_Variable'
			SET @averageSwapReceiptMargins_Variable = (SELECT SwapReceiveMargins FROM #dealSwap WHERE SwapName='Variable' )
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@averageSwapReceiptMargins_Variable AS decimal(18, 4))AS VARCHAR)  + '%') 

			----- DerivedPayMargin ----------------
			DECLARE @derivedPayMargin decimal(36,16)
					,@soniaCompoundingDuringCollectionPeriod decimal(36,16)
					,@rate  decimal(36,16)

			SET @rate = (SELECT EXP(SUM(log(rate))) from cb.SoniaCompoundingAccrualRate 
							WHERE SoniaCompoundingRateId IN (SELECT SoniaCompoundingRateId  FROM cb.SoniaCompoundingRate WHERE ResetDate >=  @collectionCalendarStart AND ResetDate <= @collectionCalendarEnd)
								AND AccrualBasisTypeId =14)
 
			SET @numberOfDaysInYear = IIF((SELECT [cb].[fnIsLeapYear](DATEPART(YEAR,@ipdDate))) = 1, 366,365) 
			
		     

			SET @lineItemCode = 'SoniaCompoundingDuringCollectionPeriod'
			SET @soniaCompoundingDuringCollectionPeriod = (SELECT (@rate - 1) * (@numberOfDaysInYear / CAST(@compoundingPeriod AS FLOAT)))
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@soniaCompoundingDuringCollectionPeriod  * 100 AS decimal(18, 4))AS VARCHAR)  + '%') 
			
			SET @lineItemCode = 'DerivedPayMargin'
			
			SET @derivedPayMargin = @totalInterestRateSwapPayments / @ipdPeriod  *  @numberOfDaysInYear /  @totalIRSNotionalBalances  - @soniaCompoundingDuringCollectionPeriod 
			INSERT INTO @tblTestLineItemValue(LineItemCode, LineItemValue) VALUES(@lineItemCode, CAST(CAST(@derivedPayMargin  * 100 AS decimal(18, 4))AS VARCHAR)  + '%') 
		
			 
			----------Now insert the test line item into the main table

			--First update the TestLineItemId in the table variable
			UPDATE tbl SET tbl.TestLineItemId = tli.TestLineItemId
			FROM  @tblTestLineItemValue tbl
			JOIN cfgcb.TestLineItem tli ON tli.InternalName = tbl.LineItemCode
			JOIN cfgcb.TestType tt ON tt.TestTypeID = tli.TestTypeID
			WHERE tt.TestTypeID = @testTypeId

			--Now merge the line item values into main table
			MERGE cb.TestLineItemValue AS trg
			USING @tblTestLineItemValue AS src
			ON src.TestLineItemId = trg.TestLineItemId AND trg.DealIpdrunId = @pDealIpdRunId
			WHEN NOT MATCHED BY Target THEN
				INSERT (TestLineItemID, DealIpdRunId, [Value], IsActive, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)
				VALUES (src.TestLineItemId, @pDealIpdRunId, src.LineItemValue, 1, @createdBy, @createdDate, @createdBy, @createdDate)
			WHEN MATCHED THEN UPDATE SET
				trg.[Value]	= src.LineItemValue;

			---Save the test result 
			EXEC [cb].[spSaveDealIpdTestResult] @pDealIpdRunId, @testTypeId, @testResult, @pUserName
		 
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spRunCBMCResult', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
