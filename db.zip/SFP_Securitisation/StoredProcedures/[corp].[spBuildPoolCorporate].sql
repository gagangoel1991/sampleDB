USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spBuildPoolCorporate]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spBuildPoolCorporate]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
	DECLARE @RETURN INT
	EXEC [corp].[spBuildPoolCorporate] 479 
*/

CREATE PROCEDURE [corp].[spBuildPoolCorporate] 
(    
 @PoolID INT,                                    
 @UserName VARCHAR(50) = '',                                
 @IsDebug BIT = 0,         
 @pRowId VARCHAR(36) = NULL,
 @pRowIdForCT VARCHAR(36) = NULL,         
 @ReturnValue INT = 1 OUTPUT  
)      
AS                                             
BEGIN    
  
	 DECLARE @StartTime datetime = GETUTCDATE()  
	 DECLARE @Query NVARCHAR(MAX) = ''  
	 DECLARE @poolSourcingTypeId INT    
	 DECLARE @CurrentDateTime DATETIME = GETUTCDATE();    
	 DECLARE @BrandKey VARCHAR(100) = ''  
	 DECLARE @ECSelectColumn VARCHAR(MAX) = ''  
	 DECLARE @ECID VARCHAR(2000) = ''  
	 DECLARE @UnPivotSql VARCHAR(MAX) = N''
	 DECLARE @ApplicableECMethod INT = 1
	 DECLARE @PoolPurposeId INT
	 DECLARE @AssetClassId INT 
  
	 --Once LimitAnalysis field will be saved it will be fetched dynamically from table  
	 DECLARE @LimitAnalysisField VARCHAR(200) = ''  
	 DECLARE @PoolLimitAnalysisFieldId INT  
	 DECLARE @AddECColumn VARCHAR(MAX)  
  
	 /*Declarations for Concentration Test Starts*/  
	 DECLARE @CTSelectColumn VARCHAR(MAX) = ''   
	 DECLARE @CTID VARCHAR(2000) = ''  
	 DECLARE @UnPivotCTResult VARCHAR(MAX) = N''  
	 DECLARE @CTEvalQuery VARCHAR(MAX) = N''   
	 DECLARE @CTEResultQuery VARCHAR(MAX) = N''  
	 DECLARE @CTStatus VARCHAR(10) = 'Fail' --setting default status to Fail so that code can atleast run for one time.  
	 DECLARE @CTRunCount INT = 1  
	 DECLARE @CTRemarks VARCHAR(100) = ''  
	 /*Declarations for Concentration Test Ends*/  
  
	 /*Declarations for Updating Pool Starts*/  
	 DECLARE @PoolBalance DECIMAL(19,2)  
	 DECLARE @NumberOfAccount INT  
	 DECLARE @NumberOfSubAccount INT  
	 DECLARE @VintageDate VARCHAR(20)  
	 DECLARE @PoolApplyExclusion BIT  
	 DECLARE @PartitionKey VARCHAR(20)  
	 /*Declarations for Updating Pool Starts*/  
	 DECLARE @TargetPool INT = NULL
	 Declare @IsFacilitySharingAllowed Varchar(10)
	 DECLARE @IsBalanceUploaded BIT = 0
	 DECLARE @FacilityIds1 corp.FacilityList

	 SELECT @VintageDate = REPLACE(CONVERT(VARCHAR, VintageDate, 106) , ' ', '-'), 
			@PoolApplyExclusion = ISNULL(PoolApplyExclusion,1), 
			@PartitionKey = CONVERT(VARCHAR, VintageDate, 112),
			@PoolPurposeId = PoolPurposeId,
			@poolSourcingTypeId  = SourcingTypeId,
			@AssetClassId  = AssetClassId,
			@IsBalanceUploaded = IsBalanceUploaded   
	FROM PS.Pool
	WHERE PoolId= @PoolID 

	--SELECT @VintageDate = '30-Jun-2022', @PartitionKey = '20220630'

	DECLARE @DealKey VARCHAR(500),@PoolKey VARCHAR(500)

	SELECT @DealKey = COALESCE(@DealKey + ',', '') + CAST(SourcePoolId AS VARCHAR(15))   
	FROM PS.PoolSourceMap   
	WHERE SourcePoolType IN ('Deal') AND IsActive = 1 AND PoolId= @PoolID    
	ORDER BY SourcePoolId ASC
	
	IF(@DealKey like '%-1%' AND NOT EXISTS(SELECT 1 FROM Ps.PoolEcMap WHERE poolID = @PoolID))
		BEGIN
			SET @ReturnValue = -5  
			RETURN @ReturnValue
		END

	SELECT @TargetPool = targetPoolId FROM [PS].[Pool] WHERE PoolId= @PoolID
	SELECT @PoolPurposeId = PoolPurposeId FROM [PS].[Pool] WHERE  PoolId = @PoolID
	IF(@PoolPurposeId =2  AND @TargetPool is Not Null AND @DealKey like '%-1%')
		BEGIN
			SELECT @IsFacilitySharingAllowed = FacilitySharingAllowed FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1]  WHERE dealid = @TargetPool
			IF(@IsFacilitySharingAllowed is NOT NULL AND Lower(@IsFacilitySharingAllowed) = 'y')
				BEGIN
					SELECT @DealKey = STUFF( 
					(SELECT Distinct ',' + CAST(DealId AS VARCHAR(15))
					FROM [sfp].[syn_SFP_ModelCorporate_vw_CorporateDeal_v1] 
					WHERE FacilitySharingAllowed = 'Y' or dealId = -1 
					FOR XML PATH(''),TYPE).value('.', 'NVARCHAR(MAX)'),1,1,'') 
				END
		END

	SELECT @PoolKey = COALESCE(@PoolKey + ',', '') + CAST(SourcePoolId AS VARCHAR(15))   
	FROM PS.PoolSourceMap   
	WHERE SourcePoolType IN ('Pool') AND IsActive = 1 AND PoolId= @PoolID   
	
	--Fetching DealKeys from Poolkeys
	DECLARE @SourcePoolId INT;
	DECLARE @PoolDealKey VARCHAR(500) = '';
	DECLARE @Temp TABLE(Deals VARCHAR(100))
	DECLARE sourcePoolCusor CURSOR FOR
		SELECT SourcePoolId FROM PS.PoolSourceMap   
		WHERE SourcePoolType IN ('Pool') AND IsActive = 1 AND PoolId= @PoolId
	OPEN sourcePoolCusor;
	FETCH NEXT FROM sourcePoolCusor INTO @SourcePoolId;
	WHILE @@FETCH_STATUS = 0 
	BEGIN
		INSERT INTO @Temp EXEC ps.getPoolSourceDeals @SourcePoolId
		SET @PoolDealKey = IIF(@PoolDealKey = '', @PoolDealKey, @PoolDealKey + ',') + (SELECT TOP(1) Deals FROM @Temp)
		DELETE FROM @Temp
		FETCH NEXT FROM sourcePoolCusor INTO @SourcePoolId;
	END;
	CLOSE sourcePoolCusor;
	DEALLOCATE sourcePoolCusor;
	SET @DealKey = IIF(@DealKey = '' OR @DealKey IS NULL, @PoolDealKey, @DealKey + ',' + @PoolDealKey) 

	SET @DealKey = (SELECT TOP(1) STUFF((CAST('<x>' + REPLACE(@DealKey,',','</x><x>') + '</x>' AS XML).query
					('for $x in distinct-values(/x/text())
						return <x>{concat(",", $x)}</x>
					').value('.','varchar(250)')),1,1,''))


	--Once BrandCode will be implemented it will be fetched dynamically    
	IF(Convert(VARCHAR, SUBSTRING(@DealKey, 0, 3)) = '-1')  
	BEGIN     
		SELECT @BrandKey = @BrandKey + CONVERT(VARCHAR, BrandKey) + ',' FROM PS.PoolBrandMap  WHERE IsActive = 1 AND PoolId= @PoolID  
		SET @BrandKey= SUBSTRING(@BrandKey,0,LEN(RTRIM(@BrandKey)))  
	END   
  
	DECLARE @Remarks VARCHAR(500)  
	SET @Remarks = 'VintageDate: '+@VintageDate+' and Deal: '+ISNULL(@DealKey,'')+' and Brand Selected: '+ISNULL(@BrandKey,'')  
	EXEC [app].[spInsertExecutionLog] @PoolID,'Build Start','ps.spBuildPool',@Remarks 
       
	--Get PoolLimit Analysis Field  
	SELECT @PoolLimitAnalysisFieldId = ISNULL(PoolLimitAnalysisFieldId,4) FROM ps.Pool WHERE PoolId = @PoolID  

	SELECT @LimitAnalysisField = IIF(@PoolPurposeId = 3,'RONA',DbColumnName) FROM ps.PoolLimitAnalysisField WHERE PoolLimitAnalysisFieldId = @PoolLimitAnalysisFieldId  
	--SELECT @LimitAnalysisField = 'RONA' --'CommittedExposure'

	--Get Applicable EC Method for given Pool from Pool table (1 is AND, 2 is OR)
	SELECT @ApplicableECMethod = ISNULL(ApplicableECMethod, 1) FROM ps.Pool WHERE PoolId = @PoolID
	

	--Random Selection code start
	DECLARE @PoolLimit DECIMAL(19, 2) = (SELECT TOP 1 Limit FROM PS.Pool WHERE PoolId= @PoolID)
	DECLARE @RandomSelectionType INT = (SELECT TOP 1 RandomSelection FROM PS.Pool WHERE PoolId= @PoolID)
	DECLARE @IsRandomSelection BIT = 0	
	DECLARE @PoolLimitStopper DECIMAL(19, 2)
	DECLARE @TotalRandomBalance Decimal(19, 2)
	DECLARE @OutstandingBalancePercentage Decimal(19, 2)

	DECLARE @BoolFieldDataTypeId INT = (SELECT TOP 1 FieldDataTypeId FROM ps.FieldDataType WHERE [Type] = 'Bool')

	IF(@RandomSelectionType = 0)
	BEGIN
		SET @IsRandomSelection = 0
	END
	ELSE 
	BEGIN 
		SET @IsRandomSelection = 1
		SET @PoolLimitStopper = @PoolLimit -(@PoolLimit*.1/100)		
	END
	--Random Selection code end
	  
	IF OBJECT_ID('tempdb.dbo.#tempEligibility', 'U') IS NOT NULL                    
	DROP TABLE #tempEligibility;    
  
	IF OBJECT_ID('tempdb.dbo.#AccountKeysUnpivot', 'U') IS NOT NULL                    
	DROP TABLE #AccountKeysUnpivot   
   
	IF OBJECT_ID('tempdb.dbo.#AccountKeys', 'U') IS NOT NULL                    
	DROP TABLE #AccountKeys                        
     
	IF OBJECT_ID('tempdb.dbo.#tempEligibilityCriteria', 'U') IS NOT NULL                                             
	DROP TABLE #tempEligibilityCriteria        
  
	IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL                                             
	DROP TABLE #Result  
  
	IF OBJECT_ID('tempdb.dbo.#RandomAccountKeys', 'U') IS NOT NULL                                             
	DROP TABLE #RandomAccountKeys                    
   
	IF OBJECT_ID('tempdb.dbo.#AdvanceSourceDataAfterBuild', 'U') IS NOT NULL                                             
	DROP TABLE #AdvanceSourceDataAfterBuild      
  
	IF OBJECT_ID('tempdb.dbo.#finalOutputFromAdvanceSource', 'U') IS NOT NULL                                             
	DROP TABLE #finalOutputFromAdvanceSource   
   
	IF OBJECT_ID('tempdb.dbo.#AccountKeysBeforeRandom', 'U') IS NOT NULL                                             
	DROP TABLE #AccountKeysBeforeRandom    
   
	IF OBJECT_ID('tempdb.dbo.#Exclusion', 'U') IS NOT NULL                                             
	DROP TABLE #Exclusion   
  
	IF OBJECT_ID('tempdb.dbo.#CustomECFields', 'U') IS NOT NULL  
	DROP TABLE #CustomECFields  
  
	IF OBJECT_ID('tempdb.dbo.#tempEligibilityWithCustomFields', 'U') IS NOT NULL  
	DROP TABLE #tempEligibilityWithCustomFields    
  
	IF OBJECT_ID('tempdb.dbo.#tempEligibilityFields', 'U') IS NOT NULL  
	DROP TABLE #tempEligibilityFields  
   
	IF OBJECT_ID('tempdb.dbo.#CustomFieldUpdatedSQL', 'U') IS NOT NULL  
	DROP TABLE #CustomFieldUpdatedSQL  
  
	IF OBJECT_ID('tempdb.dbo.#tempCTFields', 'U') IS NOT NULL  
	DROP TABLE #tempCTFields  
	
	IF OBJECT_ID('tempdb.dbo.#CTEval', 'U') IS NOT NULL  
	DROP TABLE #CTEval

	IF OBJECT_ID('tempdb.dbo.#tempCTFields_Superset', 'U') IS NOT NULL  
	DROP TABLE #tempCTFields_Superset 

	IF OBJECT_ID('tempdb.dbo.#CalculatedRona', 'U') IS NOT NULL  
	DROP TABLE #CalculatedRona 

	IF OBJECT_ID('tempdb.dbo.#CalculatedRona1', 'U') IS NOT NULL  
	DROP TABLE #CalculatedRona1 
  
  	IF OBJECT_ID('tempdb.dbo.#Staging', 'U') IS NOT NULL 
	DROP Table #Staging
	
	IF OBJECT_ID('tempdb.dbo.#DataForCT', 'U') IS NOT NULL 
	DROP Table #DataForCT

	IF OBJECT_ID('tempdb.dbo.#DataForCT1', 'U') IS NOT NULL 
	DROP Table #DataForCT1

	IF OBJECT_ID('tempdb.dbo.#DataForCT_Agg', 'U') IS NOT NULL 
	DROP Table #DataForCT_Agg

	IF OBJECT_ID('tempdb.dbo.#Staging_TP', 'U') IS NOT NULL 
	DROP Table #Staging_TP

	
	--Exclusion & Pool specific inclusion change code start  
	DECLARE @Active BIT = 1
  
	-- Flag already built pools that depends on current pool to Force Rebuild | Start Declaration and Selection  
	DECLARE @SourcePoolType_HypoPool VARCHAR(20) = 'Pool'  
	, @PoolStatusBuild VARCHAR(20) = 'Build'  
	, @PoolCurrentStatus VARCHAR(20)  
   
	-- DECLARE @BuildPoolStatusId INT = (SELECT PoolStatusId FROM ps.PoolStatus WHERE [Status] = @PoolStatusBuild)  
  
	SELECT @PoolCurrentStatus = PoolStatus.[Status]  
	FROM [ps].[Pool] [Pool]  
	INNER JOIN ps.PoolStatus PoolStatus on [Pool].PoolStatusId = PoolStatus.PoolStatusId  
	WHERE [Pool].IsActive = @Active   
	AND [PoolStatus].IsActive = @Active   
	AND [Pool].PoolId = @PoolId   
   
	DECLARE @CustomFieldTypeId INT = (SELECT FieldTypeId FROM ps.FieldType WHERE TypeName = 'Custom');  
    
	CREATE TABLE #AccountKeys                                
	(    
		FacilityKey BIGINT,
		FacilityId BIGINT,
		LoanKey BIGINT,
		Balance DECIMAL(19, 2)                            
	);  
	CREATE TABLE #AdvanceSourceDataAfterBuild                               
	(    
		FacilityId BIGINT,
		FacilityKey BIGINT, 
		Balance DECIMAL(19, 2)                            
	);  
	Create Table #Result(  
		PoolId int,  
		FacilityId BIGINT,
		FacilityKey BIGINT,
		Balance Decimal(19,2)  
	); 
	CREATE TABLE #CalculatedRona
	(    
		FacilityId BIGINT,
		FacilityKey BIGINT, 
		AvailableRonaForAllocation DECIMAL(19, 2)
	);
	CREATE TABLE #CalculatedRona1
	(    
		FacilityId BIGINT,
		FacilityKey BIGINT, 
		AvailableRonaForAllocation DECIMAL(19, 2)
	);  
 
	BEGIN TRY                                         
		-- Flag pool is building | START  
		UPDATE ps.[Pool]  
		SET [IsPoolBuildInProgress] = @Active,  
			[ModifiedBy] = @UserName,  
			[ModifiedDate] = @CurrentDateTime  
		WHERE PoolId = @PoolId   
			AND ps.[Pool].[IsActive] = @Active  
		-- Flag pool is building | END  
 
		-- Flag already built pools that depends on current pool to Force Rebuild | Start Declaration and Selection  
		IF (@PoolCurrentStatus = @PoolStatusBuild)  
		BEGIN  
			-- Flag already built pools that depends on current pool - To Force Rebuild  
			UPDATE ps.[Pool]  
			SET [IsRebuildRequired] = @Active  
			FROM ps.[Pool]
			INNER JOIN [ps].[PoolSourceMap] PSM ON PSM.PoolId = ps.[Pool].PoolId  
			WHERE PSM.[SourcePoolId] = @PoolId   
			AND PSM.[SourcePooltype] = @SourcePoolType_HypoPool   
			AND PSM.[IsActive] = @Active   
			AND ps.[Pool].[IsActive] = @Active  
		END 
		-- Flag already built pools that depends on current pool to Force Rebuild | End Declaration and Selection

		/*Section For Advance Sourcing */
		IF EXISTS (SELECT 1 FROM PS.PoolSourcingType WHERE [Description] IN ('Intersection', 'Disjoint') AND IsActive = 1 AND SourcingTypeId = @poolSourcingTypeId) 
		BEGIN
			INSERT INTO #AdvanceSourceDataAfterBuild
			EXEC [corp].[spSaveCorporateIntersectionOrDisjointData] @PoolId, @poolSourcingTypeId, @LimitAnalysisField,  @UserName;

			IF @PoolPurposeId = 2
			BEGIN
				-- Calculate RONA for the returned facilities for Top-Up pools
				INSERT INTO @FacilityIds1 SELECT DISTINCT FacilityId FROM #AdvanceSourceDataAfterBuild
				
				INSERT INTO #CalculatedRona1 (FacilityId, FacilityKey, AvailableRonaForAllocation)
				EXEC CORP.spCalculateAvailableRona @poolId, NULL, @FacilityIds1, @UserName

				UPDATE DS 
				SET DS.Balance = CR.AvailableRonaForAllocation
				FROM #AdvanceSourceDataAfterBuild DS
				JOIN #CalculatedRona1 CR
				ON DS.FacilityId = CR.FacilityId AND DS.FacilityKey = CR.FacilityKey
			END
		END
    
		IF EXISTS (SELECT 1 FROM ps.PoolSourcingType WHERE [Description]='Upload' AND IsActive = 1 AND SourcingTypeId = @poolSourcingTypeId)
		BEGIN
			INSERT INTO #AdvanceSourceDataAfterBuild 
			EXEC  [corp].[spSaveCorporateUploadAssetData] @PoolId, @LimitAnalysisField, @UserName ;
			IF @PoolPurposeId = 2 AND @IsBalanceUploaded = 0
			BEGIN
				INSERT INTO @FacilityIds1 SELECT DISTINCT FacilityId FROM #AdvanceSourceDataAfterBuild
				
				INSERT INTO #CalculatedRona1 (FacilityId, FacilityKey, AvailableRonaForAllocation)
				EXEC CORP.spCalculateAvailableRona @poolId, NULL, @FacilityIds1, @UserName

				UPDATE DS 
				SET DS.Balance = CR.AvailableRonaForAllocation
				FROM #AdvanceSourceDataAfterBuild DS
				JOIN #CalculatedRona1 CR
				ON DS.FacilityId = CR.FacilityId AND DS.FacilityKey = CR.FacilityKey
			END
		END
	   --Pool Build Logic - For Pool SourcingType 1 OR If having EC for SourcingType 2,3,4  
	   SELECT *,   
		CASE WHEN tmp.EligibilityCriteriaId = -1   
		 THEN ROW_NUMBER() OVER (ORDER by tmp.EligibilityCriteriaFieldId)   
		 ELSE ROW_NUMBER() OVER (PARTITION BY tmp.EligibilityCriteriaId ORDER BY tmp.EligibilityCriteriaFieldId)   
		END AS RowNumber   
	   INTO #tempEligibility  
	   FROM (  
		 SELECT DISTINCT ec.EligibilityCriteriaId,                     
		   ec.Name,                     
		   '('+ ec.EligibilityExpression +')' as EligibilityExpression,                      
		   ecField.EligibilityCriteriaFieldId,                     
		   ecField.CriteriaFieldTable,                     
		   ecField.IsCombinedEntity,     
		   ecField.FieldDataType,  
		   ecField.FieldType,        
		   ecField.CriteriaFieldName,                     
		   ecField.CriteriaFieldSql,        
		   ecField.SourceFieldsUsed,      
		   ec.ApplicableAt     
		 FROM ps.Pool pl                                        
		 INNER JOIN ps.PoolEcMap ecMap ON pl.PoolId = ecMap.PoolId 
		 INNER JOIN ps.EligibilityCriteria ec ON ecMap.EligibilityCriteriaId = ec.EligibilityCriteriaId AND pl.AssetClassId = ec.AssetClassId 
		 INNER JOIN ps.EligibilityCriteriaCondition  ecCondition ON ec.EligibilityCriteriaId = ecCondition.EligibilityCriteriaId                                              
		 INNER JOIN ps.EligibilityCriteriaField ecField ON (ecCondition.EligibilityCriteriaFieldId = ecField.EligibilityCriteriaFieldId OR ecCondition.ExpectedValue = ecField.CriteriaFieldName) AND pl.AssetClassId = ecField.AssetClassId                                            
		 WHERE pl.PoolId = @PoolID AND ecMAp.IsActive = @Active                    
     
		 UNION ALL   
		 ---- Adding CT   
			SELECT   
		   -1 as EligibilityCriteriaId,  
		   'CTField' as Name,  
		   '' as EligibilityExpression,  
		   ecField.EligibilityCriteriaFieldId,                     
		   ecField.CriteriaFieldTable,                     
		   ecField.IsCombinedEntity,     
		   ecField.FieldDataType,  
		   ecField.FieldType,        
		   ecField.CriteriaFieldName,                     
		   ecField.CriteriaFieldSql,  
		   ecField.SourceFieldsUsed,  
		   -1 as ApplicableAt       
		 FROM ps.Pool pl                                               
		 INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = @Active  
		 INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = @Active  AND pl.AssetClassId =  ct.AssetClassId
		 INNER JOIN ps.ConcentrationTestCondition  ctCondition ON ct.ConcentrationTestId = ctCondition.ConcentrationTestId
		 INNER JOIN ps.EligibilityCriteriaField ecField ON ecField.EligibilityCriteriaFieldId = ctCondition.EligibilityCriteriaFieldId AND ecField.IsActive= @Active  AND pl.AssetClassId =  ecField.AssetClassId  
		 WHERE pl.PoolId = @PoolID  
		) as tmp

		
	
	   /*Section start to replace column name wth their sql for complex fields' */  
	   -- Replacing brackets and comma with addtion leading and trailing space so that fields can be  
	   -- treated as whole word and we can replace field's CriteriaFieldNames with CriteriaFieldSql.  
	   UPDATE #tempEligibility  
	   SET EligibilityExpression  = replace(replace(EligibilityExpression, '(', '( '), ')', ' )');  
  
	   UPDATE #tempEligibility  
	   SET EligibilityExpression  = replace(EligibilityExpression, ',', ' , ');  
  
	   UPDATE #tempEligibility  
	   SET EligibilityExpression  = replace(replace(EligibilityExpression, '[', '[ '), ']', ' ]');  
  
	   SELECT *,   
	   ROW_NUMBER() OVER (PARTITION BY temp.EligibilityCriteriaFieldId ORDER BY temp.EligibilityCriteriaFieldId) RowNumber  
	   INTO #tempEligibilityFields   
	   FROM   
	   (SELECT DISTINCT  
		ecf.EligibilityCriteriaFieldId,  
		ecf.CriteriaFieldSql,  
		sp.Value,  
		ecfs.CriteriaFieldName 'Replace_From_Name',  
		ecfs.CriteriaFieldSQL 'Replace_TO_Name'  
	   FROM #tempEligibility ecf  
	   CROSS APPLY [app].[udfSplitString](SourceFieldsUsed, ',') sp  
	   INNER JOIN  ps.EligibilityCriteriaField ecfs ON sp.value = ecfs.EligibilityCriteriaFieldId  AND ecfs.AssetClassId = @AssetClassId
	   WHERE ecf.FieldType = @CustomFieldTypeId ) AS temp   
  
	   UPDATE #tempEligibilityFields  
	   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '(', '( '), ')', ' )');  
  
	   UPDATE #tempEligibilityFields  
	   SET CriteriaFieldSql  = replace(CriteriaFieldSql, ',', ' , ');  
  
	   UPDATE #tempEligibilityFields  
	   SET CriteriaFieldSql  = replace(replace(CriteriaFieldSql, '[', '[ '), ']', ' ]');  

	   ;WITH UpdatedEligibilitySQLf(RowID,EligibilityCriteriaFieldId, Expression)                                
	   AS                                
	   (                      
		SELECT RowNumber,                     
		 EligibilityCriteriaFieldId,   
		 [ps].[fn_ReplaceWholeWord](CriteriaFieldSql, Replace_From_Name, Replace_TO_Name) as Expression   
		FROM #tempEligibilityFields WHERE RowNumber = 1                                
                 
	   UNION ALL                                              
                 
		SELECT RowNumber,                
		 t.EligibilityCriteriaFieldId,                         
		 --EC replace Issue Fix [For Custom Fields]  - START [OLD - Expression,]  
		 [ps].[fn_ReplaceWholeWord](c.Expression, Replace_From_Name, Replace_TO_Name) as Expression       
		FROM UpdatedEligibilitySQLf c                        
		 INNER JOIN #tempEligibilityFields t ON t.EligibilityCriteriaFieldId = c.EligibilityCriteriaFieldId                        
		WHERE RowNumber = RowID + 1                        
	   ) 
  
	   SELECT EligibilityCriteriaFieldId,                     
	   Expression As FinalExpression    
	   INTO #CustomFieldUpdatedSQL  
	   FROM UpdatedEligibilitySQLf                                              
	   WHERE RowID IN                                               
	   (                                              
		SELECT MAX(RowID) AS RowID     
		FROM UpdatedEligibilitySQLf tbl     
		WHERE UpdatedEligibilitySQLf.EligibilityCriteriaFieldId = tbl.EligibilityCriteriaFieldId                                                                           
	   )    
	   GROUP BY RowID, EligibilityCriteriaFieldId, Expression                                           
	   ORDER BY EligibilityCriteriaFieldId 

	   --update #tempEligibility  
	   UPDATE te  
	   SET te.CriteriaFieldSQL = cf.FinalExpression  
	   FROM #tempEligibility te  
	   INNER JOIN #CustomFieldUpdatedSQL cf  
	   ON te.EligibilityCriteriaFieldId = cf.EligibilityCriteriaFieldId
  
      /*fetch custom fields with base columns names as comma seperated in single row*/  
	   DECLARE @fields VARCHAR(MAX)  
	   SELECT @fields =   ISNULL(@fields+', ','') + t.SourceFieldsUsed  
	   FROM (  
		 /* Custom Fields Used in EC*/  
		 SELECT SourceFieldsUsed FROM #tempEligibility WHERE SourceFieldsUsed IS NOT NULL
		 UNION
		 /*Custom Fields Used in Concentration Test*/  
		 SELECT ecField.SourceFieldsUsed  
		 FROM ps.Pool pl                                               
		 INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = 1  
		 INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1                                                   
		 INNER JOIN ps.EligibilityCriteriaField ecField ON ecField.EligibilityCriteriaFieldId = ct.AnalysisCriteriaFieldId AND ecField.IsActive=1   
		 WHERE pl.PoolId = @PoolID AND ecField.SourceFieldsUsed IS NOT NULL
		 ) t

	   /*Now split custom fields list into a temp tabel in multiple rows*/  
	   SELECT CONVERT(INT,Value) AS FieldId INTO #CustomECFields FROM [app].[udfSplitString](@fields,',')  
        
	   /*Added CriteriaFieldName in temp table for both custom and non custom fields*/  
	   SELECT DISTINCT CriteriaFieldSql, CriteriaFieldTable, FieldDataType  
	   INTO #tempEligibilityWithCustomFields   
	   FROM (  
		 SELECT CriteriaFieldSql, CriteriaFieldTable, FieldDataType 
		 FROM ps.EligibilityCriteriaField 
		 where EligibilityCriteriaFieldId in (SELECT FieldId FROM #CustomECFields )  
			  AND AssetClassId =@AssetClassId
		 )x
	   /*Non-custom Eligibility Criteria Fields */  
	   UNION   
		SELECT DISTINCT CriteriaFieldSql, CriteriaFieldTable, FieldDataType FROM #tempEligibility WHERE SourceFieldsUsed IS NULL
	   /*Mandatory Eligibility Criteria Fields Which are exposed on UI as well */  
	   UNION   
		SELECT CriteriaFieldSql, CriteriaFieldTable, FieldDataType 
		FROM ps.EligibilityCriteriaField 
		WHERE CriteriaFieldSql IN ('FacilityID')
		--CriteriaFieldSql IN ('LOAN_IDENTIFIER','OUTSTANDNG_CAPITAL_BALANCE_AMT','TRUE_BALANCE_AMT')
	   /*Columns required for Concentration Test*/  
	   UNION   
		SELECT ecField.CriteriaFieldSql, ecField.CriteriaFieldTable, ecField.FieldDataType  
		FROM ps.Pool pl                                               
		INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = 1  
		INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1                                                   
		INNER JOIN ps.EligibilityCriteriaField ecField ON ecField.EligibilityCriteriaFieldId = ct.AnalysisCriteriaFieldId AND ecField.IsActive=1  
		WHERE pl.PoolId = @PoolID AND ecField.SourceFieldsUsed IS NULL  
  
	   /*Mandatory Eligibility Criteria Fields Which are not exposed on UI */  
	    UNION  
	    SELECT 'TotalCreditLimit','Facility',2
	   UNION  
	    SELECT 'FacilityKey','Facility',2	   
	   UNION  
		SELECT 'LoanKey','CorpFacilityDetail',2
	   UNION  
	    SELECT 'RONA','Facility',2
	   UNION  
	    SELECT 'UtilisationGBP_ReportingDate','Facility',2
	   UNION
	    SELECT 'DealInitialSize','Facility',2
	   UNION
	    SELECT 'DealName','Facility',1
	   UNION
	    SELECT 'CommittedExposure','Facility',2

	   --update exclusion IN CASE OF Advance Sourcing  
	   SELECT TOP 0 *  
	   INTO #finalOutputFromAdvanceSource  
	   FROM #AdvanceSourceDataAfterBuild
  
	   IF EXISTS (SELECT 1 FROM PS.PoolSourcingType WHERE [Description] NOT IN ('Standard') AND IsActive = 1 AND SourcingTypeId = @poolSourcingTypeId)  
		AND EXISTS(SELECT EligibilityCriteriaId FROM #tempEligibility)  
	   BEGIN      
		 INSERT INTO #finalOutputFromAdvanceSource  
		 SELECT asdab.*      
		 FROM #AdvanceSourceDataAfterBuild asdab        
	   END
	   -- CURRENTLY WE HAVE NO EXCLUSIONS IN CORPORATE, WE MAY ENABLE IT LATER
	   ELSE IF EXISTS (SELECT 1 FROM PS.PoolSourcingType WHERE [Description] NOT IN ('Standard') AND IsActive = 1 AND SourcingTypeId = @poolSourcingTypeId)
		BEGIN
				INSERT INTO #finalOutputFromAdvanceSource
				SELECT asdab.*			 
				FROM #AdvanceSourceDataAfterBuild asdab
				--LEFT JOIN #Exclusion tblExclusion ON asdab.LoanId = tblExclusion.LoanNumber
				--WHERE tblExclusion.LoanNumber IS NULL;
		END

   --BEGIN TRANSACTION BuildPool;
   --Execute if having Eligibility Criteria OR Standard Sourcing selected
   IF EXISTS(SELECT EligibilityCriteriaId FROM #tempEligibility)
      OR (@poolSourcingTypeId = (SELECT SourcingTypeId  FROM ps.PoolSourcingType WHERE [Description]='Standard' AND IsActive = 1))
   /*#1 Start*/
   BEGIN      
                                                
       ;WITH UpdatedEligibilitySQL(RowID,EligibilityCriteriaId, Expression, FieldsUsed, CriteriaFieldTable, IsCombinedEntity, ApplicableAt)                                
    AS                                
    (                      
     SELECT RowNumber,                     
      EligibilityCriteriaId,                                
       [ps].[fn_ReplaceWholeWord](  
         CASE WHEN FieldDataType = @BoolFieldDataTypeId THEN REPLACE(REPLACE(EligibilityExpression, CriteriaFieldName + ' = ''N''', CriteriaFieldName + ' IN (''N'',''No'',''False'')'), CriteriaFieldName + ' = ''Y''', CriteriaFieldName + ' IN (''Y'',''Yes'',''True'')') ELSE EligibilityExpression END,  
         CriteriaFieldName, '('+CriteriaFieldSql+')') as Expression,    
      SourceFieldsUsed,                     
      CriteriaFieldTable,                     
      IsCombinedEntity,      
      ApplicableAt                    
     FROM #tempEligibility WHERE RowNumber = 1 AND EligibilityCriteriaId <> -1                                
                   
     UNION ALL                                              
                   
     SELECT RowNumber,                     
      t.EligibilityCriteriaId,     
       [ps].[fn_ReplaceWholeWord](  
         CASE WHEN FieldDataType = @BoolFieldDataTypeId THEN REPLACE(REPLACE(c.Expression, CriteriaFieldName + ' = ''N''', CriteriaFieldName + ' IN (''N'',''No'',''False'')'), CriteriaFieldName + ' = ''Y''', CriteriaFieldName + ' IN (''Y'',''Yes'',''True'')') ELSE c.Expression END,  
         t.CriteriaFieldName, '('+t.CriteriaFieldSql+')') as Expression,    
      SourceFieldsUsed,                     
      t.CriteriaFieldTable,                     
      t.IsCombinedEntity,      
      t.ApplicableAt                                             
     FROM UpdatedEligibilitySQL c                        
      INNER JOIN #tempEligibility t ON t.EligibilityCriteriaId = c.EligibilityCriteriaId      
       AND t.EligibilityCriteriaId <> -1  
     WHERE RowNumber = RowID + 1                        
     )

     SELECT EligibilityCriteriaId,                     
      Expression As FinalExpression,    
      ApplicableAt                      
     INTO #tempEligibilityCriteria                     
     FROM UpdatedEligibilitySQL                                              
     WHERE RowID IN                                               
     (                                              
     SELECT MAX(RowID) AS RowID     
     FROM UpdatedEligibilitySQL tbl     
     WHERE UpdatedEligibilitySQL.EligibilityCriteriaId = tbl.EligibilityCriteriaId                                              
     --GROUP BY RowID                                
    )    
    GROUP BY RowID, EligibilityCriteriaId, Expression, FieldsUsed, CriteriaFieldTable, IsCombinedEntity, ApplicableAt                                            
    ORDER BY EligibilityCriteriaId 
      
    -- Reverting square brackets to its previous state so that sql can evaluate expression value within brackets.  
    UPDATE #tempEligibilityCriteria  
    SET FinalExpression  = replace(replace(FinalExpression, '( ', '('), ' )', ')');  
  
    UPDATE #tempEligibilityCriteria  
    SET FinalExpression  = replace(FinalExpression, ' , ', ',');      
      
    UPDATE #tempEligibilityCriteria  
    SET FinalExpression  = replace(replace(FinalExpression, '[ ', '['), ' ]', ']');
 
    --If EligibilityCriteria applied to Pool  
    IF EXISTS(Select 1 from #tempEligibilityCriteria)  
    BEGIN  
     SELECT @ECSelectColumn = @ECSelectColumn +  'Case When ' + FinalExpression + ' Then 1 Else 0 End AS '''  + CAST(EligibilityCriteriaId as VARCHAR)  + ''', '         
     FROM #tempEligibilityCriteria
     SET @ECSelectColumn = ','+@ECSelectColumn    
     -- Print SUBSTRING(@ECSelectColumn, 0, LEN(@ECSelectColumn))      
    
     -- Used during Unpivoting under IN condition    
     SELECT @ECID = @ECID + '[' + Cast(EligibilityCriteriaId as VARCHAR)+']' + ', ' FROM #tempEligibilityCriteria        
     
     --Alter #AccountKeys Table to add EC's as columns  
     SET @AddECColumn  = 'Alter Table #AccountKeys ADD '  
     SELECT @AddECColumn = @AddECColumn +  '[' + CAST(EligibilityCriteriaId as VARCHAR)  + '] VARCHAR(10), ' From #tempEligibilityCriteria    
     SET @AddECColumn = (SUBSTRING(@AddECColumn, 0, LEN(@AddECColumn)))    
      
     EXEC (@AddECColumn)    
    END
          
    EXEC  [app].[spInsertExecutionLog] @PoolId, 'Parameters Set for rpt.uspMortgageLoanEntity'      
     
    PRINT 'Parameters Set for rpt.uspMortgageLoanEntity'  
  
    DECLARE @XmlData XML = NULL  
    DECLARE @ReqCols XML = NULL  
    Declare @RowID Varchar(50) = '' 
  
    IF(@poolSourcingTypeId <> 1)  
    BEGIN      
	 SELECT @XmlData = ( SELECT FacilityKey  FROM #finalOutputFromAdvanceSource FOR XML PATH('Node'), ROOT('Root')) 
     SET @DealKey = ''   
    END

	IF (@poolSourcingTypeId = 1 AND LEN(@PoolKey) <> 0) 
	BEGIN 
			SELECT @XmlData = (SELECT DISTINCT pb.LoanId AS FacilityKey
							   FROM ps.PoolBuildDetail pb WITH (NOLOCK) 
							   INNER JOIN ps.PoolSourceMap psm WITH (NOLOCK) ON pb.PoolId = psm.SourcePoolId							   
							   WHERE pb.IsActive = 1 AND psm.SourcePoolType = 'Pool' AND psm.isActive = 1 AND psm.PoolId = @poolId
							   FOR XML PATH('Node'), ROOT('Root') 
							  ) 
	END
            
	SELECT @ReqCols = ( SELECT DISTINCT CriteriaFieldSql AS CriteriaFieldName, FieldDataType FROM #tempEligibilityWithCustomFields FOR XML PATH('Node'), ROOT('Root'))   
      
    EXEC  [app].[spInsertExecutionLog] @PoolId, 'Common SP rpt.uspCommercialFacilityEntity Start'   

   --select  @VintageDate,  @DealKey,  @ReqCols,  @XmlData
   --RETURN 
     IF (@pRowId IS NULL)
	 BEGIN
		EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
		@VintageDate = @VintageDate,    
		@DealKey  = @DealKey,    
		@FacilityIds = NULL,    
		@ReqColumns  = @ReqCols,    
		@XmlData = @XmlData,
		-- @poolId = @PoolKey,
		@OutputRowID = @RowID OUTPUT 
	END
	ELSE SET @RowID = @pRowId
   
    EXEC  [app].[spInsertExecutionLog] @PoolId, 'Common SP rpt.uspCommercialFacilityEntity End'
  
    --PRINT 'Data Population in #MortgageData Ended'
    PRINT 'Query Execution Started'

    SET @QUERY= 'INSERT INTO #AccountKeys
        SELECT DISTINCT FacilityKey  
           ,FacilityId
		   ,LoanKey
           ,' +@LimitAnalysisField+' AS Balance  
           '+ SUBSTRING(@ECSelectColumn, 0, LEN(@ECSelectColumn))+'       
        FROM  ( SELECT * FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = '''+@RowID+''' ) query '
                                 
    IF(@IsDebug = 1)                                
    PRINT CAST(@query as NTEXT)                                    
     EXEC(@query) 
	  
    PRINT 'Query Execution Ended'   
  
    EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Inserted in #AccountKeys Table'      
  
    IF EXISTS (SELECT  1 FROM #AccountKeys)     
    /*#2 Start*/  
    BEGIN  
     
     /* DELETE FROM PoolEligibilityBuildDetail TABLE WHERE PoolId equals to @PoolID*/  
     DECLARE @r INT;   
     SET @r = 1;  
   
     WHILE @r > 0  
     BEGIN  
      BEGIN TRANSACTION;   
       DELETE TOP (1000000) [ps].[PoolEligibilityBuildDetail]  WHERE PoolId = @PoolID   
       SET @r = @@ROWCOUNT;   
      COMMIT TRANSACTION;  
     END         
  
     EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Deleted From ps.PoolEligibilityBuildDetail Table'  
  
     /*Creating temp tables for Random Selection logic*/  
     CREATE TABLE #AccountKeysBeforeRandom(    
      FacilityId INT,        
      Balance DECIMAL(19,2)  
     )  
           
     CREATE TABLE #RandomAccountKeys(    
      FacilityId INT,        
      Balance DECIMAL(19,2)  
     )      

     IF EXISTS (Select 1 from #tempEligibilityCriteria)   
     BEGIN
			  /*Insert All those facilities in PoolEligibilityBuildDetail table which got failed after applying EC */  
			  SET @UnPivotSql = N'INSERT INTO [ps].[PoolEligibilityBuildDetail]([PoolId], [LoanId], [EligibilityCriteriaId], [LoanBalance], [Status])  
			  SELECT '+CAST(@PoolID AS VARCHAR(10))+'   
					,x.FacilityId  
					,x.Eligibility_Id  
					,SUM(x.Balance) AS Balance  
					,CASE WHEN ec.ApplicableAt = 3 THEN MAX(x.Eligibility_Result) ELSE MIN(x.Eligibility_Result) END AS ECStatus  
			  FROM (      
				SELECT u.FacilityId, LoanKey, u.Eligibility_Id, u.Balance, u.Eligibility_Result  
				FROM #AccountKeys s      
				UNPIVOT ( Eligibility_Result for Eligibility_Id in ('+ SUBSTRING(@ECID, 0, LEN(@ECID)) + ')
				  ) u
			  ) x
			  INNER JOIN ps.EligibilityCriteria ec ON ec.EligibilityCriteriaId = x.Eligibility_Id
			  GROUP BY x.FacilityId, x.Eligibility_Id, ec.ApplicableAt
			  HAVING (CASE WHEN ec.ApplicableAt = 3 THEN MAX(x.Eligibility_Result) ELSE MIN(x.Eligibility_Result) END) = 0'
  
			  EXEC (@UnPivotSql)      
			  Print 'Unpivot Executed and Inserted Data in ps.PoolEligibilityBuildDetail Table'                   
        
			  EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Unpivoted & Inserted in ps.PoolEligibilityBuildDetail Table'       

				IF @ApplicableECMethod = 2
				BEGIN

					DECLARE @ECCountValue INT = (SELECT COUNT(*) FROM #tempEligibilityCriteria)
					
					-- Insert all passed LoanIDs into #AccountKeysBeforeRandom
					INSERT INTO #AccountKeysBeforeRandom (FacilityId, Balance)
					SELECT ak.FacilityId
						,SUM(ak.Balance) AS Balance 
					FROM #AccountKeys ak 						
					WHERE NOT EXISTS (
						-- Failed LoanIDs by EC Tests
						SELECT LoanID FROM [ps].[PoolEligibilityBuildDetail] WHERE PoolId = @PoolID AND LoanId = ak.FacilityId 
						Group By LoanID Having Count(EligibilityCriteriaId) = @ECCountValue)
					GROUP BY ak.FacilityId

					-- /* Insert those records in PoolEligibilityBuildDetail table which are passed after applying EC
					-- but not part of pool because of Exclusion, inserting with invalid EcId(i.e. -1) and status =-1 */
					-- INSERT INTO [ps].[PoolEligibilityBuildDetail]([PoolId], [LoanId], [EligibilityCriteriaId], [LoanBalance], [Status])
					-- SELECT @PoolID,
					-- 	akbr.FacilityId,
					-- 	-1,
					-- 	akbr.Balance,
					-- 	-1
					-- FROM #AccountKeysBeforeRandom akbr
					-- WHERE EXISTS (SELECT LoanNumber FROM #Exclusion ex WHERE ex.LoanNumber = akbr.LoanId)
					
					-- -- Remove the excluded loans from #AccountKeysBeforeRandom to come up with final list
					-- DELETE FROM #AccountKeysBeforeRandom 
					-- WHERE EXISTS (SELECT LoanNumber FROM #Exclusion ex WHERE ex.LoanNumber = LoanId)

				END
				ELSE
				BEGIN
								
					-- /* Insert those records in PoolEligibilityBuildDetail table which are passed after applying EC
					-- 	but not part of pool because of Exclusion, inserting with invalid EcId(i.e. -1) and status =-1 */
					-- INSERT INTO [ps].[PoolEligibilityBuildDetail]([PoolId], [LoanId], [EligibilityCriteriaId], [LoanBalance], [Status])
					-- SELECT @PoolID,
					-- 	ak.FacilityId,
					-- 	-1,
					-- 	SUM(ak.Balance),
					-- 	-1
					-- FROM #AccountKeys ak 						
					-- WHERE NOT EXISTS (SELECT LoanId FROM [ps].[PoolEligibilityBuildDetail] p WHERE p.PoolId = @PoolID AND p.LoanId = ak.LOAN_IDENTIFIER )
					-- AND EXISTS (SELECT LoanNumber FROM #Exclusion ex WHERE ex.LoanNumber = ak.LOAN_IDENTIFIER )
					-- GROUP BY ak.FacilityId	

					/*Exclude those loans which are failed either by Ec or Exclusion*/
					INSERT INTO #AccountKeysBeforeRandom (FacilityId, Balance)
					SELECT ak.FacilityId
						,SUM(ak.Balance) AS Balance 
					FROM #AccountKeys ak 						
					WHERE NOT EXISTS (SELECT LoanId FROM [ps].[PoolEligibilityBuildDetail] p WHERE p.PoolId = @PoolID AND p.LoanId = ak.FacilityId )						  
					GROUP BY ak.FacilityId																

				END															
              
     END
     ELSE   
     BEGIN  
		  -- Update list after excluding loans from exclusion list  
		  INSERT INTO #AccountKeysBeforeRandom (FacilityId, Balance)  
		  SELECT ak.FacilityId  
			 ,SUM(ak.Balance) AS Balance         
		  FROM #AccountKeys ak  
			--LEFT JOIN #Exclusion tblExclusion ON ak.LOAN_IDENTIFIER = tblExclusion.LoanNumber   -- TBC SAKK
			--WHERE tblExclusion.LoanNumber IS NULL  
		  GROUP BY ak.FacilityId  
     END   
       
     EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Inserted in #AccountKeysBeforeRandom Temp Table'       
       
     /*#3 End*/ 

	 /* Updating the Balance of passed Facilities as per shared facility RONA calculation 
	 	The balance will be updated only for Top-Up pools and only when sourcing is not from file upload */
	 IF @PoolPurposeId = 2 AND @poolSourcingTypeId IN (1, 2, 3)
	 BEGIN
		
		DECLARE @FacilityIds corp.FacilityList
		INSERT INTO @FacilityIds SELECT DISTINCT facilityId FROM #AccountKeysBeforeRandom
		
		INSERT INTO #CalculatedRona (FacilityId, FacilityKey, AvailableRonaForAllocation)
		EXEC CORP.spCalculateAvailableRona @PoolId, @DealKey, @FacilityIds, @UserName, @RowIDParam=''

		EXEC [app].[spInsertExecutionLog] @PoolId, 'spCalculateAvailableRona Stored Proc Run Complete'  

		UPDATE AKBR 
		SET AKBR.Balance = CR.AvailableRonaForAllocation
		FROM #AccountKeysBeforeRandom AKBR
		JOIN #CalculatedRona CR
			ON AKBR.FacilityId = CR.FacilityId

		UPDATE AK 
		SET AK.Balance = CR.AvailableRonaForAllocation
		FROM #AccountKeys AK
		JOIN #CalculatedRona CR
			ON AK.FacilityId = CR.FacilityId AND AK.FacilityKey = CR.FacilityKey

		EXEC [app].[spInsertExecutionLog] @PoolId, '#AccountKeysBeforeRandom updated with Available RONA'  
		-- Commented out the below statement since we are now returning 0 for -ve or null RONA values.
		-- DELETE FROM #AccountKeys WHERE Balance <= 0
		-- DELETE FROM #AccountKeysBeforeRandom WHERE Balance <= 0

	 END
  
     /*Concentration Test Code Begin - Which only needs to be run one time*/  
       SELECT @CTID = @CTID + '[' + Cast(PoolCTMapId as VARCHAR)+']' + ','   
       FROM ps.Pool pl                                               
       INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId  
       WHERE pl.PoolId = @PoolId AND ctMap.IsActive = 1  
  
       IF(LEN(@CTID) > 0)  
       BEGIN  
			
			DECLARE @CT_WildCard VARCHAR(100) = 'Sum of RONA < MAX RONA for deal'
			DECLARE @CT_WildCardID INT = (SELECT TOP 1 ConcentrationTestId FROM ps.ConcentrationTest WHERE CriteriaName = @CT_WildCard AND IsActive = 1)
			DECLARE @CT_WildCardPoolCTMapID INT = (SELECT TOP 1 PoolCTMapId FROM ps.PoolCTMap where ConcentrationTestId = @CT_WildCardID AND PoolId = @PoolID)

			SET @LimitAnalysisField = 'RONA'

			/* Added code to pick Criteria field name and criteria field sql used in CT */  
			SELECT @CTSelectColumn = CASE   WHEN ct.ConcentrationTestTypeId = 1   
											THEN @CTSelectColumn + 'IIF(SUM(CASE WHEN '+ISNULL(NULLIF(CTExpression_Superset,''),'1=1')+' THEN IIF(rn=1,'+ @LimitAnalysisField + ',0) ELSE 0 END) =0,0, 
																	SUM(CASE WHEN '+ IIF(CTExpression = ecField.CriteriaFieldName,'1=1',CTExpression)+' AND '+ISNULL(NULLIF(CTExpression_Superset,''),'1=1')+' THEN ISNULL('+REPLACE(ecField.CriteriaFieldSql,'MaturityDate@Sec','MaturityDate')+' * '+ @LimitAnalysisField + ',0) ELSE 0 END)
																	/SUM(CASE WHEN '+ISNULL(NULLIF(CTExpression_Superset,''),'1=1')+' THEN IIF(rn=1,'+ @LimitAnalysisField + ',0) ELSE 0 END) 
																	)AS '''  + CAST(ctMap.PoolCTMapId as VARCHAR)  + ''', ' 
											WHEN ct.ConcentrationTestTypeId = 2   
											THEN @CTSelectColumn + 'IIF(SUM(CASE WHEN '+ISNULL(NULLIF(CTExpression_Superset,''),'1=1')+' THEN IIF(rn=1,'+ @LimitAnalysisField + ',0) ELSE 0 END) =0,0, 
																	SUM(CASE WHEN ' + CTExpression + ' AND '+ISNULL(NULLIF(CTExpression_Superset,''),'1=1')+' THEN '+ @LimitAnalysisField +' ELSE 0 END)
																	/SUM(CASE WHEN '+ISNULL(NULLIF(CTExpression_Superset,''),'1=1')+' THEN IIF(rn=1,'+ @LimitAnalysisField + ',0) ELSE 0 END)*100) AS ''' +CAST(ctMap.PoolCTMapId as VARCHAR)  + ''', '  
											WHEN ct.ConcentrationTestTypeId = 3   
											THEN @CTSelectColumn + '(SELECT MIN(Result) AS Result FROM(
																		SELECT IIF( IIF(SUM(SUM(RONA))OVER() = 0 ,0,SUM(CASE WHEN '+ISNULL(NULLIF(REPLACE(IIF(CTExpression = ecField.CriteriaFieldName,'1=1',CTExpression),'('+ecField.CriteriaFieldSql+')','(1=1)'),''),'1=1')+' THEN RONA ELSE 0 END)/SUM(SUM(RONA))OVER()*100) < = '+CONVERT(VARCHAR,ct.LimitPercentage)+',1,0) AS Result  
																		FROM (SELECT DISTINCT FacilityId,'+ecField.CriteriaFieldSql+',RONA FROM #DataForCT WHERE '+ISNULL(NULLIF(ct.CTExpression_Superset,''),'1=1')+')y 
																		GROUP BY '+ecField.CriteriaFieldSql+')x
																	 ) AS ''' +CAST(ctMap.PoolCTMapId as VARCHAR)  + ''', '
									 END  
					
			FROM ps.Pool pl                                              
			INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = 1  
			INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1                                                   
			LEFT JOIN ps.EligibilityCriteriaField ecField ON ecField.EligibilityCriteriaFieldId = ct.AnalysisCriteriaFieldId AND ecField.IsActive=1  
			WHERE pl.PoolId = @PoolId AND ct.CriteriaName NOT IN (@CT_WildCard)  
			ORDER BY PoolCTMapId 
          
			/* Replacing criteria field name with criteria field sql in the CT expression STARTS*/                
			SELECT CriteriaFieldName, CriteriaFieldSql, @CTSelectColumn AS expression, FieldDataType          
			INTO #tempCTFields  
			FROM #tempEligibility  
			WHERE EligibilityCriteriaId = -1 AND CriteriaFieldName <> CriteriaFieldSql  

			UPDATE #tempCTFields  
			SET expression  = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(expression, '(', '( '), ')', ' )'), ', ', ' ,'), '[', '[ '), ']', ' ]')
			
			PRINT 'CT Expression Created' 
			/*
			;WITH subq (OriginalExpression, CorrectedExpression, PassNum, CriteriaFieldName) AS  
			  (  
				 SELECT ctFields.expression AS CorrectedExpression, ctFields.expression AS OriginalExpression, 1 AS PassNum, CriteriaFieldName   
				 FROM #tempCTFields ctFields  
				 UNION ALL  
				 SELECT subq.OriginalExpression   
					   ,CAST([ps].[fn_ReplaceWholeWord]( CASE WHEN FieldDataType = @BoolFieldDataTypeId 
															  THEN REPLACE(REPLACE(subq.CorrectedExpression, ctFields.CriteriaFieldName + ' = ''N''', ctFields.CriteriaFieldName + ' IN (''N'',''No'',''False'')'), ctFields.CriteriaFieldName + ' = ''Y''', ctFields.CriteriaFieldName + ' IN (''Y'',''Yes'',''True'')') 
															  ELSE subq.CorrectedExpression 
														  END,  
														      ctFields.CriteriaFieldName,  '('+ctFields.CriteriaFieldSql+')'
												        ) AS VARCHAR(MAX)) AS CorrectedExpression  
					   ,PassNum+1 AS PassNum  
					   ,ctFields.CriteriaFieldName   
				FROM subq CROSS JOIN #tempCTFields ctFields   
				WHERE ( '.'+ subq.CorrectedExpression +'.' like '%[^a-z]'+ ctFields.CriteriaFieldName +'[^a-z]%' OR     
					    '.'+ subq.CorrectedExpression +'.' like '[^a-z]'+  ctFields.CriteriaFieldName +'[^a-z]%' OR     
					    '.'+ subq.CorrectedExpression +'.' like '%[^a-z]'+ ctFields.CriteriaFieldName +'[^a-z]'   
					  )   
			 )  
          
			UPDATE #tempCTFields    
			SET expression = subq.CorrectedExpression   
			FROM #tempCTFields ctFields   
			INNER JOIN subq  ON ctFields.expression=subq.OriginalExpression   
			WHERE subq.passnum=(SELECT MAX(PassNum) FROM subq)

			-- Reverting square brackets to its previous state so that sql can evaluate expression value within brackets.  
			UPDATE #tempCTFields  
			SET expression  = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(expression, '( ', '('), ' )', ')'), ' , ', ','), '[ ', '['), ' ]', ']')            
            */


			DECLARE @col_names CURSOR
		 	DECLARE @Expr VARCHAR(MAX)
			DECLARE @FieldDataType INT			
			DECLARE @FieldName VARCHAR(100)
			DECLARE @FieldSql VARCHAR(100)


			SET @col_names = CURSOR FOR
			SELECT Expression ,FieldDataType, CriteriaFieldName, CriteriaFieldSql FROM #tempCTFields
			OPEN @col_names
			FETCH NEXT FROM @col_names INTO @Expr,@FieldDataType,@FieldName,@FieldSql
			WHILE @@FETCH_STATUS = 0
			BEGIN			
				UPDATE #tempCTFields
				SET Expression = CAST([ps].[fn_ReplaceWholeWord]( CASE WHEN @FieldDataType = 4 
															THEN REPLACE(REPLACE(@Expr, @FieldName + ' = ''N''', @FieldName + ' IN (''N'',''No'',''False'')'), @FieldName + ' = ''Y''', @FieldName + ' IN (''Y'',''Yes'',''True'')') 
															ELSE @Expr 
														END,  
														    @FieldName,  '('+@FieldSql+')'
												    ) AS VARCHAR(MAX))
	
				FETCH NEXT
				FROM @col_names INTO @Expr,@FieldDataType,@FieldName,@FieldSql
			END
			CLOSE @col_names
			DEALLOCATE @col_names 			         
          
			SELECT TOP 1 @CTSelectColumn =  REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(Expression, '( ', '('), ' )', ')'), ' , ', ','), '[ ', '['), ' ]', ']') 
			FROM #tempCTFields;      
			
			PRINT 'CT Expression Updated'  
			/* Replacing criteria field name with criteria field sql in the CT expression ENDS*/  
               
       
			/*Create a temp table and add columns dynamically by using dynamic query*/         
			CREATE TABLE #CTEval (PoolId INT)  
          
			SET @AddECColumn  = 'Alter Table #CTEval ADD '  
			SELECT @AddECColumn = @AddECColumn +  '[' + CAST(PoolCTMapId as VARCHAR)  + '] DECIMAL(19,2), '   
			FROM ps.Pool pl                                               
			INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId  
			WHERE pl.PoolId = @PoolId AND ctMap.IsActive = 1  AND ctMap.PoolCTMapId <> ISNULL(@CT_WildCardPoolCTMapID,0) 
			ORDER BY PoolCTMapId  
			
			IF(@CT_WildCardPoolCTMapID IS NOT NULL)
			SELECT @AddECColumn = @AddECColumn +  '[' + CAST(@CT_WildCardPoolCTMapID AS VARCHAR)  + '] DECIMAL(19,2), '  
          
			SET @AddECColumn = (SUBSTRING(@AddECColumn, 0, LEN(@AddECColumn)))        
			EXEC (@AddECColumn)  

			PRINT '#CTEval Table Created'
       END  
  
     /*Concentratiion Test While Loop Start*/  
     EXEC [app].[spInsertExecutionLog] @PoolId, 'Random Selection & CT Loop Started'  
	 PRINT 'Random Selection & CT Loop Started'

	 DECLARE @RowIDForCT VARCHAR(50) = ''
	 DECLARE @CountRS INT
	 DECLARE @BalanceRS DECIMAL(19,2)
	 DECLARE @FailedCTList VARCHAR(400) = ''

     WHILE (@CTRunCount <= 10 AND @CTStatus = 'Fail')  
     BEGIN  
         /*Random Selection code start */ 
		  IF OBJECT_ID('tempdb.dbo.#RandomAccountKeys', 'U') IS NOT NULL  
		  	TRUNCATE TABLE #RandomAccountKeys;  
		  IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL  
		  	TRUNCATE TABLE #Result;  
		  IF OBJECT_ID('tempdb.dbo.#CTEval', 'U') IS NOT NULL  
		  	TRUNCATE TABLE #CTEval;

		  IF(@IsRandomSelection = 1) -- TODO, also check if CT is applied then only go for random selection
			BEGIN 
				;WITH cteRunningTtl AS 
				(
				SELECT t1.FacilityId	
						,t1.Balance							
						,PrecedingSum = SUM(t1.Balance) OVER ( ORDER BY NEWID() ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW )
				FROM #AccountKeysBeforeRandom t1							
				)

				INSERT INTO #RandomAccountKeys(FacilityId, Balance) 
				SELECT FacilityId,				
						Balance
				FROM cteRunningTtl
				WHERE PrecedingSum < @PoolLimitStopper						
								
							
				SET @TotalRandomBalance = (SELECT SUM(Balance) FROM #RandomAccountKeys)
				SET @OutstandingBalancePercentage = ((@PoolLimitStopper-@TotalRandomBalance)/@PoolLimitStopper)*100
							
				IF(@OutstandingBalancePercentage >= 0.75)
				BEGIN 
					;WITH cteRunningTtl AS 
					(
					SELECT t1.FacilityId	
							,t1.Balance
							,PrecedingSum = SUM(t1.Balance) OVER ( ORDER BY t1.Balance ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW )
					FROM #AccountKeysBeforeRandom t1
					LEFT JOIN #RandomAccountKeys t2
					ON t1.FacilityId = t2.FacilityId									
					WHERE t2.FacilityId IS NULL
					)
					INSERT INTO #RandomAccountKeys(FacilityId, Balance)
					SELECT FacilityId
							,Balance 
					FROM cteRunningTtl
					WHERE  PrecedingSum > 0 AND PrecedingSum  < (@PoolLimitStopper-@TotalRandomBalance)
				END		
				IF EXISTS (SELECT 1 FROM #tempEligibilityCriteria)
				BEGIN
					/* Insert those records in PoolEligibilityBuildDetail table which are passed after applying EC
						but not part of pool because of Random Selection, inserting records with invalid EcId(i.e. -1) and status =-2 */
					INSERT INTO [ps].[PoolEligibilityBuildDetail]([PoolId], [LoanId], [EligibilityCriteriaId], [LoanBalance], [Status])
					SELECT @PoolID,
							ak.FacilityId,
							-1,
							ak.Balance,
							-2
					FROM #AccountKeysBeforeRandom ak 						
					WHERE NOT EXISTS (SELECT FacilityId FROM #RandomAccountKeys rak WHERE rak.FacilityId = ak.FacilityId )								
				END
			END 
			ELSE
			BEGIN
				INSERT INTO #RandomAccountKeys(FacilityId)
				SELECT FacilityId FROM #AccountKeysBeforeRandom
			END

         /*Random Selection code end */ 
        
		  INSERT INTO #Result                           
		  SELECT DISTINCT @PoolID AS PoolId,    
			ake.FacilityId,    
			ake.FacilityKey,  
			ake.Balance  
		  FROM #AccountKeys ake    
		  INNER JOIN #RandomAccountKeys rak ON ake.FacilityId = rak.FacilityId   

		  SELECT @CountRS = COUNT(DISTINCT FacilityId) from #Result
		  SELECT @BalanceRS = SUM(Balance) from #Result

		  IF(@IsRandomSelection = 1)
		  BEGIN
			  SET @CTRemarks = 'Random Selection Logic Applied With Count: '+ CONVERT(VARCHAR,@CountRS) +' and Balance: '+CONVERT(VARCHAR,ISNULL(@BalanceRS, 0))
			  EXEC [app].[spInsertExecutionLog] @PoolId, @CTRemarks
		  END

		   IF(LEN(@CTID) > 0)  
		   BEGIN  
				SET @CTRemarks = 'Concentration Test Run: '+CAST(@CTRunCount AS varchar(5))+' Started.'  
				EXEC [app].[spInsertExecutionLog] @PoolId, @CTRemarks 			
				
				/*
				DECLARE @CTSupersetExpr VARCHAR(MAX) = ''
				SELECT @CTSupersetExpr = ct.CTExpression_Superset  
				FROM ps.PoolCTMap ctMap 								                                              
				INNER JOIN  ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1 				 
				WHERE ctMap.PoolId = @PoolId 	

				IF (NULLIF(@CTSupersetExpr,'') IS NOT NULL)
				BEGIN
					/* Replacing criteria field name with criteria field sql in the CT expression STARTS*/                
					SELECT CriteriaFieldName, CriteriaFieldSql, @CTSupersetExpr AS expression, FieldDataType          
					INTO #tempCTFields_Superset
					FROM #tempEligibility  
					WHERE EligibilityCriteriaId = -1 AND CriteriaFieldName <> CriteriaFieldSql  

					UPDATE #tempCTFields_Superset  
					SET expression  = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(expression, '(', '( '), ')', ' )'), ', ', ' ,'), '[', '[ '), ']', ' ]')
  
					;WITH ctSuperset (OriginalExpression, CorrectedExpression, PassNum, CriteriaFieldName) AS  
					  (  
						 SELECT ctFields.expression AS CorrectedExpression, ctFields.expression AS OriginalExpression, 1 AS PassNum, CriteriaFieldName   
						 FROM #tempCTFields_Superset ctFields  
						 UNION ALL  
						 SELECT ctSuperset.OriginalExpression   
							   ,CAST([ps].[fn_ReplaceWholeWord]( CASE WHEN FieldDataType = @BoolFieldDataTypeId 
																	  THEN REPLACE(REPLACE(ctSuperset.CorrectedExpression, ctFields.CriteriaFieldName + ' = ''N''', ctFields.CriteriaFieldName + ' IN (''N'',''No'',''False'')'), ctFields.CriteriaFieldName + ' = ''Y''', ctFields.CriteriaFieldName + ' IN (''Y'',''Yes'',''True'')') 
																	  ELSE ctSuperset.CorrectedExpression 
																  END,  
																	  ctFields.CriteriaFieldName,  '('+ctFields.CriteriaFieldSql+')'
																) AS VARCHAR(MAX)) AS CorrectedExpression  
							   ,PassNum+1 AS PassNum  
							   ,ctFields.CriteriaFieldName   
						FROM ctSuperset CROSS JOIN #tempCTFields_Superset ctFields   
						WHERE ( '.'+ ctSuperset.CorrectedExpression +'.' like '%[^a-z]'+ ctFields.CriteriaFieldName +'[^a-z]%' OR     
								'.'+ ctSuperset.CorrectedExpression +'.' like '[^a-z]'+  ctFields.CriteriaFieldName +'[^a-z]%' OR     
								'.'+ ctSuperset.CorrectedExpression +'.' like '%[^a-z]'+ ctFields.CriteriaFieldName +'[^a-z]'   
							  )   
					 )  
          
					UPDATE #tempCTFields_Superset    
					SET expression = ctSuperset.CorrectedExpression   
					FROM #tempCTFields_Superset ctFields   
					INNER JOIN ctSuperset  ON ctFields.expression = ctSuperset.OriginalExpression   
					WHERE ctSuperset.passnum=(SELECT MAX(PassNum) FROM ctSuperset)  
  
					-- Reverting square brackets to its previous state so that sql can evaluate expression value within brackets.  
					UPDATE #tempCTFields_Superset  
					SET expression  = REPLACE(REPLACE(REPLACE(REPLACE(REPLACE(expression, '( ', '('), ' )', ')'), ' , ', ','), '[ ', '['), ' ]', ']')            
          
					SELECT TOP 1 @CTSupersetExpr =  expression FROM #tempCTFields_Superset;        
					/* Replacing criteria field name with criteria field sql in the CT expression ENDS*/				
								
				END 
				ELSE
				BEGIN
					SET @CTSupersetExpr ='1=1'
				END
				*/

				IF EXISTS (SELECT 1 FROM ps.Pool WHERE PoolPurposeId = 2 AND PoolId = @PoolID) -- Check if pool purpose is Topup or not
				BEGIN
					
					IF OBJECT_ID('tempdb.dbo.#Staging', 'U') IS NULL
					BEGIN
						DECLARE @CTName VARCHAR(MAX) = ''
					
						SELECT @CTName = @CTName + '[' + ct.CriteriaName + ']' + ','   
						FROM ps.Pool pl                                               
						INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId 
						INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId 
						WHERE pl.PoolId = @PoolId AND ctMap.IsActive = 1
					
					
						IF(CHARINDEX(@CT_WildCard,@CTName)>0)
						SELECT @CTSelectColumn = CONCAT(@CTSelectColumn, 'IIF(SUM(RONA) < MAX(DealInitialSize_TP),1,0) AS ['+CONVERT(VARCHAR,@CT_WildCardPoolCTMapID)+'],') 
					
					
					
						SELECT DISTINCT * INTO #Staging FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE RowId = @RowID				

						/*This will update RONA value for source pool so that it can be used in CT, for Target Deal RONA from Common sp will be used*/
						UPDATE stg 
						SET stg.RONA = cr.AvailableRonaForAllocation
						FROM #Staging stg
						JOIN #CalculatedRona cr ON stg.FacilityKey = cr.FacilityKey	
					
					IF (@pRowIdForCT IS NULL)
					BEGIN
		
						EXEC [corp].[syn_Corporate_sp_rpt_CommercialFacilityEntity]
							 @VintageDate = @VintageDate,    
							 @DealKey  = @TargetPool,    
							 @FacilityIds = NULL,    
							 @ReqColumns  = @ReqCols,    
							 @XmlData = NULL,
							 @OutputRowID = @RowIDForCT OUTPUT
					END
					ELSE SET @RowIDForCT = @pRowIdForCT
					
					SELECT DISTINCT *, DealInitialSize AS DealInitialSize_TP INTO #Staging_TP FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WITH (NOLOCK) WHERE RowId = @RowIDForCT

					END

					DECLARE @DealInitialSize_TargetPool DECIMAL(38,2) = 0.00

					IF NOT EXISTS(SELECT 1 FROM #Staging_TP) /*In case target deal is blank*/
					BEGIN
						SET @DealInitialSize_TargetPool = (SELECT TOP 1 DealInitialSize FROM [corp].[syn_SfpModelCorporate_vw_dimCorporateDeal] WHERE DealId = @TargetPool)
					END

					SELECT DISTINCT s.*,@DealInitialSize_TargetPool AS DealInitialSize_TP  
					INTO #DataForCT
					FROM #Staging s  
					INNER JOIN #Result r ON r.FacilityKey = s.FacilityKey 
					UNION 
					SELECT * FROM #Staging_TP
				
					SELECT FacilityId, Sum(RONA) AS RONA 
					INTO #DataForCT_Agg 
					FROM (SELECT FacilityId, RONA, ROW_NUMBER() OVER(PARTITION BY FacilityId, RowId ORDER BY FacilityId) AS rn FROM #DataForCT) ctdata 
					WHERE ctdata.rn = 1
					GROUP BY FacilityId 
				
					UPDATE a 
					SET a.RONA = b.RONA 
					FROM #DataForCT a 
					INNER JOIN #DataForCT_Agg b ON a.FacilityId = b.FacilityId
      
					SET @CTEvalQuery= 'INSERT INTO #CTEval SELECT DISTINCT '+CAST(@PoolID AS VARCHAR(10))+', '+SUBSTRING(@CTSelectColumn, 0, LEN(@CTSelectColumn))+' 
					FROM (SELECT *, ROW_NUMBER() OVER(PARTITION BY FacilityId ORDER BY FacilityId) AS rn FROM #DataForCT) ctdata WHERE rn = 1'
				END

				ELSE

				BEGIN

					SELECT DISTINCT s.*, 1 AS rn  INTO #DataForCT1
					FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] s  
					INNER JOIN #Result r ON r.FacilityKey = s.FacilityKey 
					WHERE s.RowId = @RowID	

					SET @CTEvalQuery= 'INSERT INTO #CTEval SELECT DISTINCT '+CAST(@PoolID AS VARCHAR(10))+', '+SUBSTRING(REPLACE(@CTSelectColumn,'#DataForCT','#DataForCT1'), 0, LEN(REPLACE(@CTSelectColumn,'#DataForCT','#DataForCT1')))+' FROM #DataForCT1 '
				END

				--PRINT (CAST(@CTEvalQuery AS NTEXT))
				EXEC (@CTEvalQuery)  

				PRINT('@CTEvalQuery Executed')

				IF OBJECT_ID('tempdb.dbo.#DataForCT', 'U') IS NOT NULL
					DROP TABLE #DataForCT

				IF OBJECT_ID('tempdb.dbo.#DataForCT1', 'U') IS NOT NULL
					DROP TABLE #DataForCT1

				IF OBJECT_ID('tempdb.dbo.#DataForCT_Agg', 'U') IS NOT NULL
					DROP TABLE #DataForCT_Agg
     
				DELETE FROM PS.PoolCTDetail WHERE PoolCTMapId IN( SELECT PoolCTMapId FROM ps.PoolCTMap WHERE PoolId = @PoolId)  
      
				SET @UnPivotCTResult = N'INSERT INTO ps.PoolCTDetail (PoolCTMapId, ResultPercent)   
					   SELECT CT_MapId,CT_Result   
					   FROM #CTEval      
					   UNPIVOT ( CT_Result  FOR CT_MapId IN ('+ SUBSTRING(@CTID, 0, LEN(@CTID))+')  ) unpvt'      
        
				EXEC (@UnPivotCTResult)     
       
				/*Calculating Result of all applied CT's per CT wise*/  
				IF OBJECT_ID('tempdb.dbo.#CTResult', 'U') IS NOT NULL  
				DROP TABLE #CTResult;  
  
				CREATE TABLE #CTResult(Id INT,Status INT)  
  
				SET @CTEResultQuery = ''  
  
				SELECT @CTEResultQuery =  @CTEResultQuery + 'SELECT '+CAST(ctMap.PoolCTMapId AS varchar(10))+' AS PoolCTMapId, CASE WHEN '+ CAST(pctDetail.ResultPercent AS VARCHAR(10))+' '+IIF(ct.ConcentrationTestTypeId = 3,'=', o.Operator)+' '+CAST(IIF(ct.ConcentrationTestTypeId = 3,1,ct.LimitPercentage) AS varchar(10))+' THEN 1 ELSE 0 END AS Status UNION '  
				FROM ps.Pool pl                                               
				INNER JOIN ps.PoolCTMap ctMap ON ctMap.PoolId = pl.PoolId AND ctMap.IsActive = 1  
				INNER JOIN ps.PoolCTDetail pctDetail ON pctDetail.PoolCTMapId = ctMap.PoolCTMapId  
				INNER JOIN ps.ConcentrationTest ct ON ct.ConcentrationTestId = ctMap.ConcentrationTestId AND ct.isActive = 1  
				INNER JOIN ps.Operator o ON o.OperatorId = ct.LimitOperator AND o.isActive = 1  
				WHERE pl.PoolId = @PoolId  
         
			   IF(@CTEResultQuery <> '')
			   BEGIN
					SET @CTEResultQuery = 'INSERT INTO #CTResult ' + SUBSTRING(@CTEResultQuery, 0, LEN(@CTEResultQuery)-5) /*Minus 5 is to remove "Union" at the end*/
					EXEC (@CTEResultQuery)

					PRINT('@CTEResultQuery Executed')
		
					/*Getting out Concentration Test Status if pass or fail*/  
					SELECT @CTStatus = IIF(MIN(Status) = 0, 'Fail','Pass') FROM #CTResult 					
					
					SET @FailedCTList = ''

					SELECT @FailedCTList = COALESCE(@FailedCTList + ',', '') + CAST(pcm.ConcentrationTestId AS VARCHAR(10)) 
					FROM ps.PoolCTMap pcm 
					INNER JOIN #CTResult ctr ON pcm.PoolCTMapId = ctr.Id 
					WHERE ctr.Status = 0 ORDER by pcm.ConcentrationTestId 
       
					SET @CTRemarks = 'Concentration Test Run: '+CAST(@CTRunCount AS varchar(5))+' ,Status: '+@CTStatus+ ' ('+ISNULL(@FailedCTList, '')+')' 
					EXEC [app].[spInsertExecutionLog] @PoolId, @CTRemarks  
			   END  
		   END  
		   ELSE  
		   BEGIN  
				SET @CTStatus = 'Pass'  
		   END   

		  /*Increment While Loop Counter. In case random seletion is not slelected, no need to run CT test again*/
			IF(@IsRandomSelection = 1)
			SET @CTRunCount = @CTRunCount + 1
			ELSE
			SET @CTRunCount = 11
	  END /*Concentratiion Test While Loop End*/  

	
  
     /*Updating final results into Pool CT Details Table */  
     IF(LEN(@CTID) > 0 AND OBJECT_ID('tempdb.dbo.#CTResult', 'U') IS NOT NULL)  
     BEGIN  
		  UPDATE ps.PoolCTDetail  
		  SET ResultStatus = c.Status  
		  FROM ps.PoolCTDetail p  
		  INNER JOIN #CTResult c ON c.Id = p.PoolCTMapId  
        
		  EXEC  [app].[spInsertExecutionLog] @PoolId, 'Concentration Test Run Completed and Data Saved into ps.PoolCTDetail Table'        
     END             
       
     IF OBJECT_ID('tempdb.dbo.#AccountKeysBeforeRandom', 'U') IS NOT NULL  
      DROP TABLE #AccountKeysBeforeRandom;       
     IF OBJECT_ID('tempdb.dbo.#RandomAccountKeys', 'U') IS NOT NULL  
      DROP TABLE #RandomAccountKeys;  
     IF OBJECT_ID('tempdb.dbo.#AccountKeys', 'U') IS NOT NULL  
      DROP TABLE #AccountKeys;  
     IF OBJECT_ID('tempdb.dbo.#CTEval', 'U') IS NOT NULL  
      DROP TABLE #CTEval;  
           
    END     
      
    /*#2 Else Part Start*/  
    ELSE  
    BEGIN   
     SET @ReturnValue = -4  
    END     
    /*#2 Else Part End*/   
      
    /*#2 End*/      
   END     
     
   /*#1 Else Part Start*/  
   ELSE IF NOT EXISTS(SELECT EligibilityCriteriaId FROM #tempEligibility) AND   
     (EXISTS (SELECT 1 FROM PS.PoolSourcingType WHERE [Description] NOT IN ('Standard') AND IsActive = 1 AND SourcingTypeId = @poolSourcingTypeId))  
   BEGIN      
    INSERT INTO #Result  
    SELECT @PoolID as PoolId, adv.FacilityId, adv.FacilityKey, adv.Balance     
    FROM #finalOutputFromAdvanceSource adv;  
      
    EXEC  [app].[spInsertExecutionLog] @PoolId, 'Sourcing Type Selected is Advance Source'    
   END   
   /*#1 Else Part End*/  
  
   /*#1 End*/  
  
   /*Delete data from staging table*/  
   IF(LEN(@RowID)> 0)  
   BEGIN  
    DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE (RowId = @RowID AND RowId <> @pRowId) OR (RowId = @RowIDForCT AND RowId <> @pRowIdForCT)
    EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Deleted From SfpPlusCorporateStaging Table'  
   END  
  
  
   DELETE FROM PS.PoolBuildDetail WHERE PoolID = @PoolID 
   DELETE FROM ps.PoolFacilityCherryPickState WHERE PoolID = @PoolID 
   EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Deleted from ps.PoolBuildDetail Table'  

    
   Print 'Begin Insert Into PoolBuildDetail' 
   INSERT INTO PS.PoolBuildDetail    
   (    
    PoolId,     
    LoanId,     
    MortgageAccountKey,  
    LoanBalance  
   )                                        
   SELECT DISTINCT PoolId,     
    FacilityId,
    FacilityKey, 
    SUM(Balance) OVER(PARTITION BY FacilityId)  
   FROM #Result
     
   print 'Inserted Into PoolBuildDetail'      
   EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Inserted Into ps.PoolBuildDetail Table'      
  
                       
   --Updating Pool Table : In Case having EC so for Sourcing Type (2, 3) needs to do this in its specific sp as well   
     
   SELECT @PoolBalance = SUM(Balance),   
       @NumberOfAccount = COUNT(DISTINCT FacilityKey),   
       @NumberOfSubAccount = 0 --COUNT(MortgageSubAccountKey)    
   FROM #Result  
     
                                 
   UPDATE [ps].[Pool]                                       
   SET  [BuiltBy] = @UserName,   
		[BuiltDate] = @CurrentDateTime,   
		[ModifiedBy] = @UserName,   
		[ModifiedDate] = @CurrentDateTime,                        
		[PoolStatusId] = IIF(LEN(@CTID) > 0 AND @CTStatus = 'Fail', 8, 2),  
		[IsRebuildRequired] = 0,   
		[IsPoolBuildInProgress] = 0,  
		[NumberOfAccount] = @NumberOfAccount,                        
		[NumberOfSubAccount] = @NumberOfSubAccount,    
		[TrueBalance] = IIF(@PoolLimitAnalysisFieldId = 2, @PoolBalance, 0.00),                    
		[CapitalBalance] = IIF(@PoolLimitAnalysisFieldId = 1, @PoolBalance, 0.00),                      
		[CurrentPoolAmount] = @PoolBalance,  
		[PoolBuildTime] = DATEDIFF(S,@StartTime,GETUTCDATE()), /*update last pool build elapsed time in pool table*/      
		[EffectiveDate] = NULL,  
		[NoticeDate] = NULL,  
		[AuthorizedBy] = NULL,  
		[AuthorizedDate] = NULL  
	WHERE [PoolId] = @PoolId;  
  
	EXEC  [app].[spInsertExecutionLog] @PoolId, 'Data Updated For ps.Pool Table'  
  
	EXEC [ps].[spGetPoolById] @PoolId, @UserName  

	IF EXISTS (SELECT 1 FROM ps.Pool WHERE PoolPurposeId = 3 AND PoolId = @PoolID) -- Check if pool purpose is Repurchase or not
				BEGIN
					EXEC [corp].[UpdatePoolLimitAnalysisOnRepurchase]   @PoolId
				END
     
  
	--COMMIT TRANSACTION BuildPool;         
     
	IF OBJECT_ID('tempdb..#tempEligibilityCriteria') IS NOT NULL  
	BEGIN  
	DECLARE @ECCount INT  
	SELECT @ECCount = COUNT(*) FROM #tempEligibilityCriteria  
	SET @Remarks =  @Remarks + ' and EC Count: '+ CAST(ISNULL(@ECCount, 0) AS VARCHAR(10))  
	END  
    
	EXEC  [app].[spInsertExecutionLog] @PoolID,'Build End','ps.spBuildPool',@Remarks    
    
	--IF OBJECT_ID('tempdb..#MortgageData') IS NOT NULL  
	-- DROP TABLE #MortgageData     
	IF OBJECT_ID('tempdb.dbo.#CustomECFields', 'U') IS NOT NULL  
	DROP TABLE #CustomECFields  
	IF OBJECT_ID('tempdb.dbo.#tempEligibilityWithCustomFields', 'U') IS NOT NULL  
	DROP TABLE #tempEligibilityWithCustomFields      
	IF OBJECT_ID('tempdb.dbo.#Result', 'U') IS NOT NULL  
	DROP TABLE #Result     
  
	RETURN @ReturnValue   
          
 END TRY                                      
 BEGIN CATCH                                      
        
	DECLARE                                       
	@errorMessage     NVARCHAR(MAX),                                      
	@errorSeverity    INT,           
	@errorNumber      INT,                                      
	@errorLine        INT,                                      
	@errorState       INT; 
	                                   
	SELECT @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                     
       
	IF(LEN(@RowID) > 0)  
	BEGIN  
		DELETE FROM [corp].[syn_Corporate_tbl_rpt.SfpPlusCorporateStaging] WHERE (RowId = @RowID AND RowId <> @pRowId) OR (RowId = @RowIDForCT AND RowId <> @pRowIdForCT)
		EXEC [app].[spInsertExecutionLog] @PoolId, 'Data Deleted From SfpPlusCorporateStaging Inside Catch Block'  
	END   
  
	SET @errorMessage = 'Error Occured: '+@errorMessage  
	EXEC  [app].[spInsertExecutionLog] @PoolId, @errorMessage,'ps.spBuildPoolCorporate',@Remarks    
  
	UPDATE ps.[Pool]  SET IsPoolBuildInProgress = 0 WHERE [PoolId] = @PoolId;                               
                                      
	EXEC app.SaveErrorLog 2, 1, 'spBuildPoolCorporate', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @UserName                       
                                    
	RAISERROR (@errorMessage, @errorSeverity, @errorState )  
	RETURN @ReturnValue  
	                                     
 END CATCH  
	
END
GO

