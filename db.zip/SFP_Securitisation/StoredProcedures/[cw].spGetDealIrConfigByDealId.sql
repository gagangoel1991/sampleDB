USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetDealIrConfigByDealId]') IS NOT NULL
	DROP PROCEDURE [cw].spGetDealIrConfigByDealId 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].spGetDealIrConfigByDealId  
/*  
 * Author: Sakthivel Loganathan 
 * Date: 03.04.2022  
 * Description:  This will return the Deal Ir Config single record based on dealID and report type name 
 * -------------------------------------------------------  
*/  
@pDealId INT = NULL,  
@pReportTypeName VARCHAR(50)
AS  
BEGIN  
  
 SET NOCOUNT ON  
  
 BEGIN TRY    
  
  DECLARE @ReportTypeId INT;
  SELECT @pReportTypeName =  ISNULL(NULLIF(@pReportTypeName,''), 'IR')
  SELECT @ReportTypeId = ReportTypeId FROM [cfgCW].[IR_ReportType] WHERE ReportTypeName = @pReportTypeName 
 

   DECLARE @defaultTemplateFile varchar(255)  
   , @DraftRequestCreatedBy varchar(255)  
   , @IR_Reporting_Management INT =1  
   , @WorkflowName varchar(40)='IR_Reporting_Management'  
     
   SELECT @defaultTemplateFile = Value FROM cw.vw_DealLookup WHERE TypeCode='Build_IR' AND Name='IR_Template' 
   
    DECLARE @WorkFlowStepId INT = (SELECT WorkflowStepId FROM [cfgCW].[WorkflowStep] WHERE StepName = 'Authorise' 
								AND WorkflowTypeId = (SELECT WorkflowTypeId FROM [cfgCW].[WorkflowType] WHERE Name = 'IR_Reporting_Management' ))

   DECLARE @pDealIrConfigId INT = (SELECT DealIrConfigId FROM [cfgCW].[IR_DealIrConfig] 
								   WHERE ReportTypeId = @ReportTypeId AND  WorkflowStepId = @WorkFlowStepId AND DealId = @pDealId )
      
  
   SELECT IR_Conf.Name,  
   IR_Conf.Description,  
   IR_Conf.DealId,  
   IR_Conf.TemplateId,  
   IR_Conf.OriginalFileName,  
   IR_Conf.UploadedFileName,  
   IRT.OriginalFileName AS TemplateFileName,  
   @defaultTemplateFile AS DefaultFileName,  
   IR_Conf.WorkflowStepId,  
   wfc.Comment AS AuthorizerComment,  
   isNull(wf.ActionedBy, '') AS 'AuthRequestorUserName',  
   isNull(@DraftRequestCreatedBy,'') AS 'DraftRequestCreatedBy',  
   IR_Conf.ModifiedBy AS LastModifiedUserName,  
   IR_Conf.ModifiedDate AS LastModifiedDate,  
   ws.DisplayName AS Status  ,
   IR_Conf.DealIrConfigId,
   [cw].[fnGetReportLookupValueByName]('ESMA',@pReportTypeName,'ESMA_ANNEX_PARENT_SHEET')  AS  ReportParentSheet
   FROM [cfgCW].[IR_DealIrConfig] IR_Conf  
   LEFT JOIN cfgCW.IR_Template IRT ON IRT.TemplateID=IR_Conf.TemplateID  AND IR_Conf.ReportTypeId = IRT.ReportTypeId
   LEFT JOIN (SELECT ActionedBy, ProcessReferenceId   
      FROM [cw].[vwWorkflowProcess]   
      WHERE WorkflowProcessId = ( SELECT MAX(WorkflowProcessId)   
          FROM [cw].[vwWorkflowProcess]  
          WHERE Name=@WorkflowName  
          AND DisplayName ='Pending Authorisation'  
          AND ProcessReferenceId=@pDealIrConfigId )  
      ) wf ON Wf.ProcessReferenceId = IR_Conf.DealIrConfigId  
   LEFT JOIN (SELECT Comment, ProcessReferenceId  
      FROM [cw].[vwWorkflowProcess]   
      WHERE WorkflowProcessId = ( SELECT MAX(WorkflowProcessId)   
          FROM [cw].[vwWorkflowProcess]  
          WHERE Name=@WorkflowName AND ProcessReferenceId=@pDealIrConfigId   
          )) wfc ON Wfc.ProcessReferenceId = IR_Conf.DealIrConfigId        
   LEFT JOIN cfgCW.WorkflowStep ws ON ws.WorkflowStepId = IR_Conf.WorkflowStepId AND ws.WorkflowTypeId=@IR_Reporting_Management  
   WHERE DealIrConfigId = @pDealIrConfigId  AND IR_Conf.ReportTypeId = @ReportTypeId 
     
 END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'spGetDealIrConfigByDealId', @errorNumber,  @errorSeverity, @errorLine, @errorMessage , ''  
  RAISERROR (@errorMessage,@errorSeverity, @errorState )  
 END CATCH  
END
GO

--go
-- exec [cw].spGetDealIrConfigByDealId  @pDealId  = 6,@pReportTypeName = 'ANNEX2D'