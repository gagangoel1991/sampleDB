USE SFP_Securitisation

GO


IF OBJECT_ID('[cw].[spGetDailyCollectionDateList]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetDailyCollectionDateList]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--/*  
--Author: Arun  
--Date:    07.07.2022  
--Description:  This will return last 5 dates based on date passed.  
--Usage : [cw].[spGetDailyCollectionDateList]  '2022-05-31','Dunmore1'        
--go
--[cw].[spGetDailyCollectionDateList]  '2022-05-31','Dunmore1','Advice'      
--Change History  
----------------  
--Author              Date                 Description  
---------------------------------------------------------  
--*/  

CREATE PROCEDURE [cw].[spGetDailyCollectionDateList] 
   @pAsAtDate DATE = null 
  ,@pDealName VARCHAR(255)
  ,@pDateType VARCHAR(50)='Collection'
  ,@pUserName VARCHAR(50) = NULL    
AS  
BEGIN  
BEGIN TRY  
   
   		DECLARE @dealId INT, @dealRegionCode VARCHAR(10);  
	 		

		SELECT @dealRegionCode = [DealRegionCode], @dealId = dealId FROM [cw].[vw_ActiveDeal] WHERE DealName = @pDealName  

		IF @pDateType ='Collection'
			SELECT Top 5 AsAtDate 
			FROM sfp.syn_SfpModel_vw_Calendar_v1
			WHERE AsAtDate<@pAsAtDate AND RegionCode = @dealRegionCode AND IsWorkingDay = 1
			ORDER BY AsAtDate DESC
		ELSE IF @pDateType ='Advice'
			SELECT Top 5 AsAtDate 
			FROM sfp.syn_SfpModel_vw_Calendar_v1
			WHERE AsAtDate<=@pAsAtDate AND RegionCode = @dealRegionCode AND IsWorkingDay = 1
			ORDER BY AsAtDate DESC


END TRY
		BEGIN CATCH  
		DECLARE   
		   @errorMessage     NVARCHAR(MAX),  
		   @errorSeverity    INT,  
		   @errorNumber      INT,  
		   @errorLine        INT,  
		   @errorState       INT;  
  
		SELECT   @errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1,1,'cw.spGetDailyCollectionDateList', @errorNumber, @errorSeverity, @errorLine, @errorMessage, @pUserName
  
		RAISERROR (@errorMessage,  @errorSeverity,  @errorState )  

	END CATCH

END

GO