USE [SFP_Securitisation]

GO


IF OBJECT_ID('[cb].[spGetCapitalAccountLedger]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetCapitalAccountLedger]
GO

GO
/****** Object:  StoredProcedure [cb].[spGetReserveFund]    Script Date: 11/17/2022 10:05:06 AM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
--==================================  
--Author: Arun
--Date: 17-11-2022 
-- Change History
--Description: GET Revenue Ledger
--[cb].[spGetCapitalAccountLedger] 6,69,''
--==================================   
CREATE PROCEDURE [cb].[spGetCapitalAccountLedger] @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY

		DECLARE @dealId  INT, 
					  @ipdDate DATE

		SELECT @dealId = DealId, 
					@ipdDate = IpdDate
			  FROM   cw.vwDealIpdRun dir
			  WHERE  DealIpdRunId = @pIPDRunId 

		SELECT CAST(CONVERT(VARCHAR(10), ipd.IpdDate, 103) AS VARCHAR) AS IpdDate
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN wliParent.ParentLineItemId
				ELSE ISNULL(litem.ParentLineItemId, 0)
				END ParentId
			,CASE 
				WHEN wliParent.ParentLineItemId IS NOT NULL
					THEN 1
				ELSE 0
				END IsSubLineItems
        	,litem.DisplayTextUI
			,litem.FieldName
			,scf.CapitalAccountLedger_bF
			,scf.CapitalDistribution
			,scf.CapitalDistributionLLPtoNW
			,scf.LossesSoldToLLP
			,scf.CapitalisedInterest
			,scf.BorrowerLoanAdvance
			,scf.LoanSecuritySaleToLLP
			,scf.SubsitutionAssetSale
			,scf.PaymentTermination
			,scf.PaymentCouponAmount
			,scf.PaymentCouponAmountShortfall
			,scf.PaymentRedemtionAmount
			,scf.CashCapitalRedemtionContribution
			,scf.CapitalAccountLedger_cf
		FROM cfgcb.CoveredBondFund cbf
		JOIN [cb].[CapitalAccountLedger] scf ON cbf.CoveredBondFundId = scf.CoveredBondFundId
		JOIN [CW].[vwDealIpdRun] dir ON dir.DealIpdRunId = scf.DealipdRunid
		JOIN cw.DealIpd ipd ON ipd.DealIpdId = dir.DealIpdId
		JOIN [cfgcb].[CoveredBondFundLineItemUI] litem ON cbf.CoveredBondFundId = litem.CoveredBondFundId
		LEFT JOIN (
			SELECT DISTINCT ParentLineItemId
			FROM [cfgcb].[CoveredBondFundLineItemUI]
			) AS wliParent ON wliParent.ParentLineItemId = litem.CoveredBondFundLineItemId
		WHERE dir.DealIpdRunId IN (
				SELECT RunId
				FROM cw.fnGetPrevIpdRunIds(@pDealId, @pIPDRunId, 4)
				)
		ORDER BY ipd.IpdDate DESC
	
	END TRY
	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spGetCapitalAccountLedger'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END

GO
