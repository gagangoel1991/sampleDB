USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetRPPSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetRPPSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spIR_GetRPPSummary 
(
@pAsAtDate datetime,
 @pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL
) 
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get revenue priority of payment summary for IR liability Strats
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
*/ 
AS 
 BEGIN 
	BEGIN TRY 
  

     DECLARE 
		@dealIpdRunId        INT,
        @dealId              SMALLINT,
        @ipdDate             DATETIME,
        @previousIPDDateName VARCHAR(200)='PreviousIPD',
		@PreviousRunNum      SMALLINT,
		@previousIpdDate      DATE,  
		@dealPreviousIpdRunId INT  
  

      IF( Object_id('tempdb..#temp') IS NOT NULL ) 
        DROP TABLE #temp 

      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL ) 
        DROP TABLE #tempPrevious 

		 SELECT   
	  @dealIpdRunId = dir.DealIpdRunId  
	  , @dealId = dir.DealId  
	  , @ipdDate = di.IpdDate  
	  , @previousIpdDate  = ipdDt.PreviousIPD  
	 FROM     
	  cw.vwDealIpdDates ipdDt  
	 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
	 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
	 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
	 WHERE   
	  deal.DealName = @pDealName  
	  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
	  AND dir.IpdSequence <> 0   
	        
	 SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
	 JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
	 WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1  

    SELECT 
		wli.WaterfallLineItemId, 
		wli.DisplayName, 
		IIF(wliParent.ParentWaterfallLineItemId IS NOT NULL, wliParent.TotalRequiredAmount, rwps.TotalRequiredAmount) AS CurrentRequiredAmount, 
		IIF(wliParent.ParentWaterfallLineItemId IS NOT NULL, wliParent.TotalPaidAmount, rwps.TotalPaidAmount) AS CurrentPaidAmount, 
		IIF(wliParent.ParentWaterfallLineItemId IS NOT NULL, wliParent.RemainingDueAmount, rwps.RemainingDueAmount) AS CurrentShortfall,
		CONVERT(DECIMAL(38, 16), NULL) PreviousRequiredAmount, 
		CONVERT(DECIMAL(38, 16), NULL) PreviousPaidAmount, 
		CONVERT(DECIMAL(38, 16), NULL) PreviousShortfall ,
		wli.SortOrder
	INTO   
		#temp 
	FROM   
		cw.RevenueWaterfallPaymentSummary rwps
	JOIN
		cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = rwps.WaterfallLineItemId 
	LEFT JOIN
		(
			SELECT wliParent1.ParentWaterfallLineItemId, SUM(lineItemSum.TotalRequiredAmount) AS TotalRequiredAmount,
				SUM(lineItemSum.TotalPaidAmount) AS TotalPaidAmount, SUM(lineItemSum.RemainingDueAmount) AS RemainingDueAmount
			FROM 
				cfgCW.WaterfallLineItem wliParent1
			JOIN 
				cw.RevenueWaterfallPaymentSummary lineItemSum ON lineItemSum.WaterfallLineItemId = wliParent1.WaterfallLineItemId
			WHERE
				lineItemSum.DealIpdRunId = @DealIpdRunId 
			GROUP BY 
				ParentWaterfallLineItemId 
		) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	WHERE  
		rwps.DealIpdRunId = @DealIpdRunId 
		AND wli.ParentWaterfallLineItemId IS NULL
		ORDER BY 
		wli.SortOrder ASC 

	SELECT 
		wli.WaterfallLineItemId, 
		IIF(wliParent.ParentWaterfallLineItemId IS NOT NULL, wliParent.TotalRequiredAmount, rwps.TotalRequiredAmount) AS PreviousRequiredAmount, 
		IIF(wliParent.ParentWaterfallLineItemId IS NOT NULL, wliParent.TotalPaidAmount, rwps.TotalPaidAmount) AS PreviousPaidAmount, 
		IIF(wliParent.ParentWaterfallLineItemId IS NOT NULL, wliParent.RemainingDueAmount, rwps.RemainingDueAmount) AS PreviousShortfall
	INTO   #tempPrevious 
	FROM   
		cw.RevenueWaterfallPaymentSummary rwps
	JOIN
		cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = rwps.WaterfallLineItemId 
	LEFT JOIN
		(
			SELECT wliParent1.ParentWaterfallLineItemId, SUM(lineItemSum.TotalRequiredAmount) AS TotalRequiredAmount,
				SUM(lineItemSum.TotalPaidAmount) AS TotalPaidAmount, SUM(lineItemSum.RemainingDueAmount) AS RemainingDueAmount
			FROM 
				cfgCW.WaterfallLineItem wliParent1
			JOIN 
				cw.RevenueWaterfallPaymentSummary lineItemSum ON lineItemSum.WaterfallLineItemId = wliParent1.WaterfallLineItemId
			WHERE
				lineItemSum.DealIpdRunId = @DealPreviousIpdRunId 
			GROUP BY 
				ParentWaterfallLineItemId 
		) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	WHERE  
		rwps.DealIpdRunId = @DealPreviousIpdRunId 
	ORDER  BY 
		wli.SortOrder ASC 

    UPDATE t 
    SET    PreviousRequiredAmount = tPrevious.PreviousRequiredAmount, 
            PreviousPaidAmount = tPrevious.PreviousPaidAmount, 
            PreviousShortfall = tPrevious.PreviousShortfall 
    FROM   #temp t, 
            #tempPrevious tPrevious 
    WHERE  t.WaterfallLineItemId = tPrevious.WaterfallLineItemId 

    SELECT DisplayName, 
            CONVERT(DECIMAL(38, 16), (CurrentRequiredAmount))               CurrentRequiredAmount,
            CONVERT(DECIMAL(38, 16), (CurrentPaidAmount))                   CurrentPaidAmount,
            CONVERT(DECIMAL(38, 16), (CurrentShortfall))                    CurrentShortfall,
            CONVERT(DECIMAL(38, 16), (COALESCE(PreviousRequiredAmount, 0))) PreviousRequiredAmount,
            CONVERT(DECIMAL(38, 16), (COALESCE(PreviousPaidAmount, 0)))     PreviousPaidAmount,
            CONVERT(DECIMAL(38, 16), (COALESCE(PreviousShortfall, 0)))      PreviousShortfall
    FROM   #temp 
	ORDER BY SortOrder
  END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetRPPSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  END

GO