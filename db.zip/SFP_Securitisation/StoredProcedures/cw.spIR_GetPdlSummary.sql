USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetPdlSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetPdlSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC [cw].[spIR_GetPdlSummary]   
(  
@pAsAtDate datetime,  
 @pDealName  varchar(200),  
@pUserName VARCHAR(80) = NULL  
)   
 /*   
 *   Author: Aditya Shrivastava   
 *   Date:  26.05.2020   
 *   Description:  Get Pdl summary for IR liability Strats  
 *          
 *   Change History   
 *   --------------   
 *   Author    Date    Description   
 *   -------------------------------------------------------              
 * 
 *   EXEC [cw].[spIR_GetPdlSummary]   '2020-05-29',  'DUNMORE1', ''
  */   
AS   
  BEGIN   
  BEGIN TRY   
  
   -- Declare @pDealName varchar(200)='DUNMORE1'  
   --,@pAsAtDate datetime='2020-05-29'
  
    DECLARE   
  @dealIpdRunId        INT,  
        @dealId              SMALLINT,  
        @ipdDate             DATETIME,  
        @previousIPDDateName VARCHAR(200)='PreviousIPD',  
  @previousIpdDate      DATE,  
  @dealPreviousIpdRunId INT  
  
      IF( Object_id('tempdb..#tempCurrent') IS NOT NULL )   
        DROP TABLE #tempCurrent   
  
      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL )   
        DROP TABLE #tempPrevious   
  
      IF( Object_id('tempdb..#tempFinal') IS NOT NULL )   
        DROP TABLE #tempFinal   
  
      IF( Object_id('tempdb..#tempPreviousInverted') IS NOT NULL )   
        DROP TABLE #tempPreviousInverted   
  
    SELECT   
  @dealIpdRunId = dir.DealIpdRunId  
  , @dealId = dir.DealId  
  , @ipdDate = di.IpdDate  
  , @previousIpdDate  = ipdDt.PreviousIPD  
 FROM     
  cw.vwDealIpdDates ipdDt  
 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
 WHERE   
  deal.DealName = @pDealName  
  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
  AND dir.IpdSequence <> 0   
        
 SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
 JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
 WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1  

  
  DECLARE @furtherClassAShortfallRemedy DECIMAL(38,16) = (SELECT PrincipalWaterfallTotalPaidAmount   
                  FROM cw.vwPrincipalWaterfallPaymentSummary   
                  WHERE DealIpdRunId=@dealIpdRunId  
                AND WaterfallLineItemInternalName='PrincipalPriorityofPayments_1.000');  
  
  
  DECLARE @2PreviousDealIpdRunId int =  [cw].[fnGetPrevIpdRunIdByIpdDate](@dealId, @previousIpdDate)  
  
   DECLARE 
   @arrearsPDL_PreviousIPD DECIMAL(38,16),  
   @arrearsPDL_2PreviousIPD DECIMAL(38,16),
   @Pde_PreviousIPD DECIMAL(38,16),
   @Pde_2PreviousIPD DECIMAL(38,16);

  SELECT 
  @arrearsPDL_PreviousIPD = ArrearsPDL ,
  @Pde_PreviousIPD = PDEForCurrentIPD 
  FROM cw.PDL_PreWF WHERE DealIpdRunId = @dealPreviousIpdRunId;  

   SELECT 
  @arrearsPDL_2PreviousIPD = ArrearsPDL ,
  @Pde_2PreviousIPD = PDEForCurrentIPD 
  FROM cw.PDL_PreWF WHERE DealIpdRunId = @2PreviousDealIpdRunId; 
  
  SELECT   
   pdlPre.OpeningBalance,  
    COALESCE(pdlPre.Losses, 0 ) Losses,  
   @furtherClassAShortfallRemedy FurtherClassAShortfallRemedy,  
   pdlPre.WarehouseLoanAmount  
   ,CONVERT(decimal(38,16),-1 * (pdlPre.ArrearsPDL - @arrearsPDL_PreviousIPD)) AggregateProvisionalArrearsAllocation,  
   pdlPost.TotalPDLPaidForCurrentIPD CureDebitEntires,  
   CONVERT(decimal(38,16),-1 * @Pde_PreviousIPD) PrincipalDeficiencyExcessRevenueAmount,  
   pdlPost.ClosingBalance  
      INTO   #tempCurrent   
      FROM   cw.PDL_PreWF pdlPre  
             JOIN cw.PDL_PostWF pdlPost ON pdlPre.DealIpdRunId = pdlPost.DealIpdRunId    
             JOIN cw.vwDealIpdRun dir ON  dir.DealIpdRunId = pdlPost.DealIpdRunId   
      WHERE    
    dir.DealIpdRunId = @dealIpdRunId   
    
      SELECT LineItemName,   
             CurrentPeriodAmount,   
             CONVERT(DECIMAL(38, 16), NULL) PreviousPeriodAmount   
      INTO   #tempFinal   
      FROM   #tempCurrent   
             UNPIVOT ( CurrentPeriodAmount   
                     FOR LineItemName IN ( OpeningBalance,   
                                           Losses,  
                                           FurtherClassAShortfallRemedy,  
                                           WarehouseLoanAmount   
             ,AggregateProvisionalArrearsAllocation,  
                                           CureDebitEntires,   
                              PrincipalDeficiencyExcessRevenueAmount,   
                                           ClosingBalance
             ) ) unpiv;   
  
  
   SELECT   
   pdlPre.OpeningBalance,  
    COALESCE(pdlPre.Losses, 0 ) Losses,  
   @furtherClassAShortfallRemedy FurtherClassAShortfallRemedy,  
   pdlPre.WarehouseLoanAmount  
   ,CONVERT(decimal(38,16),-1 * (pdlPre.ArrearsPDL - @arrearsPDL_2PreviousIPD)) AggregateProvisionalArrearsAllocation,  
   pdlPost.TotalPDLPaidForCurrentIPD CureDebitEntires,  
   CONVERT(decimal(38,16),-1 * @Pde_2PreviousIPD) PrincipalDeficiencyExcessRevenueAmount,  
   pdlPost.ClosingBalance 
      INTO   #tempPrevious   
      FROM   cw.PDL_PreWF pdlPre  
             JOIN cw.PDL_PostWF pdlPost ON pdlPre.DealIpdRunId = pdlPost.DealIpdRunId    
             JOIN cw.vwDealIpdRun dir ON  dir.DealIpdRunId = pdlPost.DealIpdRunId   
               
      WHERE                
   dir.DealIpdRunId = @dealPreviousIpdRunId  
   
 
      SELECT LineItemName,   
             PreviousPeriodAmount   
      INTO   #tempPreviousInverted   
      FROM   #tempPrevious   
             UNPIVOT ( PreviousPeriodAmount   
                     FOR LineItemName IN ( OpeningBalance,   
                                           Losses,   
                                           FurtherClassAShortfallRemedy,   
                                           WarehouseLoanAmount,   
                                           AggregateProvisionalArrearsAllocation,   
                                           CureDebitEntires,   
                                           PrincipalDeficiencyExcessRevenueAmount,   
                                           ClosingBalance) ) unpiv;   
  
      UPDATE #tempFinal   
      SET    #tempfinal.PreviousPeriodAmount = #temppreviousinverted.PreviousPeriodAmount   
      FROM   #tempFinal,   
             #tempPreviousInverted   
      WHERE #tempfinal.LineItemName = #temppreviousinverted.LineItemName   
  
   IF( Object_id('tempdb..#tempLineOrder') IS NOT NULL )   
        DROP TABLE #tempLineOrder   
  
  CREATE TABLE #tempLineOrder (InternalName varchar(200), DisplayName varchar(500), sortOrder decimal(9,3))  
  
  INSERT INTO #tempLineOrder VALUES  
   ('OpeningBalance','Opening Balance',1)  
  ,('Losses','Losses',2)  
  ,('FurtherClassAShortfallRemedy','Further Class A Shortfall remedy',3)  
  ,('WarehouseLoanAmount','Aggregate Warehoused Mortgage Account Amount',4)  
  ,('AggregateProvisionalArrearsAllocation','Aggregate Provisional Arrears Allocation',5)  
  ,('CureDebitEntires','Cure Debit Entires of Pre-Enforcement Revenue Priority of Payments',6)  
  ,('PrincipalDeficiencyExcessRevenueAmount','Principal Deficiency Excess Revenue Amount',7)  
  ,('ClosingBalance','Closing Balance',8)  
  
  
      SELECT DisplayName,   
             CONVERT(DECIMAL(38, 2), Round(CurrentPeriodAmount, 2))  CurrentPeriodAmount,   
             CONVERT(DECIMAL(38, 2), Round(PreviousPeriodAmount, 2)) PreviousPeriodAmount   
      FROM   #tempFinal  t1  
          JOIN  #tempLineOrder t2 ON t1.LineItemName = t2.InternalName  
      
      ORDER  BY t2.SortOrder  
  
   END TRY   
  
     BEGIN CATCH    
  DECLARE     
   @errorMessage     NVARCHAR(MAX),    
   @errorSeverity    INT,    
   @errorNumber      INT,    
   @errorLine        INT,    
   @errorState       INT;    
    
  SELECT     
  @errorMessage = ERROR_MESSAGE()
  ,@errorSeverity = ERROR_SEVERITY()
  ,@errorNumber = ERROR_NUMBER()
  ,@errorLine = ERROR_LINE()
  ,@errorState = ERROR_STATE()    
    
  EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetPdlSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName    
      
  RAISERROR (@errorMessage,    
     @errorSeverity,    
     @errorState )    
 END CATCH     
  END
  
  go
  
