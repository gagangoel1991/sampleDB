USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spGetWIPCollectionLedger]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetWIPCollectionLedger]  
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


CREATE PROC [cw].[spGetWIPCollectionLedger] 
--==================================
--Author: Saurabh Bhatia
--Date:	24-Nov-2020
--Description:  To get Collection Ledger List on the basis 
--of CollectionBusinessStart AND CollectionBusinessEnd FROM WIP
-- Exec cw.spGetWIPCollectionLedger  15,53,''
--================================== 
    @pDealId SMALLINT,
    @pIPDRunId INT,
	   @pUserName		VARCHAR(80) 
AS
BEGIN
SET NOCOUNT ON
BEGIN TRY

   DECLARE @cols AS NVARCHAR(MAX), @query  AS NVARCHAR(MAX)
   DECLARE @collectionStartDate VARCHAR(10),@collectionEndDate VARCHAR(10)

   SELECT * INTO #tempCollectionLedger FROM cw.CollectionLedger_WIP WHERE IsActive=1

	  SELECT	
			@collectionStartDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessStart AS DATE),23), 
			@collectionEndDate = CONVERT(VARCHAR(10),CAST(CollectionBusinessEnd AS DATE),23)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
       SELECT CollectionLedgerId,AdviceDate,CollectionDate,NetPrincipalCollections,FinanceCollections,OtherCollections,TotalDailyCashAmount,[Status],ModifiedBy,ModifiedDate,Reason FROM
   	   (SELECT
           wip.[Status]
          ,wip.Id AS WIPId
	         ,cl.CollectionLedgerId 
          ,ROW_NUMBER() OVER(PARTITION BY cl.CollectionDate ORDER BY Id DESC) AS RowNum 
		        ,cl.AdviceDate AS AdviceDate
		        ,cl.CollectionDate AS CollectionDate
		        ,ROUND(cl.NetPrincipalCollections,4) NetPrincipalCollections
		        ,ROUND(cl.FinanceCollections,4) FinanceCollections
		        ,ROUND(cl.OtherCollections,4) OtherCollections
		        ,ROUND(cl.TotalDailyCashAmount,4)		 TotalDailyCashAmount
          ,cl.CreatedBy AS ModifiedBy
          ,cl.CreatedDate AS ModifiedDate
		        ,wip.ChangeReason AS Reason
	         FROM cw.CollectionLedger cl 
          JOIN #tempCollectionLedger wip ON wip.CollectionLedgerId = cl.CollectionLedgerId
          WHERE cl.DealId=@pDealId  AND CAST(cl.CollectionDate AS DATE) BETWEEN @collectionStartDate AND @collectionEndDate)t  WHERE t.RowNum=1 ORDER BY CASE WHEN t.WIPId IS NOT NULL THEN 0 ELSE 1 END, t.CollectionDate
           
END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetWIPCollectionLedger', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END 
GO
