USE [SFP_Securitisation]
GO

IF EXISTS (SELECT 1 FROM sysobjects WHERE id = object_id(N'[app].[spSaveUserListingPreference]') AND OBJECTPROPERTY(id, N'IsProcedure') = 1)
	DROP PROCEDURE [app].[spSaveUserListingPreference]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [app].[spSaveUserListingPreference]                            
	@pListingPageName VARCHAR(50),            
	@pUserName VARCHAR(20),            
	@pHiddenColumnList AS [app].[ColumnList] ReadOnly, 
	@pReturnValue INT = -1 OUTPUT         
AS             
BEGIN             
	BEGIN TRY
		DECLARE @ListingPageId INT
		DECLARE @UserListingMapId INT
		DECLARE @Active BIT = 1
		DECLARE @CurrentDateTime DATETIME = GETUTCDATE()

		BEGIN TRANSACTION SFP_Sec_SaveListingPreference
			IF NOT EXISTS (SELECT 1 FROM [app].[ListingPage] WHERE ListingPageName=@pListingPageName AND IsActive = @Active)
			BEGIN
				INSERT INTO [app].[ListingPage] (ListingPageName, IsActive, [CreatedBy],[CreatedDate],[ModifiedBy],[ModifiedDate]) 
				VALUES (@pListingPageName, @Active, @pUserName, @CurrentDateTime, @pUserName, @CurrentDateTime)
			END
			
			SELECT @ListingPageId = ListingPageId FROM [app].[ListingPage] WHERE ListingPageName = @pListingPageName AND IsActive = @Active

			IF NOT EXISTS (SELECT 1 FROM [app].[UserListingMap] WHERE ListingPageId=@ListingPageId AND UserName=@pUserName AND IsActive = @Active)
			BEGIN
				INSERT INTO [app].[UserListingMap] (UserName, ListingPageID, IsActive, [CreatedBy],[CreatedDate],[ModifiedBy],[ModifiedDate]) 
				VALUES (@pUserName, @ListingPageId, @Active,@pUserName, @CurrentDateTime, @pUserName, @CurrentDateTime)
				SET @pReturnValue = 1
			END
			ELSE
				SET @pReturnValue = 2

			SELECT @UserListingMapId = UserListingMapId FROM [app].[UserListingMap] WHERE ListingPageId=@ListingPageId AND UserName=@pUserName AND IsActive = @Active

			DELETE FROM [app].[ListingHiddenColumnMap] WHERE UserListingMapId = @UserListingMapId AND IsActive = @Active
			
			INSERT INTO [app].[ListingHiddenColumnMap] (UserListingMapId, ColumnName, IsActive, [CreatedBy],[CreatedDate],[ModifiedBy],[ModifiedDate])
			SELECT @UserListingMapId, ColumnName, @Active, @pUserName, @CurrentDateTime, @pUserName, @CurrentDateTime FROM @pHiddenColumnList
		COMMIT TRANSACTION SFP_Sec_SaveListingPreference

	END TRY              
	BEGIN CATCH              
		DECLARE               
			@errorMessage     NVARCHAR(MAX),              
			@errorSeverity    INT,              
			@errorNumber      INT,              
			@errorLine        INT,              
			@errorState       INT;              
		SELECT               
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()              

		IF @@TRANCOUNT > 0
		BEGIN
			ROLLBACK TRANSACTION SFP_Sec_SaveListingPreference
		END    

		EXEC app.SaveErrorLog 2, 1, 'spSaveUserListingPreference', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName            
                
		RAISERROR (@errorMessage,              
		@errorSeverity,              
		@errorState)      
	END CATCH              
END
GO