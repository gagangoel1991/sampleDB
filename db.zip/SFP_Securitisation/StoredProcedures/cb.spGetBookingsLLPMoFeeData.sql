USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingsLLPMoFeeData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingsLLPMoFeeData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Rajesh Sahu 
--Date: 10-Feb-2023 
--Description: GET Booking NWB FO Fees Data 
--[cb].[spGetBookingsLLPMoFeeData] 6,71,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingsLLPMoFeeData] 
   @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  

BEGIN  

BEGIN TRY  
   Declare @ValueDate varchar(10);
	DECLARE @ipdDate DATE;

	IF EXISTS(SELECT 1 FROM tempdb.sys.objects WHERE object_id = OBJECT_ID(N'tempdb.dbo.#LLPMo') and type='U')
			Drop table #LLPMo
		
		CREATE TABLE #LLPMo
			(
				[Id] [int] IDENTITY(1,1) NOT NULL,
				[ValueDate] [varchar](10) NULL,
				[AccrualStart] [varchar](10) NULL,
				[AccrualEnd] [varchar](10) NULL,
				[Currency] [varchar](100) NULL,
				[FeeAmount] [decimal](38, 2) NULL,
				[TaxType] [varchar](100) NULL,
				[TaxRate] [varchar](100) NULL,
				[FeeType] [varchar](100) NULL,
				[PayRec] [varchar](100) NULL,
				[PropVeri] [varchar](100) NULL,
				[BookCode] [varchar](500) NULL,
				[BookingEntity] [varchar](500) NULL,
				[Counterparty] [varchar](500) NULL,
				[SendMsg] [varchar](100) NULL,
				[SwiftField] [varchar](100) NULL,
				[Memo] [varchar](1000) NULL,
				[GTCollection] [varchar](100) NULL,
				[ReductionAmount] [varchar](100) NULL			
			)
		
		INSERT INTO #LLPMo
			(
				[ValueDate], [AccrualStart], [AccrualEnd], [Currency], [FeeAmount], [TaxType], [TaxRate], [FeeType], [PayRec], [PropVeri], [BookCode]
				, [BookingEntity], [Counterparty], [SendMsg], [SwiftField], [Memo], [GTCollection], [ReductionAmount]
		    )
		SELECT
			   CONVERT(VARCHAR(30),dir.IpdDate,103) AS [ValueDate],
			   CONVERT(VARCHAR(30),dir.IpdDate,103) AS [AccrualStart],
			   CONVERT(VARCHAR(30),dir.IpdDate,103) AS [AccrualEnd],
			   bv.Currency,
			   ABS(TRY_CAST(bv.[Value] AS DECIMAL(38, 2))) as FeeAmount,
			   'None' as TaxType,
			   '' AS TaxRate,
			   CASE WHEN bv.LineItem in ('NWB Deferred Consideration receipt','Collections Loan Reduction') THEN 'Finance Collections' ELSE bv.FeeType END
			   AS    FeeType,
			   IIF(TRY_CAST(CASE WHEN bv.[Value] = '-' THEN '0' ELSE bv.[Value] END AS DECIMAL(12,3)) > 0,'Receivable','Payable') AS PayRec,
			   'Verified' AS PropVeri,
			   bv.BookName AS BookCode,
			   CASE WHEN bv.BookName = 'NWLLP_DEPO' THEN 'NW COVERED BONDS LLP Deposit Account' when bv.BookName = 'NWLLP_TRANS' THEN 'NW COVERED BONDS LLP Trans account' 
			   when bv.BookName = 'GTNWDEIMOS' THEN 'NWBPLC GT DEIMOS COL' ELSE bv.[Value] END AS BookingEntity,
			   bv.CounterpartyName AS Counterparty,
			   CASE WHEN bv.[LineItemInternalName] = 'Transfer_of_Funds_to_Trans_NCBD_16' THEN 'Yes' ELSE 'No' END AS SendMsg,
			   'IPD Payment' AS SwiftField,
			   bv.LineItem AS Memo,
			   'No' AS GTCollection,
			   'No' AS ReductionAmount
		FROM 
			[cb].[vwBookingLineItems] bg
			LEFT JOIN [cb].[vwBookingLineItemValue] bv ON bg.BookingLineItemId =bv.BookingLineItemId
			LEFT JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = bv.DealipdRunid
		WHERE 
				bg.BookingGroupInternalName IN ('NWB_Covered_Bonds_Depo_Account_(600001 - 48803421 / NWBCOVBONDS.GBP)',
				'NWB_Covered_Bonds_Transaction_Account_(600001 - 48803413 / NWBCOVBONDS-GBP)',
				'NW_Collections_Account_(4607236 - LDNAWELO-GBP)') AND
				bg.DealName='Deimos' 
				AND bv.DealIpdRunId = @pIPDRunId AND dir.IsCurrentVersion = 1 AND bg.DealId= @pDealId
				AND bv.LineItemInternalName in ('Adjustment_of_Maturing_NWB_Trade_vs_Cash_NCBD_05',
					'Transfer_of_Funds_to_Trans_NCBD_16',
					'Transfer_of_Funds_from_GIC_NCBT_01',
					'Servicer_charges_NCBT_08',
					'Cash_Manager_charges_NCBT_09',
					'Payment_of_NWB_Deferred_Consideration_NCBT_18',
					'NWB_Deferred_Consideration_receipt_NCA_05',
					'Collections_Loan_Reduction_NCA_06',
					'Fee_payable_to_Liquidation_Member_NCBT_19',
					'Profit_payable_to_Members_NCBT_20',
					'Series_11_Coupon_Amount_NCBT_06',
					'GT_Interest_Top-up_NCBD_15',
					'Security_Trustee_charges_NCBT_07',
					'Account_Bank_charges_NCBT_10',
					'Asset_Monitor_charges_NCBT_11',
					'Credit_Coupon_PaymentLedger_NCBT_12',
					'Credit_Pre-Maturity_Liquidity Ledger_NCBT_13',
					'Credit_Revenue Ledger__NCBT_14',
					'Excluded_Swap_Termination_Amounts_NCBT_15',
					'Indemnity_amounts_due_to_Asset_NCBT_16',
					'Repay_RBS_Cash_Capital_Contributions_NCBT_17')
					ORDER BY 
					CASE 
					WHEN bv.LineItemInternalName = 'Adjustment_of_Maturing_NWB_Trade_vs_Cash_NCBD_05' THEN 1
					WHEN bv.LineItemInternalName = 'Transfer_of_Funds_to_Trans_NCBD_16' THEN 2
					WHEN bv.LineItemInternalName = 'Transfer_of_Funds_from_GIC_NCBT_01' THEN 3
					WHEN bv.LineItemInternalName = 'Servicer_charges_NCBT_08' THEN 4
					WHEN bv.LineItemInternalName = 'Cash_Manager_charges_NCBT_09' THEN 5
					WHEN bv.LineItemInternalName = 'Payment_of_NWB_Deferred_Consideration_NCBT_18' THEN 6
					WHEN bv.LineItemInternalName = 'NWB_Deferred_Consideration_receipt_NCA_05' THEN 7
					WHEN bv.LineItemInternalName = 'Collections_Loan_Reduction_NCA_06' THEN 8
					WHEN bv.LineItemInternalName = 'Fee_payable_to_Liquidation_Member_NCBT_19' THEN 9
					WHEN bv.LineItemInternalName = 'Profit_payable_to_Members_NCBT_20' THEN 10
					WHEN bv.LineItemInternalName = 'Series_11_Coupon_Amount_NCBT_06' THEN 11
					WHEN bv.LineItemInternalName = 'GT_Interest_Top-up_NCBD_15' THEN 12
					WHEN bv.LineItemInternalName = 'Security_Trustee_charges_NCBT_07' THEN 13
					WHEN bv.LineItemInternalName = 'Account_Bank_charges_NCBT_10' THEN 14
					WHEN bv.LineItemInternalName = 'Asset_Monitor_charges_NCBT_11' THEN 15
					WHEN bv.LineItemInternalName = 'Credit_Coupon_PaymentLedger_NCBT_12' THEN 16
					WHEN bv.LineItemInternalName = 'Credit_Pre-Maturity_Liquidity Ledger_NCBT_13' THEN 17
					WHEN bv.LineItemInternalName = 'Credit_Revenue Ledger__NCBT_14' THEN 18
					WHEN bv.LineItemInternalName = 'Excluded_Swap_Termination_Amounts_NCBT_15' THEN 19
					WHEN bv.LineItemInternalName = 'Indemnity_amounts_due_to_Asset_NCBT_16' THEN 20
					WHEN bv.LineItemInternalName = 'Repay_RBS_Cash_Capital_Contributions_NCBT_17' THEN 21
					END
    
	-- Find IPD Date
	SELECT	
		@ipdDate =CAST(IPD AS DATE)
	FROM 
		[cw].[vwDealIpdDates] ipdDt
	JOIN
		cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
	WHERE
		ipdRun.RunId = @pIPDRunId

	-- Set date value from existing
	Select @ValueDate = [ValueDate] from #LLPMo where Id = 1;

	-- Union all with Invoice data matched with deal ipd
	Select [ValueDate], [AccrualStart], [AccrualEnd], [Currency], [FeeAmount], [TaxType], [TaxRate], [FeeType], [PayRec], [PropVeri], [BookCode]
				, [BookingEntity], [Counterparty], [SendMsg], [SwiftField], [Memo], [GTCollection], [ReductionAmount] from #LLPMo
	Union ALL
	SELECT 
			@ValueDate as [ValueDate], @ValueDate as [AccrualStart], @ValueDate as [AccrualEnd], c.[Name] as [Currency]
			,invoice.Amount, 'None', '', 'Administration Fee' as FeeType, 
			IIF(invoice.Amount > 0,'Receivable','Payable') AS PayRec,'Verified', 
			'NWLLP_TRANS', 'NW COVERED BONDS LLP Trans account', 'SPV Fees Account - Non Trading Counterparties', 'No', 'IPD Payment', invoice.[Description] as [Memo], 'No', 'No'
	FROM
		[CW].[InvoiceData] invoice
	JOIN
		[cfgCW].[InvoiceCategory] IC ON IC.InvoiceCategoryId = invoice.InvoiceCategoryId
	JOIN
		[cfgCW].[InvoiceCategoryType] ICType ON IC.InvoiceCategoryTypeId = ICType.InvoiceCategoryTypeId
	JOIN 
		[cw].[vw_ActiveDeal] deal ON invoice.DealId = deal.DealId
	JOIN 
		[cw].[vw_ActiveDealCounterparty] dcp ON dcp.DealCounterpartyId = invoice.DealCounterpartyId
	JOIN  
		cfgcw.DealLookupValue dlv ON dlv.LookupValueId=invoice.InvoiceStatusId
	JOIN  
		cfgcw.DealLookupType dlt ON dlt.LookupTypeId=dlv.LookupTypeId
	LEFT JOIN  
			[cfgCW].[Currency] c ON c.CurrencyId =invoice.InvoiceCurrencyId
	WHERE
		(@pDealId = 0 OR invoice.DealId = @pDealId) AND (CAST(invoice.DealIpdDate AS DATE)=CAST(@ipdDate AS DATE))
			AND dlt.TypeCode = 'InvoiceStatus' 

END TRY    
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetBookingsLLPMoFeeData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END


GO


