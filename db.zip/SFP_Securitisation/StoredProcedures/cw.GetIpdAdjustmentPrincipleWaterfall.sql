USE SFP_Securitisation

GO

IF OBJECT_ID('cw.GetIpdAdjustmentPrincipleWaterfall') IS NOT NULL
DROP PROC  cw.GetIpdAdjustmentPrincipleWaterfall
GO

GO
/****** Object:  StoredProcedure [cw].[GetIpdAdjustmentPrincipleWaterfall]    Script Date: 14/03/2021 15:08:07 ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Arun
 * Date:	14.04.2021
 * Description:  IPD Adjustement Principle Waterfall for IPD run.
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * CW.GetIpdAdjustmentPrincipleWaterfall 30, 14, 'PreAvailablePrincipalReceipts' --'PrincipalPriorityofPayments'
 * -------------------------------------------------------
*/    
        
CREATE PROC CW.GetIpdAdjustmentPrincipleWaterfall
@pDealIpdRunId		INT,  
@pDealId INT = NULL,
@pWaterfallCategoryName varchar(255) = NULL
AS             
BEGIN
	DECLARE @postWaterfallCategoryName  VARCHAR(255),@dealName varchar(20);  

	SELECT TOP 1  @dealName=dir.dealName FROM cw.vwDealIpdRun dir WHERE dir.DealIpdRunId = @pDealIpdRunId

	SELECT @postWaterfallCategoryName = CASE WHEN @pWaterfallCategoryName= 'PreAvailablePrincipalReceipts' AND @dealName<>'DEIMOS'
		THEN 'PostAvailablePrincipalReceipts'  
         WHEN (@pWaterfallCategoryName = 'PreAvailableRevenueReceipts'  AND @dealName<>'DEIMOS') THEN 'PostAvailableRevenueReceipts'
		 WHEN @pWaterfallCategoryName = 'Adjustments_ARR' AND @dealName='DEIMOS' THEN 'PreAvailableRevenueReceipts'  
         WHEN @pWaterfallCategoryName = 'Adjustments_APR' AND @dealName='DEIMOS' THEN 'PreAvailablePrincipalReceipts'
		 WHEN @pWaterfallCategoryName = 'Adjustments_ARR' THEN 'PostAvailableRevenueReceipts' 
		 WHEN @pWaterfallCategoryName = 'Adjustments_APR' THEN 'PostAvailablePrincipalReceipts' 
		 WHEN @pWaterfallCategoryName = 'Adjustments_PrincipalWaterfall' THEN 'PrincipalPriorityofPayments' 
		 WHEN @pWaterfallCategoryName = 'Adjustments_RevenueWaterfall' THEN 'RevenuePriorityofPayments'
         ELSE @pWaterfallCategoryName END
         
	SELECT 
		CASE WHEN wliParent.ParentWaterfallLineItemId IS NOT NULL THEN wliParent.ParentWaterfallLineItemId ELSE ISNULL(wli.ParentWaterfallLineItemId, 0) END AS ParentWaterfallLineItemId,
		ISNULL(wla.WaterfallLineItemAmountId, 0) AS WaterfallLineItemAmountId, 
		wli.DisplayName AS LineItem,
		CAST(isNull(RequiredAmount,0) AS decimal(38,16)) AS RequiredAmount,  
		CAST(IsNull(AdjustedAmount,0) AS decimal(38,16)) AS  AdjustedAmount,   
		CAST(IsNull(TotalRequiredAmount,0) AS decimal(38,16))AS TotalRequiredAmount,
		CASE WHEN wliParent.ParentWaterfallLineItemId IS NOT NULL THEN 1 ELSE 0 END AS IsSubLineItems, 
		wli.IsEditable,
		wli.IsAdjustmentAllowed,
		wli.WaterfallLineItemOperatorInTotal,
        wla.ModifiedBy AS ModifiedBy,
        wla.ModifiedDate AS ModifiedDate
	FROM 
		cfgCW.WaterfallCategory wc
	INNER JOIN 
		cfgCW.WaterfallLineItem wli ON wc.WaterfallCategoryId = wli.WaterfallCategoryId  
	LEFT JOIN
		(SELECT DISTINCT ParentWaterfallLineItemId FROM cfgCW.WaterfallLineItem) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
	LEFT JOIN 
		cw.WaterfallLineItemAmount wla ON wla.WaterfallLineItemId = wli.WaterfallLineItemId AND DealIpdRunId=@pDealIpdRunId
	WHERE
		dealId=@pDealId
		AND wc.InternalName = @postWaterfallCategoryName
	ORDER BY 
		WLI.SortOrder
END

GO
