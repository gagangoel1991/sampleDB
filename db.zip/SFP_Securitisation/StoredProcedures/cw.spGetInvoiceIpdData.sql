USE SFP_Securitisation
GO
IF OBJECT_ID('[cw].[spGetInvoiceIpdData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetInvoiceIpdData]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spGetInvoiceIpdData]
/*
 * Author: Gunjan Chandola
 * Date:	07.04.2021
 * Description:  This will return the THE INVOICE DATA For 
 * 				Specific IPD
 * EXEC  [cw].[spGetInvoiceIpdData] 14,10,''
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/
@pDealId				INT = NULL,
@pIPDRunId		INT = NULL,
@pUserName		VARCHAR(80) 
AS
BEGIN

	SET NOCOUNT ON

	BEGIN TRY
		DECLARE @ipdDate DATE

		SELECT	
			@ipdDate =CAST(IPD AS DATE)
		FROM 
			[cw].[vwDealIpdDates] ipdDt
		JOIN
			cw.DealIpdRun ipdRun ON ipdDt.DealIpdId = ipdRun.DealIpdId
		WHERE
			ipdRun.RunId = @pIPDRunId
		
		SELECT 
			invoice.Name AS [Name],
			invoice.InvoiceId,
			deal.DealId,
			deal.DealName AS DealName,
			ICType.InvoiceCategoryTypeId,
			ICType.Name AS InvoiceCategoryType,
			IC.InvoiceCategoryId,
			IC.Name AS InvoiceCategory,
			dcp.CounterpartyName,
			dcp.DealCounterpartyId,
			invoice.Description,
			invoice.Amount,
			invoice.PaidDate,
			invoice.DealIpdDate,
			invoice.UploadedFileName,
			invoice.OriginalFileName,
			dlv.DisplayText AS Status,
			invoice.ReferenceNumber AS ReferenceNumber,
			invoice.CreatedBy AS CreatedBy,
			invoice.CreatedDate AS CreatedDate,
			invoice.ModifiedBy AS ModifiedBy,
			invoice.ModifiedDate AS ModifiedDate
		FROM
			[CW].[InvoiceData] invoice
		JOIN
			[cfgCW].[InvoiceCategory] IC ON IC.InvoiceCategoryId = invoice.InvoiceCategoryId
		JOIN
			[cfgCW].[InvoiceCategoryType] ICType ON IC.InvoiceCategoryTypeId = ICType.InvoiceCategoryTypeId
		JOIN 
			[cw].[vw_ActiveDeal] deal ON invoice.DealId = deal.DealId
		JOIN 
			[cw].[vw_ActiveDealCounterparty] dcp ON dcp.DealCounterpartyId = invoice.DealCounterpartyId
		JOIN  
			cfgcw.DealLookupValue dlv ON dlv.LookupValueId=invoice.InvoiceStatusId
		JOIN  
			cfgcw.DealLookupType dlt ON dlt.LookupTypeId=dlv.LookupTypeId
		WHERE
			(@pDealId = 0 OR invoice.DealId = @pDealId) AND (CAST(invoice.DealIpdDate AS DATE)=CAST(@ipdDate AS DATE))
			 AND dlt.TypeCode = 'InvoiceStatus' 
		ORDER BY
			invoice.ModifiedDate DESC
			
	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetInvoiceIpdData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, @pUserName
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH
END
GO
