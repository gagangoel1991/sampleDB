USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.spIR_GetAPRSummary') IS NOT NULL
	DROP PROCEDURE cw.spIR_GetAPRSummary
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spIR_GetAPRSummary 
(
@pAsAtDate datetime, 
@pDealName  varchar(200),
@pUserName	VARCHAR(80) = NULL

)
/* 
 *   Author: Aditya Shrivastava 
 *   Date:  26.05.2020 
 *   Description:  Get Available principal receipts summary for IR liability Strats
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */ 
AS 
  BEGIN 
	 BEGIN TRY 
 --	Declare @pDealName varchar(200)='ARDMORE1'	  ,@pAsAtDate datetime='2018-07-31';

     DECLARE @dealIpdRunId                  INT,
        @waterfallCategoryInternamName VARCHAR(200)='PostAvailablePrincipalReceipts',
        @dealId                        SMALLINT,
        @ipdDate                       DATETIME,
        @previousIPDDateName            VARCHAR(200)='PreviousIPD',
        @ipdSequence                   INT,
		@PreviousRunNum					SMALLINT,
		@previousIpdDate      DATE,  
		@dealPreviousIpdRunId INT  

      IF( Object_id('tempdb..#temp') IS NOT NULL ) 
        DROP TABLE #temp 

      IF( Object_id('tempdb..#tempPrevious') IS NOT NULL ) 
        DROP TABLE #tempPrevious 

	   SELECT   
	  @dealIpdRunId = dir.DealIpdRunId  
	  , @dealId = dir.DealId  
	  , @ipdDate = di.IpdDate  
	  , @previousIpdDate  = ipdDt.PreviousIPD  
	 FROM     
	  cw.vwDealIpdDates ipdDt  
	 JOIN cw.DealIpd di ON di.DealIpdId = ipdDt.DealIpdId  
	 JOIN cw.vwDealIpdRun dir ON dir.DealIpdId = ipdDt.DealIpdId   
	 JOIN cw.vw_ActiveDeal deal ON deal.DealId = di.DealId  
	 WHERE   
	  deal.DealName = @pDealName  
	  AND CAST(ipdDt.CollectionBusinessEnd AS DATE)= @pAsAtDate   
	  AND dir.IpdSequence <> 0   
        
	 SELECT @dealPreviousIpdRunId = RunId FROM cw.DealIpdRun dir  
	 JOIN cw.DealIpd di ON di.DealIpdId = dir.DealIpdId  
	 WHERE di.IpdDate = @previousIpdDate AND dir.IsCurrentVersion = 1  

    
	 SET @waterfallCategoryInternamName = CASE WHEN @pDealName ='Deimos' THEN 'PreAvailablePrincipalReceipts' ELSE @waterfallCategoryInternamName END
	
	

      SELECT wli.WaterfallLineItemId, 
             wli.DisplayName, 
             IIF(wliParent.ParentWaterfallLineItemId IS NULL
				, CASE WHEN wli.WaterfallLineItemOperatorInTotal='LESS' THEN wlia.WaterfallLineItemTotalRequiredAmount*-1 ELSE  wlia.WaterfallLineItemTotalRequiredAmount END
				, wliParent.TotalRequiredAmount) AS CurrentPeriodAmount, 
             CONVERT(DECIMAL(38, 16), NULL) AS PreviousPeriodAmount, 
			 wli.SortOrder
	  INTO   #temp 
      FROM   cw.vwWaterfallLineItemAmount wlia
             JOIN cfgcw.WaterfallLineItem wli ON wlia.WaterfallLineItemId = wli.WaterfallLineItemId 
             JOIN cfgcw.WaterfallCategory wc ON wli.WaterfallCategoryId = wc.WaterfallCategoryId 
             JOIN cw.vwDealIpdRun dir ON wc.DealId = dir.DealId AND wlia.DealIpdRunId = dir.DealIpdRunId
			 LEFT JOIN
				(
					SELECT wliParent1.ParentWaterfallLineItemId, SUM(lineItemSum.WaterfallLineItemTotalRequiredAmount) AS TotalRequiredAmount
					FROM 
						cfgCW.WaterfallLineItem wliParent1
					JOIN 
						cw.vwWaterfallLineItemAmount lineItemSum ON lineItemSum.WaterfallLineItemId = wliParent1.WaterfallLineItemId
					WHERE
						lineItemSum.DealIpdRunId = @DealIpdRunId 
					GROUP BY 
						ParentWaterfallLineItemId 
				) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
      WHERE 
             wc.InternalName = @waterfallCategoryInternamName 
             AND dir.DealIpdRunId = @dealIpdRunId 
			 AND wli.ParentWaterfallLineItemId IS NULL

      SELECT wli.WaterfallLineItemId, 
             IIF(wliParent.ParentWaterfallLineItemId IS NULL
				, CASE WHEN wli.WaterfallLineItemOperatorInTotal='LESS' THEN wlia.WaterfallLineItemTotalRequiredAmount*-1 ELSE  wlia.WaterfallLineItemTotalRequiredAmount END
				, wliParent.TotalRequiredAmount) AS PreviousPeriodAmount 
      INTO   #tempPrevious 
      FROM   cw.vwWaterfallLineItemAmount wlia
             JOIN cfgcw.WaterfallLineItem wli ON wlia.WaterfallLineItemId = wli.WaterfallLineItemId 
             JOIN cfgcw.WaterfallCategory wc ON wli.WaterfallCategoryId = wc.WaterfallCategoryId 
             JOIN cw.vwDealIpdRun dir ON wc.DealId = dir.DealId AND wlia.DealIpdRunId = dir.DealIpdRunId
			 LEFT JOIN
				(
					SELECT wliParent1.ParentWaterfallLineItemId, SUM(lineItemSum.WaterfallLineItemTotalRequiredAmount) AS TotalRequiredAmount
					FROM 
						cfgCW.WaterfallLineItem wliParent1
					JOIN 
						cw.vwWaterfallLineItemAmount lineItemSum ON lineItemSum.WaterfallLineItemId = wliParent1.WaterfallLineItemId
					WHERE
						lineItemSum.DealIpdRunId = @dealPreviousIpdRunId 
					GROUP BY 
						ParentWaterfallLineItemId 
				) AS wliParent ON  wliParent.ParentWaterfallLineItemId = wli.WaterfallLineItemId
      WHERE  
			wc.InternalName = @waterfallCategoryInternamName 
             AND dir.DealIpdRunId = @dealPreviousIpdRunId 
			 AND wli.ParentWaterfallLineItemId IS NULL

      UPDATE t 
      SET    PreviousPeriodAmount = tPrevious.PreviousPeriodAmount 
      FROM   #temp t, 
             #tempPrevious tPrevious 
      WHERE  t.WaterfallLineItemId = tPrevious.WaterfallLineItemId 

      SELECT DisplayName, 
             CONVERT(DECIMAL(38, 16), CurrentPeriodAmount)               CurrentPeriodAmount,
             CONVERT(DECIMAL(38, 16), COALESCE(PreviousPeriodAmount, 0)) PreviousPeriodAmount
      FROM   #temp 
	  ORDER BY SortOrder
  END TRY 

     BEGIN CATCH  
		DECLARE   
			@errorMessage     NVARCHAR(MAX),  
			@errorSeverity    INT,  
			@errorNumber      INT,  
			@errorLine        INT,  
			@errorState       INT;  
  
		SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spIR_GetAPRSummary', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
		RAISERROR (@errorMessage,  
					@errorSeverity,  
				 @errorState )  
	END CATCH   
  END
GO