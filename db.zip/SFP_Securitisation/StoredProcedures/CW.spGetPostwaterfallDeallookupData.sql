USE [SFP_Securitisation]
GO
IF OBJECT_ID('CW.spGetPostwaterfallDeallookupData') IS NOT NULL
DROP PROC CW.spGetPostwaterfallDeallookupData
GO
/*
 * Author: Ravindra
 * Date:    24.11.2021
 * Description:  This will return postwaterfall output sheet summary Data.
 * 
 * Change History
 * --------------
 * Author              Date                 Description
 * -- EXEC CW.spGetPostwaterfallDeallookupData
 * -------------------------------------------------------
*/
CREATE PROC CW.spGetPostwaterfallDeallookupData   
		
AS
BEGIN
	BEGIN TRY
		SELECT dv.name AS AttributeName,dt.name AS AttributeType,--string_split(value,',') as colindex,

		Replace(LEFT(value,CHARINDEX(',',value)-1),'col','') AS StartColindex,
		Replace(Replace(RIGHT(value,CHARINDEX(',',value)),'row',''),',','') AS StartRowindex,
		''AS EndColindex,
		'' AS EndRowindex,
		'' AS Value FROM cfgcw.DealLookupValue dv
		INNER JOIN cfgcw.DealLookupType dt
		ON dt.LookupTypeId =dv.LookupTypeId AND 
		 TypeCode = 'WaterfallReconciliation'
		 UNION

		 SELECT DISTINCT 'PW Start Column Index' AS AttributeName,
		 'Asset Strats Reconciliation Attribute' AS AttributeType,--string_split(value,',') as colindex,

		'' AS StartColindex,
		dv.Value AS StartRowindex,
		'' AS EndColindex,
		dv1.Value AS EndRowindex,
		'' AS Value FROM cfgcw.DealLookupValue dv
		INNER JOIN cfgcw.DealLookupType dt		
		ON dt.LookupTypeId =dv.LookupTypeId AND 
		 TypeCode = 'AssetStratsReconciliation' AND dv.Name IN ('PW Start Row Index','PW End Row Index')
		 INNER JOIN cfgcw.DealLookupValue dv1 ON dv1.Value <> dv.Value
		 WHERE dv1.Name IN ('PW Start Row Index','PW End Row Index')  AND dv.Name ='PW Start Row Index'
	
		
	END TRY
	BEGIN CATCH
		DECLARE 
					@errorMessage     NVARCHAR(MAX),
					@errorSeverity    INT,
					@errorNumber      INT,
					@errorLine        INT,
					@errorState       INT;

		SELECT 
					@errorMessage = ERROR_MESSAGE()
					,@errorSeverity = ERROR_SEVERITY()
					,@errorNumber = ERROR_NUMBER()
					,@errorLine = ERROR_LINE()
					,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetPostwaterfallDeallookupData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, ''
    
		RAISERROR (@errorMessage,
					@errorSeverity,
					@errorState )
	END CATCH
END

GO