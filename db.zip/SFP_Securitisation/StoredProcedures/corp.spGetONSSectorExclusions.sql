USE [SFP_Securitisation]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetONSSectorExclusions]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetONSSectorExclusions]
GO


CREATE PROCEDURE [corp].[spGetONSSectorExclusions]             
AS 
     
BEGIN      
	BEGIN TRY  
		
	SELECT INDSSC01,INDSSC02,INDSSC03,BOECodeFix,Description,SICCode,BOEINDClassPre2010,BOEINDClassPost2011,SICCodeFix,Cluster,SectorMstr,SectorSub,
		   Excluded, CAST(RelatesToDate AS VARCHAR) AS RelatesToDate, LoadDate, SourceFile 
	FROM  [corp].[syn_Staging_tbl_ONS_SectorExclusions]

    END TRY                    
	BEGIN CATCH                    
		DECLARE                     
		@errorMessage     NVARCHAR(MAX),                    
		@errorSeverity    INT,                    
		@errorNumber      INT,                    
		@errorLine        INT,                    
		@errorState       INT;   
		
		SELECT                     
		@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()                    
                    
		EXEC app.SaveErrorLog 2, 1, 'spGetONSSectorExclusions', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''
                      
		RAISERROR 
		(
			@errorMessage,                    
			@errorSeverity,                    
			@errorState 
		)
	END CATCH      
END
GO