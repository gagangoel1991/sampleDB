USE SFP_Securitisation
GO

IF OBJECT_ID('cb.spGetRatingMasterData') IS NOT NULL
	DROP PROCEDURE cb.spGetRatingMasterData
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--========================================
--Author: Suresh Pandey
--Date:	25-01-2022
--Description:  To Get Rating Master Data
--for the user rating upload functionality
--Exec cw.spGetRatingMasterData 15
--Note: This sp is also Getting called from 
--multiple locations
--========================================
CREATE PROCEDURE cb.spGetRatingMasterData (@DealId INT)
AS
BEGIN
	
		DECLARE @NoteDealSubjectTypeId INT = (
				SELECT DealSubjectTypeId
				FROM cfgcw.DealSubjectType
				WHERE [name] = 'Note'
				)
		DECLARE @CounterpartyDealSubjectTypeId INT = (
				SELECT DealSubjectTypeId
				FROM cfgcw.DealSubjectType
				WHERE [name] = 'Counterparty'
				)
		DECLARE @BondRatingTypeId INT = (
				SELECT RatingTypeId
				FROM cfgcw.RatingType
				WHERE [Name] = 'Bond Rating'
				)

		IF object_id('tempdb..#TempRatingData') IS NOT NULL
			DROP TABLE #TempRatingData

		SELECT DISTINCT a.CRAId
			,a.[Name] AS [CRA]
			,r.RatingTypeId
			,t.[Name] AS [RatingType]
			,Rating
		INTO #TempRatingData
		FROM cfgcw.CRARating r
		JOIN cfgcw.CreditRatingAgency a ON r.CRAId = a.CRAId
		JOIN cfgcw.RatingType t ON t.RatingTypeId = r.RatingTypeId
		WHERE a.IsActive = 1
			AND t.IsActive = 1
			AND r.IsActive = 1

		SELECT X.ISIN AS 'UniqueIdentifier'
			,t.CRAId
			,t.CRA
			,t.RatingTypeId
			,t.[RatingType]
			,t.Rating
			,'Bond' AS [Type]
		FROM #TempRatingData t
		JOIN (
			SELECT m.CRAId
				,dn.ISIN
			FROM cfgcb.DealNote dn
			CROSS JOIN cfgcw.DealSubjectCRAMap m
			WHERE m.DealId = @DealId
				AND m.DealSubjectTypeId = @NoteDealSubjectTypeId
				AND m.IsActive = 1
				AND dn.IsNote = 1
				AND dn.DealId = @DealId
				AND dn.IsActive = 1
			) X ON X.CRAId = t.CRAId
			AND t.RatingTypeId = @BondRatingTypeId
		
		UNION ALL
		
		SELECT X.CisCode AS 'UniqueIdentifier'
			,t.CRAId
			,t.CRA
			,t.RatingTypeId
			,t.[RatingType]
			,t.Rating
			,'Counterparty' AS [Type]
		FROM #TempRatingData t
		JOIN (
			SELECT m.CRAId
				,dn.CisCode
			FROM [CW].[vw_ActiveDealCounterparty] dn
			CROSS JOIN cfgcw.DealSubjectCRAMap m
			WHERE m.DealId = @DealId
				AND m.DealSubjectTypeId = @CounterpartyDealSubjectTypeId
				AND m.IsActive = 1
				AND dn.DealId = @DealId
			) X ON X.CRAId = t.CRAId
			AND t.RatingTypeId <> @BondRatingTypeId
	
END
GO


