USE [SFP_Securitisation]
GO

IF OBJECT_ID('[ps].[spGetEntityAuditDetails]') IS NOT NULL
	DROP PROCEDURE [ps].[spGetEntityAuditDetails] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--=================================================        
--Author: Sakthivel Loganathan        
--Date: 04-02-2022       
--Description: to read audit columns of tables for auth workflow           
--=================================================         
CREATE PROCEDURE [ps].[spGetEntityAuditDetails]       
   @pWorkflowType   VARCHAR(100),          
   @pPsId   INT,       
   @pUserName  VARCHAR(80)
AS        
BEGIN        
 BEGIN TRY         
		  DECLARE 
		   @ctWorkflow VARCHAR(50) = 'Concentration_Test',  
		   @ecWorkflow VARCHAR(50) = 'Eligibility_Criteria',  
		   @ecfWorkflow VARCHAR(50) = 'Custom_Field' , 
		   @poolfWorkflow VARCHAR(50) = 'Pool'   ,
		   @ddcWorkflow VARCHAR(50) = 'DealDataCorrection' 
         
		  BEGIN TRAN ManageWorkflow   
			   IF @pWorkflowType=@ctWorkflow      
			   BEGIN  
					SELECT  CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,AuthorizedBy,AuthorizedDate 
					FROM [ps].[ConcentrationTest] WHERE ConcentrationTestId=@pPsId
			   END 
			  ELSE IF @pWorkflowType=@ecWorkflow  
			  BEGIN  
					SELECT  CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,AuthorizedBy,AuthorizedDate
					FROM [ps].[EligibilityCriteria] WHERE EligibilityCriteriaId=@pPsId
			  END  
			  ELSE IF @pWorkflowType=@ecfWorkflow  
			  BEGIN    
					SELECT  CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,AuthorizedBy,AuthorizedDate 
					FROM [ps].[EligibilityCriteriaField] WHERE EligibilityCriteriaFieldId=@pPsId AND isActive = 1 
			  END
			  ELSE IF @pWorkflowType= @poolfWorkflow
			  BEGIN
					SELECT  CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,AuthorizedBy,AuthorizedDate 
					FROM [ps].[Pool] WHERE PoolId=@pPsId AND isActive = 1 
			  END
			  ELSE IF @pWorkflowType= @ddcWorkflow  
			  BEGIN  
				     	SELECT  CreatedBy,CreatedDate,ModifiedBy,ModifiedDate,AuthorizedBy,AuthorizedDate   
				     	FROM [corp].[DealDataCorrection] WHERE DealDataCorrectionId=@pPsId AND isActive = 1   
			  END 
		  COMMIT TRAN  
 END TRY        
 BEGIN CATCH        
  IF @@trancount > 0 ROLLBACK TRANSACTION ManageWorkflow;     
  DECLARE         
   @errorMessage     NVARCHAR(MAX),        
   @errorSeverity    INT,        
   @errorNumber      INT,        
   @errorLine        INT,        
   @errorState       INT;        
        
  SELECT         
  @errorMessage = ERROR_MESSAGE()
  ,@errorSeverity = ERROR_SEVERITY()
  ,@errorNumber = ERROR_NUMBER()
  ,@errorLine = ERROR_LINE()
  ,@errorState = ERROR_STATE()        
        
  EXEC app.SaveErrorLog 1, 1, 'ps.spGetEntityAuditDetails', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName        
          
  RAISERROR (@errorMessage,        
   @errorSeverity,        
   @errorState )        
 END CATCH        
END