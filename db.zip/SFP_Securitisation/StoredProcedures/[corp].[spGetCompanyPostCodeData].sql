USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetCompanyPostCodeData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetCompanyPostCodeData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-------------------------------------------------------  
Author: Saurav
Date: 04.07.2022  
Description:  This will return data from the staging table COMPANY_POSTCODE_DATA for displaying the data on UI
			  [corp].[spGetCompanyPostCodeData]
Change History  
--------------  
Author			Date		Description  
-------------------------------------------------------  
Saurav Kumar	04-07-2022	Initial SP creation
*/  
CREATE PROCEDURE [corp].[spGetCompanyPostCodeData]  
AS  
BEGIN 
			
	BEGIN TRY  

		SELECT Top 1000 
			COMPANY_NUMBER, 
			POST_CODE, 
			AS_AT_DATE
		FROM [corp].[syn_SfpStaging_tbl_COMPANY_POSTCODE_DATA]
		ORDER BY 1, 2

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetCompanyPostCodeData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, ''
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH

END
GO