USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[spLoadDealProductnSwitchData]') IS NOT NULL
	DROP PROCEDURE [cw].[spLoadDealProductnSwitchData]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cw].[spLoadDealProductnSwitchData]
/*
 * Author: Kapil Sharma
 * Date:	19.03.2021
 * Description:  This will load the deal product data on a monthly basis
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * 
 * Usages:
 * [cw].[spLoadDealProductnSwitchData] 1, '2021-02-01'
 * -------------------------------------------------------
*/
(  
	@pFeedRunLogId		INT,  
	@pAsAtDate			DATETIME  
)  
AS  
BEGIN   

	BEGIN TRY 
		DECLARE   
			@createdDate      DATETIME = GETDATE(),  
			@createdBy       VARCHAR(100) = 'System',  
			@dealName       VARCHAR(100),  
			@mortgageDealId      INT,  
			@dealId        INT,  
			@fromCollectionDatePrevMonth  DATETIME,  
			@prevQuarterDate     DATETIME,  
			@prevQuarterVintageDate    DATETIME,  
			@prevQuarterPartitionId    INT,  
			@toCollectionDate     DATETIME,  
			@partitionId      INT,  
			@vintageDate      DATE,  
			@prevMonthVintageDate    DATE,  
			@prevMonthPartitionId    INT,  
			@aggregatedFieldId     SMALLINT,  
			@dailyColFieldName     VARCHAR(100),  
			@monthToBeProcessed     DATETIME,  
			@dealRegionCode      VARCHAR(10),  
			@productTypeId      SMALLINT,  
			@productName      VARCHAR(100),  
			@highInterestRateTypeId    SMALLINT,  
			@lowInterestRateTypeId    SMALLINT  
  
   
   
		--As batch will be run on first day of each month for prev month  
		SET @monthToBeProcessed = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-2))   
		SET @fromCollectionDatePrevMonth = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-3))   
		SET @prevQuarterDate = DATEADD(DD,1 ,EOMONTH(@pAsAtDate,-5))  
		SET @toCollectionDate = EOMONTH(@pAsAtDate, -1)   
		SET @highInterestRateTypeId = 1  
		SET @lowInterestRateTypeId = 2  
  
		--check temp table if exists  
		IF OBJECT_ID('tempdb..#tmpMortgageLoanResult') IS NOT NULL DROP TABLE #tmpMortgageLoanResult  
		IF OBJECT_ID('tempdb..#tmpMortgageLoanPrevMonthResult') IS NOT NULL DROP TABLE #tmpMortgageLoanPrevMonthResult  
		IF OBJECT_ID('tempdb..#tmpMortgageLoanPrevQuarterMonthResult') IS NOT NULL DROP TABLE #tmpMortgageLoanPrevQuarterMonthResult  
		IF OBJECT_ID('tempdb..#tmpDealProductData') IS NOT NULL DROP TABLE #tmpDealProductData  
		IF OBJECT_ID('tempdb..#tmpDealProductSwitch') IS NOT NULL DROP TABLE #tmpDealProductSwitch  
		IF OBJECT_ID('tempdb..#tmpDealProductQuarterlySwitch') IS NOT NULL DROP TABLE #tmpDealProductQuarterlySwitch  
     
		CREATE TABLE #tmpDealProductData(CorrelatedDate Datetime, DealId INT, ProductTypeId SMALLINT, LoanCount INT,  TrueBalanceValue DECIMAL(38, 16), CapitalBalanceValue DECIMAL(38, 16))  
		CREATE TABLE #tmpDealProductSwitch(CorrelatedDate Datetime, DealId INT, ProductSwitchTypeId SMALLINT,LoanCount INT,  TrueBalanceValue DECIMAL(38, 16), CapitalBalanceValue DECIMAL(38, 16),  
		QuarterlyLoanCount INT,  QuarterlyTrueBalanceValue DECIMAL(38, 16), QuarterlyCapitalBalanceValue DECIMAL(38, 16))  
		CREATE TABLE #tmpDealProductQuarterlySwitch(CorrelatedDate Datetime, DealId INT, ProductSwitchTypeId SMALLINT,LoanCount INT,  TrueBalanceValue DECIMAL(38, 16), CapitalBalanceValue DECIMAL(38, 16))  
  
		SELECT * INTO #tmpMortgageLoanResult FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
		SELECT * INTO #tmpMortgageLoanPrevMonthResult FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
		SELECT * INTO #tmpMortgageLoanPrevQuarterMonthResult FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
  
		PRINT 'Creating the cursor'  
		DECLARE cursorCWDeal CURSOR FOR       
		SELECT DISTINCT MortgageDealId, DealId, DealRegionCode, DealName FROM [cw].[vw_ActiveDeal] WHERE DealStatusDisplayName = 'Active' --where DealId IN(14, 15)  
    
		OPEN cursorCWDeal      
    
		FETCH NEXT FROM cursorCWDeal INTO @mortgageDealId, @dealId, @dealRegionCode, @dealName  
		WHILE @@FETCH_STATUS = 0      
		BEGIN   
			TRUNCATE TABLE #tmpMortgageLoanResult;  
			TRUNCATE TABLE #tmpMortgageLoanPrevMonthResult;  
			TRUNCATE TABLE #tmpMortgageLoanPrevQuarterMonthResult;  
     
			--Get the partition id, and last working date of the month  
			SELECT   
				TOP 1 @partitionId = CONVERT(INT, CONVERT(VARCHAR(8), AsAtDate, 112)) ,  
				@vintageDate =  AsAtDate,  
				@toCollectionDate = AsAtDate  
			FROM   
				sfp.syn_SfpModel_vw_Calendar_v1 
			WHERE   
				Month = Month(@monthToBeProcessed)  AND year = Year(@monthToBeProcessed)    
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode  
			ORDER BY   
				AsAtDate DESC    
  
			-----(Previous-1) month last business date i.e. if we are fetching data for May 2020 then we need the last business day of Apr2020  
			SELECT   
				TOP 1 @prevMonthPartitionId = CONVERT(INT, CONVERT(VARCHAR(8), AsAtDate, 112)),  
				@prevMonthVintageDate =  AsAtDate  
			FROM   
				sfp.syn_SfpModel_vw_Calendar_v1 
			WHERE   
				Month = Month(@fromCollectionDatePrevMonth) AND year = Year(@fromCollectionDatePrevMonth)    
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode  
			ORDER BY   
				AsAtDate DESC  
  
			-----(Previous-3) month last business date i.e. if we are fetching data for May 2020 then we need the last business day of Apr2020  
			SELECT   
				TOP 1 @prevQuarterPartitionId = CONVERT(INT, CONVERT(VARCHAR(8), AsAtDate, 112)),  
				@prevQuarterVintageDate =  AsAtDate  
			FROM   
				sfp.syn_SfpModel_vw_Calendar_v1 
			WHERE   
				Month = Month(@prevQuarterDate) AND year = Year(@prevQuarterDate)    
				AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode  
			ORDER BY   
				AsAtDate DESC  
  
			EXEC [CW].[spCheckAndLoadMortgageFieldData] @vintageDate, @mortgageDealId  
			INSERT INTO #tmpMortgageLoanResult     
			SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionId AND MortgageDealKey = @mortgageDealId 
  
			PRINT 'Execution completed -  Mortgage Commmon SP'  
  
			INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
			SELECT   
				@vintageDate,  
				@dealId,   
				pt.ProductTypeId,   
				COUNT(*) AS LoanCount,  
				SUM(ISNULL(tmp.TRUE_BALANCE_AMT, 0)),   
				SUM(ISNULL(tmp.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0))   
			FROM   
				#tmpMortgageLoanResult tmp  
			JOIN   
				[cfgCW].[ProductType] pt ON tmp.Product = pt.Name  
			WHERE  
				pt.Name NOT IN ('WAInterestRate', 'WASVR')--These two fields are the calculated fields   
			GROUP BY   
				tmp.Product, pt.ProductTypeId  
  
			--Calculate the WAInterestRate type  
			IF EXISTS(SELECT TOP 1 * FROM [cfgCW].[ProductType] WHERE Name = 'WAInterestRate')  
			BEGIN  
				INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT  
					@vintageDate, @dealId,   
					(SELECT TOP 1 ProductTypeId FROM [cfgCW].[ProductType] WHERE Name = 'WAInterestRate'),  
					COUNT(*) AS LoanCount,  
					SUM((CURRENT_INTEREST_RATE/100)*TRUE_BALANCE_AMT)/SUM(TRUE_BALANCE_AMT)*100,  
					SUM((CURRENT_INTEREST_RATE/100)*OUTSTANDNG_CAPITAL_BALANCE_AMT)/SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT)*100  
				FROM  
					#tmpMortgageLoanResult  
			END  
  
			--Calculate the WAInterestRate type  
			IF EXISTS(SELECT TOP 1 * FROM [cfgCW].[ProductType] WHERE Name = 'WASVROnCurrInterestRate')  
			BEGIN  
				INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT  
					@vintageDate, @dealId,   
					(SELECT TOP 1 ProductTypeId FROM [cfgCW].[ProductType] WHERE Name = 'WASVROnCurrInterestRate'),  
					COUNT(*) AS LoanCount,  
					SUM((CURRENT_INTEREST_RATE/100)*TRUE_BALANCE_AMT)/SUM(TRUE_BALANCE_AMT)*100,  
					SUM((CURRENT_INTEREST_RATE/100)*OUTSTANDNG_CAPITAL_BALANCE_AMT)/SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT)*100  
				FROM  
					#tmpMortgageLoanResult  
				WHERE  
					Product = 'SVR'  
			END  
  
			--Calculate the WAInterestRate type  
			IF EXISTS(SELECT TOP 1 * FROM [cfgCW].[ProductType] WHERE Name = 'WASVROnBaseInterestRate')  
			BEGIN  
				INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT  
					@vintageDate, @dealId,   
					(SELECT TOP 1 ProductTypeId FROM [cfgCW].[ProductType] WHERE Name = 'WASVROnBaseInterestRate'),  
					COUNT(*) AS LoanCount,  
					SUM((BASE_INTEREST_RATE/100)*TRUE_BALANCE_AMT)/SUM(TRUE_BALANCE_AMT)*100,  
					SUM((BASE_INTEREST_RATE/100)*OUTSTANDNG_CAPITAL_BALANCE_AMT)/SUM(OUTSTANDNG_CAPITAL_BALANCE_AMT)*100  
				FROM  
					#tmpMortgageLoanResult  
				WHERE  
					Product = 'SVR'  
			END  
     
			--Insert Missing Product Type  
			INSERT INTO #tmpDealProductData(CorrelatedDate, DealId, ProductTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
			SELECT   
				@vintageDate, @dealId, pt.ProductTypeId, 0, 0, 0  
			FROM  
				[cfgCW].[ProductType] pt   
			LEFT JOIN  
				(SELECT DISTINCT Product FROM #tmpMortgageLoanResult) AS tmp ON tmp.Product = pt.Name  
			WHERE  
				pt.Name NOT IN ('WAInterestRate', 'WASVROnBaseInterestRate', 'WASVROnCurrInterestRate')--These two fields are the calculated fields   
				AND tmp.Product IS NULL  
     
			-------------------Now capture the Product Switch cases--------------------------------  
			--Populating prev month mortgage data  
  
			EXEC [CW].[spCheckAndLoadMortgageFieldData] @prevMonthVintageDate, @mortgageDealId  
			INSERT INTO #tmpMortgageLoanPrevMonthResult     
			SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @prevMonthPartitionId AND MortgageDealKey = @mortgageDealId    
  
			--Populating prev quarter mortgage data  
			EXEC [CW].[spCheckAndLoadMortgageFieldData] @prevQuarterVintageDate, @mortgageDealId  
			INSERT INTO #tmpMortgageLoanPrevQuarterMonthResult     
			SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @prevQuarterPartitionId AND MortgageDealKey = @mortgageDealId   
  
			--*******************Checking Product switch for prev month***********************************  
			IF @dealName <>'Deimos' --Don't need the product switch details for Deimos deal so excluding this deal from calculation
			BEGIN
				INSERT INTO #tmpDealProductSwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId AS DealId,  
					pst.ProductSwitchTypeId AS ProductSwitchTypeId,  
					COUNT(*) AS LoanCount,  
					SUM(ISNULL(curr.TRUE_BALANCE_AMT, 0)) AS TrueBalanceValue,   
					SUM(ISNULL(curr.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue  
				FROM   
					#tmpMortgageLoanPrevMonthResult prev  
				JOIN   
					[cfgCW].[ProductType] pt1 ON pt1.Name = prev.Product  
				JOIN  
					#tmpMortgageLoanResult curr ON prev.LOAN_IDENTIFIER = curr.LOAN_IDENTIFIER AND prev.SUB_ACCOUNT_ID = curr.SUB_ACCOUNT_ID  
				JOIN   
					[cfgCW].[ProductType] pt2 ON pt2.Name = curr.Product  
				JOIN  
					[cfgCW].[ProductSwitchType] pst ON pst.ProductTypeId1 = pt1.ProductTypeId   
					AND pst.ProductTypeId2 = pt2.ProductTypeId   
				WHERE  
					pst.ProductRateOfInterestTypeId1 IS NULL   
					AND pst.ProductRateOfInterestTypeId1 IS NULL  
					AND curr.LIVE_ACCOUNT ='Y'
					AND ISNULL(pst.IsInterestControlCodeCondition, 0) = 0  
				GROUP BY   
					pst.ProductSwitchTypeId  
  
				--Now check the interest switch   
				INSERT INTO #tmpDealProductSwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId AS DealId,  
					pst.ProductSwitchTypeId AS ProductSwitchTypeId,  
					COUNT(*) AS LoanCount,  
					SUM(ISNULL(curr.TRUE_BALANCE_AMT, 0)) AS TrueBalanceValue,   
					SUM(ISNULL(curr.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue  
				FROM   
					#tmpMortgageLoanPrevMonthResult prev  
				JOIN   
					[cfgCW].[ProductType] pt1 ON pt1.Name = prev.Product  
				JOIN  
					#tmpMortgageLoanResult curr ON prev.LOAN_IDENTIFIER = curr.LOAN_IDENTIFIER AND prev.SUB_ACCOUNT_ID = curr.SUB_ACCOUNT_ID  
				JOIN   
					[cfgCW].[ProductType] pt2 ON pt2.Name = curr.Product  
				JOIN  
					[cfgCW].[ProductSwitchType] pst ON pst.ProductTypeId1 = pt1.ProductTypeId   
					AND pst.ProductTypeId2 = pt2.ProductTypeId   
					AND pst.ProductRateOfInterestTypeId1 = (CASE WHEN (prev.CURRENT_INTEREST_RATE - curr.CURRENT_INTEREST_RATE)> 0 THEN 1  
					WHEN (prev.CURRENT_INTEREST_RATE - curr.CURRENT_INTEREST_RATE) < 0 THEN 2 ELSE -1 END)  
					AND pst.ProductRateOfInterestTypeId2 = (CASE WHEN (curr.CURRENT_INTEREST_RATE - prev.CURRENT_INTEREST_RATE)> 0 THEN 1  
					WHEN (curr.CURRENT_INTEREST_RATE - prev.CURRENT_INTEREST_RATE) < 0 THEN 2 ELSE -1 END)  
				WHERE  
					pst.ProductRateOfInterestTypeId1 IS NOT NULL   
					AND pst.ProductRateOfInterestTypeId2 IS NOT NULL  
					AND ISNULL(pst.IsInterestControlCodeCondition, 0) = 0  
					AND curr.LIVE_ACCOUNT ='Y'
				GROUP BY   
					pst.ProductSwitchTypeId  
  
				--Now check the Interest Control Code related switch  
				INSERT INTO #tmpDealProductSwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId AS DealId,  
					pst.ProductSwitchTypeId AS ProductSwitchTypeId,  
					COUNT(*) AS LoanCount,  
					SUM(ISNULL(curr.TRUE_BALANCE_AMT, 0)) AS TrueBalanceValue,   
					SUM(ISNULL(curr.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue  
				FROM   
					#tmpMortgageLoanPrevMonthResult prev  
				JOIN   
					[cfgCW].[ProductType] pt1 ON pt1.Name = prev.Product  
				JOIN  
					#tmpMortgageLoanResult curr ON prev.LOAN_IDENTIFIER = curr.LOAN_IDENTIFIER AND prev.SUB_ACCOUNT_ID = curr.SUB_ACCOUNT_ID  
				JOIN   
					[cfgCW].[ProductType] pt2 ON pt2.Name = curr.Product  
				JOIN  
					[cfgCW].[ProductSwitchType] pst ON pst.ProductTypeId1 = pt1.ProductTypeId   
					AND pst.ProductTypeId2 = pt2.ProductTypeId   
					AND prev.CURRENT_INTEREST_RATE = curr.CURRENT_INTEREST_RATE  
				WHERE  
					ISNULL(pst.IsInterestControlCodeCondition, 0) = 1  
					AND curr.InterestControlCode <> prev.InterestControlCode  
					AND curr.LIVE_ACCOUNT ='Y'
				GROUP BY   
					pst.ProductSwitchTypeId  
   
				--*******************Checking Product switch for quarter***************************************  
				INSERT INTO #tmpDealProductQuarterlySwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId AS DealId,  
					pst.ProductSwitchTypeId AS ProductSwitchTypeId,  
					COUNT(*) AS LoanCount,  
					SUM(ISNULL(curr.TRUE_BALANCE_AMT, 0)) AS TrueBalanceValue,   
					SUM(ISNULL(curr.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue  
				FROM   
					#tmpMortgageLoanPrevQuarterMonthResult prev  
				JOIN   
					[cfgCW].[ProductType] pt1 ON pt1.Name = prev.Product  
				JOIN  
					#tmpMortgageLoanResult curr ON prev.LOAN_IDENTIFIER = curr.LOAN_IDENTIFIER AND prev.SUB_ACCOUNT_ID = curr.SUB_ACCOUNT_ID  
				JOIN   
					[cfgCW].[ProductType] pt2 ON pt2.Name = curr.Product  
				JOIN  
					[cfgCW].[ProductSwitchType] pst ON pst.ProductTypeId1 = pt1.ProductTypeId   
					AND pst.ProductTypeId2 = pt2.ProductTypeId   
				WHERE  
					pst.ProductRateOfInterestTypeId1 IS NULL   
					AND ProductRateOfInterestTypeId2 IS NULL  
					AND ISNULL(pst.IsInterestControlCodeCondition, 0) = 0  
					AND curr.LIVE_ACCOUNT ='Y'
				GROUP BY   
					pst.ProductSwitchTypeId  
  
				--Now check the interest switch prev quarter  
				INSERT INTO #tmpDealProductQuarterlySwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId AS DealId,  
					pst.ProductSwitchTypeId AS ProductSwitchTypeId,  
					COUNT(*) AS LoanCount,  
					SUM(ISNULL(curr.TRUE_BALANCE_AMT, 0)) AS TrueBalanceValue,   
					SUM(ISNULL(curr.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue  
				FROM   
					#tmpMortgageLoanPrevQuarterMonthResult prev  
				JOIN   
					[cfgCW].[ProductType] pt1 ON pt1.Name = prev.Product  
				JOIN  
					#tmpMortgageLoanResult curr ON  prev.LOAN_IDENTIFIER = curr.LOAN_IDENTIFIER AND prev.SUB_ACCOUNT_ID = curr.SUB_ACCOUNT_ID  
				JOIN   
					[cfgCW].[ProductType] pt2 ON pt2.Name = curr.Product  
				JOIN  
					[cfgCW].[ProductSwitchType] pst ON pst.ProductTypeId1 = pt1.ProductTypeId   
					AND pst.ProductTypeId2 = pt2.ProductTypeId   
					AND pst.ProductRateOfInterestTypeId1 = (CASE WHEN (prev.CURRENT_INTEREST_RATE - curr.CURRENT_INTEREST_RATE)> 0 THEN 1  
					WHEN (prev.CURRENT_INTEREST_RATE - curr.CURRENT_INTEREST_RATE) < 0 THEN 2 ELSE -1 END)  
					AND pst.ProductRateOfInterestTypeId2 = (CASE WHEN (curr.CURRENT_INTEREST_RATE - prev.CURRENT_INTEREST_RATE)> 0 THEN 1  
					WHEN (curr.CURRENT_INTEREST_RATE - prev.CURRENT_INTEREST_RATE) < 0 THEN 2 ELSE -1 END)  
				WHERE  
					pst.ProductRateOfInterestTypeId1 IS NOT NULL   
					AND ProductRateOfInterestTypeId2 IS NOT NULL  
					AND ISNULL(pst.IsInterestControlCodeCondition, 0) = 0  
					AND curr.LIVE_ACCOUNT ='Y'
				GROUP BY   
					pst.ProductSwitchTypeId  
  
				--Now check the Interest Control Code related switch  
				INSERT INTO #tmpDealProductQuarterlySwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId AS DealId,  
					pst.ProductSwitchTypeId AS ProductSwitchTypeId,  
					COUNT(*) AS LoanCount,  
					SUM(ISNULL(curr.TRUE_BALANCE_AMT, 0)) AS TrueBalanceValue,   
					SUM(ISNULL(curr.OUTSTANDNG_CAPITAL_BALANCE_AMT, 0)) CapitalBalanceValue  
				FROM   
					#tmpMortgageLoanPrevQuarterMonthResult prev  
				JOIN   
					[cfgCW].[ProductType] pt1 ON pt1.Name = prev.Product  
				JOIN  
					#tmpMortgageLoanResult curr ON  prev.LOAN_IDENTIFIER = curr.LOAN_IDENTIFIER AND prev.SUB_ACCOUNT_ID = curr.SUB_ACCOUNT_ID  
				JOIN   
					[cfgCW].[ProductType] pt2 ON pt2.Name = curr.Product  
				JOIN  
					[cfgCW].[ProductSwitchType] pst ON pst.ProductTypeId1 = pt1.ProductTypeId   
					AND pst.ProductTypeId2 = pt2.ProductTypeId   
					AND prev.CURRENT_INTEREST_RATE = curr.CURRENT_INTEREST_RATE  
				WHERE  
					ISNULL(pst.IsInterestControlCodeCondition, 0) = 1  
					AND curr.InterestControlCode <> prev.InterestControlCode 
					AND curr.LIVE_ACCOUNT ='Y' 
				GROUP BY   
					pst.ProductSwitchTypeId  
  
				--add the missing product switch condition  
				INSERT INTO #tmpDealProductSwitch(CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue)  
				SELECT   
					@vintageDate AS CorrelatedDate,  
					@dealId,   
					pst.ProductSwitchTypeId,   
					0, 0, 0  
				FROM  
					[cfgCW].[ProductSwitchType] pst  
				LEFT JOIN  
					#tmpDealProductSwitch tmp ON pst.ProductSwitchTypeId = tmp.ProductSwitchTypeId  
					AND tmp.DealId = @dealId  
				WHERE   
					tmp.DealId IS NULL  
  
				---Now merge the prev quarter switch data  
				UPDATE dps SET   
					dps.QuarterlyLoanCount = dpqs.LoanCount,  
					dps.QuarterlyCapitalBalanceValue = dpqs.CapitalBalanceValue,  
					dps.QuarterlyTrueBalanceValue = dpqs.TrueBalanceValue  
				FROM   
					#tmpDealProductSwitch dps  
				JOIN   
					#tmpDealProductQuarterlySwitch dpqs ON dps.ProductSwitchTypeId = dpqs.ProductSwitchTypeId  
				WHERE   
					dps.DealId = @dealId  
					AND dpqs.DealId = @dealId  
			END
     
			FETCH NEXT FROM cursorCWDeal INTO @mortgageDealId, @dealId, @dealRegionCode, @dealName 
		END  
  
		CLOSE cursorCWDeal;    
		DEALLOCATE cursorCWDeal;   
  
		--Now Populating the data data in cw table   
  
		DELETE dps FROM [cw].[DealProductSwitchData] dps  
		JOIN #tmpDealProductSwitch tmp ON dps.CorrelatedDate = tmp.CorrelatedDate AND dps.DealId = tmp.DealId;  
  
		DELETE dpd FROM [cw].[DealProductData] dpd  
		JOIN #tmpDealProductData tmp ON dpd.CorrelatedDate = tmp.CorrelatedDate AND dpd.DealId = tmp.DealId  
  
		--Populating the Product data  
		INSERT INTO [cw].[DealProductData](CorrelatedDate, DealId, ProductTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue,   
		CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  
		SELECT CorrelatedDate, DealId, ProductTypeId, ISNULL(LoanCount, 0), ISNULL(TrueBalanceValue, 0), ISNULL(CapitalBalanceValue, 0),   
		@createdBy, @createdDate, @createdBy, @createdDate   
		FROM   
		#tmpDealProductData  
  
		--Populating the Product Switch  data  
		INSERT INTO [cw].[DealProductSwitchData](CorrelatedDate, DealId, ProductSwitchTypeId, LoanCount, TrueBalanceValue, CapitalBalanceValue,   
		QuarterlyLoanCount, QuarterlyTrueBalanceValue, QuarterlyCapitalBalanceValue, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate)  
		SELECT CorrelatedDate, DealId, tmp.ProductSwitchTypeId, ISNULL(LoanCount, 0), ISNULL(TrueBalanceValue, 0), ISNULL(CapitalBalanceValue, 0),  
		ISNULL(QuarterlyLoanCount, 0), ISNULL(QuarterlyTrueBalanceValue, 0), ISNULL(QuarterlyCapitalBalanceValue, 0), @createdBy, @createdDate, @createdBy, @createdDate   
		FROM   
		#tmpDealProductSwitch tmp  
  
		PRINT 'Completed............'  
  
	END TRY    
  
	BEGIN CATCH     
		IF CURSOR_STATUS('global','cursorCWDeal') >= 0   
		BEGIN  
			CLOSE cursorCWDeal;  
			DEALLOCATE cursorCWDeal;   
		END  
		DECLARE     
			@errorMessage     NVARCHAR(MAX),    
			@errorSeverity    INT,    
			@errorNumber      INT,    
			@errorLine        INT,    
			@errorState       INT;    
  
		SELECT     
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()    
  
		EXEC app.SaveErrorLog 1, 1, 'cw.spLoadDealProductnSwitchData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage    
		, 'System'    
  
		RAISERROR (@errorMessage,    
		@errorSeverity,    
		@errorState )    
  
	END CATCH    
  
END

GO
