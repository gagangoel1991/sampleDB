USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[spCalculateOneDayCollectionInterest]') IS NOT NULL
	DROP PROCEDURE [cb].[spCalculateOneDayCollectionInterest]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE PROCEDURE [cb].[spCalculateOneDayCollectionInterest]
/*-----------------------------------------------------
 * Author: Kapil Sharma
 * Date:	25.01.2022
 * Description:  This will calculate the interest on collection for one day
 * 
 * Example: 
 * [cb].[spCalculateOneDayCollectionInterest] '2021-04-01'
 * 				
 * Change History
 * --------------
 * Author		Date			Description
   Arun			09-FEB-2022 	For Estimation load Daily Cash collection will by-pass condition and insert the interest data based on estimated values
-------------------------------------------------------*/
(
	@pAsAtDate				DATE
)
AS
BEGIN
	BEGIN TRY
		DECLARE
			@dealId							INT,
			@dealRegion						VARCHAR(20),
			@isEstimationData				INT=0

		SELECT @dealRegion = dlv.[Value], @dealId = DealId FROM cfg.Deal deal
		JOIN cfgcw.DealLookupValue dlv ON dlv.LookupValueId = deal.JurisdictionMarkerId
		WHERE deal.DealName = 'Deimos'
		
		SELECT @isEstimationData= IsNull(IsEstimationData,0) FROM [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId

		IF (@pAsAtDate IS NOT NULL AND EXISTS(SELECT TOP 1 * FROM cw.DailyCollection WHERE DealId = @dealId AND CollectionDate = @pAsAtDate))  or @isEstimationData=1
		BEGIN
			
			DECLARE
				@prevBusinessDay				DATE,
				@principalReceiptsAmount		DECIMAL(36, 18),
				@revenueReceiptsAmount			DECIMAL(36, 18),
				@startingCumulativeCollection	DECIMAL(36, 18),
				@totalCollection				DECIMAL(36, 18),
				@cumulativeCollection			DECIMAL(36, 18),
				@interestAmount					DECIMAL(36, 18),
				@depositDate					DATE,
				@maturityDate					DATE,
				@depositMaturityDtDiff			DECIMAL(8, 4),
				@soniaRate						DECIMAL(36, 18),			
				@prevDayCumulativeCollection	DECIMAL(36, 18),
				@prevDayInterestAmount			DECIMAL(36, 18),
				@createdBy						VARCHAR(80) = 'System',
				@createdDate					DATETIME = GETDATE(),
				@dayCountDays					DECIMAL(8, 4) = 365,
				
				@isPrevDayEstimationData		INT=0,
				@estimatedCollectionAmount		DECIMAL(36, 18) =0,
				@estimatedCumulativeCollection	DECIMAL(36, 18) =0,
				@prevDayEstimatedCumulativeCollection DECIMAL(36, 18) =0

			

			SELECT @prevBusinessDay = [cw].[fnGetBusinessDate](@pAsAtDate, @dealRegion, -1, 1)

			SELECT @soniaRate =[cw].[fnGetSoniaRate](@pAsAtDate, 5) 

			IF @soniaRate IS NOT NULL
			BEGIN
				--Need to fetch the advice date from collection ledger and will use it as Deposit Date
				BEGIN TRANSACTION

				SELECT 
					TOP 1 @depositDate =  AsAtDate
				FROM 
					sfp.syn_SfpModel_vw_Calendar_v1
				WHERE 
					AsAtDate>@pAsAtDate 
					AND IsWorkingDay = 1 AND RegionCode = @dealRegion
				ORDER BY	
					AsAtDate ASC  
			
				IF @depositDate IS NULL
				BEGIN
					SELECT @depositDate = AdviceDate FROM cw.CollectionLedger 
					WHERE DealId = @dealId AND CollectionDate = @pAsAtDate
				END

				--Get the Maturity Date, It will DepositDate + 1
				SELECT @maturityDate = [cw].[fnGetBusinessDate](@depositDate, @dealRegion, 1, 0)

				SET @depositMaturityDtDiff = DATEDIFF(DD, @depositDate, @maturityDate)

				SELECT @prevDayCumulativeCollection = CumulativeCollection, @prevDayInterestAmount = InterestAmount, @prevDayEstimatedCumulativeCollection = EstimatedCumulativeCollection
				FROM cb.SFPCollectionInterest WHERE CollectionDate = @prevBusinessDay 

				SELECT @isEstimationData= IsNull(IsEstimationData,0) FROM [CW].[DailyCollectionSummary] where CollectionDate = @pAsAtDate and DealId=@dealId
				SELECT @IsPrevDayEstimationData = IsNull(IsEstimationData,0) From  [CW].[DailyCollectionSummary] where CollectionDate = @prevBusinessDay and DealId=@dealId 


			
				SELECT @revenueReceiptsAmount = CAST(dc.Value AS DECIMAL(36, 18)) *-1 FROM cw.DailyCollection dc
				JOIN cfgcw.DailyCollectionField dcf ON dc.DailyCollectionFieldId = dcf.DailyCollectionFieldId AND dc.DealId = dcf.DealId
				WHERE dcf.DealId = @dealId AND dc.CollectionDate = @pAsAtDate AND dcf.ColumnName IN ('NetRevenueReceipts')

				SELECT @principalReceiptsAmount = CAST(dc.Value AS DECIMAL(36, 18)) *-1 FROM cw.DailyCollection dc
				JOIN cfgcw.DailyCollectionField dcf ON dc.DailyCollectionFieldId = dcf.DailyCollectionFieldId AND dc.DealId = dcf.DealId
				WHERE dcf.DealId = @dealId AND dc.CollectionDate = @pAsAtDate AND dcf.ColumnName IN ('PrincipalReceiptsDerived')
			
			
				SET @totalCollection = ISNULL(@revenueReceiptsAmount, 0) + ISNULL(@principalReceiptsAmount, 0)

			
				IF @isEstimationData=0 and @IsPrevDayEstimationData =1
					Select @estimatedCollectionAmount = CAST(isNull(Value,0) as decimal(38,2)) From cw.vwDailyCollectionLineItemValue Where CollectionDate= @pAsAtDate  and DealId=@dealId and LineItemInternalName='Daily Cash Movement_3.000'
				ELSE IF @isEstimationData=1 OR @IsPrevDayEstimationData =1
					Select @estimatedCollectionAmount = CAST(isNull(Value,0) as decimal(38,2)) From cw.vwDailyCollectionLineItemValue Where CollectionDate= @pAsAtDate  and DealId=@dealId and LineItemInternalName='Est_Daily Cash Movement_3.000'
				ELSE
					SET @estimatedCollectionAmount = @totalCollection

				IF EXISTS(SELECT TOP 1 * FROM cw.vwDealIpdDates WHERE DealId = @dealId AND CAST(IPD AS DATE)= CAST(@depositDate AS DATE))
				BEGIN
					PRINT 'INSIDE IPD'
					PRINT @pAsAtDate
					DECLARE
						@monthFirstDay				DATE,
						@totalCollectionBeforeIpd	DECIMAL(36, 18),
						@totalInterestBeforeIpd		DECIMAL(36, 18),
						@totalReserveIntBeforeIpd	DECIMAL(36, 18)

					SELECT @monthFirstDay = DATEADD(month, DATEDIFF(month, 0, @pAsAtDate), 0)

					SELECT @totalCollectionBeforeIpd = SUM(TotalCollection) FROM cb.SFPCollectionInterest 
					WHERE CAST(CollectionDate AS DATE)>=CAST(@monthFirstDay AS DATE) AND CAST(CollectionDate AS DATE)<CAST(@pAsAtDate AS DATE)

					SELECT @totalInterestBeforeIpd = SUM(InterestAmount) FROM cb.SFPCollectionInterest 
					WHERE CAST(DepositDate AS DATE)>=CAST(@monthFirstDay AS DATE) AND CAST(DepositDate AS DATE)<CAST(@depositDate AS DATE)

					SELECT @totalReserveIntBeforeIpd = SUM(InterestAmount) FROM cb.ReserveInterest 
					WHERE CAST(DepositDate AS DATE)>=CAST(@monthFirstDay AS DATE) AND CAST(DepositDate AS DATE)<CAST(@depositDate AS DATE)

					SET @startingCumulativeCollection = ISNULL(@totalCollectionBeforeIpd, 0) + ISNULL(@totalInterestBeforeIpd, 0) + ISNULL (@totalReserveIntBeforeIpd, 0) 
				
					SET @cumulativeCollection = ISNULL(@startingCumulativeCollection, 0) + @totalCollection
					SET @estimatedCumulativeCollection = ISNULL(@startingCumulativeCollection, 0) + @estimatedCollectionAmount

					IF @isEstimationData=0 and @IsPrevDayEstimationData =1
						SET @interestAmount = CAST(@startingCumulativeCollection + isNull(@estimatedCollectionAmount,0)  AS FLOAT)*(@soniaRate/100.00)*(CAST(@depositMaturityDtDiff AS FLOAT)/@dayCountDays)
					ELSE IF @isEstimationData=1 OR @IsPrevDayEstimationData =1
						SET @interestAmount = CAST(@startingCumulativeCollection + isNull(@estimatedCollectionAmount,0)  AS FLOAT)*(@soniaRate/100.00)*(CAST(@depositMaturityDtDiff AS FLOAT)/@dayCountDays)
					Else
						SET @interestAmount = CAST(@cumulativeCollection AS FLOAT)*(@soniaRate/100.00)*(CAST(@depositMaturityDtDiff AS FLOAT)/@dayCountDays)

				END
				ELSE
				BEGIN
					---Prev bussiness day cumulative collection + Current day collection (Revenue + Principal)
					SET @cumulativeCollection = ISNULL(@prevDayCumulativeCollection, 0) + @totalCollection + ISNULL(@prevDayInterestAmount, 0)
					SET @estimatedCumulativeCollection = ISNULL(@prevDayEstimatedCumulativeCollection, 0) + @estimatedCollectionAmount + + ISNULL(@prevDayInterestAmount, 0)
				
				
					SET @interestAmount = CAST(@estimatedCumulativeCollection AS FLOAT)*(@soniaRate/100.00)*(CAST(@depositMaturityDtDiff AS FLOAT)/@dayCountDays)


					SET @startingCumulativeCollection = 0
				END

				IF NOT EXISTS(SELECT TOP 1 * FROM cb.SFPCollectionInterest WHERE CollectionDate = @pAsAtDate)
				BEGIN
					INSERT INTO cb.SFPCollectionInterest(CollectionDate, PrincipalReceiptAmount, RevenueReceiptAmount, TotalCollection, SoniaRate, DepositDate, MaturityDate
					,StartingCumulativeCollection, CumulativeCollection, InterestAmount, CreatedBy, CreatedDate, ModifiedBy, ModifiedDate, EstimatedTotalCollection, EstimatedCumulativeCollection)
					VALUES(@pAsAtDate, isNull(@principalReceiptsAmount,0), isNull(@revenueReceiptsAmount,0), isNull(@totalCollection,0), @soniaRate, @depositDate, @maturityDate,
					isNull(@startingCumulativeCollection,0), isNull(@cumulativeCollection,0), isNull(@interestAmount,0), @createdBy, @createdDate, @createdBy, @createdDate, isNull(@estimatedCollectionAmount,0), isNull(@estimatedCumulativeCollection,0))
				END
				ELSE
				BEGIN
					UPDATE cb.SFPCollectionInterest SET PrincipalReceiptAmount = isNull(@principalReceiptsAmount,0), RevenueReceiptAmount = isNull(@revenueReceiptsAmount,0),
					TotalCollection = isNull(@totalCollection,0), SoniaRate =@soniaRate, DepositDate = @depositDate, MaturityDate = @maturityDate,
					StartingCumulativeCollection = isNull(@startingCumulativeCollection,0), CumulativeCollection = isNull(@cumulativeCollection,0), InterestAmount = isNull(@interestAmount,0),
					ModifiedBy = @createdBy, ModifiedDate = @createdDate,
					EstimatedTotalCollection=isNull(@estimatedCollectionAmount,0), EstimatedCumulativeCollection = isNull(@estimatedCumulativeCollection,0)

					WHERE CollectionDate = @pAsAtDate
				END

				COMMIT TRANSACTION; 
			END

		END

	END TRY
	BEGIN CATCH

		IF @@trancount > 0 ROLLBACK TRANSACTION; 

		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'cb.spCalculateOneDayCollectionInterest', @errorNumber,  @errorSeverity, @errorLine, @errorMessage
		, 'System'
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH 
END
GO