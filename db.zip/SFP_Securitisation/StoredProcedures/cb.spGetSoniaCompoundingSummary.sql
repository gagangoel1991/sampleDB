USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetSoniaCompoundingSummary]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetSoniaCompoundingSummary]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Suresh Pandey 
--Date: 17-02-2022 
--Description: GET Sonia rate compounding summary
--   [cb].[spGetSoniaCompoundingSummary] 6,101,''
--==================================   
CREATE PROCEDURE [cb].[spGetSoniaCompoundingSummary] 
	@pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)
AS
BEGIN
	BEGIN TRY

	Declare @NewRedemptionDate DATE,@NewRedemptionIpdDate DATE,@LatestIPDDate Date

	SELECT TOP 1 @NewRedemptionDate = NewRedemptionDate from cfgcb.DealNote WHERE NewRedemptionDate IS NOT NULL AND series=11
	SELECT TOP 1 @NewRedemptionIpdDate =dir.IpdDate from cw.vwDealIpdRun dir where dir.IpdDate>= @NewRedemptionDate AND dealid=@pDealId
		
		IF ( Object_id('tempdb..#IpdRunId') IS NOT NULL ) 
		DROP TABLE #IpdRunId 

		CREATE TABLE #IpdRunId(
			RunId INT)

		INSERT INTO #IpdRunId
		SELECT RunId FROM cw.fnGetPrevIpdRunIds(@pDealId,@pIPDRunId,4)

		
		SELECT Top 1 @LatestIPDDate= IpdDate from cw.vwDealIpdRun dir JOIN #IpdRunId run ON dir.DealIpdRunId=run.RunID where dealid=@pDealId order by 1 desc

	--	select @NewRedemptionDate DATE,@NewRedemptionIpdDate,@LatestIPDDate

		--To remove base ipd data. Removing run id from temp table so data will not pick for this Ipd
		DELETE FROM #IpdRunId WHERE RunId IN (SELECT RunId FROM cw.Dealipdrun WHERE dealipdid = (SELECT dealipdid FROM cw.Dealipd WHERE dealid=6 AND IpdDate='2021-04-22 00:00:00.000'))

		SELECT * FROM (
		SELECT	ipd.IpdDate,
				vdid.CollectionBusinessEnd AS CollectionEndDate,
				vdid.CollectionBusinessStart AS CollectionStartDate,
				ds.SwapName AS SwapName,
				dswf.PayCouponPeriodStart AS CouponPeriodStart,
				dswf.PayCouponPeriodEnd AS CouponPeriodEnd,
				dswf.PayDayCountFactor AS PayDayCountFactor,
				ds.PayDayCountMethodId AS DayCountMethodId,
				cb.fnGetSoniaCompoundingCouponRate(ds.PayDayCountMethodId,dswf.PayDayCountFactor,dswf.PayCouponPeriodStart,dswf.PayCouponPeriodEnd) * 100 AS Coupon,
				'Deal Swap' AS GroupType,
				1 AS SortOrder
		FROM cb.DealSwap_Wf dswf
		JOIN cfgcb.DealSwap ds ON ds.DealSwapId=dswf.DealSwapId
		JOIN cw.dealipdrun dir ON dir.RunId=dswf.DealIpdRunId
		JOIN cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN #IpdRunId runid ON runid.RunId=dir.RunId
		JOIN [CW].[vwDealIpdDates] vdid ON vdid.IPD=ipd.IpdDate
		
		UNION

		SELECT	ipd.IpdDate,
				vdid.CollectionBusinessEnd AS CollectionEndDate,
				vdid.CollectionBusinessStart AS CollectionStartDate,
				dn.[Name] AS SwapName,
				nswf.PayCouponPeriodStart  AS  CouponPeriodStart,
				nswf.PayCouponPeriodEnd AS  CouponPeriodEnd,
				nswf.PayDayCountFactor AS PayDayCountFactor,
				dn.DayCountMethodId AS DayCountMethodId,
				cb.fnGetSoniaCompoundingCouponRate(ns.PayDayCountMethodId,nswf.PayDayCountFactor,nswf.PayCouponPeriodStart,nswf.PayCouponPeriodEnd) * 100 AS Coupon,
				'Bond Swap' AS GroupType,
				2 AS SortOrder
		FROM cb.NoteSwap_Wf nswf
		JOIN cfgcb.NoteSwap  ns ON ns.NoteSwapId=nswf.NoteSwapId
		JOIN [cfgcb].[DealNote] dn ON dn.DealNoteId=ns.DealNoteId
		JOIN cw.dealipdrun dir ON dir.RunId=nswf.DealIpdRunId
		JOIN cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN #IpdRunId runid ON runid.RunId=dir.RunId
		JOIN [CW].[vwDealIpdDates] vdid ON vdid.IPD=ipd.IpdDate

		UNION

		SELECT	ipd.IpdDate,
				vdid.CollectionBusinessEnd AS CollectionEndDate,
				vdid.CollectionBusinessStart AS CollectionStartDate,
				dn.[Name] AS SwapName,
				dnwf.CouponPaymentStartPeriod  AS  CouponPeriodStart,
				dnwf.CouponPaymentEndPeriod AS  CouponPeriodEnd,
				dnwf.DayCountFactor AS PayDayCountFactor,
				dn.DayCountMethodId AS DayCountMethodId,
				CASE WHEN dnwf.CouponPaymentEndPeriod=ipd.IpdDate THEN
							cb.fnGetSoniaCompoundingCouponRate(dn.DayCountMethodId,dnwf.DayCountFactor,dnwf.CouponPaymentStartPeriod,dnwf.CouponPaymentEndPeriod)
							ELSE 0 END * 100 AS Coupon,
				dn.[Name] AS GroupType,
				3 AS SortOrder
		FROM cb.DealNote_Wf dnwf
		JOIN [cfgcb].[DealNote] dn ON dn.DealNoteId=dnwf.DealNoteId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId=dnwf.DealIpdRunId
		JOIN cw.DealIpd ipd ON ipd.DealIpdId=dir.DealIpdId 
		JOIN #IpdRunId runid ON runid.RunId=dir.DealIpdRunId
		JOIN [CW].[vwDealIpdDates] vdid ON vdid.IPD=ipd.IpdDate
		WHERE IsSwapLinked =0
		

		AND  1= CASE
				   WHEN (dn.NewRedemptionDate is NOT NULL AND  @LatestIPDDate >	@NewRedemptionIpdDate )			   
				    THEN 0
					WHEN (dn.NewRedemptionDate is  NULL AND dn.MaturityDate <@LatestIPDDate)
					THEN 0
				    ELSE  1
				 END
		
		) a
		ORDER BY SortOrder,IpdDate DESC,GroupType

	END TRY

	BEGIN CATCH
		DECLARE @errorMessage NVARCHAR(MAX)
			,@errorSeverity INT
			,@errorNumber INT
			,@errorLine INT
			,@errorState INT;

		SELECT @errorMessage = ERROR_MESSAGE()
			,@errorSeverity = ERROR_SEVERITY()
			,@errorNumber = ERROR_NUMBER()
			,@errorLine = ERROR_LINE()
			,@errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1
			,1
			,'cb.spGetSoniaCompoundingSummary'
			,@errorNumber
			,@errorSeverity
			,@errorLine
			,@errorMessage
			,@pUserName

		RAISERROR (
				@errorMessage
				,@errorSeverity
				,@errorState
				)
	END CATCH
END
GO


