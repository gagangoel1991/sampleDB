USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT 1 FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spInsertNewDealCorporate]') AND TYPE IN (N'P', N'PC'))
	DROP PROCEDURE [corp].[spInsertNewDealCorporate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
 

CREATE PROCEDURE [corp].[spInsertNewDealCorporate]  
(  
	@pDealName VARCHAR(50),
	@pDescription VARCHAR(200),
	@pDealQuaterMonth VARCHAR(20),
	@pDealMaturityDate DATE,
	@pCreatedBy VARCHAR(60),
	@pDealStartDate DATE,
	@pDealType VARCHAR(50),
	@pBaseCurrency VARCHAR(3),
	@pCashReportingFlag VARCHAR(5),
	@pDealInitialSize DECIMAL(19,2),
	@pTopupEndDate DATE,
	@pTopupFlag VARCHAR(5),
	@pRiskRetentionPercent DECIMAL(15, 14),
	@pRiskRetentionMethod VARCHAR(15),
	@pRiskRetentionHolder VARCHAR(15),
	@pRonaCalculatedBasedOn VARCHAR(60),
	@pFxRateDate DATE,	
	@pFacilitySharingAllowed VARCHAR(1),	
	@pEnableHistoricFlagging VARCHAR(1),		
	@pFacilityPercentChangeAllowed VARCHAR(1),
	@pLegalRetentionPercent DECIMAL(15, 14) = NULL,
	@pDMLType INT = 1,  
	@pDealStatus VARCHAR(50) = 'Active',
	@pReturnValue INT = 0 OUTPUT,  
	@pReturnMessage VARCHAR(100) = NULL OUTPUT  
)  
AS  
BEGIN  
 BEGIN TRY  
  IF(@pDMLType = 1)  
  BEGIN  
   IF NOT EXISTS(SELECT 1 FROM [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] WHERE DealName = @pDealName AND IsActive = 'Y')  
   BEGIN 
    DECLARE @Id BIGINT
	DECLARE @CurrentUser VARCHAR(50) = SUSER_NAME() -- @pModifiedBy
	DECLARE @pReportTemplateName VARCHAR(10) ='ESMA_12_CB' 
	DECLARE @pLookUpName VARCHAR(50) =@pDealName
	DECLARE @pLookUpValue VARCHAR(50)='OBSOLUTE'
	DECLARE @pReportValue VARCHAR(100) ='OBSOLUTE'
	DECLARE @pLookUpValueDescription VARCHAR(100) ='OBSOLUTE'
	DECLARE @CurrentDateTime DATETIME = GETUTCDATE()
	DECLARE @AsAtDateFrom DATE = DATEADD(dd, DATEDIFF(dd, 0, GETUTCDATE()), 0) -- remove date time | GETUTCDATE()
	DECLARE @AsAtDateTo DATE = '9999-12-31'
	DECLARE @pModifiedBy  VARCHAR(50) =SUSER_NAME()

 
   DECLARE @DealID INT = (SELECT MAX( CONVERT(INT,DealId)) + 1 FROM [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal]) 
   SELECT @DealID = ISNULL(@DealID, 1)
   DECLARE @Seq INT = ( SELECT TOP 1 ( (ROW_NUMBER() Over(Partition BY  DATEPART(YYYY, CreatedDate) ORDER BY DealId,CreatedDate ASC) ) )+1 FROM [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] order by DealId DESC) 
   SELECT @Seq = ISNULL(@Seq, 1)
   DECLARE @UniqueIdentifier VARCHAR(50)= (SELECT DISTINCT  LookUpValueDescription  	 
															FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
															WHERE ReportTemplateName = 'ESMA_CB'  AND LookUpName='LEI'
															AND Lookupvalue='NATIONAL WESTMINSTER BANK PUBLIC LIMITED COMPANY'
											)
	SELECT @UniqueIdentifier =@UniqueIdentifier +'N'+CAST(YEAR(@pDealStartDate)AS VARCHAR(10))+CAST(@Seq AS VARCHAR(10))
  
    INSERT INTO [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal]
    (  
		DealID,
		DealName,
		Description,
		DealQuaterMonth,
		DealMaturityDate,
		IsActive,
		CreatedBy,
		CreatedDate,
		ModifiedBy,
		ModifiedDate,
		DealRetentionPercent,
		DealStartDate,
		UniqueIdentifier,
		DealType,
		PoolSize,
		BaseCurrency,
		CashReportingFlag,
		DealInitialSize,
		TopupEndDate,
		TopupFlag,
		RiskRetentionMethod,
		RiskRetentionHolder,
		RonaCalculatedBasedOn,
		FxRateDate,	
		FacilitySharingAllowed,	
		EnableHistoricFlagging,		
		FacilityPercentChangeAllowed,
		LegalRetentionPercent,
		DealStatus
    )  
    VALUES  
    (  
		@DealID,
		@pDealName,
		@pDescription,
		@pDealQuaterMonth,
		@pDealMaturityDate,
		'Y',
		@pCreatedBy,
		getdate(),
		@pCreatedBy,
		getdate(),
		@pRiskRetentionPercent,
		@pDealStartDate,
		@UniqueIdentifier,
		@pDealType,
		'NA',
		@pBaseCurrency,
		@pCashReportingFlag,
		@pDealInitialSize,
		@pTopupEndDate,
		@pTopupFlag,
		@pRiskRetentionMethod,
		@pRiskRetentionHolder,
		@pRonaCalculatedBasedOn,
		@pFxRateDate,	
		@pFacilitySharingAllowed,	
		@pEnableHistoricFlagging,		
		@pFacilityPercentChangeAllowed,
		@pLegalRetentionPercent,
		@pDealStatus
    )  
  
   SELECT @pReturnValue = CONVERT(INT,DealId), 
		  @pReturnMessage = DealName 
   FROM [corp].[syn_SfpModelCorporate_tbl_DimCorporateDeal] 
   WHERE DealName = @pDealName AND IsActive = 'Y'

   SELECT @pLookUpName  =@pDealName
   SELECT @Id = MAX(Id) + 1 FROM [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
   IF NOT EXISTS ( SELECT 1 FROM  [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
							WHERE [ReportTemplateName] = @pReportTemplateName 
								AND [LookUpName] = @pLookUpName
								AND [LookUpValue] = @pLookUpValue
								AND [LookUpValueDescription] = @pLookUpValueDescription
								AND [ReportValue] = @pReportValue
							)
            BEGIN
				INSERT [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
					   ([id], [Status], [Changer], [Requester], [RequestedDateTime], [Authoriser], [AuthorisationDateTime]
					   ,[ModifiedDateTime], [ReportTemplateName], [LookUpName], [LookUpValue], [LookUpValueDescription], [ReportValue]) 

				VALUES (@Id, NULL, NULL, NULL, NULL, NULL, NULL 
						,NULL, @pReportTemplateName, @pLookUpName, @pLookUpValue, @pLookUpValue, @pReportValue)
			END

	  IF NOT EXISTS (SELECT 1 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
                           WHERE [ReportTemplateName] = @pReportTemplateName 
                                AND [LookUpName] = @pLookUpName
                                AND [LookUpValue] = @pLookUpValue
                                AND [LookUpValueDescription] = @pLookUpValueDescription
                                AND [ReportValue] = @pReportValue
						   )
            BEGIN

				INSERT INTO [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
										([ReportTemplateName],[LookUpName],[LookUpValue],[LookUpValueDescription],[ReportValue],[AsAtDateFrom],[AsAtDateTo],
										 [CreateDateTime],[CurrentRecord],[Changer],[Requester],[RequestedDateTime],[Authoriser],[AuthorisationDateTime],[ModifiedBy],[ModifiedDateTime])
								 SELECT @pReportTemplateName, @pLookUpName, @pLookUpValue, @pLookUpValueDescription, @pReportValue, @AsAtDateFrom, @AsAtDateTo,
										@CurrentDateTime, 1, '', '', @CurrentDateTime, '', @CurrentDateTime, @pModifiedBy, @CurrentDateTime    
										
			END


	 
	 
	/* 
	 
	SET @pLookUpValue  ='ReportingEntityContactTelephone'
	SET @pReportValue  ='07747 627290'
	SET @pLookUpValueDescription  ='ReportingEntityContactTelephone'
	

   SET @pLookUpName  =@pDealName
   SELECT @Id = MAX(Id) + 1 FROM [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
   IF NOT EXISTS ( SELECT 1 FROM  [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
							WHERE [ReportTemplateName] = @pReportTemplateName 
								AND [LookUpName] = @pLookUpName
								AND [LookUpValue] = @pLookUpValue
								AND [LookUpValueDescription] = @pLookUpValueDescription
								AND [ReportValue] = @pReportValue
							)
            BEGIN
				INSERT [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
					   ([id], [Status], [Changer], [Requester], [RequestedDateTime], [Authoriser], [AuthorisationDateTime]
					   ,[ModifiedDateTime], [ReportTemplateName], [LookUpName], [LookUpValue], [LookUpValueDescription], [ReportValue]) 

				VALUES (@Id, NULL, NULL, NULL, NULL, NULL, NULL 
						,NULL, @pReportTemplateName, @pLookUpName, @pLookUpValue, @pLookUpValue, @pReportValue)
			END

	  IF NOT EXISTS (SELECT 1 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
                           WHERE [ReportTemplateName] = @pReportTemplateName 
                                AND [LookUpName] = @pLookUpName
                                AND [LookUpValue] = @pLookUpValue
                                AND [LookUpValueDescription] = @pLookUpValueDescription
                                AND [ReportValue] = @pReportValue
						   )
            BEGIN

				INSERT INTO [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
										([ReportTemplateName],[LookUpName],[LookUpValue],[LookUpValueDescription],[ReportValue],[AsAtDateFrom],[AsAtDateTo],
										 [CreateDateTime],[CurrentRecord],[Changer],[Requester],[RequestedDateTime],[Authoriser],[AuthorisationDateTime],[ModifiedBy],[ModifiedDateTime])
								 SELECT @pReportTemplateName, @pLookUpName, @pLookUpValue, @pLookUpValueDescription, @pReportValue, @AsAtDateFrom, @AsAtDateTo,
										@CurrentDateTime, 1, '', '', @CurrentDateTime, '', @CurrentDateTime, @pModifiedBy, @CurrentDateTime    
										
			END


	SET @pLookUpValue  ='ReportingEntityContactEmails'
	SET @pReportValue  ='simon.ayres@natwest.com'
	SET @pLookUpValueDescription  ='ReportingEntityContactEmails'
	

   SET @pLookUpName  =@pDealName
   SELECT @Id = MAX(Id) + 1 FROM [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
   IF NOT EXISTS ( SELECT 1 FROM  [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
							WHERE [ReportTemplateName] = @pReportTemplateName 
								AND [LookUpName] = @pLookUpName
								AND [LookUpValue] = @pLookUpValue
								AND [LookUpValueDescription] = @pLookUpValueDescription
								AND [ReportValue] = @pReportValue
							)
            BEGIN
				INSERT [sfp].[syn_SfpModel_ref_ReportLookUpDataForWorkpad]
					   ([id], [Status], [Changer], [Requester], [RequestedDateTime], [Authoriser], [AuthorisationDateTime]
					   ,[ModifiedDateTime], [ReportTemplateName], [LookUpName], [LookUpValue], [LookUpValueDescription], [ReportValue]) 

				VALUES (@Id, NULL, NULL, NULL, NULL, NULL, NULL 
						,NULL, @pReportTemplateName, @pLookUpName, @pLookUpValue, @pLookUpValue, @pReportValue)
			END

	  IF NOT EXISTS (SELECT 1 FROM [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
                           WHERE [ReportTemplateName] = @pReportTemplateName 
                                AND [LookUpName] = @pLookUpName
                                AND [LookUpValue] = @pLookUpValue
                                AND [LookUpValueDescription] = @pLookUpValueDescription
                                AND [ReportValue] = @pReportValue
						   )
            BEGIN

				INSERT INTO [sfp].[syn_SfpModel_vw_ref_vw_ReportLookUpData_v1]  
										([ReportTemplateName],[LookUpName],[LookUpValue],[LookUpValueDescription],[ReportValue],[AsAtDateFrom],[AsAtDateTo],
										 [CreateDateTime],[CurrentRecord],[Changer],[Requester],[RequestedDateTime],[Authoriser],[AuthorisationDateTime],[ModifiedBy],[ModifiedDateTime])
								 SELECT @pReportTemplateName, @pLookUpName, @pLookUpValue, @pLookUpValueDescription, @pReportValue, @AsAtDateFrom, @AsAtDateTo,
										@CurrentDateTime, 1, '', '', @CurrentDateTime, '', @CurrentDateTime, @pModifiedBy, @CurrentDateTime    
										
			END
			*/
   END  
  END  
 END TRY  
 BEGIN CATCH  
   DECLARE     
    @errorMessage     NVARCHAR(MAX),    
    @errorSeverity    INT,    
    @errorNumber      INT,    
    @errorLine        INT,    
    @errorState       INT;    
   SELECT     
    @errorMessage = ERROR_MESSAGE()  
    ,@errorSeverity = ERROR_SEVERITY()  
    ,@errorNumber = ERROR_NUMBER()  
    ,@errorLine = ERROR_LINE()  
    ,@errorState = ERROR_STATE()    
    
   EXEC app.SaveErrorLog 2, 1, 'spInsertNewDealCorporate', @errorNumber, @errorSeverity, @errorLine, @errorMessage, ''    
      
   RAISERROR (@errorMessage,    
     @errorSeverity,    
     @errorState )    
 END CATCH  
END
GO
