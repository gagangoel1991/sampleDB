USE [SFP_Securitisation]
GO

IF  EXISTS (SELECT * FROM sys.objects WHERE object_id = OBJECT_ID(N'[corp].[spGetCBFacilityAttributeData]') AND type in (N'P', N'PC'))
	DROP PROCEDURE [corp].[spGetCBFacilityAttributeData]
GO

SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*-------------------------------------------------------  
Author: Saurav
Date: 04.07.2022  
Description:  This will return data from the staging table CBFacilityAttribute for displaying the data on UI
			  exec [corp].[spGetCBFacilityAttributeData]
Change History  NJ; 09-Jul-2022; SFPT-12508; Added InterestRateFloor column
--------------  
Author			Date		Description  
-------------------------------------------------------  
Saurav Kumar	04-07-2022	Initial SP creation
*/
CREATE PROCEDURE [corp].[spGetCBFacilityAttributeData]  
AS  
BEGIN 
			
	BEGIN TRY  

		SELECT Top 1000 
			Deal, 
			FacilityId, 
			RepaymentType, 
			RepaymentFrequency, 
			InterestRateFloor,
			AsAtDate
		FROM [corp].[syn_SfpStaging_tbl_CBFacilityAttribute]
		ORDER BY 1, 2

	END TRY
	BEGIN CATCH
		DECLARE 
			@errorMessage     NVARCHAR(MAX),
			@errorSeverity    INT,
			@errorNumber      INT,
			@errorLine        INT,
			@errorState       INT;

		SELECT 
			@errorMessage = ERROR_MESSAGE(), @errorSeverity = ERROR_SEVERITY(), @errorNumber = ERROR_NUMBER(), @errorLine = ERROR_LINE(), @errorState = ERROR_STATE()

		EXEC app.SaveErrorLog 1, 1, 'spGetCBFacilityAttributeData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, ''
		
		RAISERROR (@errorMessage,
             @errorSeverity,
             @errorState )
	END CATCH

END
GO
