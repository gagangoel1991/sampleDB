USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.spDeleteAssetStrat') IS NOT NULL
	DROP PROC  cw.spDeleteAssetStrat
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROC cw.spDeleteAssetStrat
@pStratId int,
@pUserName varchar(80),
@pReturnCode int =0 output
AS  
BEGIN  

 BEGIN TRY  
  
  --Update [cfgCW].[IR_Strat] set IsActive=0 , ModifiedBy = @ModifiedBy, ModifiedDate=getdate()
  --where StratId=@pStratId
  
  --DELETE from [cfgCW].IR_AssetStratCriteria where AssetStratFieldMapId in (Select AssetStratId from [cfgCW].IR_AssetStrat where StratId=@pStratId)
  
  DELETE IAC
	FROM [cfgCW].IR_AssetStratCriteria IAC
	INNER JOIN [cfgCW].IR_AssetStrat IAS  ON IAC.AssetStratFieldMapId=IAS.AssetStratId
	WHERE IAS.StratId=@pStratId
  
  DELETE FROM [cfgCW].IR_AssetStrat WHERE StratId=@pStratId
  
  DELETE FROM [cfgCW].[IR_Strat] WHERE StratId=@pStratId
  
  SET @pReturnCode=1
  
  RETURN @pReturnCode;
   
 END TRY  
  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 2, 1, 'spDeleteAssetStrat', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
  
END  
GO
