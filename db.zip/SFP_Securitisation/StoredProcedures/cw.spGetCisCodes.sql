USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetCisCodes]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetCisCodes]   
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [cw].[spGetCisCodes]   
/*  
 * Author: Gunjan Chandola  
 * Date: 23.03.2021  
 * Description:  This will return Active CisCode for a deal 
 * [cw].[spGetCisCodes] 15,'CHAGJGA'
 * Change History  
 * --------------  
 * Author  Date  Description  
 * -------------------------------------------------------  
*/  
@pDealId  INT,   
@pUserName  VARCHAR(80)  
AS  
BEGIN  
  
 SET NOCOUNT ON  
 
 BEGIN TRY 
   DECLARE @seprator varchar(20) = ' | ';  
 
	SELECT CisCode + @seprator + CounterpartyName AS CisCode 
	FROM [cfgCW].[DealCounterParty] dn
	   JOIN [CW].[vw_DealLookup] dlv ON dlv.LookupValueId = dn.DealCounterpartyTypeId
	WHERE dn.DealId= @pDealId AND dn.IsActive=1 AND dlv.Name <> 'Booking' 
 
 END TRY  
 BEGIN CATCH  
  DECLARE   
   @errorMessage     NVARCHAR(MAX),  
   @errorSeverity    INT,  
   @errorNumber      INT,  
   @errorLine        INT,  
   @errorState       INT;  
  
  SELECT   
   @errorMessage = ERROR_MESSAGE()
   ,@errorSeverity = ERROR_SEVERITY()
   ,@errorNumber = ERROR_NUMBER()
   ,@errorLine = ERROR_LINE()
   ,@errorState = ERROR_STATE()  
  
  EXEC app.SaveErrorLog 1, 1, 'spGetCisCodes', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
  , @pUserName  
    
  RAISERROR (@errorMessage,  
             @errorSeverity,  
             @errorState )  
 END CATCH  
END  
GO


