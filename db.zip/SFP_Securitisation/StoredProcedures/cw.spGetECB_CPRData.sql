USE [SFP_Securitisation]
GO
--Need to remove the deal specific procedure 
IF OBJECT_ID('[cw].[spGetRMBSDealECB_CPRData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetRMBSDealECB_CPRData]   
GO
IF OBJECT_ID('[cw].[spGetECB_CPRData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetECB_CPRData]   
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE PROCEDURE [CW].[spGetECB_CPRData]  
/*-------------------------------------------------------  
 * Author: Kapil Sharma
 * Date: 06.09.2021  
 * Description:  This will return the ECB report CPR section data for RMBS deals
 * 			  [cw].[spGetECB_CPRData]  'Dunmore1', '2020-11-30'
 * Change History  
 * --------------  
 * Author  Date  Description  
 * -------------------------------------------------------  
*/  
(  
 @DealName		VARCHAR(70),  
 @AsAtDate		DATETIME ,
 @PoolDescription VARCHAR(115) = NULL
)  
AS  
BEGIN 
	BEGIN TRY  

		DECLARE
			@dealIpdRunId					INT,
			@dealPrevIpdRunId				INT,
			@dealId							INT,
			@annualisedCPRCurrentMonth		DECIMAL(20, 8),
			@annualisedCPRMinus1Month		DECIMAL(20, 8),
			@annualisedCPRMinus2Month		DECIMAL(20, 8),
			@currentMonthCorrleatedDate		DATE,
			@prevMonthCorrelatedDate		DATETIME,
			@prev2MonthCorrelatedDate		DATETIME,
			@dealRegionCode					VARCHAR(20)

		SELECT 
			@dealIpdRunId = dir.RunId,
			@dealPrevIpdRunId = dirMinus1.DealIpdRunId,
			@dealId = deal.DealId,
			@currentMonthCorrleatedDate = dit.CollectionBusinessEnd,
			@dealRegionCode = deal.DealRegionCode,
			@annualisedCPRCurrentMonth = IIF(dit.CollectionBusinessEnd IS NULL, 0, [CW].[fnGetDealAggregatedFieldValue](dit.CollectionBusinessEnd, di.DealId, 'AnnualisedCPR'))
		FROM
			cw.DealIpdRun dir
		JOIN
			cw.DealIpd di ON dir.DealIpdId = di.DealIpdId
		JOIN
			cw.vwDealIpdDates dit ON di.IpdDate = dit.IPD
		JOIN
			cw.vw_ActiveDeal deal ON deal.DealId = di.DealId
		LEFT JOIN
			cw.vwDealIpdRun dirMinus1 ON dit.PreviousIPD = dirMinus1.IpdDate AND dirMinus1.DealId = deal.DealId
		LEFT JOIN
			cw.vwDealIpdDates ditMinus1 ON dirMinus1.IpdDate = ditMinus1.IPD
		LEFT JOIN
			cw.vwDealIpdRun dirMinus2 ON ditMinus1.PreviousIPD = dirMinus2.IpdDate AND dirMinus2.DealId = deal.DealId
		LEFT JOIN
			cw.vwDealIpdDates ditMinus2 ON dirMinus2.IpdDate = ditMinus2.IPD
		WHERE
			dit.CollectionBusinessEnd = @AsAtDate
			AND deal.DealName = @DealName
			AND dir.IsCurrentVersion = 1

		SELECT 
			TOP 1 @prevMonthCorrelatedDate =  AsAtDate
		FROM 
			sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			Month = Month(DATEADD(DD,1 ,EOMONTH(@currentMonthCorrleatedDate,-2))) AND year = Year(DATEADD(DD,1 ,EOMONTH(@currentMonthCorrleatedDate,-2)))  
			AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
		ORDER BY	
			AsAtDate DESC

		SELECT 
			TOP 1 @prev2MonthCorrelatedDate =  AsAtDate
		FROM 
			sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			Month = Month(DATEADD(DD,1 ,EOMONTH(@currentMonthCorrleatedDate,-3))) AND year = Year(DATEADD(DD,1 ,EOMONTH(@currentMonthCorrleatedDate,-3)))  
			AND IsWorkingDay = 1 AND RegionCode = @dealRegionCode
		ORDER BY	
			AsAtDate DESC

		PRINT '@prevMonthCorrelatedDate'
		PRINT @prevMonthCorrelatedDate
		PRINT '@prev2MonthCorrelatedDate'
		PRINT @prev2MonthCorrelatedDate

		SET @annualisedCPRMinus1Month = IIF(@prevMonthCorrelatedDate IS NULL, 0, [CW].[fnGetDealAggregatedFieldValue](@prevMonthCorrelatedDate, @dealId, 'AnnualisedCPR'))
		SET @annualisedCPRMinus2Month =  IIF(@prev2MonthCorrelatedDate IS NULL, 0, [CW].[fnGetDealAggregatedFieldValue](@prev2MonthCorrelatedDate, @dealId, 'AnnualisedCPR'))

		SELECT 
			ISNULL((SELECT Losses FROM cw.PDL_PreWF WHERE DealIpdRunId = @dealIpdRunId), 0) AS AppliedAmountLossesCurrentMonth,
			0 AppliedAmountLossesMinus1Month,
			0 AppliedAmountLossesMinus2Months,
			ISNULL((SELECT Losses FROM cw.PDL_PreWF WHERE DealIpdRunId = @dealPrevIpdRunId), 0) AS AppliedAmountLossesMinus3Months,
			(ISNULL(@annualisedCPRCurrentMonth, 0) + ISNULL(@annualisedCPRMinus1Month, 0) + ISNULL(@annualisedCPRMinus2Month, 0))/3 AS AnnualisedAvgCPR

	END TRY

	BEGIN CATCH  

	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  

	SELECT   
		@errorMessage = ERROR_MESSAGE()
		,@errorSeverity = ERROR_SEVERITY()
		,@errorNumber = ERROR_NUMBER()
		,@errorLine = ERROR_LINE()
		,@errorState = ERROR_STATE()  

	EXEC app.SaveErrorLog 1, 1, 'cw.spGetECB_CPRData', @errorNumber,  @errorSeverity, @errorLine, @errorMessage  
	, 'System'  

	RAISERROR (@errorMessage,  
		 @errorSeverity,  
		 @errorState )  
	END CATCH  

END
GO
