USE [SFP_Securitisation]
GO

IF OBJECT_ID('cb.spIR_GetInterestPaymentType') IS NOT NULL
	DROP PROC cb.spIR_GetInterestPaymentType
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO


/*
 * Author: Arun
 * Date:    26.05.2020
 * Description:  This will return Inetrest Type for Investor report.
 * Usage : cb.spIR_GetInterestPaymentType @pAsAtDate  = '30-APR-2021'
 * 		,@pDealName  = 'DEIMOS'  
 * 		,@pUserName = NULL                                                  
 * Change History
 * --------------
 * Author              Date                 Description
 * -------------------------------------------------------
*/
CREATE PROC cb.spIR_GetInterestPaymentType @pAsAtDate DATE
		,@pDealName VARCHAR(255) 
		,@pUserName VARCHAR(50) = NULL  
AS
BEGIN
BEGIN TRY
	
	DECLARE @partitionID_AsAtDate INT = CONVERT(INT, CONVERT(VARCHAR(8), @pAsAtDate, 112))
	DECLARE @dealId int, @mortgageDealKey int;
	SELECT @dealId = dealId, @mortgageDealKey= MortgageDealId FROM [cw].[vw_ActiveDeal]  WHERE DealName=@pDealName
	DECLARE @totalSubAccounts float, @totalOutstandingCapitalBalance float
	, @capitalBalanceAtFlagged float
	, @mortgagedealstart DATE 
	, @dealkey INT
	, @fieldName varchar(20)= 'PRODUCT'
	
	CREATE TABLE #ProductTypeGroup(SortOrder INT IDENTITY (1,1), ProductTypeGroup varchar(255))
	CREATE TABLE #ProductType(ProductTypeId INT, Name varchar(255), ProductTypeGroup varchar(255))
	
	INSERT INTO #ProductTypeGroup (ProductTypeGroup)
	SELECT DISTINCT ReportLookupValue AS LookupValueDescription  
	FROM cfgcw.IR_AssetStratGroupingLookupData AL 
	INNER JOIN cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
	WHERE M.FieldName=@fieldName
	
	INSERT INTO #ProductType
	SELECT pt.ProductTypeId, pt.Name, AL.ReportLookupValue AS LookupValueDescription 
	FROM cfgcw.IR_AssetStratGroupingLookupData AL 
	INNER JOIN cfgCW.IR_AssetField M ON M.AssetFieldId=AL.AssetStratFieldId
	INNER JOIN sfp.syn_SfpModel_vw_ReportLookUpData_v1 L ON L.ReportTemplateName='SFP+' 
		AND L.LookupValueDescription=AL.ReportLookupName AND L.LookupName =M.FieldName
	INNER JOIN [cfgCW].[ProductType] pt ON L.LookUpValue=pt.Name 		
	WHERE M.FieldName=@fieldName


	SELECT * INTO #VwMortgageSubAccount  FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE 1<>1  
	EXEC [CW].[spCheckAndLoadMortgageFieldData] @pAsAtDate, @dealId
	INSERT INTO #VwMortgageSubAccount   
	SELECT * FROM [CW].[Syn_SfpSecuritisation_tbl_MortgageFieldData] WHERE PartitionId = @partitionID_AsAtDate AND MortgageDealKey = @mortgageDealKey

	SELECT @totalOutstandingCapitalBalance = sum(Outstandng_Capital_Balance_Amt), @totalSubAccounts = count(*)
	FROM #VwMortgageSubAccount pd
	
	SELECT ProductTypeGroup, SUM(LoanCount)  AS [MortgageLoans]
	, CASE WHEN @totalSubAccounts > 0 THEN Cast((SUM(LoanCount) / @totalSubAccounts ) AS Float)  ELSE 0 END AS TotalLoanCountPercent
	, SUM(CapitalBalanceValue) AS TotalOutstandingCapitalBalance
	, CASE WHEN @totalOutstandingCapitalBalance > 0 THEN Cast((sum(CapitalBalanceValue) / @totalOutstandingCapitalBalance ) AS Float)  ELSE 0 END AS TotalOutstandingCapitalPercent
	INTO #CrntProduct
	FROM [cw].[DealProductData] pd
	JOIN  #ProductType  pt ON pd.ProductTypeId=pt.ProductTypeId
	WHERE pd.DealId=@dealId AND CorrelatedDate=@pAsAtDate
	GROUP BY ProductTypeGroup
	
	
	---=================================================================
	
	
	
	SELECT ISNULL(P.ProductTypeGroup,'Total') AS '~HeaderText'
	,  ISNULL((SUM(CP.[MortgageLoans])),0) AS 'Number'
	,  ISNULL(CAST(SUM(CP.TotalLoanCountPercent) AS decimal(38,8)),0) AS '% of Total Number'
	,  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalBalance) AS decimal(38,2)),0) AS 'Amount (GBP)'
	,  ISNULL(CAST(SUM(CP.TotalOutstandingCapitalPercent) AS decimal(38,8)),0) AS '% of Total Amount'
     FROM #ProductTypeGroup P
     LEFT JOIN #CrntProduct CP ON CP.ProductTypeGroup = P.ProductTypeGroup
     GROUP BY P.ProductTypeGroup WITH rollup   
	 ORDER BY SUM(P.SortOrder)  
  
END TRY
BEGIN CATCH
    DECLARE 
                @errorMessage     NVARCHAR(MAX),
                @errorSeverity    INT,
                @errorNumber      INT,
                @errorLine        INT,
                @errorState       INT;

    SELECT 
                @errorMessage = ERROR_MESSAGE()
                ,@errorSeverity = ERROR_SEVERITY()
                ,@errorNumber = ERROR_NUMBER()
                ,@errorLine = ERROR_LINE()
                ,@errorState = ERROR_STATE()

    EXEC app.SaveErrorLog 1, 1, 'cb.spIR_GetInterestPaymentType', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName
    
    RAISERROR (@errorMessage,
                @errorSeverity,
                @errorState )
END CATCH			
END
			   
GO