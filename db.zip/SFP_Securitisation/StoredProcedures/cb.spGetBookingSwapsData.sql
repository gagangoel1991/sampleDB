USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cb].[spGetBookingSwapsData]') IS NOT NULL
	DROP PROCEDURE [cb].[spGetBookingSwapsData] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

--==================================  
--Author: Ravindra Singh 
--Date: 27-02-2023 
--Description: GET Booking Swap Data 
--[cb].[spGetBookingSwapsData] 6,60,''
--==================================   
CREATE PROCEDURE [cb].[spGetBookingSwapsData] 
   @pDealId INT
	,@pIPDRunId INT
	,@pUserName VARCHAR(80)      
AS  
BEGIN  
  
BEGIN TRY

SELECT * INTO #tempSwapData FROM
 (
 SELECT 
			ds.DealSwapId AS SwapId
			,cfgds.SwapName AS SwapName,
			IIF(cfgds.SwapName='Tracker','D090576691867.NW',
			IIF(cfgds.SwapName='Variable','D090576717528.NW',
			IIF(cfgds.SwapName='Fixed','D090576691399.NW',''))) AS Reference
			,'GBP' as PayCurrency
			,'GBP' as ReceiveCurrency
			,'GB81SOGE23639119016236' AS CreditAccount
			,'GB81SOGE23639119016236' AS DebitAccount
			,CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
			,IIF(ds.ReceiveAmount>ds.PayAmount,ds.ReceiveAmount-ds.PayAmount,0) AS PayAmount
			,IIF(ds.ReceiveAmount<ds.PayAmount,ds.PayAmount-ds.ReceiveAmount,0) AS ReceiveAmount,
			null as  TotalAmount
		FROM [cb].[DealSwap_Wf] ds
		JOIN [cfgcb].[DealSwap] cfgds ON cfgds.DealSwapId = ds.DealSwapId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = ds.DealipdRunid
		WHERE dir.DealIpdRunId = @pIPDRunId
	

	UNION

	SELECT nsWf.NoteswapId AS SwapId
			,dn.Name AS SwapName,
			IIF(dn.Name='Series 8','D010585414985.NW',
			IIF(dn.Name='Series 9','CBSeries9XCCY.NW','')) AS Reference
			,'EUR' as PayCurrency
			,'GBP' as ReceiveCurrency			
			,'GB81SOGE23639119016236' AS CreditAccount
			,'GB81SOGE23639119016236' AS DebitAccount
			,CONVERT(VARCHAR(10), dir.IpdDate, 103) AS IpdDate
		--	,0 as Pay1Amount
		--	,0 as ReceiveAmount
			,0 AS PayAmount
			,nsWf.PayAmount AS ReceiveAmount,
			null as  TotalAmount
		FROM cb.NoteSwap_Wf nsWf
		JOIN cfgcb.NoteSwap ns ON nsWf.NoteSwapId = ns.NoteSwapId
		JOIN cfgcb.DealNote dn ON ns.DealNoteId = dn.DealNoteId
		JOIN cw.vwDealIpdRun dir ON dir.DealIpdRunId = nsWf.DealipdRunid
		WHERE dir.DealIpdRunId = @pIPDRunId
UNION

SELECT    
          0 AS SwapId
			,'' AS SwapName,
			'D090576748545.RBK2.NW' AS Reference
			,'EUR' as PayCurrency
			,'GBP' as ReceiveCurrency			
			,'GB81SOGE23639119016236' AS CreditAccount
			,'GB81SOGE23639119016236' AS DebitAccount
			,'' AS IpdDate
		--	,0 as Pay1Amount
		--	,0 as ReceiveAmount
			,0 AS PayAmount
			,0 AS ReceiveAmount,
			null as  TotalAmount
			)t

Select * INTO #bookingSwapData FROM #tempSwapData

SELECT SwapId, SwapName, Reference, PayCurrency, ReceiveCurrency, CreditAccount, DebitAccount, IpdDate, CAST(PayAmount AS DECIMAL(38, 2)) As PayAmount
, CAST(ReceiveAmount AS DECIMAL(38, 2)) As ReceiveAmount
, CAST(TotalAmount AS DECIMAL(38, 2)) As TotalAmount FROM
(
SELECT      
			null AS SwapId
			,null AS SwapName,
			null AS Reference
			,null as PayCurrency
			,null as ReceiveCurrency
			,null AS CreditAccount
			,null AS DebitAccount
			,null AS IpdDate
			,null AS PayAmount
			,null AS ReceiveAmount,
			(SUM(ReceiveAmount) - SUM(PayAmount))
			 as TotalAmount
			 FROM  #tempSwapData
			 group by CreditAccount

UNION

select * from #bookingSwapData

)tet

order by  CASE 
	  WHEN Reference='D090576691867.NW' THEN 1 
	  WHEN Reference='D090576717528.NW' THEN 2 
	  WHEN Reference='D090576691399.NW' THEN 3
	  WHEN Reference='D090576748545.RBK2.NW' THEN 4
	  WHEN Reference='D010585414985.NW' THEN 5
	  WHEN Reference='CBSeries9XCCY.NW' THEN 6
	  
	  END


  
END TRY  
BEGIN CATCH  
	DECLARE   
		@errorMessage     NVARCHAR(MAX),  
		@errorSeverity    INT,  
		@errorNumber      INT,  
		@errorLine        INT,  
		@errorState       INT;  
  
	SELECT   
	@errorMessage = ERROR_MESSAGE()
	,@errorSeverity = ERROR_SEVERITY()
	,@errorNumber = ERROR_NUMBER()
	,@errorLine = ERROR_LINE()
	,@errorState = ERROR_STATE()  
  
	EXEC app.SaveErrorLog 1, 1, 'cw.spGetDealNoteInformation', @errorNumber,  @errorSeverity, @errorLine, @errorMessage, @pUserName  
    
	RAISERROR (@errorMessage,  
				@errorSeverity,  
             @errorState )  
END CATCH  
END
GO
