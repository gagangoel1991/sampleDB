USE SFP_Securitisation
GO

IF OBJECT_ID('[cw].[spGetWorkflowAuditData]') IS NOT NULL
	DROP PROCEDURE [cw].[spGetWorkflowAuditData]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

--==================================    
--Author: Suresh Pandey   
--Date: 07-07-2021   
--Description: Get Audit Trail of IPD workflow  
  
-- exec [cw].[spGetWorkflowAuditData] 'Automated_Data_Collection_Ledger',3,''  
--==================================     
  
CREATE PROCEDURE [cw].[spGetWorkflowAuditData]   
(
	 @pWorkflowType		VARCHAR(100),  
	 @pReferenceId		INT,  
	 @pUserName			VARCHAR(80)  
)
AS    
BEGIN    
    
	BEGIN TRY  

		IF( Object_id('tempdb..#tempReference') IS NOT NULL ) 
			DROP TABLE #tempReference 

		CREATE TABLE #tempReference(ReferenceId INT)

		INSERT INTO #tempReference(ReferenceId) VALUES(@pReferenceId)   
   
		IF @pWorkflowType IN ('Automated_Data_Daily_Collection', 'Automated_Data_Collection_Ledger', 'Automated_Data_Interest_Rates','Automated_Data_Cash_Ladder')  
		BEGIN  
			DECLARE  
				@dealId				SMALLINT,  
				@dealIpdDate		DATE,  
				@businessStartDate  DATE,  
				@businessEndDate	DATE,  
				@rateDate			DATE, 
				@dealType			VARCHAR(20),
				@currentIpdDate		DATE,
				@prevIpdDate		DATE,
				@dealRegionCode		VARCHAR(40),
				@CreatedDate		DATETIME = GETUTCDATE()  
  
			--Getting the dealid, Business Start and End Date for the speciifed run id  
			SELECT   
				@dealId = di.DealId, @dealIpdDate = did.IPD,   
				@businessStartDate = did.CollectionBusinessStart,   
				@businessEndDate = did.CollectionBusinessEnd,  
				@rateDate = did.RateResetDate,
				@currentIpdDate = did.Ipd, 
				@prevIpdDate= did.PreviousIPD,
				@dealRegionCode = deal.DealRegionCode
			FROM cw.DealIpd di  
			JOIN cw.vwDealIpdRun dir ON di.DealIpdId = dir.DealIpdId  
			JOIN cw.vw_ActiveDeal deal ON deal.DealId = dir.DealId
			JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId  
			WHERE dir.DealIpdRunId = @pReferenceId 
			
			SET @dealType =(SELECT [cw].[fnGetDealType] (@dealId))
  
			DELETE FROM #tempReference

			IF @pWorkflowType = 'Automated_Data_Daily_Collection'  
			BEGIN  
				INSERT INTO #tempReference(ReferenceId)
				SELECT DISTINCT  wfs.ProcessReferenceId FROM [cw].[vwWorkFlowLastAction] wfs  
				JOIN cw.DailyCollection_WIP wip ON wip.ProcessReferenceId = wfs.ProcessReferenceId  
				WHERE DealId = @dealId AND wfs.WorkflowTypeName = 'Automated_Data_Daily_Collection'  
				AND CollectionDate>=@businessStartDate AND CollectionDate<=@businessEndDate  
			END  
			ELSE IF @pWorkflowType = 'Automated_Data_Collection_Ledger'  
			BEGIN  
				INSERT INTO #tempReference(ReferenceId)
				SELECT DISTINCT  wfs.ProcessReferenceId FROM [cw].[vwWorkFlowLastAction] wfs  
				JOIN cw.CollectionLedger_WIP wip ON wip.ProcessReferenceId = wfs.ProcessReferenceId  
				WHERE DealId = @dealId AND wfs.WorkflowTypeName = 'Automated_Data_Collection_Ledger'  
				AND CollectionDate>=@businessStartDate AND CollectionDate<=@businessEndDate  
			END  
			ELSE IF @pWorkflowType = 'Automated_Data_Interest_Rates'  
			BEGIN  
				IF (@dealType='Covered Bond')
				BEGIN
					DECLARE
						@resetLeadDays		INT

					SELECT @resetLeadDays = CAST([Value] AS INT) FROM [cfgcb].[SoniaResetLeadDays] WHERE IsActive = 1
					SELECT @businessStartDate = [CW].[fnGetBusinessDate](@prevIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
					SELECT @businessEndDate = [CW].[fnGetBusinessDate](@currentIpdDate, @dealRegionCode, @resetLeadDays*-1, 0)
				END

				INSERT INTO #tempReference(ReferenceId)
				SELECT DISTINCT  wfs.ProcessReferenceId FROM [cw].[vwWorkFlowLastAction] wfs  
				JOIN cw.InterestRate_WIP wip ON wip.ProcessReferenceId = wfs.ProcessReferenceId  
				JOIN cw.InterestRate ir ON wip.InterestRateId = ir.InterestRateId  
				WHERE 
					wfs.WorkflowTypeName = 'Automated_Data_Interest_Rates'  
					AND
					(
						(@dealType = 'Covered Bond' AND CAST(ir.BaseDate AS DATE)>=@businessStartDate AND CAST(ir.BaseDate AS DATE)<=@businessEndDate)
						OR
						(@dealType = 'RMBS' AND (CAST(ir.BaseDate AS DATE)=CAST(@rateDate AS DATE)))
					)
			END  
			ELSE IF @pWorkflowType = 'Automated_Data_Cash_Ladder'  
			BEGIN  
				INSERT INTO #tempReference(ReferenceId)
				SELECT DISTINCT  wfs.ProcessReferenceId FROM [cw].[vwWorkFlowLastAction] wfs  
				JOIN cw.CashLadder_WIP wip ON wip.ProcessReferenceId = wfs.ProcessReferenceId  
				WHERE DealId = @dealId AND wfs.WorkflowTypeName = 'Automated_Data_Cash_Ladder'  
				AND CollectionDate>=@businessStartDate AND CollectionDate<=@businessEndDate  
			END  
		END  

		SELECT   
			CAST(ROW_NUMBER() OVER(ORDER BY wfp.ActionedDate ASC) AS INT) AS RowIndex,  
			ProcessReferenceId,   
			wfs.DisplayName AS StepName,   
			wfp.ActionedBy,   
			wfp.ActionedDate,   
			wfp.Comment   
		FROM   
			cw.workflowprocess wfp  
		JOIN   
			cfgCW.WorkflowStep wfs ON wfp.WorkflowStepId = wfs.WorkflowStepId  
		JOIN   
			cfgCW.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId  
		JOIN
			#tempReference tr  ON tr.ReferenceId=wfp.ProcessReferenceId
		WHERE   
			wft.[Name] = @pWorkflowType   
		ORDER BY   
			RowIndex DESC
      
	END TRY    
	BEGIN CATCH  
		DECLARE @errorMessage NVARCHAR(MAX) ,@errorSeverity INT ,@errorNumber INT,@errorLine INT,@errorState INT;  
		SELECT @errorMessage = ERROR_MESSAGE(),@errorSeverity = ERROR_SEVERITY(),@errorNumber = ERROR_NUMBER(),
			@errorLine = ERROR_LINE(),@errorState = ERROR_STATE()  
  
		EXEC app.SaveErrorLog 1 ,2,'spGetWorkflowAuditData',@errorNumber,@errorSeverity,@errorLine,@errorMessage,@pUserName  
  
		 RAISERROR (  
		   @errorMessage  
		   ,@errorSeverity  
		   ,@errorState  
		)  
	END CATCH	
END
GO


