USE [SFP_Securitisation]
GO
GO
GRANT SELECT ON SCHEMA::[CW] TO [sftautosys]
GRANT INSERT ON SCHEMA::[CW] TO [sftautosys]
GRANT UPDATE ON SCHEMA::[CW] TO [sftautosys]
GRANT DELETE ON SCHEMA::[CW] TO [sftautosys]
GRANT ALTER ON SCHEMA::[CW] TO [sftautosys]
GO

GRANT SELECT ON SCHEMA::[auditCW] TO [sftautosys]
GRANT INSERT ON SCHEMA::[auditCW] TO [sftautosys]
GRANT UPDATE ON SCHEMA::[auditCW] TO [sftautosys]
GRANT DELETE ON SCHEMA::[auditCW] TO [sftautosys]
GRANT ALTER ON SCHEMA::[auditCW] TO [sftautosys]
GO

GRANT SELECT ON SCHEMA::[cfgCW] TO [sftautosys]
GRANT INSERT ON SCHEMA::[cfgCW] TO [sftautosys]
GRANT UPDATE ON SCHEMA::[cfgCW] TO [sftautosys]
GRANT DELETE ON SCHEMA::[cfgCW] TO [sftautosys]
GRANT ALTER ON SCHEMA::[cfgCW] TO [sftautosys]
GO

GRANT SELECT ON SCHEMA::app TO [sftautosys]
GRANT INSERT ON SCHEMA::app TO [sftautosys]
GRANT UPDATE ON SCHEMA::app TO [sftautosys]
GRANT DELETE ON SCHEMA::app TO [sftautosys]
GRANT ALTER ON SCHEMA::app TO [sftautosys]
GO

GRANT SELECT ON SCHEMA::cfg TO [sftautosys]
GRANT INSERT ON SCHEMA::cfg TO [sftautosys]
GRANT UPDATE ON SCHEMA::cfg TO [sftautosys]
GRANT DELETE ON SCHEMA::cfg TO [sftautosys]
GRANT ALTER ON SCHEMA::cfg TO [sftautosys]
GO

GRANT SELECT ON SCHEMA::sfp TO [sftautosys]
GRANT INSERT ON SCHEMA::sfp TO [sftautosys]
GRANT UPDATE ON SCHEMA::sfp TO [sftautosys]
GRANT DELETE ON SCHEMA::sfp TO [sftautosys]
GRANT ALTER ON SCHEMA::sfp TO [sftautosys]
GO

GRANT SELECT ON [app].[ErrorLog] TO [sftautosys]
GRANT INSERT ON [app].[ErrorLog] TO [sftautosys]
GRANT UPDATE ON [app].[ErrorLog] TO [sftautosys]
GRANT DELETE ON [app].[ErrorLog] TO [sftautosys]
GRANT ALL ON [app].[ErrorLog] TO [sftautosys]
GO
GRANT SELECT ON [app].[Module] TO [sftautosys]
GRANT SELECT ON [app].[LogOriginType] TO [sftautosys]

GRANT SELECT ON cw.feedRunLog TO [sftautosys]
GRANT INSERT ON cw.feedRunLog TO [sftautosys]
GRANT UPDATE ON cw.feedRunLog TO [sftautosys]
GRANT DELETE ON cw.feedRunLog TO [sftautosys]
GRANT ALL ON [cw].[feedRunLog] TO [sftautosys]
GO
GRANT SELECT ON cfgCW.FeedStage TO [sftautosys]
GRANT ALL ON [cw].[feedRunLog] TO [sftautosys]
GO

GRANT SELECT ON cfgCW.FeedDealMap TO [sftautosys]
GRANT ALL ON [cfgCW].[FeedDealMap] TO [sftautosys]
GO

GRANT SELECT ON cfgCW.SourceSystemFeed TO [sftautosys]
GRANT ALL ON [cfgCW].[SourceSystemFeed] TO [sftautosys]
GO

GRANT SELECT ON cfgCW.SourceSystem TO [sftautosys]
GRANT ALL ON [cfgCW].[SourceSystem] TO [sftautosys]
GO

GRANT SELECT ON cfgCW.StormBrandMap TO [sftautosys]
GRANT ALL ON [cfgCW].[StormBrandMap] TO [sftautosys]
GO

GRANT SELECT ON cfgCW.DealBrand TO [sftautosys]
GRANT ALL ON [cfgCW].[DealBrand] TO [sftautosys]
GO

GRANT SELECT ON cfg.deal TO [sftautosys]
GRANT SELECT ON cfgCW.CashWaterfallDeal TO [sftautosys]
GO

GRANT SELECT ON cfgCW.RatingType TO [sftautosys]
GO

GRANT SELECT ON cfgCW.CreditRatingAgency TO [sftautosys]
GO

GRANT SELECT ON cfgCW.Currency TO [sftautosys]
GO

GRANT SELECT ON cfgCW.DealLookupValue TO [sftautosys]
GO

GRANT SELECT ON cfgCW.DealLookupType TO [sftautosys]
GO

GRANT SELECT ON [cw].[VW_ACTIVEdEAL] TO [sftautosys]
GRANT SELECT ON [cw].[vw_ActiveDealCounterparty] TO [sftautosys]
GRANT SELECT ON cw.vw_ActiveCounterpartyRatingStg TO [sftautosys]
GRANT ALL ON cw.[fnGetISINList] TO [sftautosys]
GO
GRANT EXECUTE ON cw.[fnGetISINList]  TO [sftautosys]

------------------------------Permission fro Cash Ladder and Collection Ledger------------------------

GRANT SELECT ON [CW].[CashLadder] TO [sftautosys]
GRANT INSERT ON [CW].[CashLadder] TO [sftautosys]
GRANT UPDATE ON [CW].[CashLadder] TO [sftautosys]
GRANT DELETE ON [CW].[CashLadder] TO [sftautosys]
go
GRANT SELECT ON [auditCW].[CashLadder] TO [sftautosys]
GRANT INSERT ON [auditCW].[CashLadder] TO [sftautosys]
GRANT UPDATE ON [auditCW].[CashLadder] TO [sftautosys]
GRANT DELETE ON [auditCW].[CashLadder] TO [sftautosys]
GO
GRANT SELECT ON [CW].[CollectionLedger] TO [sftautosys]
GRANT INSERT ON [CW].[CollectionLedger] TO [sftautosys]
GRANT UPDATE ON [CW].[CollectionLedger] TO [sftautosys]
GRANT DELETE ON [CW].[CollectionLedger] TO [sftautosys]
go
GRANT SELECT ON [auditCW].[CollectionLedger] TO [sftautosys]
GRANT INSERT ON [auditCW].[CollectionLedger] TO [sftautosys]
GRANT UPDATE ON [auditCW].[CollectionLedger] TO [sftautosys]
GRANT DELETE ON [auditCW].[CollectionLedger] TO [sftautosys]
GO
GRANT EXECUTE ON cw.spInsertFeedRunLog TO [sftautosys]
GO
GRANT EXECUTE ON cw.spUpdateFeedRunLog TO [sftautosys]
GO
GRANT EXECUTE ON app.SaveErrorLog TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadCashLadderData] TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadCollectionLedgerData] TO [sftautosys]
GO
GRANT SELECT ON [cw].[Syn_SfpStaging_tbl_CashLadder] TO [sftautosys]
GO
GRANT SELECT ON [cw].[Syn_SfpStaging_tbl_CollectionLedger] TO [sftautosys]
GO
-----------------------------Permission for Counterparty Rating-------------------------------------
GO
GRANT SELECT ON [cw].[SourceCounterpartyRating] TO [sftautosys]
GRANT UPDATE ON [cw].[SourceCounterpartyRating] TO [sftautosys]
GRANT DELETE ON [cw].[SourceCounterpartyRating] TO [sftautosys]
GRANT INSERT ON [cw].[SourceCounterpartyRating] TO [sftautosys]
GO
GO
GRANT SELECT ON [auditCW].[SourceCounterpartyRating] TO [sftautosys]
GRANT UPDATE ON [auditCW].[SourceCounterpartyRating] TO [sftautosys]
GRANT DELETE ON [auditCW].[SourceCounterpartyRating] TO [sftautosys]
GRANT INSERT ON [auditCW].[SourceCounterpartyRating] TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadCounterpartyRatingData] TO [sftautosys]
GO
GRANT SELECT ON cw.Syn_SfpStaging_tbl_CounterpartyRating TO [sftautosys]
GO
---------------------------Permission for FX Rate----------------------------------------------------
GO
GRANT SELECT ON [auditCW].[FXRate] TO [sftautosys]
GRANT UPDATE ON [auditCW].[FXRate] TO [sftautosys]
GRANT DELETE ON [auditCW].[FXRate] TO [sftautosys]
GRANT INSERT ON [auditCW].[FXRate] TO [sftautosys]
GRANT ALL ON    [auditCW].[FXRate] TO [sftautosys]
GO
GRANT SELECT ON [CW].[FXRate] TO [sftautosys]
GRANT UPDATE ON [CW].[FXRate] TO [sftautosys]
GRANT DELETE ON [CW].[FXRate] TO [sftautosys]
GRANT INSERT ON [CW].[FXRate] TO [sftautosys]
GRANT ALL ON    [CW].[FXRate] TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadFXRateData] TO [sftautosys]
GO
GRANT SELECT ON cw.Syn_SfpStaging_tbl_FXRate TO [sftautosys]
GO

------------------------Permission for Bond Rating-------------------------------------------------
GO
GRANT SELECT ON [auditCW].[SourceBondRating] TO [sftautosys]
GRANT UPDATE ON [auditCW].[SourceBondRating] TO [sftautosys]
GRANT DELETE ON [auditCW].[SourceBondRating] TO [sftautosys]
GRANT INSERT ON [auditCW].[SourceBondRating] TO [sftautosys]
GRANT ALL ON    [auditCW].[SourceBondRating] TO [sftautosys]
GO
GRANT SELECT ON [CW].[SourceBondRating] TO [sftautosys]
GRANT UPDATE ON [CW].[SourceBondRating] TO [sftautosys]
GRANT DELETE ON [CW].[SourceBondRating] TO [sftautosys]
GRANT INSERT ON [CW].[SourceBondRating] TO [sftautosys]
GRANT ALL ON    [CW].[SourceBondRating] TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadBondRatingData] TO [sftautosys]
GO
GRANT SELECT ON [cw].[Syn_SfpStaging_tbl_BondRating] TO [sftautosys]
GO

------------------------Permission for Bond Rating-------------------------------------------------
GO
GRANT SELECT ON [auditCW].[InterestRate] TO [sftautosys]
GRANT UPDATE ON [auditCW].[InterestRate] TO [sftautosys]
GRANT DELETE ON [auditCW].[InterestRate] TO [sftautosys]
GRANT INSERT ON [auditCW].[InterestRate] TO [sftautosys]
GRANT ALL ON    [auditCW].[InterestRate] TO [sftautosys]
GO
GRANT SELECT ON [CW].[InterestRate] TO [sftautosys]
GRANT UPDATE ON [CW].[InterestRate] TO [sftautosys]
GRANT DELETE ON [CW].[InterestRate] TO [sftautosys]
GRANT INSERT ON [CW].[InterestRate] TO [sftautosys]
GRANT ALL ON    [CW].[InterestRate] TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadInterestRateData] TO [sftautosys]
GO
GRANT SELECT ON cw.Syn_SfpStaging_tbl_InterestRate  TO [sftautosys]
GO

-----------------------------Permission for Nucleus Counterparty Feed--------------------------
GRANT SELECT ON cw.Counterparty TO [sftautosys]
GRANT INSERT ON cw.Counterparty TO [sftautosys]
GRANT UPDATE ON cw.Counterparty TO [sftautosys]
GRANT DELETE ON cw.Counterparty TO [sftautosys]
GRANT ALL ON cw.Counterparty TO [sftautosys]

GRANT SELECT ON auditCW.Counterparty TO [sftautosys]
GRANT INSERT ON auditCW.Counterparty TO [sftautosys]
GRANT UPDATE ON auditCW.Counterparty TO [sftautosys]
GRANT DELETE ON auditCW.Counterparty TO [sftautosys]
GRANT ALL ON auditCW.Counterparty TO [sftautosys]

GRANT EXECUTE ON [cw].[spLoadnTransformCounterpartyData] TO [sftautosys]

GRANT SELECT ON [cw].[syn_SfpStaging_tbl_NucleusCounterparty] TO [sftautosys]
GO

-----------------------Permission for Daily Collection--------------------------------------------
GRANT SELECT ON [cw].[DailyCollection] TO [sftautosys]
GRANT UPDATE ON [cw].[DailyCollection] TO [sftautosys]
GRANT INSERT ON [cw].[DailyCollection] TO [sftautosys]
GRANT DELETE ON [cw].[DailyCollection] TO [sftautosys]
GRANT ALL ON [cw].[DailyCollection] TO [sftautosys]
GO
GRANT SELECT ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT UPDATE ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT INSERT ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT DELETE ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT ALL ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GO
GRANT SELECT ON [cfgCW].[DailyCollectionField] TO [sftautosys]
GO
GRANT SELECT ON [AUDITcw].[DailyCollection] TO [sftautosys]
GRANT INSERT ON [AUDITcw].[DailyCollection] TO [sftautosys]
GRANT UPDATE ON [AUDITcw].[DailyCollection] TO [sftautosys]
GRANT DELETE ON [AUDITcw].[DailyCollection] TO [sftautosys]
GRANT ALL ON [AUDITcw].[DailyCollection] TO [sftautosys]
GO
GRANT EXECUTE ON [cw].[spLoadMortgageDailyCollection] TO [sftautosys]
GRANT EXECUTE ON [cw].[spTransformMortgageDailyCollection] TO [sftautosys]
GO

-----------------------Permission for Monthly Aggregated Data --------------------------------------
GRANT SELECT ON [cw].[DealAggregatedData] TO [sftautosys]
GRANT UPDATE ON [cw].[DealAggregatedData] TO [sftautosys]
GRANT INSERT ON [cw].[DealAggregatedData] TO [sftautosys]
GRANT DELETE ON [cw].[DealAggregatedData] TO [sftautosys]
GRANT ALL ON [cw].[DealAggregatedData] TO [sftautosys]
GO

GRANT SELECT ON [cfgCW].[DealAggregatedField] TO [sftautosys]
GO

GRANT SELECT ON [auditCW].[DealAggregatedData] TO [sftautosys]
GRANT INSERT ON [auditCW].[DealAggregatedData] TO [sftautosys]
GRANT UPDATE ON [auditCW].[DealAggregatedData] TO [sftautosys]
GRANT DELETE ON [auditCW].[DealAggregatedData] TO [sftautosys]
GRANT ALL ON [auditCW].[DealAggregatedData] TO [sftautosys]
GO

GRANT SELECT ON [cw].[DealAggregatedDataStg] TO [sftautosys]
GRANT INSERT ON [cw].[DealAggregatedDataStg] TO [sftautosys]
GRANT UPDATE ON [cw].[DealAggregatedDataStg] TO [sftautosys]
GRANT DELETE ON [cw].[DealAggregatedDataStg] TO [sftautosys]
GRANT ALL ON [cw].[DealAggregatedDataStg] TO [sftautosys]
GO

GRANT SELECT ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT INSERT ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT UPDATE ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT DELETE ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GRANT ALL ON [cw].[MortgageCollectionExtractStg] TO [sftautosys]
GO

GRANT EXECUTE ON [cw].[spLoadMonthlyDealAggregatedData] TO [sftautosys]
GRANT EXECUTE ON [cw].[spTransformMonthlyDealAggregatedData] TO [sftautosys]
GO
GRANT SELECT ON [cfgCW].[DealNote] TO [sftautosys]
GRANT SELECT ON [cfgCW].[DealCounterparty] TO [sftautosys]
GO
GRANT SELECT ON [cfgCW].[RequestDetail] TO [sftautosys]
GO

GRANT SELECT ON [cw].[DealProductData] TO [sftautosys]
GRANT INSERT ON [cw].[DealProductData] TO [sftautosys]
GRANT UPDATE ON [cw].[DealProductData] TO [sftautosys]
GRANT DELETE ON [cw].[DealProductData] TO [sftautosys]
GRANT ALL ON [cw].[DealProductData] TO [sftautosys]
GO
GRANT SELECT ON [cw].[DealProductSwitchData] TO [sftautosys]
GRANT INSERT ON [cw].[DealProductSwitchData] TO [sftautosys]
GRANT UPDATE ON [cw].[DealProductSwitchData] TO [sftautosys]
GRANT DELETE ON [cw].[DealProductSwitchData] TO [sftautosys]
GRANT ALL ON [cw].[DealProductSwitchData] TO [sftautosys]
GO
GRANT SELECT ON [cfgCW].[ProductSwitchType] TO [sftautosys]
GO
GRANT SELECT ON [cfgCW].[ProductRateOfInterestType] TO [sftautosys]
GO
GRANT SELECT ON [cfgCW].[ProductType] TO [sftautosys]

GRANT EXECUTE ON [cw].[spLoadDealProductnSwitchData] TO [sftautosys]
GO
--------------------------------Permission for Other Sysnonyms ----------------------------------------
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Dim_Calendar] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Dim_Brand] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Dim_MortgageAssetSubPool] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Fact_MortgageSubAccount] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Dim_mortgagedeal] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Fact_MortgageSubAccountSecTransaction] TO [sftautosys]
GRANT SELECT ON [sfp].[syn_SfpModel_tbl_Fact_MortgageSubAccountSecTransactionSummary]  TO [sftautosys]
GO
-----------
