USE [SFP_Securitisation]
GO

GRANT SELECT ON SCHEMA::[PS] TO [sftautosys]
GRANT UPDATE ON SCHEMA::[PS] TO [sftautosys]
GO

GRANT SELECT ON [ps].[vwHypoPool] TO [sftautosys]
GRANT UPDATE ON [ps].[vwHypoPool] TO [sftautosys]
GO

IF (EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = 'sfp_app_ssrs' AND [type] = 'R'))
BEGIN
	GRANT SELECT ON [ps].[vw_Pool] TO [sfp_app_ssrs];
	GRANT SELECT ON [ps].[vw_PoolLoans] TO [sfp_app_ssrs];
END
GO