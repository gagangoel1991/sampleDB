USE [SFP_Securitisation]
GO

IF (NOT EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = 'sfp_web_svc' AND [type] = 'R'))
BEGIN
	CREATE ROLE [sfp_web_svc] AUTHORIZATION [dbo];
END

GRANT SELECT, EXECUTE, INSERT ON SCHEMA :: [app] TO [sfp_web_svc]
GO

GRANT SELECT, EXECUTE, INSERT, DELETE, UPDATE ON SCHEMA :: [ps] TO [sfp_web_svc] 
GO

GRANT SELECT, EXECUTE, INSERT, DELETE, UPDATE ON SCHEMA :: [sfp] TO [sfp_web_svc]
GO

GRANT SELECT, INSERT ON SCHEMA :: [auditCW] TO [sfp_web_svc]
GO

GRANT SELECT, EXECUTE, INSERT, DELETE, UPDATE ON SCHEMA :: [cfg] TO [sfp_web_svc] 
GO

GRANT SELECT, EXECUTE, INSERT, DELETE, UPDATE ON SCHEMA :: [cw] TO [sfp_web_svc] 
GO

GRANT SELECT, EXECUTE, INSERT, DELETE, UPDATE ON SCHEMA :: [cfgCW] TO [sfp_web_svc] 

GO

USE [SFP_Model]
GO

IF (NOT EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = 'sfp_web_svc' AND [type] = 'R'))
BEGIN
	CREATE ROLE [sfp_web_svc] AUTHORIZATION [dbo];
END

GRANT SELECT, EXECUTE ON SCHEMA :: [rpt] TO [sfp_web_svc] 
GO

GRANT EXECUTE ON SCHEMA :: [dm] TO [sfp_web_svc] 
GO

GRANT SELECT, EXECUTE ON SCHEMA :: [dbo] TO [sfp_web_svc] 
GO


USE [SFP_MODEL_CORPORATE]
GO

IF (NOT EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = 'sfp_web_svc' AND [type] = 'R'))
BEGIN
	CREATE ROLE [sfp_web_svc] AUTHORIZATION [dbo];
END

GRANT INSERT ON SCHEMA::[DW] TO [sfp_web_svc]
GO


USE [SFP_Staging]
GO

IF (NOT EXISTS (SELECT 1 FROM [sys].[database_principals] WHERE [name] = 'sfp_web_svc' AND [type] = 'R'))
BEGIN
	CREATE ROLE [sfp_web_svc] AUTHORIZATION [dbo];
END
GRANT  SELECT, EXECUTE, INSERT, DELETE, UPDATE ON SCHEMA :: [stage] TO [sfp_web_svc] 
GO 