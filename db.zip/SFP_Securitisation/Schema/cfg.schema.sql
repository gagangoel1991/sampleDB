USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'cfg')
BEGIN
	EXEC('CREATE SCHEMA cfg')
END
GO