USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'rpt')
BEGIN
	EXEC('CREATE SCHEMA rpt')
END
GO