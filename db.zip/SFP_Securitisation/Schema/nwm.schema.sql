USE [SFP_Securitisation]
GO

GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'nwm')
BEGIN
	EXEC('CREATE SCHEMA nwm')
END
GO