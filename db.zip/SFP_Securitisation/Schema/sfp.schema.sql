USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'sfp')
BEGIN
	EXEC('CREATE SCHEMA sfp')
END
GO