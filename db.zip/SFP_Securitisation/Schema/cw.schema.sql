USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'cw')
BEGIN
	EXEC('CREATE SCHEMA cw')
END
GO