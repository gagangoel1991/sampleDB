USE [SFP_Securitisation]
GO
/****** Object:  Schema [auditPS]    Script Date: 10/07/2020 16:48:04 ******/


IF NOT EXISTS ( SELECT  *
                FROM    sys.schemas
                WHERE   name = N'auditPS' )
    EXEC('CREATE SCHEMA [auditPS]');
GO

