USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT 1 FROM sys.schemas WHERE name = 'archivePS')
BEGIN
	EXEC('CREATE SCHEMA archivePS')
END
GO