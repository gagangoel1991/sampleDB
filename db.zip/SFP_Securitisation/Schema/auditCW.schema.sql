USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'auditCW')
BEGIN
	EXEC('CREATE SCHEMA auditCW')
END
GO