USE [SFP_Securitisation]
GO
IF NOT EXISTS (SELECT * FROM sys.schemas WHERE name = 'cfgCW')
BEGIN
	EXEC('CREATE SCHEMA cfgCW')
END
GO