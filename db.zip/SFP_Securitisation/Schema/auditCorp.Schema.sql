USE [SFP_Securitisation]
GO

IF NOT EXISTS ( SELECT  1 FROM  sys.schemas WHERE   name = N'auditCorp' )
	
	EXEC('CREATE SCHEMA [auditCorp]');
	
GO
