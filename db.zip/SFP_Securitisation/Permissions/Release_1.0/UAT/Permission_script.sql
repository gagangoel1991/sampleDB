USE [SFP_Securitisation]
GO
DECLARE
	@serviceAccount		VARCHAR(100)
	
SET @serviceAccount = '[FM\sca-sftautosysuat]'

EXEC ('Grant select On Schema::[CW]  To ' + @serviceAccount)
EXEC ('Grant insert On Schema::[CW]  To ' + @serviceAccount)
EXEC ('Grant update On Schema::[CW]  To ' + @serviceAccount)
EXEC ('Grant delete On Schema::[CW]  To ' + @serviceAccount)
EXEC ('Grant alter On Schema::[CW]  To ' + @serviceAccount)

EXEC ('Grant select On Schema::[auditCW]  To ' + @serviceAccount)
EXEC ('Grant insert On Schema::[auditCW]  To ' + @serviceAccount)
EXEC ('Grant update On Schema::[auditCW]  To ' + @serviceAccount)
EXEC ('Grant delete On Schema::[auditCW]  To ' + @serviceAccount)
EXEC ('Grant alter On Schema::[auditCW]  To ' + @serviceAccount)

EXEC ('Grant select On Schema::[cfgCW]  To ' + @serviceAccount)
EXEC ('Grant insert On Schema::[cfgCW]  To ' + @serviceAccount)
EXEC ('Grant update On Schema::[cfgCW]  To ' + @serviceAccount)
EXEC ('Grant delete On Schema::[cfgCW]  To ' + @serviceAccount)
EXEC ('Grant alter On Schema::[cfgCW]  To ' + @serviceAccount)

EXEC ('Grant select On Schema::app  To ' + @serviceAccount)
EXEC ('Grant insert On Schema::app  To ' + @serviceAccount)
EXEC ('Grant update On Schema::app  To ' + @serviceAccount)
EXEC ('Grant delete On Schema::app  To ' + @serviceAccount)
EXEC ('Grant alter On Schema::app  To ' + @serviceAccount)

EXEC ('Grant select On Schema::cfg  To ' + @serviceAccount)
EXEC ('Grant insert On Schema::cfg  To ' + @serviceAccount)
EXEC ('Grant update On Schema::cfg  To ' + @serviceAccount)
EXEC ('Grant delete On Schema::cfg  To ' + @serviceAccount)
EXEC ('Grant alter On Schema::cfg  To ' + @serviceAccount)

EXEC ('Grant select On Schema::sfp  To ' + @serviceAccount)
EXEC ('Grant insert On Schema::sfp  To ' + @serviceAccount)
EXEC ('Grant update On Schema::sfp  To ' + @serviceAccount)
EXEC ('Grant delete On Schema::sfp  To ' + @serviceAccount)
EXEC ('Grant alter On Schema::sfp  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [app].[ErrorLog]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [app].[ErrorLog]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [app].[ErrorLog]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [app].[ErrorLog]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [app].[ErrorLog]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [app].[Module]  To ' + @serviceAccount)
EXEC ('Grant SELECT ON [app].[LogOriginType]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cw.feedRunLog  To ' + @serviceAccount)
EXEC ('Grant INSERT ON cw.feedRunLog  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON cw.feedRunLog  To ' + @serviceAccount)
EXEC ('Grant DELETE ON cw.feedRunLog  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[feedRunLog]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.FeedStage  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[feedRunLog]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.FeedDealMap  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cfgCW].[FeedDealMap]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.SourceSystemFeed  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cfgCW].[SourceSystemFeed]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.SourceSystem  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cfgCW].[SourceSystem]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.StormBrandMap  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cfgCW].[StormBrandMap]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.DealBrand  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cfgCW].[DealBrand]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfg.deal  To ' + @serviceAccount)
EXEC ('Grant SELECT ON cfgCW.CashWaterfallDeal  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.RatingType  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.CreditRatingAgency  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.Currency  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.DealLookupValue  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cfgCW.DealLookupType  To ' + @serviceAccount)

EXEC ('Grant SELECT on [cw].[VW_ACTIVEdEAL]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [cw].[vw_ActiveDealCounterparty]  To ' + @serviceAccount)
EXEC ('Grant SELECT ON cw.vw_ActiveCounterpartyRatingStg  To ' + @serviceAccount)
EXEC ('Grant All on cw.[fnGetISINList]  To ' + @serviceAccount)
EXEC ('Grant execute on cw.[fnGetISINList]   To ' + @serviceAccount)

------------------------------Permission fro Cash Ladder and Collection Ledger------------------------

EXEC ('Grant select on [CW].[CashLadder]  To ' + @serviceAccount)
EXEC ('Grant insert on [CW].[CashLadder]  To ' + @serviceAccount)
EXEC ('Grant update on [CW].[CashLadder]  To ' + @serviceAccount)
EXEC ('Grant delete on [CW].[CashLadder]  To ' + @serviceAccount)

EXEC ('Grant select on [auditCW].[CashLadder]  To ' + @serviceAccount)
EXEC ('Grant insert on [auditCW].[CashLadder]  To ' + @serviceAccount)
EXEC ('Grant update on [auditCW].[CashLadder]  To ' + @serviceAccount)
EXEC ('Grant delete on [auditCW].[CashLadder]  To ' + @serviceAccount)

EXEC ('Grant select on [CW].[CollectionLedger]  To ' + @serviceAccount)
EXEC ('Grant insert on [CW].[CollectionLedger]  To ' + @serviceAccount)
EXEC ('Grant update on [CW].[CollectionLedger]  To ' + @serviceAccount)
EXEC ('Grant delete on [CW].[CollectionLedger]  To ' + @serviceAccount)

EXEC ('Grant select on [auditCW].[CollectionLedger]  To ' + @serviceAccount)
EXEC ('Grant insert on [auditCW].[CollectionLedger]  To ' + @serviceAccount)
EXEC ('Grant update on [auditCW].[CollectionLedger]  To ' + @serviceAccount)
EXEC ('Grant delete on [auditCW].[CollectionLedger]  To ' + @serviceAccount)

EXEC ('Grant execute on cw.spInsertFeedRunLog  To ' + @serviceAccount)

EXEC ('Grant execute on cw.spUpdateFeedRunLog  To ' + @serviceAccount)

EXEC ('Grant execute on app.SaveErrorLog  To ' + @serviceAccount)

EXEC ('Grant execute on [cw].[spLoadCashLadderData]  To ' + @serviceAccount)

EXEC ('Grant execute on [cw].[spLoadCollectionLedgerData]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [cw].[Syn_SfpStaging_tbl_CashLadder]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [cw].[Syn_SfpStaging_tbl_CollectionLedger]  To ' + @serviceAccount)

-----------------------------Permission for Counterparty Rating-------------------------------------

EXEC ('Grant SELECT ON [cw].[SourceCounterpartyRating]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [cw].[SourceCounterpartyRating]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [cw].[SourceCounterpartyRating]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [cw].[SourceCounterpartyRating]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [auditCW].[SourceCounterpartyRating]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [auditCW].[SourceCounterpartyRating]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [auditCW].[SourceCounterpartyRating]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [auditCW].[SourceCounterpartyRating]  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadCounterpartyRatingData]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cw.Syn_SfpStaging_tbl_CounterpartyRating  To ' + @serviceAccount)

---------------------------Permission for FX Rate----------------------------------------------------

EXEC ('Grant SELECT ON [auditCW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [auditCW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [auditCW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [auditCW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant ALL ON    [auditCW].[FXRate]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [CW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [CW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [CW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [CW].[FXRate]  To ' + @serviceAccount)
EXEC ('Grant ALL ON    [CW].[FXRate]  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadFXRateData]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON cw.Syn_SfpStaging_tbl_FXRate  To ' + @serviceAccount)

------------------------Permission for Bond Rating-------------------------------------------------

EXEC ('Grant SELECT ON [auditCW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [auditCW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [auditCW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [auditCW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant ALL ON    [auditCW].[SourceBondRating]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [CW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [CW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [CW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [CW].[SourceBondRating]  To ' + @serviceAccount)
EXEC ('Grant ALL ON    [CW].[SourceBondRating]  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadBondRatingData]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [cw].[Syn_SfpStaging_tbl_BondRating]  To ' + @serviceAccount)

------------------------Permission for Bond Rating-------------------------------------------------
EXEC ('Grant SELECT ON [auditCW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [auditCW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [auditCW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [auditCW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant ALL ON    [auditCW].[InterestRate]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [CW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON [CW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant DELETE ON [CW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant INSERT ON [CW].[InterestRate]  To ' + @serviceAccount)
EXEC ('Grant ALL ON    [CW].[InterestRate]  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadInterestRateData]  To ' + @serviceAccount)

EXEC ('Grant SELECT on cw.Syn_SfpStaging_tbl_InterestRate   To ' + @serviceAccount)


-----------------------------Permission for Nucleus Counterparty Feed--------------------------
EXEC ('Grant SELECT ON cw.Counterparty  To ' + @serviceAccount)
EXEC ('Grant INSERT ON cw.Counterparty  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON cw.Counterparty  To ' + @serviceAccount)
EXEC ('Grant DELETE ON cw.Counterparty  To ' + @serviceAccount)
EXEC ('Grant ALL ON cw.Counterparty  To ' + @serviceAccount)

EXEC ('Grant SELECT ON auditCW.Counterparty  To ' + @serviceAccount)
EXEC ('Grant INSERT ON auditCW.Counterparty  To ' + @serviceAccount)
EXEC ('Grant UPDATE ON auditCW.Counterparty  To ' + @serviceAccount)
EXEC ('Grant DELETE ON auditCW.Counterparty  To ' + @serviceAccount)
EXEC ('Grant ALL ON auditCW.Counterparty  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadnTransformCounterpartyData]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [cw].[syn_SfpStaging_tbl_NucleusCounterparty]  To ' + @serviceAccount)


-----------------------Permission for Daily Collection--------------------------------------------
EXEC ('Grant SELECT on [cw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [cw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [cw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [cw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[DailyCollection]  To ' + @serviceAccount)

EXEC ('Grant SELECT on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)

EXEC ('Grant SELECT on [cfgCW].[DailyCollectionField]  To ' + @serviceAccount)

EXEC ('Grant SELECT on [AUDITcw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [AUDITcw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [AUDITcw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [AUDITcw].[DailyCollection]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [AUDITcw].[DailyCollection]  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadMortgageDailyCollection]  To ' + @serviceAccount)
EXEC ('Grant EXECUTE ON [cw].[spTransformMortgageDailyCollection]  To ' + @serviceAccount)


-----------------------Permission for Monthly Aggregated Data --------------------------------------
EXEC ('Grant SELECT on [cw].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [cw].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [cw].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [cw].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[DealAggregatedData]  To ' + @serviceAccount)


EXEC ('Grant SELECT on [cfgCW].[DealAggregatedField]  To ' + @serviceAccount)


EXEC ('Grant SELECT on [auditCW].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [auditCW].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [auditCW].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [auditCW].[DealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [auditCW].[DealAggregatedData]  To ' + @serviceAccount)


EXEC ('Grant SELECT on [cw].[DealAggregatedDataStg]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [cw].[DealAggregatedDataStg]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [cw].[DealAggregatedDataStg]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [cw].[DealAggregatedDataStg]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[DealAggregatedDataStg]  To ' + @serviceAccount)

EXEC ('Grant SELECT on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant INSERT on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant UPDATE on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant DELETE on [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)
EXEC ('Grant ALL ON [cw].[MortgageCollectionExtractStg]  To ' + @serviceAccount)

EXEC ('Grant EXECUTE ON [cw].[spLoadMonthlyDealAggregatedData]  To ' + @serviceAccount)
EXEC ('Grant EXECUTE ON [cw].[spTransformMonthlyDealAggregatedData]  To ' + @serviceAccount)

EXEC ('Grant SELECT on [cfgCW].[DealNote]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [cfgCW].[DealCounterparty]  To ' + @serviceAccount)

EXEC ('Grant SELECT ON [cfgCW].[RequestDetail]  To ' + @serviceAccount)

--------------------------------Permission for Other Sysnonyms ----------------------------------------
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Dim_Calendar]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Dim_Brand]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Fact_MortgageAssetPool]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Dim_MortgageAssetSubPool]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Fact_MortgageSubAccount]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Dim_MortgageSubAccount]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Dim_mortgagedeal]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Fact_MortgageSubAccountSecTransaction]  To ' + @serviceAccount)
EXEC ('Grant SELECT on [sfp].[syn_SfpModel_tbl_Fact_MortgageSubAccountSecTransactionSummary]   To ' + @serviceAccount)

-----------