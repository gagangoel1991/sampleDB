USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetNoteISINRating') IS NOT NULL
	DROP FUNCTION [cw].[fnGetNoteISINRating]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Kapil Sharma
 * Created Date	: 02-07-2021    
 * Description		: For fetching the NOTE ISIN rating
*/    
CREATE FUNCTION [cw].[fnGetNoteISINRating]
(
	@pDealId			SMALLINT,
	@pISIN				VARCHAR(40), 
	@pRatingTypeId		TINYINT,
	@pRatingDate		DATE = NULL --Rating date will be null if Original rating is required
)
 RETURNS VARCHAR(400)   
AS      
BEGIN   
    DECLARE  @tblRatingData TABLE 
    (
        Rating		VARCHAR(100)
    )  

     DECLARE  
		@rating			VARCHAR(400)

	IF @pRatingDate IS NOT NULL
	BEGIN
		INSERT INTO @tblRatingData
		SELECT br.Rating AS ThresholdRating  FROM [cw].[vwBondRating] br
		JOIN cfgcw.CreditRatingAgency cra ON cra.CRAId = br.CRAId
		JOIN cfgcw.RatingType rt ON rt.RatingTypeId = br.RatingTypeId
		JOIN cfgCW.DealSubjectCRAMap craMap ON craMap.CRAId = cra.CRAId AND craMap.DealSubjectTypeId = 1 --Notes
		WHERE 
			craMap.DealId = @pDealId AND rt.RatingTypeId = @pRatingTypeId
			AND br.RatingDate = @pRatingDate
			AND br.ISIN = @pISIN
	END
	ELSE
	BEGIN
		
		IF @pDealId= 6 -- DEIMOS DEAL
		BEGIN
			INSERT INTO @tblRatingData
			SELECT dsir.Rating AS ThresholdRating  FROM [cfgcw].[DealSubjectInitialRating] dsir
			JOIN [cfgcb].[DealNote] dn ON dn.DealNoteId = dsir.DealSubjectId AND dsir.DealId = dn.DealId
			JOIN cfgcw.CreditRatingAgency cra ON cra.CRAId = dsir.CRAId
			JOIN cfgcw.RatingType rt ON rt.RatingTypeId = dsir.RatingTypeId
			WHERE 
				dsir.DealId = @pDealId 
				AND rt.RatingTypeId = @pRatingTypeId
				AND dn.ISIN = @pISIN
		END
		ELSE
		BEGIN
			INSERT INTO @tblRatingData
			SELECT dsir.Rating AS ThresholdRating  FROM [cfgcw].[DealSubjectInitialRating] dsir
			JOIN cfgcw.DealNote dn ON dn.DealNoteId = dsir.DealSubjectId AND dsir.DealId = dn.DealId
			JOIN cfgcw.CreditRatingAgency cra ON cra.CRAId = dsir.CRAId
			JOIN cfgcw.RatingType rt ON rt.RatingTypeId = dsir.RatingTypeId
			WHERE 
				dsir.DealId = @pDealId 
				AND rt.RatingTypeId = @pRatingTypeId
				AND dn.ISIN = @pISIN
		END
	END
     
    IF @pDealId= 6
	 BEGIN
		SELECT @rating = COALESCE(@rating + ' / ', '') + Rating FROM @tblRatingData

		SET @rating = Replace(@rating, '/', '/ - /')
		SET @rating = @rating + ' / -'
	END
	ELSE
		SELECT @rating = COALESCE(@rating + ' / ', '') + Rating FROM @tblRatingData

     RETURN ISNULL(@rating, 'N/A')
END   
GO 
