USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetDealType') IS NOT NULL
	DROP FUNCTION [cw].[fnGetDealType]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Suresh Pandey 
 * Created Date	: 27-01-2022    
 * Description		: For getting deal Name from cfgcw.DealLookupValue table
*/    
CREATE FUNCTION [cw].[fnGetDealType]
( 
  @pDealId	INT
 )  
RETURNS  VARCHAR(300) AS           
BEGIN      
    DECLARE @result		VARCHAR(300)

	SELECT @result = v.[Name] FROM [cfg].[Deal] d
				JOIN [cfgCW].[DealLookupValue] v
					ON d.dealtypeid= v.[LookupValueId]
				JOIN cfgCW.DealLookupType t 
					ON v.LookupTypeId=t.LookupTypeId
				WHERE t.TypeCode='DealType' AND d.DealId=@pDealId

     RETURN @result
END  
GO