USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetWorkflowStepId') IS NOT NULL
	DROP FUNCTION cw.fnGetWorkflowStepId;
GO


/*    
 *   
 * Author   : GUNJAN CHANDOLA  
 * Created Date : 15-06-2021    
 * Description  : To automated data auth step ID
 * Example   :  Select  cw.fnGetWorkflowStepId 
*/    
  
CREATE FUNCTION cw.fnGetWorkflowStepId
(
  @pStepName VARCHAR(100), 
  @pFeedName VARCHAR(100)
 )  
RETURNS  INT AS           
BEGIN      
    DECLARE @id AS INT
	   SET @id=(SELECT wfs.WorkflowStepId
	   FROM cfgcw.WorkflowStep wfs
	   JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
	   WHERE wft.Name = @pFeedName
	   AND wfs.StepName = @pStepName)

     RETURN @id
END  
GO
