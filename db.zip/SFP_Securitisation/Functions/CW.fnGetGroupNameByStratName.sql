
IF OBJECT_ID('CW.fnGetGroupNameByStratName') IS NOT NULL
DROP FUNCTION CW.fnGetGroupNameByStratName
GO  
  
CREATE FUNCTION CW.fnGetGroupNameByStratName(@StratName VARCHAR(200),@Value DECIMAL(38,16))    
/*    
 * Author: Arun
 * Date:    14.11.2020    
 * Description:  This will return group by name after comparing passed value with attribute value    
 *                                                     
 * Change History    
 * --------------    
 * Author              Date                 Description    
 * -------------------------------------------------------    
*/    
RETURNs VARCHAR(200) AS    
BEGIN    
  
 DECLARE @retValue VARCHAR(200);    
 
 SELECT @retValue=dans.DisplayName    
 FROM CW.VwGetGroupNameByStratName  dans  
 WHERE StratInternalName=@StratName AND    
 (    
  (    
   (CHARINDEX('=',MaxOp)=0 AND CHARINDEX('=',MinOp)=0)    
   AND  (MinValue IS NOT NULL AND MaxValue IS NOT NULL AND @Value > MinValue AND @Value < MaxValue)    
  )    
  OR     
  (    
   (CHARINDEX('=',MaxOp)=2 AND CHARINDEX('=',MinOp)=2)    
   AND  (MinValue IS NOT NULL AND MaxValue IS NOT NULL AND @Value >= MinValue AND @Value <= MaxValue)    
  )  
  OR     
  (    
   (CHARINDEX('=',MinOp) IS NULL AND CHARINDEX('=',MaxOp) = 0 )    
	   AND (MinValue IS NULL AND @Value < MaxValue)    
  )   
  OR     
  (    
   (CHARINDEX('=',MinOp) IS NULL AND CHARINDEX('=',MaxOp) = 2 )    
	   AND (MinValue IS NULL AND @Value <= MaxValue)    
  )   
   OR     
  (    
   (CHARINDEX('=',MaxOp) IS NULL AND CHARINDEX('=',MinOp) = 0 )    
	   AND (MaxValue IS NULL AND @Value > MinValue)    
  )   
   OR     
  (    
   (CHARINDEX('=',MaxOp) IS NULL AND CHARINDEX('=',MinOp) = 2 )    
	   AND (MaxValue IS NULL AND @Value >= MinValue)    
  )     
  OR     
  (    
   (CHARINDEX('=',MaxOp)=2 AND CHARINDEX('=',MinOp)=0)    
   AND  (MinValue IS NOT NULL AND MaxValue IS NOT NULL AND @Value > MinValue AND @Value <= MaxValue)    
  )     
  OR     
  (    
   (CHARINDEX('=',MaxOp)=0 AND CHARINDEX('=',MinOp)=2)    
   AND  (MinValue IS NOT NULL AND MaxValue IS NOT NULL AND @Value >= MinValue AND @Value < MaxValue)    
  )   

 )    
    
 RETURN isNull(@retValue,'');  
END    

GO
