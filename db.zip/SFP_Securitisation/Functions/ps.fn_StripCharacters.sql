USE [SFP_Securitisation]
GO
/****** Object:  UserDefinedFunction [ps].[fn_StripCharacters]    Script Date: 21/11/2021 21:30:16 ******/
IF OBJECT_ID('ps.fn_StripCharacters') IS NOT NULL
DROP FUNCTION [ps].[fn_StripCharacters]
GO

/****** Object:  UserDefinedFunction [ps].[fn_StripCharacters]    Script Date: 21/11/2021 21:30:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [ps].[fn_StripCharacters]
(
    @String NVARCHAR(MAX), 
    @MatchExpression VARCHAR(255)
)
RETURNS NVARCHAR(MAX)
AS
BEGIN
    SET @MatchExpression =  '%['+@MatchExpression+']%'
    
    WHILE PatIndex(@MatchExpression, @String) > 0
        SET @String = Stuff(@String, PatIndex(@MatchExpression, @String), 1, '')
    
    RETURN @String
END
GO