USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetDealAggregatedFieldValue]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetDealAggregatedFieldValue]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	18.01.2022
 * Description:  This will return Deal Aggregated Field value based on the parameters
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Example:
 * SELECT [cw].[fnGetDealAggregatedFieldValue]('2021-04-30', 6, 'ArrearsAdjustedCapitalBalance') 
*/ 
CREATE FUNCTION [cw].[fnGetDealAggregatedFieldValue]      
(      
    @pCorrelatedDate			DATE,
	@pDealId					INT,
	@pFieldCode					VARCHAR(100)
)      
RETURNS DECIMAL(38, 16)     
AS      
BEGIN      
	DECLARE @value DECIMAL(38, 16)  
	
	SELECT @value =  dad.LoanBalance FROM cw.DealAggregatedData dad
	JOIN cfgcw.DealAggregatedField daf ON dad.DealAggregatedFieldId = daf.DealAggregatedFieldId AND dad.DealId = daf.DealId
	WHERE CorrelatedDate = @pCorrelatedDate AND dad.DealId = @pDealId
	AND daf.FieldName = @pFieldCode

	RETURN @value
END
GO