USE [SFP_Securitisation]
GO
  
 
IF OBJECT_ID('cw.fnGetReportLookupValueByName') IS NOT NULL
	DROP FUNCTION [cw].[fnGetReportLookupValueByName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Suresh Pandey
 * Created Date		: 20-09-2022     
 * Description		: For gettingthe lookup value from ref.vw_ReportLookUpData_v1 table
*/    
CREATE FUNCTION [cw].[fnGetReportLookupValueByName]
(
  @pReportTemplateName VARCHAR(10),
  @pLookUpValue		VARCHAR(100),
  @pLookupName		VARCHAR(100) = NULL
 )  
RETURNS  VARCHAR(300) AS           
BEGIN      
    DECLARE @result		VARCHAR(300)

	SET @result =(SELECT ReportValue 
					FROM 
						sfp.syn_SfpModel_vw_ReportLookUpData_v1
					WHERE 
						ReportTemplateName = @pReportTemplateName
						AND LookUpValue = @pLookUpValue
						AND LookupName = @pLookupName)
	

     RETURN @result
END  
GO