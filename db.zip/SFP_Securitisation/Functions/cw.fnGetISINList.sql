USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.[fnGetISINList]') IS NOT NULL
	DROP FUNCTION cw.[fnGetISINList];
GO
/*
 * Author: Arun
 * Date:   15-Oct-2020  
 * Description:  To fetch active ISIN for bond rating and convert them into string
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Kapil Sharma 15-Jun-22   Added the union with covered deal notes as well
 
 * Example:
 * SELECT [cw].[fnGetISINList]() 
*/ 
CREATE FUNCTION cw.[fnGetISINList]      
(      
    
)      
RETURNS VARCHAR(MAX)      
AS      
BEGIN      
	DECLARE @ISINList VARCHAR(MAX)

	SELECT @ISINList = COALESCE(@ISINList + ',', '') + CAST(isin.ISIN AS VARCHAR)
	FROM
	(
		SELECT rmbs.ISIN FROM cfgCW.DealNote rmbs 
		JOIN cfgCW.CashWaterfallDeal deal ON deal.DealId = rmbs.DealId
		WHERE rmbs.IsActive=1
		UNION
		SELECT cb.ISIN FROM cfgcb.DealNote cb WHERE cb.ValidTo > GETDATE()
	) AS isin

	RETURN @ISINList     

END
GO
