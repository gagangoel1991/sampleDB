USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetDealLookupValue') IS NOT NULL
	DROP FUNCTION [cw].[fnGetDealLookupValue]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Kapil Sharma 
 * Created Date	: 17-06-2021    
 * Description		: For gettingthe lookup value from cfgcw.DealLookupValue table
*/    
CREATE FUNCTION [cw].[fnGetDealLookupValue]
(
  @pLookupTypeCode		VARCHAR(100), 
  @pLookupValueId		SMALLINT
 )  
RETURNS  VARCHAR(300) AS           
BEGIN      
    DECLARE @result		VARCHAR(300)

	SELECT 
		@result = dlv.[Value] 
	FROM 
		cfgcw.DealLookupValue dlv
	JOIN 
		cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
	WHERE 
		dlt.TypeCode = @pLookupTypeCode
		AND dlv.LookupValueId = @pLookupValueId

     RETURN @result
END  
GO