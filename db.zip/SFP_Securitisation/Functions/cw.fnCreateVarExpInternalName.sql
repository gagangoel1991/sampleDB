USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.fnCreateVarExpInternalName') IS NOT NULL 
	DROP  FUNCTION cw.[fnCreateVarExpInternalName]

GO


/* 
 *   Author: Aditya Shrivastava 
 *   Date:  02.06.2020 
 *   Description: Create and return variable/expression name bASED UPON PARAM
 *   Ex: SELECT cw.[fnCreateVarExpInternalName]('exp')
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
CREATE FUNCTION [cw].[fnCreateVarExpInternalName] (@Param VARCHAR(200)) 
returns VARCHAR(200) 
AS 
  BEGIN 
      DECLARE @CreatedInternalName VARCHAR(200); 

      IF( @Param = 'exp' ) 
        BEGIN 
            SELECT TOP 1 @CreatedInternalName = 'expression_' 
                                                + RIGHT('00000'+CONVERT(NVARCHAR(10), CONVERT(INT, Substring( InternalName, 12, 5 ))+1 ), 5) 
            FROM   cw.Expression 
            ORDER  BY CONVERT(INT, Substring(InternalName, 12, 5)) DESC 

            IF( @CreatedInternalName IS NULL ) 
              SET @CreatedInternalName='expression_00001' 
        END 
      ELSE IF( @Param = 'var' ) 
        BEGIN 
            SELECT TOP 1 @CreatedInternalName = 'variable_' 
                                                + RIGHT('00000'+CONVERT(NVARCHAR(10), CONVERT(INT, Substring(InternalName, 10, 5 ))+1 ), 5) 
            FROM   cw.Variable 
            ORDER  BY CONVERT(INT, Substring(InternalName, 10, 5)) DESC 

            IF( @CreatedInternalName IS NULL ) 
              SET @CreatedInternalName='variable_00001' 
        END 

      RETURN @CreatedInternalName; 
  END 

GO 