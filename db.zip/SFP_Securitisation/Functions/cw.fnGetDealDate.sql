USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetDealDate') IS NOT NULL 
	DROP  FUNCTION cw.[fnGetDealDate]


GO

/* 
 *   Author: Aditya Shrivastava
 *   Date:  04.06.2020 
 *   Description: Return dates based upon dealid, previosRunNum and DealDateKeyInternalName
 *   Ex: SELECT cw.[fnGetDealDate](14,3,'Previous')
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
CREATE FUNCTION [cw].[fnGetDealDate] (@DealId  SMALLINT,@PreviousRunNum SMALLINT,
                     @DealDateKeyInternalName  VARCHAR(200)) 
returns DATETIME
AS 
  BEGIN 
     	 --Declare @DealId smallint=14, @PreviousRunNum smallInt=0, @DealDateKeyInternalName VARCHAR(200)='PreviousIPD'

		DECLARE @ReturnDate DATETIME , @DealIpdRunId int

		SET @DealIpdRunId = (SELECT DealIpdRunId FROM [cw].[vwDealIpdRun] WHERE dealid=@Dealid AND PreviousRunNum=@PreviousRunNum)


		SET @ReturnDate = (SELECT DealDateValue FROM cw.vwDealDate 
					WHERE DealIpdRunId = @DealIpdRunId AND DealDateKeyInternalName = @DealDateKeyInternalName)


      RETURN @ReturnDate; 
  END 

  GO

