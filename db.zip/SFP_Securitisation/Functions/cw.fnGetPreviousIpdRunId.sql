USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetPreviousIpdRunId') IS NOT NULL 
	DROP  FUNCTION cw.[fnGetPreviousIpdRunId]


GO


/* 
 *   Author: Aditya Shrivastava
 *   Date:  04.06.2020 
 *   Description: Return PreviousIpdRunId based upon dealid and previosRunNum.
 *   Ex: SELECT cw.[fnGetPreviousIpdRunId](14,2)
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
CREATE FUNCTION [cw].[fnGetPreviousIpdRunId] (@DealId  SMALLINT,@PreviousRunNum SMALLINT) 
returns INT
AS 
  BEGIN
		DECLARE @PreviousIpdDate DATETIME = (SELECT cw.[fnGetDealDate](@DealId,@PreviousRunNum,'PreviousIPD'))
		DECLARE @DealIpdRunId INT

		 SET @DealIpdRunId =(SELECT DealIpdRunId 
											FROM   (SELECT DealIpdRunId, 
														   row_number() 
															 OVER ( 
															   partition BY IpdDate 
															   ORDER BY DealIpdRunId DESC) AS rn 
													FROM   cw.vwDealIpdRun 
													WHERE  DealId = @DealId 
														   AND IpdDate = @PreviousIpddate) AS t 
											WHERE  t.rn = 1) 


      RETURN @DealIpdRunId; 

END
GO