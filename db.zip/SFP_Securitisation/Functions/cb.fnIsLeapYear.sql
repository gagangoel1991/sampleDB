USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.fnIsLeapYear') IS NOT NULL
	DROP FUNCTION [cb].[fnIsLeapYear]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Suresh Pandey
 * Created Date		: 08-06-2022    
 * Description		: For checkig leap year
 * 
 *  SELECT [cb].[fnIsLeapYear](2022)  
*/    
CREATE FUNCTION [cb].[fnIsLeapYear] (@pYear  INT)
RETURNS BIT
AS 
BEGIN
	DECLARE @result BIT

	IF ((@pYear % 4 = 0 AND @pYear % 100 <> 0) OR @pYear % 400 = 0)
	  SET @result = 1
	ELSE
	  SET @result =  0
	
	RETURN @result

END
GO