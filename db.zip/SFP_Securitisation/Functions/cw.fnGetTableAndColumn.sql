USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.fnGetTableAndColumn') IS NOT NULL 
	DROP  FUNCTION CW.fnGetTableAndColumn
GO

/* 
 *   Author: Aditya Shrivastava 
 *   Date:  02.06.2020 
 *   Description:  Get table name or column name based upon filter value
 *   Ex: SELECT cw.fnGetTableAndColumn(@text,'table')
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */  
CREATE FUNCTION [cw].[fnGetTableAndColumn] (@text   VARCHAR(500), 
                                            @filter VARCHAR(20)) 
RETURNS VARCHAR(50) 
AS 
  BEGIN 
      DECLARE @returnValue VARCHAR(50); 

      SET @text=(SELECT Replace(@text, '{', '')); 
      SET @text=(SELECT Replace(@text, '}', '')); 

      IF( @filter = 'table' ) 
        BEGIN 
            SELECT @returnValue = Substring(@text, 0, Charindex('.', Substring(@text, Charindex('.', @text)+1, Len(@text 
                                                      )) ) + Charindex('.', @text)); 
        END 
      ELSE 
        BEGIN 
            SELECT @returnValue = Substring(Substring(@text, Charindex('.', @text) + 1, Len(@text)), 
                                                        Charindex('.', Substring(@text, Charindex('.', @text)+1, Len( 
                                                        @text ))) + 1, Len( Substring(@text, Charindex('.', @text) + 1, Len(@text)))); 
        END 

      RETURN @returnValue; 
  END   
  
  GO 
