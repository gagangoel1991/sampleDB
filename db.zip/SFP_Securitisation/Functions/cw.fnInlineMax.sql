USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.fnInlineMax') IS NOT NULL 
	DROP  FUNCTION cw.[fnInlineMax]
GO


/* 
 *   Author: Aditya Shrivastava 
 *   Date:  02.06.2020 
 *   Description:  Get max of values passed as CSV to this function
 *   Ex: SELECT cw.fnGetTableAndColumn('500','100.36')
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
CREATE FUNCTION [CW].[fnInlineMax](@InputStr VARCHAR(max)) 
returns DECIMAL(38,16) 
AS 
  BEGIN 
      DECLARE @temp cw.udtDecimalArray 

      WHILE Len(@InputStr) > 0 
        BEGIN 
            DECLARE @num VARCHAR(100) 

            IF Charindex(',', @InputStr) > 0 
              SET @num = Substring(@InputStr, 0, Charindex(',', @InputStr)) 
            ELSE 
              BEGIN 
                  SET @num = @InputStr 
                  SET @InputStr = '' 
              END 

            INSERT INTO @temp 
            SELECT CASE 
                     WHEN @num = 'NULL' THEN '0' 
                     ELSE @num 
                   END 

            SET @InputStr = Replace(@InputStr, @num + ',', '') 
        END 

      RETURN 
        (SELECT Max(num) 
         FROM   @temp) 
  END 

GO   