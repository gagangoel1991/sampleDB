USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetLogStepCodeValue') IS NOT NULL
	DROP FUNCTION [cw].[fnGetLogStepCodeValue]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Ravindra Singh
 * Created Date	: 06-09-2021    
 * Description		: For gettingthe lookup value from cw.fnGetLogStepCodeValue table
*/    
CREATE FUNCTION [cw].[fnGetLogStepCodeValue]
(
  @pStepCode		VARCHAR(100),
  @plogFeatureID    INT
 )  
RETURNS  INT AS           
BEGIN      
    DECLARE @result		INT

	SELECT 
		@result = LogStepId 
	FROM 
		app.LogStep ls
	
	WHERE 
		StepCode = @pStepCode AND LogFeatureId =@plogFeatureID

     RETURN @result
END  
GO