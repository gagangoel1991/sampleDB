USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.fnVarExpAppend') IS NOT NULL 
	DROP  FUNCTION cw.fnVarExpAppend
GO

/* 
 *   Author: Aditya Shrivastava 
 *   Date:  02.06.2020 
 *   Description:  pass internal name of expression or variable and return name with tableName and schema. used on calcualteExpression stored procedure
 *   Ex: SELECT [CW].[fnVarExpAppend]('variable_0001')
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */   
CREATE FUNCTION [CW].[fnVarExpAppend] (@InternalName VARCHAR(200)) 
returns VARCHAR(200) 
AS 
  BEGIN 
      DECLARE @AppendName VARCHAR(200); 

      IF( Charindex('expression', @InternalName) > 0 ) 
        BEGIN 
            SET @AppendName='[cw.expression.' + @InternalName + ']' 
        END 
      ELSE IF( Charindex('variable', @InternalName) > 0 ) 
        BEGIN 
            SET @AppendName='[cw.variable.' + @InternalName + ']' 
        END 

      RETURN @AppendName; 
  END 

GO  