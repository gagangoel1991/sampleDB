USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnIsIpdStatusAllowChange') IS NOT NULL
	DROP FUNCTION cw.fnIsIpdStatusAllowChange;
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	23.07.2021
 * Description:  This will check whether the deal ipd status allow changes in the related data or not
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cw].[fnIsIpdStatusAllowChange]      
(      
	@pDealIpdRunId	INT
)      
RETURNS BIT     
AS      
BEGIN      
	DECLARE 
		@result				BIT,
		@ipdworkflowStepId	SMALLINT

	SELECT @ipdworkflowStepId = WorkflowStepId FROM cw.DealIpdRun WHERE RunId = @pDealIpdRunId
	
	IF NOT EXISTS(SELECT TOP 1 * FROM cfgcw.WorkflowStep wfs 
		JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
		WHERE 
			wft.Name = 'Deal_IPD' 
			AND wfs.StepName NOT IN ('SendForAuthorisation', 'Authorise')
			AND wfs.WorkflowStepId = @ipdworkflowStepId)
	BEGIN
		SET @result = 0 
	END
	ELSE
		SET @result = 1
	
	RETURN @result
END
GO

