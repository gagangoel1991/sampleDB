USE [SFP_Securitisation]
GO
 
IF OBJECT_ID('cw.fnGetDealLookupValueByName') IS NOT NULL
	DROP FUNCTION [cw].[fnGetDealLookupValueByName]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Suresh Pandey
 * Created Date	: 17-07-2022    
 * Description		: For gettingthe lookup value from cfgcw.DealLookupValue table
*/    
CREATE FUNCTION [cw].[fnGetDealLookupValueByName]
(
  @pLookupName		VARCHAR(100), 
  @pLookupTypeCode		VARCHAR(100) = NULL
 )  
RETURNS  VARCHAR(300) AS           
BEGIN      
    DECLARE @result		VARCHAR(300)

	IF(@pLookupTypeCode IS NULL OR @pLookupTypeCode='')
	BEGIN

		SET @result = (SELECT dlv.[Value] 
					FROM 
						cfgcw.DealLookupValue dlv
					JOIN 
						cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
					WHERE 
						dlv.Name = @pLookupName)
						
	END 
	ELSE 
	BEGIN
		SET @result =(SELECT dlv.[Value] 
					FROM 
						cfgcw.DealLookupValue dlv
					JOIN 
						cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
					WHERE 
						dlt.TypeCode = @pLookupTypeCode
						AND dlv.Name = @pLookupName)
	END 

     RETURN @result
END  
GO