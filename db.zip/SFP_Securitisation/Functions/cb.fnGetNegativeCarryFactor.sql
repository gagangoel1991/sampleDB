USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[fnGetNegativeCarryFactor]') IS NOT NULL
	DROP FUNCTION [cb].[fnGetNegativeCarryFactor]
GO
/*
 * Author: Suresh Pandey
 * Date:	19.01.2022
 * Description:  This will return the NegativeCarryFactor 
 * 
 * SELECT [Cb].[fnGetNegativeCarryFactor](6, 28)			
 * 
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cb].[fnGetNegativeCarryFactor]      
(      
	@pDealId SMALLINT,
	@pDealIpdRunId INT
)      
RETURNS DECIMAL(38, 16)    
AS      
BEGIN  
	DECLARE @weightedAverageMargin DECIMAL(38, 16) ,@negativeCarryFactor  DECIMAL(38, 16)
	
	SET @weightedAverageMargin = (SELECT [Cb].[fnGetWeightedAverageMargin](@pDealId, @pDealIpdRunId) ) 
	
	SET @negativeCarryFactor = (SELECT IIF(@weightedAverageMargin<=0.1/100, 0.5/100,(@weightedAverageMargin-0.1/100)+0.5/100))
	
	RETURN @negativeCarryFactor

END
GO


