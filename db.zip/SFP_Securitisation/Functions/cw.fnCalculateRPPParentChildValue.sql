USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.fnCalculateRPPParentChildValue') IS NOT NULL 
	DROP  FUNCTION cw.[fnCalculateRPPParentChildValue]

GO


/* 
 *   Author: Aditya Shrivastava 
 *   Date:  02.08.2020 
 *   Description: Create and return value for parent in SP: spGetIPDRevenueWaterfall
 *   Ex: SELECT cw.[fnCalculateRPPParentChildValue](154,1,14,'RemainingDueAmount',0)
 *        
 *   Change History 
 *   -------------- 
 *   Author    Date    Description 
 *   -------------------------------------------------------            
  */
CREATE FUNCTION [cw].[fnCalculateRPPParentChildValue] (@WaterfallLineItemId INT,  @SourceId INT, @DealIpdRunId INT, @FieldName VARCHAR(200), @ParamValue decimal(38,16))
returns decimal(38,16)
AS 
  BEGIN
		DECLARE @Amount decimal(38,16)
		 
		IF NOT EXISTS (SELECT * FROM  cfgcw.WaterfallLineItem wli WHERE ParentWaterfallLineItemId = @WaterfallLineItemId)
			SET @Amount = @ParamValue;
		ELSE
		BEGIN
			SELECT @Amount = CASE 
								WHEN @FieldName='TotalDueAmount' THEN sum(TotalDueAmount) 
								WHEN @FieldName='DueAmount' THEN sum(DueAmount) 
								WHEN @FieldName='AmountPaidFromSource' THEN sum(AmountPaidFromSource)
								WHEN @FieldName='RemainingDueAmount' THEN sum(RemainingDueAmount)
								WHEN @FieldName='TotalPaidAmount' THEN sum(TotalPaidAmount)
								WHEN @FieldName='IsEligible' THEN iif(sum(CASE WHEN IsEligible=1 THEN 1 ELSE 0 END)=count(IsEligible),1,0)
								
							END	
			FROM cw.RevenueWaterfallPayment rwp  
			JOIN cfgcw.WaterfallLineItem wli
			ON ParentWaterfallLineItemId = @WaterfallLineItemId
			AND rwp.WaterfallLineItemId = wli.WaterfallLineItemId 
			AND  DealIpdRunId=@DealIpdRunId AND  SourceId=@SourceId
		END

		RETURN @Amount
END

GO