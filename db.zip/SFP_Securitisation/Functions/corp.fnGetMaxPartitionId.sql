USE [SFP_Securitisation]
GO

IF OBJECT_ID('[corp].[fnGetMaxPartitionId]') IS NOT NULL
	DROP FUNCTION [corp].[fnGetMaxPartitionId];
GO

/*------------------------------------------------------------------------------------------------------------
Author         : Aditya Aggarwal
Creation Date  : 01-March-2023
Description    : Fetches max PartitionId for which Corporate batch is complete 
Execution      : [corp].[fnGetMaxPartitionId]()
Change History :

-------------------------------------------------------------------------------------------------------------*/

CREATE FUNCTION [corp].[fnGetMaxPartitionId]      
(      
    
)      
RETURNS INT      
AS      
BEGIN      
	/* FETCHING MAX PARTITION ID FOR ALL 4 SOURCE SYSTEMS */
	DECLARE @RMPMaxPartitionId INT = (SELECT TOP(1) PartitionId FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] WITH (NOLOCK) WHERE SourceId = 1 ORDER BY PartitionId DESC)
	DECLARE @PRMMaxPartitionId INT = (SELECT TOP(1) PartitionId FROM [corp].[syn_SfpModelCorporate_vw_FactFacility] WITH (NOLOCK) WHERE SourceId = 2 ORDER BY PartitionId DESC)
	DECLARE @LIQPMaxPartitionId INT = (SELECT TOP(1) PartitionId FROM [corp].[syn_SfpModelCorporate_vw_FactLoan] WITH (NOLOCK) WHERE SourceId = 3 ORDER BY PartitionId DESC)
	DECLARE @CAUMaxPartitionId INT = (SELECT TOP(1) PartitionId FROM [corp].[syn_SfpModelCorporate_vw_FactLoan] WITH (NOLOCK) WHERE SourceId = 4 ORDER BY PartitionId DESC)	
	
	DECLARE @BatchMaxPartitionId INT = (SELECT  TOP(1) Relates_To_Date_YYYYMMDD
										FROM [app].[syn_Configuration_ctrl_vw_EventLog_v1]
										WHERE Event = 'BUILD_RMP_LOAN_TO_FACILITY_LINKING' AND State = 'Success'
										GROUP BY Relates_To_Date_YYYYMMDD
										HAVING COUNT(*) > 1
										ORDER BY Relates_To_Date_YYYYMMDD DESC)

	/* FINDING MAX PARTITION ID WHICH IS PRESENT IN ALL 4 SOURCE SYSTEMS */			
	DECLARE @MaxPartitionId INT = (SELECT MIN(PartitionId) FROM (VALUES (@RMPMaxPartitionId), (@PRMMaxPartitionId), (@LIQPMaxPartitionId),(@CAUMaxPartitionId), (@BatchMaxPartitionId)) Partitions(PartitionId))
	
	RETURN @MaxPartitionId    

END
GO
