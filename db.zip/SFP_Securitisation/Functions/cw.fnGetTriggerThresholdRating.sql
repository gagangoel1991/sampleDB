USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetTriggerThresholdRating]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetTriggerThresholdRating];
GO
--------------------------------------------------------
--    Author   : Gunjan Chandola  
--Created Date : 28-May-2021    
--Description  : To fetch non rating threshold rating
--   Example   : SELECT  [cw].[fnGetTriggerThresholdRating](1)
--------------------------------------------------------   
  
CREATE FUNCTION [cw].[fnGetTriggerThresholdRating]      
(      
     @pDealIpdTriggerResultId  INT
)      
 RETURNS VARCHAR(MAX)   
AS      
BEGIN  

	DECLARE @CRAId INT
		,@p_CRAId INT
		,@RatingTypeId INT
		,@CRA_Name VARCHAR(200)
		,@RT_Name VARCHAR(200)
		,@ThresholdRating VARCHAR(200)
		,@ThresholdRating_Concatenated VARCHAR(4000);

		DECLARE db_cursor CURSOR
		FOR
		SELECT DISTINCT cra.CRAId
			,rt.RatingTypeId
			,cra.[Name] AS CRA_Name
			,CASE 
				WHEN rt.RatingTypeId = 1
					THEN 'ST'
				WHEN rt.RatingTypeId = 2
					THEN 'LT'
				WHEN rt.RatingTypeId = 4
					THEN 'STCP'
				WHEN rt.RatingTypeId = 5
					THEN 'LTCP'
				ELSE rt.[Name]
				END AS RT_Name
			,trm.ThresholdRating
		FROM cfgCW.DealTriggerRatingMap trm
		JOIN cfgCW.DealSubjectCRAMap craMap ON trm.DealSubjectCRAMapId = craMap.DealSubjectCRAMapId
		JOIN cfgCW.CreditRatingAgency cra ON craMap.CRAId = cra.CRAId
		JOIN cfgCW.RatingType rt ON trm.RatingTypeId = rt.RatingTypeId
		JOIN cfgCW.DealTriggerMap tm ON trm.DealTriggerMapId = tm.DealTriggerMapId
		JOIN cw.DealIpdTriggerResult tr ON trm.DealTriggerMapId = tr.DealTriggerMapId
		WHERE tr.DealIpdTriggerResultId = @pDealIpdTriggerResultId
		ORDER BY cra.CRAId
			,rt.RatingTypeId

	
	OPEN db_cursor  
	FETCH NEXT FROM db_cursor INTO @CRAId,@RatingTypeId,@CRA_Name,@RT_Name,@ThresholdRating  
	
	WHILE @@FETCH_STATUS = 0  
	BEGIN  
	
		SET  @ThresholdRating_Concatenated = ISNULL(@ThresholdRating_Concatenated, '') + CASE WHEN LEN(@ThresholdRating_Concatenated)>0 AND @p_CRAId = @craId THEN '/' ELSE ' ' END + @CRA_Name + ' ' + @RT_Name + ' '+ @ThresholdRating		
		SET @p_CRAId=@CRAId 
	    FETCH NEXT FROM db_cursor INTO @CRAId,@RatingTypeId,@CRA_Name,@RT_Name,@ThresholdRating  
	END 
	
	CLOSE db_cursor  
	DEALLOCATE db_cursor 
    
	RETURN @ThresholdRating_Concatenated
END     
GO
