USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.fnYearFracValue') IS NOT NULL
	DROP FUNCTION [cb].[fnYearFracValue]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Aditya Shrivastava
 * Created Date	: 15-12-2021    
 * Description		: for calculating frac value
 * 
 *  Change History 
 *   --------------  
 *   Author    Date    Description 
 *   ------------------------------------------------------- 
 *   AS		18.01.2022		changed logic as it is changed in modal as well
*/    
CREATE FUNCTION [cb].[fnYearFracValue] (@pStartDate  date,@pEndDate date, @pDayCountMethod varchar(300))
returns decimal(38,16)
AS 
BEGIN
DECLARE
--@pStartDate date = '2021-01-13', @pEndDate date = '2022-01-13'
--@pStartDate date = '2020-12-22', @pEndDate date = '2021-01-22'
--, @pDayCountMethod varchar(300)='-1', 
@dateDiff decimal(9,6)
, @dayCountMethodFactor decimal(38,16)
, @areDatesYearSame bit
, @isStartDateLeapYear bit
, @totalDaysInStartYear smallInt
, @actualFraction decimal(38,16)
, @isEndDateLeapYear bit
, @totalDaysInEndYear smallInt
, @daysInStartYear smallInt
, @daysInEndYear smallInt
, @startDateYearFraction decimal(38,16)
, @endDateYearFraction decimal(38,16)


SET @areDatesYearSame = (SELECT IIF (year(@pStartDate) = year(@pEndDate) , 1 , 0 ))

--print '@areDatesYearSame'
--print @areDatesYearSame

SET @dateDiff = (SELECT DATEDIFF(day, @pStartDate, @pEndDate ))

--print '@dateDiff'
--print @dateDiff

SET @dayCountMethodFactor = (SELECT CASE WHEN @pDayCountMethod IN ('365.0', '360.0') THEN @dateDiff/ @pDayCountMethod
ELSE -1.0 END)

--print '@dayCountMethodFactor'
--print @dayCountMethodFactor


SELECT  @isStartDateLeapYear=  IIF (( year(@pStartDate) % 4 = 0 AND  year(@pStartDate) % 100 != 0) OR  year(@pStartDate) % 400 = 0, 1,0)
 
 --print '@isStartDateLeapYear'
 --print @isStartDateLeapYear

 SELECT @totalDaysInStartYear= IIF(@isStartDateLeapYear = 1, 366,365)

 --print '@totalDaysInStartYear'
 --print @totalDaysInStartYear

 SELECT @actualFraction = IIF (@areDatesYearSame = 1, CONVERT(decimal(20,8),@dateDiff)/CONVERT(decimal(20,8),@totalDaysInStartYear), -1 )

 --print '@actualFraction'
 --print @actualFraction
 
SELECT  @isEndDateLeapYear=  IIF (( year(@pEndDate) % 4 = 0 AND  year(@pEndDate) % 100 != 0) OR  year(@pEndDate) % 400 = 0, 1,0)
 
 --print @isEndDateLeapYear
 
 SELECT @totalDaysInEndYear= IIF(@isEndDateLeapYear = 1, 366,365)

 --print @totalDaysInEndYear

 --SELECT @daysInStartYear = datediff(day, @pStartDate, EOMONTH(@pStartDate)) + 1
 SELECT @daysInStartYear = datediff(day,@pStartDate,datefromparts(year(@pStartDate), 12, 31))+1
 --SELECT @daysInEndYear = datediff(day, datefromparts(year(@pEndDate), month(@pEndDate), 1), @pEndDate)
 SELECT @daysInEndYear = datediff(day,datefromparts(year(@pEndDate), 1, 1),@pEndDate)
 --print '@daysInStartYear'
 --print @daysInStartYear
 --print '@daysInEndYear'
 --print @daysInEndYear


 SELECT @startDateYearFraction = CONVERT(decimal(20,8),@daysInStartYear)/ CONVERT(decimal(20,8),@totalDaysInStartYear)
 SELECT @endDateYearFraction = CONVERT(decimal(20,8),@daysInEndYear)/ CONVERT(decimal(20,8),@totalDaysInEndYear)

 --print '@startDateYearFraction'
 --print @startDateYearFraction
 --print '@endDateYearFraction'
 --print @endDateYearFraction

 --print @startDateYearFraction + @endDateYearFraction
 
 --select  IIF(@dayCountMethodFactor != -1, 
	--			@startDateYearFraction + @endDateYearFraction, 
	--			IIF(@actualFraction != -1, @actualFraction, @startDateYearFraction + @endDateYearFraction))
RETURN  IIF(@dayCountMethodFactor != -1, 
				@dayCountMethodFactor,
				IIF(@actualFraction != -1, @actualFraction, @startDateYearFraction + @endDateYearFraction))

END

GO