USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetPrevIpdRunIdByIpdDate]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetPrevIpdRunIdByIpdDate]
GO


/*   
 *   Author: Kapil Sharma  
 *   Date:  30.07.2021  
 *   Description: This will return the previous IPD Run ID based on the current IPD Date  
 *   Ex: SELECT cw.[fnGetPrevIpdRunIdByIpdDate](14,2)  
 *          
 *   Change History   
 *   --------------   
 *   Author    Date    Description   
 *   -------------------------------------------------------              
  */  
CREATE FUNCTION [cw].[fnGetPrevIpdRunIdByIpdDate] (@pDealId INT, @pIpdDate  DATE)   
returns INT  
AS   
BEGIN  
    
 DECLARE @prevIpdRunId INT  
  
 SELECT @prevIpdRunId = dir.RunId  
 FROM cw.vwDealIpdDates currIpdDt   
 JOIN cw.vwDealIpdDates prevIpdDt ON prevIpdDt.IPD = currIpdDt.PreviousIPD AND prevIpdDt.DealId = @pDealId  
 JOIN cw.DealIpd di ON di.DealIpdId = prevIpdDt.DealIpdId AND di.DealId = @pDealId  
 JOIN cw.DealIpdRun dir ON dir.DealIpdId = di.DealIpdId   
 WHERE   
  currIpdDt.IPD = @pIpdDate AND currIpdDt.DealId = @pDealId  
  AND dir.IsCurrentVersion = 1   
  AND di.IpdSequence >0  
  
    RETURN @prevIpdRunId;   
  
END

GO
