USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetCurrencySwapRate]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetCurrencySwapRate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	18.01.2022
 * Description:  This will return the manual field value
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Example:
 * SELECT [cw].[fnGetCurrencySwapRate](52, 56, '2021-05-28') 
*/ 
CREATE FUNCTION [cw].[fnGetCurrencySwapRate]    
(      
    @pFromCurrencyId		INT,
	@pToCurrencyId			INT,
	@pSpotDate				DATE
)      
RETURNS DECIMAL(18, 11) 
AS     
BEGIN      
	DECLARE @value DECIMAL(18, 11) 
	
	SELECT @value = Rate FROM cw.FxRate fx
	JOIN cfgcw.Currency src ON src.CurrencyId = fx.FromCurrencyId
	JOIN cfgcw.Currency trg ON trg.CurrencyId = fx.ToCurrencyId
	WHERE RelatesRateDate = @pSpotDate 
	AND src.CurrencyId = @pFromCurrencyId AND trg.CurrencyId = @pToCurrencyId

	RETURN @value
END
GO