USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnIsTriggerBreached]') IS NOT NULL
	DROP FUNCTION [cw].[fnIsTriggerBreached]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Suresh Pandey
 * Date:	16.02.2022
 * Description:  This will return the trigger is breached or not based on parameter 
 * 
 * SELECT [CW].[fnIsTriggerBreached](6, 1034,'RatingTrigger','Pre-MaturityTest')	
 * 
 * SELECT [CW].[fnIsTriggerBreached](6, 1034,'NonRatingTrigger','EventOfDefault')	
 * 
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cw].[fnIsTriggerBreached]      
(      
	@pDealId SMALLINT,
	@pDealIpdRunId INT,
	@pTriggerType VARCHAR(200),
	@pTriggerName VARCHAR(200)
)      
RETURNS BIT   
AS      
BEGIN  
	DECLARE 
		@result				BIT;
		
		SELECT  
			@result= tr.IsBreached   
		FROM  
			cw.DealIpdTriggerResult tr 
		JOIN 
			cfgCW.DealTriggerMap tm ON tr.DealTriggerMapId=tm.DealTriggerMapId
		JOIN 
			cfgCW.TriggerActionMap tam ON tm.TriggerActionMapId=tam.TriggerActionMapId
		JOIN
			cfgcw.TriggerActionType tat ON tam.TriggerActionTypeId =tat.TriggerActionTypeId
		JOIN 
			cfgCW.[Trigger] t ON tam.TriggerId=t.TriggerId AND t.DealId = tm.DealId
		JOIN 
			cfgCW.TriggerType tt ON t.TriggerTypeId=tt.TriggerTypeId
		WHERE  
			tm.DealId=@pDealId
			AND tr.DealIpdRunId=@pDealIpdRunId  
			AND tt.InternalName = @pTriggerType
			AND t.InternalName=@pTriggerName

	RETURN @result

END
GO

