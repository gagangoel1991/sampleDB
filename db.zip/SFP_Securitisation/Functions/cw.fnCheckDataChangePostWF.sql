USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[fnCheckDataChangePostWF]') IS NOT NULL
	DROP FUNCTION [cw].[fnCheckDataChangePostWF]
GO

/* 
 *   Author: Gunjan Chandola
 *   Date:  03.08.2021
 *   Description: to check if data has been changed post run Ipd.
 *   Ex: SELECT [cw].[fnCheckDataChangePostWF](2252,'2020-11-30','2020-11-30')                 
  */
CREATE FUNCTION [CW].[fnCheckDataChangePostWF] (
	@workflowProcessId SMALLINT
	,@bondRatingMaxDate DATE
	,@cpRatingMaxDate DATE
	)
RETURNS INT
AS
BEGIN
	DECLARE @ipdDate DATE
		,@dealId INT
		,@dealIpdRunId INT

	SELECT @ipdDate = IpdDate
		,@dealId = di.DealId
		,@dealIpdRunId = RunId
	FROM cw.DealIPD di
	JOIN cw.DealIpdRun dir ON dir.DealIpdID = di.DealIpdId
	JOIN cw.WorkFlowProcess wfs ON wfs.ProcessReferenceId = dir.RunId
	WHERE wfs.WorkflowProcessId = @workflowProcessId

	DECLARE @resultCode INT = 100

	IF EXISTS (
			SELECT inv.InvoiceId
				,invPostWF.InvoiceId
				,inv.DealIpdDate
				,invPostWF.DealIpdDate
			FROM [cw].[InvoiceData] inv
			LEFT JOIN [cw].[InvoiceData_postwf] invPostWF ON invPostWF.WorkflowProcessId = @workflowProcessId
				AND inv.DealId = invPostWF.DealId
				AND inv.InvoiceCategoryId = invPostWF.InvoiceCategoryId
				AND inv.DealCounterpartyId = invPostWF.DealCounterpartyId
				AND inv.Amount = invPostWF.Amount
				AND inv.PaidDate = invPostWF.PaidDate
				AND inv.ReferenceNumber = invPostWF.ReferenceNumber
				AND inv.SpotRate = invPostWF.SpotRate
				AND inv.InvoiceDate = invPostWF.InvoiceDate
				AND inv.InvoiceCurrencyId = invPostWF.InvoiceCurrencyId
				AND inv.SpotRateDate = invPostWF.SpotRateDate
			WHERE inv.DealIpdDate = @ipdDate
				AND invPostWF.InvoiceId IS NULL
			)
		OR EXISTS (
			SELECT inv.InvoiceId
				,invPostWF.InvoiceId
				,inv.DealIpdDate
				,invPostWF.DealIpdDate
			FROM [cw].[InvoiceData_postwf] invPostWF
			LEFT JOIN [cw].[InvoiceData] inv ON inv.DealId = invPostWF.DealId
				AND inv.InvoiceCategoryId = invPostWF.InvoiceCategoryId
				AND inv.DealCounterpartyId = invPostWF.DealCounterpartyId
				AND inv.Amount = invPostWF.Amount
				AND inv.PaidDate = invPostWF.PaidDate
				AND inv.ReferenceNumber = invPostWF.ReferenceNumber
				AND inv.SpotRate = invPostWF.SpotRate
				AND inv.InvoiceDate = invPostWF.InvoiceDate
				AND inv.InvoiceCurrencyId = invPostWF.InvoiceCurrencyId
				AND inv.SpotRateDate = invPostWF.SpotRateDate
			WHERE invPostWF.DealIpdDate = @ipdDate
				AND invPostWF.WorkflowProcessId = @workflowProcessId
				AND inv.InvoiceId IS NULL
			)
	BEGIN
		SET @resultCode = 106 --invoice data change  
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM [CW].[WaterfallLineItemAmount] lim
			LEFT JOIN [CW].[WaterfallLineItemAmount_postwf] limPostWF ON lim.DealIpdRunId = limPostWF.DealIpdRunId
			JOIN cw.WorkflowProcess wfp ON limPostWF.WorkflowProcessId = wfp.WorkflowProcessId
			WHERE lim.WaterfallLineItemId = limPostWF.WaterfallLineItemId
				AND lim.AdjustedAmount != limPostWF.AdjustedAmount
				AND wfp.WorkflowProcessId = @workflowProcessId
			)
		OR EXISTS (
			SELECT 1
			FROM [CW].[WaterfallLineItemAmount_postwf] limPostWF
			LEFT JOIN [CW].[WaterfallLineItemAmount] lim ON lim.DealIpdRunId = limPostWF.DealIpdRunId
			JOIN cw.WorkflowProcess wfp ON limPostWF.WorkflowProcessId = wfp.WorkflowProcessId
			WHERE lim.WaterfallLineItemId = limPostWF.WaterfallLineItemId
				AND lim.AdjustedAmount != limPostWF.AdjustedAmount
				AND wfp.WorkflowProcessId = @workflowProcessId
			)
	BEGIN
		SET @resultCode = 107 --Adjustments data change  
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM cw.DealIpdTriggerResult tr
			LEFT JOIN cw.DealIpdTriggerResult_postwf trPostWF ON tr.DealIpdRunId = trPostWF.DealIpdRunId
			JOIN cw.WorkflowProcess wfp ON trPostWF.WorkflowProcessId = wfp.WorkflowProcessId
			WHERE tr.DealTriggerMapId = trPostWF.DealTriggerMapId
				AND (
					tr.OutcomeSummary != trPostWF.OutcomeSummary
					OR tr.IsBreached != trPostWF.IsBreached
					)
				AND wfp.WorkflowProcessId = @workflowProcessId
			)
		OR EXISTS (
			SELECT 1
			FROM cw.DealIpdTriggerResult_postwf trPostWF
			LEFT JOIN cw.DealIpdTriggerResult tr ON tr.DealIpdRunId = trPostWF.DealIpdRunId
			JOIN cw.WorkflowProcess wfp ON trPostWF.WorkflowProcessId = wfp.WorkflowProcessId
			WHERE tr.DealTriggerMapId = trPostWF.DealTriggerMapId
				AND (
					tr.OutcomeSummary != trPostWF.OutcomeSummary
					OR tr.IsBreached != trPostWF.IsBreached
					)
				AND wfp.WorkflowProcessId = @workflowProcessId
			)
	BEGIN
		SET @resultCode = 108 --Rating/Non Rating trigger data change  
	END
	--Bond rating for RMBS 
	ELSE IF EXISTS (
			SELECT 1
			FROM cw.UserBondRating_postwf ubrPostWF
			JOIN cfgcw.DealNote dn ON dn.ISIN = ubrPostWF.ISIN
				AND dn.DealId = @dealId
				AND ubrPostWF.WorkflowProcessId = @workflowProcessId
			LEFT JOIN cw.vwBondRating ubr ON ubr.ISIN = ubrPostWF.ISIN
				AND ubr.Series = ubrPostWF.Series
				AND ubr.RatingTypeId = ubrPostWF.RatingTypeId
				AND ubr.Rating = ubrPostWF.Rating
				AND ubr.RatingDate = @bondRatingMaxDate
				AND ubr.ISIN IN (
					SELECT ISIN
					FROM cfgcw.DealNote
					WHERE DealId = @dealId
					)
			WHERE ubrPostWF.RatingDate = @bondRatingMaxDate
				AND ubr.ISIN IS NULL
			)
		OR EXISTS (
			SELECT 1
			FROM cw.vwBondRating ubr
			JOIN cfgcw.DealNote dn ON dn.ISIN = ubr.ISIN
				AND dn.DealId = @dealId
			LEFT JOIN cw.UserBondRating_postwf ubrPostWF ON ubr.ISIN = ubrPostWF.ISIN
				AND ubr.Series = ubrPostWF.Series
				AND ubr.RatingTypeId = ubrPostWF.RatingTypeId
				AND ubr.Rating = ubrPostWF.Rating
				AND ubrPostWF.ISIN IN (
					SELECT ISIN
					FROM cfgcw.DealNote
					WHERE DealId = @dealId
					)
				AND ubrPostWF.WorkflowProcessId = @workflowProcessId
				AND ubrPostWF.RatingDate = @bondRatingMaxDate
			WHERE ubr.RatingDate = @bondRatingMaxDate
				AND ubrPostWF.ISIN IS NULL
			)
	BEGIN
		SET @resultCode = 109 --Bond rating data change  for RMBS 
	END
	--Bond rating for Covered Bond 
	ELSE IF EXISTS (
			SELECT 1
			FROM cw.UserBondRating_postwf ubrPostWF
			JOIN cfgcb.DealNote dn ON dn.ISIN = ubrPostWF.ISIN
				AND dn.DealId = @dealId
				AND ubrPostWF.WorkflowProcessId = @workflowProcessId
			LEFT JOIN cw.vwBondRating ubr ON ubr.ISIN = ubrPostWF.ISIN
				AND ubr.Series = ubrPostWF.Series
				AND ubr.RatingTypeId = ubrPostWF.RatingTypeId
				AND ubr.Rating = ubrPostWF.Rating
				AND ubr.RatingDate = @bondRatingMaxDate
				AND ubr.ISIN IN (
					SELECT ISIN
					FROM cfgcb.DealNote
					WHERE DealId = @dealId
					)
			WHERE ubrPostWF.RatingDate = @bondRatingMaxDate
				AND ubr.ISIN IS NULL
			)
		OR EXISTS (
			SELECT 1
			FROM cw.vwBondRating ubr
			JOIN cfgcb.DealNote dn ON dn.ISIN = ubr.ISIN
				AND dn.DealId = @dealId
			LEFT JOIN cw.UserBondRating_postwf ubrPostWF ON ubr.ISIN = ubrPostWF.ISIN
				AND ubr.Series = ubrPostWF.Series
				AND ubr.RatingTypeId = ubrPostWF.RatingTypeId
				AND ubr.Rating = ubrPostWF.Rating
				AND ubrPostWF.ISIN IN (
					SELECT ISIN
					FROM cfgcb.DealNote
					WHERE DealId = @dealId
					)
				AND ubrPostWF.WorkflowProcessId = @workflowProcessId
				AND ubrPostWF.RatingDate = @bondRatingMaxDate
			WHERE ubr.RatingDate = @bondRatingMaxDate
				AND ubrPostWF.ISIN IS NULL
			)
	BEGIN
		SET @resultCode = 109 --Bond rating data change  
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM cw.UserCounterpartyRating_PostWF cprPostWF
			JOIN [CW].[vw_ActiveDealCounterparty] cp ON cp.CisCode = cprPostWF.CisCode
				AND cp.DealId = @dealId
				AND cprPostWF.WorkflowProcessId = @workflowProcessId
			LEFT JOIN cw.vwCounterPartyRating cpr ON cpr.CisCode = cprPostWF.CisCode
				AND cpr.RatingTypeId = cprPostWF.RatingTypeId
				AND cpr.Rating = cprPostWF.Rating
				AND cpr.RatingDate = @cpRatingMaxDate
				AND cpr.CisCode IN (
					SELECT CisCode
					FROM [CW].[vw_ActiveDealCounterparty] cp
					WHERE cp.DealId = @dealId
					)
			WHERE cprPostWF.RatingDate = @cpRatingMaxDate
				AND cpr.CisCode IS NULL
				OR EXISTS (
					SELECT 1
					FROM cw.vwCounterPartyRating cpr
					JOIN [CW].[vw_ActiveDealCounterparty] cp ON cp.CisCode = cpr.CisCode
						AND cp.DealId = @dealId
						AND cprPostWF.WorkflowProcessId = @workflowProcessId
					LEFT JOIN cw.UserCounterpartyRating_PostWF cprPostWF ON cpr.CisCode = cprPostWF.CisCode
						AND cpr.RatingTypeId = cprPostWF.RatingTypeId
						AND cpr.Rating = cprPostWF.Rating
						AND cpr.RatingDate = @cpRatingMaxDate
						AND cpr.CisCode IN (
							SELECT CisCode
							FROM [CW].[vw_ActiveDealCounterparty] cp
							WHERE cp.DealId = @dealId
							)
					WHERE cpr.RatingDate = @cpRatingMaxDate
						AND cprPostWF.CisCode IS NULL
					)
			)
	BEGIN
		SET @resultCode = 110 --CP rating change  
	END
	ELSE IF EXISTS (
			SELECT 1
			FROM cw.[DealIpdConditionTest] ct
			LEFT JOIN [cw].[DealIpdConditionTest_PostWF] ctPostWF ON ct.DealConditionId = ctPostWF.DealConditionId
				AND ISNULL(ctPostWF.LoanCount, 0) = ISNULL(ct.LoanCount, 0)
				AND ISNULL(ctPostWF.LoanAmount, 0) = ISNULL(ct.LoanAmount, 0)
				AND ISNULL(ctPostWF.RepurchaseAmount, 0) = ISNULL(ct.RepurchaseAmount, 0)
				AND ct.DealIpdRunId = ctPostWF.DealIpdRunId
			WHERE ct.DealIpdRunId = @dealIpdRunId
				AND ctPostWF.DealConditionTestId IS NULL
				OR EXISTS (
					SELECT 1
					FROM cw.[DealIpdConditionTest_PostWF] ctPostWF
					LEFT JOIN [cw].[DealIpdConditionTest] ct ON ct.DealConditionId = ctPostWF.DealConditionId
						AND ISNULL(ctPostWF.LoanCount, 0) = ISNULL(ct.LoanCount, 0)
						AND ISNULL(ctPostWF.LoanAmount, 0) = ISNULL(ct.LoanAmount, 0)
						AND ISNULL(ctPostWF.RepurchaseAmount, 0) = ISNULL(ct.RepurchaseAmount, 0)
						AND ct.DealIpdRunId = ctPostWF.DealIpdRunId
					WHERE ct.DealIpdRunId = @dealIpdRunId
						AND ctPostWF.DealConditionTestId IS NULL
						AND ctPostWF.WorkflowProcessId = @workflowProcessId
					)
			)
	BEGIN
		SET @resultCode = 111 --ConditionTest change  
	END
	ELSE IF EXISTS (
			SELECT TOP 1 1 
			FROM cb.ManualFieldValue mfv
			FULL JOIN cb.ManualFieldValue_PostWF mfv_PostWF ON mfv.ManualFieldId = mfv_PostWF.ManualFieldId
				AND mfv.DealIpdRunId = mfv_PostWF.DealIpdRunId
				AND mfv.[Value] = mfv_PostWF.[Value]
			JOIN cfgcb.ManualField mf ON mf.ManualFieldId = mfv.ManualFieldId
			JOIN cfgcb.ManualFieldGroup mfg ON mfg.ManualFieldGroupId = mf.ManualFieldGroupId
			JOIN cfgcb.ManualFieldGroupType mfgt ON mfgt.ManualFieldGroupTypeId = mfg.ManualFieldGroupTypeId
			WHERE mfv.DealIpdRunId = @dealIpdRunId
				AND (
					mfv.ManualFieldId IS NULL
					OR mfv_PostWF.ManualFieldId IS NULL
					)
				AND mfgt.InternalName = 'CashwaterfallField'
			)
	BEGIN
		SET @resultCode = 112 --Manual Field change  
	END
	RETURN @resultCode
END
GO


