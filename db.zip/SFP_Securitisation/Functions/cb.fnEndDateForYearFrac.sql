USE [SFP_Securitisation]
GO
IF OBJECT_ID('cb.fnEndDateForYearFrac') IS NOT NULL
	DROP FUNCTION [cb].[fnEndDateForYearFrac]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

/*    
Author			: Aditya Shrivastava
Created Date	: 15-06-2022
Description		: for calculating period end date for an ipd 
select [cb].[fnEndDateForYearFrac] ('2022-05-23')

 Change History 
  --------------  
  Author    Date    Description 
  ------------------------------------------------------- 
*/     
CREATE FUNCTION [cb].[fnEndDateForYearFrac] (@ipddate  date)
returns date
AS 
BEGIN
	Declare @MaxInterestRateDate date= (select top 1 BaseDate FROM [cw].[vwInterestRate] where RICCode = 'SONIAOSR=' order by 1 desc);
	Declare @retDate date;
	If(@MaxInterestRateDate > @ipddate)
		set @retDate= @ipddate;
	else
		set @retDate= @MaxInterestRateDate;

		RETURN @retDate;
END