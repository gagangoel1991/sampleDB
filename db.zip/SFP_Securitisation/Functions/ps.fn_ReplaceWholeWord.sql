USE [SFP_Securitisation]
GO

IF OBJECT_ID('ps.fn_ReplaceWholeWord') IS NOT NULL
	DROP FUNCTION [ps].[fn_ReplaceWholeWord]
GO

CREATE FUNCTION ps.fn_ReplaceWholeWord(@text VARCHAR(MAX), @toReplace VARCHAR(MAX), @replacer VARCHAR(MAX))
RETURNS VARCHAR(MAX)
AS
BEGIN
DECLARE @newText VARCHAR(MAX) = '';

WHILE @text <> ''
BEGIN
	
	DECLARE @currentWord VARCHAR(MAX) = CASE WHEN CHARINDEX(' ', @text, 0) > 0 THEN SUBSTRING(@text, 0, CHARINDEX(' ', @text, 0)) ELSE @text END;
	
	IF @currentWord = @toReplace
		SET @newText = @newText + @replacer + ' ';
	ELSE
		SET @newText = @newText + @currentWord + ' ';
	
	SET @text = CASE WHEN CHARINDEX(' ', @text, 0) = 0 THEN '' ELSE SUBSTRING(@text, CHARINDEX(' ', @text, 0)+1, LEN(@text)+2) END

END

SET @newText = RTRIM(@newText);

RETURN @newText;
END
GO