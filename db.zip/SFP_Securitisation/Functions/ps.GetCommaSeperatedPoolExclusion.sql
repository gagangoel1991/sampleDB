USE [SFP_Securitisation]
GO

IF OBJECT_ID('ps.GetCommaSeperatedPoolExclusion') is not NULL
	DROP FUNCTION [ps].[GetCommaSeperatedPoolExclusion]
GO

/* 
  Author: Saurabh Tyagi
  Date:  28.06.2022 
  Description: Returns comma seperated Exclusion reasons ids
  Ex: SELECT [ps].[GetCommaSeperatedExclusionForPool](110)
       
  Change History 
  -------------- 
  Author    Date    Description 
  -------------------------------------------------------            
  */

CREATE FUNCTION [ps].[GetCommaSeperatedPoolExclusion]
(
	@PoolId VARCHAR(MAX)
)
RETURNS NVARCHAR(MAX) 
AS
	BEGIN
	      DECLARE @ReasonIds NVARCHAR(MAX);

	       DECLARE @poolExclusionTbl TABLE
		  (
			 Reasonid INT
		  )

		INSERT INTO @poolExclusionTbl
					(
						Reasonid
					)
		SELECT Reasonid
		FROM   [ps].[PoolExclusionException] exclusion
		WHERE  exclusion.Poolid = @PoolId;

		SELECT @ReasonIds = Stuff((SELECT ',' + CONVERT(VARCHAR(100), ex.Reasonid)
					  FROM   @poolExclusionTbl ex
					  WHERE  ex.Reasonid = ex.Reasonid
					  GROUP  BY ex.Reasonid
					  FOR XML PATH('')), 1, 1,'')
		FROM   @poolExclusionTbl exclusion;
		
		RETURN @ReasonIds
	END
GO
