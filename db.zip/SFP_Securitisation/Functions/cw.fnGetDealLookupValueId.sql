USE [SFP_Securitisation]
GO
IF OBJECT_ID('cw.fnGetDealLookupValueId') IS NOT NULL
	DROP FUNCTION [cw].[fnGetDealLookupValueId]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*    
 * Author			: Suresh Pandey 
 * Created Date	: 29-09-2021    
 * Description		: For gettingthe lookup Id from cfgcw.DealLookupValue table
*/    
CREATE FUNCTION [cw].[fnGetDealLookupValueId]
(
  @pLookupTypeCode		VARCHAR(100), 
  @pLookupValueName		VARCHAR(300)
 )  
RETURNS  VARCHAR(300) AS           
BEGIN      
    DECLARE @result		VARCHAR(300)

	SELECT 
		@result = dlv.LookupValueId 
	FROM 
		cfgcw.DealLookupValue dlv
	JOIN 
		cfgcw.DealLookupType dlt ON dlt.LookupTypeId = dlv.LookupTypeId
	WHERE 
		dlt.TypeCode = @pLookupTypeCode
		AND dlv.[Name] = @pLookupValueName

     RETURN @result
END  
GO