USE [SFP_Securitisation]
GO

IF OBJECT_ID('[cw].[fnGetWaterfallLineItemValue]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetWaterfallLineItemValue]
GO
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

/*
 * Author: Kapil Sharma
 * Date:	18.01.2022
 * Description:  This will return the manual field value
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Example:
 * SELECT [cb].[fnGetWaterfallLineItemValue](34, 'PreAvailableRevenueReceipts', 'PreAvailableRevenueReceipts_7.000') 
*/ 
CREATE FUNCTION [cw].[fnGetWaterfallLineItemValue]    
(      
    @pDealIpdRunId					INT,
	@pCategoryInternalName			VARCHAR(200),
	@pLineItemInternalName			VARCHAR(200)
)      
RETURNS DECIMAL(36, 18) 
AS     
BEGIN      
	DECLARE @value DECIMAL(36, 18)
	
	SELECT @value = wlia.TotalRequiredAmount FROM cw.WaterfallLineItemAmount wlia
	JOIN cfgcw.WaterfallLineItem wli ON wli.WaterfallLineItemId = wlia.WaterfallLineItemId
	JOIN cfgcw.WaterfallCategory wc ON wc.WaterfallCategoryId = wli.WaterfallCategoryId
	WHERE wc.InternalName = @pCategoryInternalName AND wli.InternalName = @pLineItemInternalName
	AND wlia.DealIpdRunId = @pDealIpdRunId

	RETURN @value
END
GO


