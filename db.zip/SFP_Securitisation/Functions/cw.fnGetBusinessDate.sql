USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetBusinessDate]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetBusinessDate]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	03.05.2021
 * Description:  This will return the business data 
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cw].[fnGetBusinessDate]      
(      
    @pDate			DATE,
	@pRegionCode	VARCHAR(20),
	@pInterval		INT,
	@pZeroBackward	BIT = 0
)      
RETURNS DATE     
AS      
BEGIN      
	DECLARE @businessDate DATE
	
	IF @pInterval = 0 AND @pZeroBackward = 1
	BEGIN
		SELECT
		   @businessDate = AsAtDate
		FROM
		   sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			AsAtDate<=@pDate
			AND RegionCode = @pRegionCode
			AND IsWorkingDay = 1
		ORDER BY
		   AsAtDate DESC
		OFFSET @pInterval ROWS   -- Skip this number of rows
		FETCH NEXT 1 ROWS ONLY;  -- Return this number of row
	END
	ELSE IF @pInterval>=0
	BEGIN
		SELECT
		   @businessDate = AsAtDate
		FROM
		   sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			AsAtDate>=@pDate
			AND RegionCode = @pRegionCode
			AND IsWorkingDay = 1
		ORDER BY
		   AsAtDate
		OFFSET @pInterval ROWS   -- Skip this number of rows
		FETCH NEXT 1 ROWS ONLY;  -- Return this number of row
	END
	ELSE
	BEGIN
		SELECT
		   @businessDate = AsAtDate
		FROM
		   sfp.syn_SfpModel_vw_Calendar_v1
		WHERE 
			AsAtDate<=@pDate
			AND RegionCode = @pRegionCode
			AND IsWorkingDay = 1
		ORDER BY
		   AsAtDate DESC
		OFFSET @pInterval*-1 ROWS   -- Skip this number of rows
		FETCH NEXT 1 ROWS ONLY;  -- Return this number of row
	END

	RETURN @businessDate
END
GO
