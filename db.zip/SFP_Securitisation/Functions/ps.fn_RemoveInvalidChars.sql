USE [SFP_Securitisation]
GO
/****** Object:  UserDefinedFunction [ps].[fn_RemoveInvalidChars]    Script Date: 18/09/2020 21:30:16 ******/
IF OBJECT_ID('ps.fn_RemoveInvalidChars') IS NOT NULL
DROP FUNCTION [ps].[fn_RemoveInvalidChars]
GO

/****** Object:  UserDefinedFunction [ps].[fn_RemoveInvalidChars]    Script Date: 18/09/2020 21:30:16 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO



CREATE FUNCTION [ps].[fn_RemoveInvalidChars]
 (
 @Value varchar(MAX)
 )
 Returns varchar(MAX)
BEGIN
	DECLARE @Result varchar(Max)
  SET @Result = RTRIM(LTRIM(REPLACE(REPLACE(@Value, '[', ''), ']', '')))
  SET @Result = RTRIM(LTRIM(REPLACE(REPLACE(@Result, '(', ''), ')', '')))
  RETURN LOWER(@Result)
END
GO


