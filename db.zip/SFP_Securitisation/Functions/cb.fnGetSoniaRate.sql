USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetSoniaRate]') IS NOT NULL
BEGIN
	DROP FUNCTION [cw].[fnGetSoniaRate]
END
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	04.02.2022
 * Description:  This will return SONIA rate for a given date
 * 
 * SELECT [cw].[fnGetSoniaRate]('2021-04-01', 5)
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cw].[fnGetSoniaRate]      
(      
    @pDate				DATE,
	@pResetLeadDays		TINYINT
)      
RETURNS DECIMAL(36, 18)     
AS      
BEGIN      
	DECLARE 
		@rate		DECIMAL(36, 18)
	
	SELECT @rate = scr.SoniaRate FROM cb.SoniaCompoundingRate scr
	JOIN [cfgcb].[SoniaResetLeadDays] srld ON scr.SoniaResetLeadDaysId = srld.SoniaResetLeadDaysId
	WHERE srld.[Value] = @pResetLeadDays AND srld.IsActive = 1
		AND scr.ResetDate = @pDate

	RETURN @rate
END
GO