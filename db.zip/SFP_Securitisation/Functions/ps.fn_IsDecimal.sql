USE [SFP_Securitisation]
GO

IF OBJECT_ID('ps.fn_IsDecimal') IS NOT NULL
	DROP FUNCTION [ps].[fn_IsDecimal]
GO

SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE FUNCTION [ps].[fn_IsDecimal]
(
	@Number VARCHAR(100)
)
RETURNS BIT
AS
BEGIN

   RETURN REPLACE(ISNUMERIC(REPLACE(@Number,'+','A') + 'e0'),1,CHARINDEX('.',@Number))

END
GO


