USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[fnGetManualFieldValue]') IS NOT NULL
	DROP FUNCTION [cb].[fnGetManualFieldValue]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	18.01.2022
 * Description:  This will return the manual field value
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Example:
 * SELECT [cb].[fnGetManualFieldValue](1034, 'AssetCoverage', 'Breaches_Warranties') 
*/ 
CREATE FUNCTION [cb].[fnGetManualFieldValue]    
(      
    @pDealIpdRunId					INT,
	@pManualFieldInternalGroupName	VARCHAR(200),
	@pManualFieldInternalName		VARCHAR(200)
)      
RETURNS VARCHAR(200)  
AS     
BEGIN      
	DECLARE @value VARCHAR(200) 
	
	SELECT @value = mfv.[Value] FROM cb.ManualFieldValue mfv
	JOIN cfgcb.ManualField mf ON mf.ManualFieldId = mfv.ManualFieldId
	JOIN cfgcb.ManualFieldGroup mfg ON mfg.ManualFieldGroupId = mf.ManualFieldGroupId
	WHERE mfv.DealIpdRunId = @pDealIpdRunId AND mfg.InternalName = @pManualFieldInternalGroupName
	AND mf.InternalName = @pManualFieldInternalName

	RETURN @value
END
GO