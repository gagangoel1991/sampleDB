USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[fnGetWeightedAverageMargin]') IS NOT NULL
	DROP FUNCTION [cb].[fnGetWeightedAverageMargin]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Suresh Pandey
 * Date:	19.01.2022
 * Description:  This will return the Weighted Average Margin  
 * 
 * SELECT [Cb].[fnGetWeightedAverageMargin](6, 28)			
 * 
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cb].[fnGetWeightedAverageMargin]      
(      
	@pDealId SMALLINT,
	@pDealIpdRunId INT
)      
RETURNS DECIMAL(38, 16)    
AS      
BEGIN  
	DECLARE @ipdDate   DATETIME ,@weightedAverageMargin DECIMAL(38, 16) 

	SELECT @ipdDate = IpdDate FROM  cw.vwDealIpdRun 
		WHERE  DealIpdRunId = @pDealIpdRunId; 

	SELECT @weightedAverageMargin= SUM (IssuanceAmount/100 * Margin)/CAST(SUM(IssuanceAmount ) AS FLOAT) /100
		FROM (
			SELECT dn.DealNoteId,IsNote,IsSwapLinked,dn.MaturityDate, IssuanceAmount,
					CASE WHEN dn.IsSwapLinked =1 THEN ns.PayMargin ELSE dn.Margin END AS Margin FROM
				(
					SELECT DealNoteId,IsNote,IsSwapLinked,MaturityDate, GBPEquivalent AS IssuanceAmount,Margin  FROM [cfgcb].[DealNote] 
						WHERE DealId=@pDealId AND MaturityDate>@ipdDate
				) AS dn
				LEFT JOIN [cfgcb].[NoteSwap] ns
					ON dn.DealNoteId=ns.DealNoteId  AND dn.IsSwapLinked=1 AND @ipdDate BETWEEN ns.ValidFrom AND ns.ValidTo 
		) a
	
	
	RETURN @weightedAverageMargin

END
GO

