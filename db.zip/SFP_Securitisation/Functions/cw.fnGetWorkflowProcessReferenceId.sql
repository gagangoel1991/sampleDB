USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetWorkflowProcessReferenceId]') IS NOT NULL
	DROP FUNCTION [cw].[fnGetWorkflowProcessReferenceId];
GO
-----------------------------------------------
--Author       : Kapil Sharma  
--Created Date : 24-06-2021    
--Description  : GET unique Process Ref Id
--Example      : Select cw.fnGetProcessReferenceId 
-----------------------------------------------
  
CREATE FUNCTION [cw].[fnGetWorkflowProcessReferenceId]
(
	@pWorkflowType		VARCHAR(100),
	@pDealIpdRunId		INT	
)  
RETURNS  INT AS           
BEGIN      
	DECLARE 
		@processReferenceId			INT,
		@dealId						SMALLINT,
		@businessStartDate			DATE,
		@businessEndDate			DATE,
		@ipdDate					DATE

	--Getting the dealid, Business Start and End Date for the speciifed run id
	SELECT @dealID = di.DealId, @businessStartDate = did.CollectionBusinessStart, 
		@businessEndDate = did.CollectionBusinessEnd, @ipdDate = did.IPD
	FROM cw.DealIpd di
	JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
	JOIN cw.vwDealIpdDates did ON did.DealIpdId = di.DealIpdId
	WHERE dir.RunId = @pDealIpdRunId

	IF @pWorkflowType = 'Automated_Data_Daily_Collection'
	BEGIN
		SELECT @processReferenceId = wip.ProcessReferenceId FROM cw.DailyCollection_wip wip
		JOIN cw.vwWorkFlowLastAction wfp ON wfp.ProcessReferenceId = wip.ProcessReferenceId
		WHERE wip.DealId = @dealID
		AND wfp.WorkflowTypeName = @pWorkflowType
		AND wfp.WorkflowStepName <>'Authorise'
		AND wip.CollectionDate>=@businessStartDate AND wip.CollectionDate<=@businessEndDate
	END
	ELSE IF @pWorkflowType = 'Automated_Data_Collection_Ledger'
	BEGIN
		SELECT @processReferenceId = wip.ProcessReferenceId FROM cw.CollectionLedger_WIP wip
		JOIN cw.vwWorkFlowLastAction wfp ON wfp.ProcessReferenceId = wip.ProcessReferenceId
		WHERE wip.DealId = @dealID
		AND wfp.WorkflowTypeName = @pWorkflowType
		AND wfp.WorkflowStepName <>'Authorise'
		AND wip.CollectionDate>=@businessStartDate AND wip.CollectionDate<=@businessEndDate
	END
	ELSE IF @pWorkflowType = 'Automated_Data_Interest_Rates'
	BEGIN
		SELECT @processReferenceId = wip.ProcessReferenceId FROM cw.InterestRate_WIP wip
		JOIN cw.InterestRate ir ON ir.InterestRateId = wip.InterestRateId 
		JOIN cw.vwWorkFlowLastAction wfp ON wfp.ProcessReferenceId = wip.ProcessReferenceId
		WHERE wfp.WorkflowTypeName = @pWorkflowType
		AND wfp.WorkflowStepName <>'Authorise'
		AND ir.BaseDate >=@businessStartDate AND ir.BaseDate<=@ipdDate
	END

	ELSE IF @pWorkflowType = 'Automated_Data_Cash_Ladder'
	BEGIN
		SELECT @processReferenceId = wip.ProcessReferenceId FROM cw.CashLadder_WIP wip
		JOIN cw.vwWorkFlowLastAction wfp ON wfp.ProcessReferenceId = wip.ProcessReferenceId
		WHERE wip.DealId = @dealID
		AND wfp.WorkflowTypeName = @pWorkflowType
		AND wfp.WorkflowStepName <>'Authorise'
	--	AND wip.CollectionDate>=@businessStartDate AND wip.CollectionDate<=@businessEndDate
	END

	IF @processReferenceId IS NULL
	BEGIN
		SELECT @processReferenceId = ISNULL(MAX(ISNULL(wfp.ProcessReferenceId, 0)), 0) + 1 FROM cw.WorkflowProcess wfp 
		JOIN cfgcw.WorkflowStep wfs ON wfs.WorkflowStepId = wfp.WorkflowStepId
		JOIN cfgcw.WorkflowType wft ON wft.WorkflowTypeId = wfs.WorkflowTypeId
		WHERE wft.[Name] = @pWorkflowType
	END
	
    RETURN @processReferenceId
END  
GO
