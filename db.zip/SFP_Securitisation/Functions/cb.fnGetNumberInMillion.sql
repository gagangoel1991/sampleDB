USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[fnGetNumberInMillion]') IS NOT NULL
	DROP FUNCTION [cb].[fnGetNumberInMillion]
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Suresh Pandey
 * Date:	19.01.2022
 * Description:   
 * 
 * SELECT [cb].[fnGetNumberInMillion]( 22)			
 * 
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION [cb].[fnGetNumberInMillion]    
(      
	@pNumber DECIMAL(38, 16)
)      
RETURNS DECIMAL(18, 2)    
AS      
BEGIN  
	DECLARE @numberInMillion DECIMAL(18, 2) 

	SET @numberInMillion = @pNumber/1000000
	
	
	RETURN @numberInMillion

END
GO

