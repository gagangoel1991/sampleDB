USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnGetRoundUpValue]') IS NOT NULL
	DROP FUNCTION cw.fnGetRoundUpValue
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Arun 
 * Date:	24.08.2022
 * Description:   
 * 
 * SELECT [cw].[fnGetRoundUpValue](34580, 5)		
 * 
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
*/ 
CREATE FUNCTION cw.fnGetRoundUpValue    
(      
	@pNumber NUMERIC,
	@pRoundUpTo INT= 0
)      
RETURNS DECIMAL(18, 2)    
AS      
BEGIN  

	DECLARE @roundUpValue varchar(max)

	IF len(@pNumber) <=@pRoundUpTo 
	BEGIN
		SET @roundUpValue = CAST((1) as VARCHAR) + CAST( REPLICATE(0, @pRoundUpTo) as VARCHAR)
	END
	ELSE
	BEGIN
		SET @pNumber = Left(@pNumber, len(@pNumber)- @pRoundUpTo)
		SET @roundUpValue = CAST((@pNumber+1) as VARCHAR) + CAST( REPLICATE(0, @pRoundUpTo) as VARCHAR)
	END

	RETURN @roundUpValue

END
GO


