USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cb].[fnGetSoniaCompoundingCouponRate]') IS NOT NULL
	DROP FUNCTION [cb].[fnGetSoniaCompoundingCouponRate] 
GO
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/*
 * Author: Kapil Sharma
 * Date:	18.01.2022
 * Description:  This will return the SONIA compounding Coupon Rate for Notes and Deal Swap 
 * 				
 * Change History
 * --------------
 * Author		Date		Description
 * -------------------------------------------------------
 * Example:
 * SELECT [CW].[fnGetSoniaCompoundingCouponRate](14, '0.087671233', '2021-04-22', '2021-05-24') 
*/ 
CREATE FUNCTION [cb].[fnGetSoniaCompoundingCouponRate]      
(      
    @pAcrualBasisTypeId			INT,
	@dayCountFactorVal			DECIMAL(38,16),
	@pPeriodStartDate			DATETIME,
	@pPeriodEndDate				DATETIME
)      
RETURNS DECIMAL(38, 16)     
AS      
BEGIN      
	DECLARE @couponRate DECIMAL(38, 16)  
	
	SELECT @couponRate = ((EXP(SUM(LOG(scar.Rate))) - 1)*1/@dayCountFactorVal*100)/100 FROM [cb].[SoniaCompoundingRate] scr
	JOIN [cb].[SoniaCompoundingAccrualRate] scar ON scr.SoniaCompoundingRateId = scar.SoniaCompoundingRateId
	WHERE
		scar.AccrualBasisTypeId = @pAcrualBasisTypeId 
		AND scr.AccrualStartDate>=@pPeriodStartDate
		AND scr.AccrualEndDate<=@pPeriodEndDate

	RETURN @couponRate
END
GO