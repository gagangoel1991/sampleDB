USE [SFP_Securitisation]
GO
IF OBJECT_ID('[cw].[fnIR_GetTriggerThresholdRating]') IS NOT NULL
	DROP FUNCTION [cw].[fnIR_GetTriggerThresholdRating];
GO
--------------------------------------------------------
--Author   : Saurabh Bhatia  
--Created Date : 29-April-2022    
--Description  : Copy of fnGetTriggerThresholdRating 
--				 To fetch non rating threshold rating
--Example   : SELECT  [cw].[fnIR_GetTriggerThresholdRating](1)
--------------------------------------------------------   
  
CREATE FUNCTION [cw].[fnIR_GetTriggerThresholdRating]      
(      
     @pDealIpdTriggerResultId  INT
)      
 RETURNS VARCHAR(MAX)   
AS      
BEGIN  

    DECLARE  @ThresholdRatingTable TABLE 
    (
        ThresholdRating VARCHAR(500)
    )  
    DECLARE @ThresholdRating VARCHAR(MAX)    
    INSERT INTO @ThresholdRatingTable
    SELECT  DISTINCT CONCAT(cra.Name,' ',rt.Name,' ',trm.ThresholdRating) AS ThresholdRating  FROM cfgCW.DealTriggerRatingMap trm
    JOIN  cfgCW.DealSubjectCRAMap craMap ON trm.DealSubjectCRAMapId=craMap.DealSubjectCRAMapId
    JOIN cfgCW.CreditRatingAgency cra ON craMap.CRAId=cra.CRAId
    JOIN cfgCW.RatingType rt ON trm.RatingTypeId=rt.RatingTypeId
    JOIN cfgCW.DealTriggerMap tm ON trm.DealTriggerMapId=tm.DealTriggerMapId
    JOIN cw.DealIpdTriggerResult tr ON trm.DealTriggerMapId=tr.DealTriggerMapId
    WHERE tr.DealIpdTriggerResultId=@pDealIpdTriggerResultId
     
     SELECT @ThresholdRating = COALESCE(@ThresholdRating + ' / ', '') + ThresholdRating FROM @ThresholdRatingTable

     RETURN @ThresholdRating
END     
GO
