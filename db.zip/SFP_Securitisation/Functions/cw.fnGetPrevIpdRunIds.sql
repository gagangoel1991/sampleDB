USE [SFP_Securitisation]
GO

IF OBJECT_ID('cw.fnGetPrevIpdRunIds') IS NOT NULL
	DROP FUNCTION cw.fnGetPrevIpdRunIds;
GO

/*    
 *   
 * Author   : GUNJAN CHANDOLA  
 * Created Date : 19-05-2021    
 * Description  : To fetch last four IPDDates
 * Example   :  Select * FROM cw.fnGetPrevIpdRunIds(14,3,4)  
*/
CREATE FUNCTION [CW].[fnGetPrevIpdRunIds] (
	@pDealId INT
	,@pIPDRunId INT
	,@pNumOfLastIpds INT
	)
RETURNS @LastFourIpdRunIds TABLE (RunId INT)
AS
BEGIN
	DECLARE @ipdDate DATE

	SELECT @ipdDate = IPDDate
	FROM cw.DealIpd di
	JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
	WHERE dir.RunId = @pIPDRunId

	INSERT INTO @LastFourIpdRunIds
	SELECT TOP (@pNumOfLastIpds) dir.RunId
	FROM cw.DealIpd di
	JOIN cw.DealIpdRun dir ON di.DealIpdId = dir.DealIpdId
	WHERE (
			di.dealid != 6
			AND dir.IsCurrentVersion = 1
			AND di.IpdSequence > 0
			AND di.IpdDate <= @ipdDate
			AND di.DealId = @pDealId
			)
		OR (
			di.dealid = 6
			AND dir.IsCurrentVersion = 1
			AND di.IpdSequence > 131
			AND di.IpdDate <= @ipdDate
			AND di.DealId = @pDealId
			)
	ORDER BY di.IpdDate DESC

	RETURN
END
GO


