USE [SFP_Securitisation]
GO

IF object_Id('CW.fnGetStratConfigGroupName') IS NOT NULL 
	DROP  FUNCTION CW.fnGetStratConfigGroupName

Go

CREATE FUNCTION CW.fnGetStratConfigGroupName
(
	@stratRangeData  AS [cw].[udtStratRangeConfig] READONLY 
	,@Value DECIMAL(38,16)
)     
/*      
 * Author: Arun  
 * Date:    14.11.2020      
 * Description:  This will return group by name after comparing passed value with attribute value      
 *                                                       
 * Change History      
 * --------------      
 * Author              Date                 Description      
 * -------------------------------------------------------      
*/      
RETURNs VARCHAR(200) AS      
BEGIN      
    
 DECLARE @retValue VARCHAR(200);      
   
 SELECT @retValue=
 
  (CASE     
    WHEN FromValue IS NOT NULL AND ToValue IS NOT NULL     
     THEN C.FromOperator+CONVERT(VARCHAR(20),CONVERT(FLOAT,FromValue))+'-'+C.ToOperator+CONVERT(VARCHAR(20),CONVERT(FLOAT,ToValue))    
    WHEN FromValue IS NULL    
     THEN C.ToOperator+CONVERT(VARCHAR(20),CONVERT(FLOAT,ToValue))    
    WHEN ToValue IS NULL    
     THEN C.FromOperator+CONVERT(VARCHAR(20),CONVERT(FLOAT,FromValue))    
    END)  
    
  FROM @stratRangeData C    
 WHERE    
 (    
  (    
   (CHARINDEX('=',ToOperator)=0 AND CHARINDEX('=',FromOperator)=0)    
   AND  (FromValue IS NOT NULL AND ToValue IS NOT NULL AND @Value > FromValue AND @Value < ToValue)    
  )    
  OR     
  (    
   (CHARINDEX('=',ToOperator)=2 AND CHARINDEX('=',FromOperator)=2)    
   AND  (FromValue IS NOT NULL AND ToValue IS NOT NULL AND @Value >= FromValue AND @Value <= ToValue)    
  )  
  OR     
  (    
   (CHARINDEX('=',FromOperator) IS NULL AND CHARINDEX('=',ToOperator) = 0 )    
	   AND (FromValue IS NULL AND @Value < ToValue)    
  )   
  OR     
  (    
   (CHARINDEX('=',FromOperator) IS NULL AND CHARINDEX('=',ToOperator) = 2 )    
	   AND (FromValue IS NULL AND @Value <= ToValue)    
  )   
   OR     
  (    
   (CHARINDEX('=',ToOperator) IS NULL AND CHARINDEX('=',FromOperator) = 0 )    
	   AND (ToValue IS NULL AND @Value > FromValue)    
  )   
   OR     
  (    
   (CHARINDEX('=',ToOperator) IS NULL AND CHARINDEX('=',FromOperator) = 2 )    
	   AND (ToValue IS NULL AND @Value >= FromValue)    
  )     
  OR     
  (    
   (CHARINDEX('=',ToOperator)=2 AND CHARINDEX('=',FromOperator)=0)    
   AND  (FromValue IS NOT NULL AND ToValue IS NOT NULL AND @Value > FromValue AND @Value <= ToValue)    
  )     
  OR     
  (    
   (CHARINDEX('=',ToOperator)=0 AND CHARINDEX('=',FromOperator)=2)    
   AND  (FromValue IS NOT NULL AND ToValue IS NOT NULL AND @Value >= FromValue AND @Value < ToValue)    
  )   

 )       
      
      
 RETURN isNull(@retValue,'');      
END      

GO
